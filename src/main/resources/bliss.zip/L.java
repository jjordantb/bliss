public abstract class L implements QAI {
   protected String I;
   protected String Z;
   protected String C = null;
   static int B;
   public static JY D;

   abstract void method1158(int var1, int var2, IEI var3);

   abstract void method1159(int var1, YF var2);

   String I(int var1) {
      try {
         return this.C;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "em.a(" + ')');
      }
   }

   abstract void method1161(VG var1, float var2, float var3);

   abstract void method1162(VG var1, float var2, float var3, float var4);

   abstract void method1163(VG var1, float var2, float var3, float var4, float var5);

   abstract void method1164(VG var1, float[] var2, int var3);

   abstract void method1165(VG var1, float var2, float var3, float var4, float var5);

   abstract void method1166(VG var1, YF var2);

   abstract void method1167(VG var1, int var2, IEI var3);

   abstract void method1168(int var1, float var2, float var3, float var4);

   abstract void method1169(int var1, float var2, float var3, float var4, float var5);

   abstract void method1170(int var1, float[] var2, int var3);

   abstract void method1171(int var1, YF var2);

   abstract void method1172(int var1, YF var2);

   abstract void method1173(int var1, YF var2);

   abstract void method1174(int var1, int var2, IEI var3);

   abstract void method1175(int var1, YF var2);

   abstract void method1176(VG var1, float var2);

   abstract void method1177(VG var1, float[] var2, int var3);

   abstract void method1178(VG var1, float var2, float var3, float var4, float var5);

   abstract void method1179(VG var1, float var2, float var3, float var4);

   public abstract boolean method1180();

   abstract void method1181(VG var1, float var2);

   abstract void method1182(int var1, float[] var2, int var3);

   abstract void method1183(VG var1, float var2);

   abstract void method1184(VG var1, int var2, IEI var3);

   abstract void method1185(VG var1, float var2, float var3);

   abstract void method1186(VG var1, float var2, float var3, float var4);

   abstract void method1187(VG var1, YF var2);

   abstract void method1188(VG var1, float var2, float var3, float var4);

   abstract void method1189(VG var1, float var2, float var3, float var4, float var5);

   abstract void method1190(VG var1, float var2);

   abstract void method1191(VG var1, float var2, float var3);

   abstract void method1192(VG var1, YF var2);

   abstract void method1193(VG var1, float var2, float var3, float var4, float var5);

   abstract void method1194(VG var1, float var2, float var3, float var4, float var5);

   abstract void method1195(int var1, float var2, float var3, float var4);

   abstract void method1196(VG var1, float[] var2, int var3);

   abstract void method1197(VG var1, YF var2);

   abstract void method1198(VG var1, YF var2);

   abstract void method1199(int var1, int var2, IEI var3);

   abstract void method1200(VG var1, YF var2);

   abstract void method1201(VG var1, YF var2);

   abstract void method1202(VG var1, YF var2);

   abstract void method1203(VG var1, YF var2);

   abstract void method1204(VG var1, YF var2);

   abstract void method1205(VG var1, float var2, float var3, float var4, float var5);

   abstract void method1206(int var1, float var2, float var3, float var4);

   abstract void method1207(VG var1, float var2);

   abstract void method1208(VG var1, int var2, IEI var3);

   public abstract boolean method1209();

   abstract void method1210(int var1, float var2, float var3, float var4);

   abstract void method1211(int var1, float var2, float var3, float var4);

   abstract void method1212(VG var1, int var2, IEI var3);

   abstract void method1213(int var1, float var2, float var3, float var4);

   abstract void method1214(int var1, float[] var2, int var3);

   abstract void method1215(VG var1, YF var2);

   abstract void method1216(VG var1, YF var2);

   abstract void method1217(int var1, YF var2);

   abstract void method1218(int var1, int var2, IEI var3);

   abstract void method1219(int var1, float var2, float var3, float var4);

   abstract void method1220(int var1, int var2, IEI var3);

   public abstract boolean method1221();

   abstract void method1222(int var1, float var2, float var3, float var4, float var5);

   public static void Z(int var0) {
      try {
         CU.I(22050, FW.J.r.Z((byte)-26) == 1, 2, 1957376607);
         AN.A = FDI.I(PCI.A, 0, 22050, -1310188777);
         WBI.I(true, GDI.I((XE)null, (int)-1887308031), 1581194982);
         JN.L = FDI.I(PCI.A, 1, 2048, -139744037);
         RA.S = new ZG();
         JN.L.I((WE)RA.S, (int)1746054467);
         NA.F = new CA(22050, 1164070869 * PA.F);
         KZ.I(-874181924);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "em.a(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         QO.I(var3, var4, var0, -1300595818);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "em.ch(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.S[(var0.A += 969361751) * -203050393 - 1] = TX.C.I(var2, (short)-5435).I((byte)-114);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "em.acl(" + ')');
      }
   }

   static void I(int var0, int var1, byte var2) {
      try {
         if (JX.J.S || FX.k * -278777595 != 1 && (!AU.B || 2 != -278777595 * FX.k || !FX.E.T.equals(VEI.RZ.I(WO.U, -875414210)))) {
            LZI var3 = NZ.I(-2044946043);
            int var4 = var3.I(VEI.OZ.I(WO.U, -875414210), -917382772);
            int var5;
            int var7;
            if (!FX.D) {
               for(YK var9 = (YK)FX.K.Z(1766612795); var9 != null; var9 = (YK)FX.K.B(49146)) {
                  var7 = GI.I(var9, var3, 692106883);
                  if (var7 > var4) {
                     var4 = var7;
                  }
               }

               var4 += 8;
               var5 = -411680299 * FX.C * FX.k * -278777595 + 21;
               UX.I = (FX.C * -411680299 * FX.k * -278777595 + (FX.c ? 26 : 22)) * -893561885;
            } else {
               for(EL var6 = (EL)FX.M.Z(-1195719541); var6 != null; var6 = (EL)FX.M.C(1977524177)) {
                  if (1 == var6.G * -628325139) {
                     var7 = GI.I((YK)var6.H.I.S, var3, 692106883);
                  } else {
                     var7 = KBI.I(var6, var3, 1340388103);
                  }

                  if (var7 > var4) {
                     var4 = var7;
                  }
               }

               var4 += 8;
               var5 = FX.H * 1592446965 * FX.C * -411680299 + 21;
               UX.I = -893561885 * ((FX.c ? 26 : 22) + FX.C * -411680299 * FX.H * 1592446965);
            }

            var4 += 10;
            int var10 = var0 - var4 / 2;
            if (var4 + var10 > GY.Z * -2110394505) {
               var10 = -2110394505 * GY.Z - var4;
            }

            if (var10 < 0) {
               var10 = 0;
            }

            var7 = var1;
            if (var1 + var5 > -1111710645 * JM.J) {
               var7 = JM.J * -1111710645 - var5;
            }

            if (var7 < 0) {
               var7 = 0;
            }

            QFI.I = 671566195 * var10;
            PN.E = 1083843311 * var7;
            ZZ.H = var4 * 1077909003;
            FX.d = (int)(Math.random() * 24.0D) * 704172827;
            FX.G = true;
         }

      } catch (RuntimeException var8) {
         throw DQ.I(var8, "em.r(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var3.W * 1354508417;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "em.os(" + ')');
      }
   }
}
