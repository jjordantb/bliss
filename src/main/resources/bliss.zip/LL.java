public abstract class LL extends QK {
   int G;

   abstract boolean method3436();

   abstract Object method3437(int var1);

   abstract boolean method3438(int var1);

   abstract boolean method3439();

   abstract Object method3440();

   abstract boolean method3441();

   LL(int var1) {
      this.G = 1222339519 * var1;
   }

   abstract Object method3442();
}
