import java.io.File;

public class FT {
   int I;
   public int Z = -345860175;
   public int C = 1206519288;
   public int B = 0;
   public int D = -473139963;
   static int append = 1190717;
   public int F = 1749423345;
   public int J = 99235328;
   public boolean S = true;
   public boolean A = true;
   public boolean E = false;
   public int G = -1425774653;
   ET H;
   public int K = -120073920;
   public int L = 1567851881;
   public int M = 0;
   public int N = 526820032;
   public static IBI O;
   public static GSI P;
   public static HJ[] Q;

   void I(byte var1) {
      try {
         this.C = (2109091647 * this.C << 8 | -692668059 * this.I) * 150814911;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "pn.b(" + ')');
      }
   }

   void append(REI var1, int var2, short var3) {
      try {
         if (var2 == 1) {
            this.B = P.I(var1.B((byte)45), (byte)66) * -1294090885;
         } else if (var2 == 2) {
            this.D = var1.I() * 473139963;
         } else if (3 == var2) {
            this.D = var1.C() * 473139963;
            if (324071475 * this.D == 65535) {
               this.D = -473139963;
            }
         } else if (5 == var2) {
            this.A = false;
         } else if (var2 == 7) {
            this.F = P.I(var1.B((byte)-44), (byte)71) * -1749423345;
         } else if (var2 == 8) {
            this.H.I = 1023752851 * this.I;
         } else if (var2 == 9) {
            this.J = (var1.C() << 2) * 1803744539;
         } else if (10 == var2) {
            this.S = false;
         } else if (11 == var2) {
            this.C = var1.I() * 150814911;
         } else if (var2 == 12) {
            this.E = true;
         } else if (13 == var2) {
            this.G = var1.B((byte)-32) * -442102017;
         } else if (var2 == 14) {
            this.K = (var1.I() << 2) * -1612488891;
         } else if (16 == var2) {
            this.Z = var1.I() * 1767159631;
         } else if (var2 == 20) {
            this.L = var1.C() * 1320194135;
         } else if (21 == var2) {
            this.M = var1.I() * 346396917;
         } else if (22 == var2) {
            this.N = var1.C() * 75340427;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "pn.f(" + ')');
      }
   }

   void I(REI var1, int var2) {
      try {
         while(true) {
            int var3 = var1.I();
            if (var3 == 0) {
               return;
            }

            this.append(var1, var3, (short)8128);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "pn.a(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, int var3) {
      try {
         var2.J -= -1175642067;
         var0.lI = var2.H[var2.J * 681479919] * -1733811909;
         var0.F = 210030285 * var2.H[681479919 * var2.J + 1];
         var0.RI = var2.H[2 + 681479919 * var2.J] * 1629063197;
         VEI.I(var0, -260828169);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "pn.ep(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         if (2 == XEI.lD * 1131012101 && var2 < -1054937867 * XEI.kD) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = XEI.bI[var2];
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "pn.vw(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         F var3 = XL.Z(var2, -1477365564);
         int var4 = -1;
         if (var3 != null) {
            var4 = var3.Z * -876503999;
         }

         var0.H[(var0.J += -391880689) * 681479919 - 1] = var4;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "pn.acx(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         boolean var2 = false;
         String var3 = "";
         if (var0.W != null && var0.W.I(592860146)) {
            File var4 = var0.W.I((short)-10504);
            if (var4 != null) {
               var3 = var4.getPath();
               if (var3 == null) {
                  var3 = "";
               }
            }

            var2 = true;
            var0.W = null;
         }

         var0.H[(var0.J += -391880689) * 681479919 - 1] = var2 ? 1 : 0;
         var0.S[(var0.A += 969361751) * -203050393 - 1] = var3;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "pn.agm(" + ')');
      }
   }

   static final void I(int var0) {
      try {
         KZI.Z.I((byte)89);
         IC.L.Z(1757095308);
         VD.G.I(682089220);
         XEI.mI.E(134727545).Z(1599239758);
         WZ.q.Z(343664164);
         JH.R.C(75457779);
         GZI.C.Z(-927634718);
         GC.S.I(1855785885);
         TY.D.Z(2005498704);
         LX.B.I((byte)80);
         NW.J.I(1240218712);
         UDI.D.I(2116049963);
         EJI.I.I((byte)119);
         FN.Z.I(242474592);
         YFI.F.I((byte)-124);
         II.CI.Z((byte)81);
         WQ.K.Z(758365461);
         WFI.C.I(2090718480);
         JSI.B.I(-1350735214);
         EZ.O.I(382411498);
         BJ.C.I(122236875);
         GJI.G.I((short)-15590);
         EZI.I.I(-1069278127);
         R.I(-1852134831);
         NA.I(26517601);
         DZI.F.D(-1647804880);
         HZI.Z(-962878443);
         YI.Z((byte)-41);
         XEI.qZ.Z();
         XEI.wB.Z();
         XEI.VI.Z();
         FX.j.Z();
         YT.B.Z();
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "pn.gb(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         int var3 = XEI.PD[var2].I(-574288948);
         var0.H[(var0.J += -391880689) * 681479919 - 1] = 1 == var3 ? 1 : 0;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "pn.yz(" + ')');
      }
   }
}
