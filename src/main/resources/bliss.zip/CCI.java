public abstract class CCI {
   public static KJ I;
   static KU Z;

   public abstract int method544();

   public abstract int method545();

   abstract boolean method546();

   public abstract int method547();

   abstract boolean method136();

   abstract boolean method548();

   abstract boolean method134();

   public abstract void method137();

   public abstract void method135();

   public abstract void method138();

   public abstract int method549();

   public abstract int method550();

   public abstract int method551();

   public abstract int method552();

   static final void I(OU var0, int var1) {
      try {
         var0.K -= -1365138610;
         if (var0.Q[1685767703 * var0.K] > var0.Q[1685767703 * var0.K + 1]) {
            var0.i += 286750741 * var0.X[var0.i * 1883543357];
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "cb.bb(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         String var2 = (String)var0.S[(var0.A -= 969361751) * -203050393];
         var0.S[(var0.A += 969361751) * -203050393 - 1] = TJ.I(var2, 757970283);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "cb.zc(" + ')');
      }
   }

   static KU I(int var0, byte var1) {
      try {
         if (var0 == 0) {
            if (3.0D == (double)GN.K) {
               return OT.G;
            }

            if (4.0D == (double)GN.K) {
               return CS.Z;
            }

            if (6.0D == (double)GN.K) {
               return Z;
            }

            if ((double)GN.K >= 8.0D) {
               return DV.I;
            }
         } else if (1 == var0) {
            if (3.0D == (double)GN.K) {
               return Z;
            }

            if (4.0D == (double)GN.K) {
               return DV.I;
            }

            if ((double)GN.K == 6.0D) {
               return MQ.Z;
            }

            if ((double)GN.K >= 8.0D) {
               return MU.C;
            }
         } else if (2 == var0) {
            if (3.0D == (double)GN.K) {
               return MQ.Z;
            }

            if ((double)GN.K == 4.0D) {
               return MU.C;
            }

            if (6.0D == (double)GN.K) {
               return ZC.I;
            }

            if ((double)GN.K >= 8.0D) {
               return EJ.C;
            }
         }

         return null;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "cb.bt(" + ')');
      }
   }

   public static String I(byte[] var0, int var1, int var2, int var3) {
      try {
         char[] var4 = new char[var2];
         int var5 = 0;

         for(int var6 = 0; var6 < var2; ++var6) {
            int var7 = var0[var6 + var1] & 255;
            if (var7 == 0) {
               if (var3 == 1825442367) {
                  throw new IllegalStateException();
               }
            } else {
               if (var7 >= 128 && var7 < 160) {
                  char var8 = EV.I[var7 - 128];
                  if (var8 == 0) {
                     var8 = '?';
                  }

                  var7 = var8;
               }

               var4[var5++] = (char)var7;
            }
         }

         return new String(var4, 0, var5);
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "cb.u(" + ')');
      }
   }
}
