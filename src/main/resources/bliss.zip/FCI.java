public class FCI {
   static IY I = new IY();
   static OS Z;
   static GSI C;

   FCI() throws Throwable {
      throw new Error();
   }

   static int I(int var0) {
      try {
         int var1 = EFI.C.Q * -861845079;
         if (var1 < VF.Z.length - 1) {
            EFI.C = VF.Z[var1 + 1];
         }

         return 100;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "w.k(" + ')');
      }
   }

   public static NA[] I(byte var0) {
      try {
         return new NA[]{NA.I, NA.B, NA.Z, NA.D};
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "w.a(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, int var3) {
      try {
         var0.KI = -590899066;
         var0.VC = null;
         var0.f = var2.H[(var2.J -= -391880689) * 681479919] * -1825442367;
         if (-1 == -1309843523 * var0.a && !var1.I) {
            LV.Z(-440872681 * var0.V, 1613777968);
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "w.hw(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         if (XEI.R) {
            VD.I.Z(-1732158505);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "w.anx(" + ')');
      }
   }

   public static ZQ Z(byte var0) {
      try {
         return PF.I(1606920449 * VY.E.B, (byte)52);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "w.d(" + ')');
      }
   }
}
