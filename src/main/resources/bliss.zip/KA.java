import jaggl.OpenGL;

public class KA {
   int glCallList;

   void I() {
      OpenGL.glEndList();
   }

   void I(char var1) {
      OpenGL.glCallList(this.glCallList + var1);
   }

   void I(int var1) {
      OpenGL.glNewList(this.glCallList + var1, 4864);
   }

   KA(MJI var1, int var2) {
      this.glCallList = OpenGL.glGenLists(var2);
   }
}
