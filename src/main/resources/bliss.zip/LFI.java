public final class LFI {
   static long I;
   static long Z;
   static HSI[] C;
   static String B;

   LFI() throws Throwable {
      throw new Error();
   }

   static final void I(OU var0, byte var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         DS.I(var3, var4, var0, -1057885619);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "dj.on(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var0.R.I * -2079715533;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "dj.xz(" + ')');
      }
   }

   public static void I(int var0, int var1) {
      try {
         GN.l = -2138103821;
         GN.g = var0 * 1998014133;
         JZ.t = -189172599;
         QFI.D = -338630500;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "dj.cg(" + ')');
      }
   }
}
