import jaggl.OpenGL;

public class AO extends SN {
   int A;
   int E;
   int G;

   AO(MJI var1, YCI var2, SDI var3, int var4, int var5, int var6) {
      super(var1, 32879, var2, var3, var4 * var5 * var6, false);
      this.E = var4;
      this.G = var5;
      this.A = var6;
      this.J.I((SN)this);
      OpenGL.glTexImage3Dub(this.I, 0, MJI.I(this.C, this.B), this.E, this.G, this.A, 0, MJI.I(this.C), 5121, (byte[])null, 0);
      this.I(true);
   }

   void I(int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      this.J.I((SN)this);
      OpenGL.glCopyTexSubImage3D(this.I, 0, var1, var2, var3, var6, var7, var4, var5);
      OpenGL.glFlush();
   }

   AO(MJI var1, YCI var2, SDI var3, int var4, int var5, int var6, byte[] var7, YCI var8) {
      super(var1, 32879, var2, var3, var4 * var5 * var6, false);
      this.E = var4;
      this.G = var5;
      this.A = var6;
      this.J.I((SN)this);
      OpenGL.glPixelStorei(3317, 1);
      OpenGL.glTexImage3Dub(this.I, 0, MJI.I(this.C, this.B), this.E, this.G, this.A, 0, MJI.I(var8), 5121, var7, 0);
      OpenGL.glPixelStorei(3317, 4);
      this.I(true);
   }
}
