public class FY {
   public AE I = new AE();
   AE Z;

   public AE I(int var1) {
      try {
         AE var2 = this.I.C;
         if (var2 == this.I) {
            this.Z = null;
            return null;
         } else {
            this.Z = var2.C;
            return var2;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sw.d(" + ')');
      }
   }

   public void I(AE var1, int var2) {
      try {
         if (var1.C != null) {
            var1.I(-1460969981);
         }

         var1.C = this.I;
         var1.I = this.I.I;
         var1.C.I = var1;
         var1.I.C = var1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "sw.b(" + ')');
      }
   }

   public AE I(byte var1) {
      try {
         AE var2 = this.Z;
         if (this.I == var2) {
            this.Z = null;
            return null;
         } else {
            this.Z = var2.C;
            return var2;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sw.x(" + ')');
      }
   }

   public AE Z(int var1) {
      try {
         AE var2 = this.I.I;
         if (var2 == this.I) {
            this.Z = null;
            return null;
         } else {
            this.Z = var2.I;
            return var2;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sw.k(" + ')');
      }
   }

   public void Z(AE var1, int var2) {
      try {
         if (var1.C != null) {
            var1.I(-1460969981);
         }

         var1.C = this.I.C;
         var1.I = this.I;
         var1.C.I = var1;
         var1.I.C = var1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "sw.f(" + ')');
      }
   }

   public AE Z(byte var1) {
      try {
         AE var2 = this.Z;
         if (var2 == this.I) {
            this.Z = null;
            return null;
         } else {
            this.Z = var2.I;
            return var2;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sw.u(" + ')');
      }
   }

   public boolean C(byte var1) {
      try {
         return this.I.I == this.I;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sw.r(" + ')');
      }
   }

   public AE C(int var1) {
      try {
         AE var2 = this.I.I;
         if (this.I == var2) {
            return null;
         } else {
            var2.I(-1460969981);
            return var2;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sw.i(" + ')');
      }
   }

   public void B(int var1) {
      try {
         while(true) {
            AE var2 = this.I.I;
            if (this.I == var2) {
               if (var1 < -824427525) {
                  this.Z = null;
                  return;
               }

               return;
            }

            var2.I(-1460969981);
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sw.a(" + ')');
      }
   }

   public FY() {
      this.I.I = this.I;
      this.I.C = this.I;
   }

   public static void I(QK var0, QK var1, int var2) {
      try {
         if (var0.J != null) {
            var0.C(-881477192);
         }

         var0.J = var1;
         var0.S = var1.S;
         var0.J.S = var0;
         var0.S.J = var0;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "sw.p(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         if (ET.D != null) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 1;
            var0.D = ET.D;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sw.xx(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         boolean var2 = true;
         if (XEI.R) {
            try {
               Object var3 = VD.S.C(-1654113322);
               if (var3 != null) {
                  var2 = ((Boolean)var3).booleanValue();
               }
            } catch (Throwable var4) {
               ;
            }
         }

         var0.H[(var0.J += -391880689) * 681479919 - 1] = var2 ? 1 : 0;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "sw.ank(" + ')');
      }
   }

   static final void C(OU var0, byte var1) {
      try {
         String var2 = (String)var0.S[(var0.A -= 969361751) * -203050393];
         PK var3 = GB.I(MEI.v, XEI.eI.Z, (byte)19);
         var3.J.F(var2.length() + 1);
         var3.J.I(var2, 2140741369);
         XEI.eI.I(var3, (byte)-70);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "sw.sf(" + ')');
      }
   }
}
