public class JA implements BAI {
   static JA I = new JA(3, 1);
   public static JA Z = new JA(2, 4);
   static JA C = new JA(4, 7);
   static JA B = new JA(0, 3);
   public int D;
   static JA F = new JA(5, 5);
   static JA J = new JA(1, 6);
   static JA S = new JA(7, 0);
   static JA A = new JA(6, 2);
   int append;
   static IBI E;

   public int method244() {
      return 1575163887 * this.append;
   }

   public JA I(byte var1) {
      try {
         switch(this.D * 495490839) {
         case 0:
            return C;
         case 1:
            return A;
         case 2:
            return S;
         case 3:
            return F;
         case 4:
            return B;
         case 5:
            return I;
         case 6:
            return J;
         case 7:
            return Z;
         default:
            throw new IllegalStateException();
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "lj.b(" + ')');
      }
   }

   public int method242(int var1) {
      try {
         return 1575163887 * this.append;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "lj.f(" + ')');
      }
   }

   public int method243() {
      return 1575163887 * this.append;
   }

   JA(int var1, int var2) {
      this.D = var1 * 699142311;
      this.append = var2 * 1812395791;
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-68);
         X var4 = IU.F[var2 >> 16];
         ICI.I(var3, var4, var0, 783841228);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "lj.fg(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         EK.I(var3, var4, var0, -1683091614);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "lj.nk(" + ')');
      }
   }
}
