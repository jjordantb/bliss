import java.nio.ByteBuffer;
import java.util.Arrays;

public class EC implements LAI {
   public int I;
   public HZ Z;
   public int C;
   public int B;
   public IZ D;
   public static KJ F;

   public RZ method49(int var1) {
      try {
         return RZ.A;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "gl.f(" + ')');
      }
   }

   public RZ method50() {
      return RZ.A;
   }

   EC(int var1, HZ var2, IZ var3, int var4, int var5) {
      this.C = var1 * -1500420259;
      this.Z = var2;
      this.D = var3;
      this.B = var4 * -455546715;
      this.I = -463734461 * var5;
   }

   public RZ method51() {
      return RZ.A;
   }

   static final void I(HSI var0, X var1, OU var2, byte var3) {
      try {
         String var4 = (String)var2.S[(var2.A -= 969361751) * -203050393];
         if (IN.I(var4, var2, -172692776) != null) {
            var4 = var4.substring(0, var4.length() - 1);
         }

         var0.aI = OI.I(var4, var2, -2046058202);
         var0.JZ = true;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "gl.ln(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)76);
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var3.x * 1045422783;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "gl.rv(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         var0.J -= -1567522756;
         VO.I(var0.H[var0.J * 681479919], var0.H[1 + var0.J * 681479919], var0.H[681479919 * var0.J + 2], var0.H[3 + 681479919 * var0.J], true, 256, 1228357249);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "gl.tk(" + ')');
      }
   }

   public static Object I(byte[] var0, boolean var1, short var2) {
      try {
         if (var0 == null) {
            return null;
         } else if (var0.length > 136) {
            ByteBuffer var3 = ByteBuffer.allocateDirect(var0.length);
            var3.position(0);
            var3.put(var0);
            return var3;
         } else {
            return var1 ? Arrays.copyOf(var0, var0.length) : var0;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "gl.a(" + ')');
      }
   }
}
