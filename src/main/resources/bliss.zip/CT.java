public class CT extends YR {
   static int S = 4096;
   static int append = 12;

   CT() throws Throwable {
      throw new Error();
   }

   static final void Z(OU var0, int var1) {
      try {
         var0.J -= -1567522756;
         XEI.wC = (short)var0.H[681479919 * var0.J];
         if (XEI.wC <= 0) {
            XEI.wC = 1;
         }

         XEI.EZ = (short)var0.H[1 + 681479919 * var0.J];
         if (XEI.EZ <= 0) {
            XEI.EZ = 32767;
         } else if (XEI.EZ < XEI.wC) {
            XEI.EZ = XEI.wC;
         }

         XEI.fD = (short)var0.H[681479919 * var0.J + 2];
         if (XEI.fD <= 0) {
            XEI.fD = 1;
         }

         XEI.jD = (short)var0.H[3 + 681479919 * var0.J];
         if (XEI.jD <= 0) {
            XEI.jD = 32767;
         } else if (XEI.jD < XEI.fD) {
            XEI.jD = XEI.fD;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "adr.aki(" + ')');
      }
   }
}
