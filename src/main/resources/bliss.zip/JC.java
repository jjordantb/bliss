public class JC {
   static JC I;
   public static JC Z;
   public static JC C;
   public static JC B;
   public static JC D;
   public static JC F;
   public static JC J;
   static JC S;
   static JC A;
   public int E;
   SDI G;
   static JC H;
   int K;
   static int L = 16;
   static int M;
   public static JC N;
   public int O;
   int P;
   static JC Q;

   static {
      N = new JC(0, 0, 3, SDI.F);
      Z = new JC(11, 1, 3, SDI.F);
      C = new JC(3, 2, 4, SDI.C);
      J = new JC(9, 3, 1, SDI.F);
      D = new JC(10, 4, 2, SDI.F);
      F = new JC(5, 5, 3, SDI.F);
      B = new JC(8, 6, 4, SDI.F);
      S = new JC(6, 7, 4, SDI.F);
      Q = new JC(1, 8, 4, SDI.F);
      I = new JC(4, 9, 4, SDI.F);
      A = new JC(7, 10, 3, SDI.F);
      H = new JC(2, 11, 3, SDI.F);
      M = PFI.I(16, 1046709218);
   }

   JC(int var1, int var2, int var3, SDI var4) {
      this.E = var1;
      this.K = var2;
      this.P = var3;
      this.G = var4;
      this.O = this.P * this.G.S * 685647847;
      if (this.K >= 16) {
         throw new RuntimeException();
      }
   }

   static JC I(int var0) {
      switch(var0) {
      case 0:
         return N;
      case 1:
         return Z;
      case 2:
         return C;
      case 3:
         return J;
      case 4:
         return D;
      case 5:
         return F;
      case 6:
         return B;
      default:
         return null;
      }
   }
}
