public class GI extends EI {
   IBI method271;
   IBI method52;
   IBI method53;
   IBI D;
   IBI method623;
   IBI method626;

   public boolean method54() {
      if (!super.method52(-471154250)) {
         return false;
      } else {
         PI var1 = (PI)this.C;
         if (!this.I.D(var1.K * -876812375, -457216440)) {
            return false;
         } else if (!this.I.D(1551490597 * var1.H, -457216440)) {
            return false;
         } else if (!this.I.D(578265259 * var1.N, -457216440)) {
            return false;
         } else if (!this.I.D(var1.L * 861652881, -457216440)) {
            return false;
         } else if (!this.I.D(var1.M * -1259370861, -457216440)) {
            return false;
         } else {
            return this.I.D(var1.G * 356687159, -457216440);
         }
      }
   }

   void method1409(boolean var1, int var2, int var3) {
      if (var1) {
         int[] var4 = new int[4];
         FT.P.qa(var4);
         FT.P.r(var2, var3, this.C.D * -944287579 + var2, this.C.A * -1387457793 + var3);
         int var5 = this.method53.method271();
         int var6 = this.method53.method626();
         int var7 = this.method52.method271();
         int var8 = this.method52.method626();
         this.method53.I(var2, (this.C.A * -1387457793 - var6) / 2 + var3);
         this.method52.I(var2 + this.C.D * -944287579 - var7, (-1387457793 * this.C.A - var8) / 2 + var3);
         FT.P.r(var2, var3, -944287579 * this.C.D + var2, var3 + this.method623.method626());
         this.method623.Z(var5 + var2, var3, this.C.D * -944287579 - var5 - var7, this.C.A * -1387457793);
         int var9 = this.method626.method626();
         FT.P.r(var2, this.C.A * -1387457793 + var3 - var9, var2 + -944287579 * this.C.D, var3 + this.C.A * -1387457793);
         this.method626.Z(var5 + var2, var3 + this.C.A * -1387457793 - var9, this.C.D * -944287579 - var5 - var7, this.C.A * -1387457793);
         FT.P.r(var4[0], var4[1], var4[2], var4[3]);
      }

   }

   void method1412(boolean var1, int var2, int var3, int var4) {
      try {
         if (var1) {
            int[] var5 = new int[4];
            FT.P.qa(var5);
            FT.P.r(var2, var3, this.C.D * -944287579 + var2, this.C.A * -1387457793 + var3);
            int var6 = this.method53.method271();
            int var7 = this.method53.method626();
            int var8 = this.method52.method271();
            int var9 = this.method52.method626();
            this.method53.I(var2, (this.C.A * -1387457793 - var7) / 2 + var3);
            this.method52.I(var2 + this.C.D * -944287579 - var8, (-1387457793 * this.C.A - var9) / 2 + var3);
            FT.P.r(var2, var3, -944287579 * this.C.D + var2, var3 + this.method623.method626());
            this.method623.Z(var6 + var2, var3, this.C.D * -944287579 - var6 - var8, this.C.A * -1387457793);
            int var10 = this.method626.method626();
            FT.P.r(var2, this.C.A * -1387457793 + var3 - var10, var2 + -944287579 * this.C.D, var3 + this.C.A * -1387457793);
            this.method626.Z(var6 + var2, var3 + this.C.A * -1387457793 - var10, this.C.D * -944287579 - var6 - var8, this.C.A * -1387457793);
            FT.P.r(var5[0], var5[1], var5[2], var5[3]);
         }

      } catch (RuntimeException var11) {
         throw DQ.I(var11, "zb.x(" + ')');
      }
   }

   void method1413(boolean var1, int var2, int var3) {
      int var4 = var2 + this.method53.method271();
      int var5 = -944287579 * this.C.D + var2 - this.method52.method271();
      int var6 = var3 + this.method623.method626();
      int var7 = this.C.A * -1387457793 + var3 - this.method626.method626();
      int var8 = var5 - var4;
      int var9 = var7 - var6;
      int var10 = this.I(652896143) * var8 / 10000;
      int[] var11 = new int[4];
      FT.P.qa(var11);
      FT.P.r(var4, var6, var4 + var10, var7);
      this.I(var4, var6, var8, var9, 1789961003);
      FT.P.r(var10 + var4, var6, var5, var7);
      this.method271.Z(var4, var6, var8, var9);
      FT.P.r(var11[0], var11[1], var11[2], var11[3]);
   }

   void I(int var1, int var2, int var3, int var4, int var5) {
      try {
         this.D.Z(var1, var2, var3, var4);
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "zb.c(" + ')');
      }
   }

   public boolean method52(int var1) {
      try {
         if (!super.method52(-571978774)) {
            return false;
         } else {
            PI var2 = (PI)this.C;
            if (!this.I.D(var2.K * -876812375, -457216440)) {
               return false;
            } else if (!this.I.D(1551490597 * var2.H, -457216440)) {
               return false;
            } else if (!this.I.D(578265259 * var2.N, -457216440)) {
               return false;
            } else if (!this.I.D(var2.L * 861652881, -457216440)) {
               return false;
            } else if (!this.I.D(var2.M * -1259370861, -457216440)) {
               return false;
            } else {
               return this.I.D(var2.G * 356687159, -457216440);
            }
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "zb.b(" + ')');
      }
   }

   public void method55() {
      super.method53(-1049861204);
      PI var1 = (PI)this.C;
      this.D = NV.I(this.I, var1.K * -876812375, (byte)-20);
      this.method271 = NV.I(this.I, var1.H * 1551490597, (byte)-36);
      this.method53 = NV.I(this.I, 578265259 * var1.N, (byte)-107);
      this.method52 = NV.I(this.I, 861652881 * var1.L, (byte)-11);
      this.method623 = NV.I(this.I, -1259370861 * var1.M, (byte)-42);
      this.method626 = NV.I(this.I, 356687159 * var1.G, (byte)-75);
   }

   public boolean method57() {
      if (!super.method52(-1053320809)) {
         return false;
      } else {
         PI var1 = (PI)this.C;
         if (!this.I.D(var1.K * -876812375, -457216440)) {
            return false;
         } else if (!this.I.D(1551490597 * var1.H, -457216440)) {
            return false;
         } else if (!this.I.D(578265259 * var1.N, -457216440)) {
            return false;
         } else if (!this.I.D(var1.L * 861652881, -457216440)) {
            return false;
         } else if (!this.I.D(var1.M * -1259370861, -457216440)) {
            return false;
         } else {
            return this.I.D(var1.G * 356687159, -457216440);
         }
      }
   }

   public boolean method59() {
      if (!super.method52(-1356653583)) {
         return false;
      } else {
         PI var1 = (PI)this.C;
         if (!this.I.D(var1.K * -876812375, -457216440)) {
            return false;
         } else if (!this.I.D(1551490597 * var1.H, -457216440)) {
            return false;
         } else if (!this.I.D(578265259 * var1.N, -457216440)) {
            return false;
         } else if (!this.I.D(var1.L * 861652881, -457216440)) {
            return false;
         } else if (!this.I.D(var1.M * -1259370861, -457216440)) {
            return false;
         } else {
            return this.I.D(var1.G * 356687159, -457216440);
         }
      }
   }

   void method1417(boolean var1, int var2, int var3) {
      if (var1) {
         int[] var4 = new int[4];
         FT.P.qa(var4);
         FT.P.r(var2, var3, this.C.D * -944287579 + var2, this.C.A * -1387457793 + var3);
         int var5 = this.method53.method271();
         int var6 = this.method53.method626();
         int var7 = this.method52.method271();
         int var8 = this.method52.method626();
         this.method53.I(var2, (this.C.A * -1387457793 - var6) / 2 + var3);
         this.method52.I(var2 + this.C.D * -944287579 - var7, (-1387457793 * this.C.A - var8) / 2 + var3);
         FT.P.r(var2, var3, -944287579 * this.C.D + var2, var3 + this.method623.method626());
         this.method623.Z(var5 + var2, var3, this.C.D * -944287579 - var5 - var7, this.C.A * -1387457793);
         int var9 = this.method626.method626();
         FT.P.r(var2, this.C.A * -1387457793 + var3 - var9, var2 + -944287579 * this.C.D, var3 + this.C.A * -1387457793);
         this.method626.Z(var5 + var2, var3 + this.C.A * -1387457793 - var9, this.C.D * -944287579 - var5 - var7, this.C.A * -1387457793);
         FT.P.r(var4[0], var4[1], var4[2], var4[3]);
      }

   }

   void method1411(boolean var1, int var2, int var3, int var4) {
      try {
         int var5 = var2 + this.method53.method271();
         int var6 = -944287579 * this.C.D + var2 - this.method52.method271();
         int var7 = var3 + this.method623.method626();
         int var8 = this.C.A * -1387457793 + var3 - this.method626.method626();
         int var9 = var6 - var5;
         int var10 = var8 - var7;
         int var11 = this.I(1969642247) * var9 / 10000;
         int[] var12 = new int[4];
         FT.P.qa(var12);
         FT.P.r(var5, var7, var5 + var11, var8);
         this.I(var5, var7, var9, var10, -1231781770);
         FT.P.r(var11 + var5, var7, var6, var8);
         this.method271.Z(var5, var7, var9, var10);
         FT.P.r(var12[0], var12[1], var12[2], var12[3]);
      } catch (RuntimeException var13) {
         throw DQ.I(var13, "zb.r(" + ')');
      }
   }

   void method1414(boolean var1, int var2, int var3) {
      int var4 = var2 + this.method53.method271();
      int var5 = -944287579 * this.C.D + var2 - this.method52.method271();
      int var6 = var3 + this.method623.method626();
      int var7 = this.C.A * -1387457793 + var3 - this.method626.method626();
      int var8 = var5 - var4;
      int var9 = var7 - var6;
      int var10 = this.I(-573228636) * var8 / 10000;
      int[] var11 = new int[4];
      FT.P.qa(var11);
      FT.P.r(var4, var6, var4 + var10, var7);
      this.I(var4, var6, var8, var9, -672953345);
      FT.P.r(var10 + var4, var6, var5, var7);
      this.method271.Z(var4, var6, var8, var9);
      FT.P.r(var11[0], var11[1], var11[2], var11[3]);
   }

   void method1415(boolean var1, int var2, int var3) {
      int var4 = var2 + this.method53.method271();
      int var5 = -944287579 * this.C.D + var2 - this.method52.method271();
      int var6 = var3 + this.method623.method626();
      int var7 = this.C.A * -1387457793 + var3 - this.method626.method626();
      int var8 = var5 - var4;
      int var9 = var7 - var6;
      int var10 = this.I(898782840) * var8 / 10000;
      int[] var11 = new int[4];
      FT.P.qa(var11);
      FT.P.r(var4, var6, var4 + var10, var7);
      this.I(var4, var6, var8, var9, 2053935529);
      FT.P.r(var10 + var4, var6, var5, var7);
      this.method271.Z(var4, var6, var8, var9);
      FT.P.r(var11[0], var11[1], var11[2], var11[3]);
   }

   void method1416(boolean var1, int var2, int var3) {
      int var4 = var2 + this.method53.method271();
      int var5 = -944287579 * this.C.D + var2 - this.method52.method271();
      int var6 = var3 + this.method623.method626();
      int var7 = this.C.A * -1387457793 + var3 - this.method626.method626();
      int var8 = var5 - var4;
      int var9 = var7 - var6;
      int var10 = this.I(2121135602) * var8 / 10000;
      int[] var11 = new int[4];
      FT.P.qa(var11);
      FT.P.r(var4, var6, var4 + var10, var7);
      this.I(var4, var6, var8, var9, 1166821857);
      FT.P.r(var10 + var4, var6, var5, var7);
      this.method271.Z(var4, var6, var8, var9);
      FT.P.r(var11[0], var11[1], var11[2], var11[3]);
   }

   void method1410(boolean var1, int var2, int var3) {
      if (var1) {
         int[] var4 = new int[4];
         FT.P.qa(var4);
         FT.P.r(var2, var3, this.C.D * -944287579 + var2, this.C.A * -1387457793 + var3);
         int var5 = this.method53.method271();
         int var6 = this.method53.method626();
         int var7 = this.method52.method271();
         int var8 = this.method52.method626();
         this.method53.I(var2, (this.C.A * -1387457793 - var6) / 2 + var3);
         this.method52.I(var2 + this.C.D * -944287579 - var7, (-1387457793 * this.C.A - var8) / 2 + var3);
         FT.P.r(var2, var3, -944287579 * this.C.D + var2, var3 + this.method623.method626());
         this.method623.Z(var5 + var2, var3, this.C.D * -944287579 - var5 - var7, this.C.A * -1387457793);
         int var9 = this.method626.method626();
         FT.P.r(var2, this.C.A * -1387457793 + var3 - var9, var2 + -944287579 * this.C.D, var3 + this.C.A * -1387457793);
         this.method626.Z(var5 + var2, var3 + this.C.A * -1387457793 - var9, this.C.D * -944287579 - var5 - var7, this.C.A * -1387457793);
         FT.P.r(var4[0], var4[1], var4[2], var4[3]);
      }

   }

   GI(KJ var1, KJ var2, PI var3) {
      super(var1, var2, var3);
   }

   public void method53(int var1) {
      try {
         super.method53(215816169);
         PI var2 = (PI)this.C;
         this.D = NV.I(this.I, var2.K * -876812375, (byte)53);
         this.method271 = NV.I(this.I, var2.H * 1551490597, (byte)-54);
         this.method53 = NV.I(this.I, 578265259 * var2.N, (byte)-41);
         this.method52 = NV.I(this.I, 861652881 * var2.L, (byte)-125);
         this.method623 = NV.I(this.I, -1259370861 * var2.M, (byte)95);
         this.method626 = NV.I(this.I, 356687159 * var2.G, (byte)-11);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "zb.a(" + ')');
      }
   }

   static int I(YK var0, LZI var1, int var2) {
      try {
         String var3 = GDI.I(var0, 2106133220);
         int[] var4 = LO.I(var0, (byte)-16);
         if (var4 != null) {
            var3 = var3 + JF.I((int[])var4, (byte)1);
         }

         int var5 = var1.I((String)var3, (GAI[])FX.s, (int)1319235613);
         if (var0.Q) {
            var5 += ESI.F.method623() + 4;
         }

         return var5;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "zb.bm(" + ')');
      }
   }

   public static String I(REI var0, int var1) {
      try {
         return FX.I(var0, 32767, 116620582);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "zb.b(" + ')');
      }
   }

   static void Z(int var0) {
      try {
         GN.o.I((byte)-14);
         GN.p.I((byte)-2);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "zb.bp(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         var0.J -= -783761378;
         int var2 = var0.H[681479919 * var0.J];
         int var3 = var0.H[681479919 * var0.J + 1];
         Q.I(var2, new OSI(var3, 3), (int[])null, true, -1040917955);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "zb.sp(" + ')');
      }
   }
}
