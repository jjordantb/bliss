public class BX {
   public int I;
   public int Z;
   public int C;

   void Z(REI var1, int var2, int var3) {
      try {
         if (var2 == 1) {
            this.Z = var1.C() * -361098111;
            this.C = var1.I() * 709302387;
            this.I = var1.I() * 1322614137;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ry.f(" + ')');
      }
   }

   void I(REI var1, int var2) {
      try {
         while(true) {
            int var3 = var1.I();
            if (var3 == 0) {
               if (var2 > 1941304655) {
                  ;
               }

               return;
            }

            this.Z(var1, var3, 33985);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ry.a(" + ')');
      }
   }

   static boolean I(int var0) {
      try {
         return YII.I(PZ.B.J, 1089632340);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "ry.b(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         CU var3;
         if (var0.c) {
            var3 = var0.M;
         } else {
            var3 = var0.L;
         }

         var0.H[(var0.J += -391880689) * 681479919 - 1] = var3.I(var2, -1, -574024132) ? 1 : 0;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ry.bz(" + ')');
      }
   }
}
