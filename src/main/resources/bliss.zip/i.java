public class i extends YJI implements SAI {
   ja aJa6678;
   long nativeid;
   IY aClass453_6679 = new IY();

   i(ja var1, ba var2, int var3, int var4, int[][] var5, int[][] var6, int var7, int var8, int var9) {
      super(var3, var4, var7, var5);
      this.aJa6678 = var1;
      this.G(this.aJa6678, var2, var3, var4, this.D, var6, var7, var8, var9);
   }

   public final void method6359(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, ADI var11, boolean var12) {
      this.ya(var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11.Z * -1212608691, var11.I * 1996750669, var11.C * -1475891183, var12);
   }

   native void ay(int var1, int var2, int var3, int var4, int var5, int var6, int[] var7);

   public native void ma(boolean var1);

   public native void LA(int var1, int var2, int var3);

   public native void SA();

   native void ya(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, int var11, int var12, int var13, boolean var14);

   native void ab(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, int var11, int var12, int var13, boolean var14);

   public void method6336(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, int[] var11, int[] var12, int[] var13, ADI var14, boolean var15) {
      boolean var16 = false;
      if (var10 != null) {
         int[] var17 = var10;

         for(int var18 = 0; var18 < var17.length; ++var18) {
            int var19 = var17[var18];
            if (var19 != -1) {
               var16 = true;
               break;
            }
         }
      }

      int var31 = var10.length;
      int[] var32 = new int[var31 * 3];
      int[] var33 = new int[var31 * 3];
      int[] var20 = new int[var31 * 3];
      int[] var21 = new int[var31 * 3];
      int[] var22 = new int[var31 * 3];
      int[] var23 = var11 != null ? new int[var31 * 3] : null;
      int[] var24 = var4 != null ? new int[var31 * 3] : null;
      int[] var25 = var6 != null ? new int[var31 * 3] : null;
      int var26 = 0;

      for(int var27 = 0; var27 < var31; ++var27) {
         int var28 = var7[var27];
         int var29 = var8[var27];
         int var30 = var9[var27];
         var32[var26] = var3[var28];
         var33[var26] = var5[var28];
         var20[var26] = var10[var27];
         var21[var26] = var12[var27];
         var22[var26] = var13[var27];
         if (var11 != null) {
            var23[var26] = var11[var27];
         }

         if (var4 != null) {
            var24[var26] = var4[var28];
         }

         if (var6 != null) {
            var25[var26] = var6[var28];
         }

         ++var26;
         var32[var26] = var3[var29];
         var33[var26] = var5[var29];
         var20[var26] = var10[var27];
         var21[var26] = var12[var27];
         var22[var26] = var13[var27];
         if (var11 != null) {
            var23[var26] = var11[var27];
         }

         if (var4 != null) {
            var24[var26] = var4[var29];
         }

         if (var6 != null) {
            var25[var26] = var6[var29];
         }

         ++var26;
         var32[var26] = var3[var30];
         var33[var26] = var5[var30];
         var20[var26] = var10[var27];
         var21[var26] = var12[var27];
         var22[var26] = var13[var27];
         if (var11 != null) {
            var23[var26] = var11[var27];
         }

         if (var4 != null) {
            var24[var26] = var4[var30];
         }

         if (var6 != null) {
            var25[var26] = var6[var30];
         }

         ++var26;
      }

      if (var16 || var23 != null) {
         this.ya(var1, var2, var32, var24, var33, var25, var20, var23, var21, var22, var14.Z * -1212608691, var14.I * 1996750669, var14.C * -1475891183, var15);
      }

   }

   public void method6338(int var1, int var2, int var3, boolean[][] var4, boolean var5, int var6) {
      int var7 = 0;
      float[] var8 = new float[this.aClass453_6679.J(1828905535)];

      for(GE var9 = (GE)this.aClass453_6679.Z(1766612795); var9 != null; var9 = (GE)this.aClass453_6679.B(49146)) {
         var8[var7++] = var9.J(608404512);
      }

      this.t(var8);

      for(int var13 = 0; var13 < var3 + var3; ++var13) {
         for(int var10 = 0; var10 < var3 + var3; ++var10) {
            if (var4[var13][var10]) {
               int var11 = var1 - var3 + var13;
               int var12 = var2 - var3 + var10;
               if (var11 >= 0 && var11 < this.Z * -506105871 && var12 >= 0 && var12 < this.I * -1148794921) {
                  this.aJa6678.method5571().method281(this, var11, var12);
               }
            }
         }
      }

   }

   public void method6339(int var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean[][] var8) {
      this.aJa6678.method5571().method282(this, var1, var2, var3, var4, var5, var6, var7, var8);
   }

   public native GJI w(int var1, int var2, GJI var3);

   public native void UA(GJI var1, int var2, int var3, int var4, int var5, boolean var6);

   public void method6349(int var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean[][] var8) {
      this.aJa6678.method5571().method282(this, var1, var2, var3, var4, var5, var6, var7, var8);
   }

   public boolean method6353(GJI var1, int var2, int var3, int var4, int var5, boolean var6) {
      return true;
   }

   public void method6342(GE var1, int[] var2) {
      this.aClass453_6679.I((AE)var1, (int)1770032903);
      this.A(var1.hashCode(), var1.B(823958259), var1.C(-2119819308), var1.I((byte)45), var1.F(-672312292), var1.D(-2045432623), var2);
   }

   native void A(int var1, int var2, int var3, int var4, int var5, int var6, int[] var7);

   native void t(float[] var1);

   public final void method6346(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, ADI var11, boolean var12) {
      this.ya(var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11.Z * -1212608691, var11.I * 1996750669, var11.C * -1475891183, var12);
   }

   public native void z(boolean var1);

   public native void ak(GJI var1, int var2, int var3, int var4, int var5, boolean var6);

   public final void method6335(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, ADI var11, boolean var12) {
      this.ya(var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11.Z * -1212608691, var11.I * 1996750669, var11.C * -1475891183, var12);
   }

   native void an(float[] var1);

   public final void method6345(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, ADI var11, boolean var12) {
      this.ya(var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11.Z * -1212608691, var11.I * 1996750669, var11.C * -1475891183, var12);
   }

   public native void h();

   public void method6357(int var1, int var2, int var3, boolean[][] var4, boolean var5, int var6) {
      int var7 = 0;
      float[] var8 = new float[this.aClass453_6679.J(1828905535)];

      for(GE var9 = (GE)this.aClass453_6679.Z(1766612795); var9 != null; var9 = (GE)this.aClass453_6679.B(49146)) {
         var8[var7++] = var9.J(608404512);
      }

      this.t(var8);

      for(int var13 = 0; var13 < var3 + var3; ++var13) {
         for(int var10 = 0; var10 < var3 + var3; ++var10) {
            if (var4[var13][var10]) {
               int var11 = var1 - var3 + var13;
               int var12 = var2 - var3 + var10;
               if (var11 >= 0 && var11 < this.Z * -506105871 && var12 >= 0 && var12 < this.I * -1148794921) {
                  this.aJa6678.method5571().method281(this, var11, var12);
               }
            }
         }
      }

   }

   public void method6348(int var1, int var2, int var3, boolean[][] var4, boolean var5, int var6) {
      int var7 = 0;
      float[] var8 = new float[this.aClass453_6679.J(1828905535)];

      for(GE var9 = (GE)this.aClass453_6679.Z(1766612795); var9 != null; var9 = (GE)this.aClass453_6679.B(49146)) {
         var8[var7++] = var9.J(608404512);
      }

      this.t(var8);

      for(int var13 = 0; var13 < var3 + var3; ++var13) {
         for(int var10 = 0; var10 < var3 + var3; ++var10) {
            if (var4[var13][var10]) {
               int var11 = var1 - var3 + var13;
               int var12 = var2 - var3 + var10;
               if (var11 >= 0 && var11 < this.Z * -506105871 && var12 >= 0 && var12 < this.I * -1148794921) {
                  this.aJa6678.method5571().method281(this, var11, var12);
               }
            }
         }
      }

   }

   public void method6337(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, int[] var11, int[] var12, int[] var13, ADI var14, boolean var15) {
      boolean var16 = false;
      if (var10 != null) {
         int[] var17 = var10;

         for(int var18 = 0; var18 < var17.length; ++var18) {
            int var19 = var17[var18];
            if (var19 != -1) {
               var16 = true;
               break;
            }
         }
      }

      int var31 = var10.length;
      int[] var32 = new int[var31 * 3];
      int[] var33 = new int[var31 * 3];
      int[] var20 = new int[var31 * 3];
      int[] var21 = new int[var31 * 3];
      int[] var22 = new int[var31 * 3];
      int[] var23 = var11 != null ? new int[var31 * 3] : null;
      int[] var24 = var4 != null ? new int[var31 * 3] : null;
      int[] var25 = var6 != null ? new int[var31 * 3] : null;
      int var26 = 0;

      for(int var27 = 0; var27 < var31; ++var27) {
         int var28 = var7[var27];
         int var29 = var8[var27];
         int var30 = var9[var27];
         var32[var26] = var3[var28];
         var33[var26] = var5[var28];
         var20[var26] = var10[var27];
         var21[var26] = var12[var27];
         var22[var26] = var13[var27];
         if (var11 != null) {
            var23[var26] = var11[var27];
         }

         if (var4 != null) {
            var24[var26] = var4[var28];
         }

         if (var6 != null) {
            var25[var26] = var6[var28];
         }

         ++var26;
         var32[var26] = var3[var29];
         var33[var26] = var5[var29];
         var20[var26] = var10[var27];
         var21[var26] = var12[var27];
         var22[var26] = var13[var27];
         if (var11 != null) {
            var23[var26] = var11[var27];
         }

         if (var4 != null) {
            var24[var26] = var4[var29];
         }

         if (var6 != null) {
            var25[var26] = var6[var29];
         }

         ++var26;
         var32[var26] = var3[var30];
         var33[var26] = var5[var30];
         var20[var26] = var10[var27];
         var21[var26] = var12[var27];
         var22[var26] = var13[var27];
         if (var11 != null) {
            var23[var26] = var11[var27];
         }

         if (var4 != null) {
            var24[var26] = var4[var30];
         }

         if (var6 != null) {
            var25[var26] = var6[var30];
         }

         ++var26;
      }

      if (var16 || var23 != null) {
         this.ya(var1, var2, var32, var24, var33, var25, var20, var23, var21, var22, var14.Z * -1212608691, var14.I * 1996750669, var14.C * -1475891183, var15);
      }

   }

   public native void ad(GJI var1, int var2, int var3, int var4, int var5, boolean var6);

   public void method6350(int var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean[][] var8) {
      this.aJa6678.method5571().method282(this, var1, var2, var3, var4, var5, var6, var7, var8);
   }

   public void method6351(int var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean[][] var8) {
      this.aJa6678.method5571().method282(this, var1, var2, var3, var4, var5, var6, var7, var8);
   }

   public void method6352(int var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean[][] var8) {
      this.aJa6678.method5571().method282(this, var1, var2, var3, var4, var5, var6, var7, var8);
   }

   public native GJI l(int var1, int var2, GJI var3);

   public native GJI ax(int var1, int var2, GJI var3);

   public native GJI aa(int var1, int var2, GJI var3);

   public void method6356(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, int[] var11, int[] var12, int[] var13, ADI var14, boolean var15) {
      boolean var16 = false;
      if (var10 != null) {
         int[] var17 = var10;

         for(int var18 = 0; var18 < var17.length; ++var18) {
            int var19 = var17[var18];
            if (var19 != -1) {
               var16 = true;
               break;
            }
         }
      }

      int var31 = var10.length;
      int[] var32 = new int[var31 * 3];
      int[] var33 = new int[var31 * 3];
      int[] var20 = new int[var31 * 3];
      int[] var21 = new int[var31 * 3];
      int[] var22 = new int[var31 * 3];
      int[] var23 = var11 != null ? new int[var31 * 3] : null;
      int[] var24 = var4 != null ? new int[var31 * 3] : null;
      int[] var25 = var6 != null ? new int[var31 * 3] : null;
      int var26 = 0;

      for(int var27 = 0; var27 < var31; ++var27) {
         int var28 = var7[var27];
         int var29 = var8[var27];
         int var30 = var9[var27];
         var32[var26] = var3[var28];
         var33[var26] = var5[var28];
         var20[var26] = var10[var27];
         var21[var26] = var12[var27];
         var22[var26] = var13[var27];
         if (var11 != null) {
            var23[var26] = var11[var27];
         }

         if (var4 != null) {
            var24[var26] = var4[var28];
         }

         if (var6 != null) {
            var25[var26] = var6[var28];
         }

         ++var26;
         var32[var26] = var3[var29];
         var33[var26] = var5[var29];
         var20[var26] = var10[var27];
         var21[var26] = var12[var27];
         var22[var26] = var13[var27];
         if (var11 != null) {
            var23[var26] = var11[var27];
         }

         if (var4 != null) {
            var24[var26] = var4[var29];
         }

         if (var6 != null) {
            var25[var26] = var6[var29];
         }

         ++var26;
         var32[var26] = var3[var30];
         var33[var26] = var5[var30];
         var20[var26] = var10[var27];
         var21[var26] = var12[var27];
         var22[var26] = var13[var27];
         if (var11 != null) {
            var23[var26] = var11[var27];
         }

         if (var4 != null) {
            var24[var26] = var4[var30];
         }

         if (var6 != null) {
            var25[var26] = var6[var30];
         }

         ++var26;
      }

      if (var16 || var23 != null) {
         this.ya(var1, var2, var32, var24, var33, var25, var20, var23, var21, var22, var14.Z * -1212608691, var14.I * 1996750669, var14.C * -1475891183, var15);
      }

   }

   public boolean method6354(GJI var1, int var2, int var3, int var4, int var5, boolean var6) {
      return true;
   }

   public native void NA(GJI var1, int var2, int var3, int var4, int var5, boolean var6);

   public boolean method6355(GJI var1, int var2, int var3, int var4, int var5, boolean var6) {
      return true;
   }

   public void method6343(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, int[] var11, int[] var12, int[] var13, ADI var14, boolean var15) {
      boolean var16 = false;
      if (var10 != null) {
         int[] var17 = var10;

         for(int var18 = 0; var18 < var17.length; ++var18) {
            int var19 = var17[var18];
            if (var19 != -1) {
               var16 = true;
               break;
            }
         }
      }

      int var31 = var10.length;
      int[] var32 = new int[var31 * 3];
      int[] var33 = new int[var31 * 3];
      int[] var20 = new int[var31 * 3];
      int[] var21 = new int[var31 * 3];
      int[] var22 = new int[var31 * 3];
      int[] var23 = var11 != null ? new int[var31 * 3] : null;
      int[] var24 = var4 != null ? new int[var31 * 3] : null;
      int[] var25 = var6 != null ? new int[var31 * 3] : null;
      int var26 = 0;

      for(int var27 = 0; var27 < var31; ++var27) {
         int var28 = var7[var27];
         int var29 = var8[var27];
         int var30 = var9[var27];
         var32[var26] = var3[var28];
         var33[var26] = var5[var28];
         var20[var26] = var10[var27];
         var21[var26] = var12[var27];
         var22[var26] = var13[var27];
         if (var11 != null) {
            var23[var26] = var11[var27];
         }

         if (var4 != null) {
            var24[var26] = var4[var28];
         }

         if (var6 != null) {
            var25[var26] = var6[var28];
         }

         ++var26;
         var32[var26] = var3[var29];
         var33[var26] = var5[var29];
         var20[var26] = var10[var27];
         var21[var26] = var12[var27];
         var22[var26] = var13[var27];
         if (var11 != null) {
            var23[var26] = var11[var27];
         }

         if (var4 != null) {
            var24[var26] = var4[var29];
         }

         if (var6 != null) {
            var25[var26] = var6[var29];
         }

         ++var26;
         var32[var26] = var3[var30];
         var33[var26] = var5[var30];
         var20[var26] = var10[var27];
         var21[var26] = var12[var27];
         var22[var26] = var13[var27];
         if (var11 != null) {
            var23[var26] = var11[var27];
         }

         if (var4 != null) {
            var24[var26] = var4[var30];
         }

         if (var6 != null) {
            var25[var26] = var6[var30];
         }

         ++var26;
      }

      if (var16 || var23 != null) {
         this.ya(var1, var2, var32, var24, var33, var25, var20, var23, var21, var22, var14.Z * -1212608691, var14.I * 1996750669, var14.C * -1475891183, var15);
      }

   }

   public void method6344(GE var1, int[] var2) {
      this.aClass453_6679.I((AE)var1, (int)957931044);
      this.A(var1.hashCode(), var1.B(823958259), var1.C(-939748445), var1.I((byte)100), var1.F(-1170808732), var1.D(-2059498120), var2);
   }

   public void method6358(GE var1, int[] var2) {
      this.aClass453_6679.I((AE)var1, (int)1406819574);
      this.A(var1.hashCode(), var1.B(823958259), var1.C(-1659137214), var1.I((byte)53), var1.F(-822697788), var1.D(-1817941652), var2);
   }

   native void au(float[] var1);

   native void ap(ja var1, ba var2, int var3, int var4, int[][] var5, int[][] var6, int var7, int var8, int var9);

   native void af(ja var1, ba var2, int var3, int var4, int[][] var5, int[][] var6, int var7, int var8, int var9);

   native void aw(ja var1, ba var2, int var3, int var4, int[][] var5, int[][] var6, int var7, int var8, int var9);

   public void method6347(int var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean[][] var8) {
      this.aJa6678.method5571().method282(this, var1, var2, var3, var4, var5, var6, var7, var8);
   }

   native void aj(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, int var11, int var12, int var13, boolean var14);

   native void G(ja var1, ba var2, int var3, int var4, int[][] var5, int[][] var6, int var7, int var8, int var9);

   native void aq(int var1, int var2, int var3, int var4, int var5, int var6, int[] var7);

   native void ag(float[] var1);

   public native void at(int var1, int var2, int var3);

   public native void av(GJI var1, int var2, int var3, int var4, int var5, boolean var6);
}
