import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.ref.ReferenceQueue;
import java.util.ArrayList;

public final class GZI {
   int B;
   static int I;
   ReferenceQueue Z = new ReferenceQueue();
   WEI[] add = new WEI[16];
   public static SU C;
   public static IBI D;

   public void I(Object var1, Object var2, int var3) {
      try {
         if (var1 == null) {
            throw new NullPointerException();
         } else {
            this.B(1702492864);
            int var4 = System.identityHashCode(var1);
            int var5 = var4 & this.add.length - 1;
            WEI var6 = this.add[var5];
            if (var6 == null) {
               this.add[var5] = new WEI(var1, this.Z, var4, var2);
               this.B += -1233820543;
               if (2061425537 * this.B >= this.add.length) {
                  this.Z(-354056618);
               }
            } else {
               while(var6.get() != var1) {
                  if (var6.Z == null) {
                     var6.Z = new WEI(var1, this.Z, var4, var2);
                     this.B += -1233820543;
                     if (this.B * 2061425537 >= this.add.length) {
                        this.Z(-2117837549);
                     }
                     break;
                  }

                  var6 = var6.Z;
               }
            }

         }
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "us.a(" + ')');
      }
   }

   void B(int var1) {
      try {
         while(true) {
            WEI var2 = (WEI)this.Z.poll();
            if (var2 == null) {
               return;
            }

            int var3 = 1530822039 * var2.I & this.add.length - 1;
            WEI var4 = this.add[var3];
            if (var2 == var4) {
               this.add[var3] = var2.Z;
               this.B -= -1233820543;
            } else {
               while(var4 != null && var2 != var4.Z) {
                  var4 = var4.Z;
               }

               if (var4 != null) {
                  var4.Z = var2.Z;
                  this.B -= -1233820543;
               }
            }
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "us.i(" + ')');
      }
   }

   public ArrayList I(int var1) {
      try {
         this.B(-93976926);
         ArrayList var2 = new ArrayList(this.B * 2061425537);
         WEI[] var3 = this.add;

         for(int var4 = 0; var4 < var3.length; ++var4) {
            for(WEI var5 = var3[var4]; var5 != null; var5 = var5.Z) {
               Object var6 = var5.get();
               if (var6 != null) {
                  var2.add(var6);
               }
            }
         }

         return var2;
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "us.b(" + ')');
      }
   }

   public void I(Object var1, int var2) {
      try {
         if (var1 == null) {
            throw new NullPointerException();
         } else {
            this.B(-439163515);
            int var3 = System.identityHashCode(var1);
            int var4 = var3 & this.add.length - 1;
            WEI var5 = this.add[var4];
            if (var5 != null) {
               if (var5.get() == var1) {
                  this.add[var4] = var5.Z;
                  this.B -= -1233820543;
               } else {
                  while(true) {
                     WEI var6 = var5.Z;
                     if (var6 == null) {
                        if (var2 < 125611783) {
                           ;
                        }
                        break;
                     }

                     if (var6.get() == var1) {
                        var5.Z = var6.Z;
                        this.B -= -1233820543;
                        break;
                     }

                     var5 = var6;
                  }
               }
            }

         }
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "us.f(" + ')');
      }
   }

   void Z(int var1) {
      try {
         WEI[] var2 = this.add;
         this.add = new WEI[2 * var2.length];
         WEI[] var3 = var2;

         WEI var5;
         for(int var4 = 0; var4 < var3.length; ++var4) {
            for(WEI var6 = var3[var4]; var6 != null; var6 = var5) {
               var5 = var6.Z;
               int var7 = var6.I * 1530822039 & this.add.length - 1;
               var6.Z = this.add[var7];
               this.add[var7] = var6;
            }
         }

      } catch (RuntimeException var8) {
         throw DQ.I(var8, "us.p(" + ')');
      }
   }

   public static void I(boolean var0, int var1) {
      try {
         if (var0) {
            if (-1 != XEI.xC * -257444687) {
               HFI.I(-257444687 * XEI.xC, -2042512871);
            }

            for(OSI var2 = (OSI)XEI.yC.C(1741120464); var2 != null; var2 = (OSI)XEI.yC.Z((byte)42)) {
               if (!var2.Z(-629325116)) {
                  var2 = (OSI)XEI.yC.C(1941104676);
                  if (var2 == null) {
                     if (var1 >= -995600773) {
                        return;
                     }
                     break;
                  }
               }

               BB.I(var2, true, false, -113822480);
            }

            XEI.xC = -1785861201;
            XEI.yC = new JX(8);
            EU.I((short)255);
            XEI.xC = 62030331 * JX.J.G;
            DS.I(false, (byte)8);
            TQ.Z(-960032596);
            KZ.I(-257444687 * XEI.xC, (int[])null, 2019085039);
         }

         QD.I(-2068735860);
         TQ.h = false;
         JSI.I(1449725764);
         XEI.aD = 280458557;
         ICI.C(XEI.nC * 1203044105, 614001892);
         UA.F = new PEI((AP)null);
         UA.F.I((float)(XEI.mI.Z(-1895849411) * 512 / 2), 0.0F, (float)(XEI.mI.C(501771104) * 512 / 2));
         UA.F.YI[0] = XEI.mI.Z(-1873805931) / 2;
         UA.F.v[0] = XEI.mI.C(2001443939) / 2;
         RZ.H = 0;
         RR.Q = 0;
         if (3 == EE.V * -863531439) {
            RR.Q = (1374340743 * GT.D << 9) * 547882953;
            RZ.H = (SFI.F * -1548077269 << 9) * 309839105;
         } else {
            EU.I((byte)90);
         }

         XEI.mI.C((byte)-45).I(-1834713428);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "us.fs(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-38);
         var0.H[(var0.J += -391880689) * 681479919 - 1] = 1354508417 * var3.W;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "us.qx(" + ')');
      }
   }

   static boolean I(QEI var0, int var1, int var2) {
      try {
         int var3 = var0.C(2);
         int var4;
         int var5;
         int var9;
         int var10;
         int var11;
         if (var3 == 0) {
            if (var0.C(1) != 0) {
               I(var0, var1, -1136734730);
            }

            var4 = var0.C(6);
            var5 = var0.C(6);
            boolean var17 = var0.C(1) == 1;
            if (var17) {
               C.E[(C.A += 867608709) * -1281683379 - 1] = var1;
            }

            if (XEI.MC[var1] != null) {
               throw new RuntimeException();
            } else {
               IV var18 = C.S[var1];
               PEI var19 = XEI.MC[var1] = new PEI(XEI.mI.T(-1611682495));
               var19.W = var1 * 1714292119;
               if (C.D[var1] != null) {
                  var19.I(C.D[var1], (byte)3);
               }

               var19.I(-1000138653 * var18.Z, true, 1449559817);
               var19.u = -790543005 * var18.I;
               var9 = var18.B * 1966930015;
               var10 = var9 >> 28;
               var11 = var9 >> 14 & 255;
               int var12 = var9 & 255;
               XP var13 = XEI.mI.I(681479919);
               int var14 = (var11 << 6) + var4 - var13.I * -1760580017;
               int var15 = (var12 << 6) + var5 - 283514611 * var13.Z;
               var19.qI = var18.C;
               var19.GZ = var18.D;
               var19.MI[0] = C.B[var1];
               var19.K = var19.L = (byte)var10;
               if (XEI.mI.M(1040339757).I(var14, var15, -937818147)) {
                  var19.L = (byte)(var19.L + 1);
               }

               var19.I(var14, var15, -2040915654);
               var19.FZ = false;
               C.S[var1] = null;
               return true;
            }
         } else if (1 == var3) {
            var4 = var0.C(2);
            var5 = C.S[var1].B * 1966930015;
            C.S[var1].B = (((var4 + (var5 >> 28) & 3) << 28) + (var5 & 268435455)) * 1896571807;
            return false;
         } else {
            int var6;
            int var7;
            int var8;
            if (var3 == 2) {
               var4 = var0.C(5);
               var5 = var4 >> 3;
               var6 = var4 & 7;
               var7 = 1966930015 * C.S[var1].B;
               var8 = (var7 >> 28) + var5 & 3;
               var9 = var7 >> 14 & 255;
               var10 = var7 & 255;
               if (var6 == 0) {
                  --var9;
                  --var10;
               }

               if (var6 == 1) {
                  --var10;
               }

               if (var6 == 2) {
                  ++var9;
                  --var10;
               }

               if (3 == var6) {
                  --var9;
               }

               if (4 == var6) {
                  ++var9;
               }

               if (var6 == 5) {
                  --var9;
                  ++var10;
               }

               if (6 == var6) {
                  ++var10;
               }

               if (var6 == 7) {
                  ++var9;
                  ++var10;
               }

               C.S[var1].B = 1896571807 * (var10 + (var8 << 28) + (var9 << 14));
               return false;
            } else {
               var4 = var0.C(18);
               var5 = var4 >> 16;
               var6 = var4 >> 8 & 255;
               var7 = var4 & 255;
               var8 = 1966930015 * C.S[var1].B;
               var9 = var5 + (var8 >> 28) & 3;
               var10 = var6 + (var8 >> 14) & 255;
               var11 = var8 + var7 & 255;
               C.S[var1].B = (var11 + (var10 << 14) + (var9 << 28)) * 1896571807;
               return false;
            }
         }
      } catch (RuntimeException var16) {
         throw DQ.I(var16, "us.k(" + ')');
      }
   }

   static void I(int var0, String var1, int var2) {
      try {
         VK var3 = IV.I(2, (long)var0);
         var3.I((byte)54);
         var3.M = var1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "us.at(" + ')');
      }
   }

   static void I(File var0, byte[] var1, int var2, int var3) throws IOException {
      try {
         DataInputStream var4 = new DataInputStream(new BufferedInputStream(new FileInputStream(var0)));

         try {
            var4.readFully(var1, 0, var2);
         } catch (EOFException var6) {
            ;
         }

         var4.close();
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "us.a(" + ')');
      }
   }
}
