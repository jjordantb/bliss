public class BU {
   public int[] I;
   SU Z;
   public int C;
   public int[] B;
   public boolean D = false;
   public int[] F;
   public int J = 490274841;
   public boolean S = false;
   public boolean[] A;
   public int E = 1084755117;
   public int G = 556718803;
   public int H = -1297220983;
   public int K = -1164419115;
   public int L = 1486793947;
   public int[] M;
   public int N = -1421665550;
   public boolean O = false;
   public static boolean P = false;
   public int[][] Q;
   public int[] R;
   public int T = 1424483545;
   public int[] U;
   JX append;

   public String I(int var1, String var2, int var3) {
      try {
         if (this.append == null) {
            return var2;
         } else {
            QG var4 = (QG)this.append.I((long)var1);
            return var4 == null ? var2 : (String)var4.J;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "qe.k(" + ')');
      }
   }

   void F(REI var1, int var2, int var3) {
      try {
         int var4;
         int var5;
         if (1 == var2) {
            var4 = var1.C();
            this.I = new int[var4];

            for(var5 = 0; var5 < var4; ++var5) {
               this.I[var5] = var1.C();
            }

            this.B = new int[var4];

            for(var5 = 0; var5 < var4; ++var5) {
               this.B[var5] = var1.C();
            }

            for(var5 = 0; var5 < var4; ++var5) {
               this.B[var5] += var1.C() << 16;
            }
         } else if (2 == var2) {
            this.J = var1.C() * -490274841;
         } else if (var2 == 3) {
            this.A = new boolean[256];
            var4 = var1.I();

            for(var5 = 0; var5 < var4; ++var5) {
               this.A[var1.I()] = true;
            }
         } else if (5 == var2) {
            this.E = var1.I() * -1501035895;
         } else if (6 == var2) {
            this.G = var1.C() * -556718803;
         } else if (var2 == 7) {
            this.H = var1.C() * 1297220983;
         } else if (var2 == 8) {
            this.K = var1.I() * 248539239;
         } else if (var2 == 9) {
            this.L = var1.I() * -1486793947;
         } else if (10 == var2) {
            this.T = var1.I() * -1424483545;
         } else if (var2 == 11) {
            this.N = var1.I() * 1436650873;
         } else if (var2 == 12) {
            var4 = var1.I();
            this.F = new int[var4];

            for(var5 = 0; var5 < var4; ++var5) {
               this.F[var5] = var1.C();
            }

            for(var5 = 0; var5 < var4; ++var5) {
               this.F[var5] += var1.C() << 16;
            }
         } else {
            int var7;
            if (13 == var2) {
               var4 = var1.C();
               this.Q = new int[var4][];

               for(var5 = 0; var5 < var4; ++var5) {
                  int var6 = var1.I();
                  if (var6 > 0) {
                     this.Q[var5] = new int[var6];
                     this.Q[var5][0] = var1.B((byte)-28);

                     for(var7 = 1; var7 < var6; ++var7) {
                        this.Q[var5][var7] = var1.C();
                     }
                  }
               }
            } else if (14 == var2) {
               this.O = true;
            } else if (var2 == 15) {
               this.S = true;
            } else if (16 != var2) {
               if (18 == var2) {
                  this.D = true;
               } else if (19 == var2) {
                  if (this.R == null) {
                     this.R = new int[this.Q.length];

                     for(var4 = 0; var4 < this.Q.length; ++var4) {
                        this.R[var4] = 255;
                     }
                  }

                  this.R[var1.I()] = var1.I();
               } else if (20 == var2) {
                  if (this.M == null || this.U == null) {
                     this.M = new int[this.Q.length];
                     this.U = new int[this.Q.length];

                     for(var4 = 0; var4 < this.Q.length; ++var4) {
                        this.M[var4] = 256;
                        this.U[var4] = 256;
                     }
                  }

                  var4 = var1.I();
                  this.M[var4] = var1.C();
                  this.U[var4] = var1.C();
               } else if (var2 == 249) {
                  var4 = var1.I();
                  if (this.append == null) {
                     var5 = JV.I(var4, (byte)16);
                     this.append = new JX(var5);
                  }

                  for(var5 = 0; var5 < var4; ++var5) {
                     boolean var10 = var1.I() == 1;
                     var7 = var1.B((byte)-17);
                     Object var8;
                     if (var10) {
                        var8 = new QG(var1.E(102394051));
                     } else {
                        var8 = new OK(var1.H((byte)14));
                     }

                     this.append.I((AE)var8, (long)var7);
                  }
               }
            }
         }

      } catch (RuntimeException var9) {
         throw DQ.I(var9, "qe.f(" + ')');
      }
   }

   void I(byte var1) {
      try {
         if (62820525 * this.L == -1) {
            if (this.A != null) {
               this.L = 1321379402;
            } else {
               this.L = 0;
            }
         }

         if (-1 == -882531177 * this.T) {
            if (this.A != null) {
               this.T = 1446000206;
            } else {
               this.T = 0;
            }
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "qe.b(" + ')');
      }
   }

   public boolean I(int var1) {
      try {
         if (this.B == null) {
            return true;
         } else {
            boolean var2 = true;
            int[] var3 = this.B;

            for(int var4 = 0; var4 < var3.length; ++var4) {
               int var5 = var3[var4];
               if (this.Z.I(var5 >>> 16, -1720040211) == null) {
                  var2 = false;
               }
            }

            return var2;
         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "qe.p(" + ')');
      }
   }

   public int I(int var1, int var2, int var3) {
      try {
         if (this.append == null) {
            return var2;
         } else {
            OK var4 = (OK)this.append.I((long)var1);
            return var4 == null ? var2 : var4.J * -774922497;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "qe.i(" + ')');
      }
   }

   void I(REI var1, int var2) {
      try {
         while(true) {
            int var3 = var1.I();
            if (var3 == 0) {
               if (var2 >= -360107567) {
                  throw new IllegalStateException();
               }

               return;
            }

            this.F(var1, var3, -1717065205);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "qe.a(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = XEI.TD;
         var0.H[(var0.J += -391880689) * 681479919 - 1] = XEI.cD;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "qe.akz(" + ')');
      }
   }

   public static void I(int var0, int var1, int var2, int var3, KEI var4, GEI var5, PEI var6, byte var7) {
      try {
         SM var8 = new SM();
         var8.G = 2135210127 * var0;
         var8.H = -7217919 * (var1 << 9);
         var8.E = (var2 << 9) * 584186023;
         if (var4 != null) {
            var8.T = var4;
            int var9 = var4.N * -1125834887;
            int var10 = var4.L * -565161399;
            if (var3 == 1 || var3 == 3) {
               var9 = var4.L * -565161399;
               var10 = var4.N * -1125834887;
            }

            var8.L = 305826635 * (var1 + var9 << 9);
            var8.M = -1647445571 * (var2 + var10 << 9);
            var8.z = 128561991 * var4.o;
            var8.c = var4.u;
            var8.O = 1644605369 * (-161350689 * var4.g << 9);
            var8.s = var4.t * -1807698503;
            var8.a = var4.v * 763489431;
            var8.A = var4.w * 1972784599;
            var8.P = var4.x;
            var8.e = var4.V;
            var8.g = -1937096719 * var4.AI;
            var8.Y = 1100795 * var4.SI;
            var8.N = 406226903 * (-282587873 * var4.JI << 9);
            if (var4.C != null) {
               var8.U = true;
               var8.C(-2011876770);
            }

            if (var8.P != null) {
               var8.k = (-15898815 * var8.a + (int)(Math.random() * (double)(-1398300237 * var8.A - -15898815 * var8.a))) * 950219665;
            }

            SM.S.I((AE)var8, (int)2135348486);
         } else if (var5 != null) {
            var8.Q = var5;
            HEI var12 = var5.tI;
            if (var12.ZI != null) {
               var8.U = true;
               var12 = var12.I((FAI)MI.E, 1825815932);
            }

            if (var12 != null) {
               var8.L = 305826635 * (var12.II * -2095128707 + var1 << 9);
               var8.M = -1647445571 * (var2 + -2095128707 * var12.II << 9);
               var8.z = SI.I(var5, 2096811251) * 502744039;
               var8.c = var12.r;
               var8.O = (var12.G * 1525111487 << 9) * 1644605369;
               var8.s = -1283486135 * var12.q;
               var8.g = 1142643823 * var12.z;
               var8.Y = 1682293055 * var12.BI;
               var8.N = (-1422618341 * var12.l << 9) * 406226903;
            }

            SM.l.I((AE)var8, (int)387904128);
         } else if (var6 != null) {
            var8.R = var6;
            var8.L = (var1 + var6.S() << 9) * 305826635;
            var8.M = (var2 + var6.S() << 9) * -1647445571;
            var8.z = ET.I(var6, 2035612836) * 502744039;
            var8.c = var6.lI;
            var8.O = (780357347 * var6.BZ << 9) * 1644605369;
            var8.s = -1138033583 * var6.DZ;
            var8.g = -1197363456;
            var8.Y = -900102912;
            var8.N = 0;
            SM.X.I(var8, (long)(var6.W * 1888274983));
         }

      } catch (RuntimeException var11) {
         throw DQ.I(var11, "qe.p(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)95);
         X var4 = IU.F[var2 >> 16];
         AS.I(var3, var4, var0, (short)28140);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "qe.gu(" + ')');
      }
   }

   static SSI I(int var0, int var1, int var2, byte var3) {
      try {
         BP var4 = XEI.mI.T(-1611682495).E[var0][var1][var2];
         if (var4 == null) {
            return null;
         } else {
            SSI var5 = null;
            int var6 = -1;

            for(XO var7 = var4.Z; var7 != null; var7 = var7.C) {
               ZR var8 = var7.Z;
               if (var8 instanceof SSI) {
                  SSI var9 = (SSI)var8;
                  int var10 = (var9.S() - 1) * 256 + 252;
                  SF var11 = var9.I().I;
                  int var12 = (int)var11.I - var10 >> 9;
                  int var13 = (int)var11.Z - var10 >> 9;
                  int var14 = var10 + (int)var11.I >> 9;
                  int var15 = var10 + (int)var11.Z >> 9;
                  if (var12 <= var1 && var13 <= var2 && var14 >= var1 && var15 >= var2) {
                     int var16 = (1 + var14 - var1) * (var15 + 1 - var2);
                     if (var16 > var6) {
                        var5 = var9;
                        var6 = var16;
                     }
                  }
               }
            }

            return var5;
         }
      } catch (RuntimeException var17) {
         throw DQ.I(var17, "qe.id(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, byte var3) {
      try {
         var0.y = var2.H[(var2.J -= -391880689) * 681479919] == 1;
         VEI.I(var0, 2128713505);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "qe.ds(" + ')');
      }
   }

   static int Z(int var0, int var1, int var2) {
      try {
         double var3 = Math.log((double)var1) / Math.log(2.0D);
         double var5 = Math.log((double)var0) / Math.log(2.0D);
         double var7 = Math.random() * (var3 - var5) + var5;
         return (int)(Math.pow(2.0D, var7) + 0.5D);
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "qe.m(" + ')');
      }
   }
}
