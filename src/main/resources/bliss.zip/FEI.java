public interface FEI {
   int method169();

   boolean method170(int var1, short var2);

   int[] method171(int var1, float var2, int var3, int var4, boolean var5, int var6);

   int[] method172(int var1, float var2, int var3, int var4, boolean var5, byte var6);

   int[] method173(int var1, float var2, int var3, int var4, boolean var5);

   WCI method174(int var1, int var2);

   int method175();

   void method176(int var1);

   int method177(int var1);

   int[] method178(int var1, float var2, int var3, int var4, boolean var5);

   float[] method179(int var1, float var2, int var3, int var4, boolean var5);

   boolean method180(int var1);

   float[] method181(int var1, float var2, int var3, int var4, boolean var5, byte var6);

   int[] method182(int var1, float var2, int var3, int var4, boolean var5);

   int[] method183(int var1, float var2, int var3, int var4, boolean var5);

   float[] method184(int var1, float var2, int var3, int var4, boolean var5);

   int method185();

   int method186();

   WCI method187(int var1);

   WCI method188(int var1);

   void method189();

   int[] method190(int var1, float var2, int var3, int var4, boolean var5);
}
