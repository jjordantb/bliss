public class IW extends LV {
   int method5612(int var1, int var2) {
      return 1;
   }

   public IW(int var1, MM var2) {
      super(var1, var2);
   }

   public void I(int var1) {
   }

   int method5616(int var1) {
      return 1;
   }

   void method5614(int var1, int var2) {
      try {
         this.C = var1 * 1886334997;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aeb.p(" + ')');
      }
   }

   public int Z(int var1) {
      try {
         return -1598873795 * this.C;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aeb.z(" + ')');
      }
   }

   int method5615() {
      return 0;
   }

   public IW(MM var1) {
      super(var1);
   }

   void method5610(int var1) {
      this.C = var1 * 1886334997;
   }

   int method5611(int var1) {
      return 0;
   }

   public static BAI I(BAI[] var0, int var1, byte var2) {
      try {
         BAI[] var3 = var0;

         for(int var4 = 0; var4 < var3.length; ++var4) {
            BAI var5 = var3[var4];
            if (var1 == var5.method242(694163818)) {
               return var5;
            }
         }

         return null;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "aeb.a(" + ')');
      }
   }
}
