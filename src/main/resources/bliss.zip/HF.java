public class HF {
   public static int[] I = new int[16384];
   public static int cos = 16383;
   public static int sin = 14;
   public static int Z = 8192;
   public static int C = 16384;
   public static int B = 16383;
   public static int D = 14;
   public static int F = 1024;
   public static int J = 2048;
   public static int[] S = new int[16384];
   public static double A = 2607.5945876176133D;
   public static int E = 6144;
   public static int G = 10240;
   public static int H = 12288;
   public static int K = 14336;
   public static int L = 16384;
   public static int M = 16384;
   public static int N = 4096;

   static {
      double var0 = 3.834951969714103E-4D;

      for(int var2 = 0; var2 < 16384; ++var2) {
         S[var2] = (int)(16384.0D * Math.sin((double)var2 * var0));
         I[var2] = (int)(16384.0D * Math.cos((double)var2 * var0));
      }

   }

   public static float I(int var0) {
      var0 &= 16383;
      return (float)((double)((float)var0 / 16384.0F) * 6.283185307179586D);
   }

   HF() throws Throwable {
      throw new Error();
   }
}
