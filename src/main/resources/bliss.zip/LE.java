public class LE extends AE {
   byte[] J;
   LX S;

   LE(REI var1) {
      var1.A = (var1.S.length - 3) * 116413311;
      int var2 = var1.I();
      int var3 = var1.C();
      int var4 = 14 + var2 * 10;
      var1.A = 0;
      int var5 = 0;
      int var6 = 0;
      int var7 = 0;
      int var8 = 0;
      int var9 = 0;
      int var10 = 0;
      int var11 = 0;
      int var12 = 0;

      int var13;
      int var14;
      int var15;
      for(var13 = 0; var13 < var2; ++var13) {
         var14 = -1;

         while(true) {
            var15 = var1.I();
            if (var15 != var14) {
               ++var4;
            }

            var14 = var15 & 15;
            if (var15 == 7) {
               break;
            }

            if (var15 == 23) {
               ++var5;
            } else if (var14 == 0) {
               ++var7;
            } else if (var14 == 1) {
               ++var8;
            } else if (var14 == 2) {
               ++var6;
            } else if (var14 == 3) {
               ++var9;
            } else if (var14 == 4) {
               ++var10;
            } else if (var14 == 5) {
               ++var11;
            } else {
               if (var14 != 6) {
                  throw new RuntimeException();
               }

               ++var12;
            }
         }
      }

      var4 += 5 * var5;
      var4 += 2 * (var7 + var8 + var6 + var9 + var11);
      var4 += var10 + var12;
      var13 = var1.A * 385051775;
      var14 = var2 + var5 + var6 + var7 + var8 + var9 + var10 + var11 + var12;

      for(var15 = 0; var15 < var14; ++var15) {
         var1.H(1692297361);
      }

      var4 += var1.A * 385051775 - var13;
      var15 = var1.A * 385051775;
      int var16 = 0;
      int var17 = 0;
      int var18 = 0;
      int var19 = 0;
      int var20 = 0;
      int var21 = 0;
      int var22 = 0;
      int var23 = 0;
      int var24 = 0;
      int var25 = 0;
      int var26 = 0;
      int var27 = 0;
      int var28 = 0;

      int var29;
      for(var29 = 0; var29 < var6; ++var29) {
         var28 = var28 + var1.I() & 127;
         if (var28 != 0 && var28 != 32) {
            if (var28 == 1) {
               ++var16;
            } else if (var28 == 33) {
               ++var17;
            } else if (var28 == 7) {
               ++var18;
            } else if (var28 == 39) {
               ++var19;
            } else if (var28 == 10) {
               ++var20;
            } else if (var28 == 42) {
               ++var21;
            } else if (var28 == 99) {
               ++var22;
            } else if (var28 == 98) {
               ++var23;
            } else if (var28 == 101) {
               ++var24;
            } else if (var28 == 100) {
               ++var25;
            } else if (var28 != 64 && var28 != 65 && var28 != 120 && var28 != 121 && var28 != 123) {
               ++var27;
            } else {
               ++var26;
            }
         } else {
            ++var12;
         }
      }

      var29 = 0;
      int var30 = var1.A * 385051775;
      var1.A += var26 * 116413311;
      int var31 = var1.A * 385051775;
      var1.A += var11 * 116413311;
      int var32 = var1.A * 385051775;
      var1.A += var10 * 116413311;
      int var33 = var1.A * 385051775;
      var1.A += var9 * 116413311;
      int var34 = var1.A * 385051775;
      var1.A += var16 * 116413311;
      int var35 = var1.A * 385051775;
      var1.A += var18 * 116413311;
      int var36 = var1.A * 385051775;
      var1.A += var20 * 116413311;
      int var37 = var1.A * 385051775;
      var1.A += (var7 + var8 + var11) * 116413311;
      int var38 = var1.A * 385051775;
      var1.A += var7 * 116413311;
      int var39 = var1.A * 385051775;
      var1.A += var27 * 116413311;
      int var40 = var1.A * 385051775;
      var1.A += var8 * 116413311;
      int var41 = var1.A * 385051775;
      var1.A += var17 * 116413311;
      int var42 = var1.A * 385051775;
      var1.A += var19 * 116413311;
      int var43 = var1.A * 385051775;
      var1.A += var21 * 116413311;
      int var44 = var1.A * 385051775;
      var1.A += var12 * 116413311;
      int var45 = var1.A * 385051775;
      var1.A += var9 * 116413311;
      int var46 = var1.A * 385051775;
      var1.A += var22 * 116413311;
      int var47 = var1.A * 385051775;
      var1.A += var23 * 116413311;
      int var48 = var1.A * 385051775;
      var1.A += var24 * 116413311;
      int var49 = var1.A * 385051775;
      var1.A += var25 * 116413311;
      int var50 = var1.A * 385051775;
      var1.A += var5 * 349239933;
      this.J = new byte[var4];
      REI var51 = new REI(this.J);
      var51.B(1297377380, -316974152);
      var51.B(6, (int)-588529934);
      var51.Z(var2 > 1 ? 1 : 0, 16711935);
      var51.Z(var2, 16711935);
      var51.Z(var3, 16711935);
      var1.A = var13 * 116413311;
      int var52 = 0;
      int var53 = 0;
      int var54 = 0;
      int var55 = 0;
      int var56 = 0;
      int var57 = 0;
      int var58 = 0;
      int[] var59 = new int[128];
      var28 = 0;

      label223:
      for(int var60 = 0; var60 < var2; ++var60) {
         var51.B(1297379947, -1929295606);
         var51.A += 465653244;
         int var61 = var51.A * 385051775;
         int var62 = -1;

         while(true) {
            while(true) {
               int var63 = var1.H(1692297361);
               var51.G(var63, -1081187550);
               int var64 = var1.S[var29++] & 255;
               boolean var65 = var64 != var62;
               var62 = var64 & 15;
               if (var64 == 7) {
                  if (var65) {
                     var51.F((int)255);
                  }

                  var51.F((int)47);
                  var51.F((int)0);
                  var51.J(var51.A * 385051775 - var61, 1397495562);
                  continue label223;
               }

               if (var64 == 23) {
                  if (var65) {
                     var51.F((int)255);
                  }

                  var51.F((int)81);
                  var51.F((int)3);
                  var51.F((int)var1.S[var50++]);
                  var51.F((int)var1.S[var50++]);
                  var51.F((int)var1.S[var50++]);
               } else {
                  var52 ^= var64 >> 4;
                  if (var62 == 0) {
                     if (var65) {
                        var51.F(144 + var52);
                     }

                     var53 += var1.S[var37++];
                     var54 += var1.S[var38++];
                     var51.F(var53 & 127);
                     var51.F(var54 & 127);
                  } else if (var62 == 1) {
                     if (var65) {
                        var51.F(128 + var52);
                     }

                     var53 += var1.S[var37++];
                     var55 += var1.S[var40++];
                     var51.F(var53 & 127);
                     var51.F(var55 & 127);
                  } else if (var62 == 2) {
                     if (var65) {
                        var51.F(176 + var52);
                     }

                     var28 = var28 + var1.S[var15++] & 127;
                     var51.F(var28);
                     byte var66;
                     if (var28 != 0 && var28 != 32) {
                        if (var28 == 1) {
                           var66 = var1.S[var34++];
                        } else if (var28 == 33) {
                           var66 = var1.S[var41++];
                        } else if (var28 == 7) {
                           var66 = var1.S[var35++];
                        } else if (var28 == 39) {
                           var66 = var1.S[var42++];
                        } else if (var28 == 10) {
                           var66 = var1.S[var36++];
                        } else if (var28 == 42) {
                           var66 = var1.S[var43++];
                        } else if (var28 == 99) {
                           var66 = var1.S[var46++];
                        } else if (var28 == 98) {
                           var66 = var1.S[var47++];
                        } else if (var28 == 101) {
                           var66 = var1.S[var48++];
                        } else if (var28 == 100) {
                           var66 = var1.S[var49++];
                        } else if (var28 != 64 && var28 != 65 && var28 != 120 && var28 != 121 && var28 != 123) {
                           var66 = var1.S[var39++];
                        } else {
                           var66 = var1.S[var30++];
                        }
                     } else {
                        var66 = var1.S[var44++];
                     }

                     int var67 = var66 + var59[var28];
                     var59[var28] = var67;
                     var51.F(var67 & 127);
                  } else if (var62 == 3) {
                     if (var65) {
                        var51.F(224 + var52);
                     }

                     var56 += var1.S[var45++];
                     var56 += var1.S[var33++] << 7;
                     var51.F(var56 & 127);
                     var51.F(var56 >> 7 & 127);
                  } else if (var62 == 4) {
                     if (var65) {
                        var51.F(208 + var52);
                     }

                     var57 += var1.S[var32++];
                     var51.F(var57 & 127);
                  } else if (var62 == 5) {
                     if (var65) {
                        var51.F(160 + var52);
                     }

                     var53 += var1.S[var37++];
                     var58 += var1.S[var31++];
                     var51.F(var53 & 127);
                     var51.F(var58 & 127);
                  } else {
                     if (var62 != 6) {
                        throw new RuntimeException();
                     }

                     if (var65) {
                        var51.F(192 + var52);
                     }

                     var51.F((int)var1.S[var44++]);
                  }
               }
            }
         }
      }

   }

   void I() {
      if (this.S == null) {
         this.S = new LX(16);
         int[] var1 = new int[16];
         int[] var2 = new int[16];
         var2[9] = 128;
         var1[9] = 128;
         J var4 = new J(this.J);
         int var5 = var4.Z();

         int var6;
         for(var6 = 0; var6 < var5; ++var6) {
            var4.I(var6);
            var4.Z(var6);
            var4.F(var6);
         }

         label56:
         do {
            while(true) {
               var6 = var4.B();
               int var7 = var4.G[var6];

               while(var4.G[var6] == var7) {
                  var4.I(var6);
                  int var8 = var4.C(var6);
                  if (var8 == 1) {
                     var4.C();
                     var4.F(var6);
                     continue label56;
                  }

                  int var9 = var8 & 240;
                  int var10;
                  int var11;
                  int var12;
                  if (var9 == 176) {
                     var10 = var8 & 15;
                     var11 = var8 >> 8 & 127;
                     var12 = var8 >> 16 & 127;
                     if (var11 == 0) {
                        var1[var10] = (var1[var10] & -2080769) + (var12 << 14);
                     }

                     if (var11 == 32) {
                        var1[var10] = (var1[var10] & -16257) + (var12 << 7);
                     }
                  }

                  if (var9 == 192) {
                     var10 = var8 & 15;
                     var11 = var8 >> 8 & 127;
                     var2[var10] = var1[var10] + var11;
                  }

                  if (var9 == 144) {
                     var10 = var8 & 15;
                     var11 = var8 >> 8 & 127;
                     var12 = var8 >> 16 & 127;
                     if (var12 > 0) {
                        int var13 = var2[var10];
                        PG var14 = (PG)this.S.I((long)var13);
                        if (var14 == null) {
                           var14 = new PG(new byte[128]);
                           this.S.I(var14, (long)var13);
                        }

                        var14.J[var11] = 1;
                     }
                  }

                  var4.Z(var6);
                  var4.F(var6);
               }
            }
         } while(!var4.D());
      }

   }

   static LE I(KJ var0, int var1, int var2) {
      byte[] var3 = var0.I(var1, var2, (byte)-117);
      return var3 == null ? null : new LE(new REI(var3));
   }

   void Z() {
      this.S = null;
   }
}
