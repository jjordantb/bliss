import java.awt.Canvas;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class ja extends GSI implements SAI {
   IY aClass453_6680 = new IY();
   static int[] anIntArray6681;
   ba aBa6682;
   YF aClass233_6683;
   boolean aBoolean6684 = false;
   int anInt6685 = 4096;
   YF aClass233_6686;
   float aFloat6687;
   LF aClass222_6688;
   YF aClass233_6689;
   YF aClass233_6690;
   float aFloat6691;
   int anInt6692;
   static int[] anIntArray6693 = new int[Math.max(Math.max(104, 20), 24573)];
   float aFloat6694;
   float aFloat6695;
   LF aClass222_6696;
   a[] anAArray6697;
   static int anInt6698 = 20;
   static int anInt6699 = 104;
   long nativeid = 0L;
   static int anInt6700 = 20;
   static int anInt6701 = 24573;
   static int anInt6702 = 4;
   static float[] aFloatArray6703 = new float[20];
   static int[] anIntArray6704 = new int[6];
   static int[] anIntArray6705;
   static float[] aFloatArray6706;
   static int[] anIntArray6707;
   static int[] anIntArray6708;
   int anInt6709 = 4096;
   static int[] anIntArray6710;
   static short[] aShortArray6711;
   static byte[] aByteArray6712;
   boolean aBoolean6713 = false;

   static {
      anIntArray6705 = anIntArray6693;
      aFloatArray6706 = aFloatArray6703;
      anIntArray6681 = anIntArray6693;
      anIntArray6708 = anIntArray6693;
      anIntArray6707 = new int[8191];
      anIntArray6710 = new int[8191];
      aShortArray6711 = new short[8191];
      aByteArray6712 = new byte[8191];
   }

   native void Q(int var1, int[] var2, float[] var3);

   native void q(FEI var1, int var2, int var3);

   native void oo(float[] var1);

   native void R(int var1, int var2, int var3, int var4, int var5, int var6, QJI var7, int var8, int var9);

   native void da();

   native void Y(int var1);

   native void n(VJI var1);

   public native void ea(int var1, int var2, int var3, int var4);

   Object WA() {
      return new aa(this);
   }

   static void method50123(int var0) {
      try {
         Class var1 = ClassLoader.class;
         Field var2 = var1.getDeclaredField("nativeLibraries");
         Class var3 = AccessibleObject.class;
         Method var4 = var3.getDeclaredMethod("setAccessible", Boolean.TYPE);
         var4.invoke(var2, Boolean.TRUE);
      } catch (Throwable var5) {
         ;
      }

   }

   public int method5135(int var1, int var2, int var3, int var4, int var5, int var6) {
      int var7 = 0;
      float var8 = this.aClass233_6683.I[14] + this.aClass233_6683.I[2] * (float)var1 + this.aClass233_6683.I[6] * (float)var2 + this.aClass233_6683.I[10] * (float)var3;
      float var9 = this.aClass233_6683.I[14] + this.aClass233_6683.I[2] * (float)var4 + this.aClass233_6683.I[6] * (float)var5 + this.aClass233_6683.I[10] * (float)var6;
      float var10 = this.aClass233_6683.I[15] + this.aClass233_6683.I[3] * (float)var1 + this.aClass233_6683.I[7] * (float)var2 + this.aClass233_6683.I[11] * (float)var3;
      float var11 = this.aClass233_6683.I[15] + this.aClass233_6683.I[3] * (float)var4 + this.aClass233_6683.I[7] * (float)var5 + this.aClass233_6683.I[11] * (float)var6;
      if (var8 < -var10 && var9 < -var11) {
         var7 |= 16;
      } else if (var8 > var10 && var9 > var11) {
         var7 |= 32;
      }

      float var12 = this.aClass233_6683.I[12] + this.aClass233_6683.I[0] * (float)var1 + this.aClass233_6683.I[4] * (float)var2 + this.aClass233_6683.I[8] * (float)var3;
      float var13 = this.aClass233_6683.I[12] + this.aClass233_6683.I[0] * (float)var4 + this.aClass233_6683.I[4] * (float)var5 + this.aClass233_6683.I[8] * (float)var6;
      if (var12 < -var10 && var13 < -var11) {
         var7 |= 1;
      }

      if (var12 > var10 && var13 > var11) {
         var7 |= 2;
      }

      float var14 = this.aClass233_6683.I[13] + this.aClass233_6683.I[1] * (float)var1 + this.aClass233_6683.I[5] * (float)var2 + this.aClass233_6683.I[9] * (float)var3;
      float var15 = this.aClass233_6683.I[13] + this.aClass233_6683.I[1] * (float)var4 + this.aClass233_6683.I[5] * (float)var5 + this.aClass233_6683.I[9] * (float)var6;
      if (var14 < -var10 && var15 < -var11) {
         var7 |= 4;
      }

      if (var14 > var10 && var15 > var11) {
         var7 |= 8;
      }

      return var7;
   }

   public void method5012(boolean var1) {
   }

   protected void finalize() {
      this.H(1915551427);
      if (this.nativeid != 0L) {
         ZDI.I(this, (short)18758);
      }

   }

   void method5068() {
      if (!this.aBoolean6684) {
         this.anAArray6697 = null;
         this.aBa6682 = null;
         this.aClass233_6686 = null;

         for(ba var1 = (ba)this.aClass453_6680.Z(1766612795); var1 != null; var1 = (ba)this.aClass453_6680.B(49146)) {
            var1.ha();
         }

         this.aClass453_6680.I((byte)1);
         this.da();
         if (this.aBoolean6713) {
            JF.I(false, true, (short)17761);
            this.aBoolean6713 = false;
         }

         this.h();
         ZDI.Z(-1408959178);
         this.aBoolean6684 = true;
      }

   }

   void method5568(XBI var1, boolean var2) {
      int var3 = 0;
      int var4 = 0;
      int var5 = 0;
      int var6 = 0;
      int var7 = 0;

      for(NN var8 = (NN)var1.I.C(-1980678448); var8 != null; var8 = (NN)var1.I.Z(-1594607978)) {
         anIntArray6708[var3++] = var8.D;
         anIntArray6708[var3++] = var8.A;
         anIntArray6708[var3++] = var8.E;
         anIntArray6707[var4++] = var8.H;
         aShortArray6711[var6++] = (short)var8.L;
         anIntArray6710[var5++] = var8.G;
         if (var2) {
            aByteArray6712[var7++] = var8.K;
         }
      }

   }

   public SBI method4987() {
      return new SBI(0, "SSE", 1, "CPU", 0L);
   }

   public void method5011() {
      this.aFloat6695 = (float)this.I((short)13884).method545() / 2.0F;
      this.aFloat6694 = (float)this.I((short)-4468).method552() / 2.0F;
      this.aFloat6687 = this.aFloat6695;
      this.aFloat6691 = this.aFloat6694;
      this.k();
   }

   public void method5075() {
   }

   void method5023() {
      if (!this.aBoolean6684) {
         this.anAArray6697 = null;
         this.aBa6682 = null;
         this.aClass233_6686 = null;

         for(ba var1 = (ba)this.aClass453_6680.Z(1766612795); var1 != null; var1 = (ba)this.aClass453_6680.B(49146)) {
            var1.ha();
         }

         this.aClass453_6680.I((byte)1);
         this.da();
         if (this.aBoolean6713) {
            JF.I(false, true, (short)-22106);
            this.aBoolean6713 = false;
         }

         this.h();
         ZDI.Z(-1408959178);
         this.aBoolean6684 = true;
      }

   }

   public void method4993(int var1) {
      ZDI.I((byte)3);
      this.Y(var1);

      for(ba var2 = (ba)this.aClass453_6680.Z(1766612795); var2 != null; var2 = (ba)this.aClass453_6680.B(49146)) {
         var2.u();
      }

   }

   void method5150(float var1, float var2, float var3, float var4, float var5, float var6) {
   }

   public boolean method5001() {
      return true;
   }

   public native void z(boolean var1);

   native void nf(short var1, short var2, int var3, byte var4, byte var5, int var6, boolean var7, byte var8, byte var9, byte var10, byte var11, boolean var12, boolean var13, boolean var14, boolean var15, boolean var16, byte var17, boolean var18, boolean var19, int var20);

   public boolean method5050() {
      return false;
   }

   public boolean method4996() {
      return false;
   }

   public boolean method5082() {
      return true;
   }

   public boolean method5032() {
      return false;
   }

   native void ns();

   native void fm(int var1, int var2, int var3, int var4, int var5);

   public boolean method5051() {
      return true;
   }

   public native void G(int var1, int var2, int var3, int var4, int var5);

   public boolean method5159() {
      return true;
   }

   public native int[] aq(int var1, int var2, int var3, int var4);

   public native void gv(int var1, QJI var2, int var3, int var4);

   public void method5115(int var1) {
      this.anInt6709 = this.anInt6685 = var1;
      if (this.anInt6692 > 1) {
         throw new IllegalStateException();
      } else {
         this.method5569(this.anInt6692);
         this.method5570(0);
      }
   }

   public native void L();

   native void d(long var1, long var3);

   public OBI method5142(OBI var1, OBI var2, float var3, OBI var4) {
      return null;
   }

   native void k();

   public void method5187(int var1, int var2, int var3, int var4) {
      this.aFloat6695 = (float)var3 / 2.0F;
      this.aFloat6694 = (float)var4 / 2.0F;
      this.aFloat6687 = (float)var1 + this.aFloat6695;
      this.aFloat6691 = (float)var2 + this.aFloat6694;
      this.A(var1, var2, var3, var4);
   }

   public native void fl(int var1, int var2, int var3, int var4, int var5);

   public native void GA(float var1, float var2);

   public OS method5114(LZI var1, RFI[] var2, boolean var3) {
      int[] var4 = new int[var2.length];
      int[] var5 = new int[var2.length];
      boolean var6 = false;

      for(int var7 = 0; var7 < var2.length; ++var7) {
         var4[var7] = var2[var7].Z;
         var5[var7] = var2[var7].F;
         if (var2[var7].A != null) {
            var6 = true;
         }
      }

      if (var3) {
         if (var6) {
            return new ea(this, this.aBa6682, var1, var2, (IBI[])null);
         } else {
            return new m(this, this.aBa6682, var1, var2, (IBI[])null);
         }
      } else if (var6) {
         throw new IllegalArgumentException("");
      } else {
         return new ia(this, this.aBa6682, var1, var2, (IBI[])null);
      }
   }

   public native int du();

   public native void o(int var1, int var2, int var3, int var4);

   public native void qa(int[] var1);

   public native void ba(int var1, int var2);

   public void method5189(OBI var1) {
   }

   public native void B(int var1, int var2, int var3, int var4, int var5, int var6);

   public native void N(int var1, int var2, int var3, int var4, int var5, int var6, byte[] var7, int var8, int var9);

   public void method5020(int var1, int var2, float var3, int var4, int var5, float var6, int var7, int var8, float var9, int var10, int var11, int var12, int var13) {
      throw new IllegalStateException();
   }

   public native void XA(int var1, int var2, int var3, int var4, int var5);

   native void op(float[] var1);

   public void method5091(int var1, int var2, int var3, int var4, int var5, int var6) {
      this.YA(var1, var2, var3, var4, var5, var6);
   }

   public void method5022(int var1, int var2, int var3, int var4, int var5, int var6, QJI var7, int var8, int var9) {
      this.R(var1, var2, var3, var4, var5, var6, var7, var8, var9);
   }

   native void CA(int var1, int var2, int var3, int var4, int var5);

   public void method5145() {
   }

   public void method5007(int var1, int var2, int var3, int var4, int var5, int var6, QJI var7, int var8, int var9, int var10, int var11, int var12) {
   }

   public void method5039(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9) {
   }

   public YF method5083() {
      return this.aClass233_6686;
   }

   public OS method5092(LZI var1, RFI[] var2, boolean var3) {
      int[] var4 = new int[var2.length];
      int[] var5 = new int[var2.length];
      boolean var6 = false;

      for(int var7 = 0; var7 < var2.length; ++var7) {
         var4[var7] = var2[var7].Z;
         var5[var7] = var2[var7].F;
         if (var2[var7].A != null) {
            var6 = true;
         }
      }

      if (var3) {
         if (var6) {
            return new ea(this, this.aBa6682, var1, var2, (IBI[])null);
         } else {
            return new m(this, this.aBa6682, var1, var2, (IBI[])null);
         }
      } else if (var6) {
         throw new IllegalArgumentException("");
      } else {
         return new ia(this, this.aBa6682, var1, var2, (IBI[])null);
      }
   }

   public void method5059(float var1, float var2, float var3, float[] var4) {
      float var5 = this.aClass233_6683.I[14] + this.aClass233_6683.I[2] * var1 + this.aClass233_6683.I[6] * var2 + this.aClass233_6683.I[10] * var3;
      float var6 = this.aClass233_6683.I[15] + this.aClass233_6683.I[3] * var1 + this.aClass233_6683.I[7] * var2 + this.aClass233_6683.I[11] * var3;
      if (var5 >= -var6 && var5 <= var6) {
         float var7 = this.aClass233_6683.I[12] + this.aClass233_6683.I[0] * var1 + this.aClass233_6683.I[4] * var2 + this.aClass233_6683.I[8] * var3;
         if (var7 >= -var6 && var7 <= var6) {
            float var8 = this.aClass233_6683.I[13] + this.aClass233_6683.I[1] * var1 + this.aClass233_6683.I[5] * var2 + this.aClass233_6683.I[9] * var3;
            if (var8 >= -var6 && var8 <= var6) {
               float var9 = this.aClass233_6689.I[14] + this.aClass233_6689.I[2] * var1 + this.aClass233_6689.I[6] * var2 + this.aClass233_6689.I[10] * var3;
               var4[0] = this.aFloat6687 + this.aFloat6695 * var7 / var6;
               var4[1] = this.aFloat6691 + this.aFloat6694 * var8 / var6;
               var4[2] = var9;
            } else {
               var4[2] = Float.NaN;
               var4[1] = Float.NaN;
               var4[0] = Float.NaN;
            }
         } else {
            var4[2] = Float.NaN;
            var4[1] = Float.NaN;
            var4[0] = Float.NaN;
         }
      } else {
         var4[2] = Float.NaN;
         var4[1] = Float.NaN;
         var4[0] = Float.NaN;
      }

   }

   public VJI method5026(int var1) {
      ba var2 = new ba(this, var1);
      this.aClass453_6680.I((AE)var2, (int)1259364637);
      return var2;
   }

   public void method5027(VJI var1) {
      this.aBa6682 = (ba)var1;
      this.n(var1);
   }

   public IBI method5029(int var1, int var2, boolean var3, boolean var4) {
      return new fa(this, var1, var2, var4);
   }

   public IBI method5030(int[] var1, int var2, int var3, int var4, int var5, boolean var6) {
      return new fa(this, var1, var2, var3, var4, var5, false);
   }

   public IBI method5125(RFI var1, boolean var2) {
      fa var3 = new fa(this, var1.J, var1.S, var1.A, 0, var1.Z, var1.Z, var1.F);
      var3.method621(var1.D, var1.I, var1.B, var1.C);
      return var3;
   }

   public IBI method5033(int var1, int var2, int var3, int var4, boolean var5) {
      return new fa(this, var1, var2, var3, var4, !var5);
   }

   native void V(short var1, short var2, int var3, byte var4, byte var5, int var6, boolean var7, byte var8, byte var9, byte var10, byte var11, boolean var12, boolean var13, boolean var14, boolean var15, boolean var16, byte var17, boolean var18, boolean var19, int var20);

   public native void DA(int var1, QJI var2, int var3, int var4);

   public native void ej(int var1, int var2, int var3, int var4);

   public void method5162(float var1, float var2, float var3, float[] var4) {
      float var5 = this.aClass233_6683.I[15] + this.aClass233_6683.I[3] * var1 + this.aClass233_6683.I[7] * var2 + this.aClass233_6683.I[11] * var3;
      float var6 = this.aClass233_6683.I[12] + this.aClass233_6683.I[0] * var1 + this.aClass233_6683.I[4] * var2 + this.aClass233_6683.I[8] * var3;
      float var7 = this.aClass233_6683.I[13] + this.aClass233_6683.I[1] * var1 + this.aClass233_6683.I[5] * var2 + this.aClass233_6683.I[9] * var3;
      float var8 = this.aClass233_6689.I[14] + this.aClass233_6689.I[2] * var1 + this.aClass233_6689.I[6] * var2 + this.aClass233_6689.I[10] * var3;
      var4[0] = this.aFloat6687 + this.aFloat6695 * var6 / var5;
      var4[1] = this.aFloat6691 + this.aFloat6694 * var7 / var5;
      var4[2] = var8;
   }

   public UT method5037(MBI var1, int var2, int var3, int var4, int var5) {
      return new h(this, this.aBa6682, var1, var2, var3, var4, var5);
   }

   public int method5017(int var1, int var2) {
      int var3 = var1 & 1048575;
      int var4 = var2 & 1048575;
      return var3 & var4 ^ var4;
   }

   public int method5004(int var1, int var2) {
      return var1 | var2;
   }

   public native void gg(int var1, QJI var2, int var3, int var4);

   public YF method5036() {
      return this.aClass233_6686;
   }

   public LF method5178() {
      return this.aClass222_6696;
   }

   void method5569(int var1) {
      this.anInt6692 = var1;
      this.anAArray6697 = new a[this.anInt6692];

      for(int var2 = 0; var2 < this.anInt6692; ++var2) {
         this.anAArray6697[var2] = new a(this, this.anInt6709, this.anInt6685);
      }

   }

   void method5570(int var1) {
      this.anAArray6697[var1].method283();
   }

   a method5571() {
      for(int var1 = 0; var1 < this.anInt6692; ++var1) {
         if (this.anAArray6697[var1].aRunnable6669 == Thread.currentThread()) {
            return this.anAArray6697[var1];
         }
      }

      return null;
   }

   public void method5042(XBI var1) {
      if (var1.I.I((short)-13342) != 0) {
         this.method5568(var1, false);
         this.method5571().method278(this, anIntArray6708, anIntArray6707, anIntArray6710, aShortArray6711, var1.I.I((short)-17134));
      }

   }

   public void method5043(LF var1) {
      this.aClass222_6688 = var1;
      this.aClass233_6689.I(var1);
      this.AA(this.aClass233_6689.I);
      this.aClass233_6683.I(this.aClass233_6689, this.aClass233_6690);
   }

   public LF method5044() {
      return this.aClass222_6688;
   }

   public void method5182(YF var1) {
      this.aClass233_6690 = var1;
      this.wa(this.aClass233_6690.I);
      this.aClass233_6683.I(this.aClass233_6689, this.aClass233_6690);
   }

   native void JA(int var1, int var2, int var3, int var4);

   public boolean method5127() {
      return true;
   }

   native void nm(long var1, long var3);

   void method5009() {
      if (!this.aBoolean6684) {
         this.anAArray6697 = null;
         this.aBa6682 = null;
         this.aClass233_6686 = null;

         for(ba var1 = (ba)this.aClass453_6680.Z(1766612795); var1 != null; var1 = (ba)this.aClass453_6680.B(49146)) {
            var1.ha();
         }

         this.aClass453_6680.I((byte)1);
         this.da();
         if (this.aBoolean6713) {
            JF.I(false, true, (short)-6656);
            this.aBoolean6713 = false;
         }

         this.h();
         ZDI.Z(-1408959178);
         this.aBoolean6684 = true;
      }

   }

   public void method5128(XBI var1) {
      if (var1.I.I((short)-3305) != 0) {
         this.method5568(var1, false);
         this.method5571().method278(this, anIntArray6708, anIntArray6707, anIntArray6710, aShortArray6711, var1.I.I((short)6188));
      }

   }

   public native void J(int var1);

   public native void c(int var1, int var2, int var3);

   public native void RA(boolean var1);

   public void method5021(int var1, GE[] var2) {
      int var3 = 0;

      for(int var4 = 0; var4 < var1; ++var4) {
         anIntArray6705[var3++] = var2[var4].B(823958259);
         anIntArray6705[var3++] = var2[var4].C(-2035778581);
         anIntArray6705[var3++] = var2[var4].I((byte)52);
         anIntArray6705[var3++] = var2[var4].F(34190041);
         aFloatArray6706[var4] = var2[var4].J(608404512);
         anIntArray6705[var3++] = var2[var4].D(-1429005837);
      }

      this.Q(var1, anIntArray6705, aFloatArray6706);
   }

   native void mt(FEI var1, int var2, int var3);

   public OBI method5028(int var1, int var2, int var3, int var4, int var5, int var6) {
      return null;
   }

   public OBI method5179(OBI var1, OBI var2, float var3, OBI var4) {
      return null;
   }

   public void method5095(OBI var1) {
   }

   void method5064(int var1, int var2) throws Exception_Sub1 {
      za var3 = (za)this.K(1919444558);
      if (var3 == null) {
         throw new IllegalStateException();
      } else {
         var3.method581(var1, var2);
         if (this.LZ != null) {
            this.LZ.method176(589016953);
         }

      }
   }

   void method4989(int var1, int var2) throws Exception_Sub1 {
      za var3 = (za)this.K(2121679356);
      if (var3 == null) {
         throw new IllegalStateException();
      } else {
         var3.method581(var1, var2);
         if (this.LZ != null) {
            this.LZ.method176(1305525906);
         }

      }
   }

   public boolean method4995() {
      return true;
   }

   public void method5053() {
   }

   public boolean method5054() {
      return false;
   }

   public ECI method5138() {
      return new NCI(this);
   }

   public void method5176() {
   }

   public void method5168(int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      this.method5571().method286(this, var1, var2, var3, var4, var5, var6, var7);
   }

   public YF method5045() {
      return this.aClass233_6690;
   }

   public final void method5057(int var1, ADI var2) {
      this.M(var1, var2.Z * -1212608691, var2.I * 1996750669, var2.C * -1475891183);
   }

   native void M(int var1, int var2, int var3, int var4);

   public ECI method5094() {
      return new NCI(this);
   }

   public XAI method5186(int var1, int var2) {
      return new oa(var1, var2);
   }

   public SBI method5062() {
      return new SBI(0, "SSE", 1, "CPU", 0L);
   }

   public native void es(int[] var1);

   public native void fu(int var1, int var2, int var3, int var4, int var5);

   void method5065(int var1, int var2) throws Exception_Sub1 {
      za var3 = (za)this.K(1865730499);
      if (var3 == null) {
         throw new IllegalStateException();
      } else {
         var3.method581(var1, var2);
         if (this.LZ != null) {
            this.LZ.method176(1643795383);
         }

      }
   }

   public void method5066() {
   }

   public void method5067() {
   }

   public native int za();

   public native void fh(int var1, int var2);

   public boolean method5073() {
      return true;
   }

   void method5069() {
      if (!this.aBoolean6684) {
         this.anAArray6697 = null;
         this.aBa6682 = null;
         this.aClass233_6686 = null;

         for(ba var1 = (ba)this.aClass453_6680.Z(1766612795); var1 != null; var1 = (ba)this.aClass453_6680.B(49146)) {
            var1.ha();
         }

         this.aClass453_6680.I((byte)1);
         this.da();
         if (this.aBoolean6713) {
            JF.I(false, true, (short)-17613);
            this.aBoolean6713 = false;
         }

         this.h();
         ZDI.Z(-1408959178);
         this.aBoolean6684 = true;
      }

   }

   public void method5174(int var1) {
      ZDI.I((byte)3);
      this.Y(var1);

      for(ba var2 = (ba)this.aClass453_6680.Z(1766612795); var2 != null; var2 = (ba)this.aClass453_6680.B(49146)) {
         var2.u();
      }

   }

   public native int dm();

   public ja(Canvas var1, FEI var2, int var3, int var4) {
      super(var2);

      try {
         if (!NFI.Z(2126469897).method265("sw3d", 1499520275)) {
            throw new RuntimeException("");
         } else {
            ZDI.I(-1686477693);
            this.q(this.LZ, this.LZ.method177(452373566), 0);
            ST.I(false, true, -162450455);
            this.aBoolean6713 = true;
            this.aClass233_6686 = new YF();
            new SF();
            this.aClass222_6696 = new LF();
            new AF();
            this.aClass233_6689 = new YF();
            this.aClass233_6690 = new YF();
            this.aClass233_6683 = new YF();
            this.method5043(new LF());
            this.method5182(new YF());
            this.method5569(1);
            this.method5570(0);
            if (var1 != null) {
               this.I(var1, var3, var4, -414919790);
               this.I(var1, (byte)-90);
            }

            int var5 = this.LZ.method177(468739561);

            for(short var6 = 0; var6 < var5; ++var6) {
               WCI var7 = this.LZ.method174(var6, 1423908475);
               if (var7 != null) {
                  this.V(var6, var7.A, var7.F * -2138060883, var7.J, var7.K, var7.S * 1616831825, var7.Z, var7.E, var7.G, var7.H, var7.I, var7.B, var7.M, var7.D, var7.N, var7.O, var7.L, var7.P, var7.Q, var7.C * -490972023);
               }
            }

         }
      } catch (Throwable var8) {
         this.H(368074744);
         throw new RuntimeException();
      }
   }

   public boolean method5070() {
      return true;
   }

   public native void ed(int var1, int var2, int var3, int var4);

   public boolean method5072() {
      return true;
   }

   public boolean method5071() {
      return true;
   }

   public boolean method5081() {
      return false;
   }

   public void method5134(YF var1) {
      this.aClass233_6690 = var1;
      this.wa(this.aClass233_6690.I);
      this.aClass233_6683.I(this.aClass233_6689, this.aClass233_6690);
   }

   native void mu(int var1, int var2, int var3, int var4, int var5, int var6);

   public boolean method5076() {
      return false;
   }

   public boolean method5077() {
      return false;
   }

   public boolean method5079() {
      return true;
   }

   public native void fa(int var1, int var2, int var3, int var4, int var5, int var6);

   public boolean method5180() {
      return true;
   }

   public int method5048() {
      return 4;
   }

   public boolean method5078() {
      return true;
   }

   OCI method5117(Canvas var1, int var2, int var3) {
      return new za(this, var1, var2, var3);
   }

   public native int[] ev(int var1, int var2, int var3, int var4);

   public native int[] eg(int var1, int var2, int var3, int var4);

   public native void hb(int var1);

   public native void em(boolean var1);

   public native void ec(boolean var1);

   public void method5086() {
      this.aFloat6695 = (float)this.I((short)21033).method545() / 2.0F;
      this.aFloat6694 = (float)this.I((short)-7995).method552() / 2.0F;
      this.aFloat6687 = this.aFloat6695;
      this.aFloat6691 = this.aFloat6694;
      this.k();
   }

   public native void ey(float var1, float var2);

   public native void ez(float var1, float var2);

   public native void el(float var1, float var2);

   public void method5060(float var1, float var2, float var3, float[] var4) {
      float var5 = this.aClass233_6683.I[15] + this.aClass233_6683.I[3] * var1 + this.aClass233_6683.I[7] * var2 + this.aClass233_6683.I[11] * var3;
      float var6 = this.aClass233_6683.I[12] + this.aClass233_6683.I[0] * var1 + this.aClass233_6683.I[4] * var2 + this.aClass233_6683.I[8] * var3;
      float var7 = this.aClass233_6683.I[13] + this.aClass233_6683.I[1] * var1 + this.aClass233_6683.I[5] * var2 + this.aClass233_6683.I[9] * var3;
      float var8 = this.aClass233_6689.I[14] + this.aClass233_6689.I[2] * var1 + this.aClass233_6689.I[6] * var2 + this.aClass233_6689.I[10] * var3;
      var4[0] = this.aFloat6687 + this.aFloat6695 * var6 / var5;
      var4[1] = this.aFloat6691 + this.aFloat6694 * var7 / var5;
      var4[2] = var8;
   }

   public native void ep();

   public native void ei();

   public boolean method5146() {
      return false;
   }

   public void method5112() {
   }

   public native void r(int var1, int var2, int var3, int var4);

   public native void eh(int var1, int var2, int var3, int var4);

   public void method5019(int var1, int var2, int var3, int var4, int var5, int var6) {
      this.XA(var1, var2, var3, var5, var6);
      this.XA(var1, var2 + var4 - 1, var3, var5, var6);
      this.G(var1, var2 + 1, var4 - 1, var5, var6);
      this.G(var1 + var3 - 1, var2 + 1, var4 - 1, var5, var6);
   }

   public native void eo(int[] var1);

   public native void er(int[] var1);

   public native void fy(int var1, int var2);

   public native void fb(int var1, int var2);

   public void method5080() {
   }

   public native void fn(int var1, int var2);

   public void method5093(int var1, int var2, int var3, int var4, int var5, int var6) {
      this.XA(var1, var2, var3, var5, var6);
      this.XA(var1, var2 + var4 - 1, var3, var5, var6);
      this.G(var1, var2 + 1, var4 - 1, var5, var6);
      this.G(var1 + var3 - 1, var2 + 1, var4 - 1, var5, var6);
   }

   native void A(int var1, int var2, int var3, int var4);

   public void method5169(int var1) {
      this.anInt6709 = this.anInt6685 = var1;
      if (this.anInt6692 > 1) {
         throw new IllegalStateException();
      } else {
         this.method5569(this.anInt6692);
         this.method5570(0);
      }
   }

   public native void fi(int var1, int var2, int var3, int var4, int var5, int var6, byte[] var7, int var8, int var9);

   native void fv(int var1, int var2, int var3, int var4, int var5);

   native void or(float[] var1);

   public native void ff(int var1, int var2, int var3, int var4, int var5);

   public native void fd(int var1, int var2, int var3, int var4, int var5);

   public native void ft(int var1, int var2, int var3, int var4, int var5);

   public void method4999(int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      this.method5571().method286(this, var1, var2, var3, var4, var5, var6, var7);
   }

   public native void eq();

   public void method5038(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9) {
   }

   public void method5088(int var1, int var2, int var3, int var4, int var5, int var6, QJI var7, int var8, int var9) {
      this.R(var1, var2, var3, var4, var5, var6, var7, var8, var9);
   }

   public native void hg(int var1, float var2, float var3, float var4, float var5, float var6);

   public void method5097(int var1, int var2, int var3, int var4, int var5, int var6, QJI var7, int var8, int var9) {
      this.R(var1, var2, var3, var4, var5, var6, var7, var8, var9);
   }

   public void method5131(LF var1) {
      this.aClass222_6688 = var1;
      this.aClass233_6689.I(var1);
      this.AA(this.aClass233_6689.I);
      this.aClass233_6683.I(this.aClass233_6689, this.aClass233_6690);
   }

   public int method5099(int var1, int var2, int var3, int var4, int var5, int var6) {
      int var7 = 0;
      float var8 = this.aClass233_6683.I[14] + this.aClass233_6683.I[2] * (float)var1 + this.aClass233_6683.I[6] * (float)var2 + this.aClass233_6683.I[10] * (float)var3;
      float var9 = this.aClass233_6683.I[14] + this.aClass233_6683.I[2] * (float)var4 + this.aClass233_6683.I[6] * (float)var5 + this.aClass233_6683.I[10] * (float)var6;
      float var10 = this.aClass233_6683.I[15] + this.aClass233_6683.I[3] * (float)var1 + this.aClass233_6683.I[7] * (float)var2 + this.aClass233_6683.I[11] * (float)var3;
      float var11 = this.aClass233_6683.I[15] + this.aClass233_6683.I[3] * (float)var4 + this.aClass233_6683.I[7] * (float)var5 + this.aClass233_6683.I[11] * (float)var6;
      if (var8 < -var10 && var9 < -var11) {
         var7 |= 16;
      } else if (var8 > var10 && var9 > var11) {
         var7 |= 32;
      }

      float var12 = this.aClass233_6683.I[12] + this.aClass233_6683.I[0] * (float)var1 + this.aClass233_6683.I[4] * (float)var2 + this.aClass233_6683.I[8] * (float)var3;
      float var13 = this.aClass233_6683.I[12] + this.aClass233_6683.I[0] * (float)var4 + this.aClass233_6683.I[4] * (float)var5 + this.aClass233_6683.I[8] * (float)var6;
      if (var12 < -var10 && var13 < -var11) {
         var7 |= 1;
      }

      if (var12 > var10 && var13 > var11) {
         var7 |= 2;
      }

      float var14 = this.aClass233_6683.I[13] + this.aClass233_6683.I[1] * (float)var1 + this.aClass233_6683.I[5] * (float)var2 + this.aClass233_6683.I[9] * (float)var3;
      float var15 = this.aClass233_6683.I[13] + this.aClass233_6683.I[1] * (float)var4 + this.aClass233_6683.I[5] * (float)var5 + this.aClass233_6683.I[9] * (float)var6;
      if (var14 < -var10 && var15 < -var11) {
         var7 |= 4;
      }

      if (var14 > var10 && var15 > var11) {
         var7 |= 8;
      }

      return var7;
   }

   public XAI method5165(int var1, int var2) {
      return new oa(var1, var2);
   }

   public boolean method5119() {
      return false;
   }

   public VJI method5102(int var1) {
      ba var2 = new ba(this, var1);
      this.aClass453_6680.I((AE)var2, (int)472280132);
      return var2;
   }

   public void method5103(VJI var1) {
      this.aBa6682 = (ba)var1;
      this.n(var1);
   }

   public IBI method5104(int var1, int var2, boolean var3, boolean var4) {
      return new fa(this, var1, var2, var4);
   }

   public void method5160(float var1, float var2, float var3, float[] var4) {
      float var5 = this.aClass233_6683.I[15] + this.aClass233_6683.I[3] * var1 + this.aClass233_6683.I[7] * var2 + this.aClass233_6683.I[11] * var3;
      float var6 = this.aClass233_6683.I[12] + this.aClass233_6683.I[0] * var1 + this.aClass233_6683.I[4] * var2 + this.aClass233_6683.I[8] * var3;
      float var7 = this.aClass233_6683.I[13] + this.aClass233_6683.I[1] * var1 + this.aClass233_6683.I[5] * var2 + this.aClass233_6683.I[9] * var3;
      float var8 = this.aClass233_6689.I[14] + this.aClass233_6689.I[2] * var1 + this.aClass233_6689.I[6] * var2 + this.aClass233_6689.I[10] * var3;
      var4[0] = this.aFloat6687 + this.aFloat6695 * var6 / var5;
      var4[1] = this.aFloat6691 + this.aFloat6694 * var7 / var5;
      var4[2] = var8;
   }

   public IBI method5106(int[] var1, int var2, int var3, int var4, int var5, boolean var6) {
      return new fa(this, var1, var2, var3, var4, var5, false);
   }

   public IBI method5190(int[] var1, int var2, int var3, int var4, int var5, boolean var6) {
      return new fa(this, var1, var2, var3, var4, var5, false);
   }

   public int method5126(int var1, int var2) {
      int var3 = var1 & 1048575;
      int var4 = var2 & 1048575;
      return var3 & var4 ^ var4;
   }

   public IBI method5101(RFI var1, boolean var2) {
      fa var3 = new fa(this, var1.J, var1.S, var1.A, 0, var1.Z, var1.Z, var1.F);
      var3.method621(var1.D, var1.I, var1.B, var1.C);
      return var3;
   }

   public IBI method5108(int var1, int var2, int var3, int var4, boolean var5) {
      return new fa(this, var1, var2, var3, var4, !var5);
   }

   public QJI method5109(int var1, int var2, int[] var3, int[] var4) {
      return new wa(this, this.aBa6682, var1, var2, var3, var4);
   }

   public void method5154() {
   }

   native void AA(float[] var1);

   public void method5047(boolean var1) {
   }

   public native void fo(int var1, int var2, int var3, int var4, int var5, int var6, byte[] var7, int var8, int var9);

   public OS method5113(LZI var1, RFI[] var2, boolean var3) {
      int[] var4 = new int[var2.length];
      int[] var5 = new int[var2.length];
      boolean var6 = false;

      for(int var7 = 0; var7 < var2.length; ++var7) {
         var4[var7] = var2[var7].Z;
         var5[var7] = var2[var7].F;
         if (var2[var7].A != null) {
            var6 = true;
         }
      }

      if (var3) {
         if (var6) {
            return new ea(this, this.aBa6682, var1, var2, (IBI[])null);
         } else {
            return new m(this, this.aBa6682, var1, var2, (IBI[])null);
         }
      } else if (var6) {
         throw new IllegalArgumentException("");
      } else {
         return new ia(this, this.aBa6682, var1, var2, (IBI[])null);
      }
   }

   public boolean method5074() {
      return true;
   }

   public native void m(int var1, float var2, float var3, float var4, float var5, float var6);

   public boolean method5052() {
      return false;
   }

   public void method5056(int var1, int var2, int var3, int var4) {
   }

   public int method5118(int var1, int var2) {
      int var3 = var1 & 1048575;
      int var4 = var2 & 1048575;
      return var3 & var4 ^ var4;
   }

   public int method5024(int var1, int var2) {
      int var3 = var1 & 1048575;
      int var4 = var2 & 1048575;
      return var3 & var4 ^ var4;
   }

   public int method5120(int var1, int var2) {
      int var3 = var1 & 1048575;
      int var4 = var2 & 1048575;
      return var3 & var4 ^ var4;
   }

   public YJI method5121(int var1, int var2, int[][] var3, int[][] var4, int var5, int var6, int var7) {
      return new i(this, this.aBa6682, var1, var2, var3, var4, var5, var6, var7);
   }

   public YJI method5122(int var1, int var2, int[][] var3, int[][] var4, int var5, int var6, int var7) {
      return new i(this, this.aBa6682, var1, var2, var3, var4, var5, var6, var7);
   }

   public YJI method5123(int var1, int var2, int[][] var3, int[][] var4, int var5, int var6, int var7) {
      return new i(this, this.aBa6682, var1, var2, var3, var4, var5, var6, var7);
   }

   public YJI method5087(int var1, int var2, int[][] var3, int[][] var4, int var5, int var6, int var7) {
      return new i(this, this.aBa6682, var1, var2, var3, var4, var5, var6, var7);
   }

   public LF method5013() {
      return this.aClass222_6696;
   }

   public LF method5008() {
      return this.aClass222_6696;
   }

   public void method5132(LF var1) {
      this.aClass222_6688 = var1;
      this.aClass233_6689.I(var1);
      this.AA(this.aClass233_6689.I);
      this.aClass233_6683.I(this.aClass233_6689, this.aClass233_6690);
   }

   public QJI method5110(int var1, int var2, int[] var3, int[] var4) {
      return new wa(this, this.aBa6682, var1, var2, var3, var4);
   }

   native void PA(za var1);

   public void method5129(LF var1) {
      this.aClass222_6688 = var1;
      this.aClass233_6689.I(var1);
      this.AA(this.aClass233_6689.I);
      this.aClass233_6683.I(this.aClass233_6689, this.aClass233_6690);
   }

   public void method5130(LF var1) {
      this.aClass222_6688 = var1;
      this.aClass233_6689.I(var1);
      this.AA(this.aClass233_6689.I);
      this.aClass233_6683.I(this.aClass233_6689, this.aClass233_6690);
   }

   public void method5096(int var1, int var2, int var3, int var4, int var5, int var6, QJI var7, int var8, int var9) {
      this.R(var1, var2, var3, var4, var5, var6, var7, var8, var9);
   }

   public void method4991(int var1, int var2, int var3, int var4) {
   }

   public void method5133(YF var1) {
      this.aClass233_6690 = var1;
      this.wa(this.aClass233_6690.I);
      this.aClass233_6683.I(this.aClass233_6689, this.aClass233_6690);
   }

   native void YA(int var1, int var2, int var3, int var4, int var5, int var6);

   public boolean method4994() {
      return true;
   }

   OCI method5006(Canvas var1, int var2, int var3) {
      return new za(this, var1, var2, var3);
   }

   public void method4997(int var1, GE[] var2) {
      int var3 = 0;

      for(int var4 = 0; var4 < var1; ++var4) {
         anIntArray6705[var3++] = var2[var4].B(823958259);
         anIntArray6705[var3++] = var2[var4].C(-417421408);
         anIntArray6705[var3++] = var2[var4].I((byte)4);
         anIntArray6705[var3++] = var2[var4].F(-642441246);
         aFloatArray6706[var4] = var2[var4].J(608404512);
         anIntArray6705[var3++] = var2[var4].D(-1322756012);
      }

      this.Q(var1, anIntArray6705, aFloatArray6706);
   }

   public IBI method5105(int[] var1, int var2, int var3, int var4, int var5, boolean var6) {
      return new fa(this, var1, var2, var3, var4, var5, false);
   }

   public native void hv(int var1, int var2, int var3);

   public native void hj(int var1, int var2, int var3);

   public native void hn(int var1, int var2, int var3);

   public native void he(int var1, int var2, int var3);

   public void method5137(boolean var1) {
   }

   public void method5184(boolean var1) {
   }

   public OBI method5185(int var1, int var2, int var3, int var4, int var5, int var6) {
      return null;
   }

   public OBI method5140(int var1, int var2, int var3, int var4, int var5, int var6) {
      return null;
   }

   public OBI method5181(int var1, int var2, int var3, int var4, int var5, int var6) {
      return null;
   }

   public OBI method5084(int var1, int var2, int var3, int var4, int var5, int var6) {
      return null;
   }

   public OBI method4986(OBI var1, OBI var2, float var3, OBI var4) {
      return null;
   }

   public SBI method5063() {
      return new SBI(0, "SSE", 1, "CPU", 0L);
   }

   void h() {
      System.gc();
      System.runFinalization();
      ZDI.I((byte)3);
   }

   boolean SA(short var1) {
      FEI var2 = this.LZ;
      synchronized(this.LZ) {
         WCI var3 = this.LZ.method174(var1, 1155250631);
         boolean var6;
         if (var3 == null) {
            var6 = false;
            return var6;
         } else if (!this.LZ.method170(var1, (short)29433)) {
            var6 = false;
            return var6;
         } else {
            int[] var4;
            if (var3.F * -2138060883 != 2) {
               var4 = this.LZ.method171(var1, 0.7F, 128, 128, true, 1135790918);
            } else {
               var4 = this.LZ.method172(var1, 0.7F, 128, 128, true, (byte)2);
            }

            this.F(var1, var4, var3.A, var3.F * -2138060883, var3.J, var3.K, var3.S * 1616831825, var3.Z, var3.E, var3.G, var3.H, var3.I, var3.B, var3.M, var3.D, var3.N, var3.O, var3.L, var3.P, var3.Q, var3.C * -490972023);
            return true;
         }
      }
   }

   public boolean method5144() {
      return false;
   }

   public native void IA(float var1);

   void method5141() {
      if (!this.aBoolean6684) {
         this.anAArray6697 = null;
         this.aBa6682 = null;
         this.aClass233_6686 = null;

         for(ba var1 = (ba)this.aClass453_6680.Z(1766612795); var1 != null; var1 = (ba)this.aClass453_6680.B(49146)) {
            var1.ha();
         }

         this.aClass453_6680.I((byte)1);
         this.da();
         if (this.aBoolean6713) {
            JF.I(false, true, (short)8528);
            this.aBoolean6713 = false;
         }

         this.h();
         ZDI.Z(-1408959178);
         this.aBoolean6684 = true;
      }

   }

   native void om(float[] var1);

   public boolean method5148() {
      return false;
   }

   public boolean method5149() {
      return false;
   }

   public int method5025(int var1, int var2, int var3, int var4, int var5, int var6) {
      int var7 = 0;
      float var8 = this.aClass233_6683.I[14] + this.aClass233_6683.I[2] * (float)var1 + this.aClass233_6683.I[6] * (float)var2 + this.aClass233_6683.I[10] * (float)var3;
      float var9 = this.aClass233_6683.I[14] + this.aClass233_6683.I[2] * (float)var4 + this.aClass233_6683.I[6] * (float)var5 + this.aClass233_6683.I[10] * (float)var6;
      float var10 = this.aClass233_6683.I[15] + this.aClass233_6683.I[3] * (float)var1 + this.aClass233_6683.I[7] * (float)var2 + this.aClass233_6683.I[11] * (float)var3;
      float var11 = this.aClass233_6683.I[15] + this.aClass233_6683.I[3] * (float)var4 + this.aClass233_6683.I[7] * (float)var5 + this.aClass233_6683.I[11] * (float)var6;
      if (var8 < -var10 && var9 < -var11) {
         var7 |= 16;
      } else if (var8 > var10 && var9 > var11) {
         var7 |= 32;
      }

      float var12 = this.aClass233_6683.I[12] + this.aClass233_6683.I[0] * (float)var1 + this.aClass233_6683.I[4] * (float)var2 + this.aClass233_6683.I[8] * (float)var3;
      float var13 = this.aClass233_6683.I[12] + this.aClass233_6683.I[0] * (float)var4 + this.aClass233_6683.I[4] * (float)var5 + this.aClass233_6683.I[8] * (float)var6;
      if (var12 < -var10 && var13 < -var11) {
         var7 |= 1;
      }

      if (var12 > var10 && var13 > var11) {
         var7 |= 2;
      }

      float var14 = this.aClass233_6683.I[13] + this.aClass233_6683.I[1] * (float)var1 + this.aClass233_6683.I[5] * (float)var2 + this.aClass233_6683.I[9] * (float)var3;
      float var15 = this.aClass233_6683.I[13] + this.aClass233_6683.I[1] * (float)var4 + this.aClass233_6683.I[5] * (float)var5 + this.aClass233_6683.I[9] * (float)var6;
      if (var14 < -var10 && var15 < -var11) {
         var7 |= 4;
      }

      if (var14 > var10 && var15 > var11) {
         var7 |= 8;
      }

      return var7;
   }

   native void mi(int var1, int var2, int var3, int var4, int var5, int var6, QJI var7, int var8, int var9);

   public void method5175() {
   }

   public void method5153() {
   }

   void method5188(float var1, float var2, float var3, float var4, float var5, float var6) {
   }

   public final void method5155(int var1, ADI var2) {
      this.M(var1, var2.Z * -1212608691, var2.I * 1996750669, var2.C * -1475891183);
   }

   public final void method5156(int var1, ADI var2) {
      this.M(var1, var2.Z * -1212608691, var2.I * 1996750669, var2.C * -1475891183);
   }

   public final void method5089(int var1, ADI var2) {
      this.JA(var1, var2.Z * -1212608691, var2.I * 1996750669, var2.C * -1475891183);
   }

   public native void hu(float var1);

   public native void iv();

   public void method5157(int var1, int var2, float var3, int var4, int var5, float var6, int var7, int var8, float var9, int var10, int var11, int var12, int var13) {
      throw new IllegalStateException();
   }

   public void method5158(int var1, int var2, float var3, int var4, int var5, float var6, int var7, int var8, float var9, int var10, int var11, int var12, int var13) {
      throw new IllegalStateException();
   }

   public void method5139(int var1, int var2, float var3, int var4, int var5, float var6, int var7, int var8, float var9, int var10, int var11, int var12, int var13) {
      throw new IllegalStateException();
   }

   native void od(int var1, int var2, int var3, int var4);

   public void method5161(float var1, float var2, float var3, float[] var4) {
      float var5 = this.aClass233_6683.I[15] + this.aClass233_6683.I[3] * var1 + this.aClass233_6683.I[7] * var2 + this.aClass233_6683.I[11] * var3;
      float var6 = this.aClass233_6683.I[12] + this.aClass233_6683.I[0] * var1 + this.aClass233_6683.I[4] * var2 + this.aClass233_6683.I[8] * var3;
      float var7 = this.aClass233_6683.I[13] + this.aClass233_6683.I[1] * var1 + this.aClass233_6683.I[5] * var2 + this.aClass233_6683.I[9] * var3;
      float var8 = this.aClass233_6689.I[14] + this.aClass233_6689.I[2] * var1 + this.aClass233_6689.I[6] * var2 + this.aClass233_6689.I[10] * var3;
      var4[0] = this.aFloat6687 + this.aFloat6695 * var6 / var5;
      var4[1] = this.aFloat6691 + this.aFloat6694 * var7 / var5;
      var4[2] = var8;
   }

   public native void ih();

   public void method5055(float var1, float var2, float var3, float[] var4) {
      float var5 = this.aClass233_6683.I[14] + this.aClass233_6683.I[2] * var1 + this.aClass233_6683.I[6] * var2 + this.aClass233_6683.I[10] * var3;
      float var6 = this.aClass233_6683.I[15] + this.aClass233_6683.I[3] * var1 + this.aClass233_6683.I[7] * var2 + this.aClass233_6683.I[11] * var3;
      if (var5 >= -var6 && var5 <= var6) {
         float var7 = this.aClass233_6683.I[12] + this.aClass233_6683.I[0] * var1 + this.aClass233_6683.I[4] * var2 + this.aClass233_6683.I[8] * var3;
         if (var7 >= -var6 && var7 <= var6) {
            float var8 = this.aClass233_6683.I[13] + this.aClass233_6683.I[1] * var1 + this.aClass233_6683.I[5] * var2 + this.aClass233_6683.I[9] * var3;
            if (var8 >= -var6 && var8 <= var6) {
               float var9 = this.aClass233_6689.I[14] + this.aClass233_6689.I[2] * var1 + this.aClass233_6689.I[6] * var2 + this.aClass233_6689.I[10] * var3;
               var4[0] = this.aFloat6687 + this.aFloat6695 * var7 / var6;
               var4[1] = this.aFloat6691 + this.aFloat6694 * var8 / var6;
               var4[2] = var9;
            } else {
               var4[2] = Float.NaN;
               var4[1] = Float.NaN;
               var4[0] = Float.NaN;
            }
         } else {
            var4[2] = Float.NaN;
            var4[1] = Float.NaN;
            var4[0] = Float.NaN;
         }
      } else {
         var4[2] = Float.NaN;
         var4[1] = Float.NaN;
         var4[0] = Float.NaN;
      }

   }

   public void method5164(float var1, float var2, float var3, float[] var4) {
      float var5 = this.aClass233_6683.I[14] + this.aClass233_6683.I[2] * var1 + this.aClass233_6683.I[6] * var2 + this.aClass233_6683.I[10] * var3;
      float var6 = this.aClass233_6683.I[15] + this.aClass233_6683.I[3] * var1 + this.aClass233_6683.I[7] * var2 + this.aClass233_6683.I[11] * var3;
      if (var5 >= -var6 && var5 <= var6) {
         float var7 = this.aClass233_6683.I[12] + this.aClass233_6683.I[0] * var1 + this.aClass233_6683.I[4] * var2 + this.aClass233_6683.I[8] * var3;
         if (var7 >= -var6 && var7 <= var6) {
            float var8 = this.aClass233_6683.I[13] + this.aClass233_6683.I[1] * var1 + this.aClass233_6683.I[5] * var2 + this.aClass233_6683.I[9] * var3;
            if (var8 >= -var6 && var8 <= var6) {
               float var9 = this.aClass233_6689.I[14] + this.aClass233_6689.I[2] * var1 + this.aClass233_6689.I[6] * var2 + this.aClass233_6689.I[10] * var3;
               var4[0] = this.aFloat6687 + this.aFloat6695 * var7 / var6;
               var4[1] = this.aFloat6691 + this.aFloat6694 * var8 / var6;
               var4[2] = var9;
            } else {
               var4[2] = Float.NaN;
               var4[1] = Float.NaN;
               var4[0] = Float.NaN;
            }
         } else {
            var4[2] = Float.NaN;
            var4[1] = Float.NaN;
            var4[0] = Float.NaN;
         }
      } else {
         var4[2] = Float.NaN;
         var4[1] = Float.NaN;
         var4[0] = Float.NaN;
      }

   }

   public boolean method4998() {
      return true;
   }

   public native void O();

   synchronized void method5573() {
      this.H(336698672);
      if (this.nativeid != 0L) {
         ZDI.I(this, (short)12675);
      }

   }

   public boolean method5166() {
      return false;
   }

   public void method5167(int var1, int var2, int var3, int var4, int var5, int var6) {
      this.YA(var1, var2, var3, var4, var5, var6);
   }

   native void ox(int var1, int var2, int var3, int var4);

   public void method5010(int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      this.method5571().method286(this, var1, var2, var3, var4, var5, var6, var7);
   }

   public int method5170(int var1, int var2) {
      return var1 | var2;
   }

   public void method5090(int var1, int var2, int var3, int var4) {
      this.aFloat6695 = (float)var3 / 2.0F;
      this.aFloat6694 = (float)var4 / 2.0F;
      this.aFloat6687 = (float)var1 + this.aFloat6695;
      this.aFloat6691 = (float)var2 + this.aFloat6694;
      this.A(var1, var2, var3, var4);
   }

   public LF method5171() {
      return this.aClass222_6688;
   }

   public YF method5172() {
      return this.aClass233_6690;
   }

   public YF method5124() {
      return this.aClass233_6690;
   }

   public int method5177() {
      return 4;
   }

   public native void hs(float var1);

   public native void go(int var1, QJI var2, int var3, int var4);

   native void ms(FEI var1, int var2, int var3);

   native void mx(FEI var1, int var2, int var3);

   public void method5085(boolean var1) {
   }

   native void me(int var1, int var2, int var3, int var4, int var5, int var6);

   native void mz(int var1, int var2, int var3, int var4, int var5, int var6, QJI var7, int var8, int var9);

   public LF method5183() {
      return this.aClass222_6696;
   }

   public IBI method5107(RFI var1, boolean var2) {
      fa var3 = new fa(this, var1.J, var1.S, var1.A, 0, var1.Z, var1.Z, var1.F);
      var3.method621(var1.D, var1.I, var1.B, var1.C);
      return var3;
   }

   native void mn();

   native void ne();

   public UT method5116(MBI var1, int var2, int var3, int var4, int var5) {
      return new h(this, this.aBa6682, var1, var2, var3, var4, var5);
   }

   native void ng(int var1);

   native void nt(VJI var1);

   native void nl(VJI var1);

   native void nh(int var1, int[] var2, float[] var3);

   public void method5061(boolean var1) {
   }

   native void no(short var1, short var2, int var3, byte var4, byte var5, int var6, boolean var7, byte var8, byte var9, byte var10, byte var11, boolean var12, boolean var13, boolean var14, boolean var15, boolean var16, byte var17, boolean var18, boolean var19, int var20);

   public QJI method5034(int var1, int var2, int[] var3, int[] var4) {
      return new wa(this, this.aBa6682, var1, var2, var3, var4);
   }

   native void ni(short var1, short var2, int var3, byte var4, byte var5, int var6, boolean var7, byte var8, byte var9, byte var10, byte var11, boolean var12, boolean var13, boolean var14, boolean var15, boolean var16, byte var17, boolean var18, boolean var19, int var20);

   native void nu(za var1);

   native void np(long var1, long var3);

   native void ny(long var1, long var3);

   native void mb(int var1, int var2, int var3, int var4, int var5, int var6, QJI var7, int var8, int var9);

   native void nj();

   native void nw();

   native void nx(int var1, int var2, int var3, int var4);

   native void nk(int var1, int var2, int var3, int var4);

   native void nc(int var1, int[] var2, float[] var3);

   public YJI method5040(int var1, int var2, int[][] var3, int[][] var4, int var5, int var6, int var7) {
      return new i(this, this.aBa6682, var1, var2, var3, var4, var5, var6, var7);
   }

   public boolean method5111() {
      return true;
   }

   public int method5100(int var1, int var2, int var3, int var4, int var5, int var6) {
      int var7 = 0;
      float var8 = this.aClass233_6683.I[14] + this.aClass233_6683.I[2] * (float)var1 + this.aClass233_6683.I[6] * (float)var2 + this.aClass233_6683.I[10] * (float)var3;
      float var9 = this.aClass233_6683.I[14] + this.aClass233_6683.I[2] * (float)var4 + this.aClass233_6683.I[6] * (float)var5 + this.aClass233_6683.I[10] * (float)var6;
      float var10 = this.aClass233_6683.I[15] + this.aClass233_6683.I[3] * (float)var1 + this.aClass233_6683.I[7] * (float)var2 + this.aClass233_6683.I[11] * (float)var3;
      float var11 = this.aClass233_6683.I[15] + this.aClass233_6683.I[3] * (float)var4 + this.aClass233_6683.I[7] * (float)var5 + this.aClass233_6683.I[11] * (float)var6;
      if (var8 < -var10 && var9 < -var11) {
         var7 |= 16;
      } else if (var8 > var10 && var9 > var11) {
         var7 |= 32;
      }

      float var12 = this.aClass233_6683.I[12] + this.aClass233_6683.I[0] * (float)var1 + this.aClass233_6683.I[4] * (float)var2 + this.aClass233_6683.I[8] * (float)var3;
      float var13 = this.aClass233_6683.I[12] + this.aClass233_6683.I[0] * (float)var4 + this.aClass233_6683.I[4] * (float)var5 + this.aClass233_6683.I[8] * (float)var6;
      if (var12 < -var10 && var13 < -var11) {
         var7 |= 1;
      }

      if (var12 > var10 && var13 > var11) {
         var7 |= 2;
      }

      float var14 = this.aClass233_6683.I[13] + this.aClass233_6683.I[1] * (float)var1 + this.aClass233_6683.I[5] * (float)var2 + this.aClass233_6683.I[9] * (float)var3;
      float var15 = this.aClass233_6683.I[13] + this.aClass233_6683.I[1] * (float)var4 + this.aClass233_6683.I[5] * (float)var5 + this.aClass233_6683.I[9] * (float)var6;
      if (var14 < -var10 && var15 < -var11) {
         var7 |= 4;
      }

      if (var14 > var10 && var15 > var11) {
         var7 |= 8;
      }

      return var7;
   }

   public void method5098(int var1, int var2, int var3, int var4, int var5, int var6, QJI var7, int var8, int var9, int var10, int var11, int var12) {
   }

   public final void method5058(int var1, ADI var2) {
      this.JA(var1, var2.Z * -1212608691, var2.I * 1996750669, var2.C * -1475891183);
   }

   native void wa(float[] var1);

   native void F(short var1, int[] var2, short var3, int var4, byte var5, byte var6, int var7, boolean var8, byte var9, byte var10, byte var11, byte var12, boolean var13, boolean var14, boolean var15, boolean var16, boolean var17, byte var18, boolean var19, boolean var20, int var21);

   native void ou(int var1, int var2, int var3, int var4);

   native void oj(int var1, int var2, int var3, int var4);

   public native void ma(boolean var1);

   native void oz(int var1, int var2, int var3, int var4);
}
