public class BZ implements MAI {
   IBI I;
   EC Z;
   KJ S;
   public static int[] C;

   public void method55() {
      this.I = NV.I(this.S, -610589451 * this.Z.C, (byte)-80);
   }

   public void method53(int var1) {
      try {
         this.I = NV.I(this.S, -610589451 * this.Z.C, (byte)-10);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "fm.a(" + ')');
      }
   }

   public void method58(boolean var1, byte var2) {
      try {
         if (var1) {
            int var3 = this.Z.Z.I(this.I.method271(), XEI.BC * 775068819, -2059315000) + -245579987 * this.Z.B;
            int var4 = this.Z.D.I(this.I.method626(), XEI.KC * -791746413, -1363619703) + this.Z.I * -1426302101;
            this.I.I(var3, var4);
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "fm.f(" + ')');
      }
   }

   public boolean method52(int var1) {
      try {
         return this.S.D(-610589451 * this.Z.C, -457216440);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "fm.b(" + ')');
      }
   }

   public void method56(boolean var1) {
      if (var1) {
         int var2 = this.Z.Z.I(this.I.method271(), XEI.BC * 775068819, -2133654536) + -245579987 * this.Z.B;
         int var3 = this.Z.D.I(this.I.method626(), XEI.KC * -791746413, -1742244574) + this.Z.I * -1426302101;
         this.I.I(var2, var3);
      }

   }

   public boolean method54() {
      return this.S.D(-610589451 * this.Z.C, -457216440);
   }

   public boolean method57() {
      return this.S.D(-610589451 * this.Z.C, -457216440);
   }

   BZ(KJ var1, EC var2) {
      this.S = var1;
      this.Z = var2;
   }

   public boolean method59() {
      return this.S.D(-610589451 * this.Z.C, -457216440);
   }

   public static void I(int var0, int var1, int var2, int var3) {
      try {
         var2 = var2 * FW.J.p.I(-2142096131) >> 8;
         if (var2 != 0 && var0 != -1) {
            if (!AN.D && -1256171511 * AN.B != -1 && WBI.I(87442639) && !KFI.I((byte)9)) {
               BG.A = BB.I(34386078);
               TR.I((short)1644);
               XE var4 = GDI.I(BG.A, -1213425929);
               WBI.I(true, var4, 1899476415);
            }

            YY.I(HY.D, var0, 0, var2, false, -1993911100);
            IP.I(-1, 255, -1975547626);
            AN.D = true;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "fm.c(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         RDI.I(var3, var4, var0, 2141482523);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "fm.in(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = XEI.YD;
         var0.H[(var0.J += -391880689) * 681479919 - 1] = XEI.iD;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "fm.akc(" + ')');
      }
   }

   static Class I(String var0, byte var1) throws ClassNotFoundException {
      try {
         if (var0.equals("B")) {
            return Byte.TYPE;
         } else if (var0.equals("I")) {
            return Integer.TYPE;
         } else if (var0.equals("S")) {
            return Short.TYPE;
         } else if (var0.equals("J")) {
            return Long.TYPE;
         } else if (var0.equals("Z")) {
            return Boolean.TYPE;
         } else if (var0.equals("F")) {
            return Float.TYPE;
         } else if (var0.equals("D")) {
            return Double.TYPE;
         } else if (var0.equals("C")) {
            return Character.TYPE;
         } else {
            return var0.equals("void") ? Void.TYPE : var0.getClass();
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "fm.i(" + ')');
      }
   }

   public static final void I(int var0, int var1, int var2, int var3, int var4, int var5, int var6) {
      try {
         if (var0 >= DT.D * -1424479739 && var1 <= DT.Z * 1135094847 && var2 >= 1155384281 * DT.C && var3 <= DT.B * -1062447355) {
            if (1 == var5) {
               OR.I(var0, var1, var2, var3, var4, -616636288);
            } else {
               KR.I(var0, var1, var2, var3, var4, var5, 1228342009);
            }
         } else if (1 == var5) {
            NO.I(var0, var1, var2, var3, var4, (byte)16);
         } else {
            VJI.I(var0, var1, var2, var3, var4, var5, 630835292);
         }

      } catch (RuntimeException var8) {
         throw DQ.I(var8, "fm.r(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         boolean var2 = var0.H[(var0.J -= -391880689) * 681479919] != 0;
         if (UA.F.xI != null) {
            UA.F.xI.I(var2, -635669328);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "fm.cw(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = SEI.C(FW.J.d.I(-1033655497), 200, -564822941);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "fm.akd(" + ')');
      }
   }
}
