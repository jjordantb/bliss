import jaggl.OpenGL;

public class FI extends BI {
   int b;
   OJI glUseProgram;
   N method1221;

   public void method1355() {
      if (this.glUseProgram.JZ != this.method1221) {
         if (this.method1221 == null) {
            throw new RuntimeException_Sub1();
         }

         OpenGL.glUseProgram(this.b);
         this.glUseProgram.JZ = this.method1221;
      }

   }

   void I() {
      for(int var1 = 0; var1 < this.C(-1467018991); ++var1) {
         ((N)this.Z(var1, 862535051)).b();
      }

      super.I();
   }

   public boolean method1331(L var1) {
      if (this.method1221 == var1) {
         return true;
      } else if (!var1.method1221()) {
         return false;
      } else {
         boolean var2 = this.method1374();
         this.method1221 = (N)var1;
         this.I = this.I(var1, -180449856) * -1776466383;
         if (this.I * -33664303 == -1) {
            throw new IllegalArgumentException();
         } else {
            this.b = this.method1221.F;
            if (var2) {
               OpenGL.glUseProgram(this.b);
               this.glUseProgram.JZ = this.method1221;
            }

            return true;
         }
      }
   }

   VG method1367(R var1) {
      return new WG(this, var1);
   }

   public void method1340() {
      if (this.glUseProgram.JZ != this.method1221) {
         if (this.method1221 == null) {
            throw new RuntimeException_Sub1();
         }

         OpenGL.glUseProgram(this.b);
         this.glUseProgram.JZ = this.method1221;
      }

   }

   public void method1372() {
   }

   public boolean method1374() {
      return this.glUseProgram.JZ == this.method1221;
   }

   public void method1358() {
   }

   public void method1354() {
      if (this.glUseProgram.JZ != this.method1221) {
         if (this.method1221 == null) {
            throw new RuntimeException_Sub1();
         }

         OpenGL.glUseProgram(this.b);
         this.glUseProgram.JZ = this.method1221;
      }

   }

   L method1362(NJI var1, G var2) {
      return new N((OJI)var1, this, var2);
   }

   public void method1373() {
      if (this.glUseProgram.JZ != this.method1221) {
         if (this.method1221 == null) {
            throw new RuntimeException_Sub1();
         }

         OpenGL.glUseProgram(this.b);
         this.glUseProgram.JZ = this.method1221;
      }

   }

   public boolean method1349(L var1) {
      if (this.method1221 == var1) {
         return true;
      } else if (!var1.method1221()) {
         return false;
      } else {
         boolean var2 = this.method1374();
         this.method1221 = (N)var1;
         this.I = this.I(var1, -180449856) * -1776466383;
         if (this.I * -33664303 == -1) {
            throw new IllegalArgumentException();
         } else {
            this.b = this.method1221.F;
            if (var2) {
               OpenGL.glUseProgram(this.b);
               this.glUseProgram.JZ = this.method1221;
            }

            return true;
         }
      }
   }

   public void method1357() {
   }

   public boolean method1375(L var1) {
      if (this.method1221 == var1) {
         return true;
      } else if (!var1.method1221()) {
         return false;
      } else {
         boolean var2 = this.method1374();
         this.method1221 = (N)var1;
         this.I = this.I(var1, -180449856) * -1776466383;
         if (this.I * -33664303 == -1) {
            throw new IllegalArgumentException();
         } else {
            this.b = this.method1221.F;
            if (var2) {
               OpenGL.glUseProgram(this.b);
               this.glUseProgram.JZ = this.method1221;
            }

            return true;
         }
      }
   }

   void b() {
      for(int var1 = 0; var1 < this.C(-1467018991); ++var1) {
         ((N)this.Z(var1, 1695242016)).b();
      }

      super.I();
   }

   public boolean method1371() {
      return this.glUseProgram.JZ == this.method1221;
   }

   public void method1356() {
   }

   L method1361(NJI var1, G var2) {
      return new N((OJI)var1, this, var2);
   }

   VG method1364(R var1) {
      return new WG(this, var1);
   }

   FI(OJI var1, H var2) {
      super(var1, var2);
      this.glUseProgram = var1;
   }

   L method1326(NJI var1, G var2) {
      return new N((OJI)var1, this, var2);
   }

   public boolean method1359() {
      return this.glUseProgram.JZ == this.method1221;
   }

   public boolean method1376(L var1) {
      if (this.method1221 == var1) {
         return true;
      } else if (!var1.method1221()) {
         return false;
      } else {
         boolean var2 = this.method1374();
         this.method1221 = (N)var1;
         this.I = this.I(var1, -180449856) * -1776466383;
         if (this.I * -33664303 == -1) {
            throw new IllegalArgumentException();
         } else {
            this.b = this.method1221.F;
            if (var2) {
               OpenGL.glUseProgram(this.b);
               this.glUseProgram.JZ = this.method1221;
            }

            return true;
         }
      }
   }
}
