import jaggl.OpenGL;

public class JP implements VAI {
   int glFramebufferTexture2DEXT;
   int I;
   DO Z;

   JP(DO var1, int var2, int var3) {
      this.I = var3;
      this.Z = var1;
      this.glFramebufferTexture2DEXT = var2;
   }

   public void method1(int var1) {
      OpenGL.glFramebufferTexture2DEXT(36160, var1, this.glFramebufferTexture2DEXT, this.Z.Z, this.I);
   }

   public int i() {
      return this.Z.M;
   }

   public void method3(int var1) {
      OpenGL.glFramebufferTexture2DEXT(36160, var1, this.glFramebufferTexture2DEXT, this.Z.Z, this.I);
   }

   public void b() {
   }

   public int p() {
      return this.Z.M;
   }

   public int f() {
      return this.Z.M;
   }

   public int k() {
      return this.Z.M;
   }

   public void d() {
   }

   public void u() {
   }

   public void x() {
   }

   public void method2(int var1) {
      OpenGL.glFramebufferTexture2DEXT(36160, var1, this.glFramebufferTexture2DEXT, this.Z.Z, this.I);
   }

   public int a() {
      return this.Z.M;
   }

   public void method4(int var1) {
      OpenGL.glFramebufferTexture2DEXT(36160, var1, this.glFramebufferTexture2DEXT, this.Z.Z, this.I);
   }
}
