public class CG extends WE {
   XE append;
   FY G = new FY();
   ZG H = new ZG();

   void I(HE var1, int[] var2, int var3, int var4, int var5, int var6) {
      try {
         if ((this.append.V[70539643 * var1.Y] & 4) != 0 && var1.T * 1595133323 < 0) {
            int var7 = this.append.i[var1.Y * 70539643] / (PA.F * 1164070869);

            while(true) {
               int var8 = (1048575 + var7 - -327753205 * var1.i) / var7;
               if (var8 > var4) {
                  var1.i += var4 * var7 * -460252765;
                  break;
               }

               var1.W.method2934(var2, var3, var8);
               var3 += var8;
               var4 -= var8;
               var1.i += (var7 * var8 - 1048576) * -460252765;
               int var9 = PA.F * 1164070869 / 100;
               int var10 = 262144 / var7;
               if (var10 < var9) {
                  var9 = var10;
               }

               YE var11 = var1.W;
               if (this.append.X[70539643 * var1.Y] == 0) {
                  var1.W = YE.I(var1.A, var11.F(), var11.J(), var11.Z());
               } else {
                  var1.W = YE.I(var1.A, var11.F(), 0, var11.Z());
                  this.append.I((HE)var1, var1.U.G[var1.H * 1458878633] < 0, (byte)1);
                  var1.W.Z(var9, var11.J());
               }

               if (var1.U.G[var1.H * 1458878633] < 0) {
                  var1.W.B(-1);
               }

               var11.F(var9);
               var11.method2934(var2, var3, var5 - var3);
               if (var11.D()) {
                  this.H.I(var11);
               }
            }
         }

         var1.W.method2934(var2, var3, var4);
      } catch (RuntimeException var12) {
         throw DQ.I(var12, "ait.av(" + ')');
      }
   }

   WE method2930() {
      try {
         HE var1 = (HE)this.G.Z(1312741945);
         if (var1 == null) {
            return null;
         } else {
            return (WE)(var1.W != null ? var1.W : this.method2931());
         }
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "ait.f(" + ')');
      }
   }

   WE method2931() {
      try {
         HE var1;
         do {
            var1 = (HE)this.G.Z((byte)-51);
            if (var1 == null) {
               return null;
            }
         } while(var1.W == null);

         return var1.W;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "ait.b(" + ')');
      }
   }

   int method2929() {
      return 0;
   }

   CG(XE var1) {
      this.append = var1;
   }

   WE method2938() {
      HE var1 = (HE)this.G.Z(1592221798);
      if (var1 == null) {
         return null;
      } else {
         return (WE)(var1.W != null ? var1.W : this.method2931());
      }
   }

   int method2942() {
      return 0;
   }

   void append(HE var1, int var2, int var3) {
      try {
         if ((this.append.V[70539643 * var1.Y] & 4) != 0 && 1595133323 * var1.T < 0) {
            int var4 = this.append.i[70539643 * var1.Y] / (1164070869 * PA.F);
            int var5 = (var4 + 1048575 - -327753205 * var1.i) / var4;
            var1.i = -460252765 * (var2 * var4 + var1.i * -327753205 & 1048575);
            if (var5 <= var2) {
               if (this.append.X[var1.Y * 70539643] == 0) {
                  var1.W = YE.I(var1.A, var1.W.F(), var1.W.J(), var1.W.Z());
               } else {
                  var1.W = YE.I(var1.A, var1.W.F(), 0, var1.W.Z());
                  this.append.I((HE)var1, var1.U.G[var1.H * 1458878633] < 0, (byte)1);
               }

               if (var1.U.G[var1.H * 1458878633] < 0) {
                  var1.W.B(-1);
               }

               var2 = var1.i * -327753205 / var4;
            }
         }

         var1.W.method2935(var2);
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ait.at(" + ')');
      }
   }

   WE method2944() {
      HE var1 = (HE)this.G.Z(1939327453);
      if (var1 == null) {
         return null;
      } else {
         return (WE)(var1.W != null ? var1.W : this.method2931());
      }
   }

   WE method2937() {
      HE var1 = (HE)this.G.Z(1962198238);
      if (var1 == null) {
         return null;
      } else {
         return (WE)(var1.W != null ? var1.W : this.method2931());
      }
   }

   void method2934(int[] var1, int var2, int var3) {
      try {
         this.H.method2934(var1, var2, var3);

         for(HE var4 = (HE)this.G.Z(1804222944); var4 != null; var4 = (HE)this.G.Z((byte)-61)) {
            if (!this.append.I(var4, (byte)49)) {
               int var5 = var2;
               int var6 = var3;

               do {
                  if (var6 <= -129654463 * var4.X) {
                     this.I(var4, var1, var5, var6, var6 + var5, 2107590773);
                     var4.X -= 718794433 * var6;
                     break;
                  }

                  this.I(var4, var1, var5, -129654463 * var4.X, var5 + var6, 1945030807);
                  var5 += -129654463 * var4.X;
                  var6 -= -129654463 * var4.X;
               } while(!this.append.I(var4, var1, var5, var6, 308349107));
            }
         }

      } catch (RuntimeException var7) {
         throw DQ.I(var7, "ait.k(" + ')');
      }
   }

   int method2943() {
      return 0;
   }

   WE method2939() {
      HE var1 = (HE)this.G.Z(1902536390);
      if (var1 == null) {
         return null;
      } else {
         return (WE)(var1.W != null ? var1.W : this.method2931());
      }
   }

   int method2936() {
      return 0;
   }

   WE method2941() {
      HE var1;
      do {
         var1 = (HE)this.G.Z((byte)-20);
         if (var1 == null) {
            return null;
         }
      } while(var1.W == null);

      return var1.W;
   }

   void method2948(int var1) {
      this.H.method2935(var1);

      for(HE var2 = (HE)this.G.Z(1342928995); var2 != null; var2 = (HE)this.G.Z((byte)-97)) {
         if (!this.append.I(var2, (byte)62)) {
            int var3 = var1;

            do {
               if (var3 <= -129654463 * var2.X) {
                  this.append(var2, var3, -1423260065);
                  var2.X -= var3 * 718794433;
                  break;
               }

               this.append(var2, -129654463 * var2.X, -1278171875);
               var3 -= var2.X * -129654463;
            } while(!this.append.I(var2, (int[])null, 0, var3, -657565071));
         }
      }

   }

   void method2935(int var1) {
      try {
         this.H.method2935(var1);

         for(HE var2 = (HE)this.G.Z(1563549422); var2 != null; var2 = (HE)this.G.Z((byte)-111)) {
            if (!this.append.I(var2, (byte)51)) {
               int var3 = var1;

               do {
                  if (var3 <= -129654463 * var2.X) {
                     this.append(var2, var3, -2140903292);
                     var2.X -= var3 * 718794433;
                     break;
                  }

                  this.append(var2, -129654463 * var2.X, -1211758254);
                  var3 -= var2.X * -129654463;
               } while(!this.append.I(var2, (int[])null, 0, var3, -1621498050));
            }
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ait.d(" + ')');
      }
   }

   void method2932(int[] var1, int var2, int var3) {
      this.H.method2934(var1, var2, var3);

      for(HE var4 = (HE)this.G.Z(1337915005); var4 != null; var4 = (HE)this.G.Z((byte)-57)) {
         if (!this.append.I(var4, (byte)-37)) {
            int var5 = var2;
            int var6 = var3;

            do {
               if (var6 <= -129654463 * var4.X) {
                  this.I(var4, var1, var5, var6, var6 + var5, 955925823);
                  var4.X -= 718794433 * var6;
                  break;
               }

               this.I(var4, var1, var5, -129654463 * var4.X, var5 + var6, 3456667);
               var5 += -129654463 * var4.X;
               var6 -= -129654463 * var4.X;
            } while(!this.append.I(var4, var1, var5, var6, -1959198557));
         }
      }

   }

   void method2928(int[] var1, int var2, int var3) {
      this.H.method2934(var1, var2, var3);

      for(HE var4 = (HE)this.G.Z(1686060186); var4 != null; var4 = (HE)this.G.Z((byte)-84)) {
         if (!this.append.I(var4, (byte)5)) {
            int var5 = var2;
            int var6 = var3;

            do {
               if (var6 <= -129654463 * var4.X) {
                  this.I(var4, var1, var5, var6, var6 + var5, -535844657);
                  var4.X -= 718794433 * var6;
                  break;
               }

               this.I(var4, var1, var5, -129654463 * var4.X, var5 + var6, 1587884521);
               var5 += -129654463 * var4.X;
               var6 -= -129654463 * var4.X;
            } while(!this.append.I(var4, var1, var5, var6, -60228894));
         }
      }

   }

   void method2945(int[] var1, int var2, int var3) {
      this.H.method2934(var1, var2, var3);

      for(HE var4 = (HE)this.G.Z(1507919697); var4 != null; var4 = (HE)this.G.Z((byte)-117)) {
         if (!this.append.I(var4, (byte)-31)) {
            int var5 = var2;
            int var6 = var3;

            do {
               if (var6 <= -129654463 * var4.X) {
                  this.I(var4, var1, var5, var6, var6 + var5, 888947175);
                  var4.X -= 718794433 * var6;
                  break;
               }

               this.I(var4, var1, var5, -129654463 * var4.X, var5 + var6, -1260559674);
               var5 += -129654463 * var4.X;
               var6 -= -129654463 * var4.X;
            } while(!this.append.I(var4, var1, var5, var6, -1973772367));
         }
      }

   }

   WE method2940() {
      HE var1;
      do {
         var1 = (HE)this.G.Z((byte)-92);
         if (var1 == null) {
            return null;
         }
      } while(var1.W == null);

      return var1.W;
   }

   void method2949(int var1) {
      this.H.method2935(var1);

      for(HE var2 = (HE)this.G.Z(1615542283); var2 != null; var2 = (HE)this.G.Z((byte)-58)) {
         if (!this.append.I(var2, (byte)49)) {
            int var3 = var1;

            do {
               if (var3 <= -129654463 * var2.X) {
                  this.append(var2, var3, -1608691527);
                  var2.X -= var3 * 718794433;
                  break;
               }

               this.append(var2, -129654463 * var2.X, -1252817178);
               var3 -= var2.X * -129654463;
            } while(!this.append.I(var2, (int[])null, 0, var3, 388406507));
         }
      }

   }

   WE method2946() {
      HE var1 = (HE)this.G.Z(1374349809);
      if (var1 == null) {
         return null;
      } else {
         return (WE)(var1.W != null ? var1.W : this.method2931());
      }
   }

   void method2947(int var1) {
      this.H.method2935(var1);

      for(HE var2 = (HE)this.G.Z(1835442055); var2 != null; var2 = (HE)this.G.Z((byte)-114)) {
         if (!this.append.I(var2, (byte)-80)) {
            int var3 = var1;

            do {
               if (var3 <= -129654463 * var2.X) {
                  this.append(var2, var3, -1605363259);
                  var2.X -= var3 * 718794433;
                  break;
               }

               this.append(var2, -129654463 * var2.X, -1438243413);
               var3 -= var2.X * -129654463;
            } while(!this.append.I(var2, (int[])null, 0, var3, 93946984));
         }
      }

   }
}
