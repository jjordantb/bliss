public class J {
   long I;
   int Z;
   REI C = new REI((byte[])null);
   int[] B;
   static int D = 2;
   static int F = 0;
   int[] J;
   static int S = 500000;
   int[] A;
   static byte[] E = new byte[]{2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 1, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
   int[] G;
   static int H = 1;
   int K;
   static int L = 3;

   void I(byte[] var1) {
      this.C.S = var1;
      this.C.A = 1164133110;
      int var2 = this.C.C();
      this.Z = this.C.C();
      this.K = 500000;
      this.A = new int[var2];

      int var3;
      int var5;
      for(var3 = 0; var3 < var2; this.C.A += var5 * 116413311) {
         int var4 = this.C.H((byte)54);
         var5 = this.C.H((byte)-51);
         if (var4 == 1297379947) {
            this.A[var3] = this.C.A * 385051775;
            ++var3;
         }
      }

      this.I = 0L;
      this.B = new int[var2];

      for(var3 = 0; var3 < var2; ++var3) {
         this.B[var3] = this.A[var3];
      }

      this.G = new int[var2];
      this.J = new int[var2];
   }

   void I() {
      this.C.S = null;
      this.A = null;
      this.B = null;
      this.G = null;
      this.J = null;
   }

   int Z() {
      return this.B.length;
   }

   void I(int var1) {
      this.C.A = this.B[var1] * 116413311;
   }

   J(byte[] var1) {
      this.I(var1);
   }

   void C() {
      this.C.A = -116413311;
   }

   void Z(int var1) {
      int var2 = this.C.H(1692297361);
      this.G[var1] += var2;
   }

   int C(int var1) {
      int var2 = this.B(var1);
      return var2;
   }

   int B(int var1) {
      byte var2 = this.C.S[this.C.A * 385051775];
      int var5;
      if (var2 < 0) {
         var5 = var2 & 255;
         this.J[var1] = var5;
         this.C.A += 116413311;
      } else {
         var5 = this.J[var1];
      }

      if (var5 != 240 && var5 != 247) {
         return this.I(var1, var5);
      } else {
         int var3 = this.C.H(1692297361);
         if (var5 == 247 && var3 > 0) {
            int var4 = this.C.S[this.C.A * 385051775] & 255;
            if (var4 >= 241 && var4 <= 243 || var4 == 246 || var4 == 248 || var4 >= 250 && var4 <= 252 || var4 == 254) {
               this.C.A += 116413311;
               this.J[var1] = var4;
               return this.I(var1, var4);
            }
         }

         this.C.A += var3 * 116413311;
         return 0;
      }
   }

   int I(int var1, int var2) {
      int var4;
      if (var2 == 255) {
         int var7 = this.C.I();
         var4 = this.C.H(1692297361);
         if (var7 == 47) {
            this.C.A += var4 * 116413311;
            return 1;
         } else if (var7 == 81) {
            int var5 = this.C.B((byte)17);
            var4 -= 3;
            int var6 = this.G[var1];
            this.I += (long)var6 * (long)(this.K - var5);
            this.K = var5;
            this.C.A += var4 * 116413311;
            return 2;
         } else {
            this.C.A += var4 * 116413311;
            return 3;
         }
      } else {
         byte var3 = E[var2 - 128];
         var4 = var2;
         if (var3 >= 1) {
            var4 = var2 | this.C.I() << 8;
         }

         if (var3 >= 2) {
            var4 |= this.C.I() << 16;
         }

         return var4;
      }
   }

   long D(int var1) {
      return this.I + (long)var1 * (long)this.K;
   }

   int B() {
      int var1 = this.B.length;
      int var2 = -1;
      int var3 = Integer.MAX_VALUE;

      for(int var4 = 0; var4 < var1; ++var4) {
         if (this.B[var4] >= 0 && this.G[var4] < var3) {
            var2 = var4;
            var3 = this.G[var4];
         }
      }

      return var2;
   }

   boolean D() {
      int var1 = this.B.length;

      for(int var2 = 0; var2 < var1; ++var2) {
         if (this.B[var2] >= 0) {
            return false;
         }
      }

      return true;
   }

   void F(int var1) {
      this.B[var1] = this.C.A * 385051775;
   }

   boolean F() {
      return this.C.S != null;
   }

   J() {
   }

   void I(long var1) {
      this.I = var1;
      int var3 = this.B.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         this.G[var4] = 0;
         this.J[var4] = 0;
         this.C.A = this.A[var4] * 116413311;
         this.Z(var4);
         this.B[var4] = this.C.A * 385051775;
      }

   }
}
