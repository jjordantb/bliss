public class LJ {
   public static int append = 8;
   public static int charAt = 4;
   static int length = 2;
   public static int toString = 2;
   static int I = 1;
   static int Z = 16;
   public byte[][][] C;

   public void I(int var1) {
      try {
         for(int var2 = 0; var2 < this.C.length; ++var2) {
            for(int var3 = 0; var3 < this.C[0].length; ++var3) {
               for(int var4 = 0; var4 < this.C[0][0].length; ++var4) {
                  this.C[var2][var3][var4] = 0;
               }
            }
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "kf.a(" + ')');
      }
   }

   public boolean I(int var1, int var2, int var3) {
      try {
         if (var1 >= 0 && var2 >= 0 && var1 < this.C[1].length && var2 < this.C[1][var1].length) {
            return (this.C[1][var1][var2] & 2) != 0;
         } else {
            return false;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "kf.f(" + ')');
      }
   }

   public boolean I(int var1, int var2, int var3, int var4, byte var5) {
      try {
         if ((this.C[0][var3][var4] & 2) != 0) {
            return true;
         } else if ((this.C[var2][var3][var4] & 16) != 0) {
            return false;
         } else {
            return this.append(var2, var3, var4, 739061165) == var1;
         }
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "kf.b(" + ')');
      }
   }

   public LJ(int var1, int var2, int var3) {
      this.C = new byte[var1][var2][var3];
   }

   int append(int var1, int var2, int var3, int var4) {
      try {
         if ((this.C[var1][var2][var3] & 8) != 0) {
            return 0;
         } else {
            return var1 > 0 && (this.C[1][var2][var3] & 2) != 0 ? var1 - 1 : var1;
         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "kf.p(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, int var3) {
      try {
         var2.J -= -783761378;
         var0.UI = var2.H[var2.J * 681479919] * 437213185;
         var0.VI = 1266800241 * var2.H[681479919 * var2.J + 1];
         VEI.I(var0, -147880968);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "kf.fq(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.J -= -391880689;
         int var2 = var0.H[var0.J * 681479919];
         OSI var3 = (OSI)XEI.yC.I((long)var2);
         if (var3 != null && 3 == 27137839 * var3.J) {
            BB.I(var3, true, true, -113822480);
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "kf.sh(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         W.I(var2 >> 14 & 16383, var2 & 16383, -548972447);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "kf.aeb(" + ')');
      }
   }

   public static void Z(int var0) {
      try {
         RT.Z(1590487126);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "kf.f(" + ')');
      }
   }

   static void I(byte[] var0, int var1) {
      try {
         REI var2 = new REI(var0);

         while(true) {
            int var3 = var2.I();
            if (var3 == 0) {
               if (var1 == -475561782) {
                  throw new IllegalStateException();
               }

               return;
            }

            if (1 == var3) {
               int var4 = var2.C();
               if (AN.J * 782166935 == -1) {
                  AN.J = var4 * 154813479;
               }
            }
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "kf.x(" + ')');
      }
   }

   public static int I(CharSequence var0, int var1) {
      try {
         int var2 = var0.length();
         int var3 = 0;

         for(int var4 = 0; var4 < var2; ++var4) {
            var3 = (var3 << 5) - var3 + JI.I(var0.charAt(var4), 1088430238);
         }

         return var3;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "kf.r(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         if (var0.H[(var0.J -= -391880689) * 681479919] == 1) {
            var0.i += var0.X[1883543357 * var0.i] * 286750741;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "kf.bw(" + ')');
      }
   }

   public static void I(GEI var0, byte var1) {
      try {
         for(SM var2 = (SM)SM.l.Z(1766612795); var2 != null; var2 = (SM)SM.l.B(49146)) {
            if (var0 == var2.Q) {
               if (var2.f != null) {
                  RA.S.Z(var2.f);
                  var2.f = null;
               }

               var2.I(-1460969981);
               break;
            }
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "kf.k(" + ')');
      }
   }
}
