public class HT {
   public IAI I;
   public static KJ Z;

   public HT(KJ var1) {
      byte[] var2 = var1.I(NT.I.S * -363169051, (byte)11);
      this.I(new REI(var2), 1724191904);
   }

   void I(REI var1, int var2) {
      try {
         while(true) {
            int var3 = var1.I();
            if (var3 == 0) {
               if (var2 != 1724191904) {
                  throw new IllegalStateException();
               }

               return;
            }

            if (1 == var3) {
               this.I = KEI.I(var1, (byte)-47);
            }
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "pr.a(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)58);
         X var4 = IU.F[var2 >> 16];
         CZ.I(var3, var4, var0, 1344346794);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "pr.gl(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.A.Z(-575221319) ? 1 : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "pr.anr(" + ')');
      }
   }

   public static String I(long var0) {
      try {
         if (var0 > 0L && var0 < 6582952005840035281L) {
            if (var0 % 37L == 0L) {
               return null;
            } else {
               int var2 = 0;

               for(long var3 = var0; 0L != var3; var3 /= 37L) {
                  ++var2;
               }

               StringBuilder var7 = new StringBuilder(var2);

               while(0L != var0) {
                  long var4 = var0;
                  var0 /= 37L;
                  var7.append(HV.I[(int)(var4 - 37L * var0)]);
               }

               return var7.reverse().toString();
            }
         } else {
            return null;
         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "pr.f(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, short var3) {
      try {
         var0.GI = var2.H[(var2.J -= -391880689) * 681479919] == 1;
         VEI.I(var0, -275285651);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "pr.fs(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-91);
         X var4 = IU.F[var2 >> 16];
         FU.I(var3, var4, var0, (byte)-121);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "pr.hd(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         if (2 == 1131012101 * XEI.lD && var2 >= 0 && var2 < XEI.kD * -1054937867) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = XEI.rI[var2] ? 1 : 0;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "pr.wt(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.S[(var0.A += 969361751) * -203050393 - 1] = var0.R.M[var2];
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "pr.xw(" + ')');
      }
   }
}
