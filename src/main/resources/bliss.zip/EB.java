public class EB {
   static EB I = new EB();
   public static EB Z = new EB();
}
