public class JFI extends LDI {
   int Z;
   int append;
   static HSI C;

   JFI(REI var1) {
      super(var1);
      this.append = var1.C() * -40183047;
      this.Z = var1.Y(1235052657) * -1186011313;
   }

   public void method866(int var1) {
      try {
         OFI var2 = PFI.J[this.append * -878655671];
         VEI.I(-637425735 * var2.Z, var2.C * -123379955, var2.D * 1400706617, var2.I.X * -6749525, var2.I.V * -1976050083, 1067426701 * var2.F, this.Z * 1204408239, 55517890);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "xd.f(" + ')');
      }
   }

   boolean Z() {
      BU var1 = GZI.C.I(this.Z * 1204408239, (byte)-25);
      return var1.I(509501216);
   }

   boolean Z(int var1) {
      try {
         BU var2 = GZI.C.I(this.Z * 1204408239, (byte)-37);
         return var2.I(706659093);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "xd.p(" + ')');
      }
   }

   public void method869() {
      OFI var1 = PFI.J[this.append * -878655671];
      VEI.I(-637425735 * var1.Z, var1.C * -123379955, var1.D * 1400706617, var1.I.X * -6749525, var1.I.V * -1976050083, 1067426701 * var1.F, this.Z * 1204408239, -944775974);
   }

   public void method868() {
      OFI var1 = PFI.J[this.append * -878655671];
      VEI.I(-637425735 * var1.Z, var1.C * -123379955, var1.D * 1400706617, var1.I.X * -6749525, var1.I.V * -1976050083, 1067426701 * var1.F, this.Z * 1204408239, -1580583180);
   }

   static final void B(OU var0, int var1) {
      try {
         FW.J.I(FW.J.n, var0.H[(var0.J -= -391880689) * 681479919], -2055385599);
         JN.I(656179282);
         XEI.w = false;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "xd.aid(" + ')');
      }
   }

   static long I(byte var0) {
      try {
         return ZE.O.method3794(-489985044);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "xd.aa(" + ')');
      }
   }
}
