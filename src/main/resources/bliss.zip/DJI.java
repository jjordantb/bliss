import java.util.Iterator;
import java.util.List;

public abstract class DJI {
   int I;
   int Z;
   int C;
   public static byte[][] B;
   static int D;

   DJI(int var1, int var2, int var3) {
      this.C = var1 * -1209403731;
      this.Z = -2125519021 * var2;
      this.I = -1733764677 * var3;
   }

   abstract void method1046(int var1, int var2);

   abstract void method1047(int var1, int var2, byte var3);

   abstract void method1048(int var1, int var2, byte var3);

   abstract void method1049(int var1, int var2);

   abstract void method1050(int var1, int var2);

   abstract void method1051(int var1, int var2);

   abstract void method1052(int var1, int var2);

   abstract void method1053(int var1, int var2);

   abstract void method1054(int var1, int var2, byte var3);

   static void I(GSI var0, int var1, int var2, int var3) {
      try {
         if (var1 >= 0 && var2 >= 0 && FX.Y != null) {
            XP var4 = XEI.mI.I(681479919);
            YF var5 = var0.method5036();
            var0.method5182(FX.Y);
            var0.method5043(FX.z);
            var0.r(FX.U * -156795795, -2074651333 * FX.V, -156795795 * FX.U + 2125992951 * FX.W, FX.V * -2074651333 + FX.X * 971707205);
            var0.method5187(FX.U * -156795795, -2074651333 * FX.V, 2125992951 * FX.W, 971707205 * FX.X);
            var5.I(FX.z);
            var5.Z(FX.Y);
            var5.I();
            int var6 = var1 - FX.U * -156795795;
            int var7 = var2 - FX.V * -2074651333;
            int var9;
            int var21;
            int var22;
            int var54;
            if (XEI.mI.T(-1611682495) != null && (!XEI.rC || (-112110875 * AE.F & 64) != 0)) {
               int var8 = -1;
               var9 = -1;
               float var10 = (float)var6 * 2.0F / (float)(FX.W * 2125992951) - 1.0F;
               float var11 = 2.0F * (float)var7 / (float)(971707205 * FX.X) - 1.0F;
               var5.I(var10, var11, -1.0F, FX.S);
               float var12 = FX.S[0] / FX.S[3];
               float var13 = FX.S[1] / FX.S[3];
               float var14 = FX.S[2] / FX.S[3];
               var5.I(var10, var11, 1.0F, FX.S);
               float var15 = FX.S[0] / FX.S[3];
               float var16 = FX.S[1] / FX.S[3];
               float var17 = FX.S[2] / FX.S[3];
               float var18 = II.I(var12, var13, var14, var15, var16, var17, 4, 1869450178);
               if (var18 > 0.0F) {
                  float var19 = var15 - var12;
                  float var20 = var17 - var14;
                  var21 = (int)(var12 + var18 * var19);
                  var22 = (int)(var20 * var18 + var14);
                  var8 = var21 + (UA.F.S() - 1 << 8) >> 9;
                  var9 = var22 + (UA.F.S() - 1 << 8) >> 9;
                  byte var23 = UA.F.K;
                  if (var23 < 3 && (XEI.mI.M(-86337284).C[1][var21 >> 9][var22 >> 9] & 2) != 0) {
                     var54 = var23 + 1;
                  }
               }

               if (-1 != var8 && -1 != var9) {
                  if (XEI.rC && (-112110875 * AE.F & 64) != 0) {
                     HSI var43 = LZ.I(LT.D * 1262526353, 392084321 * XEI.tC, -156511736);
                     if (var43 != null) {
                        IJ.I(XEI.vC, " " + SS.C + " ", SJ.VI * 697885143, 59, -1, 0L, var8, var9, true, false, (long)(var8 << 32 | var9), true, -1555484950);
                     } else {
                        PZ.Z((byte)4);
                     }
                  } else {
                     if (AU.B) {
                        IJ.I(VEI.RZ.I(WO.U, -875414210), "", -1, 60, -1, 0L, var8, var9, true, false, (long)(var8 << 32 | var9), true, -1698149123);
                     }

                     IJ.I(EFI.D, "", XEI.fC * -1471730241, 23, -1, 0L, var8, var9, true, false, (long)(var8 << 32 | var9), true, -1114825452);
                  }
               }
            }

            ZP var31 = XEI.mI.T(-1611682495).N;
            var9 = var1;
            int var32 = var2;
            List var33 = var31.B;
            Iterator var34 = var33.iterator();

            do {
               while(true) {
                  KP var35;
                  do {
                     if (!var34.hasNext()) {
                        return;
                     }

                     var35 = (KP)var34.next();
                  } while(!XEI.DI && UA.F.K != var35.I.K);

                  if (!var35.I(var0, var9, var32, 1628119840)) {
                     break;
                  }

                  boolean var36 = false;
                  boolean var37 = false;
                  int var38;
                  int var39;
                  if (var35.I instanceof ZR) {
                     var38 = ((ZR)var35.I).R;
                     var39 = ((ZR)var35.I).O;
                  } else {
                     SF var40 = var35.I.I().I;
                     var38 = (int)var40.I >> 9;
                     var39 = (int)var40.Z >> 9;
                  }

                  SF var26;
                  int var27;
                  int var28;
                  int var45;
                  if (var35.I instanceof PEI) {
                     PEI var41 = (PEI)var35.I;
                     var45 = var41.S();
                     SF var48 = var41.I().I;
                     if ((var45 & 1) == 0 && ((int)var48.I & 511) == 0 && ((int)var48.Z & 511) == 0 || (var45 & 1) == 1 && ((int)var48.I & 511) == 256 && 256 == ((int)var48.Z & 511)) {
                        var21 = (int)var48.I - (var41.S() - 1 << 8);
                        var22 = (int)var48.Z - (var41.S() - 1 << 8);

                        for(var54 = 0; var54 < -1230451913 * XEI.zI; ++var54) {
                           QG var24 = (QG)XEI.UI.I((long)XEI.WI[var54]);
                           if (var24 != null) {
                              GEI var25 = (GEI)var24.J;
                              if (443738891 * XEI.kB != var25.c * 335731285 && var25.zI) {
                                 var26 = var25.I().I;
                                 var27 = (int)var26.I - (var25.tI.II * -2095128707 - 1 << 8);
                                 var28 = (int)var26.Z - (-2095128707 * var25.tI.II - 1 << 8);
                                 if (var27 >= var21 && var25.tI.II * -2095128707 <= var41.S() - (var27 - var21 >> 9) && var28 >= var22 && var25.tI.II * -2095128707 <= var41.S() - (var28 - var22 >> 9)) {
                                    LZ.I(var25, UA.F.K != var35.I.K, (byte)-10);
                                    var25.c = -339947553 * XEI.kB;
                                 }
                              }
                           }
                        }

                        var54 = 1168366243 * C.I;
                        int[] var56 = C.J;

                        for(int var62 = 0; var62 < var54; ++var62) {
                           PEI var65 = XEI.MC[var56[var62]];
                           if (var65 != null && 443738891 * XEI.kB != 335731285 * var65.c && var41 != var65) {
                              if (!var65.zI) {
                                 if (var3 == 202437353) {
                                    return;
                                 }
                              } else {
                                 SF var70 = var65.I().I;
                                 var28 = (int)var70.I - (var65.S() - 1 << 8);
                                 int var29 = (int)var70.Z - (var65.S() - 1 << 8);
                                 if (var28 >= var21 && var65.S() <= var41.S() - (var28 - var21 >> 9) && var29 >= var22 && var65.S() <= var41.S() - (var29 - var22 >> 9)) {
                                    LM.I(var65, UA.F.K != var35.I.K, 875975417);
                                    var65.c = XEI.kB * -339947553;
                                 }
                              }
                           }
                        }
                     }

                     if (443738891 * XEI.kB == 335731285 * var41.c) {
                        continue;
                     }

                     LM.I(var41, UA.F.K != var35.I.K, -554283505);
                     var41.c = -339947553 * XEI.kB;
                  }

                  int var61;
                  int var68;
                  if (var35.I instanceof GEI) {
                     GEI var42 = (GEI)var35.I;
                     if (var42.tI != null) {
                        SF var47 = var42.I().I;
                        if ((-2095128707 * var42.tI.II & 1) == 0 && ((int)var47.I & 511) == 0 && ((int)var47.Z & 511) == 0 || (-2095128707 * var42.tI.II & 1) == 1 && ((int)var47.I & 511) == 256 && ((int)var47.Z & 511) == 256) {
                           int var49 = (int)var47.I - (-2095128707 * var42.tI.II - 1 << 8);
                           var21 = (int)var47.Z - (var42.tI.II * -2095128707 - 1 << 8);

                           for(var22 = 0; var22 < XEI.zI * -1230451913; ++var22) {
                              QG var58 = (QG)XEI.UI.I((long)XEI.WI[var22]);
                              if (var58 != null) {
                                 GEI var59 = (GEI)var58.J;
                                 if (335731285 * var59.c != XEI.kB * 443738891 && var59 != var42) {
                                    if (!var59.zI) {
                                       if (var3 == 202437353) {
                                          throw new IllegalStateException();
                                       }
                                    } else {
                                       SF var64 = var59.I().I;
                                       var68 = (int)var64.I - (var59.tI.II * -2095128707 - 1 << 8);
                                       var27 = (int)var64.Z - (-2095128707 * var59.tI.II - 1 << 8);
                                       if (var68 >= var49 && -2095128707 * var59.tI.II <= var42.tI.II * -2095128707 - (var68 - var49 >> 9) && var27 >= var21 && -2095128707 * var59.tI.II <= -2095128707 * var42.tI.II - (var27 - var21 >> 9)) {
                                          LZ.I(var59, var35.I.K != UA.F.K, (byte)-62);
                                          var59.c = -339947553 * XEI.kB;
                                       }
                                    }
                                 }
                              }
                           }

                           var22 = 1168366243 * C.I;
                           int[] var60 = C.J;

                           for(var61 = 0; var61 < var22; ++var61) {
                              PEI var66 = XEI.MC[var60[var61]];
                              if (var66 != null && 335731285 * var66.c != XEI.kB * 443738891) {
                                 if (!var66.zI) {
                                    if (var3 == 202437353) {
                                       return;
                                    }
                                 } else {
                                    var26 = var66.I().I;
                                    var27 = (int)var26.I - (var66.S() - 1 << 8);
                                    var28 = (int)var26.Z - (var66.S() - 1 << 8);
                                    if (var27 >= var49 && var66.S() <= var42.tI.II * -2095128707 - (var27 - var49 >> 9) && var28 >= var21 && var66.S() <= -2095128707 * var42.tI.II - (var28 - var21 >> 9)) {
                                       LM.I(var66, var35.I.K != UA.F.K, 1713781703);
                                       var66.c = -339947553 * XEI.kB;
                                    }
                                 }
                              }
                           }
                        }

                        if (var42.c * 335731285 == 443738891 * XEI.kB) {
                           if (var3 == 202437353) {
                              throw new IllegalStateException();
                           }
                           continue;
                        }

                        LZ.I(var42, UA.F.K != var35.I.K, (byte)-73);
                        var42.c = XEI.kB * -339947553;
                     }
                  }

                  if (var35.I instanceof MR) {
                     int var44 = -1760580017 * var4.I + var38;
                     var45 = 283514611 * var4.Z + var39;
                     BG var51 = (BG)XEI.LI.I((long)(var35.I.K << 28 | var45 << 14 | var44));
                     if (var51 != null) {
                        var21 = 0;

                        for(KE var55 = (KE)var51.S.C(-1921101370); var55 != null; ++var21) {
                           SEI var63 = JH.R.I(1768239597 * var55.S);
                           if (var63.JI) {
                              var61 = var63.x * 292187293;
                           } else if (var63.b) {
                              var61 = PZ.B.Z * 1295181471;
                           } else {
                              var61 = 363537303 * PZ.B.A;
                           }

                           if (XEI.rC && var35.I.K == UA.F.K) {
                              DZI var67 = YI.D * 831522399 != -1 ? WFI.C.I(YI.D * 831522399, 1640464070) : null;
                              if ((AE.F * -112110875 & 1) != 0 && (var67 == null || var63.I(831522399 * YI.D, -388931549 * var67.I, -2028636758) != -388931549 * var67.I)) {
                                 IJ.I(XEI.vC, XEI.TZ + " " + SS.C + " " + RA.I(var61, -1803338083) + var63.A, SJ.VI * 697885143, 17, -1, (long)(var55.S * 1768239597), var38, var39, true, false, (long)var21, false, -1282887596);
                              }
                           }

                           if (var35.I.K == UA.F.K) {
                              String[] var69 = var63.V;

                              for(var68 = var69.length - 1; var68 >= 0; --var68) {
                                 if (var69[var68] != null) {
                                    short var71 = 0;
                                    var28 = XEI.QI * 1395924385;
                                    if (var68 == 0) {
                                       var71 = 18;
                                    }

                                    if (var68 == 1) {
                                       var71 = 19;
                                    }

                                    if (var68 == 2) {
                                       var71 = 20;
                                    }

                                    if (3 == var68) {
                                       var71 = 21;
                                    }

                                    if (var68 == 4) {
                                       var71 = 22;
                                    }

                                    if (var68 == 5) {
                                       var71 = 1004;
                                    }

                                    if (var68 == 1109145023 * var63.z) {
                                       var28 = 1605315453 * var63.X;
                                    }

                                    if (var63.c * 693471665 == var68) {
                                       var28 = var63.D * -1818170233;
                                    }

                                    IJ.I(var69[var68], RA.I(var61, -1300852022) + var63.A, var28, var71, -1, (long)(var55.S * 1768239597), var38, var39, true, false, (long)var21, false, -1707817875);
                                 }
                              }
                           }

                           var55 = (KE)var51.S.F(293661745);
                        }
                     }
                  }

                  if (var35.I instanceof HAI) {
                     HAI var46 = (HAI)var35.I;
                     KEI var50 = XEI.mI.E(-151154213).C(var46.method32((byte)32));
                     if (var50.C != null) {
                        var50 = var50.I((FAI)MI.E, (int)2026923830);
                     }

                     if (var50 == null) {
                        if (var3 == 202437353) {
                           return;
                        }
                     } else {
                        if (XEI.rC && var35.I.K == UA.F.K) {
                           DZI var52 = 831522399 * YI.D != -1 ? WFI.C.I(YI.D * 831522399, -616098570) : null;
                           if ((AE.F * -112110875 & 4) != 0 && (var52 == null || var50.I(831522399 * YI.D, var52.I * -388931549, (byte)2) != -388931549 * var52.I)) {
                              IJ.I(XEI.vC, XEI.TZ + " " + SS.C + " " + RA.I(65535, (int)-1704073338) + var50.D, SJ.VI * 697885143, 2, -1, X.I(var46, var38, var39, 2139321433), var38, var39, true, false, (long)var46.hashCode(), false, -978621849);
                           }
                        }

                        if (var35.I.K == UA.F.K) {
                           String[] var53 = var50.U;
                           if (var53 != null) {
                              for(var21 = var53.length - 1; var21 >= 0; --var21) {
                                 if (var53[var21] != null) {
                                    short var57 = 0;
                                    var54 = XEI.QI * 1395924385;
                                    if (var21 == 0) {
                                       var57 = 3;
                                    }

                                    if (1 == var21) {
                                       var57 = 4;
                                    }

                                    if (var21 == 2) {
                                       var57 = 5;
                                    }

                                    if (var21 == 3) {
                                       var57 = 6;
                                    }

                                    if (var21 == 4) {
                                       var57 = 1001;
                                    }

                                    if (var21 == 5) {
                                       var57 = 1002;
                                    }

                                    if (var21 == var50.Y * -1412413471) {
                                       var54 = 1501072109 * var50.FI;
                                    }

                                    if (var21 == var50.i * 1498416223) {
                                       var54 = var50.I * -143998181;
                                    }

                                    IJ.I(var53[var21], RA.I(65535, (int)-1882925758) + var50.D, var54, var57, -1, X.I(var46, var38, var39, 2141756436), var38, var39, true, false, (long)var46.hashCode(), false, -1317659949);
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            } while(var3 != 202437353);
         }

      } catch (RuntimeException var30) {
         throw DQ.I(var30, "dz.e(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.J -= -1567522756;
         int var2 = var0.H[var0.J * 681479919];
         boolean var3 = 1 == var0.H[var0.J * 681479919 + 1];
         int var4 = var0.H[var0.J * 681479919 + 2];
         boolean var5 = var0.H[3 + 681479919 * var0.J] == 1;
         LH.I(var2, var3, var4, var5, 1687031105);
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "dz.alr(" + ')');
      }
   }

   static int I(int var0, int var1, int var2) {
      try {
         int var3 = var0 >> 31 & var1 - 1;
         return var3 + (var0 + (var0 >>> 31)) % var1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "dz.r(" + ')');
      }
   }

   static void I(int var0, String var1, byte var2) {
      try {
         VK var3 = IV.I(3, (long)var0);
         var3.I((byte)104);
         var3.M = var1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "dz.ah(" + ')');
      }
   }
}
