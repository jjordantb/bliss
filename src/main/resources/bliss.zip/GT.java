public class GT {
   public char I;
   public int Z;
   public int C;
   public int B;
   public static int D;
   public static int F;

   void I(REI var1, int var2) {
      try {
         while(true) {
            int var3 = var1.I();
            if (var3 == 0) {
               return;
            }

            this.J(var1, var3, 2123525160);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "pq.a(" + ')');
      }
   }

   void J(REI var1, int var2, int var3) {
      try {
         if (var2 == 1) {
            this.I = IZI.I(var1.S(-12558881), 2024016549);
         } else if (var2 == 2) {
            this.Z = var1.C() * -1304139699;
            this.C = var1.I() * 480047535;
            this.B = var1.I() * -1977314169;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "pq.f(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         F var3 = XL.Z(var2, -1228274394);
         int var4 = -1;
         if (var3 != null) {
            var4 = var3.C * -945858763;
         }

         var0.H[(var0.J += -391880689) * 681479919 - 1] = var4;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "pq.abv(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.S.Z(-460328639) == 1 ? 1 : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "pq.ajg(" + ')');
      }
   }

   public static void I(int var0, int var1) {
      try {
         if (MU.Z((byte)56)) {
            if (2084404473 * TQ.D != var0) {
               TQ.F = 2742373017286080113L;
            }

            TQ.D = var0 * 2035975497;
            XEI.TI.I((byte)49);
            HX.I(4, 1551250847);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "pq.q(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = (int)(CI.I((byte)1) / 60000L);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "pq.akn(" + ')');
      }
   }
}
