import java.awt.Canvas;

public class CU {
   X I;
   HSI Z;

   boolean I(X var1, int var2, int var3, int var4) {
      try {
         if (var1 != null) {
            HSI var5 = var1.I(var2, (short)15753);
            if (var5 != null) {
               this.I = var1;
               this.Z = var5;
               return true;
            }
         }

         this.F((byte)38);
         return false;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "qd.b(" + ')');
      }
   }

   boolean I(int var1, int var2, int var3) {
      try {
         HSI var4 = LZ.I(var1, var2, -156511736);
         if (var4 != null) {
            this.I = IU.F[var1 >> 16];
            this.Z = var4;
            return true;
         } else {
            this.F((byte)92);
            return false;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "qd.f(" + ')');
      }
   }

   HSI I(int var1) {
      try {
         return this.I.I(this.Z.V * -440872681, (short)10433);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "qd.a(" + ')');
      }
   }

   void F(byte var1) {
      try {
         this.I = null;
         this.Z = null;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "qd.p(" + ')');
      }
   }

   static final void I(OU var0, short var1) {
      try {
         GN.n = var0.H[(var0.J -= -391880689) * 681479919] == 1;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "qd.aez(" + ')');
      }
   }

   public static int I(byte var0) {
      try {
         Canvas var1 = new Canvas();
         var1.setSize(100, 100);
         GSI var2 = JCI.I(0, var1, (FEI)null, (KJ)null, 0, -1071815074);
         long var3 = CI.I((byte)1);

         int var5;
         for(var5 = 0; var5 < 10000; ++var5) {
            var2.method5020(5, 10, 100.0F, 75, 50, 100.0F, 15, 90, 100.0F, -65536, -65536, -65536, 1);
         }

         var5 = (int)(CI.I((byte)1) - var3);
         var2.I(0, 0, 100, 100, -16777216, (byte)7);
         var2.H(1538379056);
         return var5;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "qd.f(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)54);
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var3.dZ * -1086526073;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "qd.rb(" + ')');
      }
   }

   static void I(int var0, int var1, int var2, int var3, int var4, int var5) {
      try {
         for(int var6 = var2; var6 <= var3; ++var6) {
            DFI.I(DT.I[var6], var0, var1, var4, -1334363034);
         }

      } catch (RuntimeException var7) {
         throw DQ.I(var7, "qd.z(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = (int)XEI.WZ >> 3;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "qd.agr(" + ')');
      }
   }

   static final void I(YK var0, OU var1, byte var2) {
      try {
         var1.H[(var1.J += -391880689) * 681479919 - 1] = QJ.I(var0, (byte)-65);
         var1.S[(var1.A += 969361751) * -203050393 - 1] = BDI.I(var0, 533229453);
         var1.S[(var1.A += 969361751) * -203050393 - 1] = S.I((YK)var0, (byte)14);
         var1.S[(var1.A += 969361751) * -203050393 - 1] = OD.I(var0, -532801249);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "qd.v(" + ')');
      }
   }

   public static final void I(int var0, boolean var1, int var2, int var3) {
      try {
         if (var0 >= 8000 && var0 <= 48000) {
            PA.F = var0 * 1438282109;
            PA.Z = var1;
            PA.C = var2 * 2095551653;
         } else {
            throw new IllegalArgumentException();
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "qd.a(" + ')');
      }
   }
}
