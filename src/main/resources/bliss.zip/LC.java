public class LC {
   static int Z = 3;
   int append = -247396807;
   IY equals = new IY();
   static int method3508 = 1;
   static int method3510 = 2;
   static int out = 7;
   static int println = 4;
   static int toString = 11;
   static int I = 6;
   static int C = 12;
   static int B = 8;
   static int D = 5;
   static int F = 10;
   long J;
   static int S = 9;
   static int A = 13;
   static IBI[] E;
   public static KJ G;

   public void I(QC var1, byte var2) {
      try {
         if (2334843941678543823L * var1.E == -6211723929392173281L * this.J && this.append * 2001926135 == -934549233 * var1.Z) {
            for(RL var3 = (RL)this.equals.Z(1766612795); var3 != null; var3 = (RL)this.equals.B(49146)) {
               var3.method3510(var1, (byte)1);
            }

            var1.Z += 1441392111;
         } else {
            throw new RuntimeException("");
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "gn.f(" + ')');
      }
   }

   public LC(REI var1) {
      this.Z((REI)var1, (short)594);
   }

   void Z(REI var1, short var2) {
      try {
         this.J = var1.I((short)21326) * 8254773464748362975L;
         this.append = var1.H((byte)-33) * 247396807;

         for(int var3 = var1.I(); var3 != 0; var3 = var1.I()) {
            System.out.println(var3);
            Object var4;
            if (var3 == 3) {
               var4 = new YL(this);
            } else if (1 == var3) {
               var4 = new TL(this);
            } else if (13 == var3) {
               var4 = new CM(this);
            } else if (var3 == 4) {
               var4 = new BM(this);
            } else if (6 == var3) {
               var4 = new VL(this);
            } else if (5 == var3) {
               var4 = new DM(this);
            } else if (2 == var3) {
               var4 = new JM(this);
            } else if (7 == var3) {
               var4 = new UL(this);
            } else if (8 == var3) {
               var4 = new XL(this);
            } else if (var3 == 9) {
               var4 = new FM(this);
            } else if (var3 == 10) {
               var4 = new IM(this);
            } else if (var3 == 11) {
               var4 = new WL(this);
            } else {
               if (12 != var3) {
                  throw new RuntimeException("");
               }

               var4 = new ZM(this);
            }

            ((RL)var4).method3508(var1, 804752437);
            this.equals.I((AE)var4, (int)843424958);
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "gn.a(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.J -= -783761378;
         int var2 = var0.H[681479919 * var0.J];
         int var3 = var0.H[1 + var0.J * 681479919];
         SEI var4 = JH.R.I(var2);
         if (var3 >= 1 && var3 <= 5 && var4.Z(var3 - 1) != null && !var4.Z(var3 - 1).equals("null")) {
            var0.S[(var0.A += 969361751) * -203050393 - 1] = var4.Z(var3 - 1);
         } else {
            var0.S[(var0.A += 969361751) * -203050393 - 1] = "";
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "gn.aar(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         KBI.I(var3, var4, var0, (byte)125);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "gn.jz(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         var0.J -= -1175642067;
         int var2 = var0.H[681479919 * var0.J];
         int var3 = var0.H[var0.J * 681479919 + 1];
         int var4 = var0.H[681479919 * var0.J + 2];
         HSI var5 = LZ.I(var2 << 16 | var3, var4, -156511736);
         PZ.Z((byte)4);
         OL var6 = XEI.I(var5);
         TZ.I(var5, var6.C((byte)-10), -1133219011 * var6.J, 1387537939);
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "gn.amf(" + ')');
      }
   }
}
