import java.io.IOException;

public class IO extends YN {
   int Z;
   static int length = 10;
   KJ substring;
   byte[][] toString = new byte[10][];
   int[] I;
   int C;
   REI B = new REI((byte[])null);
   REI D = new REI((byte[])null);

   int method3775(byte[] var1, int var2) throws IOException {
      try {
         int var4;
         int var5;
         if (this.I == null) {
            if (!this.substring.I(this.Z * -247750727, 0, (int)-925167069)) {
               return 0;
            }

            byte[] var3 = this.substring.I(-247750727 * this.Z, 0, (byte)-2);
            if (var3 == null) {
               throw new IllegalStateException("");
            }

            this.D.S = var3;
            this.D.A = 0;
            var4 = var3.length >> 1;
            this.I = new int[var4];

            for(var5 = 0; var5 < var4; ++var5) {
               this.I[var5] = this.D.C();
            }
         }

         if (this.C * 352672983 >= this.I.length) {
            return -1;
         } else {
            this.F((byte)81);
            this.D.S = var1;
            this.D.A = 0;

            do {
               if (this.D.A * 385051775 >= this.D.S.length) {
                  this.D.S = null;
                  return var1.length;
               }

               if (this.B.S == null) {
                  if (this.toString[0] == null) {
                     this.D.S = null;
                     return this.D.A * 385051775;
                  }

                  this.B.S = this.toString[0];
               }

               int var7 = this.D.S.length - 385051775 * this.D.A;
               var4 = this.B.S.length - 385051775 * this.B.A;
               if (var7 < var4) {
                  this.B.I(this.D.S, this.D.A * 385051775, var7, -953523806);
                  this.D.S = null;
                  return var1.length;
               }

               this.D.I(this.B.S, this.B.A * 385051775, var4, (short)-26872);
               this.B.S = null;
               this.B.A = 0;
               this.C += -592488729;

               for(var5 = 0; var5 < 9; ++var5) {
                  this.toString[var5] = this.toString[1 + var5];
               }

               this.toString[9] = null;
            } while(this.C * 352672983 < this.I.length);

            this.D.S = null;
            return this.D.A * 385051775;
         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "acm.a(" + ')');
      }
   }

   public void F(byte var1) {
      try {
         if (this.I != null) {
            for(int var2 = 0; var2 < 10 && var2 + 352672983 * this.C < this.I.length; ++var2) {
               if (this.toString[var2] == null && this.substring.I(this.I[var2 + 352672983 * this.C], 0, (int)-951445461)) {
                  this.toString[var2] = this.substring.I(this.I[352672983 * this.C + var2], 0, (byte)-31);
               }
            }
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "acm.as(" + ')');
      }
   }

   int method3777(byte[] var1) throws IOException {
      int var3;
      int var4;
      if (this.I == null) {
         if (!this.substring.I(this.Z * -247750727, 0, (int)-1752861403)) {
            return 0;
         }

         byte[] var2 = this.substring.I(-247750727 * this.Z, 0, (byte)9);
         if (var2 == null) {
            throw new IllegalStateException("");
         }

         this.D.S = var2;
         this.D.A = 0;
         var3 = var2.length >> 1;
         this.I = new int[var3];

         for(var4 = 0; var4 < var3; ++var4) {
            this.I[var4] = this.D.C();
         }
      }

      if (this.C * 352672983 >= this.I.length) {
         return -1;
      } else {
         this.F((byte)97);
         this.D.S = var1;
         this.D.A = 0;

         do {
            if (this.D.A * 385051775 >= this.D.S.length) {
               this.D.S = null;
               return var1.length;
            }

            if (this.B.S == null) {
               if (this.toString[0] == null) {
                  this.D.S = null;
                  return this.D.A * 385051775;
               }

               this.B.S = this.toString[0];
            }

            int var5 = this.D.S.length - 385051775 * this.D.A;
            var3 = this.B.S.length - 385051775 * this.B.A;
            if (var5 < var3) {
               this.B.I(this.D.S, this.D.A * 385051775, var5, -953523806);
               this.D.S = null;
               return var1.length;
            }

            this.D.I(this.B.S, this.B.A * 385051775, var3, (short)-14294);
            this.B.S = null;
            this.B.A = 0;
            this.C += -592488729;

            for(var4 = 0; var4 < 9; ++var4) {
               this.toString[var4] = this.toString[1 + var4];
            }

            this.toString[9] = null;
         } while(this.C * 352672983 < this.I.length);

         this.D.S = null;
         return this.D.A * 385051775;
      }
   }

   int method3778(byte[] var1) throws IOException {
      int var3;
      int var4;
      if (this.I == null) {
         if (!this.substring.I(this.Z * -247750727, 0, (int)-718226291)) {
            return 0;
         }

         byte[] var2 = this.substring.I(-247750727 * this.Z, 0, (byte)-126);
         if (var2 == null) {
            throw new IllegalStateException("");
         }

         this.D.S = var2;
         this.D.A = 0;
         var3 = var2.length >> 1;
         this.I = new int[var3];

         for(var4 = 0; var4 < var3; ++var4) {
            this.I[var4] = this.D.C();
         }
      }

      if (this.C * 352672983 >= this.I.length) {
         return -1;
      } else {
         this.F((byte)11);
         this.D.S = var1;
         this.D.A = 0;

         do {
            if (this.D.A * 385051775 >= this.D.S.length) {
               this.D.S = null;
               return var1.length;
            }

            if (this.B.S == null) {
               if (this.toString[0] == null) {
                  this.D.S = null;
                  return this.D.A * 385051775;
               }

               this.B.S = this.toString[0];
            }

            int var5 = this.D.S.length - 385051775 * this.D.A;
            var3 = this.B.S.length - 385051775 * this.B.A;
            if (var5 < var3) {
               this.B.I(this.D.S, this.D.A * 385051775, var5, -953523806);
               this.D.S = null;
               return var1.length;
            }

            this.D.I(this.B.S, this.B.A * 385051775, var3, (short)-19169);
            this.B.S = null;
            this.B.A = 0;
            this.C += -592488729;

            for(var4 = 0; var4 < 9; ++var4) {
               this.toString[var4] = this.toString[1 + var4];
            }

            this.toString[9] = null;
         } while(this.C * 352672983 < this.I.length);

         this.D.S = null;
         return this.D.A * 385051775;
      }
   }

   int method3766(byte[] var1) throws IOException {
      int var3;
      int var4;
      if (this.I == null) {
         if (!this.substring.I(this.Z * -247750727, 0, (int)-1469304085)) {
            return 0;
         }

         byte[] var2 = this.substring.I(-247750727 * this.Z, 0, (byte)-90);
         if (var2 == null) {
            throw new IllegalStateException("");
         }

         this.D.S = var2;
         this.D.A = 0;
         var3 = var2.length >> 1;
         this.I = new int[var3];

         for(var4 = 0; var4 < var3; ++var4) {
            this.I[var4] = this.D.C();
         }
      }

      if (this.C * 352672983 >= this.I.length) {
         return -1;
      } else {
         this.F((byte)56);
         this.D.S = var1;
         this.D.A = 0;

         do {
            if (this.D.A * 385051775 >= this.D.S.length) {
               this.D.S = null;
               return var1.length;
            }

            if (this.B.S == null) {
               if (this.toString[0] == null) {
                  this.D.S = null;
                  return this.D.A * 385051775;
               }

               this.B.S = this.toString[0];
            }

            int var5 = this.D.S.length - 385051775 * this.D.A;
            var3 = this.B.S.length - 385051775 * this.B.A;
            if (var5 < var3) {
               this.B.I(this.D.S, this.D.A * 385051775, var5, -953523806);
               this.D.S = null;
               return var1.length;
            }

            this.D.I(this.B.S, this.B.A * 385051775, var3, (short)-30519);
            this.B.S = null;
            this.B.A = 0;
            this.C += -592488729;

            for(var4 = 0; var4 < 9; ++var4) {
               this.toString[var4] = this.toString[1 + var4];
            }

            this.toString[9] = null;
         } while(this.C * 352672983 < this.I.length);

         this.D.S = null;
         return this.D.A * 385051775;
      }
   }

   public IO(int var1, KJ var2, int var3) {
      super(var1);
      this.substring = var2;
      this.Z = -2133150071 * var3;
   }

   static final void I(HSI var0, X var1, OU var2, int var3) {
      try {
         String var4 = (String)var2.S[(var2.A -= 969361751) * -203050393];
         if (IN.I(var4, var2, -301797495) != null) {
            var4 = var4.substring(0, var4.length() - 1);
         }

         var0.d = OI.I(var4, var2, -2046058202);
         var0.JZ = true;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "acm.kh(" + ')');
      }
   }
}
