import java.lang.ref.SoftReference;

public class FL extends RK {
   SoftReference get;

   boolean method3409() {
      return true;
   }

   FL(YSI var1, Object var2, int var3) {
      super(var1, var3);
      this.get = new SoftReference(var2);
   }

   boolean method3407() {
      return true;
   }

   Object method3410() {
      return this.get.get();
   }

   Object method3406() {
      return this.get.get();
   }

   Object method3408() {
      return this.get.get();
   }
}
