public class HEI {
   public boolean I = false;
   NZI Z;
   public int C;
   public String B = "null";
   public int D = -1197123063;
   public int[] F;
   public int[] J;
   public int[] S;
   public int A = 799129853;
   short[] KA;
   public short[] E;
   byte[] PA;
   short[] W;
   int X = 0;
   byte append;
   byte equals;
   public int G = 0;
   byte m = 0;
   public String[] H;
   public int K = -1816293685;
   public int L = -1226765471;
   public int M = 625322989;
   public int N = -1361323597;
   public int O = -1737724111;
   public boolean P = true;
   public int Q = -954057527;
   int method250 = 1732902784;
   public int R = 273231167;
   public byte T = -16;
   public short U = 0;
   public short[] V;
   public boolean Y = false;
   int method252 = 0;
   byte method4741;
   public byte i;
   JX method4755;
   int method5037 = 910525824;
   public int z;
   int oa = 1169422749;
   public boolean c = true;
   public boolean b = true;
   public boolean d = true;
   int[][] toString;
   public int f = -1506883587;
   public byte j = -96;
   public int s = 1213502441;
   public byte a = 0;
   int e = 70774261;
   public static int g = 2;
   public boolean h = false;
   public int k = 1377267175;
   public int l = 0;
   public int n = 363354277;
   public static int o = 1;
   public int p = 537547649;
   public int q = -1876875963;
   public boolean r;
   public int t = -68186784;
   public static short[] u = new short[256];
   public JA v;
   public int w = -198329521;
   public int x = -945207309;
   public int y;
   public int II = -1690840619;
   public int[] ZI;
   public int CI;
   public int BI;
   public short DI = 0;
   public int FI;
   public boolean JI;

   void I(REI var1, int var2) {
      try {
         while(true) {
            int var3 = var1.I();
            if (var3 == 0) {
               return;
            }

            this.J(var1, var3, 1663900566);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "uu.a(" + ')');
      }
   }

   public final UT I(GSI var1, int var2, SQ var3, FAI var4, SX var5, SX var6, SX[] var7, int[] var8, int var9, FZI var10, int var11, boolean var12, int var13) {
      try {
         if (this.ZI != null) {
            HEI var38 = this.I(var4, 1886245346);
            return var38 == null ? null : var38.I(var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, -679459424);
         } else {
            int var14 = var2;
            if (-1282053981 * this.method5037 != 128) {
               var14 = var2 | 2;
            }

            if (128 != -2086573057 * this.method250) {
               var14 |= 5;
            }

            boolean var15 = false;
            int var16 = var7 != null ? var7.length : 0;

            for(int var17 = 0; var17 < var16; ++var17) {
               if (var7[var17] != null) {
                  var14 |= var7[var17].B(-1790708337);
                  var15 = true;
               }
            }

            if (var5 != null) {
               var14 |= var5.B(-1790708337);
               var15 = true;
            }

            if (var6 != null) {
               var14 |= var6.B(-1790708337);
               var15 = true;
            }

            long var37 = (long)(this.C * -407713023 | 580915349 * var1.KZ << 16);
            if (var10 != null) {
               var37 |= var10.B * -8495627389615588201L << 24;
            }

            JQ var20 = this.Z.I;
            UT var19;
            synchronized(this.Z.I) {
               var19 = (UT)this.Z.I.I(var37);
            }

            EQ var39 = null;
            if (!var12 && var11 != -1) {
               var39 = var3.Z(var11, (byte)59);
            } else if (-1 != 525312939 * this.A) {
               var39 = var3.Z(this.A * 525312939, (byte)89);
            }

            int var25;
            if (var19 == null || (var19.m() & var14) != var14) {
               if (var19 != null) {
                  var14 |= var19.m();
               }

               int var21 = var14;
               if (this.KA != null) {
                  var21 = var14 | 16384;
               }

               if (this.W != null) {
                  var21 |= 32768;
               }

               if (this.m != 0) {
                  var21 |= 524288;
               }

               int[] var22 = var10 != null && var10.Z != null ? var10.Z : this.F;
               boolean var23 = false;
               KJ var24 = this.Z.C;
               synchronized(this.Z.C) {
                  var25 = 0;

                  while(true) {
                     if (var25 >= var22.length) {
                        break;
                     }

                     if (var22[var25] == -1) {
                        if (var13 != -679459424) {
                           throw new IllegalStateException();
                        }
                     } else if (!this.Z.C.I(var22[var25], 0, (int)-1819291215)) {
                        var23 = true;
                     }

                     ++var25;
                  }
               }

               if (var23) {
                  return null;
               }

               MBI[] var44 = new MBI[var22.length];

               for(var25 = 0; var25 < var22.length; ++var25) {
                  if (var22[var25] == -1) {
                     if (var13 != -679459424) {
                        throw new IllegalStateException();
                     }
                  } else {
                     KJ var26 = this.Z.C;
                     synchronized(this.Z.C) {
                        var44[var25] = MBI.I((KJ)this.Z.C, var22[var25], (int)0);
                     }

                     if (var44[var25] != null) {
                        if (var44[var25].P < 13) {
                           var44[var25].I(2);
                        }

                        if (this.toString != null && this.toString[var25] != null) {
                           var44[var25].Z(this.toString[var25][0], this.toString[var25][1], this.toString[var25][2]);
                        }
                     }
                  }
               }

               int var27;
               if (var39 != null && var39.I != null) {
                  for(var25 = 0; var25 < var39.I.length; ++var25) {
                     if (var25 < var44.length) {
                        if (var44[var25] == null) {
                           if (var13 != -679459424) {
                              throw new IllegalStateException();
                           }
                        } else {
                           int var46 = 0;
                           var27 = 0;
                           int var28 = 0;
                           int var29 = 0;
                           int var30 = 0;
                           int var31 = 0;
                           if (var39.I[var25] != null) {
                              var46 = var39.I[var25][0];
                              var27 = var39.I[var25][1];
                              var28 = var39.I[var25][2];
                              var29 = var39.I[var25][3] << 3;
                              var30 = var39.I[var25][4] << 3;
                              var31 = var39.I[var25][5] << 3;
                           }

                           if (var29 != 0 || var30 != 0 || var31 != 0) {
                              var44[var25].C(var29, var30, var31);
                           }

                           if (var46 != 0 || var27 != 0 || var28 != 0) {
                              var44[var25].Z(var46, var27, var28);
                           }
                        }
                     }
                  }
               }

               MBI var47;
               if (1 == var44.length) {
                  var47 = var44[0];
               } else {
                  var47 = new MBI(var44, var44.length);
               }

               var19 = var1.method5037(var47, var21, 299909243 * this.Z.D, -335572127 * this.X + 64, 850 + -1208973327 * this.method252);
               short[] var48;
               if (this.KA != null) {
                  if (var10 != null && var10.C != null) {
                     var48 = var10.C;
                  } else {
                     var48 = this.E;
                  }

                  for(var27 = 0; var27 < this.KA.length; ++var27) {
                     if (this.PA != null && var27 < this.PA.length) {
                        var19.X(this.KA[var27], u[this.PA[var27] & 255]);
                     } else {
                        var19.X(this.KA[var27], var48[var27]);
                     }
                  }
               }

               if (this.W != null) {
                  if (var10 != null && var10.I != null) {
                     var48 = var10.I;
                  } else {
                     var48 = this.V;
                  }

                  for(var27 = 0; var27 < this.W.length; ++var27) {
                     var19.W(this.W[var27], var48[var27]);
                  }
               }

               if (this.m != 0) {
                  var19.PA(this.append, this.equals, this.method4741, this.m & 255);
               }

               var19.KA(var14);
               JQ var49 = this.Z.I;
               synchronized(this.Z.I) {
                  this.Z.I.I(var19, var37);
               }
            }

            UT var41 = var19.method4755((byte)4, var14, true);
            boolean var40 = false;
            if (var8 != null) {
               for(int var42 = 0; var42 < 12; ++var42) {
                  if (-1 != var8[var42]) {
                     var40 = true;
                  }
               }
            }

            if (!var15 && !var40) {
               return var41;
            } else {
               LF[] var43 = null;
               if (var39 != null) {
                  var43 = var39.I((byte)22);
               }

               int var45;
               if (var40 && var43 != null) {
                  for(var45 = 0; var45 < 12; ++var45) {
                     if (var43[var45] != null) {
                        var41.method4741(var43[var45], 1 << var45, true);
                     }
                  }
               }

               var45 = 0;

               for(var25 = 1; var45 < var16; var25 <<= 1) {
                  if (var7[var45] != null) {
                     var7[var45].I(var41, 0, var25, (byte)125);
                  }

                  ++var45;
               }

               if (var40) {
                  for(var45 = 0; var45 < 12; ++var45) {
                     if (-1 != var8[var45]) {
                        var25 = var8[var45] - var9;
                        var25 &= 16383;
                        LF var50 = new LF();
                        var50.I(0.0F, 1.0F, 0.0F, HF.I(var25));
                        var41.method4741(var50, 1 << var45, false);
                     }
                  }
               }

               if (var40 && var43 != null) {
                  for(var45 = 0; var45 < 12; ++var45) {
                     if (var43[var45] != null) {
                        var41.method4741(var43[var45], 1 << var45, false);
                     }
                  }
               }

               if (var5 != null && var6 != null) {
                  MU.I(var41, var5, var6, -1827693647);
               } else if (var5 != null) {
                  var5.I((UT)var41, 0, (int)339112441);
               } else if (var6 != null) {
                  var6.I((UT)var41, 0, (int)-1538889562);
               }

               if (-2086573057 * this.method250 != 128 || 128 != -1282053981 * this.method5037) {
                  var41.oa(this.method250 * -2086573057, this.method5037 * -1282053981, this.method250 * -2086573057);
               }

               var41.KA(var2);
               return var41;
            }
         }
      } catch (RuntimeException var36) {
         throw DQ.I(var36, "uu.i(" + ')');
      }
   }

   public final UT I(GSI var1, int var2, FAI var3, SX var4, FZI var5, int var6) {
      try {
         if (this.ZI != null) {
            HEI var23 = this.I(var3, 1912809157);
            return var23 == null ? null : var23.I(var1, var2, var3, var4, var5, -1500196036);
         } else if (this.J != null || var5 != null && var5.Z != null) {
            int var7 = var2;
            if (var4 != null) {
               var7 = var2 | var4.B(-1790708337);
            }

            long var8 = (long)(this.C * -407713023 | 580915349 * var1.KZ << 16);
            if (var5 != null) {
               var8 |= -8495627389615588201L * var5.B << 24;
            }

            JQ var11 = this.Z.F;
            UT var10;
            synchronized(this.Z.F) {
               var10 = (UT)this.Z.F.I(var8);
            }

            if (var10 == null || (var10.m() & var7) != var7) {
               if (var10 != null) {
                  var7 |= var10.m();
               }

               int var24 = var7;
               if (this.KA != null) {
                  var24 = var7 | 16384;
               }

               if (this.W != null) {
                  var24 |= 32768;
               }

               if (this.m != 0) {
                  var24 |= 524288;
               }

               int[] var12 = var5 != null && var5.Z != null ? var5.Z : this.J;
               boolean var13 = false;
               KJ var14 = this.Z.C;
               int var15;
               synchronized(this.Z.C) {
                  for(var15 = 0; var15 < var12.length; ++var15) {
                     if (!this.Z.C.I(var12[var15], 0, (int)-602703169)) {
                        var13 = true;
                     }
                  }
               }

               if (var13) {
                  return null;
               }

               MBI[] var25 = new MBI[var12.length];
               KJ var26 = this.Z.C;
               synchronized(this.Z.C) {
                  for(int var16 = 0; var16 < var12.length; ++var16) {
                     var25[var16] = MBI.I((KJ)this.Z.C, var12[var16], (int)0);
                  }
               }

               for(var15 = 0; var15 < var12.length; ++var15) {
                  if (var25[var15] != null && var25[var15].P < 13) {
                     var25[var15].I(2);
                  }
               }

               MBI var27;
               if (var25.length == 1) {
                  var27 = var25[0];
               } else {
                  var27 = new MBI(var25, var25.length);
               }

               var10 = var1.method5037(var27, var24, this.Z.D * 299909243, 64, 768);
               int var17;
               short[] var28;
               if (this.KA != null) {
                  if (var5 != null && var5.C != null) {
                     var28 = var5.C;
                  } else {
                     var28 = this.E;
                  }

                  for(var17 = 0; var17 < this.KA.length; ++var17) {
                     if (this.PA != null && var17 < this.PA.length) {
                        var10.X(this.KA[var17], u[this.PA[var17] & 255]);
                     } else {
                        var10.X(this.KA[var17], var28[var17]);
                     }
                  }
               }

               if (this.W != null) {
                  if (var5 != null && var5.I != null) {
                     var28 = var5.I;
                  } else {
                     var28 = this.V;
                  }

                  for(var17 = 0; var17 < this.W.length; ++var17) {
                     var10.W(this.W[var17], var28[var17]);
                  }
               }

               if (this.m != 0) {
                  var10.PA(this.append, this.equals, this.method4741, this.m & 255);
               }

               var10.KA(var7);
               JQ var29 = this.Z.F;
               synchronized(this.Z.F) {
                  this.Z.F.I(var10, var8);
               }
            }

            if (var4 != null) {
               var10 = var10.method4755((byte)1, var7, true);
               var4.I((UT)var10, 0, (int)-731129719);
            }

            var10.KA(var2);
            return var10;
         } else {
            return null;
         }
      } catch (RuntimeException var22) {
         throw DQ.I(var22, "uu.k(" + ')');
      }
   }

   public final boolean I(int var1) {
      try {
         if (this.F == null) {
            return true;
         } else {
            boolean var2 = true;
            int[] var3 = this.F;

            for(int var4 = 0; var4 < var3.length; ++var4) {
               int var5 = var3[var4];
               if (!this.Z.C.I(var5, 0, (int)-463050298)) {
                  var2 = false;
               }
            }

            return var2;
         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "uu.d(" + ')');
      }
   }

   public int I(int var1, int var2, byte var3) {
      try {
         if (this.method4755 == null) {
            return var2;
         } else {
            OK var4 = (OK)this.method4755.I((long)var1);
            return var4 == null ? var2 : var4.J * -774922497;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "uu.u(" + ')');
      }
   }

   public final HEI I(FAI var1, int var2) {
      try {
         int var3 = -1;
         if (this.e * 677538211 != -1) {
            var3 = var1.method250(677538211 * this.e, (byte)122);
         } else if (this.oa * -1248679093 != -1) {
            var3 = var1.method252(this.oa * -1248679093, (byte)49);
         }

         if (var3 >= 0 && var3 < this.ZI.length - 1 && -1 != this.ZI[var3]) {
            return this.Z.I(this.ZI[var3], 541835254);
         } else {
            int var4 = this.ZI[this.ZI.length - 1];
            return var4 != -1 ? this.Z.I(var4, 749174826) : null;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "uu.r(" + ')');
      }
   }

   HEI() {
      this.v = JA.Z;
      this.y = -1432059025;
      this.i = -1;
      this.CI = 133354337;
      this.BI = -986694912;
      this.z = 1143914752;
      this.FI = 0;
      this.JI = true;
   }

   public boolean Z(FAI var1, int var2) {
      try {
         if (this.ZI == null) {
            return true;
         } else {
            int var3 = -1;
            if (-1 != this.e * 677538211) {
               var3 = var1.method250(677538211 * this.e, (byte)4);
            } else if (-1248679093 * this.oa != -1) {
               var3 = var1.method252(-1248679093 * this.oa, (byte)94);
            }

            if (var3 >= 0 && var3 < this.ZI.length - 1 && this.ZI[var3] != -1) {
               return true;
            } else {
               int var4 = this.ZI[this.ZI.length - 1];
               return -1 != var4;
            }
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "uu.q(" + ')');
      }
   }

   public boolean I(byte var1) {
      try {
         if (this.ZI == null) {
            return -1 != this.R * 1945943361 || -1 != 1105496999 * this.s || -1390399277 * this.n != -1;
         } else {
            for(int var2 = 0; var2 < this.ZI.length; ++var2) {
               if (-1 != this.ZI[var2]) {
                  HEI var3 = this.Z.I(this.ZI[var2], -1960092896);
                  if (1945943361 * var3.R != -1 || -1 != var3.s * 1105496999 || var3.n * -1390399277 != -1) {
                     return true;
                  }
               }
            }

            return false;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "uu.n(" + ')');
      }
   }

   void Z(int var1) {
      try {
         if (this.F == null) {
            this.F = new int[0];
         }

         if (this.i == -1) {
            if (this.Z.Z == ZV.D) {
               this.i = 1;
            } else {
               this.i = 0;
            }
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "uu.b(" + ')');
      }
   }

   void J(REI var1, int var2, int var3) {
      try {
         int var4;
         int var5;
         if (var2 == 1) {
            var4 = var1.I();
            this.F = new int[var4];

            for(var5 = 0; var5 < var4; ++var5) {
               this.F[var5] = var1.Y(1235052657);
            }
         } else if (var2 == 2) {
            this.B = var1.E(-1611525197);
         } else if (12 == var2) {
            this.II = var1.I() * -1690840619;
         } else if (var2 >= 30 && var2 < 35) {
            this.H[var2 - 30] = var1.E(-329838492);
            if (this.H[var2 - 30].equals("Atack")) {
               this.H[var2 - 30] = "Attack";
            }
         } else if (var2 == 40) {
            var4 = var1.I();
            this.KA = new short[var4];
            this.E = new short[var4];

            for(var5 = 0; var5 < var4; ++var5) {
               this.KA[var5] = (short)var1.C();
               this.E[var5] = (short)var1.C();
            }
         } else if (var2 == 41) {
            var4 = var1.I();
            this.W = new short[var4];
            this.V = new short[var4];

            for(var5 = 0; var5 < var4; ++var5) {
               this.W[var5] = (short)var1.C();
               this.V[var5] = (short)var1.C();
            }
         } else if (var2 == 42) {
            var4 = var1.I();
            this.PA = new byte[var4];

            for(var5 = 0; var5 < var4; ++var5) {
               this.PA[var5] = var1.S(-12558881);
            }
         } else if (var2 == 60) {
            var4 = var1.I();
            this.J = new int[var4];

            for(var5 = 0; var5 < var4; ++var5) {
               this.J[var5] = var1.Y(1235052657);
            }
         } else if (var2 == 93) {
            this.P = false;
         } else if (var2 == 95) {
            this.Q = var1.C() * 954057527;
         } else if (var2 == 97) {
            this.method250 = var1.C() * -1227975681;
         } else if (98 == var2) {
            this.method5037 = var1.C() * 745310987;
         } else if (var2 == 99) {
            this.I = true;
         } else if (var2 == 100) {
            this.X = var1.S(-12558881) * 2012631201;
         } else if (101 == var2) {
            this.method252 = var1.S(-12558881) * 1653976405;
         } else if (var2 == 102) {
            this.x = var1.C() * 945207309;
         } else if (103 == var2) {
            this.t = var1.C() * -1075872661;
         } else {
            int var6;
            if (var2 != 106 && 118 != var2) {
               if (var2 == 107) {
                  this.c = false;
               } else if (var2 == 109) {
                  this.b = false;
               } else if (111 == var2) {
                  this.d = false;
               } else if (var2 == 113) {
                  this.DI = (short)var1.C();
                  this.U = (short)var1.C();
               } else if (114 == var2) {
                  this.j = var1.S(-12558881);
                  this.T = var1.S(-12558881);
               } else if (119 == var2) {
                  this.a = var1.S(-12558881);
               } else if (var2 == 121) {
                  this.toString = new int[this.F.length][];
                  var4 = var1.I();

                  for(var5 = 0; var5 < var4; ++var5) {
                     var6 = var1.I();
                     int[] var7 = this.toString[var6] = new int[3];
                     var7[0] = var1.S(-12558881);
                     var7[1] = var1.S(-12558881);
                     var7[2] = var1.S(-12558881);
                  }
               } else if (var2 == 122) {
                  this.f = var1.Y(1235052657) * 1506883587;
               } else if (var2 == 123) {
                  this.K = var1.C() * 1816293685;
               } else if (var2 == 125) {
                  this.v = (JA)IW.I(FN.I(-1901608125), var1.S(-12558881), (byte)2);
               } else if (127 == var2) {
                  this.A = var1.C() * -799129853;
               } else if (128 == var2) {
                  IW.I(FCI.I((byte)-83), var1.I(), (byte)2);
               } else if (var2 == 134) {
                  this.R = var1.C() * -273231167;
                  if (65535 == this.R * 1945943361) {
                     this.R = 273231167;
                  }

                  this.k = var1.C() * -1377267175;
                  if (65535 == this.k * -904091095) {
                     this.k = 1377267175;
                  }

                  this.s = var1.C() * -1213502441;
                  if (65535 == 1105496999 * this.s) {
                     this.s = 1213502441;
                  }

                  this.n = var1.C() * -363354277;
                  if (this.n * -1390399277 == 65535) {
                     this.n = 363354277;
                  }

                  this.G = var1.I() * 203494719;
               } else if (var2 == 135) {
                  this.M = var1.I() * -625322989;
                  this.D = var1.C() * 1197123063;
               } else if (136 == var2) {
                  this.N = var1.I() * 1361323597;
                  this.L = var1.C() * 1226765471;
               } else if (var2 == 137) {
                  this.O = var1.C() * 1737724111;
               } else if (var2 == 138) {
                  this.p = var1.Y(1235052657) * -537547649;
               } else if (139 == var2) {
                  this.w = var1.Y(1235052657) * 198329521;
               } else if (var2 == 140) {
                  this.q = var1.I() * -462121541;
               } else if (var2 == 141) {
                  this.h = true;
               } else if (var2 == 142) {
                  this.y = var1.C() * 1432059025;
               } else if (143 == var2) {
                  this.Y = true;
               } else if (var2 >= 150 && var2 < 155) {
                  this.H[var2 - 150] = var1.E(1280562882);
                  if (!this.Z.B) {
                     this.H[var2 - 150] = null;
                  }
               } else if (var2 == 155) {
                  this.append = var1.S(-12558881);
                  this.equals = var1.S(-12558881);
                  this.method4741 = var1.S(-12558881);
                  this.m = var1.S(-12558881);
               } else if (158 == var2) {
                  this.i = 1;
               } else if (var2 == 159) {
                  this.i = 0;
               } else if (var2 == 160) {
                  var4 = var1.I();
                  this.S = new int[var4];

                  for(var5 = 0; var5 < var4; ++var5) {
                     this.S[var5] = var1.C();
                  }
               } else if (var2 == 162) {
                  this.r = true;
               } else if (var2 == 163) {
                  this.CI = var1.I() * -133354337;
               } else if (164 == var2) {
                  this.BI = var1.C() * -138072005;
                  this.z = var1.C() * 1615081153;
               } else if (165 == var2) {
                  this.FI = var1.I() * -1027847229;
               } else if (168 == var2) {
                  this.l = var1.I() * -2143657709;
               } else if (var2 == 169) {
                  this.JI = false;
               } else if (249 == var2) {
                  var4 = var1.I();
                  if (this.method4755 == null) {
                     var5 = JV.I(var4, (byte)16);
                     this.method4755 = new JX(var5);
                  }

                  for(var5 = 0; var5 < var4; ++var5) {
                     boolean var10 = var1.I() == 1;
                     int var11 = var1.B((byte)-8);
                     Object var8;
                     if (var10) {
                        var8 = new QG(var1.E(1107258472));
                     } else {
                        var8 = new OK(var1.H((byte)-18));
                     }

                     this.method4755.I((AE)var8, (long)var11);
                  }
               }
            } else {
               this.e = var1.C() * -70774261;
               if (677538211 * this.e == 65535) {
                  this.e = 70774261;
               }

               this.oa = var1.C() * -1169422749;
               if (this.oa * -1248679093 == 65535) {
                  this.oa = 1169422749;
               }

               var4 = -1;
               if (var2 == 118) {
                  var4 = var1.C();
                  if (var4 == 65535) {
                     var4 = -1;
                  }
               }

               var5 = var1.I();
               this.ZI = new int[2 + var5];

               for(var6 = 0; var6 <= var5; ++var6) {
                  this.ZI[var6] = var1.C();
                  if (65535 == this.ZI[var6]) {
                     this.ZI[var6] = -1;
                  }
               }

               this.ZI[var5 + 1] = var4;
            }
         }

      } catch (RuntimeException var9) {
         throw DQ.I(var9, "uu.f(" + ')');
      }
   }

   public String I(int var1, String var2, int var3) {
      try {
         if (this.method4755 == null) {
            return var2;
         } else {
            QG var4 = (QG)this.method4755.I((long)var1);
            return var4 == null ? var2 : (String)var4.J;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "uu.x(" + ')');
      }
   }

   public final UT I(GSI var1, int var2, SQ var3, FAI var4, SX var5, SX var6, SX[] var7, int[] var8, int var9, FZI var10, int var11) {
      try {
         return this.I(var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, this.A * 525312939, true, -679459424);
      } catch (RuntimeException var13) {
         throw DQ.I(var13, "uu.p(" + ')');
      }
   }

   public static MI Z(REI var0, int var1) {
      try {
         MI var2 = ESI.I(var0, -2098410603);
         int var3 = var0.H((byte)-118);
         int var4 = var0.H((byte)85);
         return new OI(var2.I, var2.Z, var2.F * -39975161, 1886882435 * var2.B, var2.D * -944287579, -1387457793 * var2.A, -684094775 * var2.J, 955568089 * var2.S, var2.C * 782326281, var3, var4);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "uu.i(" + ')');
      }
   }
}
