public class ea extends OS implements SAI {
   long nativeid;

   native void bf(ja var1, ba var2, byte[][] var3, int[] var4, int[] var5, int[] var6, int[] var7);

   native void n(ja var1, ba var2, byte[][] var3, int[] var4, int[] var5, int[] var6, int[] var7);

   public native void ma(boolean var1);

   native void UA(char var1, int var2, int var3, int var4, boolean var5);

   void method2486(char var1, int var2, int var3, int var4, boolean var5, QJI var6, int var7, int var8) {
      this.P(var1, var2, var3, var4, var5, var6, var7, var8);
   }

   native void P(char var1, int var2, int var3, int var4, boolean var5, QJI var6, int var7, int var8);

   native void g(char var1, int var2, int var3, int var4, boolean var5);

   native void e(char var1, int var2, int var3, int var4, boolean var5);

   void method2489(char var1, int var2, int var3, int var4, boolean var5, QJI var6, int var7, int var8) {
      this.P(var1, var2, var3, var4, var5, var6, var7, var8);
   }

   public native void z(boolean var1);

   native void am(ja var1, ba var2, byte[][] var3, int[] var4, int[] var5, int[] var6, int[] var7);

   ea(ja var1, ba var2, LZI var3, RFI[] var4, IBI[] var5) {
      super(var1, var3);
      byte[][] var6 = new byte[var4.length][];
      int[] var7 = new int[var4.length];
      int[] var8 = new int[var4.length];
      int[] var9 = new int[var4.length];
      int[] var10 = new int[var4.length];

      for(int var11 = 0; var11 < var4.length; ++var11) {
         RFI var12 = var4[var11];
         if (var12.A != null) {
            var6[var11] = var12.A;
         } else {
            byte[] var13 = var12.S;
            byte[] var14 = var6[var11] = new byte[var13.length];

            for(int var15 = 0; var15 < var13.length; ++var15) {
               var14[var15] = (byte)(var13[var15] == 0 ? 0 : -1);
            }
         }

         var7[var11] = var12.Z;
         var8[var11] = var12.F;
         var9[var11] = var12.D;
         var10[var11] = var12.I;
      }

      this.n(var1, var2, var6, var7, var8, var9, var10);
   }

   native void bd(ja var1, ba var2, byte[][] var3, int[] var4, int[] var5, int[] var6, int[] var7);

   native void be(ja var1, ba var2, byte[][] var3, int[] var4, int[] var5, int[] var6, int[] var7);

   native void by(char var1, int var2, int var3, int var4, boolean var5, QJI var6, int var7, int var8);
}
