import java.applet.Applet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class DSI {
   int add = 0;
   public char I;
   int append;
   HashMap containsKey;
   Map entrySet;
   Object[] get;
   public char Z;
   String getKey = "null";
   public static Applet C;

   public String I(int var1, byte var2) {
      try {
         Object var3 = this.append(var1, (short)5996);
         return var3 == null ? this.getKey : (String)var3;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "tx.p(" + ')');
      }
   }

   void I(REI var1, int var2) {
      try {
         while(true) {
            int var3 = var1.I();
            if (var3 == 0) {
               return;
            }

            this.add(var1, var3, 950174382);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "tx.a(" + ')');
      }
   }

   void add(REI var1, int var2, int var3) {
      try {
         if (1 == var2) {
            this.Z = IZI.I(var1.S(-12558881), 2015897871);
         } else if (var2 == 2) {
            this.I = IZI.I(var1.S(-12558881), 1877656812);
         } else if (3 == var2) {
            this.getKey = var1.E(1756453424);
         } else if (4 == var2) {
            this.append = var1.H((byte)94) * -1961153765;
         } else {
            int var4;
            int var5;
            if (var2 != 5 && var2 != 6) {
               if (7 == var2 || 8 == var2) {
                  var4 = var1.C();
                  this.add = var1.C() * -1158380671;
                  this.get = new Object[var4];

                  for(var5 = 0; var5 < -1179140991 * this.add; ++var5) {
                     int var8 = var1.C();
                     if (var2 == 7) {
                        this.get[var8] = var1.E(1730348772);
                     } else {
                        this.get[var8] = new Integer(var1.H((byte)-14));
                     }
                  }
               }
            } else {
               this.add = var1.C() * -1158380671;
               this.entrySet = new HashMap(-1179140991 * this.add);

               for(var4 = 0; var4 < this.add * -1179140991; ++var4) {
                  var5 = var1.H((byte)-59);
                  Object var6;
                  if (var2 == 5) {
                     var6 = var1.E(-968722088);
                  } else {
                     var6 = new Integer(var1.H((byte)-67));
                  }

                  this.entrySet.put(new Integer(var5), var6);
               }
            }
         }

      } catch (RuntimeException var7) {
         throw DQ.I(var7, "tx.f(" + ')');
      }
   }

   public int I(int var1, int var2) {
      try {
         Object var3 = this.append(var1, (short)31709);
         return var3 == null ? this.append * -1363462381 : ((Integer)var3).intValue();
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "tx.b(" + ')');
      }
   }

   Object append(int var1, short var2) {
      try {
         if (this.get != null) {
            return var1 >= 0 && var1 < this.get.length ? this.get[var1] : null;
         } else {
            return this.entrySet != null ? this.entrySet.get(new Integer(var1)) : null;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "tx.i(" + ')');
      }
   }

   public boolean I(Object var1, byte var2) {
      try {
         if (this.add * -1179140991 == 0) {
            return false;
         } else {
            if (this.containsKey == null) {
               this.containsKey(671224629);
            }

            return this.containsKey.containsKey(var1);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "tx.k(" + ')');
      }
   }

   public int[] I(Object var1, short var2) {
      try {
         if (this.add * -1179140991 == 0) {
            return null;
         } else {
            if (this.containsKey == null) {
               this.containsKey(817562642);
            }

            return (int[])this.containsKey.get(var1);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "tx.d(" + ')');
      }
   }

   public int I(byte var1) {
      try {
         return this.add * -1179140991;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "tx.u(" + ')');
      }
   }

   void containsKey(int var1) {
      try {
         HashMap var2 = new HashMap();
         Object var5;
         Iterator var11;
         Entry var12;
         if (this.get != null) {
            for(int var3 = 0; var3 < this.get.length; ++var3) {
               if (this.get[var3] != null) {
                  Object var4 = this.get[var3];
                  var5 = (List)var2.get(var4);
                  if (var5 == null) {
                     var5 = new LinkedList();
                     var2.put(var4, var5);
                  }

                  ((List)var5).add(new Integer(var3));
               }
            }
         } else {
            if (this.entrySet == null) {
               throw new IllegalStateException();
            }

            Object var6;
            for(var11 = this.entrySet.entrySet().iterator(); var11.hasNext(); ((List)var6).add(var12.getKey())) {
               var12 = (Entry)var11.next();
               var5 = var12.getValue();
               var6 = (List)var2.get(var5);
               if (var6 == null) {
                  var6 = new LinkedList();
                  var2.put(var5, var6);
               }
            }
         }

         this.containsKey = new HashMap();
         var11 = var2.entrySet().iterator();

         while(var11.hasNext()) {
            var12 = (Entry)var11.next();
            List var13 = (List)var12.getValue();
            int[] var14 = new int[var13.size()];
            int var7 = 0;

            Integer var9;
            for(Iterator var8 = var13.iterator(); var8.hasNext(); var14[var7++] = var9.intValue()) {
               var9 = (Integer)var8.next();
            }

            this.containsKey.put(var12.getKey(), var14);
         }

      } catch (RuntimeException var10) {
         throw DQ.I(var10, "tx.x(" + ')');
      }
   }

   public static String Z(byte var0) {
      try {
         String var1 = "www";
         if (AEI.D == GJ.I) {
            var1 = "www-wtrc";
         } else if (GJ.I == AEI.C) {
            var1 = "www-wtqa";
         } else if (AEI.A == GJ.I) {
            var1 = "www-wtwip";
         } else if (AEI.Z == GJ.I) {
            var1 = "www-wti";
         }

         String var2 = "";
         if (XEI.XD != null) {
            var2 = "/p=" + XEI.XD;
         }

         String var3 = XEI.mD.Z + ".com";
         return "http://" + var1 + "." + var3 + "/l=" + WO.U + "/a=" + XEI.v * -1154804873 + var2 + "/";
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "tx.nn(" + ')');
      }
   }

   static void I(int var0, int var1, int var2, byte var3) {
      try {
         VK var4 = IV.I(11, (long)var0);
         var4.I((byte)23);
         var4.L = 1274450087 * var1;
         var4.H = var2 * 293101103;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "tx.aj(" + ')');
      }
   }
}
