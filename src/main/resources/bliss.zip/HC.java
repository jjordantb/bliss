public class HC {
   static int method5348 = 128;
   NJI method5349;
   static int method5416 = 128;
   CEI[] sqrt = null;
   public boolean I;
   static Object Z;
   DEI C = null;
   public CEI[] B = null;
   public DEI D = null;
   public DEI F = null;
   public static int J = 16;
   static Object S;
   static Object A;

   HC(NJI var1) {
      this.method5349 = var1;
      this.I = this.method5349.ZZ;
      if (this.I && !this.method5349.method5349(YCI.A, SDI.C)) {
         this.I = false;
      }

      if (this.I || this.method5349.method5348(YCI.A, SDI.C)) {
         method5348();
         if (!this.I) {
            this.sqrt = new CEI[16];

            int var2;
            byte[] var3;
            for(var2 = 0; var2 < 16; ++var2) {
               var3 = FV.I(Z, var2 * '耀', 32768, (byte)1);
               this.sqrt[var2] = this.method5349.I(YCI.A, 128, 128, true, (byte[])var3);
            }

            this.B = new CEI[16];

            for(var2 = 0; var2 < 16; ++var2) {
               var3 = FV.I(S, var2 * '耀', 32768, (byte)1);
               this.B[var2] = this.method5349.I(YCI.A, 128, 128, true, (byte[])var3);
            }
         } else {
            byte[] var4 = TP.I(Z, false, 1565550558);
            this.C = this.method5349.method5416(YCI.A, 128, 128, 16, true, var4);
            var4 = TP.I(S, false, -1292209598);
            this.D = this.method5349.method5416(YCI.A, 128, 128, 16, true, var4);
         }
      }

   }

   public boolean I() {
      return this.I ? this.C != null : this.sqrt != null;
   }

   public boolean Z() {
      if (!this.method5349.ZZ) {
         return false;
      } else {
         if (this.F == null) {
            byte[] var1;
            if (A == null) {
               var1 = VN.I(128, 128, 16, 8, new XN(419684), 4.0F, 4.0F, 16.0F, 0.5F, 0.6F);
               A = EC.I(var1, false, (short)13525);
            }

            var1 = TP.I(A, false, 466014049);
            byte[] var2 = new byte[var1.length * 4];
            int var3 = 0;

            for(int var4 = 0; var4 < 16; ++var4) {
               int var5 = var4 * 16384;
               int var6 = var5;

               for(int var7 = 0; var7 < 128; ++var7) {
                  int var8 = var6 + var7 * 128;
                  int var9 = var6 + (var7 - 1 & 127) * 128;
                  int var10 = var6 + (var7 + 1 & 127) * 128;

                  for(int var11 = 0; var11 < 128; ++var11) {
                     float var12 = (float)((var1[var9 + var11] & 255) - (var1[var10 + var11] & 255));
                     float var13 = (float)((var1[var8 + (var11 - 1 & 127)] & 255) - (var1[var8 + (var11 + 1 & 127)] & 255));
                     float var14 = (float)(128.0D / Math.sqrt((double)(var13 * var13 + 16384.0F + var12 * var12)));
                     var2[var3++] = (byte)((int)(var13 * var14 + 127.0F));
                     var2[var3++] = (byte)((int)(128.0F * var14 + 127.0F));
                     var2[var3++] = (byte)((int)(var12 * var14 + 127.0F));
                     var2[var3++] = var1[var5++];
                  }
               }
            }

            this.F = this.method5349.method5416(YCI.Z, 128, 128, 16, true, var2);
         }

         return this.F != null;
      }
   }

   static void method5348() {
      byte[] var1;
      if (Z == null) {
         CF var0 = new CF();
         var1 = var0.Z(128, 128, 16);
         Z = EC.I(var1, false, (short)5197);
      }

      if (S == null) {
         YD var2 = new YD();
         var1 = var2.Z(128, 128, 16);
         S = EC.I(var1, false, (short)9144);
      }

   }
}
