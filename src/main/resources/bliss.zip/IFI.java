public class IFI extends XDI {
   int append;
   int toString;
   int D;

   public void method869() {
      PFI.C[1417242443 * this.toString].I(1602235695).I(this.B * 720810617, this.Z * 1369196329 << 16, 87600989 * this.C, this.append * -921351243, false, -1879057895 * this.D, 313723785);
   }

   public void method866(int var1) {
      try {
         PFI.C[1417242443 * this.toString].I(456356673).I(this.B * 720810617, this.Z * 1369196329 << 16, 87600989 * this.C, this.append * -921351243, false, -1879057895 * this.D, -428895124);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "afo.f(" + ')');
      }
   }

   public void method868() {
      PFI.C[1417242443 * this.toString].I(1255556998).I(this.B * 720810617, this.Z * 1369196329 << 16, 87600989 * this.C, this.append * -921351243, false, -1879057895 * this.D, -1194808341);
   }

   IFI(REI var1) {
      super(var1);
      this.toString = var1.C() * 467167843;
      this.D = var1.I() * 1155326505;
      this.append = var1.C() * 624790173;
   }

   static void Z(OU var0, byte var1) {
      try {
         var0.H[var0.J * 681479919 - 2] = OO.I.I(var0.H[var0.J * 681479919 - 2], 245040087).S[var0.H[var0.J * 681479919 - 1]][1];
         var0.J -= -391880689;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "afo.z(" + ')');
      }
   }
}
