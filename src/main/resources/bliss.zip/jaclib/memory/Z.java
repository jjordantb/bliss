package jaclib.memory;

public interface Z {
   int a();

   long f();

   long d();

   long u();

   int x();

   int r();

   int q();

   int n();
}
