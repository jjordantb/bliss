package jaclib.memory;

public interface I {
   int a();

   long f();

   void b(byte[] var1, int var2, int var3, int var4);

   void p(byte[] var1, int var2, int var3, int var4);

   void i(byte[] var1, int var2, int var3, int var4);

   void k(byte[] var1, int var2, int var3, int var4);

   long d();

   long u();

   int x();

   int r();

   int q();

   int n();
}
