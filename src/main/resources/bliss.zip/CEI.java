public interface CEI extends IEI {
   int method75();

   int method76();

   float method77(float var1);

   float method78(float var1);

   boolean method79();

   void method80(boolean var1, boolean var2);

   void method81(int var1, int var2, int var3, int var4, int[] var5, int var6, int var7);

   void method82(int var1, int var2, int var3, int var4, byte[] var5, YCI var6, int var7, int var8);

   void method83(int var1, int var2, int var3, int var4, int[] var5, int var6);

   int method84();

   boolean method85();

   int method86();

   void method87(int var1, int var2, int var3, int var4, byte[] var5, YCI var6, int var7, int var8);

   int method88();

   float method89(float var1);

   float method90(float var1);

   float method91(float var1);

   int method92();

   void method93(int var1, int var2, int var3, int var4, int[] var5, int var6);

   float method94(float var1);

   float method95(float var1);

   void method96(boolean var1, boolean var2);

   void method97(boolean var1, boolean var2);

   void method98(boolean var1, boolean var2);

   void method99(boolean var1, boolean var2);

   void method100(int var1, int var2, int var3, int var4, byte[] var5, YCI var6, int var7, int var8);

   void method101(int var1, int var2, int var3, int var4, int[] var5, int var6, int var7);

   void method102(int var1, int var2, int var3, int var4, int[] var5, int var6, int var7);

   boolean Z();

   void method104(int var1, int var2, int var3, int var4, byte[] var5, YCI var6, int var7, int var8);

   float method105(float var1);

   void method106(boolean var1, boolean var2);

   void method107(int var1, int var2, int var3, int var4, int[] var5, int var6);

   boolean method108();

   float method109(float var1);

   boolean method110();

   boolean method111();
}
