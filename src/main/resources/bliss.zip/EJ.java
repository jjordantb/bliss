public class EJ {
   public static KSI I;
   static int Z;
   static KU C;

   EJ() throws Throwable {
      throw new Error();
   }

   static final void I(HSI var0, X var1, OU var2, int var3) {
      try {
         var0.zI = var2.H[(var2.J -= -391880689) * 681479919] == 1;
         VEI.I(var0, 242919800);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "kc.et(" + ')');
      }
   }

   static final void Z(HSI var0, X var1, OU var2, int var3) {
      try {
         var2.J -= -783761378;
         byte var4 = 10;
         int var5 = var2.H[var2.J * 681479919];
         int var6 = var2.H[1 + var2.J * 681479919];
         EI.I(var0, var4, var5, var6, var2, -781902989);
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "kc.ki(" + ')');
      }
   }
}
