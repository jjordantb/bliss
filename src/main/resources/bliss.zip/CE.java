public class CE {
   public static CE I = new CE();
   static CE Z = new CE();
   static CE C = new CE();

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-102);
         X var4 = IU.F[var2 >> 16];
         FCI.I(var3, var4, var0, -1946261030);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "md.hk(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = JH.R.I(var2).SI * 1625363587;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "md.aax(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         GEI var3 = (GEI)var0.E;
         int var4 = var3.B(var2, -1877195973);
         int var5 = var3.Z(var2, (byte)-50);
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var4;
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var5;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "md.apt(" + ')');
      }
   }

   public static LII B(String var0, int var1, int var2) {
      try {
         MII var3 = new MII();
         var3.Z = var0;
         var3.I = 1609563993 * var1;
         return var3;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "md.a(" + ')');
      }
   }

   static void I(HSI var0, int var1, int var2, byte var3) {
      try {
         if (var0.i == 0) {
            var0.W = -1672688609 * var0.ZC;
         } else if (var0.i == 1) {
            var0.W = -1014229119 * (var0.ZC * 1499181983 + (var1 - -2093041337 * var0.g) / 2);
         } else if (2 == var0.i) {
            var0.W = -1014229119 * (var1 - var0.g * -2093041337 - 1499181983 * var0.ZC);
         } else if (var0.i == 3) {
            var0.W = (var1 * 1499181983 * var0.ZC >> 14) * -1014229119;
         } else if (4 == var0.i) {
            var0.W = -1014229119 * ((var1 - -2093041337 * var0.g) / 2 + (var1 * 1499181983 * var0.ZC >> 14));
         } else {
            var0.W = (var1 - -2093041337 * var0.g - (1499181983 * var0.ZC * var1 >> 14)) * -1014229119;
         }

         if (var0.z == 0) {
            var0.e = 705123139 * var0.l;
         } else if (var0.z == 1) {
            var0.e = (var0.l * -901738979 + (var2 - 457937409 * var0.o) / 2) * 1145252063;
         } else if (var0.z == 2) {
            var0.e = (var2 - 457937409 * var0.o - -901738979 * var0.l) * 1145252063;
         } else if (3 == var0.z) {
            var0.e = 1145252063 * (var0.l * -901738979 * var2 >> 14);
         } else if (var0.z == 4) {
            var0.e = ((-901738979 * var0.l * var2 >> 14) + (var2 - 457937409 * var0.o) / 2) * 1145252063;
         } else {
            var0.e = 1145252063 * (var2 - var0.o * 457937409 - (var0.l * -901738979 * var2 >> 14));
         }

         if (XEI.DB && (XEI.I(var0).K * -1266165749 != 0 || var0.X * -1215239439 == 0)) {
            if (var0.W * 1354508417 < 0) {
               var0.W = 0;
            } else if (var0.W * 1354508417 + -2093041337 * var0.g > var1) {
               var0.W = -1014229119 * (var1 - -2093041337 * var0.g);
            }

            if (var0.e * -749038817 < 0) {
               var0.e = 0;
            } else if (var0.e * -749038817 + 457937409 * var0.o > var2) {
               var0.e = 1145252063 * (var2 - 457937409 * var0.o);
            }
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "md.li(" + ')');
      }
   }

   public static void I(int var0) {
      try {
         for(NM var1 = (NM)QW.C.C(2004354413); var1 != null; var1 = (NM)QW.C.Z((byte)-69)) {
            if (!var1.K) {
               RA.I(var1.S * 1566028323, (byte)49);
            } else {
               var1.K = false;
            }
         }

      } catch (RuntimeException var2) {
         throw DQ.I(var2, "md.u(" + ')');
      }
   }
}
