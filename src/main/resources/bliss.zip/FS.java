import jaggl.OpenGL;

public class FS implements WAI {
   NS glFramebufferTexture2DEXT;
   int method76;

   public void method167(int var1) {
      OpenGL.glFramebufferTexture2DEXT(36160, var1, this.glFramebufferTexture2DEXT.I, this.glFramebufferTexture2DEXT.Z, this.method76);
   }

   public int a() {
      return this.glFramebufferTexture2DEXT.method92();
   }

   public int f() {
      return this.glFramebufferTexture2DEXT.method76();
   }

   public void x() {
   }

   public void b() {
   }

   public int p() {
      return this.glFramebufferTexture2DEXT.method92();
   }

   public int i() {
      return this.glFramebufferTexture2DEXT.method92();
   }

   public void method165(int var1) {
      OpenGL.glFramebufferTexture2DEXT(36160, var1, this.glFramebufferTexture2DEXT.I, this.glFramebufferTexture2DEXT.Z, this.method76);
   }

   public int k() {
      return this.glFramebufferTexture2DEXT.method76();
   }

   public void u() {
   }

   public void d() {
   }

   FS(NS var1, int var2) {
      this.method76 = var2;
      this.glFramebufferTexture2DEXT = var1;
   }

   public void method166(int var1) {
      OpenGL.glFramebufferTexture2DEXT(36160, var1, this.glFramebufferTexture2DEXT.I, this.glFramebufferTexture2DEXT.Z, this.method76);
   }

   public void method168(int var1) {
      OpenGL.glFramebufferTexture2DEXT(36160, var1, this.glFramebufferTexture2DEXT.I, this.glFramebufferTexture2DEXT.Z, this.method76);
   }

   public void method164(int var1) {
      OpenGL.glFramebufferTexture2DEXT(36160, var1, this.glFramebufferTexture2DEXT.I, this.glFramebufferTexture2DEXT.Z, this.method76);
   }
}
