public abstract class IR extends YQ {
   IR G;
   public AP H;
   public byte K;
   public byte L;
   int M;
   public KN[] N;

   abstract boolean method4349();

   abstract boolean method4350(GSI var1, int var2, int var3, byte var4);

   abstract boolean method4351();

   abstract boolean method4352(GSI var1, int var2, int var3);

   abstract boolean method4353();

   abstract int method4354(GE[] var1, int var2);

   abstract void method4355(GSI var1, IR var2, int var3, int var4, int var5, boolean var6, int var7);

   int I(byte var1) {
      return 0;
   }

   abstract void method4357(GSI var1, int var2);

   public abstract HP method4358(GSI var1, byte var2);

   abstract boolean method4359(GSI var1);

   abstract boolean method4360(int var1);

   public abstract int method4361(int var1);

   void I(int var1, int var2) {
      try {
         this.N = new KN[var1];

         for(int var3 = 0; var3 < this.N.length; ++var3) {
            this.N[var3] = new KN();
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "adp.dx(" + ')');
      }
   }

   public int Z(byte var1) {
      try {
         return -this.method4361(1951240662);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "adp.bx(" + ')');
      }
   }

   abstract boolean method4364(GSI var1, byte var2);

   abstract boolean method4365();

   abstract boolean method4366(int var1);

   public abstract HP method4367(GSI var1);

   public abstract HP method4368(GSI var1);

   abstract boolean method4369();

   abstract KP method4370(GSI var1);

   abstract void method4371(GSI var1);

   abstract boolean method4372(GSI var1, int var2, int var3);

   abstract void method4373(GSI var1);

   abstract boolean method4374();

   abstract void method4375(GSI var1, IR var2, int var3, int var4, int var5, boolean var6);

   abstract boolean method4376(short var1);

   abstract void method4377();

   abstract void method4378();

   public abstract int method4379();

   public abstract int method4380();

   public abstract int method4381();

   abstract boolean method4382();

   abstract boolean method4383();

   IR(AP var1) {
      this.H = var1;
   }

   abstract boolean method4384();

   abstract boolean method4385(GSI var1, int var2, int var3);

   abstract boolean method4386();

   abstract boolean method4387();

   abstract void method4388(GSI var1, IR var2, int var3, int var4, int var5, boolean var6);

   abstract boolean method4389(GSI var1);

   abstract int method4390(GE[] var1);

   abstract boolean method4391(GSI var1);

   int I(int var1, int var2, GE[] var3, int var4) {
      try {
         long var5 = this.H.c[this.K][var1][var2];
         long var7 = 0L;

         int var9;
         int var10;
         for(var9 = 0; var7 <= 48L; var7 += 16L) {
            var10 = (int)(var5 >> (int)var7 & 65535L);
            if (var10 <= 0) {
               break;
            }

            var3[var9++] = this.H.b[var10 - 1].I;
         }

         for(var10 = var9; var10 < 4; ++var10) {
            var3[var10] = null;
         }

         return var9;
      } catch (RuntimeException var11) {
         throw DQ.I(var11, "adp.ds(" + ')');
      }
   }

   abstract boolean method4393(GSI var1);

   abstract KP method4394(GSI var1, int var2);

   abstract boolean method4395();

   abstract boolean method4396();

   abstract boolean method4397();

   abstract void method4398(byte var1);

   abstract boolean method4399(byte var1);

   abstract boolean method4400();

   static final void I(HSI var0, X var1, OU var2, byte var3) {
      try {
         int var4 = var2.H[(var2.J -= -391880689) * 681479919] - 1;
         if (var4 >= 0 && var4 <= 9) {
            var0.Z(var4, (String)var2.S[(var2.A -= 969361751) * -203050393], 1110385787);
         } else {
            var2.A -= 969361751;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "adp.is(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-7);
         X var4 = IU.F[var2 >> 16];
         LJ.I(var3, var4, var0, 1982682635);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "adp.fx(" + ')');
      }
   }

   static void C(byte var0) {
      try {
         if (FW.J.l.Z((byte)-114) == 1) {
            KBI.F.Z(new XS(WS.J, (QEI)null), -1108671657);
         } else {
            XEI.mI.P(1601177628);
            NSI.I(-119452364);
         }

      } catch (RuntimeException var2) {
         throw DQ.I(var2, "adp.v(" + ')');
      }
   }
}
