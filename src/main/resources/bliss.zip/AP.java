import java.util.Iterator;

public class AP {
   IR[] B;
   public int I;
   float[] F;
   int NA = 16;
   int O;
   GSI Z;
   KII C;
   boolean S;
   boolean UA;
   public GP D;
   int J;
   public int A;
   IR[] append;
   public BP[][][] E;
   public YJI[] G;
   public BP[][][] H;
   public YJI[] K;
   public BP[][][] L;
   public YJI[] M;
   int[][] hasNext;
   short[][] iterator;
   byte[][] method229;
   byte[][] method4354;
   byte[][] method4355;
   byte[][] method4357;
   public ZP N;
   GE[] method4360;
   int method4361 = 5029;
   int method4364 = 10093;
   IR[] method4366;
   int method4376;
   IR[] method4394;
   int method4398;
   int P;
   int method4399 = 5043;
   int Q;
   ZR[] method5021;
   public static boolean R = true;
   int method5025 = 0;
   int T;
   int U;
   int V;
   int W;
   int X;
   int method5048;
   public int Y;
   public int i;
   int method5057;
   int method5058;
   int method5060;
   int z;
   long[][][] c;
   int method6338 = 65391;
   int method6342;
   IR[] method6353;
   WO[] b;
   boolean[] next;
   int remove;
   boolean[][] toString;
   int[] w;
   boolean[][] d;
   boolean[][] f;
   static int j;

   public void I(int var1, byte var2) {
   }

   public void I(OS var1, int var2) {
   }

   public SR I(int var1, int var2, int var3, int var4) {
      try {
         BP var5 = this.E[var1][var2][var3];
         if (var5 == null) {
            return null;
         } else {
            this.NA(var5.J, -144193556);
            if (var5.J != null) {
               SR var6 = var5.J;
               var5.J = null;
               return var6;
            } else {
               return null;
            }
         }
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "nu.ax(" + ')');
      }
   }

   public void I(int var1) {
      try {
         for(int var2 = 0; var2 < 1204219039 * this.method5025; ++var2) {
            ZR var3 = this.method5021[var2];
            this.F(var3, true, 2052556984);
            this.method5021[var2] = null;
         }

         this.method5025 = 0;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "nu.m(" + ')');
      }
   }

   public void I(int var1, int var2, int var3) {
      try {
         BP var4 = this.E[0][var1][var2];

         for(int var5 = 0; var5 < 3; ++var5) {
            BP var6 = this.E[var5][var1][var2] = this.E[var5 + 1][var1][var2];
            if (var6 != null) {
               for(XO var7 = var6.Z; var7 != null; var7 = var7.C) {
                  ZR var8 = var7.Z;
                  if (var1 == var8.R && var8.O == var2) {
                     var8.K = (byte)(var8.K - 1);
                  }
               }

               if (var6.J != null) {
                  var6.J.K = (byte)(var6.J.K - 1);
               }

               if (var6.C != null) {
                  var6.C.K = (byte)(var6.C.K - 1);
               }

               if (var6.B != null) {
                  var6.B.K = (byte)(var6.B.K - 1);
               }

               if (var6.D != null) {
                  var6.D.K = (byte)(var6.D.K - 1);
               }

               if (var6.F != null) {
                  var6.F.K = (byte)(var6.F.K - 1);
               }
            }
         }

         if (this.E[0][var1][var2] == null) {
            this.E[0][var1][var2] = new BP(0);
            this.E[0][var1][var2].H = 1;
         }

         this.E[0][var1][var2].I = var4;
         this.E[3][var1][var2] = null;
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "nu.i(" + ')');
      }
   }

   BP B(int var1, int var2, int var3, int var4) {
      try {
         if (this.E[var1][var2][var3] == null) {
            boolean var5 = this.E[0][var2][var3] != null && this.E[0][var2][var3].I != null;
            if (var5 && var1 >= 1678382205 * this.Y - 1) {
               return null;
            }

            this.Z(var1, var2, var3, 127761391);
         }

         return this.E[var1][var2][var3];
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "nu.k(" + ')');
      }
   }

   public void Z(int var1, int var2, int var3, int var4) {
      try {
         boolean var5 = this.E[0][var2][var3] != null && this.E[0][var2][var3].I != null;

         for(int var6 = var1; var6 >= 0; --var6) {
            if (this.E[var6][var2][var3] == null) {
               BP var7 = this.E[var6][var2][var3] = new BP(var6);
               if (var5) {
                  ++var7.H;
               }
            }
         }

      } catch (RuntimeException var8) {
         throw DQ.I(var8, "nu.d(" + ')');
      }
   }

   public int I(int var1, int var2, byte var3) {
      try {
         return this.iterator != null ? this.iterator[var1][var2] & '\uffff' : 0;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "nu.x(" + ')');
      }
   }

   public int Z(int var1, int var2, byte var3) {
      try {
         return this.hasNext != null ? this.hasNext[var1][var2] & 16777215 : 0;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "nu.r(" + ')');
      }
   }

   public int C(int var1, int var2, byte var3) {
      try {
         return this.method229 != null ? this.method229[var1][var2] & 255 : 0;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "nu.q(" + ')');
      }
   }

   public int B(int var1, int var2, byte var3) {
      try {
         return this.method4354 != null ? this.method4354[var1][var2] & 255 : 0;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "nu.n(" + ')');
      }
   }

   public int Z(int var1, int var2, int var3) {
      try {
         return this.method4357 != null ? this.method4357[var1][var2] & 255 : 0;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "nu.z(" + ')');
      }
   }

   public void I(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, byte var9) {
      try {
         if (this.hasNext != null) {
            this.hasNext[var1][var2] = -16777216 | var3;
         }

         if (this.iterator != null) {
            this.iterator[var1][var2] = (short)var4;
         }

         if (this.method229 != null) {
            this.method229[var1][var2] = (byte)var5;
         }

         if (this.method4354 != null) {
            this.method4354[var1][var2] = (byte)var6;
         }

         if (this.method4355 != null) {
            this.method4355[var1][var2] = (byte)var7;
         }

         if (this.method4357 != null) {
            this.method4357[var1][var2] = (byte)var8;
         }

      } catch (RuntimeException var11) {
         throw DQ.I(var11, "nu.y(" + ')');
      }
   }

   public void I(int var1, int var2, int var3, NR var4, NR var5, byte var6) {
      try {
         BP var7 = this.B(var1, var2, var3, 1985350813);
         if (var7 != null) {
            var7.C = var4;
            var7.B = var5;
            int var8 = this.G == this.M ? 1 : 0;
            if (var4.method4399((byte)13)) {
               if (var4.method4376((short)255)) {
                  var4.G = this.method6353[var8];
                  this.method6353[var8] = var4;
               } else {
                  var4.G = this.method4366[var8];
                  this.method4366[var8] = var4;
               }
            } else {
               var4.G = this.method4394[var8];
               this.method4394[var8] = var4;
            }

            if (var5 != null) {
               if (var5.method4399((byte)13)) {
                  if (var5.method4376((short)255)) {
                     var5.G = this.method6353[var8];
                     this.method6353[var8] = var5;
                  } else {
                     var5.G = this.method4366[var8];
                     this.method4366[var8] = var5;
                  }
               } else {
                  var5.G = this.method4394[var8];
                  this.method4394[var8] = var5;
               }
            }
         }

      } catch (RuntimeException var9) {
         throw DQ.I(var9, "nu.v(" + ')');
      }
   }

   public void I(int var1, int var2, int var3, GR var4, GR var5, int var6) {
      try {
         BP var7 = this.B(var1, var2, var3, 937547322);
         if (var7 != null) {
            var7.D = var4;
            var7.F = var5;
            int var8 = this.G == this.M ? 1 : 0;
            if (var4.method4399((byte)13)) {
               if (var4.method4376((short)255)) {
                  var4.G = this.method6353[var8];
                  this.method6353[var8] = var4;
               } else {
                  var4.G = this.method4366[var8];
                  this.method4366[var8] = var4;
               }
            } else {
               var4.G = this.method4394[var8];
               this.method4394[var8] = var4;
            }

            if (var5 != null) {
               if (var5.method4399((byte)13)) {
                  if (var5.method4376((short)255)) {
                     var5.G = this.method6353[var8];
                     this.method6353[var8] = var5;
                  } else {
                     var5.G = this.method4366[var8];
                     this.method4366[var8] = var5;
                  }
               } else {
                  var5.G = this.method4394[var8];
                  this.method4394[var8] = var5;
               }
            }
         }

      } catch (RuntimeException var9) {
         throw DQ.I(var9, "nu.g(" + ')');
      }
   }

   public boolean I(ZR var1, boolean var2, byte var3) {
      try {
         boolean var4 = this.G == this.M;
         int var5 = 0;
         short var6 = 0;
         byte var7 = 0;
         var1.I(449273804);
         if (var1.R >= 0 && var1.O >= 0 && var1.P < 1988988347 * this.A && var1.Q < this.i * 1340714547) {
            short var8 = 0;

            int var9;
            int var10;
            for(var9 = var1.R; var9 <= var1.P; ++var9) {
               for(var10 = var1.O; var10 <= var1.Q; ++var10) {
                  BP var11 = this.B(var1.K, var9, var10, (int)960411819);
                  if (var11 != null) {
                     XO var12 = DJ.I((ZR)var1, (byte)47);
                     XO var13 = var11.Z;
                     if (var13 == null) {
                        var11.Z = var12;
                     } else {
                        while(var13.C != null) {
                           var13 = var13.C;
                        }

                        var13.C = var12;
                     }

                     if (var4 && (this.hasNext[var9][var10] & -16777216) != 0) {
                        var5 = this.hasNext[var9][var10];
                        var6 = this.iterator[var9][var10];
                        var7 = this.method229[var9][var10];
                     }

                     if (!var2 && var11.J != null && var11.J.O > var8) {
                        var8 = var11.J.O;
                     }
                  }
               }
            }

            if (var4 && (var5 & -16777216) != 0) {
               for(var9 = var1.R; var9 <= var1.P; ++var9) {
                  for(var10 = var1.O; var10 <= var1.Q; ++var10) {
                     if ((this.hasNext[var9][var10] & -16777216) == 0) {
                        this.hasNext[var9][var10] = var5;
                        this.iterator[var9][var10] = var6;
                        this.method229[var9][var10] = var7;
                     }
                  }
               }
            }

            if (var2) {
               this.method5021[(this.method5025 += -1037881505) * 1204219039 - 1] = var1;
               var1.H = this;
            } else {
               var9 = this.G == this.M ? 1 : 0;
               if (var1.method4399((byte)13)) {
                  if (var1.method4376((short)255)) {
                     var1.G = this.method6353[var9];
                     this.method6353[var9] = var1;
                  } else {
                     var1.G = this.method4366[var9];
                     this.method4366[var9] = var1;
                  }
               } else {
                  var1.G = this.method4394[var9];
                  this.method4394[var9] = var1;
               }
            }

            if (var2) {
               SF var15 = SF.I(var1.I().I);
               var15.C -= (float)var8;
               var1.I(var15);
               var15.I();
            }

            return true;
         } else {
            return false;
         }
      } catch (RuntimeException var14) {
         throw DQ.I(var14, "nu.e(" + ')');
      }
   }

   public void I(int var1, int var2, int var3, int var4, byte var5) {
      try {
         BP var6 = this.E[var1][var2][var3];
         if (var6 != null) {
            GR var7 = var6.D;
            GR var8 = var6.F;
            if (var7 != null) {
               var7.O = (short)(var4 * var7.O / (16 << this.I * -1688804109 - 7));
               var7.P = (short)(var7.P * var4 / (16 << -1688804109 * this.I - 7));
            }

            if (var8 != null) {
               var8.O = (short)(var4 * var8.O / (16 << this.I * -1688804109 - 7));
               var8.P = (short)(var8.P * var4 / (16 << this.I * -1688804109 - 7));
            }
         }

      } catch (RuntimeException var9) {
         throw DQ.I(var9, "nu.c(" + ')');
      }
   }

   public void I(byte var1) {
      try {
         this.method4355(1, this.Y * 1678382205, 722872945);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "nu.am(" + ')');
      }
   }

   public NR C(int var1, int var2, int var3, int var4) {
      try {
         BP var5 = this.E[var1][var2][var3];
         if (var5 != null) {
            this.NA(var5.C, -452884210);
            if (var5.C != null) {
               NR var6 = var5.C;
               var5.C = null;
               return var6;
            }
         }

         return null;
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "nu.w(" + ')');
      }
   }

   public NR I(int var1, int var2, int var3, byte var4) {
      try {
         BP var5 = this.E[var1][var2][var3];
         if (var5 != null) {
            this.NA(var5.B, -123141942);
            if (var5.B != null) {
               NR var6 = var5.B;
               var5.B = null;
               return var6;
            }
         }

         return null;
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "nu.j(" + ')');
      }
   }

   public GR D(int var1, int var2, int var3, int var4) {
      try {
         BP var5 = this.E[var1][var2][var3];
         if (var5 != null) {
            this.NA(var5.F, -531623342);
            if (var5.F != null) {
               GR var6 = var5.F;
               var5.F = null;
               return var6;
            }
         }

         return null;
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "nu.l(" + ')');
      }
   }

   public AP(GSI var1, int var2, int var3, int var4, int var5, int var6, boolean var7, boolean var8) {
      this.method4364 = 10093;
      this.method4361 = 5029;
      this.method4399 = 5043;
      this.F = new float[3];
      this.method4360 = new GE[8];
      this.method6338 = 65391;
      this.Z = var1;
      this.S = this.Z.method5048() > 0;
      this.I = var2 * -1524575173;
      this.P = (1 << this.I * -1688804109) * 732171711;
      this.X = -413418327 * (this.P * 1828905535 >> 1);
      this.Y = var3 * 1634141397;
      this.A = 1005334387 * var4;
      this.i = -1342636805 * var5;
      this.Q = var6 * 1571198643;
      this.C = new KII();
      this.D = new GP(this);
      this.H = new BP[var3][1988988347 * this.A][1340714547 * this.i];
      this.K = new YJI[var3];
      if (var7) {
         this.hasNext = new int[1988988347 * this.A][1340714547 * this.i];
         this.method229 = new byte[1988988347 * this.A][1340714547 * this.i];
         this.iterator = new short[this.A * 1988988347][1340714547 * this.i];
         this.method4354 = new byte[1988988347 * this.A][1340714547 * this.i];
         this.method4355 = new byte[this.A * 1988988347][this.i * 1340714547];
         this.method4357 = new byte[this.A * 1988988347][1340714547 * this.i];
         this.L = new BP[1][this.A * 1988988347][this.i * 1340714547];
         this.M = new YJI[1];
      }

      if (var8) {
         this.c = new long[var3][var4][var5];
         this.b = new WO['ｯ'];
         this.next = new boolean['ｯ'];
         this.method6342 = 0;
      }

      this.I(false, -740850409);
      this.method4366 = new IR[2];
      this.method6353 = new IR[2];
      this.method4394 = new IR[2];
      this.append = new IR[10093];
      this.method4398 = 0;
      this.B = new IR[5029];
      this.remove = 0;
      this.method5021 = new ZR[5043];
      this.method5025 = 0;
      this.d = new boolean[this.Q * 583010427 + this.Q * 583010427 + 1][this.Q * 583010427 + this.Q * 583010427 + 1];
      this.toString = new boolean[2 + 583010427 * this.Q + this.Q * 583010427][583010427 * this.Q + 583010427 * this.Q + 2];
      this.w = new int[2 + 583010427 * this.Q + this.Q * 583010427];
      this.N = new ZP(false);
   }

   public ZR I(int var1, int var2, int var3, XSI var4, short var5) {
      try {
         BP var6 = this.E[var1][var2][var3];
         if (var6 == null) {
            return null;
         } else {
            for(XO var7 = var6.Z; var7 != null; var7 = var7.C) {
               ZR var8 = var7.Z;
               if ((var4 == null || var4.method229(var8, -98426520)) && var8.R == var2 && var8.O == var3) {
                  this.F(var8, false, 2114979879);
                  return var8;
               }
            }

            return null;
         }
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "nu.ak(" + ')');
      }
   }

   void F(ZR var1, boolean var2, int var3) {
      try {
         for(int var4 = var1.R; var4 <= var1.P; ++var4) {
            for(int var5 = var1.O; var5 <= var1.Q; ++var5) {
               BP var6 = this.E[var1.K][var4][var5];
               if (var6 != null) {
                  XO var7 = var6.Z;

                  for(XO var8 = null; var7 != null; var7 = var7.C) {
                     if (var1 == var7.Z) {
                        if (var8 != null) {
                           var8.C = var7.C;
                        } else {
                           var6.Z = var7.C;
                        }

                        var7.I((byte)-98);
                        break;
                     }

                     var8 = var7;
                  }
               }
            }
         }

         if (!var2) {
            this.NA(var1, -615451520);
         }

      } catch (RuntimeException var9) {
         throw DQ.I(var9, "nu.ae(" + ')');
      }
   }

   void NA(IR var1, int var2) {
      try {
         if (var1 != null) {
            var1.F();

            for(int var3 = 0; var3 < 2; ++var3) {
               IR var4 = null;

               IR var5;
               for(var5 = this.method4366[var3]; var5 != null; var5 = var5.G) {
                  if (var5 == var1) {
                     if (var4 != null) {
                        var4.G = var5.G;
                     } else {
                        this.method4366[var3] = var5.G;
                     }

                     return;
                  }

                  var4 = var5;
               }

               var4 = null;

               for(var5 = this.method6353[var3]; var5 != null; var5 = var5.G) {
                  if (var5 == var1) {
                     if (var4 != null) {
                        var4.G = var5.G;
                     } else {
                        this.method6353[var3] = var5.G;
                     }

                     return;
                  }

                  var4 = var5;
               }

               var4 = null;

               for(var5 = this.method4394[var3]; var5 != null; var5 = var5.G) {
                  if (var1 == var5) {
                     if (var4 != null) {
                        var4.G = var5.G;
                     } else {
                        this.method4394[var3] = var5.G;
                     }

                     return;
                  }

                  var4 = var5;
               }
            }
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "nu.ao(" + ')');
      }
   }

   public NR F(int var1, int var2, int var3, int var4) {
      try {
         BP var5 = this.E[var1][var2][var3];
         return var5 == null ? null : var5.C;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "nu.ad(" + ')');
      }
   }

   public NR Z(int var1, int var2, int var3, byte var4) {
      try {
         BP var5 = this.E[var1][var2][var3];
         return var5 == null ? null : var5.B;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "nu.av(" + ')');
      }
   }

   public GR J(int var1, int var2, int var3, int var4) {
      try {
         BP var5 = this.E[var1][var2][var3];
         return var5 == null ? null : var5.D;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "nu.at(" + ')');
      }
   }

   public LR S(int var1, int var2, int var3, int var4) {
      try {
         BP var5 = this.E[var1][var2][var3];
         return var5 == null ? null : var5.S;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "nu.ah(" + ')');
      }
   }

   public ZR I(int var1, int var2, int var3, XSI var4, int var5) {
      try {
         BP var6 = this.E[var1][var2][var3];
         if (var6 == null) {
            return null;
         } else {
            for(XO var7 = var6.Z; var7 != null; var7 = var7.C) {
               ZR var8 = var7.Z;
               if ((var4 == null || var4.method229(var8, 240755990)) && var8.R == var2 && var8.O == var3) {
                  return var8;
               }
            }

            return null;
         }
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "nu.ai(" + ')');
      }
   }

   public XO A(int var1, int var2, int var3, int var4) {
      try {
         BP var5 = this.E[var1][var2][var3];
         return var5 == null ? null : var5.Z;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "nu.al(" + ')');
      }
   }

   public void I() {
      for(int var1 = 0; var1 < 1678382205 * this.Y; ++var1) {
         for(int var2 = 0; var2 < this.A * 1988988347; ++var2) {
            for(int var3 = 0; var3 < 1340714547 * this.i; ++var3) {
               BP var4 = this.E[var1][var2][var3];
               if (var4 != null) {
                  NR var5 = var4.C;
                  NR var6 = var4.B;
                  if (var5 != null && var5.method4366(1673017934)) {
                     this.S(var5, var1, var2, var3, 1, 1);
                     if (var6 != null && var6.method4366(1884072683)) {
                        this.S(var6, var1, var2, var3, 1, 1);
                        var6.method4355(this.Z, var5, 0, 0, 0, false, 1471147933);
                        var6.method4398((byte)115);
                     }

                     var5.method4398((byte)125);
                  }

                  for(XO var7 = var4.Z; var7 != null; var7 = var7.C) {
                     ZR var8 = var7.Z;
                     if (var8 != null && var8.method4366(1908249416)) {
                        this.S(var8, var1, var2, var3, 1 + (var8.P - var8.R), var8.Q - var8.O + 1);
                        var8.method4398((byte)61);
                     }
                  }

                  SR var9 = var4.J;
                  if (var9 != null && var9.method4366(1396337054)) {
                     this.O(var9, var1, var2, var3, 795291520);
                     var9.method4398((byte)19);
                  }
               }
            }
         }
      }

   }

   void O(IR var1, int var2, int var3, int var4, int var5) {
      try {
         BP var6;
         if (var3 < this.A * 1988988347) {
            var6 = this.E[var2][var3 + 1][var4];
            if (var6 != null && var6.J != null && var6.J.method4366(1670858079)) {
               var1.method4355(this.Z, var6.J, 1828905535 * this.P, 0, 0, true, 1480517000);
            }
         }

         if (var4 < 1988988347 * this.A) {
            var6 = this.E[var2][var3][var4 + 1];
            if (var6 != null && var6.J != null && var6.J.method4366(1930175079)) {
               var1.method4355(this.Z, var6.J, 0, 0, 1828905535 * this.P, true, 1828441739);
            }
         }

         if (var3 < 1988988347 * this.A && var4 < this.i * 1340714547) {
            var6 = this.E[var2][1 + var3][var4 + 1];
            if (var6 != null && var6.J != null && var6.J.method4366(2111976416)) {
               var1.method4355(this.Z, var6.J, this.P * 1828905535, 0, this.P * 1828905535, true, 1058354287);
            }
         }

         if (var3 < 1988988347 * this.A && var4 > 0) {
            var6 = this.E[var2][var3 + 1][var4 - 1];
            if (var6 != null && var6.J != null && var6.J.method4366(1781377638)) {
               var1.method4355(this.Z, var6.J, this.P * 1828905535, 0, -(1828905535 * this.P), true, 151502999);
            }
         }

      } catch (RuntimeException var7) {
         throw DQ.I(var7, "nu.ap(" + ')');
      }
   }

   void S(IR var1, int var2, int var3, int var4, int var5, int var6) {
      boolean var7 = true;
      int var8 = var3;
      int var9 = var5 + var3;
      int var10 = var4 - 1;
      int var11 = var4 + var6;

      for(int var12 = var2; var12 <= var2 + 1; ++var12) {
         if (this.Y * 1678382205 != var12) {
            for(int var13 = var8; var13 <= var9; ++var13) {
               if (var13 >= 0 && var13 < this.A * 1988988347) {
                  for(int var14 = var10; var14 <= var11; ++var14) {
                     if (var14 >= 0 && var14 < 1340714547 * this.i && (!var7 || var13 >= var9 || var14 >= var11 || var14 < var4 && var13 != var3)) {
                        BP var15 = this.E[var12][var13][var14];
                        if (var15 != null) {
                           int var16 = (this.G[var12].I(var13, var14, (byte)-40) + this.G[var12].I(1 + var13, var14, (byte)-92) + this.G[var12].I(var13, 1 + var14, (byte)-41) + this.G[var12].I(var13 + 1, var14 + 1, (byte)-106)) / 4 - (this.G[var2].I(var3, var4, (byte)0) + this.G[var2].I(var3 + 1, var4, (byte)-79) + this.G[var2].I(var3, 1 + var4, (byte)-78) + this.G[var2].I(1 + var3, 1 + var4, (byte)-80)) / 4;
                           NR var17 = var15.C;
                           NR var18 = var15.B;
                           if (var17 != null && var17.method4366(2051783389)) {
                              var1.method4355(this.Z, var17, this.X * 394962841 * (1 - var5) + 1828905535 * this.P * (var13 - var3), var16, (var14 - var4) * 1828905535 * this.P + this.X * 394962841 * (1 - var6), var7, 1604469537);
                           }

                           if (var18 != null && var18.method4366(1486894505)) {
                              var1.method4355(this.Z, var18, this.P * 1828905535 * (var13 - var3) + this.X * 394962841 * (1 - var5), var16, 1828905535 * this.P * (var14 - var4) + (1 - var6) * 394962841 * this.X, var7, 1798941005);
                           }

                           for(XO var19 = var15.Z; var19 != null; var19 = var19.C) {
                              ZR var20 = var19.Z;
                              if (var20 != null && var20.method4366(1399351341) && (var20.R == var13 || var8 == var13) && (var20.O == var14 || var10 == var14)) {
                                 int var21 = 1 + (var20.P - var20.R);
                                 int var22 = var20.Q - var20.O + 1;
                                 var1.method4355(this.Z, var20, 1828905535 * this.P * (var20.R - var3) + (var21 - var5) * 394962841 * this.X, var16, (var20.O - var4) * this.P * 1828905535 + 394962841 * this.X * (var22 - var6), var7, 784338104);
                              }
                           }
                        }
                     }
                  }
               }
            }

            --var8;
            var7 = false;
         }
      }

   }

   public void I(int var1, int var2, int var3, int var4, byte[][][] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, int var11, byte var12, int var13, int var14, boolean var15, boolean var16, int var17, boolean var18) {
      this.D.Z = true;
      this.UA = var16;
      this.z = (var2 >> this.I * -1688804109) * -14089225;
      this.J = (var4 >> -1688804109 * this.I) * 1732036403;
      this.T = var2 * -648073099;
      this.U = var4 * -701298583;
      this.V = var3 * -1885539273;
      this.method4376 = 1283818765 * this.z - this.Q * -1864237879;
      if (this.method4376 * 1387802915 < 0) {
         this.method5048 = -(153202551 * this.method4376);
         this.method4376 = 0;
      } else {
         this.method5048 = 0;
      }

      this.method5058 = this.J * 1233371147 - this.Q * -678030197;
      if (1655515601 * this.method5058 < 0) {
         this.O = -(754782463 * this.method5058);
         this.method5058 = 0;
      } else {
         this.O = 0;
      }

      this.method5057 = -1827235035 * this.z + this.Q * -679030015;
      if (this.method5057 * 945006459 > this.A * 1988988347) {
         this.method5057 = this.A * -1126318399;
      }

      this.method5060 = this.Q * -1363529219 + this.J * -690201987;
      if (this.method5060 * 779833815 > this.i * 1340714547) {
         this.method5060 = 1467937541 * this.i;
      }

      boolean[][] var19 = this.d;
      boolean[][] var20 = this.toString;
      int var21;
      int var22;
      if (this.UA) {
         for(var21 = 0; var21 < 583010427 * this.Q + this.Q * 583010427 + 2; ++var21) {
            var22 = 0;
            int var23 = 0;

            for(int var24 = 0; var24 < 583010427 * this.Q + this.Q * 583010427 + 2; ++var24) {
               if (var24 > 1) {
                  this.w[var24 - 2] = var22;
               }

               var22 = var23;
               int var25 = this.z * -804213305 - 583010427 * this.Q + var21;
               int var26 = 465603579 * this.J - this.Q * 583010427 + var24;
               int var27;
               if (var25 >= 0 && var26 >= 0 && var25 < 1988988347 * this.A && var26 < 1340714547 * this.i) {
                  var27 = var25 << this.I * -1688804109;
                  int var28 = var26 << -1688804109 * this.I;
                  int var29 = this.K[this.K.length - 1].I(var25, var26, (byte)-48) - (1000 << -1688804109 * this.I - 7);
                  int var30 = (this.M != null ? this.M[0].I(var25, var26, (byte)-75) + 1828905535 * this.P : this.K[0].I(var25, var26, (byte)-70) + 1828905535 * this.P) + (1000 << this.I * -1688804109 - 7);
                  var23 = this.Z.method5025(var27, var29, var28, var27, var30, var28);
                  this.toString[var21][var24] = var23 == 0;
               } else {
                  var23 = -1;
                  this.toString[var21][var24] = false;
               }

               if (var21 > 0 && var24 > 0) {
                  var27 = this.w[var24 - 1] & this.w[var24] & var22 & var23;
                  this.d[var21 - 1][var24 - 1] = var27 == 0;
               }
            }

            this.w[583010427 * this.Q + this.Q * 583010427] = var22;
            this.w[1 + 583010427 * this.Q + 583010427 * this.Q] = var23;
         }

         if (!var18) {
            this.D.Z = false;
         } else {
            this.D.C = var6;
            this.D.O = var7;
            this.D.P = var8;
            this.D.D = var9;
            this.D.I = var10;
            this.D.I(this.Z, var11);
         }
      } else {
         if (this.f == null) {
            this.f = new boolean[this.Q * 583010427 + 583010427 * this.Q + 2][583010427 * this.Q + 583010427 * this.Q + 2];
         }

         for(var21 = 0; var21 < this.f.length; ++var21) {
            for(var22 = 0; var22 < this.f[0].length; ++var22) {
               this.f[var21][var22] = true;
            }
         }

         this.toString = this.f;
         this.d = this.f;
         this.method4376 = 0;
         this.method5058 = 0;
         this.method5057 = -1126318399 * this.A;
         this.method5060 = this.i * 1467937541;
         this.D.Z = false;
      }

      JSI.I(this, this.Z, -809712178);
      if (!this.N.Z) {
         Iterator var31 = this.N.B.iterator();

         while(var31.hasNext()) {
            KP var32 = (KP)var31.next();
            var31.remove();
            ND.I(var32, (byte)-44);
         }
      }

      if (this.S) {
         for(var21 = 0; var21 < this.method6342 * -2060364501; ++var21) {
            this.b[var21].I(var1, var15, (byte)1);
         }
      }

      if (this.L != null) {
         this.I(true, -740850409);
         this.Z.method5057(-1, new ADI(1583160, 40, 127, 63, 0, 0, 0));
         this.UA(true, var5, var11, var12, var17);
         this.Z.O();
         this.I(false, -740850409);
      }

      this.UA(false, var5, var11, var12, var17);
      if (!this.UA) {
         this.d = var19;
         this.toString = var20;
      }

   }

   void UA(boolean var1, byte[][][] var2, int var3, byte var4, int var5) {
      int var6 = var1 ? 1 : 0;
      this.method4398 = 0;
      this.remove = 0;
      this.W += 888242829;
      IR var7;
      if ((var5 & 2) == 0) {
         for(var7 = this.method4366[var6]; var7 != null; var7 = var7.G) {
            this.append(var7, -51028335);
            if (-1 != -1235150701 * var7.M && !this.method229(var7, var1, var2, var3, var4)) {
               this.append[(this.method4398 += -770473687) * -1367168231 - 1] = var7;
            }
         }
      }

      int var16;
      if ((var5 & 1) == 0) {
         for(var7 = this.method6353[var6]; var7 != null; var7 = var7.G) {
            this.append(var7, 520875779);
            if (-1 != -1235150701 * var7.M && !this.method229(var7, var1, var2, var3, var4)) {
               this.B[(this.remove += -749214421) * 708424067 - 1] = var7;
            }
         }

         for(var7 = this.method4394[var6]; var7 != null; var7 = var7.G) {
            this.append(var7, 1278144320);
            if (var7.M * -1235150701 != -1 && !this.method229(var7, var1, var2, var3, var4)) {
               if (var7.method4376((short)255)) {
                  this.B[(this.remove += -749214421) * 708424067 - 1] = var7;
               } else {
                  this.append[(this.method4398 += -770473687) * -1367168231 - 1] = var7;
               }
            }
         }

         if (!var1) {
            for(var16 = 0; var16 < 1204219039 * this.method5025; ++var16) {
               this.append(this.method5021[var16], -765484247);
               if (-1 != this.method5021[var16].M * -1235150701 && !this.method229(this.method5021[var16], var1, var2, var3, var4)) {
                  if (this.method5021[var16].method4376((short)255)) {
                     this.B[(this.remove += -749214421) * 708424067 - 1] = this.method5021[var16];
                  } else {
                     this.append[(this.method4398 += -770473687) * -1367168231 - 1] = this.method5021[var16];
                  }
               }
            }
         }
      }

      if (-1367168231 * this.method4398 > 0) {
         this.iterator(this.append, 0, -1367168231 * this.method4398 - 1);

         for(var16 = 0; var16 < this.method4398 * -1367168231; ++var16) {
            this.method4354(this.append[var16], this.method4360);
         }
      }

      if (this.S) {
         this.Z.method5021(0, (GE[])null);
      }

      if ((var5 & 2) == 0) {
         for(var16 = 0; var16 < this.Y * 1678382205; ++var16) {
            int var8;
            int var9;
            boolean[][] var10;
            int var11;
            int var12;
            int var13;
            if (var16 >= var3 && var2 != null) {
               var8 = this.d.length;
               if (this.d.length + 1387802915 * this.method4376 > 1988988347 * this.A) {
                  var8 -= this.method4376 * 1387802915 + this.d.length - 1988988347 * this.A;
               }

               var9 = this.d[0].length;
               if (1655515601 * this.method5058 + this.d[0].length > this.i * 1340714547) {
                  var9 -= 1655515601 * this.method5058 + this.d[0].length - 1340714547 * this.i;
               }

               var10 = this.toString;
               if (this.UA) {
                  for(var11 = -1810993483 * this.method5048; var11 < var8; ++var11) {
                     var12 = this.method4376 * 1387802915 + var11 - -1810993483 * this.method5048;

                     for(var13 = this.O * -301075153; var13 < var9; ++var13) {
                        var10[var11][var13] = false;
                        if (this.d[var11][var13]) {
                           int var14 = var13 + 1655515601 * this.method5058 - this.O * -301075153;

                           for(int var15 = var16; var15 >= 0; --var15) {
                              if (this.E[var15][var12][var14] != null && this.E[var15][var12][var14].H == var16) {
                                 if ((var15 < var3 || var2[var15][var12][var14] != var4) && !this.D.I(var16, var12, var14)) {
                                    var10[var11][var13] = true;
                                    break;
                                 }

                                 var10[var11][var13] = false;
                                 break;
                              }
                           }
                        }
                     }
                  }
               }

               this.G[var16].method6338(-804213305 * this.z, this.J * 465603579, this.Q * 583010427, this.toString, false, var5);
            } else {
               var8 = this.d.length;
               if (1387802915 * this.method4376 + this.d.length > this.A * 1988988347) {
                  var8 -= 1387802915 * this.method4376 + this.d.length - 1988988347 * this.A;
               }

               var9 = this.d[0].length;
               if (1655515601 * this.method5058 + this.d[0].length > this.i * 1340714547) {
                  var9 -= this.d[0].length + this.method5058 * 1655515601 - this.i * 1340714547;
               }

               var10 = this.toString;
               if (this.UA) {
                  for(var11 = this.method5048 * -1810993483; var11 < var8; ++var11) {
                     var12 = var11 + this.method4376 * 1387802915 - -1810993483 * this.method5048;

                     for(var13 = this.O * -301075153; var13 < var9; ++var13) {
                        if (this.d[var11][var13] && !this.D.I(var16, var12, var13 + this.method5058 * 1655515601 - this.O * -301075153)) {
                           var10[var11][var13] = true;
                        } else {
                           var10[var11][var13] = false;
                        }
                     }
                  }
               }

               this.G[var16].method6338(this.z * -804213305, this.J * 465603579, 583010427 * this.Q, this.toString, true, var5);
            }
         }
      }

      if (708424067 * this.remove > 0) {
         this.hasNext(this.B, 0, 708424067 * this.remove - 1);

         for(var16 = 0; var16 < this.remove * 708424067; ++var16) {
            this.method4354(this.B[var16], this.method4360);
         }
      }

   }

   void append(IR var1, int var2) {
      try {
         SF var3 = var1.I().I;
         this.Z.method5060((float)((int)var3.I), (float)((int)var3.C + (var1.method4361(1951240662) >> 1)), (float)((int)var3.Z), this.F);
         var1.M = 144688539 * (int)this.F[2];
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "nu.aj(" + ')');
      }
   }

   void hasNext(IR[] var1, int var2, int var3) {
      if (var2 < var3) {
         int var4 = (var3 + var2) / 2;
         int var5 = var2;
         IR var6 = var1[var4];
         var1[var4] = var1[var3];
         var1[var3] = var6;
         int var7 = -1235150701 * var6.M;

         for(int var8 = var2; var8 < var3; ++var8) {
            if (-1235150701 * var1[var8].M > (var8 & 1) + var7) {
               IR var9 = var1[var8];
               var1[var8] = var1[var5];
               var1[var5++] = var9;
            }
         }

         var1[var3] = var1[var5];
         var1[var5] = var6;
         this.hasNext(var1, var2, var5 - 1);
         this.hasNext(var1, 1 + var5, var3);
      }

   }

   void iterator(IR[] var1, int var2, int var3) {
      if (var2 < var3) {
         int var4 = (var3 + var2) / 2;
         int var5 = var2;
         IR var6 = var1[var4];
         var1[var4] = var1[var3];
         var1[var3] = var6;
         int var7 = var6.M * -1235150701;

         for(int var8 = var2; var8 < var3; ++var8) {
            if (-1235150701 * var1[var8].M < (var8 & 1) + var7) {
               IR var9 = var1[var8];
               var1[var8] = var1[var5];
               var1[var5++] = var9;
            }
         }

         var1[var3] = var1[var5];
         var1[var5] = var6;
         this.iterator(var1, var2, var5 - 1);
         this.iterator(var1, var5 + 1, var3);
      }

   }

   boolean method229(IR var1, boolean var2, byte[][][] var3, int var4, byte var5) {
      if (!this.UA) {
         return false;
      } else if (var1 instanceof ZR) {
         short var12 = ((ZR)var1).P;
         short var13 = ((ZR)var1).Q;
         short var14 = ((ZR)var1).R;
         short var9 = ((ZR)var1).O;

         for(int var10 = var14; var10 <= var12; ++var10) {
            for(int var11 = var9; var11 <= var13; ++var11) {
               if (var1.L < 1678382205 * this.Y && var10 >= this.method4376 * 1387802915 && var10 < this.method5057 * 945006459 && var11 >= 1655515601 * this.method5058 && var11 < this.method5060 * 779833815) {
                  if ((var3 == null || var1.K < var4 || var3[var1.K][var10][var11] != var5) && var1.method4360(1467136065) && !var1.method4364(this.Z, (byte)-33)) {
                     return false;
                  }

                  if (!var2 && var10 >= this.z * -804213305 - 16 && var10 <= -804213305 * this.z + 16 && var11 >= this.J * 465603579 - 16 && var11 <= 16 + 465603579 * this.J) {
                     var1.method4357(this.Z, 1659529754);
                  }

                  return true;
               }
            }
         }

         return true;
      } else {
         SF var6 = var1.I().I;
         int var7 = (int)var6.I >> this.I * -1688804109;
         int var8 = (int)var6.Z >> -1688804109 * this.I;
         if (var1.L < this.Y * 1678382205 && var7 >= 1387802915 * this.method4376 && var7 < 945006459 * this.method5057 && var8 >= 1655515601 * this.method5058 && var8 < 779833815 * this.method5060) {
            if ((var3 == null || var1.K < var4 || var3[var1.K][var7][var8] != var5) && var1.method4360(1252283375) && !var1.method4364(this.Z, (byte)91)) {
               return false;
            } else {
               if (!var2 && var7 >= this.z * -804213305 - 16 && var7 <= 16 + -804213305 * this.z && var8 >= 465603579 * this.J - 16 && var8 <= 16 + 465603579 * this.J) {
                  var1.method4357(this.Z, 1423007257);
               }

               return true;
            }
         } else {
            return true;
         }
      }
   }

   void method4354(IR var1, GE[] var2) {
      if (this.S) {
         int var3 = var1.method4354(var2, -331363526);
         this.Z.method5021(var3, var2);
      }

      if (this.G == this.M) {
         boolean var9 = false;
         boolean var4 = false;
         SF var5 = var1.I().I;
         int var6;
         int var7;
         if (var1 instanceof ZR) {
            var6 = ((ZR)var1).R;
            var7 = ((ZR)var1).O;
         } else {
            var6 = (int)var5.I >> this.I * -1688804109;
            var7 = (int)var5.Z >> this.I * -1688804109;
         }

         ADI var8 = new ADI();
         var8.Z = this.Z(var6, var7, (byte)76) * 614121861;
         var8.I = this.I(var6, var7, (byte)-5) * -885436027;
         var8.C = this.C(var6, var7, (byte)11) * 399458545;
         var8.B = this.B(var6, var7, (byte)27) * 1507836083;
         var8.D = this.C(var6, var7, -1020454437) * -1927451111;
         var8.J = this.Z(var6, var7, -1965414520) * -875460563;
         this.Z.method5058(this.K[0].I((int)var5.I, (int)var5.Z, -1986155301), var8);
      }

      KP var10 = var1.method4394(this.Z, -461368503);
      if (var10 != null) {
         if (var10.Z) {
            var10.I = var1;
            this.N.I(var10, 469995096);
         } else {
            ND.I(var10, (byte)-93);
         }
      }

   }

   public void I(GJI var1, int var2, int var3, int var4, boolean[] var5, int var6) {
      try {
         if (this.M != this.G) {
            int var7 = this.K[var2].I(var3, var4, -1918392290);

            for(int var8 = 0; var8 <= var2; ++var8) {
               if (var5 == null || var5[var8]) {
                  YJI var9 = this.K[var8];
                  if (var9 == null) {
                     if (var6 <= 16711935) {
                        break;
                     }
                  } else {
                     var9.NA(var1, var3, var7 - var9.I(var3, var4, -1764966761), var4, 0, false);
                  }
               }
            }
         }

      } catch (RuntimeException var10) {
         throw DQ.I(var10, "nu.ar(" + ')');
      }
   }

   void method4355(int var1, int var2, int var3) {
      try {
         GJI var4 = null;

         for(int var5 = var1; var5 < var2; ++var5) {
            YJI var6 = this.K[var5];
            if (var6 != null) {
               for(int var7 = 0; var7 < 1340714547 * this.i; ++var7) {
                  for(int var8 = 0; var8 < this.A * 1988988347; ++var8) {
                     var4 = var6.w(var8, var7, var4);
                     if (var4 != null) {
                        int var9 = var8 << -1688804109 * this.I;
                        int var10 = var7 << -1688804109 * this.I;

                        for(int var11 = var5 - 1; var11 >= 0; --var11) {
                           YJI var12 = this.K[var11];
                           if (var12 == null) {
                              if (var3 == -787522086) {
                                 return;
                              }
                           } else {
                              int var13 = var6.I(var8, var7, (byte)-85) - var12.I(var8, var7, (byte)-14);
                              int var14 = var6.I(1 + var8, var7, (byte)-116) - var12.I(1 + var8, var7, (byte)-55);
                              int var15 = var6.I(1 + var8, var7 + 1, (byte)-109) - var12.I(1 + var8, var7 + 1, (byte)-78);
                              int var16 = var6.I(var8, 1 + var7, (byte)-117) - var12.I(var8, 1 + var7, (byte)-112);
                              var12.UA(var4, var9, (var16 + var15 + var13 + var14) / 4, var10, 0, false);
                           }
                        }
                     }
                  }
               }
            }
         }

      } catch (RuntimeException var17) {
         throw DQ.I(var17, "nu.ac(" + ')');
      }
   }

   public void Z(byte var1) {
      try {
         for(int var2 = 0; var2 < -2060364501 * this.method6342; ++var2) {
            if (!this.next[var2]) {
               WO var3 = this.b[var2];
               GE var4 = var3.I;
               int var5 = var3.E * -1565952249;
               int var6 = var4.F(-2066581282) - this.X * 394962841;
               int var7 = 1 + (2 * var6 >> -1688804109 * this.I);
               int var8 = 0;
               int[] var9 = new int[var7 * var7];
               int var10 = var4.B(823958259) - var6 >> this.I * -1688804109;
               int var11 = var4.I((byte)84) - var6 >> -1688804109 * this.I;
               int var12 = var4.I((byte)73) + var6 >> this.I * -1688804109;
               if (var11 < 0) {
                  var8 -= var11;
                  var11 = 0;
               }

               if (var12 >= this.i * 1340714547) {
                  var12 = 1340714547 * this.i - 1;
               }

               for(int var13 = var11; var13 <= var12; ++var13) {
                  short var14 = var3.M[var8];
                  int var15 = var14 >>> 8;
                  int var16 = var7 * var8 + var15;
                  int var17 = (var14 >>> 8) + var10;
                  int var18 = var17 + (var14 & 255) - 1;
                  if (var17 < 0) {
                     var16 -= var17;
                     var17 = 0;
                  }

                  if (var18 >= this.A * 1988988347) {
                     var18 = 1988988347 * this.A - 1;
                  }

                  for(int var19 = var17; var19 <= var18; ++var19) {
                     byte var20 = 1;
                     ZR var21 = this.I(var5, var19, var13, (XSI)null, (int)-741941433);
                     if (var21 != null && var21.U != 0) {
                        boolean var22;
                        boolean var23;
                        short var24;
                        int var25;
                        int var26;
                        if (1 == var21.U) {
                           var22 = var19 - 1 >= var17;
                           var23 = var19 + 1 <= var18;
                           if (!var22 && var13 + 1 <= var12) {
                              var24 = var3.M[var8 + 1];
                              var25 = var10 + (var24 >>> 8);
                              var26 = var25 + (var24 & 255);
                              var22 = var19 > var25 && var19 < var26;
                           }

                           if (!var23 && var13 - 1 >= var11) {
                              var24 = var3.M[var8 - 1];
                              var25 = (var24 >>> 8) + var10;
                              var26 = (var24 & 255) + var25;
                              var23 = var19 > var25 && var19 < var26;
                           }

                           if (var22 && !var23) {
                              var20 = 4;
                           } else if (var23 && !var22) {
                              var20 = 2;
                           }
                        } else {
                           var22 = var19 - 1 >= var17;
                           var23 = 1 + var19 <= var18;
                           if (!var22 && var13 - 1 >= var11) {
                              var24 = var3.M[var8 - 1];
                              var25 = var10 + (var24 >>> 8);
                              var26 = (var24 & 255) + var25;
                              var22 = var19 > var25 && var19 < var26;
                           }

                           if (!var23 && var13 + 1 <= var12) {
                              var24 = var3.M[1 + var8];
                              var25 = (var24 >>> 8) + var10;
                              var26 = (var24 & 255) + var25;
                              var23 = var19 > var25 && var19 < var26;
                           }

                           if (var22 && !var23) {
                              var20 = 3;
                           } else if (var23 && !var22) {
                              var20 = 5;
                           }
                        }
                     }

                     var9[var16++] = var20;
                  }

                  ++var8;
               }

               this.next[var2] = true;
               if (R) {
                  this.G[var5].method6342(var4, var9);
               }
            }
         }

      } catch (RuntimeException var27) {
         throw DQ.I(var27, "nu.bf(" + ')');
      }
   }

   public void Z(int var1) {
      try {
         for(int var2 = 0; var2 < this.A * 1988988347; ++var2) {
            for(int var3 = 0; var3 < this.i * 1340714547; ++var3) {
               if (this.E[0][var2][var3] == null) {
                  this.E[0][var2][var3] = new BP(0);
               }
            }
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "nu.p(" + ')');
      }
   }

   public void I(WO var1, int var2) {
      try {
         if (this.method6342 * -2060364501 < 65391) {
            GE var3 = var1.I;
            this.b[-2060364501 * this.method6342] = var1;
            this.next[this.method6342 * -2060364501] = false;
            this.method6342 += -979058301;
            int var4 = -1565952249 * var1.E;
            if (var1.K) {
               var4 = 0;
            }

            int var5 = var1.E * -1565952249;
            if (var1.H) {
               var5 = this.Y * 1678382205 - 1;
            }

            for(int var6 = var4; var6 <= var5; ++var6) {
               int var7 = 0;
               int var8 = var3.I((byte)46) - var3.F(1506691) + 394962841 * this.X >> this.I * -1688804109;
               if (var8 < 0) {
                  var7 -= var8;
                  var8 = 0;
               }

               int var9 = var3.I((byte)8) + var3.F(-884319007) - this.X * 394962841 >> -1688804109 * this.I;
               if (var9 >= 1340714547 * this.i) {
                  var9 = this.i * 1340714547 - 1;
               }

               for(int var10 = var8; var10 <= var9; ++var10) {
                  short var11 = var1.M[var7++];
                  int var12 = (var3.B(823958259) - var3.F(-701525248) + this.X * 394962841 >> this.I * -1688804109) + (var11 >>> 8);
                  int var13 = var12 + (var11 & 255) - 1;
                  if (var12 < 0) {
                     var12 = 0;
                  }

                  if (var13 >= 1988988347 * this.A) {
                     var13 = 1988988347 * this.A - 1;
                  }

                  for(int var14 = var12; var14 <= var13; ++var14) {
                     long var15 = this.c[var6][var14][var10];
                     if ((var15 & 65535L) == 0L) {
                        this.c[var6][var14][var10] = var15 | (long)(this.method6342 * -2060364501);
                     } else if ((var15 & 4294901760L) == 0L) {
                        this.c[var6][var14][var10] = var15 | (long)(this.method6342 * -2060364501) << 16;
                     } else if ((var15 & 281470681743360L) == 0L) {
                        this.c[var6][var14][var10] = var15 | (long)(this.method6342 * -2060364501) << 32;
                     } else if ((var15 & -281474976710656L) == 0L) {
                        this.c[var6][var14][var10] = var15 | (long)(this.method6342 * -2060364501) << 48;
                     }
                  }
               }
            }
         }

      } catch (RuntimeException var17) {
         throw DQ.I(var17, "nu.bd(" + ')');
      }
   }

   public void I(boolean var1, int var2) {
      try {
         if (var1) {
            this.E = this.L;
            this.G = this.M;
         } else {
            this.E = this.H;
            this.G = this.K;
         }

         this.Y = this.E.length * 1634141397;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "nu.b(" + ')');
      }
   }

   public void I(int var1, int var2, int var3, int var4, LR var5, int var6) {
      try {
         BP var7 = this.B(var1, var2, var3, 1185117443);
         if (var7 != null) {
            var5.I(new SF((float)((var2 << this.I * -1688804109) + 394962841 * this.X), (float)var4, (float)((var3 << -1688804109 * this.I) + 394962841 * this.X)));
            var7.S = var5;
            int var8 = this.M == this.G ? 1 : 0;
            if (var5.method4399((byte)13)) {
               if (var5.method4376((short)255)) {
                  var5.G = this.method6353[var8];
                  this.method6353[var8] = var5;
               } else {
                  var5.G = this.method4366[var8];
                  this.method4366[var8] = var5;
               }
            } else {
               var5.G = this.method4394[var8];
               this.method4394[var8] = var5;
            }
         }

      } catch (RuntimeException var9) {
         throw DQ.I(var9, "nu.h(" + ')');
      }
   }

   public GR C(int var1, int var2, int var3, byte var4) {
      try {
         BP var5 = this.E[var1][var2][var3];
         if (var5 != null) {
            this.NA(var5.D, 1998851021);
            if (var5.D != null) {
               GR var6 = var5.D;
               var5.D = null;
               return var6;
            }
         }

         return null;
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "nu.o(" + ')');
      }
   }

   public boolean Z(GJI var1, int var2, int var3, int var4, boolean[] var5, int var6) {
      try {
         boolean var7 = false;
         if (this.M != this.G) {
            int var8 = this.K[var2].I(var3, var4, -1298291430);

            for(int var9 = 0; var9 <= var2; ++var9) {
               YJI var10 = this.K[var9];
               if (var10 == null) {
                  if (var6 == 2008908432) {
                     throw new IllegalStateException();
                  }
               } else {
                  int var11 = var8 - var10.I(var3, var4, -1859389272);
                  if (var5 != null) {
                     var5[var9] = var10.method6353(var1, var3, var11, var4, 0, false);
                     if (!var5[var9]) {
                        if (var6 == 2008908432) {
                           throw new IllegalStateException();
                        }
                        continue;
                     }
                  }

                  var10.UA(var1, var3, var11, var4, 0, false);
                  var7 = true;
               }
            }
         }

         return var7;
      } catch (RuntimeException var12) {
         throw DQ.I(var12, "nu.au(" + ')');
      }
   }

   public void I(int var1, YJI var2, byte var3) {
      try {
         this.G[var1] = var2;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "nu.u(" + ')');
      }
   }

   public void I(int var1, int var2, int var3, SR var4, int var5) {
      try {
         BP var6 = this.B(var1, var2, var3, 996825081);
         if (var6 != null) {
            var6.J = var4;
            int var7 = this.G == this.M ? 1 : 0;
            if (var4.method4399((byte)13)) {
               if (var4.method4376((short)255)) {
                  var4.G = this.method6353[var7];
                  this.method6353[var7] = var4;
               } else {
                  var4.G = this.method4366[var7];
                  this.method4366[var7] = var4;
               }
            } else {
               var4.G = this.method4394[var7];
               this.method4394[var7] = var4;
            }
         }

      } catch (RuntimeException var8) {
         throw DQ.I(var8, "nu.t(" + ')');
      }
   }

   public SR B(int var1, int var2, int var3, byte var4) {
      try {
         BP var5 = this.E[var1][var2][var3];
         return var5 != null && var5.J != null ? var5.J : null;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "nu.az(" + ')');
      }
   }

   public LR D(int var1, int var2, int var3, byte var4) {
      try {
         BP var5 = this.E[var1][var2][var3];
         if (var5 == null) {
            return null;
         } else {
            LR var6 = var5.S;
            var5.S = null;
            this.NA(var6, 113491731);
            return var6;
         }
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "nu.aa(" + ')');
      }
   }

   public int C(int var1, int var2, int var3) {
      try {
         return this.method4355 != null ? this.method4355[var1][var2] & 255 : 0;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "nu.s(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         var0.J -= 1551802473;
         int var2 = var0.H[681479919 * var0.J];
         int var3 = var0.H[var0.J * 681479919 + 1] << 1;
         int var4 = var0.H[2 + var0.J * 681479919];
         int var5 = var0.H[681479919 * var0.J + 3];
         int var6 = var0.H[681479919 * var0.J + 4];
         int var7 = var0.H[var0.J * 681479919 + 5];
         int var8 = var0.H[681479919 * var0.J + 6];
         if (var2 >= 0 && var2 < 2 && XEI.fZ[var2] != null && var3 >= 0 && var3 < XEI.fZ[var2].length) {
            XEI.fZ[var2][var3] = new int[]{(var4 >> 14 & 16383) << 9, var5 << 2, (var4 & 16383) << 9, var8};
            XEI.fZ[var2][1 + var3] = new int[]{(var6 >> 14 & 16383) << 9, var7 << 2, (var6 & 16383) << 9};
         }

      } catch (RuntimeException var9) {
         throw DQ.I(var9, "nu.afm(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         var0.H[(var0.J += -391880689) * 681479919 - 1] = 1045422783 * var3.x;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "nu.pc(" + ')');
      }
   }

   static HSI I(HSI var0, byte var1) {
      try {
         HSI var2 = XEI.C(var0);
         if (var2 == null) {
            var2 = var0.CZ;
         }

         return var2;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "nu.ln(" + ')');
      }
   }
}
