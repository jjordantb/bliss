import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

public class EV {
   static char[] I = new char[]{'€', '\u0000', '‚', 'ƒ', '„', '…', '†', '‡', 'ˆ', '‰', 'Š', '‹', 'Œ', '\u0000', 'Ž', '\u0000', '\u0000', '‘', '’', '“', '”', '•', '–', '—', '˜', '™', 'š', '›', 'œ', '\u0000', 'ž', 'Ÿ'};
   static int Z;
   public static List B = new ArrayList();

   EV() throws Throwable {
      throw new Error();
   }

   public static void I(int[] var0, Object[] var1, int var2, int var3, int var4) {
      try {
         if (var2 < var3) {
            int var5 = (var3 + var2) / 2;
            int var6 = var2;
            int var7 = var0[var5];
            var0[var5] = var0[var3];
            var0[var3] = var7;
            Object var8 = var1[var5];
            var1[var5] = var1[var3];
            var1[var3] = var8;
            int var9 = Integer.MAX_VALUE == var7 ? 0 : 1;

            for(int var10 = var2; var10 < var3; ++var10) {
               if (var0[var10] < (var10 & var9) + var7) {
                  int var11 = var0[var10];
                  var0[var10] = var0[var6];
                  var0[var6] = var11;
                  Object var12 = var1[var10];
                  var1[var10] = var1[var6];
                  var1[var6++] = var12;
               }
            }

            var0[var3] = var0[var6];
            var0[var6] = var7;
            var1[var3] = var1[var6];
            var1[var6] = var8;
            I(var0, var1, var2, var6 - 1, -641027314);
            I(var0, var1, var6 + 1, var3, -641027314);
         }

      } catch (RuntimeException var13) {
         throw DQ.I(var13, "rj.x(" + ')');
      }
   }

   static boolean I(HSI var0, int var1) {
      try {
         OL var2 = XEI.I(var0);
         if (var2.Z((byte)1) > 0) {
            return true;
         } else if (var2.D(-1320707999)) {
            return true;
         } else {
            return var0.CZ != null;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "rj.lo(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = UC.Z.method3878(1767596149) ? 1 : 0;
         var0.H[(var0.J += -391880689) * 681479919 - 1] = UC.Z.method3887(1474356836) ? 1 : 0;
         var0.H[(var0.J += -391880689) * 681479919 - 1] = UC.Z.method3880((byte)-46) ? 1 : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "rj.vg(" + ')');
      }
   }

   public static void I(String var0, boolean var1, boolean var2, int var3) {
      B.add(var0);

      try {
         label289: {
            try {
               if (!var0.equalsIgnoreCase("commands") && !var0.equalsIgnoreCase("help")) {
                  if (var0.equalsIgnoreCase("cls")) {
                     GDI.B = 0;
                     GDI.D = 0;
                  } else if (var0.equalsIgnoreCase("displayfps")) {
                     XEI.x = !XEI.x;
                     if (XEI.x) {
                        CS.I("FPS on", 899052076);
                     } else {
                        CS.I("FPS off", 1184714257);
                     }
                  } else if (var0.equals("renderer")) {
                     SBI var4 = FT.P.method4987();
                     CS.I("Toolkit ID: " + FW.J.d.I(-481266690), 1038434697);
                     CS.I("Vendor: " + var4.I * 267107087, 212944002);
                     CS.I("Name: " + var4.F, 723527437);
                     CS.I("Version: " + var4.D * 1959468245, 1382813939);
                     CS.I("Device: " + var4.Z, 536857078);
                     CS.I("Driver Version: " + var4.J * 703334160035735425L, 1218429557);
                  } else if (var0.equals("heap")) {
                     CS.I("Heap: " + ZE.N * 1126040225 + "MB", 170718628);
                  } else {
                     if (!var0.equalsIgnoreCase("getcamerapos")) {
                        break label289;
                     }

                     XP var12 = XEI.mI.I(681479919);
                     CS.I("Pos: " + UA.F.K + "," + ((-1740717447 * RR.Q >> 9) + var12.I * -1760580017 >> 6) + "," + ((RZ.H * -299812095 >> 9) + 283514611 * var12.Z >> 6) + "," + (-1760580017 * var12.I + (-1740717447 * RR.Q >> 9) & 63) + "," + (var12.Z * 283514611 + (-299812095 * RZ.H >> 9) & 63) + " Height: " + (NQ.I(RR.Q * -1740717447, RZ.H * -299812095, UA.F.K, -1453034846) - L.B * 1449634147), 306448697);
                     CS.I("Look: " + UA.F.K + "," + (-1125224763 * YJI.J + var12.I * -1760580017 >> 6) + "," + (283514611 * var12.Z + KSI.F * -1758389953 >> 6) + "," + (var12.I * -1760580017 + -1125224763 * YJI.J & 63) + "," + (283514611 * var12.Z + -1758389953 * KSI.F & 63) + " Height: " + (NQ.I(YJI.J * -1125224763, -1758389953 * KSI.F, UA.F.K, -860898067) - 771695069 * GB.H), 1171744016);
                  }
               } else {
                  CS.I("commands - This command", 186560885);
                  CS.I("cls - Clear console", 1228482885);
                  CS.I("displayfps - Toggle FPS and other information", 553669962);
                  CS.I("renderer - Print graphics renderer information", 757390347);
                  CS.I("heap - Print java memory information", 1394924823);
                  CS.I("getcamerapos - Print location and direction of camera for use in bug reports", 1131153902);
               }
            } catch (Exception var10) {
               CS.I(VEI.I.I(WO.U, -875414210), 247216384);
            }

            return;
         }

         if (GJ.I != AEI.J || 1806357379 * XEI.QC >= 2) {
            try {
               if (var0.equalsIgnoreCase("wm1")) {
                  OQ.I(1, -1, -1, false, 1791719030);
                  if (VB.I((byte)-15) == 1) {
                     CS.I("Success", 1472876448);
                  } else {
                     CS.I("Failure", 1016209121);
                  }

                  return;
               }

               if (var0.equalsIgnoreCase("wm2")) {
                  OQ.I(2, -1, -1, false, -674111799);
                  if (VB.I((byte)-79) == 2) {
                     CS.I("Success", 1308535348);
                  } else {
                     CS.I("Failure", 863221927);
                  }

                  return;
               }

               if (YX.I && var0.equalsIgnoreCase("wm3")) {
                  OQ.I(3, 1024, 768, false, 1894568246);
                  if (VB.I((byte)-25) == 3) {
                     CS.I("Success", 2072006321);
                  } else {
                     CS.I("Failure", 1988552564);
                  }

                  return;
               }

               if (var0.equalsIgnoreCase("tk0")) {
                  WR.I(0, false, 622850291);
                  if (FW.J.d.I(-1547826526) == 0) {
                     CS.I("Success", 267543271);
                     FW.J.I(FW.J.b, 0, -458723189);
                     JN.I(656179282);
                     XEI.w = false;
                  } else {
                     CS.I("Failure", 268000194);
                  }

                  return;
               }

               if (var0.equalsIgnoreCase("tk1")) {
                  WR.I(1, false, 622850291);
                  if (FW.J.d.I(-957568446) == 1) {
                     CS.I("Success", 1271200712);
                     FW.J.I(FW.J.b, 1, -72348841);
                     JN.I(656179282);
                     XEI.w = false;
                  } else {
                     CS.I("Failure", 1851865795);
                  }

                  return;
               }

               if (var0.equalsIgnoreCase("tk2")) {
                  WR.I(2, false, 622850291);
                  if (FW.J.d.I(-565622932) == 2) {
                     CS.I("Success", 1728166997);
                     FW.J.I(FW.J.b, 2, 345084383);
                     JN.I(656179282);
                     XEI.w = false;
                  } else {
                     CS.I("Failure", 807691994);
                  }

                  return;
               }

               if (var0.equalsIgnoreCase("tk3")) {
                  WR.I(3, false, 622850291);
                  if (FW.J.d.I(-1899485997) == 3) {
                     CS.I("Success", 2073339182);
                     FW.J.I(FW.J.b, 3, 1121469356);
                     JN.I(656179282);
                     XEI.w = false;
                  } else {
                     CS.I("Failure", 1035326643);
                  }

                  return;
               }

               if (var0.equalsIgnoreCase("tk5")) {
                  WR.I(5, false, 622850291);
                  if (FW.J.d.I(-996545824) == 5) {
                     CS.I("Success", 892097548);
                     FW.J.I(FW.J.b, 5, -1087457820);
                     JN.I(656179282);
                     XEI.w = false;
                  } else {
                     CS.I("Failure", 1743942992);
                  }

                  return;
               }

               if (var0.equalsIgnoreCase("clientdrop")) {
                  if (XEI.QZ * -1233866115 == 0) {
                     UEI.C(554378996);
                  } else if (17 == -1233866115 * XEI.QZ) {
                     XEI.eI.M = true;
                  }

                  return;
               }

               int var15;
               if (var0.equalsIgnoreCase("breakcon")) {
                  VJ[] var19 = XEI.AI;

                  for(var15 = 0; var15 < var19.length; ++var15) {
                     VJ var16 = var19[var15];
                     if (var16.C(537308016) != null) {
                        var16.C(537308016).method3867((byte)100);
                     }
                  }

                  TJ.Z.method2353((short)2067);
                  return;
               }

               int var18;
               if (var0.startsWith("getclientvarpbit")) {
                  var18 = Integer.parseInt(var0.substring(17));
                  CS.I("varpbit=" + MI.E.method250(var18, (byte)49), 812809440);
                  return;
               }

               if (var0.startsWith("getclientvarp")) {
                  var18 = Integer.parseInt(var0.substring(14));
                  CS.I("varp=" + MI.E.method252(var18, (byte)25), 1156644577);
                  return;
               }

               String[] var17;
               if (var0.startsWith("directlogin")) {
                  var17 = HR.I(var0.substring(12), ' ', 1545850593);
                  if (2 == var17.length) {
                     LBI.I(var17[0], var17[1], 2101690439);
                  }

                  return;
               }

               if (var0.startsWith("snlogin ")) {
                  var17 = HR.I(var0.substring(8), ' ', 259158417);
                  var15 = Integer.parseInt(var17[0]);
                  JI.I(var15, (byte)-22);
                  return;
               }

               File var13;
               if (var0.startsWith("setoutput ")) {
                  var13 = new File(var0.substring(10));
                  if (var13.exists()) {
                     var13 = new File(var0.substring(10) + "." + CI.I((byte)1) + ".log");
                     if (var13.exists()) {
                        CS.I("file already exists!", 1609687254);
                        return;
                     }
                  }

                  if (ADI.F != null) {
                     ADI.F.close();
                     ADI.F = null;
                  }

                  try {
                     ADI.F = new FileOutputStream(var13);
                  } catch (FileNotFoundException var7) {
                     CS.I("Could not create " + var13.getName(), 2057720306);
                  } catch (SecurityException var8) {
                     CS.I("Cannot write to " + var13.getName(), 651886745);
                  }

                  return;
               }

               if (var0.equals("closeoutput")) {
                  if (ADI.F != null) {
                     ADI.F.close();
                  }

                  ADI.F = null;
                  return;
               }

               if (var0.startsWith("runscript ")) {
                  var13 = new File(var0.substring(10));
                  if (!var13.exists()) {
                     CS.I("No such file", 1833830484);
                     return;
                  }

                  byte[] var5 = VQ.I(var13, -1944658057);
                  if (var5 == null) {
                     CS.I("Failed to read file", 1208919662);
                     return;
                  }

                  String[] var6 = HR.I(BI.I((String)RZ.I(var5, 1704231187), (char)'\r', (String)"", (short)316), '\n', 714918179);
                  YCI.I(var6, 408166320);
               }

               if (XEI.QZ * -1233866115 == 0) {
                  PK var14 = GB.I(MEI.X, XEI.eI.Z, (byte)6);
                  var14.J.F(var0.length() + 3);
                  var14.J.F(var1 ? 1 : 0);
                  var14.J.F(var2 ? 1 : 0);
                  var14.J.I(var0, 2127017558);
                  XEI.eI.I(var14, (byte)-55);
               }
            } catch (Exception var9) {
               CS.I(VEI.I.I(WO.U, -875414210), 417864665);
               return;
            }
         }

         if (XEI.QZ * -1233866115 != 0) {
            CS.I(VEI.Q.I(WO.U, -875414210) + var0, 276776266);
         }

      } catch (RuntimeException var11) {
         throw DQ.I(var11, "rj.t(" + ')');
      }
   }
}
