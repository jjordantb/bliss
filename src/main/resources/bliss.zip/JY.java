public class JY {
   static JY I = new JY(0);
   public static JY Z = new JY(1);
   static JY C = new JY(2);
   public int B;
   static Thread D;

   JY(int var1) {
      this.B = 1407148203 * var1;
   }

   public static WW I(byte var0) {
      try {
         return KT.I == null ? WW.C : KT.I;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "sx.x(" + ')');
      }
   }
}
