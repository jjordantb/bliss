public class LB {
   static JQ I = new JQ(64);
   public static int append = 1;
   public static int toString = 2;
   public boolean Z = false;
   public int C = 0;
   public short B;
   static KJ D;
   public short F;
   public int[] J;
   public int S;
   int A;
   public int E;
   int G;
   public int H = -460402411;
   public int[] K;
   int L = 551876020;
   public int M;
   public int N = -1186467237;
   int O = -82525436;
   int P;
   int Q;
   public boolean R = true;
   public int T;
   int U = -1351633244;
   int V = 59539036;
   public int W = -313955239;
   public int X;
   public int Y;
   public int i;
   public int z;
   public int c;
   public int[] b;
   public int d;
   public int[] f;
   public static int j = -1;
   public int s = 894014710;
   public int a = -1054767914;
   public int e = 0;
   public short g;
   public boolean h = true;
   public int k = -1971154607;
   public int l;
   public int m = 0;
   public int n;
   public int o = -2053470659;
   public boolean p = true;
   static int q = 0;
   public boolean r = false;
   public boolean t = true;
   public boolean u = false;
   public int v;
   int w;
   public int x;
   public int y;
   public int II;
   public int ZI;
   public int CI;
   int BI;
   public int DI = -891363123;
   public boolean FI = true;
   public short JI;
   public int SI;
   public boolean AI = true;
   public int EI;
   public int GI;
   public int HI;
   public int KI;
   public int LI;
   public int MI;
   public int NI;
   public int OI;
   public int PI;

   void I(REI var1, byte var2) {
      try {
         while(true) {
            int var3 = var1.I();
            if (var3 == 0) {
               return;
            }

            this.append(var1, var3, (short)3276);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "hp.b(" + ')');
      }
   }

   void append(REI var1, int var2, short var3) {
      try {
         if (1 == var2) {
            this.B = (short)var1.C();
            this.g = (short)var1.C();
            this.F = (short)var1.C();
            this.JI = (short)var1.C();
            byte var4 = 3;
            this.B = (short)(this.B << var4);
            this.g = (short)(this.g << var4);
            this.F = (short)(this.F << var4);
            this.JI = (short)(this.JI << var4);
         } else if (2 == var2) {
            var1.I();
         } else if (3 == var2) {
            this.S = var1.H((byte)43) * -387057077;
            this.n = var1.H((byte)-103) * -1853520269;
         } else if (var2 == 4) {
            this.C = var1.I() * -687561841;
            this.d = var1.S(-12558881) * -1070610169;
         } else if (5 == var2) {
            this.II = (this.M = (var1.C() << 12 << 2) * -1969619697) * -2077217427;
         } else if (6 == var2) {
            this.P = var1.H((byte)100) * -1365954181;
            this.Q = var1.H((byte)-15) * 902519911;
         } else if (7 == var2) {
            this.X = var1.C() * 704499925;
            this.Y = var1.C() * -1653481859;
         } else if (var2 == 8) {
            this.i = var1.C() * -517504949;
            this.z = var1.C() * -1502909185;
         } else {
            int var5;
            int var7;
            if (9 == var2) {
               var7 = var1.I();
               this.J = new int[var7];

               for(var5 = 0; var5 < var7; ++var5) {
                  this.J[var5] = var1.C();
               }
            } else if (10 == var2) {
               var7 = var1.I();
               this.K = new int[var7];

               for(var5 = 0; var5 < var7; ++var5) {
                  this.K[var5] = var1.C();
               }
            } else if (12 == var2) {
               this.s = var1.S(-12558881) * 1700476293;
            } else if (var2 == 13) {
               this.a = var1.S(-12558881) * -1620099691;
            } else if (14 == var2) {
               this.e = var1.C() * -629947759;
            } else if (15 == var2) {
               this.W = var1.C() * 313955239;
            } else if (var2 == 16) {
               this.R = var1.I() == 1;
               this.k = var1.C() * 1971154607;
               this.o = var1.C() * 2053470659;
               this.h = var1.I() == 1;
            } else if (var2 == 17) {
               this.DI = var1.C() * 891363123;
            } else if (18 == var2) {
               this.T = var1.H((byte)24) * 661695111;
            } else if (var2 == 19) {
               this.m = var1.I() * 709275159;
            } else if (var2 == 20) {
               this.U = var1.I() * 587779089;
            } else if (21 == var2) {
               this.V = var1.I() * 1460884271;
            } else if (var2 == 22) {
               this.H = var1.H((byte)-1) * 460402411;
            } else if (23 == var2) {
               this.L = var1.I() * -853474699;
            } else if (24 == var2) {
               this.p = false;
            } else if (25 == var2) {
               var7 = var1.I();
               this.b = new int[var7];

               for(var5 = 0; var5 < var7; ++var5) {
                  this.b[var5] = var1.C();
               }
            } else if (var2 == 26) {
               this.AI = false;
            } else if (var2 == 27) {
               this.N = (var1.C() << 12 << 2) * 1186467237;
            } else if (var2 == 28) {
               this.O = var1.I() * -1461114135;
            } else if (29 == var2) {
               var1.J(1655872053);
            } else if (30 == var2) {
               this.Z = true;
            } else if (var2 == 31) {
               this.II = (var1.C() << 12 << 2) * 1138516579;
               this.M = (var1.C() << 12 << 2) * -1969619697;
            } else if (32 == var2) {
               this.FI = false;
            } else if (33 == var2) {
               this.r = true;
            } else if (34 == var2) {
               this.t = false;
            }
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "hp.p(" + ')');
      }
   }

   void I(int var1) {
      try {
         if (this.s * -275612851 > -2 || -1831524931 * this.a > -2) {
            this.u = true;
         }

         this.v = 1630521741 * (737478067 * this.P >> 16 & 255);
         this.w = (1522532183 * this.Q >> 16 & 255) * -231735957;
         this.x = this.w * 147388659 - this.v * -902341611;
         this.y = 313528669 * (this.P * 737478067 >> 8 & 255);
         this.A = -339699839 * (this.Q * 1522532183 >> 8 & 255);
         this.ZI = this.A * -1096760557 - 1588068271 * this.y;
         this.CI = (this.P * 737478067 & 255) * -573588505;
         this.G = (1522532183 * this.Q & 255) * -1720855383;
         this.l = -844298861 * this.G - 1351662653 * this.CI;
         this.E = (737478067 * this.P >> 24 & 255) * -1453810947;
         this.BI = 1322388433 * (1522532183 * this.Q >> 24 & 255);
         this.SI = this.BI * 1784226905 - 1139279133 * this.E;
         if (1558182711 * this.T != 0) {
            this.PI = -1525995331 * (1395500273 * this.U * 1940196053 * this.Y / 100);
            this.c = -323160919 * (this.Y * 1940196053 * -1087319089 * this.V / 100);
            if (-1703669099 * this.PI == 0) {
               this.PI = -1525995331;
            }

            this.GI = 220598105 * (((this.T * 1558182711 >> 16 & 255) - (this.x * -447935375 / 2 + this.v * 1443995973) << 8) / (-1703669099 * this.PI));
            this.HI = 1551625825 * (((1558182711 * this.T >> 8 & 255) - (-1237529867 * this.y + -1154628453 * this.ZI / 2) << 8) / (this.PI * -1703669099));
            this.KI = ((1558182711 * this.T & 255) - (this.CI * -1297143849 + this.l * -564637277 / 2) << 8) / (this.PI * -1703669099) * 1145782203;
            if (this.c * -966201447 == 0) {
               this.c = -323160919;
            }

            this.LI = 756703809 * (((1558182711 * this.T >> 24 & 255) - (629527125 * this.E + this.SI * 1235129497 / 2) << 8) / (-966201447 * this.c));
            this.GI += 220598105 * (-1778169623 * this.GI > 0 ? -4 : 4);
            this.HI += (this.HI * 936719777 > 0 ? -4 : 4) * 1551625825;
            this.KI += 1145782203 * (this.KI * 1137945971 > 0 ? -4 : 4);
            this.LI += 756703809 * (this.LI * 825667009 > 0 ? -4 : 4);
         }

         if (this.H * 799607235 != -1) {
            this.MI = -1215468705 * (this.L * 635387357 * this.Y * 1940196053 / 100);
            if (this.MI * -1035489121 == 0) {
               this.MI = -1215468705;
            }

            this.NI = (799607235 * this.H - (this.S * 373784419 + (this.n * -439251269 - 373784419 * this.S) / 2)) / (this.MI * -1035489121) * -1441694519;
         }

         if (-1628433875 * this.N != -1) {
            this.OI = 1204309337 * this.O * 1940196053 * this.Y / 100 * -1190650305;
            if (-1648307777 * this.OI == 0) {
               this.OI = -1190650305;
            }

            this.EI = (-1628433875 * this.N - ((-769306129 * this.M - -992661685 * this.II) / 2 + -992661685 * this.II)) / (-1648307777 * this.OI) * -1770208597;
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "hp.i(" + ')');
      }
   }

   static final void I(int var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      try {
         if (XEI.uI * 1596783995 == 3) {
            int var8 = C.I * 1168366243;
            int[] var9 = C.J;

            int var10;
            for(var10 = 0; var10 < var8; ++var10) {
               PEI var11 = XEI.MC[var9[var10]];
               if (var11 != null) {
                  var11.Z(var0, var1, var2, var3, var4, var5, var6, (byte)12);
               }
            }

            for(var10 = 0; var10 < -1230451913 * XEI.zI; ++var10) {
               int var14 = XEI.WI[var10];
               QG var12 = (QG)XEI.UI.I((long)var14);
               if (var12 != null) {
                  ((SSI)var12.J).Z(var0, var1, var2, var3, var4, var5, var6, (byte)12);
               }
            }
         }

      } catch (RuntimeException var13) {
         throw DQ.I(var13, "hp.js(" + ')');
      }
   }

   static void I(byte var0) {
      try {
         VK.V.I((byte)-40);
         VK.G.B(1028697182);
         VK.l.B(1342386694);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "hp.f(" + ')');
      }
   }
}
