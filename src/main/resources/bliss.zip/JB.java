import java.nio.ByteBuffer;

public class JB {
   OAI IA;
   NN[][] J;
   OAI RA;
   CC Z;
   int b = 64;
   int clear = 768;
   int method113;
   PAI method1450;
   int method1452 = 64;
   int[] method5381;
   int[] method5382;
   int[] method5383;
   int method5384 = PFI.I(1600, 308928473);
   NN[][] method5404;
   int method5455 = 1600;
   static float method63;

   void I(NJI var1) {
      this.RA.method72(786336, 24);
   }

   void I() {
      this.RA.b();
   }

   void I(NJI var1, XBI var2) {
      var1.RA(false);
      method63 = var1.AI;
      float var3 = var1.K.I[2];
      float var4 = var1.K.I[6];
      float var5 = var1.K.I[10];
      float var6 = var1.K.I[14];
      int var7 = 0;
      int var8 = Integer.MAX_VALUE;
      int var9 = 0;
      MN var10 = var2.I.Z;

      for(MN var11 = var10.B; var11 != var10; var11 = var11.B) {
         NN var12 = (NN)var11;
         int var13 = (int)(var3 * (float)(var12.D >> 12) + var4 * (float)(var12.A >> 12) + var5 * (float)(var12.E >> 12) + var6);
         if (var13 > var9) {
            var9 = var13;
         }

         if (var13 < var8) {
            var8 = var13;
         }

         this.method5381[var7++] = var13;
      }

      int var20 = var9 - var8;
      int var21;
      if (var20 + 2 > 1600) {
         var21 = 1 + PFI.I(var20, -1647802809) - this.method5384;
         var20 = (var20 >> var21) + 2;
      } else {
         var21 = 0;
         var20 += 2;
      }

      MN var22 = var10.B;
      var7 = 0;
      var1.method5384(this.method1450);
      UI var14 = var1.i;
      var14.method1452(YF.Z);
      var14.C.J();
      var14.Z = -1;
      int var15 = -2;
      boolean var16 = true;

      for(boolean var17 = true; var22 != var10; this.IA(var1, var20)) {
         this.method113 = 0;

         int var18;
         for(var18 = 0; var18 < var20; ++var18) {
            this.method5382[var18] = 0;
         }

         for(var18 = 0; var18 < 64; ++var18) {
            this.method5383[var18] = 0;
         }

         for(; var22 != var10; var22 = var22.B) {
            NN var23 = (NN)var22;
            if (var17) {
               var15 = var23.L;
               var16 = var23.J;
               var17 = false;
            }

            if (var7 > 0 && (var15 != var23.L || var16 != var23.J)) {
               var17 = true;
               break;
            }

            int var19 = this.method5381[var7++] - var8 >> var21;
            if (var19 < 1600) {
               if (this.method5382[var19] < 64) {
                  this.J[var19][this.method5382[var19]++] = var23;
               } else {
                  if (this.method5382[var19] == 64) {
                     if (this.method113 == 64) {
                        continue;
                     }

                     this.method5382[var19] += 1 + this.method113++;
                  }

                  NN[] var10000 = this.method5404[this.method5382[var19] - 64 - 1];
                  int var10002 = this.method5382[var19] - 64 - 1;
                  int var10004 = this.method5383[this.method5382[var19] - 64 - 1];
                  this.method5383[var10002] = this.method5383[this.method5382[var19] - 64 - 1] + 1;
                  var10000[var10004] = var23;
               }
            }
         }

         var14.I = var1.uI.I(var15 >= 0 ? var15 : -1);
         if (var16 && var1.AI != method63) {
            var1.IA(method63);
         } else if (var1.AI != 1.0F) {
            var1.IA(1.0F);
         }
      }

      if (var1.AI != method63) {
         var1.IA(method63);
      }

      var1.RA(true);
   }

   void IA(NJI var1, int var2) {
      int var3 = 0;
      YF var4 = var1.K;
      float var5 = var4.I[0];
      float var6 = var4.I[4];
      float var7 = var4.I[8];
      float var8 = var4.I[1];
      float var9 = var4.I[5];
      float var10 = var4.I[9];
      float var11 = var5 + var8;
      float var12 = var6 + var9;
      float var13 = var7 + var10;
      float var14 = var5 - var8;
      float var15 = var6 - var9;
      float var16 = var7 - var10;
      float var17 = var8 - var5;
      float var18 = var9 - var6;
      float var19 = var10 - var7;
      ByteBuffer var20 = var1.F;
      var20.clear();

      for(int var21 = var2 - 1; var21 >= 0; --var21) {
         int var22 = this.method5382[var21] > 64 ? 64 : this.method5382[var21];
         if (var22 > 0) {
            int var23;
            byte var27;
            byte var28;
            byte var29;
            float var31;
            float var32;
            for(var23 = var22 - 1; var23 >= 0; --var23) {
               NN var24 = this.J[var21][var23];
               int var25 = var24.H;
               byte var26 = (byte)(var25 >> 16);
               var27 = (byte)(var25 >> 8);
               var28 = (byte)var25;
               var29 = (byte)(var25 >>> 24);
               float var30 = (float)(var24.D >> 12);
               var31 = (float)(var24.A >> 12);
               var32 = (float)(var24.E >> 12);
               int var33 = var24.G >> 12;
               var20.putFloat(var30 + var11 * (float)(-var33));
               var20.putFloat(var31 + var12 * (float)(-var33));
               var20.putFloat(var32 + var13 * (float)(-var33));
               if (var1.oI == 0) {
                  var20.put(var28);
                  var20.put(var27);
                  var20.put(var26);
                  var20.put(var29);
               } else {
                  var20.put(var26);
                  var20.put(var27);
                  var20.put(var28);
                  var20.put(var29);
               }

               var20.putFloat(0.0F);
               var20.putFloat(0.0F);
               var20.putFloat(var30 + var17 * (float)var33);
               var20.putFloat(var31 + var18 * (float)var33);
               var20.putFloat(var32 + var19 * (float)var33);
               if (var1.oI == 0) {
                  var20.put(var28);
                  var20.put(var27);
                  var20.put(var26);
                  var20.put(var29);
               } else {
                  var20.put(var26);
                  var20.put(var27);
                  var20.put(var28);
                  var20.put(var29);
               }

               var20.putFloat(0.0F);
               var20.putFloat(1.0F);
               var20.putFloat(var30 + var11 * (float)var33);
               var20.putFloat(var31 + var12 * (float)var33);
               var20.putFloat(var32 + var13 * (float)var33);
               if (var1.oI == 0) {
                  var20.put(var28);
                  var20.put(var27);
                  var20.put(var26);
                  var20.put(var29);
               } else {
                  var20.put(var26);
                  var20.put(var27);
                  var20.put(var28);
                  var20.put(var29);
               }

               var20.putFloat(1.0F);
               var20.putFloat(1.0F);
               var20.putFloat(var30 + var14 * (float)var33);
               var20.putFloat(var31 + var15 * (float)var33);
               var20.putFloat(var32 + var16 * (float)var33);
               if (var1.oI == 0) {
                  var20.put(var28);
                  var20.put(var27);
                  var20.put(var26);
                  var20.put(var29);
               } else {
                  var20.put(var26);
                  var20.put(var27);
                  var20.put(var28);
                  var20.put(var29);
               }

               var20.putFloat(1.0F);
               var20.putFloat(0.0F);
               ++var3;
            }

            if (this.method5382[var21] > 64) {
               var23 = this.method5382[var21] - 64 - 1;

               for(int var36 = this.method5383[var23] - 1; var36 >= 0; --var36) {
                  NN var37 = this.method5404[var23][var36];
                  int var38 = var37.H;
                  var27 = (byte)(var38 >> 16);
                  var28 = (byte)(var38 >> 8);
                  var29 = (byte)var38;
                  byte var39 = (byte)(var38 >>> 24);
                  var31 = (float)(var37.D >> 12);
                  var32 = (float)(var37.A >> 12);
                  float var40 = (float)(var37.E >> 12);
                  int var34 = var37.G >> 12;
                  var20.putFloat(var31 + var11 * (float)(-var34));
                  var20.putFloat(var32 + var12 * (float)(-var34));
                  var20.putFloat(var40 + var13 * (float)(-var34));
                  if (var1.oI == 0) {
                     var20.put(var29);
                     var20.put(var28);
                     var20.put(var27);
                     var20.put(var39);
                  } else {
                     var20.put(var27);
                     var20.put(var28);
                     var20.put(var29);
                     var20.put(var39);
                  }

                  var20.putFloat(0.0F);
                  var20.putFloat(0.0F);
                  var20.putFloat(var31 + var17 * (float)var34);
                  var20.putFloat(var32 + var18 * (float)var34);
                  var20.putFloat(var40 + var19 * (float)var34);
                  if (var1.oI == 0) {
                     var20.put(var29);
                     var20.put(var28);
                     var20.put(var27);
                     var20.put(var39);
                  } else {
                     var20.put(var27);
                     var20.put(var28);
                     var20.put(var29);
                     var20.put(var39);
                  }

                  var20.putFloat(0.0F);
                  var20.putFloat(1.0F);
                  var20.putFloat(var31 + var11 * (float)var34);
                  var20.putFloat(var32 + var12 * (float)var34);
                  var20.putFloat(var40 + var13 * (float)var34);
                  if (var1.oI == 0) {
                     var20.put(var29);
                     var20.put(var28);
                     var20.put(var27);
                     var20.put(var39);
                  } else {
                     var20.put(var27);
                     var20.put(var28);
                     var20.put(var29);
                     var20.put(var39);
                  }

                  var20.putFloat(1.0F);
                  var20.putFloat(1.0F);
                  var20.putFloat(var31 + var14 * (float)var34);
                  var20.putFloat(var32 + var15 * (float)var34);
                  var20.putFloat(var40 + var16 * (float)var34);
                  if (var1.oI == 0) {
                     var20.put(var29);
                     var20.put(var28);
                     var20.put(var27);
                     var20.put(var39);
                  } else {
                     var20.put(var27);
                     var20.put(var28);
                     var20.put(var29);
                     var20.put(var39);
                  }

                  var20.putFloat(1.0F);
                  var20.putFloat(0.0F);
                  ++var3;
               }
            }
         }
      }

      this.RA.method63(0, var20.position(), var1.J);
      var1.method5383(0, this.RA);
      var1.method5383(1, this.IA);
      var1.method5455(this.Z);
      UI var35 = var1.i;
      var35.method1450(var3);
   }

   JB(NJI var1) {
      this.method1452 = 64;
      this.method5381 = new int[8191];
      this.method5382 = new int[1600];
      this.method5383 = new int[64];
      this.J = new NN[1600][64];
      this.method5404 = new NN[64][768];
      this.method113 = 0;
      this.Z = var1.method5404(new KB[]{new KB(new JC[]{JC.N, JC.C, JC.D}), new KB(JC.Z)});
      this.RA = var1.method5382(true);
      this.IA = var1.method5382(false);
      this.IA.method72(393168, 12);
      this.method1450 = var1.method5381(false);
      this.method1450.I(49146);
      ByteBuffer var2 = var1.F;
      var2.clear();

      int var3;
      for(var3 = 0; var3 < 8191; ++var3) {
         int var4 = var3 * 4;
         var2.putShort((short)var4);
         var2.putShort((short)(var4 + 1));
         var2.putShort((short)(var4 + 2));
         var2.putShort((short)(var4 + 2));
         var2.putShort((short)(var4 + 3));
         var2.putShort((short)var4);
      }

      this.method1450.method63(0, var2.position(), var1.J);
      var2.clear();

      for(var3 = 0; var3 < 8191; ++var3) {
         var2.putFloat(0.0F);
         var2.putFloat(-1.0F);
         var2.putFloat(0.0F);
         var2.putFloat(0.0F);
         var2.putFloat(-1.0F);
         var2.putFloat(0.0F);
         var2.putFloat(0.0F);
         var2.putFloat(-1.0F);
         var2.putFloat(0.0F);
         var2.putFloat(0.0F);
         var2.putFloat(-1.0F);
         var2.putFloat(0.0F);
      }

      this.IA.method63(0, var2.position(), var1.J);
   }
}
