import java.awt.Canvas;

final class FU implements Runnable {
   public void run() {
      try {
         try {
            LSI.I.run();
         } catch (Throwable var2) {
            ;
         }

         LSI.I = null;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "qg.run(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         ZQ var2 = PR.I(-1844616011);
         if (var2 != null) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = var2.J * -15394297;
            var0.H[(var0.J += -391880689) * 681479919 - 1] = -877023375 * var2.C;
            var0.S[(var0.A += 969361751) * -203050393 - 1] = var2.A;
            KQ var3 = var2.D(275518730);
            var0.H[(var0.J += -391880689) * 681479919 - 1] = var3.Z * 1675394033;
            var0.S[(var0.A += 969361751) * -203050393 - 1] = var3.I;
            var0.H[(var0.J += -391880689) * 681479919 - 1] = var2.I * -945794709;
            var0.H[(var0.J += -391880689) * 681479919 - 1] = var2.E * 512449113;
            var0.S[(var0.A += 969361751) * -203050393 - 1] = var2.S;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = -1;
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
            var0.S[(var0.A += 969361751) * -203050393 - 1] = "";
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
            var0.S[(var0.A += 969361751) * -203050393 - 1] = "";
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
            var0.S[(var0.A += 969361751) * -203050393 - 1] = "";
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "qg.alh(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, byte var3) {
      try {
         var0.KI = 1234689410;
         var0.VC = null;
         var0.f = var2.H[(var2.J -= -391880689) * 681479919] * -1825442367;
         if (var0.a * -1309843523 == -1 && !var1.I) {
            LV.Z(var0.V * -440872681, 2026838544);
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "qg.hx(" + ')');
      }
   }

   static synchronized GSI I(int var0, Canvas var1, FEI var2, KJ var3, int var4, int var5, int var6, int var7) {
      try {
         if (var0 == 0) {
            return MZ.I(var1, var2, var5, var6, (byte)88);
         } else if (var0 == 2) {
            return FA.I(var1, var2, var5, var6, (byte)-28);
         } else if (1 == var0) {
            return ABI.I(var1, var2, var4);
         } else if (5 == var0) {
            return JS.I(var1, var2, var3, var4);
         } else if (3 == var0) {
            return MD.I(var1, var2, var3, var4);
         } else {
            throw new IllegalArgumentException("");
         }
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "qg.f(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var3.KC * -407676483;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "qg.pl(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         var0.J -= -783761378;
         int var2 = var0.H[681479919 * var0.J];
         int var3 = var0.H[var0.J * 681479919 + 1];
         if (var2 == 0) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = (int)Math.pow((double)var2, (double)var3);
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "qg.zb(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-21);
         var0.H[(var0.J += -391880689) * 681479919 - 1] = 684246511 * var3.t;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "qg.rn(" + ')');
      }
   }

   public static UC I(REI var0, byte var1) {
      try {
         int var2 = var0.Y(1235052657);
         return new UC(var2);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "qg.a(" + ')');
      }
   }
}
