public class FW extends LV {
   public static int method5611 = 1;
   public static int toString = 0;
   static int F = 2;
   public static MM J;

   public FW(int var1, MM var2) {
      super(var1, var2);
   }

   int method5616(int var1) {
      return 1;
   }

   public void Z(byte var1) {
      try {
         if (this.I.I((byte)-104) == ZV.I) {
            this.C = -522297302;
         }

         if (this.C * -1598873795 < 0 || this.C * -1598873795 > 2) {
            this.C = this.method5611(1503163375) * 1886334997;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ael.s(" + ')');
      }
   }

   int method5611(int var1) {
      return 1;
   }

   int method5612(int var1, int var2) {
      return 1;
   }

   void method5614(int var1, int var2) {
      try {
         this.C = 1886334997 * var1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ael.p(" + ')');
      }
   }

   int method5615() {
      return 1;
   }

   public FW(MM var1) {
      super(var1);
   }

   public int C(byte var1) {
      try {
         return -1598873795 * this.C;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ael.z(" + ')');
      }
   }

   void method5610(int var1) {
      this.C = 1886334997 * var1;
   }
}
