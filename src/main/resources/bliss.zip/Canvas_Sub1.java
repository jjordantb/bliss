import java.awt.Canvas;
import java.awt.Component;
import java.awt.Graphics;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public final class Canvas_Sub1 extends Canvas {
   Component aComponent10;

   public final void update(Graphics var1) {
      try {
         this.aComponent10.update(var1);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ajk.update(" + ')');
      }
   }

   static void method50123(int var0) {
      try {
         Class var1 = ClassLoader.class;
         Field var2 = var1.getDeclaredField("nativeLibraries");
         Class var3 = AccessibleObject.class;
         Method var4 = var3.getDeclaredMethod("setAccessible", Boolean.TYPE);
         var4.invoke(var2, Boolean.TRUE);
      } catch (Throwable var5) {
         ;
      }

   }

   public final void paint(Graphics var1) {
      try {
         this.aComponent10.paint(var1);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ajk.paint(" + ')');
      }
   }

   Canvas_Sub1(Component var1) {
      this.aComponent10 = var1;
   }
}
