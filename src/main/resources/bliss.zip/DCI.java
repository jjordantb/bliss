public class DCI {
   boolean I;
   RZI[] Z;
   public static KJ C;
   static int B;

   DCI(boolean var1, RZI[] var2) {
      this.I = var1;
      this.Z = var2;
   }

   static final void I(OU var0, byte var1) {
      try {
         boolean var2 = var0.H[(var0.J -= -391880689) * 681479919] == 1;
         FW.J.I(FW.J.W, var2 ? 2 : 1, 437258176);
         FW.J.I(FW.J.X, var2 ? 2 : 1, -618485822);
         WY.I((short)-10564);
         JN.I(656179282);
         XEI.w = false;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "vz.ahh(" + ')');
      }
   }

   public static RZ[] I(int var0) {
      try {
         return new RZ[]{RZ.F, RZ.Z, RZ.C, RZ.B, RZ.D, RZ.A, RZ.E, RZ.I, RZ.J, RZ.S};
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "vz.a(" + ')');
      }
   }
}
