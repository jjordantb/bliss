public class BZI {
   RII I;
   public int Z;
   public int C;
   public boolean B = false;

   void I(REI var1, int var2) {
      try {
         while(true) {
            int var3 = var1.I();
            if (var3 == 0) {
               return;
            }

            this.D(var1, var3, 227910133);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ul.a(" + ')');
      }
   }

   public boolean I(byte var1) {
      try {
         return this.I.Z.D(this.C * 1690480405, -457216440);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ul.p(" + ')');
      }
   }

   public IBI I(GSI var1, int var2, boolean var3, byte var4) {
      try {
         long var5 = (long)(this.C * 1690480405 | var2 << 16 | (var3 ? 262144 : 0) | var1.KZ * 580915349 << 19);
         IBI var7 = (IBI)this.I.I.I(var5);
         if (var7 != null) {
            return var7;
         } else if (!this.I.Z.D(this.C * 1690480405, -457216440)) {
            return null;
         } else {
            RFI var8 = RFI.I(this.I.Z, 1690480405 * this.C, 0);
            if (var8 != null) {
               var8.I = 0;
               var8.B = 0;
               var8.D = 0;
               var8.C = 0;
               if (var3) {
                  var8.I();
               }

               for(int var12 = 0; var12 < var2; ++var12) {
                  var8.B();
               }
            }

            var7 = var1.method5125(var8, true);
            if (var7 != null) {
               this.I.I.I(var7, var5);
            }

            return var7;
         }
      } catch (RuntimeException var13) {
         throw DQ.I(var13, "ul.b(" + ')');
      }
   }

   void D(REI var1, int var2, int var3) {
      try {
         if (var2 == 1) {
            this.C = var1.Y(1235052657) * 24979517;
         } else if (2 == var2) {
            this.Z = var1.B((byte)1) * 1870808461;
         } else if (3 == var2) {
            this.B = true;
         } else if (var2 == 4) {
            this.C = -24979517;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ul.f(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         if (GN.o != null) {
            AE var3 = GN.o.I((long)var2);
            var0.H[(var0.J += -391880689) * 681479919 - 1] = var3 != null ? 1 : 0;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ul.aeo(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         if (var2 >= 1 && var2 <= 2) {
            FW.J.I(FW.J.J, var2, 708632362);
            FW.J.I(FW.J.s, var2, 837898760);
            JN.I(656179282);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ul.afu(" + ')');
      }
   }

   static void I(double var0) {
      try {
         if (GL.H != var0) {
            for(int var2 = 0; var2 < 256; ++var2) {
               int var3 = (int)(Math.pow((double)var2 / 255.0D, var0) * 255.0D);
               GL.G[var2] = var3 > 255 ? 255 : var3;
            }

            GL.H = var0;
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ul.i(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-20);
         int var4 = var0.H[(var0.J -= -391880689) * 681479919];
         --var4;
         if (var3.WI != null && var4 < var3.WI.length && var3.WI[var4] != null) {
            var0.S[(var0.A += 969361751) * -203050393 - 1] = var3.WI[var4];
         } else {
            var0.S[(var0.A += 969361751) * -203050393 - 1] = "";
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ul.sg(" + ')');
      }
   }
}
