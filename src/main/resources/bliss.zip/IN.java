public class IN extends AE {
   int J = Integer.MIN_VALUE;
   int S = Integer.MIN_VALUE;
   int A = -447945321;
   XM E;
   int G = 1232771641;
   int H = Integer.MIN_VALUE;
   int K = -1621269427;
   int L = Integer.MIN_VALUE;
   int M = 390993345;

   boolean I(int var1, int var2, byte var3) {
      try {
         if (var1 >= this.K * -321418373 && var1 <= -236078983 * this.S && var2 >= 2086933977 * this.A && var2 <= -1810755143 * this.L) {
            return true;
         } else {
            return var1 >= this.M * 1150354879 && var1 <= 957695249 * this.H && var2 >= this.G * -38089737 && var2 <= this.J * -1024506197;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aaj.a(" + ')');
      }
   }

   IN(XM var1) {
      this.E = var1;
   }

   static final int[] I(String var0, OU var1, int var2) {
      try {
         int[] var3 = null;
         if (var0.length() > 0 && var0.charAt(var0.length() - 1) == 'Y') {
            int var4 = var1.H[(var1.J -= -391880689) * 681479919];
            if (var4 > 0) {
               for(var3 = new int[var4]; var4-- > 0; var3[var4] = var1.H[(var1.J -= -391880689) * 681479919]) {
                  ;
               }
            }
         }

         return var3;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aaj.kl(" + ')');
      }
   }
}
