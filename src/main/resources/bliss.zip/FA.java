import java.awt.Canvas;
import java.awt.Desktop;
import java.awt.Desktop.Action;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URI;

public class FA {
   public static FA I = new FA();
   static FA Z = new FA();
   public static FA C = new FA();
   static FA B = new FA();

   public static void I(String var0, boolean var1, boolean var2, String var3, boolean var4, boolean var5, int var6) {
      try {
         if (var1) {
            if (!var4 && Desktop.getDesktop().isSupported(Action.BROWSE)) {
               try {
                  Desktop.getDesktop().browse(new URI(var0));
                  return;
               } catch (Exception var8) {
                  ;
               }
            }

            if (HFI.B.startsWith("win") && !var4) {
               ZS.I(var0, 0, (byte)23);
            } else if (HFI.B.startsWith("mac")) {
               NBI.I(var0, 1, var3, -1988096952);
            } else {
               ZS.I(var0, 2, (byte)77);
            }
         } else {
            ZS.I(var0, 3, (byte)71);
         }

      } catch (RuntimeException var9) {
         throw DQ.I(var9, "li.f(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.A -= 1938723502;
         var0.H[(var0.J += -391880689) * 681479919 - 1] = SS.I((String)var0.S[var0.A * -203050393], (String)var0.S[-203050393 * var0.A + 1], WO.U, -1813623072);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "li.zz(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         boolean var2 = false;
         if (XEI.R) {
            try {
               Object var3 = VD.F.I(new Object[]{SM.m * 1914527151, 1 == UA.F.AZ, var0.H[(var0.J -= -391880689) * 681479919]}, -1838433046);
               if (var3 != null) {
                  var2 = ((Boolean)var3).booleanValue();
               }
            } catch (Throwable var4) {
               ;
            }
         }

         var0.H[(var0.J += -391880689) * 681479919 - 1] = var2 ? 1 : 0;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "li.ant(" + ')');
      }
   }

   static void I(int var0, int var1, int var2, boolean var3, int var4, boolean var5, byte var6) {
      try {
         if (var0 < var1) {
            int var7 = (var0 + var1) / 2;
            int var8 = var0;
            ZQ var9 = VY.F[var7];
            VY.F[var7] = VY.F[var1];
            VY.F[var1] = var9;

            for(int var10 = var0; var10 < var1; ++var10) {
               if (GO.I(VY.F[var10], var9, var2, var3, var4, var5, -279850410) <= 0) {
                  ZQ var11 = VY.F[var10];
                  VY.F[var10] = VY.F[var8];
                  VY.F[var8++] = var11;
               }
            }

            VY.F[var1] = VY.F[var8];
            VY.F[var8] = var9;
            I(var0, var8 - 1, var2, var3, var4, var5, (byte)-43);
            I(1 + var8, var1, var2, var3, var4, var5, (byte)54);
         }

      } catch (RuntimeException var12) {
         throw DQ.I(var12, "li.x(" + ')');
      }
   }

   public static GSI I(Canvas var0, FEI var1, int var2, int var3, byte var4) {
      try {
         return new ja(var0, var1, var2, var3);
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "li.a(" + ')');
      }
   }

   static final void I(OU var0, short var1) {
      try {
         var0.J -= -1175642067;
         int var2 = var0.H[var0.J * 681479919];
         int var3 = var0.H[var0.J * 681479919 + 1];
         int var4 = var0.H[681479919 * var0.J + 2];
         GN.I(9, var2 << 16 | var3, var4, "", -529750443);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "li.alx(" + ')');
      }
   }

   public static int I(short var0) {
      return 14;
   }

   public static void I(REI var0, int var1, byte var2) {
      try {
         LM var3 = new LM();
         var3.E = var0.I() * -468176359;
         var3.L = var0.H((byte)43) * -530104791;
         var3.A = new int[var3.E * 719522345];
         var3.S = new int[var3.E * 719522345];
         var3.G = new Field[719522345 * var3.E];
         var3.J = new int[var3.E * 719522345];
         var3.K = new Method[719522345 * var3.E];
         var3.H = new byte[var3.E * 719522345][][];

         for(int var4 = 0; var4 < var3.E * 719522345; ++var4) {
            try {
               int var5 = var0.I();
               String var6;
               String var7;
               int var8;
               if (var5 != 0 && var5 != 1 && 2 != var5) {
                  if (var5 == 3 || 4 == var5) {
                     var6 = var0.E(-1377559322);
                     var7 = var0.E(1945683710);
                     var8 = var0.I();
                     String[] var9 = new String[var8];

                     for(int var10 = 0; var10 < var8; ++var10) {
                        var9[var10] = var0.E(-1854507369);
                     }

                     String var27 = var0.E(-1619475079);
                     byte[][] var11 = new byte[var8][];
                     int var13;
                     if (var5 == 3) {
                        for(int var12 = 0; var12 < var8; ++var12) {
                           var13 = var0.H((byte)-44);
                           var11[var12] = new byte[var13];
                           var0.I((byte[])var11[var12], 0, var13, (int)-953523806);
                        }
                     }

                     var3.A[var4] = var5;
                     Class[] var28 = new Class[var8];

                     for(var13 = 0; var13 < var8; ++var13) {
                        var28[var13] = BZ.I((String)var9[var13], (byte)64);
                     }

                     Class var29 = BZ.I((String)var27, (byte)5);
                     if (BZ.I((String)var6, (byte)23).getClassLoader() == null) {
                        throw new SecurityException();
                     }

                     Method[] var14 = BZ.I((String)var6, (byte)42).getDeclaredMethods();
                     Method[] var15 = var14;

                     for(int var16 = 0; var16 < var15.length; ++var16) {
                        Method var17 = var15[var16];
                        if (var17.getName().equals(var7)) {
                           Class[] var18 = var17.getParameterTypes();
                           if (var28.length == var18.length) {
                              boolean var19 = true;

                              for(int var20 = 0; var20 < var28.length; ++var20) {
                                 if (var28[var20] != var18[var20]) {
                                    var19 = false;
                                    break;
                                 }
                              }

                              if (var19 && var29 == var17.getReturnType()) {
                                 var3.K[var4] = var17;
                              }
                           }
                        }
                     }

                     var3.H[var4] = var11;
                  }
               } else {
                  var6 = var0.E(-1707497835);
                  var7 = var0.E(-976277803);
                  var8 = 0;
                  if (1 == var5) {
                     var8 = var0.H((byte)-46);
                  }

                  var3.A[var4] = var5;
                  var3.J[var4] = var8;
                  if (BZ.I((String)var6, (byte)67).getClassLoader() == null) {
                     throw new SecurityException();
                  }

                  var3.G[var4] = BZ.I((String)var6, (byte)81).getDeclaredField(var7);
               }
            } catch (ClassNotFoundException var21) {
               var3.S[var4] = -1;
            } catch (SecurityException var22) {
               var3.S[var4] = -2;
            } catch (NullPointerException var23) {
               var3.S[var4] = -3;
            } catch (Exception var24) {
               var3.S[var4] = -4;
            } catch (Throwable var25) {
               var3.S[var4] = -5;
            }
         }

         III.I.I((AE)var3, (int)512081003);
      } catch (RuntimeException var26) {
         throw DQ.I(var26, "li.p(" + ')');
      }
   }
}
