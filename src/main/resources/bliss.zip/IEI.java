public interface IEI {
   void b();

   void method122(EB var1);

   void method123();

   void d();

   void method124(EB var1);

   void x();

   void method125();

   void method126();

   void u();

   void method127(EB var1);

   void method128();

   void method129(EB var1);
}
