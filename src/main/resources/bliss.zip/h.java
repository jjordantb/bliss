public class h extends UT implements SAI {
   long nativeid;
   ja aJa6674;
   ba aBa6675;
   WBI[] aClass68Array6676;
   NFI[] aClass85Array6677;

   public native int dp();

   h(ja var1) {
      this.aJa6674 = var1;
      this.aBa6675 = null;
      this.ba(var1);
   }

   void method4757() {
      if (this.aJa6674.anInt6692 > 1) {
         synchronized(this) {
            while(this.I) {
               try {
                  this.wait();
               } catch (InterruptedException var3) {
                  ;
               }
            }

            this.I = true;
         }
      }

   }

   native void ba(ja var1);

   public native void ma(boolean var1);

   public void method4786(LF var1) {
      this.method4852(ja.anIntArray6681, var1);
      int var2 = 0;
      int var3;
      if (this.aClass85Array6677 != null) {
         for(var3 = 0; var3 < this.aClass85Array6677.length; ++var3) {
            NFI var4 = this.aClass85Array6677[var3];
            var4.J = ja.anIntArray6681[var2++] * -1879868075;
            var4.H = ja.anIntArray6681[var2++] * -2041556771;
            var4.S = ja.anIntArray6681[var2++] * -1434499227;
            var4.Z = ja.anIntArray6681[var2++] * 1070341177;
            var4.E = ja.anIntArray6681[var2++] * 1802851857;
            var4.G = ja.anIntArray6681[var2++] * 103846281;
            var4.I = ja.anIntArray6681[var2++] * -2103324039;
            var4.K = ja.anIntArray6681[var2++] * -526039059;
            var4.L = ja.anIntArray6681[var2++] * 491030489;
         }
      }

      if (this.aClass68Array6676 != null) {
         for(var3 = 0; var3 < this.aClass68Array6676.length; ++var3) {
            WBI var6 = this.aClass68Array6676[var3];
            WBI var5 = var6;
            if (var6.Z != null) {
               var5 = var6.Z;
            }

            if (var6.J == null) {
               var6.J = new YF();
            }

            var6.J.I(var1);
            var5.I = ja.anIntArray6681[var2++] * -1436341053;
            var5.D = ja.anIntArray6681[var2++] * 449866009;
            var5.F = ja.anIntArray6681[var2++] * 1336328763;
         }
      }

   }

   void method4852(int[] var1, LF var2) {
      this.aJa6674.method5571().method280(this, var1, var2);
   }

   public UT method4755(byte var1, int var2, boolean var3) {
      return this.aJa6674.method5571().method276(this, var1, var2, var3);
   }

   native void BA(h var1, h var2, int var3, boolean var4, boolean var5);

   public void method4784() {
   }

   public native int m();

   public void method4745(UT var1, int var2, int var3, int var4, boolean var5) {
      this.aJa6674.method5571().method285(this, var1, var2, var3, var4, var5);
   }

   public native void f(int var1);

   public native void S(int var1);

   public native void t(int var1);

   public native void EA(int var1);

   public native void ia(int var1, int var2, int var3);

   public native void wa();

   public native void by(int var1);

   public native void pa(int var1, int var2, YJI var3, YJI var4, int var5, int var6, int var7);

   public native int ya();

   public native int o();

   native boolean ea();

   final void method4738(int var1, int[] var2, int var3, int var4, int var5, int var6, boolean var7) {
      this.J(this.nativeid, var1, var2, var3, var4, var5, var6, var7);
   }

   public native void bc(int var1);

   native void e(int var1, int[] var2, int var3, int var4, int var5, boolean var6, int var7, int[] var8);

   public native void bs(int var1, int var2, YJI var3, YJI var4, int var5, int var6, int var7);

   public native void bl(int var1, int var2, int var3);

   public void method4741(LF var1, int var2, boolean var3) {
      YF var4 = this.aJa6674.method5571().aClass233_6673;
      var4.I(var1);
      this.aa(var4.I, var2, var3);
   }

   native void aa(float[] var1, int var2, boolean var3);

   native void fq(long var1, int var3, int[] var4, int var5, int var6, int var7, int var8, boolean var9);

   public boolean method4787(int var1, int var2, LF var3, boolean var4, int var5) {
      return this.aJa6674.method5571().method284(this, var1, var2, var3, var4);
   }

   public void method4779(UT var1, int var2, int var3, int var4, boolean var5) {
      this.aJa6674.method5571().method285(this, var1, var2, var3, var4, var5);
   }

   public native int N();

   public native int n();

   public native void dc(int var1);

   public native int cu();

   public native int YA();

   public native GJI ct(GJI var1);

   native void cw(int var1, int var2, int var3, int var4);

   public native int ha();

   public native void p(int var1);

   public native void Q(int var1);

   public native int c();

   native void ka();

   public native byte[] ah();

   public native void X(short var1, short var2);

   native void fp(h var1, h var2, int var3, boolean var4, boolean var5);

   native void IA(byte var1, byte[] var2);

   public WBI[] method4774() {
      return this.aClass68Array6676;
   }

   public native void PA(int var1, int var2, int var3, int var4);

   public boolean method4743() {
      return true;
   }

   public native void dz(short var1, short var2);

   void method4734() {
      if (this.aJa6674.anInt6692 > 1) {
         synchronized(this) {
            this.I = false;
            this.notifyAll();
         }
      }

   }

   public NFI[] method4781() {
      return this.aClass85Array6677;
   }

   public WBI[] method4728() {
      return this.aClass68Array6676;
   }

   public native void ey(short var1, short var2);

   public NFI[] method4772() {
      return this.aClass85Array6677;
   }

   native void U(ja var1, ba var2, int var3, int var4, int[] var5, int[] var6, int[] var7, int[] var8, short[] var9, int var10, short[] var11, short[] var12, short[] var13, byte[] var14, byte[] var15, byte[] var16, byte[] var17, short[] var18, short[] var19, int[] var20, byte var21, short[] var22, int var23, byte[] var24, short[] var25, short[] var26, short[] var27, int[] var28, int[] var29, int[] var30, byte[] var31, byte[] var32, int[] var33, int[] var34, int[] var35, int[] var36, int var37, int var38, int var39, int var40, int var41, int var42, int[] var43);

   public UT method4748(byte var1, int var2, boolean var3) {
      return this.aJa6674.method5571().method276(this, var1, var2, var3);
   }

   public UT method4770(byte var1, int var2, boolean var3) {
      return this.aJa6674.method5571().method276(this, var1, var2, var3);
   }

   public UT method4749(byte var1, int var2, boolean var3) {
      return this.aJa6674.method5571().method276(this, var1, var2, var3);
   }

   public native boolean i();

   public native int an();

   public native void au(int var1);

   public native void ar(int var1);

   public native void ac(int var1);

   public void method4752() {
   }

   public void method4764() {
   }

   public native void bf(int var1);

   public native void be(int var1);

   native void cl(int var1, int[] var2, int var3, int var4, int var5, boolean var6, int var7, int[] var8);

   public native void bm(int var1);

   public native void W(short var1, short var2);

   public native void bx(int var1);

   public native void bo(int var1);

   public native void df(short var1, short var2);

   public void method4740(LF var1, KN var2, int var3) {
      if (var2 == null) {
         this.aJa6674.method5571().method279(this, var1, (int[])null, var3);
      } else {
         ja.anIntArray6704[5] = 0;
         this.aJa6674.method5571().method279(this, var1, ja.anIntArray6704, var3);
         var2.B = ja.anIntArray6704[0];
         var2.D = ja.anIntArray6704[1];
         var2.F = ja.anIntArray6704[2];
         var2.C = ja.anIntArray6704[3];
         var2.S = ja.anIntArray6704[4];
         var2.J = ja.anIntArray6704[5] != 0;
      }

   }

   public native void bw(int var1, int var2, int var3);

   public native void bk(int var1, int var2, int var3);

   public native void bq(int var1, int var2, int var3);

   public native void bg(int var1, int var2, YJI var3, YJI var4, int var5, int var6, int var7);

   public native int RA();

   public native void bp(int var1, int var2, YJI var3, YJI var4, int var5, int var6, int var7);

   void method4754() {
      if (this.aJa6674.anInt6692 > 1) {
         synchronized(this) {
            while(this.I) {
               try {
                  this.wait();
               } catch (InterruptedException var3) {
                  ;
               }
            }

            this.I = true;
         }
      }

   }

   public void method4747(UT var1, int var2, int var3, int var4, boolean var5) {
      this.aJa6674.method5571().method285(this, var1, var2, var3, var4, var5);
   }

   public void method4739(LF var1, KN var2, int var3) {
      if (var2 == null) {
         this.aJa6674.method5571().method279(this, var1, (int[])null, var3);
      } else {
         ja.anIntArray6704[5] = 0;
         this.aJa6674.method5571().method279(this, var1, ja.anIntArray6704, var3);
         var2.B = ja.anIntArray6704[0];
         var2.D = ja.anIntArray6704[1];
         var2.F = ja.anIntArray6704[2];
         var2.C = ja.anIntArray6704[3];
         var2.S = ja.anIntArray6704[4];
         var2.J = ja.anIntArray6704[5] != 0;
      }

   }

   void method4758() {
      if (this.aJa6674.anInt6692 > 1) {
         synchronized(this) {
            this.I = false;
            this.notifyAll();
         }
      }

   }

   native boolean bt();

   native boolean bj();

   native void br();

   native void bz();

   native void cm();

   native void cd();

   final void method4760(int var1, int[] var2, int var3, int var4, int var5, int var6, boolean var7) {
      this.J(this.nativeid, var1, var2, var3, var4, var5, var6, var7);
   }

   native void fe(ja var1);

   void method4756() {
      if (this.aJa6674.anInt6692 > 1) {
         synchronized(this) {
            while(this.I) {
               try {
                  this.wait();
               } catch (InterruptedException var3) {
                  ;
               }
            }

            this.I = true;
         }
      }

   }

   native void gc(float[] var1, int var2, boolean var3);

   native void co(int var1, int[] var2, int var3, int var4, int var5, boolean var6, int var7, int[] var8);

   native void J(long var1, int var3, int[] var4, int var5, int var6, int var7, int var8, boolean var9);

   native void cv(int var1, int var2, int var3, int var4);

   public void method4776(LF var1, int var2, boolean var3) {
      YF var4 = this.aJa6674.method5571().aClass233_6673;
      var4.I(var1);
      this.aa(var4.I, var2, var3);
   }

   public void method4762(LF var1, int var2, boolean var3) {
      YF var4 = this.aJa6674.method5571().aClass233_6673;
      var4.I(var1);
      this.aa(var4.I, var2, var3);
   }

   public void method4759(LF var1, KN var2, int var3) {
      if (var2 == null) {
         this.aJa6674.method5571().method279(this, var1, (int[])null, var3);
      } else {
         ja.anIntArray6704[5] = 0;
         this.aJa6674.method5571().method279(this, var1, ja.anIntArray6704, var3);
         var2.B = ja.anIntArray6704[0];
         var2.D = ja.anIntArray6704[1];
         var2.F = ja.anIntArray6704[2];
         var2.C = ja.anIntArray6704[3];
         var2.S = ja.anIntArray6704[4];
         var2.J = ja.anIntArray6704[5] != 0;
      }

   }

   native void gn(byte var1, byte[] var2);

   h(ja var1, ba var2, MBI var3, int var4, int var5, int var6, int var7) {
      this.aJa6674 = var1;
      this.aBa6675 = var2;
      this.aClass85Array6677 = var3.a;
      this.aClass68Array6676 = var3.I;
      int var8 = var3.a == null ? 0 : var3.a.length;
      int var9 = var3.I == null ? 0 : var3.I.length;
      int var10 = 0;
      int[] var11 = new int[var8 * 3 + var9];

      int var12;
      for(var12 = 0; var12 < var8; ++var12) {
         var11[var10++] = this.aClass85Array6677[var12].C * -710317103;
         var11[var10++] = this.aClass85Array6677[var12].B * 1705862021;
         var11[var10++] = this.aClass85Array6677[var12].D * 1636170731;
      }

      for(var12 = 0; var12 < var9; ++var12) {
         var11[var10++] = this.aClass68Array6676[var12].B * -180596249;
      }

      var12 = var3.g == null ? 0 : var3.g.length;
      int[] var13 = new int[var12 * 8];
      int var14 = 0;

      int var15;
      MFI var16;
      for(var15 = 0; var15 < var12; ++var15) {
         var16 = var3.g[var15];
         BB var17 = AE.I(var16.C * 1834782277, -67897652);
         var13[var14++] = var16.Z * 1512514121;
         var13[var14++] = var17.S * 1951943953;
         var13[var14++] = var17.D * 893949695;
         var13[var14++] = var17.C * 39181267;
         var13[var14++] = var17.B * -310074719;
         var13[var14++] = var17.F * 1092922159;
         var13[var14++] = var17.E ? -1 : 0;
      }

      for(var15 = 0; var15 < var12; ++var15) {
         var16 = var3.g[var15];
         var13[var14++] = var16.I * -1606786303;
      }

      this.U(this.aJa6674, this.aBa6675, var3.Z, var3.L, var3.B, var3.b, var3.F, var3.J, var3.S, var3.A, var3.f, var3.s, var3.H, var3.K, var3.T, var3.M, var3.V, var3.O, var3.D, var3.Q, var3.R, var3.C, var3.U, var3.E, var3.G, var3.W, var3.Y, var3.i, var3.z, var3.c, var3.j, var3.N, var3.X, var3.d, var3.e, var11, var8, var9, var4, var5, var6, var7, var13);
   }

   public boolean method4746(int var1, int var2, LF var3, boolean var4, int var5) {
      return this.aJa6674.method5571().method284(this, var1, var2, var3, var4);
   }

   public boolean method4778() {
      return true;
   }

   public native void KA(int var1);

   public native int ca();

   public native int ci();

   public native int ce();

   public native int cq();

   public native int cr();

   native void w(int var1, int var2, int var3, int var4);

   public native int cp();

   public native void bb(int var1);

   public native int cf();

   public native int dh();

   final void method4761(int var1, int[] var2, int var3, int var4, int var5, int var6, boolean var7) {
      this.J(this.nativeid, var1, var2, var3, var4, var5, var6, var7);
   }

   native void fk(ja var1);

   public NFI[] method4771() {
      return this.aClass85Array6677;
   }

   public native int ds();

   public native GJI cc(GJI var1);

   public native void dd(int var1);

   public native void dx(int var1);

   native void fx(long var1, int var3, int[] var4, int var5, int var6, int var7, int var8, boolean var9);

   public native int dk();

   public native int db();

   public native int dn();

   public native void oa(int var1, int var2, int var3);

   public void method4768(byte var1, byte[] var2) {
      this.IA(var1, var2);
   }

   public void method4769(byte var1, byte[] var2) {
      this.IA(var1, var2);
   }

   public native void du(short var1, short var2);

   public boolean method4788() {
      return true;
   }

   public native void di(short var1, short var2);

   public void method4742(byte var1, byte[] var2) {
      this.IA(var1, var2);
   }

   public WBI[] method4753() {
      return this.aClass68Array6676;
   }

   public native void dt(int var1, int var2, int var3, int var4);

   public native GJI ga(GJI var1);

   void method4733() {
      if (this.aJa6674.anInt6692 > 1) {
         synchronized(this) {
            while(this.I) {
               try {
                  this.wait();
               } catch (InterruptedException var3) {
                  ;
               }
            }

            this.I = true;
         }
      }

   }

   public native void dv(short var1, short var2);

   public native int AA();

   public WBI[] method4773() {
      return this.aClass68Array6676;
   }

   public native byte[] method_do();

   public native void dj(int var1, int var2, int var3, int var4);

   public native int dl();

   public native void bu(int var1, int var2, int var3);

   public boolean method4777() {
      return true;
   }

   public WBI[] method4775() {
      return this.aClass68Array6676;
   }

   public native boolean ev();

   public native boolean eg();

   public native boolean ex();

   public native boolean ek();

   public native int cb();

   public native void em();

   public native int ec();

   public native void eb(short var1, short var2);

   public native int dq();

   public void method4751(LF var1) {
      this.method4852(ja.anIntArray6681, var1);
      int var2 = 0;
      int var3;
      if (this.aClass85Array6677 != null) {
         for(var3 = 0; var3 < this.aClass85Array6677.length; ++var3) {
            NFI var4 = this.aClass85Array6677[var3];
            var4.J = ja.anIntArray6681[var2++] * -1879868075;
            var4.H = ja.anIntArray6681[var2++] * -2041556771;
            var4.S = ja.anIntArray6681[var2++] * -1434499227;
            var4.Z = ja.anIntArray6681[var2++] * 1070341177;
            var4.E = ja.anIntArray6681[var2++] * 1802851857;
            var4.G = ja.anIntArray6681[var2++] * 103846281;
            var4.I = ja.anIntArray6681[var2++] * -2103324039;
            var4.K = ja.anIntArray6681[var2++] * -526039059;
            var4.L = ja.anIntArray6681[var2++] * 491030489;
         }
      }

      if (this.aClass68Array6676 != null) {
         for(var3 = 0; var3 < this.aClass68Array6676.length; ++var3) {
            WBI var6 = this.aClass68Array6676[var3];
            WBI var5 = var6;
            if (var6.Z != null) {
               var5 = var6.Z;
            }

            if (var6.J == null) {
               var6.J = new YF();
            }

            var6.J.I(var1);
            var5.I = ja.anIntArray6681[var2++] * -1436341053;
            var5.D = ja.anIntArray6681[var2++] * 449866009;
            var5.F = ja.anIntArray6681[var2++] * 1336328763;
         }
      }

   }

   public void method4782(LF var1) {
      this.method4852(ja.anIntArray6681, var1);
      int var2 = 0;
      int var3;
      if (this.aClass85Array6677 != null) {
         for(var3 = 0; var3 < this.aClass85Array6677.length; ++var3) {
            NFI var4 = this.aClass85Array6677[var3];
            var4.J = ja.anIntArray6681[var2++] * -1879868075;
            var4.H = ja.anIntArray6681[var2++] * -2041556771;
            var4.S = ja.anIntArray6681[var2++] * -1434499227;
            var4.Z = ja.anIntArray6681[var2++] * 1070341177;
            var4.E = ja.anIntArray6681[var2++] * 1802851857;
            var4.G = ja.anIntArray6681[var2++] * 103846281;
            var4.I = ja.anIntArray6681[var2++] * -2103324039;
            var4.K = ja.anIntArray6681[var2++] * -526039059;
            var4.L = ja.anIntArray6681[var2++] * 491030489;
         }
      }

      if (this.aClass68Array6676 != null) {
         for(var3 = 0; var3 < this.aClass68Array6676.length; ++var3) {
            WBI var6 = this.aClass68Array6676[var3];
            WBI var5 = var6;
            if (var6.Z != null) {
               var5 = var6.Z;
            }

            if (var6.J == null) {
               var6.J = new YF();
            }

            var6.J.I(var1);
            var5.I = ja.anIntArray6681[var2++] * -1436341053;
            var5.D = ja.anIntArray6681[var2++] * 449866009;
            var5.F = ja.anIntArray6681[var2++] * 1336328763;
         }
      }

   }

   public void method4783(LF var1) {
      this.method4852(ja.anIntArray6681, var1);
      int var2 = 0;
      int var3;
      if (this.aClass85Array6677 != null) {
         for(var3 = 0; var3 < this.aClass85Array6677.length; ++var3) {
            NFI var4 = this.aClass85Array6677[var3];
            var4.J = ja.anIntArray6681[var2++] * -1879868075;
            var4.H = ja.anIntArray6681[var2++] * -2041556771;
            var4.S = ja.anIntArray6681[var2++] * -1434499227;
            var4.Z = ja.anIntArray6681[var2++] * 1070341177;
            var4.E = ja.anIntArray6681[var2++] * 1802851857;
            var4.G = ja.anIntArray6681[var2++] * 103846281;
            var4.I = ja.anIntArray6681[var2++] * -2103324039;
            var4.K = ja.anIntArray6681[var2++] * -526039059;
            var4.L = ja.anIntArray6681[var2++] * 491030489;
         }
      }

      if (this.aClass68Array6676 != null) {
         for(var3 = 0; var3 < this.aClass68Array6676.length; ++var3) {
            WBI var6 = this.aClass68Array6676[var3];
            WBI var5 = var6;
            if (var6.Z != null) {
               var5 = var6.Z;
            }

            if (var6.J == null) {
               var6.J = new YF();
            }

            var6.J.I(var1);
            var5.I = ja.anIntArray6681[var2++] * -1436341053;
            var5.D = ja.anIntArray6681[var2++] * 449866009;
            var5.F = ja.anIntArray6681[var2++] * 1336328763;
         }
      }

   }

   native void cj(int var1, int[] var2, int var3, int var4, int var5, boolean var6, int var7, int[] var8);

   native void fc(ja var1, ba var2, int var3, int var4, int[] var5, int[] var6, int[] var7, int[] var8, short[] var9, int var10, short[] var11, short[] var12, short[] var13, byte[] var14, byte[] var15, byte[] var16, byte[] var17, short[] var18, short[] var19, int[] var20, byte var21, short[] var22, int var23, byte[] var24, short[] var25, short[] var26, short[] var27, int[] var28, int[] var29, int[] var30, byte[] var31, byte[] var32, int[] var33, int[] var34, int[] var35, int[] var36, int var37, int var38, int var39, int var40, int var41, int var42, int[] var43);

   native void fw(ja var1);

   public native void z(boolean var1);

   public native boolean u();

   public native void dr(int var1, int var2, int var3, int var4);

   public native int Z();

   public boolean method4763(int var1, int var2, LF var3, boolean var4, int var5) {
      return this.aJa6674.method5571().method284(this, var1, var2, var3, var4);
   }

   native void gt(float[] var1, int var2, boolean var3);

   public native int dg();

   native void gl(float[] var1, int var2, boolean var3);

   native void gq(float[] var1, int var2, boolean var3);

   native void gp(byte var1, byte[] var2);

   public UT method4750(byte var1, int var2, boolean var3) {
      return this.aJa6674.method5571().method276(this, var1, var2, var3);
   }

   native void ge(byte var1, byte[] var2);
}
