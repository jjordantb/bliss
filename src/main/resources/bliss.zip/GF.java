import java.io.File;

public class GF {
   public static short[][][] I;

   GF() throws Throwable {
      throw new Error();
   }

   static T[] I(int var0) {
      try {
         return new T[]{T.B, T.D, T.J, T.C, T.Z};
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "aw.a(" + ')');
      }
   }

   public static File Z(int var0) {
      try {
         return ZE.Q;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "aw.d(" + ')');
      }
   }

   static void I(REI var0, int var1) {
      try {
         int var2 = var0.B(1723054621);
         QCI.E = new KQ[var2];

         int var3;
         for(var3 = 0; var3 < var2; ++var3) {
            QCI.E[var3] = new KQ();
            QCI.E[var3].Z = var0.B(1723054621) * -801041135;
            QCI.E[var3].I = var0.T(681479919);
         }

         SU.I = var0.B(1723054621) * 457295123;
         TP.I = var0.B(1723054621) * -924756647;
         JJ.B = var0.B(1723054621) * 412440447;
         XI.Z = new ZQ[TP.I * -499146007 - -1648308965 * SU.I + 1];

         for(var3 = 0; var3 < 1017276543 * JJ.B; ++var3) {
            int var4 = var0.B(1723054621);
            ZQ var5 = XI.Z[var4] = new ZQ();
            var5.B = var0.I() * 672848077;
            var5.C = var0.H((byte)66) * -743493231;
            var5.J = -72535113 * (SU.I * -1648308965 + var4);
            var5.A = var0.T(681479919);
            var5.S = var0.T(681479919);
         }

         V.J = var0.H((byte)56) * -1232164675;
         TP.Z = true;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "aw.b(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, int var3) {
      try {
         var0.WI = null;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aw.jx(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.O.I(-863865720) == 1 ? 1 : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aw.ajp(" + ')');
      }
   }
}
