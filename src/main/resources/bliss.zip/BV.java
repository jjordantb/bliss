public class BV implements BAI {
   static BV I = new BV(31);
   public static BV Z = new BV(-3);
   static BV C = new BV(2);
   static BV B = new BV(21);
   static BV D = new BV(9);
   static BV F = new BV(10);
   static BV J = new BV(20);
   static BV S = new BV(38);
   static BV A = new BV(33);
   public static BV E = new BV(-2);
   static BV G = new BV(32);
   static BV H = new BV(34);
   public static BV K = new BV(3);
   static BV L = new BV(30);
   int append;
   public static int M;

   BV(int var1) {
      this.append = var1 * -548304903;
   }

   public int method242(int var1) {
      try {
         return 1997834825 * this.append;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "rd.f(" + ')');
      }
   }

   public int method243() {
      return 1997834825 * this.append;
   }

   public int method244() {
      return 1997834825 * this.append;
   }

   static void I(OU var0, int var1) {
      try {
         UR var2 = OO.I.I(var0.H[(var0.J -= -391880689) * 681479919], 245040087);
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var2.E == null ? 0 : var2.E.length;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "rd.t(" + ')');
      }
   }

   public static void I(int var0, short var1) {
      try {
         VK var2 = IV.I(7, (long)var0);
         var2.B(-1807179158);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "rd.q(" + ')');
      }
   }

   public static boolean I(int var0, int var1) {
      try {
         return 19 == var0 || 1 == var0 || 4 == var0 || var0 == 3 || var0 == 8 || 2 == var0 || var0 == 9;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "rd.fo(" + ')');
      }
   }
}
