public abstract class ECI extends CCI {
   protected static int append = 4;

   public abstract boolean method557();

   public abstract void method558(XAI var1);

   public abstract boolean method559();

   public abstract boolean method560();

   public abstract void method561(int var1, TAI var2);

   public abstract void method562(int var1, TAI var2);

   public abstract void method563(int var1, TAI var2);

   public abstract void method564(XAI var1);

   public abstract boolean method565();

   public static void I(byte var0) {
      try {
         if (IU.I((byte)1) != CE.I) {
            try {
               String var1 = DSI.C.getParameter(QD.R.j);
               int var2 = (int)(CI.I((byte)1) / 86400000L) - 11745;
               String var3 = "usrdob=" + var2 + "; version=1; path=/; domain=" + var1;
               MY.I(DSI.C, "document.cookie=\"" + var3 + "\"", -1921482054);
            } catch (Throwable var4) {
               ;
            }
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "we.ni(" + ')');
      }
   }

   public static XM I(int var0) {
      try {
         if (GN.N != null && GN.m != null) {
            for(XM var1 = (XM)GN.m.next(); var1 != null; var1 = (XM)GN.m.next()) {
               HQ var2 = GN.W.I(var1.E * -530122905, -616779677);
               if (var2 != null && var2.a && var2.I(GN.D, 1789313805)) {
                  return var1;
               }
            }

            return null;
         } else {
            return null;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "we.ch(" + ')');
      }
   }
}
