public class CK extends YG {
   static int length = 4;
   static int pow = 4;
   static int substring = 1638;
   static int Q = 0;
   static boolean R = true;
   short[] T;
   short[] U;
   byte[] V = new byte[512];
   int W = 0;
   int X = 710364358;
   int Y = -93378244;
   int i = 277731988;
   int z = 1307885412;
   boolean c = true;
   static int b = 8;

   void append(short var1) {
      try {
         int var2;
         if (993272049 * this.X > 0) {
            this.T = new short[832987241 * this.z];
            this.U = new short[this.z * 832987241];

            for(var2 = 0; var2 < 832987241 * this.z; ++var2) {
               this.T[var2] = (short)((int)(Math.pow((double)((float)(993272049 * this.X) / 4096.0F), (double)var2) * 4096.0D));
               this.U[var2] = (short)((int)Math.pow(2.0D, (double)var2));
            }
         } else if (this.T != null && this.z * 832987241 == this.T.length) {
            this.U = new short[this.z * 832987241];

            for(var2 = 0; var2 < this.z * 832987241; ++var2) {
               this.U[var2] = (short)((int)Math.pow(2.0D, (double)var2));
            }
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ahw.bd(" + ')');
      }
   }

   int length(int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      try {
         int var8 = var1 >> 12;
         int var9 = 1 + var8;
         if (var9 >= var6) {
            var9 = 0;
         }

         var1 &= 4095;
         var8 &= 255;
         var9 &= 255;
         int var10 = var1 - 4096;
         int var11 = var2 - 4096;
         int var12 = WD.J[var1];
         int var13 = this.V[var8 + var3] & 3;
         int var14;
         if (var13 <= 1) {
            var14 = var13 == 0 ? var1 + var2 : var2 - var1;
         } else {
            var14 = 2 == var13 ? var1 - var2 : -var1 - var2;
         }

         var13 = this.V[var9 + var3] & 3;
         int var15;
         if (var13 <= 1) {
            var15 = var13 == 0 ? var2 + var10 : var2 - var10;
         } else {
            var15 = 2 == var13 ? var10 - var2 : -var10 - var2;
         }

         int var16 = var14 + ((var15 - var14) * var12 >> 12);
         var13 = this.V[var8 + var4] & 3;
         if (var13 <= 1) {
            var14 = var13 == 0 ? var1 + var11 : var11 - var1;
         } else {
            var14 = var13 == 2 ? var1 - var11 : -var1 - var11;
         }

         var13 = this.V[var4 + var9] & 3;
         if (var13 <= 1) {
            var15 = var13 == 0 ? var10 + var11 : var11 - var10;
         } else {
            var15 = 2 == var13 ? var10 - var11 : -var10 - var11;
         }

         int var17 = var14 + (var12 * (var15 - var14) >> 12);
         return ((var17 - var16) * var5 >> 12) + var16;
      } catch (RuntimeException var18) {
         throw DQ.I(var18, "ahw.am(" + ')');
      }
   }

   void I(int var1, REI var2, byte var3) {
      try {
         switch(var1) {
         case 0:
            this.c = var2.I() == 1;
            break;
         case 1:
            this.z = var2.I() * -1820512295;
            break;
         case 2:
            this.X = var2.J(1683252364) * 52875281;
            if (993272049 * this.X < 0) {
               this.T = new short[832987241 * this.z];

               for(int var4 = 0; var4 < 832987241 * this.z; ++var4) {
                  this.T[var4] = (short)var2.J(2045257879);
               }
            }
            break;
         case 3:
            this.i = (this.Y = var2.I() * 2124139087) * -1849370933;
            break;
         case 4:
            this.W = var2.I() * -1333197873;
            break;
         case 5:
            this.i = var2.I() * 1143174821;
            break;
         case 6:
            this.Y = var2.I() * 2124139087;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ahw.r(" + ')');
      }
   }

   void I(int var1, int[] var2, int var3) {
      try {
         int var4 = this.Y * 963316911 * WJ.J[var1];
         short var5;
         int var6;
         int var7;
         int var8;
         int var9;
         int var10;
         int var11;
         int var12;
         int var13;
         int var14;
         int var15;
         int var16;
         int var17;
         if (this.z * 832987241 == 1) {
            var5 = this.T[0];
            var6 = this.U[0] << 12;
            var7 = var6 * this.Y * 963316911 >> 12;
            var8 = var6 * this.i * 1428128045 >> 12;
            var9 = var4 * var6 >> 12;
            var10 = var9 >> 12;
            var11 = 1 + var10;
            if (var11 >= var7) {
               var11 = 0;
            }

            var9 &= 4095;
            var12 = WD.J[var9];
            var13 = this.V[var10 & 255] & 255;
            var14 = this.V[var11 & 255] & 255;
            if (this.c) {
               for(var15 = 0; var15 < -1474554145 * WJ.C; ++var15) {
                  var16 = 1428128045 * this.i * WJ.A[var15];
                  var17 = this.length(var6 * var16 >> 12, var9, var13, var14, var12, var8, 1556942442);
                  var17 = var17 * var5 >> 12;
                  var2[var15] = (var17 >> 1) + 2048;
               }
            } else {
               for(var15 = 0; var15 < WJ.C * -1474554145; ++var15) {
                  var16 = this.i * 1428128045 * WJ.A[var15];
                  var17 = this.length(var16 * var6 >> 12, var9, var13, var14, var12, var8, 1069393603);
                  var2[var15] = var5 * var17 >> 12;
               }
            }
         } else {
            var5 = this.T[0];
            if (var5 > 8 || var5 < -8) {
               var6 = this.U[0] << 12;
               var7 = var6 * this.Y * 963316911 >> 12;
               var8 = 1428128045 * this.i * var6 >> 12;
               var9 = var6 * var4 >> 12;
               var10 = var9 >> 12;
               var11 = var10 + 1;
               if (var11 >= var7) {
                  var11 = 0;
               }

               var9 &= 4095;
               var12 = WD.J[var9];
               var13 = this.V[var10 & 255] & 255;
               var14 = this.V[var11 & 255] & 255;

               for(var15 = 0; var15 < -1474554145 * WJ.C; ++var15) {
                  var16 = 1428128045 * this.i * WJ.A[var15];
                  var17 = this.length(var16 * var6 >> 12, var9, var13, var14, var12, var8, 818948604);
                  var2[var15] = var5 * var17 >> 12;
               }
            }

            for(var6 = 1; var6 < 832987241 * this.z; ++var6) {
               var5 = this.T[var6];
               if (var5 > 8 || var5 < -8) {
                  var7 = this.U[var6] << 12;
                  var8 = var7 * this.Y * 963316911 >> 12;
                  var9 = var7 * this.i * 1428128045 >> 12;
                  var10 = var7 * var4 >> 12;
                  var11 = var10 >> 12;
                  var12 = 1 + var11;
                  if (var12 >= var8) {
                     var12 = 0;
                  }

                  var10 &= 4095;
                  var13 = WD.J[var10];
                  var14 = this.V[var11 & 255] & 255;
                  var15 = this.V[var12 & 255] & 255;
                  int var18;
                  if (this.c && var6 == this.z * 832987241 - 1) {
                     for(var16 = 0; var16 < -1474554145 * WJ.C; ++var16) {
                        var17 = WJ.A[var16] * 1428128045 * this.i;
                        var18 = this.length(var17 * var7 >> 12, var10, var14, var15, var13, var9, 2029664133);
                        var18 = var2[var16] + (var18 * var5 >> 12);
                        var2[var16] = (var18 >> 1) + 2048;
                     }
                  } else {
                     for(var16 = 0; var16 < WJ.C * -1474554145; ++var16) {
                        var17 = WJ.A[var16] * 1428128045 * this.i;
                        var18 = this.length(var7 * var17 >> 12, var10, var14, var15, var13, var9, 1960253122);
                        var2[var16] += var5 * var18 >> 12;
                     }
                  }
               }
            }
         }

      } catch (RuntimeException var19) {
         throw DQ.I(var19, "ahw.ac(" + ')');
      }
   }

   void pow(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.c = var2.I() == 1;
         break;
      case 1:
         this.z = var2.I() * -1820512295;
         break;
      case 2:
         this.X = var2.J(2118380070) * 52875281;
         if (993272049 * this.X < 0) {
            this.T = new short[832987241 * this.z];

            for(int var3 = 0; var3 < 832987241 * this.z; ++var3) {
               this.T[var3] = (short)var2.J(1991735410);
            }
         }
         break;
      case 3:
         this.i = (this.Y = var2.I() * 2124139087) * -1849370933;
         break;
      case 4:
         this.W = var2.I() * -1333197873;
         break;
      case 5:
         this.i = var2.I() * 1143174821;
         break;
      case 6:
         this.Y = var2.I() * 2124139087;
      }

   }

   int[] Z(int var1, int var2) {
      try {
         int[] var3 = this.P.I(var1, 1918477853);
         if (this.P.D) {
            this.I(var1, var3, -1917282940);
         }

         return var3;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ahw.i(" + ')');
      }
   }

   void substring() {
      this.V = WJ.I(this.W * -1656937681, (byte)20);
      this.append((short)1115);

      for(int var1 = 832987241 * this.z - 1; var1 >= 1; --var1) {
         short var2 = this.T[var1];
         if (var2 > 8 || var2 < -8) {
            break;
         }

         this.z -= -1820512295;
      }

   }

   void append() {
      this.V = WJ.I(this.W * -1656937681, (byte)106);
      this.append((short)-8674);

      for(int var1 = 832987241 * this.z - 1; var1 >= 1; --var1) {
         short var2 = this.T[var1];
         if (var2 > 8 || var2 < -8) {
            break;
         }

         this.z -= -1820512295;
      }

   }

   void length() {
      this.V = WJ.I(this.W * -1656937681, (byte)6);
      this.append((short)-21404);

      for(int var1 = 832987241 * this.z - 1; var1 >= 1; --var1) {
         short var2 = this.T[var1];
         if (var2 > 8 || var2 < -8) {
            break;
         }

         this.z -= -1820512295;
      }

   }

   void substring(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.c = var2.I() == 1;
         break;
      case 1:
         this.z = var2.I() * -1820512295;
         break;
      case 2:
         this.X = var2.J(2106445483) * 52875281;
         if (993272049 * this.X < 0) {
            this.T = new short[832987241 * this.z];

            for(int var3 = 0; var3 < 832987241 * this.z; ++var3) {
               this.T[var3] = (short)var2.J(1806711607);
            }
         }
         break;
      case 3:
         this.i = (this.Y = var2.I() * 2124139087) * -1849370933;
         break;
      case 4:
         this.W = var2.I() * -1333197873;
         break;
      case 5:
         this.i = var2.I() * 1143174821;
         break;
      case 6:
         this.Y = var2.I() * 2124139087;
      }

   }

   int[] toString(int var1) {
      int[] var2 = this.P.I(var1, 1993749029);
      if (this.P.D) {
         this.I(var1, var2, -1997133557);
      }

      return var2;
   }

   public CK() {
      super(0, true);
   }

   void B(int var1) {
      try {
         this.V = WJ.I(this.W * -1656937681, (byte)-21);
         this.append((short)-24216);

         for(int var2 = 832987241 * this.z - 1; var2 >= 1; --var2) {
            short var3 = this.T[var2];
            if (var3 > 8 || var3 < -8) {
               break;
            }

            this.z -= -1820512295;
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ahw.x(" + ')');
      }
   }

   int[] append(int var1) {
      int[] var2 = this.P.I(var1, 1441765254);
      if (this.P.D) {
         this.I(var1, var2, -2123444089);
      }

      return var2;
   }

   static final void I(HSI var0, X var1, OU var2, int var3) {
      try {
         String var4 = (String)var2.S[(var2.A -= 969361751) * -203050393];
         if (IN.I(var4, var2, -897734805) != null) {
            var4 = var4.substring(0, var4.length() - 1);
         }

         var0.IC = OI.I(var4, var2, -2046058202);
         var0.JZ = true;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ahw.ng(" + ')');
      }
   }
}
