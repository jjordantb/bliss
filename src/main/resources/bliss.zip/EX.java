public class EX extends SX {
   IR method32;

   void I(BU var1, int var2) {
      QD.I(var1, var2, this.method32, -463239640);
   }

   void I(BU var1, int var2, byte var3) {
      try {
         QD.I(var1, var2, this.method32, -1175411035);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aew.l(" + ')');
      }
   }

   EX(IR var1, boolean var2) {
      super(var2);
      this.method32 = var1;
   }

   static boolean I(HAI var0, byte var1) {
      try {
         KEI var2 = XEI.mI.E(1998541007).C(var0.method32((byte)21));
         if (-1 == -1204256389 * var2.b) {
            return true;
         } else {
            BZI var3 = II.CI.I(var2.b * -1204256389, -2130110173);
            return -1 == 1690480405 * var3.C ? true : var3.I((byte)7);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aew.d(" + ')');
      }
   }
}
