public class BG extends AE {
   static SU J;
   public IY S = new IY();
   static XE A;

   static final void I(int var0, int var1, int var2, int var3, byte var4) {
      try {
         if (var0 - var2 >= IT.D * -1424479739 && var2 + var0 <= IT.Z * 1135094847 && var1 - var2 >= IT.C * 1155384281 && var1 + var2 <= IT.B * -1062447355) {
            CX.I(var0, var1, var2, var3, -586727793);
         } else {
            YN.I(var0, var1, var2, var3, 179222192);
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "aad.x(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         ID.I(var3, var4, var0, (byte)-5);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aad.jo(" + ')');
      }
   }

   static final void B(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-113);
         X var4 = IU.F[var2 >> 16];
         UJ.I(var3, var4, var0, 131231409);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aad.ij(" + ')');
      }
   }

   static final void D(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.S[(var0.A += 969361751) * -203050393 - 1] = Integer.toString(var2);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aad.ze(" + ')');
      }
   }
}
