public class CH extends YG {
   public static KJ Q;
   public static int R = 1345470509;
   int T = 715315885;
   int U;
   int V;
   int[] W;

   void Z(int var1, REI var2) {
      if (var1 == 0) {
         this.T = var2.C() * -715315885;
      }

   }

   int I(short var1) {
      try {
         return -2121898277 * this.T;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "agy.q(" + ')');
      }
   }

   void append() {
      super.C(1881168514);
      this.W = null;
   }

   void C(int var1) {
      try {
         super.C(1881168514);
         this.W = null;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "agy.f(" + ')');
      }
   }

   boolean D(int var1) {
      try {
         if (this.W != null) {
            return true;
         } else if (-2121898277 * this.T >= 0) {
            RFI var2 = R * -1132597157 >= 0 ? RFI.I(Q, -1132597157 * R, -2121898277 * this.T) : RFI.I(Q, this.T * -2121898277);
            var2.C();
            this.W = var2.D();
            this.U = -506570825 * var2.Z;
            this.V = -274319933 * var2.F;
            return true;
         } else {
            return false;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "agy.ac(" + ')');
      }
   }

   void I(int var1, REI var2, byte var3) {
      try {
         if (var1 == 0) {
            this.T = var2.C() * -715315885;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "agy.r(" + ')');
      }
   }

   int[][] I(int var1, byte var2) {
      try {
         int[][] var3 = this.L.I(var1, (byte)40);
         if (this.L.I && this.D(-2021836506)) {
            int[] var4 = var3[0];
            int[] var5 = var3[1];
            int[] var6 = var3[2];
            int var7 = 1274885639 * this.U * (461985445 * WJ.B != -2125962517 * this.V ? this.V * -2125962517 * var1 / (WJ.B * 461985445) : var1);
            int var8;
            int var9;
            if (this.U * 1274885639 == -1474554145 * WJ.C) {
               for(var8 = 0; var8 < WJ.C * -1474554145; ++var8) {
                  var9 = this.W[var7++];
                  var6[var8] = (var9 & 255) << 4;
                  var5[var8] = (var9 & '\uff00') >> 4;
                  var4[var8] = (var9 & 16711680) >> 12;
               }
            } else {
               for(var8 = 0; var8 < -1474554145 * WJ.C; ++var8) {
                  var9 = var8 * this.U * 1274885639 / (WJ.C * -1474554145);
                  int var10 = this.W[var9 + var7];
                  var6[var8] = (var10 & 255) << 4;
                  var5[var8] = (var10 & '\uff00') >> 4;
                  var4[var8] = (var10 & 16711680) >> 12;
               }
            }
         }

         return var3;
      } catch (RuntimeException var11) {
         throw DQ.I(var11, "agy.k(" + ')');
      }
   }

   void toString(int var1, REI var2) {
      if (var1 == 0) {
         this.T = var2.C() * -715315885;
      }

   }

   public CH() {
      super(0, false);
   }

   int[][] F(int var1) {
      int[][] var2 = this.L.I(var1, (byte)114);
      if (this.L.I && this.D(1831903701)) {
         int[] var3 = var2[0];
         int[] var4 = var2[1];
         int[] var5 = var2[2];
         int var6 = 1274885639 * this.U * (461985445 * WJ.B != -2125962517 * this.V ? this.V * -2125962517 * var1 / (WJ.B * 461985445) : var1);
         int var7;
         int var8;
         if (this.U * 1274885639 == -1474554145 * WJ.C) {
            for(var7 = 0; var7 < WJ.C * -1474554145; ++var7) {
               var8 = this.W[var6++];
               var5[var7] = (var8 & 255) << 4;
               var4[var7] = (var8 & '\uff00') >> 4;
               var3[var7] = (var8 & 16711680) >> 12;
            }
         } else {
            for(var7 = 0; var7 < -1474554145 * WJ.C; ++var7) {
               var8 = var7 * this.U * 1274885639 / (WJ.C * -1474554145);
               int var9 = this.W[var8 + var6];
               var5[var7] = (var9 & 255) << 4;
               var4[var7] = (var9 & '\uff00') >> 4;
               var3[var7] = (var9 & 16711680) >> 12;
            }
         }
      }

      return var2;
   }

   int[][] J(int var1) {
      int[][] var2 = this.L.I(var1, (byte)9);
      if (this.L.I && this.D(508632010)) {
         int[] var3 = var2[0];
         int[] var4 = var2[1];
         int[] var5 = var2[2];
         int var6 = 1274885639 * this.U * (461985445 * WJ.B != -2125962517 * this.V ? this.V * -2125962517 * var1 / (WJ.B * 461985445) : var1);
         int var7;
         int var8;
         if (this.U * 1274885639 == -1474554145 * WJ.C) {
            for(var7 = 0; var7 < WJ.C * -1474554145; ++var7) {
               var8 = this.W[var6++];
               var5[var7] = (var8 & 255) << 4;
               var4[var7] = (var8 & '\uff00') >> 4;
               var3[var7] = (var8 & 16711680) >> 12;
            }
         } else {
            for(var7 = 0; var7 < -1474554145 * WJ.C; ++var7) {
               var8 = var7 * this.U * 1274885639 / (WJ.C * -1474554145);
               int var9 = this.W[var8 + var6];
               var5[var7] = (var9 & 255) << 4;
               var4[var7] = (var9 & '\uff00') >> 4;
               var3[var7] = (var9 & 16711680) >> 12;
            }
         }
      }

      return var2;
   }

   int Z() {
      return -2121898277 * this.T;
   }

   static final void C(OU var0, int var1) {
      try {
         if (XEI.OD != null) {
            var0.S[(var0.A += 969361751) * -203050393 - 1] = XEI.OD;
         } else {
            var0.S[(var0.A += 969361751) * -203050393 - 1] = "";
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "agy.wj(" + ')');
      }
   }
}
