import jaggl.OpenGL;

public class HCI extends ECI {
   int a;
   VAI[] f = new VAI[4];
   static int glBindFramebufferEXT = 16;
   int glBlitFramebufferEXT;
   MJI glCheckFramebufferStatusEXT;
   int glDrawBuffer;
   int glFramebufferRenderbufferEXT;
   VAI glGenFramebuffersEXT;
   int method3;

   public int method547() {
      return this.glBlitFramebufferEXT;
   }

   public int method545() {
      return this.glBlitFramebufferEXT;
   }

   public int method552() {
      return this.method3;
   }

   public void method563(int var1, TAI var2) {
      int var3 = 1 << var1;
      VAI var4 = (VAI)var2;
      if (var2 == null) {
         this.glDrawBuffer &= ~var3;
         this.f[var1] = null;
         if (this.glDrawBuffer == 0) {
            this.method3 = 0;
            this.glBlitFramebufferEXT = 0;
         }
      } else {
         if ((this.glDrawBuffer | var3) != var3) {
            if (this.glBlitFramebufferEXT != var4.a() || this.method3 != var4.f()) {
               throw new RuntimeException();
            }
         } else {
            this.method3 = var4.f();
            this.glBlitFramebufferEXT = var4.a();
            if (this == this.glCheckFramebufferStatusEXT.I((short)-4129)) {
               this.glCheckFramebufferStatusEXT.F();
            }
         }

         this.glDrawBuffer |= var3;
         this.f[var1] = var4;
      }

      if (this == this.glCheckFramebufferStatusEXT.I((short)-22905)) {
         this.Z(var1);
      } else {
         this.glFramebufferRenderbufferEXT |= var3;
      }

   }

   public void method558(XAI var1) {
      VAI var2 = (VAI)var1;
      if (var1 == null) {
         this.glDrawBuffer &= -17;
         this.glGenFramebuffersEXT = null;
         if (this.glDrawBuffer == 0) {
            this.method3 = 0;
            this.glBlitFramebufferEXT = 0;
         }
      } else {
         if ((this.glDrawBuffer | 16) != 16) {
            if (this.glBlitFramebufferEXT != var2.a() || this.method3 != var2.f()) {
               throw new RuntimeException();
            }
         } else {
            this.method3 = var2.f();
            this.glBlitFramebufferEXT = var2.a();
            if (this == this.glCheckFramebufferStatusEXT.I((short)-7371)) {
               this.glCheckFramebufferStatusEXT.F();
            }
         }

         this.glDrawBuffer |= 16;
         this.glGenFramebuffersEXT = var2;
      }

      if (this == this.glCheckFramebufferStatusEXT.I((short)16488)) {
         this.a();
      } else {
         this.glFramebufferRenderbufferEXT |= 16;
      }

   }

   void Z(int var1) {
      VAI var2 = this.f[var1];
      if (var2 == null) {
         OpenGL.glFramebufferRenderbufferEXT(36160, '賠' + var1, 36161, 0);
      } else {
         var2.method3('賠' + var1);
      }

   }

   public void method135() {
      if (this.a != 0) {
         this.glCheckFramebufferStatusEXT.Z(this.a);
         this.a = 0;
      }

   }

   public boolean method560() {
      int var1 = OpenGL.glCheckFramebufferStatusEXT(36160);
      return var1 == 36053;
   }

   boolean method136() {
      OpenGL.glBindFramebufferEXT(36160, this.a);

      for(int var1 = 0; var1 < 4; ++var1) {
         if ((this.glFramebufferRenderbufferEXT & 1 << var1) != 0) {
            this.Z(var1);
         }
      }

      if ((this.glFramebufferRenderbufferEXT & 16) != 0) {
         this.a();
      }

      this.glFramebufferRenderbufferEXT = 0;
      this.glCheckFramebufferStatusEXT.Z();
      return true;
   }

   boolean method546() {
      OpenGL.glBindFramebufferEXT(36160, 0);
      return true;
   }

   void I(int var1, int var2, int var3, int var4, int var5, int var6, boolean var7, boolean var8) {
      if (var7 | var8) {
         int var9 = this.method3;
         int var10 = this.glCheckFramebufferStatusEXT.I((short)-16350).method552();
         int var11 = 0;
         if (var8) {
            var11 |= 256;
         }

         if (var7) {
            var11 |= 16384;
         }

         OpenGL.glBindFramebufferEXT(36008, this.a);
         OpenGL.glBlitFramebufferEXT(var1, var9 - var2 - var4, var1 + var3, var9 - var2, var5, var10 - var6 - var4, var5 + var3, var10 - var6, var11, 9728);
         OpenGL.glBindFramebufferEXT(36008, 0);
      }

   }

   boolean method134() {
      OpenGL.glBindFramebufferEXT(36160, this.a);

      for(int var1 = 0; var1 < 4; ++var1) {
         if ((this.glFramebufferRenderbufferEXT & 1 << var1) != 0) {
            this.Z(var1);
         }
      }

      if ((this.glFramebufferRenderbufferEXT & 16) != 0) {
         this.a();
      }

      this.glFramebufferRenderbufferEXT = 0;
      this.glCheckFramebufferStatusEXT.Z();
      return true;
   }

   public int method551() {
      return this.glBlitFramebufferEXT;
   }

   public void method561(int var1, TAI var2) {
      int var3 = 1 << var1;
      VAI var4 = (VAI)var2;
      if (var2 == null) {
         this.glDrawBuffer &= ~var3;
         this.f[var1] = null;
         if (this.glDrawBuffer == 0) {
            this.method3 = 0;
            this.glBlitFramebufferEXT = 0;
         }
      } else {
         if ((this.glDrawBuffer | var3) != var3) {
            if (this.glBlitFramebufferEXT != var4.a() || this.method3 != var4.f()) {
               throw new RuntimeException();
            }
         } else {
            this.method3 = var4.f();
            this.glBlitFramebufferEXT = var4.a();
            if (this == this.glCheckFramebufferStatusEXT.I((short)3587)) {
               this.glCheckFramebufferStatusEXT.F();
            }
         }

         this.glDrawBuffer |= var3;
         this.f[var1] = var4;
      }

      if (this == this.glCheckFramebufferStatusEXT.I((short)8575)) {
         this.Z(var1);
      } else {
         this.glFramebufferRenderbufferEXT |= var3;
      }

   }

   public void method562(int var1, TAI var2) {
      int var3 = 1 << var1;
      VAI var4 = (VAI)var2;
      if (var2 == null) {
         this.glDrawBuffer &= ~var3;
         this.f[var1] = null;
         if (this.glDrawBuffer == 0) {
            this.method3 = 0;
            this.glBlitFramebufferEXT = 0;
         }
      } else {
         if ((this.glDrawBuffer | var3) != var3) {
            if (this.glBlitFramebufferEXT != var4.a() || this.method3 != var4.f()) {
               throw new RuntimeException();
            }
         } else {
            this.method3 = var4.f();
            this.glBlitFramebufferEXT = var4.a();
            if (this == this.glCheckFramebufferStatusEXT.I((short)26777)) {
               this.glCheckFramebufferStatusEXT.F();
            }
         }

         this.glDrawBuffer |= var3;
         this.f[var1] = var4;
      }

      if (this == this.glCheckFramebufferStatusEXT.I((short)-1151)) {
         this.Z(var1);
      } else {
         this.glFramebufferRenderbufferEXT |= var3;
      }

   }

   public void method564(XAI var1) {
      VAI var2 = (VAI)var1;
      if (var1 == null) {
         this.glDrawBuffer &= -17;
         this.glGenFramebuffersEXT = null;
         if (this.glDrawBuffer == 0) {
            this.method3 = 0;
            this.glBlitFramebufferEXT = 0;
         }
      } else {
         if ((this.glDrawBuffer | 16) != 16) {
            if (this.glBlitFramebufferEXT != var2.a() || this.method3 != var2.f()) {
               throw new RuntimeException();
            }
         } else {
            this.method3 = var2.f();
            this.glBlitFramebufferEXT = var2.a();
            if (this == this.glCheckFramebufferStatusEXT.I((short)-16571)) {
               this.glCheckFramebufferStatusEXT.F();
            }
         }

         this.glDrawBuffer |= 16;
         this.glGenFramebuffersEXT = var2;
      }

      if (this == this.glCheckFramebufferStatusEXT.I((short)11041)) {
         this.a();
      } else {
         this.glFramebufferRenderbufferEXT |= 16;
      }

   }

   public boolean method557() {
      int var1 = OpenGL.glCheckFramebufferStatusEXT(36160);
      return var1 == 36053;
   }

   public boolean method565() {
      int var1 = OpenGL.glCheckFramebufferStatusEXT(36160);
      return var1 == 36053;
   }

   public int method550() {
      return this.glBlitFramebufferEXT;
   }

   boolean method548() {
      OpenGL.glBindFramebufferEXT(36160, 0);
      return true;
   }

   void a() {
      if (this.glGenFramebuffersEXT == null) {
         OpenGL.glFramebufferRenderbufferEXT(36160, 36096, 36161, 0);
      } else {
         this.glGenFramebuffersEXT.method3(36096);
      }

   }

   public void method138() {
      if (this.a != 0) {
         this.glCheckFramebufferStatusEXT.Z(this.a);
         this.a = 0;
      }

   }

   public int method549() {
      return this.glBlitFramebufferEXT;
   }

   public void method137() {
      if (this.a != 0) {
         this.glCheckFramebufferStatusEXT.Z(this.a);
         this.a = 0;
      }

   }

   public boolean method559() {
      int var1 = OpenGL.glCheckFramebufferStatusEXT(36160);
      return var1 == 36053;
   }

   void C(int var1) {
      OpenGL.glDrawBuffer('賠' + var1);
   }

   public int method544() {
      return this.method3;
   }

   HCI(MJI var1) {
      if (!var1.CI) {
         throw new IllegalStateException("");
      } else {
         this.glCheckFramebufferStatusEXT = var1;
         int[] var2 = new int[1];
         OpenGL.glGenFramebuffersEXT(1, var2, 0);
         this.a = var2[0];
      }
   }
}
