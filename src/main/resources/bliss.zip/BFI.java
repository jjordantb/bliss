public class BFI extends LDI {
   int B;

   BFI(REI var1) {
      super(var1);
      this.B = var1.C() * 855211779;
   }

   public void method866(int var1) {
      try {
         PFI.J[this.B * 297690027].I((byte)12);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "yt.f(" + ')');
      }
   }

   public void method868() {
      PFI.J[this.B * 297690027].I((byte)12);
   }

   public void method869() {
      PFI.J[this.B * 297690027].I((byte)12);
   }

   static final void I(IR var0, int var1, boolean var2, int var3) {
      try {
         int var4;
         int var5;
         if (var0 instanceof ZR && var0 instanceof HAI) {
            ZR var10 = (ZR)var0;
            int var7 = var10.P - var10.R + 1 << 9;
            int var8 = 1 + (var10.Q - var10.O) << 9;
            var4 = (var10.R << 9) + var7 / 2;
            var5 = var8 / 2 + (var10.O << 9);
         } else {
            SF var6 = var0.I().I;
            var4 = (int)var6.I;
            var5 = (int)var6.Z;
         }

         SI.I(var0.K, var4, var5, 0, var1, var2, 1992555297);
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "yt.jg(" + ')');
      }
   }

   static final void B(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)76);
         PA.I(var3, var0, -767212097);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "yt.qe(" + ')');
      }
   }

   static final boolean I(int var0, int var1, boolean var2, LEI var3, int var4) {
      try {
         int var5 = UA.F.YI[0];
         int var6 = UA.F.v[0];
         if (var5 >= 0 && var5 < XEI.mI.Z(-2029828730) && var6 >= 0 && var6 < XEI.mI.C(911412275)) {
            if (var0 >= 0 && var0 < XEI.mI.Z(-2140756422) && var1 >= 0 && var1 < XEI.mI.C(1432313507)) {
               int var7 = QK.I(var5, var6, UA.F.S(), var3, XEI.mI.A(UA.F.K), var2, XEI.OZ, XEI.FZ);
               if (var7 < 1) {
                  return false;
               } else {
                  JN.A = XEI.OZ[var7 - 1] * -1129029761;
                  JN.I = -1835291189 * XEI.FZ[var7 - 1];
                  JN.E = false;
                  TO.I(-2054792212);
                  return true;
               }
            } else {
               return false;
            }
         } else {
            return false;
         }
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "yt.jz(" + ')');
      }
   }
}
