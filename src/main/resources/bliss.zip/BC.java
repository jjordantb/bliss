public class BC extends CC {
   public void x() {
   }

   public void b() {
   }

   public void d() {
   }

   BC(KB[] var1) {
      super(var1);
   }

   public void u() {
   }
}
