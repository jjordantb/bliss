import jaggl.OpenGL;

public class BL extends QK implements VAI {
   int glBindRenderbufferEXT;
   int glDeleteRenderbuffersEXT;
   int glFramebufferRenderbufferEXT;
   static int[] glGenRenderbuffersEXT = new int[1];
   SDI glRenderbufferStorageEXT;
   YCI glRenderbufferStorageMultisampleEXT;
   int G;
   MJI H;

   public int f() {
      return this.glDeleteRenderbuffersEXT;
   }

   public void method1(int var1) {
      OpenGL.glFramebufferRenderbufferEXT(36160, var1, 36161, this.glBindRenderbufferEXT);
   }

   public int a() {
      return this.glFramebufferRenderbufferEXT;
   }

   public void method3(int var1) {
      OpenGL.glFramebufferRenderbufferEXT(36160, var1, 36161, this.glBindRenderbufferEXT);
   }

   public void b() {
      if (this.glBindRenderbufferEXT > 0) {
         int[] var1 = new int[]{this.glBindRenderbufferEXT};
         OpenGL.glDeleteRenderbuffersEXT(1, var1, 0);
         this.glBindRenderbufferEXT = 0;
      }

   }

   void glBindRenderbufferEXT() {
      if (this.glBindRenderbufferEXT > 0) {
         this.H.C(this.glBindRenderbufferEXT, this.G);
         this.glBindRenderbufferEXT = 0;
      }

   }

   public int p() {
      return this.glFramebufferRenderbufferEXT;
   }

   public int i() {
      return this.glFramebufferRenderbufferEXT;
   }

   BL(MJI var1, YCI var2, SDI var3, int var4, int var5, int var6) {
      this.H = var1;
      this.glFramebufferRenderbufferEXT = var4;
      this.glDeleteRenderbuffersEXT = var5;
      this.glRenderbufferStorageMultisampleEXT = var2;
      this.glRenderbufferStorageEXT = var3;
      OpenGL.glGenRenderbuffersEXT(1, glGenRenderbuffersEXT, 0);
      this.glBindRenderbufferEXT = glGenRenderbuffersEXT[0];
      OpenGL.glBindRenderbufferEXT(36161, this.glBindRenderbufferEXT);
      OpenGL.glRenderbufferStorageMultisampleEXT(36161, var6, MJI.I(this.glRenderbufferStorageMultisampleEXT, this.glRenderbufferStorageEXT), this.glFramebufferRenderbufferEXT, this.glDeleteRenderbuffersEXT);
      this.G = this.glFramebufferRenderbufferEXT * this.glDeleteRenderbuffersEXT * this.glRenderbufferStorageMultisampleEXT.I * 845115459 * this.glRenderbufferStorageEXT.S * 685647847;
   }

   public void d() {
      if (this.glBindRenderbufferEXT > 0) {
         int[] var1 = new int[]{this.glBindRenderbufferEXT};
         OpenGL.glDeleteRenderbuffersEXT(1, var1, 0);
         this.glBindRenderbufferEXT = 0;
      }

   }

   public void u() {
      if (this.glBindRenderbufferEXT > 0) {
         int[] var1 = new int[]{this.glBindRenderbufferEXT};
         OpenGL.glDeleteRenderbuffersEXT(1, var1, 0);
         this.glBindRenderbufferEXT = 0;
      }

   }

   public void x() {
      if (this.glBindRenderbufferEXT > 0) {
         int[] var1 = new int[]{this.glBindRenderbufferEXT};
         OpenGL.glDeleteRenderbuffersEXT(1, var1, 0);
         this.glBindRenderbufferEXT = 0;
      }

   }

   public void method2(int var1) {
      OpenGL.glFramebufferRenderbufferEXT(36160, var1, 36161, this.glBindRenderbufferEXT);
   }

   public int k() {
      return this.glDeleteRenderbuffersEXT;
   }

   public void method4(int var1) {
      OpenGL.glFramebufferRenderbufferEXT(36160, var1, 36161, this.glBindRenderbufferEXT);
   }

   BL(MJI var1, YCI var2, SDI var3, int var4, int var5) {
      this.H = var1;
      this.glFramebufferRenderbufferEXT = var4;
      this.glDeleteRenderbuffersEXT = var5;
      this.glRenderbufferStorageMultisampleEXT = var2;
      this.glRenderbufferStorageEXT = var3;
      OpenGL.glGenRenderbuffersEXT(1, glGenRenderbuffersEXT, 0);
      this.glBindRenderbufferEXT = glGenRenderbuffersEXT[0];
      OpenGL.glBindRenderbufferEXT(36161, this.glBindRenderbufferEXT);
      OpenGL.glRenderbufferStorageEXT(36161, MJI.I(this.glRenderbufferStorageMultisampleEXT, this.glRenderbufferStorageEXT), this.glFramebufferRenderbufferEXT, this.glDeleteRenderbuffersEXT);
      this.G = this.glFramebufferRenderbufferEXT * this.glDeleteRenderbuffersEXT * this.glRenderbufferStorageMultisampleEXT.I * 845115459 * this.glRenderbufferStorageEXT.S * 685647847;
   }
}
