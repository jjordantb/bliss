public abstract class LDI {
   public int I;

   public abstract void method866(int var1);

   void I(int var1) {
   }

   LDI(REI var1) {
      this.I = var1.C() * 349693613;
   }

   public abstract void method868();

   public abstract void method869();

   boolean Z(int var1) {
      return true;
   }

   static void I(GSI var0, KEI var1, int var2, int var3, int var4, byte var5) {
      try {
         BZI var6 = II.CI.I(var1.b * -1204256389, -2141345299);
         if (1690480405 * var6.C != -1) {
            if (var1.d) {
               var2 += -1382013163 * var1.j;
               var2 &= 3;
            } else {
               var2 = 0;
            }

            IBI var7 = var6.I(var0, var2, var1.EI, (byte)-63);
            if (var7 != null) {
               int var8 = -1125834887 * var1.N;
               int var9 = -565161399 * var1.L;
               if ((var2 & 1) == 1) {
                  var8 = -565161399 * var1.L;
                  var9 = var1.N * -1125834887;
               }

               int var10 = var7.method271();
               int var11 = var7.method626();
               if (var6.B) {
                  var10 = var8 * 4;
                  var11 = 4 * var9;
               }

               if (var6.Z * -2012904123 != 0) {
                  var7.I(var3, var4 - (var9 - 1) * 4, var10, var11, 0, -16777216 | var6.Z * -2012904123, 1);
               } else {
                  var7.I(var3, var4 - 4 * (var9 - 1), var10, var11);
               }
            }
         }

      } catch (RuntimeException var12) {
         throw DQ.I(var12, "di.x(" + ')');
      }
   }

   public static void I(int var0, byte var1) {
      try {
         FN.I = var0 * 1684929947;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "di.i(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-100);
         X var4 = IU.F[var2 >> 16];
         PL.I(var3, var4, var0, -2106555824);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "di.md(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         long var2 = var0.Q[(var0.K -= -682569305) * 1685767703];
         var0.S[(var0.A += 969361751) * -203050393 - 1] = var2 == -1L ? "" : Long.toString(var2, 36).toUpperCase();
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "di.aab(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         FW.J.I(FW.J.G, var0.H[(var0.J -= -391880689) * 681479919], -283253928);
         WR.I(FW.J.d.I(-1637975360), false, 622850291);
         JN.I(656179282);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "di.aia(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         F var3 = XL.Z(var2, 601023665);
         int var4 = 0;
         if (var3 != null) {
            var4 = var3.S * 1016049299;
         }

         var0.H[(var0.J += -391880689) * 681479919 - 1] = var4;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "di.acf(" + ')');
      }
   }
}
