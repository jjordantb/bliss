public class LP extends LEI {
   int I;
   RW Z;

   public boolean method4090(int var1, int var2, int var3, XA var4, int var5) {
      try {
         return var4.I(var2, var3, var1, -1331662251 * this.B, 1517720743 * this.C, this.Z.method242(694163818), this.I * 83994365, 874579938);
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "acd.a(" + ')');
      }
   }

   public boolean method4089(int var1, int var2, int var3, XA var4) {
      return var4.I(var2, var3, var1, -1331662251 * this.B, 1517720743 * this.C, this.Z.method242(694163818), this.I * 83994365, 520136743);
   }

   public boolean method4091(int var1, int var2, int var3, XA var4) {
      return var4.I(var2, var3, var1, -1331662251 * this.B, 1517720743 * this.C, this.Z.method242(694163818), this.I * 83994365, 2048707586);
   }
}
