public class GP {
   int[] I;
   boolean Z = true;
   int[] C;
   static int B = 102;
   AP S;
   EP arraycopy;
   int[] D;
   public boolean F = true;
   int method4361;
   int[][][] method5060;
   int J;
   DP[] A;
   int E;
   int[] G = new int[2];
   int H;
   DP[] K;
   int L = 0;
   DP[] M;
   static float N = 3.0F;
   int[] O;
   int[] P;
   DP[] Q;
   boolean R = false;
   int[] T;
   int U;
   float[] V = new float[3];
   static GSI W;
   int X = -1;
   int Y = -1;
   boolean i = true;

   final boolean B(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9) {
      if (!this.B(var1, var2, var3)) {
         return false;
      } else {
         var1 = (int)this.V[0];
         var2 = (int)this.V[1];
         var3 = (int)this.V[2];
         if (!this.B(var4, var5, var6)) {
            return false;
         } else {
            var4 = (int)this.V[0];
            var5 = (int)this.V[1];
            var6 = (int)this.V[2];
            if (!this.B(var7, var8, var9)) {
               return false;
            } else {
               var7 = (int)this.V[0];
               var8 = (int)this.V[1];
               var9 = (int)this.V[2];
               return this.arraycopy.I(var2, var5, var8, var1, var4, var7, var3, var6, var9);
            }
         }
      }
   }

   public void I(int var1, int var2, int var3, int var4, int var5, int var6) {
      if (var1 != 8 && var1 != 16) {
         BP var13 = this.S.E[var2][var3][var4];
         if (var13 == null) {
            this.S.E[var2][var3][var4] = var13 = new BP(var2);
         }

         if (var1 == 1) {
            var13.E = (short)var5;
            var13.G = (short)var6;
         } else if (var1 == 2) {
            var13.A = (short)var5;
            var13.K = (short)var6;
         }

         if (this.R) {
            this.S();
         }
      } else {
         int var7;
         int var8;
         int var9;
         int var10;
         int var11;
         int var12;
         if (var1 == 8) {
            var7 = var3 << this.S.I * -1688804109;
            var8 = var7 + this.S.P * 1828905535;
            var9 = var4 << this.S.I * -1688804109;
            var10 = var9 + this.S.P * 1828905535;
            var11 = this.S.K[var2].I(var3, var4, (byte)-46);
            var12 = this.S.K[var2].I(var3 + 1, var4 + 1, (byte)-53);
            this.Q[this.H++] = new DP(this.S, var1, var2, var7, var8, var8, var7, var11, var12, var12 - var5, var11 - var5, var9, var10, var10, var9);
         } else {
            var7 = (var3 << this.S.I * -1688804109) + this.S.P * 1828905535;
            var8 = var7 - this.S.P * 1828905535;
            var9 = var4 << this.S.I * -1688804109;
            var10 = var9 + this.S.P * 1828905535;
            var11 = this.S.K[var2].I(var3 + 1, var4, (byte)-128);
            var12 = this.S.K[var2].I(var3, var4 + 1, (byte)-126);
            this.Q[this.H++] = new DP(this.S, var1, var2, var7, var8, var8, var7, var11, var12, var12 - var5, var11 - var5, var9, var10, var10, var9);
         }
      }

   }

   public void I(int var1, int var2, int var3, int var4) {
      if (var1 != 8 && var1 != 16) {
         BP var7 = this.S.E[var2][var3][var4];
         if (var7 != null) {
            if (var1 == 1) {
               var7.E = 0;
            } else if (var1 == 2) {
               var7.A = 0;
            }
         }

         this.S();
      } else {
         for(int var5 = 0; var5 < this.H; ++var5) {
            DP var6 = this.Q[var5];
            if (var6.F == var1 && var6.C == var2 && (var6.G == var3 && var6.B == var4 || var6.D == var3 && var6.J == var4)) {
               if (var5 != this.H) {
                  System.arraycopy(this.Q, var5 + 1, this.Q, var5, this.Q.length - (var5 + 1));
               }

               --this.H;
               break;
            }
         }
      }

   }

   void S(GSI var1, DP var2, int var3) {
      W = var1;
      int var4;
      if (this.C != null && var2.C >= var3) {
         for(var4 = 0; var4 < this.C.length; ++var4) {
            if (this.C[var4] != -1000000 && (var2.A[0] <= this.C[var4] || var2.A[1] <= this.C[var4] || var2.A[2] <= this.C[var4] || var2.A[3] <= this.C[var4]) && (var2.S[0] <= this.P[var4] || var2.S[1] <= this.P[var4] || var2.S[2] <= this.P[var4] || var2.S[3] <= this.P[var4]) && (var2.S[0] >= this.O[var4] || var2.S[1] >= this.O[var4] || var2.S[2] >= this.O[var4] || var2.S[3] >= this.O[var4]) && (var2.E[0] <= this.D[var4] || var2.E[1] <= this.D[var4] || var2.E[2] <= this.D[var4] || var2.E[3] <= this.D[var4]) && (var2.E[0] >= this.I[var4] || var2.E[1] >= this.I[var4] || var2.E[2] >= this.I[var4] || var2.E[3] >= this.I[var4])) {
               return;
            }
         }
      }

      int var5;
      int var6;
      boolean var7;
      float var8;
      if (var2.F == 1) {
         var4 = var2.G - this.S.z * -804213305 + this.S.Q * 583010427;
         if (var4 >= 0 && var4 <= this.S.Q * 583010427 + this.S.Q * 583010427) {
            var5 = var2.B - this.S.J * 465603579 + this.S.Q * 583010427;
            if (var5 < 0) {
               var5 = 0;
            } else if (var5 > this.S.Q * 583010427 + this.S.Q * 583010427) {
               return;
            }

            var6 = var2.J - this.S.J * 465603579 + this.S.Q * 583010427;
            if (var6 > this.S.Q * 583010427 + this.S.Q * 583010427) {
               var6 = this.S.Q * 583010427 + this.S.Q * 583010427;
            } else if (var6 < 0) {
               return;
            }

            var7 = false;

            while(var5 <= var6) {
               if (this.S.d[var4][var5++]) {
                  var7 = true;
                  break;
               }
            }

            if (var7) {
               var8 = (float)(this.S.T * -343859235 - var2.S[0]);
               if (var8 < 0.0F) {
                  var8 *= -1.0F;
               }

               if (var8 >= (float)this.method4361 && this.method4361(var2, 0) && this.method4361(var2, 1) && this.method4361(var2, 2) && this.method4361(var2, 3)) {
                  this.M[this.L++] = var2;
               }
            }
         }
      } else if (var2.F == 2) {
         var4 = var2.B - this.S.J * 465603579 + this.S.Q * 583010427;
         if (var4 >= 0 && var4 <= this.S.Q * 583010427 + this.S.Q * 583010427) {
            var5 = var2.G - this.S.z * -804213305 + this.S.Q * 583010427;
            if (var5 < 0) {
               var5 = 0;
            } else if (var5 > this.S.Q * 583010427 + this.S.Q * 583010427) {
               return;
            }

            var6 = var2.D - this.S.z * -804213305 + this.S.Q * 583010427;
            if (var6 > this.S.Q * 583010427 + this.S.Q * 583010427) {
               var6 = this.S.Q * 583010427 + this.S.Q * 583010427;
            } else if (var6 < 0) {
               return;
            }

            var7 = false;

            while(var5 <= var6) {
               if (this.S.d[var5++][var4]) {
                  var7 = true;
                  break;
               }
            }

            if (var7) {
               var8 = (float)(this.S.U * -1526003751 - var2.E[0]);
               if (var8 < 0.0F) {
                  var8 *= -1.0F;
               }

               if (var8 >= (float)this.method4361 && this.method4361(var2, 0) && this.method4361(var2, 1) && this.method4361(var2, 2) && this.method4361(var2, 3)) {
                  this.M[this.L++] = var2;
               }
            }
         }
      } else if (var2.F != 16 && var2.F != 8) {
         if (var2.F == 4) {
            float var12 = (float)(var2.A[0] - this.S.V * 2104557959);
            if (var12 > (float)this.U) {
               var5 = var2.B - this.S.J * 465603579 + this.S.Q * 583010427;
               if (var5 < 0) {
                  var5 = 0;
               } else if (var5 > this.S.Q * 583010427 + this.S.Q * 583010427) {
                  return;
               }

               var6 = var2.J - this.S.J * 465603579 + this.S.Q * 583010427;
               if (var6 > this.S.Q * 583010427 + this.S.Q * 583010427) {
                  var6 = this.S.Q * 583010427 + this.S.Q * 583010427;
               } else if (var6 < 0) {
                  return;
               }

               int var15 = var2.G - this.S.z * -804213305 + this.S.Q * 583010427;
               if (var15 < 0) {
                  var15 = 0;
               } else if (var15 > this.S.Q * 583010427 + this.S.Q * 583010427) {
                  return;
               }

               int var16 = var2.D - this.S.z * -804213305 + this.S.Q * 583010427;
               if (var16 > this.S.Q * 583010427 + this.S.Q * 583010427) {
                  var16 = this.S.Q * 583010427 + this.S.Q * 583010427;
               } else if (var16 < 0) {
                  return;
               }

               boolean var9 = false;

               label211:
               for(int var10 = var15; var10 <= var16; ++var10) {
                  for(int var11 = var5; var11 <= var6; ++var11) {
                     if (this.S.d[var10][var11]) {
                        var9 = true;
                        break label211;
                     }
                  }
               }

               if (var9 && this.method4361(var2, 0) && this.method4361(var2, 1) && this.method4361(var2, 2) && this.method4361(var2, 3)) {
                  this.M[this.L++] = var2;
               }
            }
         }
      } else {
         var4 = var2.G - this.S.z * -804213305 + this.S.Q * 583010427;
         if (var4 >= 0 && var4 <= this.S.Q * 583010427 + this.S.Q * 583010427) {
            var5 = var2.B - this.S.J * 465603579 + this.S.Q * 583010427;
            if (var5 >= 0 && var5 <= this.S.Q * 583010427 + this.S.Q * 583010427 && this.S.d[var4][var5]) {
               float var13 = (float)(this.S.T * -343859235 - var2.S[0]);
               if (var13 < 0.0F) {
                  var13 *= -1.0F;
               }

               float var14 = (float)(this.S.U * -1526003751 - var2.E[0]);
               if (var14 < 0.0F) {
                  var14 *= -1.0F;
               }

               if ((var13 >= (float)this.method4361 || var14 >= (float)this.method4361) && this.method4361(var2, 0) && this.method4361(var2, 1) && this.method4361(var2, 2) && this.method4361(var2, 3)) {
                  this.M[this.L++] = var2;
               }
            }
         }
      }

   }

   public void I(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      this.A[this.J++] = new DP(this.S, var1, var2, var3, var4, var4, var3, var7, var8, var8, var7, var5, var5, var6, var6);
   }

   GP(AP var1) {
      this.method4361 = var1.P * 1828905535;
      this.U = var1.P * 1828905535;
      this.S = var1;
      this.A = new DP[535];
      this.J = 0;
      this.K = new DP[2045];
      this.E = 0;
      this.Q = new DP[1027];
      this.H = 0;
      this.M = new DP[1045];
      this.L = 0;
      this.method5060 = new int[this.S.Y * 1678382205][this.S.A * 1988988347 + 1][this.S.i * 1340714547 + 1];
      this.R = false;
      if (this.S.Z instanceof ja) {
         this.F = false;
      } else {
         this.F = true;
      }

      if (this.F) {
         this.arraycopy = new EP(this);
      }

   }

   boolean I(int var1, int var2, int var3) {
      if (this.F && this.Z) {
         if (this.arraycopy.Z < 102) {
            return false;
         } else {
            int var4 = this.method5060[var1][var2][var3];
            if (var4 == -(this.S.W * -847572923)) {
               return false;
            } else if (var4 == this.S.W * -847572923) {
               return true;
            } else if (this.S.G == this.S.M) {
               return false;
            } else {
               int var5 = var2 << this.S.I * -1688804109;
               int var6 = var3 << this.S.I * -1688804109;
               if (this.B(var5 + 1, this.S.G[var1].I(var2, var3, (byte)-88), var6 + 1, var5 + this.S.P * 1828905535 - 1, this.S.G[var1].I(var2 + 1, var3 + 1, (byte)-108), var6 + this.S.P * 1828905535 - 1, var5 + 1, this.S.G[var1].I(var2, var3 + 1, (byte)-91), var6 + this.S.P * 1828905535 - 1) && this.B(var5 + 1, this.S.G[var1].I(var2, var3, (byte)-42), var6 + 1, var5 + this.S.P * 1828905535 - 1, this.S.G[var1].I(var2 + 1, var3, (byte)-46), var6 + 1, var5 + this.S.P * 1828905535 - 1, this.S.G[var1].I(var2 + 1, var3 + 1, (byte)-12), var6 + this.S.P * 1828905535 - 1)) {
                  this.method5060[var1][var2][var3] = this.S.W * -847572923;
                  return true;
               } else {
                  this.method5060[var1][var2][var3] = -(this.S.W * -847572923);
                  return false;
               }
            }
         }
      } else {
         return false;
      }
   }

   boolean I(NR var1, int var2, int var3, int var4) {
      if (this.F && this.Z) {
         if (this.arraycopy.Z < 102) {
            return false;
         } else if (!this.I(var2, var3, var4)) {
            return false;
         } else {
            int var5 = var3 << this.S.I * -1688804109;
            int var6 = var4 << this.S.I * -1688804109;
            int var7 = this.S.G[var2].I(var3, var4, (byte)-91) - 1;
            int var8 = var7 + var1.method4361(1951240662);
            if (var1.W == 1) {
               if (!this.B(var5, var7, var6, var5, var8, var6, var5, var8, var6 + this.S.P * 1828905535)) {
                  return false;
               } else {
                  return this.B(var5, var7, var6, var5, var8, var6 + this.S.P * 1828905535, var5, var7, var6 + this.S.P * 1828905535);
               }
            } else if (var1.W == 2) {
               if (!this.B(var5, var7, var6 + this.S.P * 1828905535, var5 + this.S.P * 1828905535, var8, var6 + this.S.P * 1828905535, var5, var8, var6 + this.S.P * 1828905535)) {
                  return false;
               } else {
                  return this.B(var5, var7, var6 + this.S.P * 1828905535, var5 + this.S.P * 1828905535, var7, var6 + this.S.P * 1828905535, var5 + this.S.P * 1828905535, var8, var6 + this.S.P * 1828905535);
               }
            } else if (var1.W == 4) {
               if (!this.B(var5 + this.S.P * 1828905535, var7, var6, var5 + this.S.P * 1828905535, var8, var6, var5 + this.S.P * 1828905535, var8, var6 + this.S.P * 1828905535)) {
                  return false;
               } else {
                  return this.B(var5 + this.S.P * 1828905535, var7, var6, var5 + this.S.P * 1828905535, var8, var6 + this.S.P * 1828905535, var5 + this.S.P * 1828905535, var7, var6 + this.S.P * 1828905535);
               }
            } else if (var1.W == 8) {
               if (!this.B(var5, var7, var6, var5 + this.S.P * 1828905535, var8, var6, var5, var8, var6)) {
                  return false;
               } else {
                  return this.B(var5, var7, var6, var5 + this.S.P * 1828905535, var7, var6, var5 + this.S.P * 1828905535, var8, var6);
               }
            } else if (var1.W == 16) {
               return this.method5060(var5, var7, var6 + this.S.X * 394962841, this.S.X * 394962841, var8, this.S.X * 394962841);
            } else if (var1.W == 32) {
               return this.method5060(var5 + this.S.X * 394962841, var7, var6 + this.S.X * 394962841, this.S.X * 394962841, var8, this.S.X * 394962841);
            } else if (var1.W == 64) {
               return this.method5060(var5 + this.S.X * 394962841, var7, var6, this.S.X * 394962841, var8, this.S.X * 394962841);
            } else if (var1.W == 128) {
               return this.method5060(var5, var7, var6, this.S.X * 394962841, var8, this.S.X * 394962841);
            } else {
               return true;
            }
         }
      } else {
         return false;
      }
   }

   boolean Z(int var1, int var2, int var3, int var4) {
      if (this.F && this.Z) {
         if (this.arraycopy.Z < 102) {
            return false;
         } else if (!this.I(var1, var2, var3)) {
            return false;
         } else {
            int var5 = var2 << this.S.I * -1688804109;
            int var6 = var3 << this.S.I * -1688804109;
            return this.method5060(var5, this.S.G[var1].I(var2, var3, (byte)-113), var6, this.S.P * 1828905535, var4, this.S.P * 1828905535);
         }
      } else {
         return false;
      }
   }

   boolean I(int var1, int var2, int var3, int var4, int var5, HP var6) {
      if (this.F && this.Z) {
         if (this.arraycopy.Z < 102) {
            return false;
         } else if (var2 == var3 && var4 == var5) {
            if (!this.I(var1, var2, var4)) {
               return false;
            } else {
               return this.arraycopy(var6);
            }
         } else {
            for(int var7 = var2; var7 <= var3; ++var7) {
               for(int var8 = var4; var8 <= var5; ++var8) {
                  if (this.method5060[var1][var7][var8] == -(this.S.W * -847572923)) {
                     return false;
                  }
               }
            }

            if (!this.arraycopy(var6)) {
               return false;
            } else {
               return true;
            }
         }
      } else {
         return false;
      }
   }

   final boolean arraycopy(HP var1) {
      return var1 == null ? false : this.method5060(var1.D, var1.J, var1.S, var1.A - var1.D, var1.Z - var1.J, var1.E - var1.S);
   }

   boolean method4361(DP var1, int var2) {
      if (!this.B(var1.S[var2], var1.A[var2], var1.E[var2])) {
         return false;
      } else {
         var1.I[var2] = (short)((int)this.V[0]);
         var1.H[var2] = (short)((int)this.V[1]);
         var1.K[var2] = (short)((int)this.V[2]);
         return true;
      }
   }

   final boolean method5060(int var1, int var2, int var3, int var4, int var5, int var6) {
      int var7 = var1 + var4;
      int var8 = var2 + var5;
      int var9 = var3 + var6;
      if (!this.B(var1, var8, var3, var7, var8, var9, var1, var8, var9)) {
         return false;
      } else if (!this.B(var1, var8, var3, var7, var8, var3, var7, var8, var9)) {
         return false;
      } else {
         if (var1 < this.S.T * -343859235) {
            if (!this.B(var1, var2, var9, var1, var8, var3, var1, var8, var9)) {
               return false;
            }

            if (!this.B(var1, var2, var9, var1, var2, var3, var1, var8, var3)) {
               return false;
            }
         } else {
            if (!this.B(var7, var2, var9, var7, var8, var3, var7, var8, var9)) {
               return false;
            }

            if (!this.B(var7, var2, var9, var7, var2, var3, var7, var8, var3)) {
               return false;
            }
         }

         if (var3 < this.S.U * -1526003751) {
            if (!this.B(var1, var2, var3, var7, var8, var3, var1, var8, var3)) {
               return false;
            }

            if (!this.B(var1, var2, var3, var7, var2, var3, var7, var8, var3)) {
               return false;
            }
         } else {
            if (!this.B(var1, var2, var9, var7, var8, var9, var1, var8, var9)) {
               return false;
            }

            if (!this.B(var1, var2, var9, var7, var2, var9, var7, var8, var9)) {
               return false;
            }
         }

         return true;
      }
   }

   final boolean B(int var1, int var2, int var3) {
      W.method5060((float)var1, (float)var2, (float)var3, this.V);
      if (this.V[2] < 50.0F) {
         return false;
      } else {
         this.V[0] /= 3.0F;
         this.V[1] /= 3.0F;
         return true;
      }
   }

   void S() {
      int var1;
      for(var1 = 0; var1 < this.E; ++var1) {
         this.K[var1] = null;
      }

      this.E = 0;

      int var2;
      int var3;
      BP var4;
      for(var1 = 0; var1 < this.S.Y * 1678382205; ++var1) {
         for(var2 = 0; var2 < this.S.A * 1988988347; ++var2) {
            for(var3 = 0; var3 < this.S.i * 1340714547; ++var3) {
               var4 = this.S.E[var1][var3][var2];
               if (var4 != null) {
                  if (var4.E > 0) {
                     var4.E = (short)(var4.E * -1);
                  }

                  if (var4.A > 0) {
                     var4.A = (short)(var4.A * -1);
                  }
               }
            }
         }
      }

      for(var1 = 0; var1 < this.S.Y * 1678382205; ++var1) {
         for(var2 = 0; var2 < this.S.A * 1988988347; ++var2) {
            for(var3 = 0; var3 < this.S.i * 1340714547; ++var3) {
               var4 = this.S.E[var1][var3][var2];
               if (var4 != null) {
                  boolean var5 = this.S.E[0][var3][var2] != null && this.S.E[0][var3][var2].I != null;
                  int var6;
                  int var7;
                  int var9;
                  BP var10;
                  int var11;
                  int var12;
                  int var13;
                  int var14;
                  int var15;
                  int var16;
                  int var17;
                  int var18;
                  int var19;
                  int var20;
                  int var21;
                  if (var4.E < 0) {
                     var6 = var2;
                     var7 = var2;
                     var9 = var1;
                     var10 = this.S.E[var1][var3][var2 - 1];

                     for(var11 = this.S.K[var1].I(var3, var2, (byte)-58); var6 > 0 && var10 != null && var10.E < 0 && var10.E == var4.E && var10.G == var4.G && var11 == this.S.K[var1].I(var3, var6 - 1, (byte)-78) && (var6 - 1 <= 0 || var11 == this.S.K[var1].I(var3, var6 - 2, (byte)-92)); var10 = this.S.E[var1][var3][var6 - 1]) {
                        --var6;
                     }

                     for(var10 = this.S.E[var1][var3][var2 + 1]; var7 < this.S.i * 1340714547 && var10 != null && var10.E < 0 && var10.E == var4.E && var10.G == var4.G && var11 == this.S.K[var1].I(var3, var7 + 1, (byte)-51) && (var7 + 1 >= this.S.i * 1340714547 || var11 == this.S.K[var1].I(var3, var7 + 2, (byte)-31)); var10 = this.S.E[var1][var3][var7 + 1]) {
                        ++var7;
                     }

                     var12 = var1 - var1 + 1;
                     var13 = this.S.K[var5 ? var1 + 1 : var1].I(var3, var6, (byte)-52);
                     var14 = var13 + var4.E * var12;
                     var15 = this.S.K[var5 ? var1 + 1 : var1].I(var3, var7 + 1, (byte)-12);
                     var16 = var15 + var4.E * var12;
                     var17 = var3 << this.S.I * -1688804109;
                     var18 = var6 << this.S.I * -1688804109;
                     var19 = (var7 << this.S.I * -1688804109) + this.S.P * 1828905535;
                     this.K[this.E++] = new DP(this.S, 1, var1, var17 + var4.G, var17 + var4.G, var17 + var4.G, var17 + var4.G, var13, var15, var16, var14, var18, var19, var19, var18);

                     for(var20 = var1; var20 <= var9; ++var20) {
                        for(var21 = var6; var21 <= var7; ++var21) {
                           this.S.E[var20][var3][var21].E = (short)(this.S.E[var20][var3][var21].E * -1);
                        }
                     }
                  }

                  if (var4.A < 0) {
                     var6 = var3;
                     var7 = var3;
                     var9 = var1;
                     var10 = this.S.E[var1][var3 - 1][var2];

                     for(var11 = this.S.K[var1].I(var3, var2, (byte)-77); var6 > 0 && var10 != null && var10.A < 0 && var10.A == var4.A && var10.K == var4.K && var11 == this.S.K[var1].I(var6 - 1, var2, (byte)-104) && (var6 - 1 <= 0 || var11 == this.S.K[var1].I(var6 - 2, var2, (byte)-71)); var10 = this.S.E[var1][var6 - 1][var2]) {
                        --var6;
                     }

                     for(var10 = this.S.E[var1][var3 + 1][var2]; var7 < this.S.A * 1988988347 && var10 != null && var10.A < 0 && var10.A == var4.A && var10.K == var4.K && var11 == this.S.K[var1].I(var7 + 1, var2, (byte)-31) && (var7 + 1 >= this.S.A * 1988988347 || var11 == this.S.K[var1].I(var7 + 2, var2, (byte)-27)); var10 = this.S.E[var1][var7 + 1][var2]) {
                        ++var7;
                     }

                     var12 = var1 - var1 + 1;
                     var13 = this.S.K[var5 ? var1 + 1 : var1].I(var6, var2, (byte)-116);
                     var14 = var13 + var4.A * var12;
                     var15 = this.S.K[var5 ? var1 + 1 : var1].I(var7 + 1, var2, (byte)-68);
                     var16 = var15 + var4.A * var12;
                     var17 = var6 << this.S.I * -1688804109;
                     var18 = (var7 << this.S.I * -1688804109) + this.S.P * 1828905535;
                     var19 = var2 << this.S.I * -1688804109;
                     this.K[this.E++] = new DP(this.S, 2, var1, var17, var18, var18, var17, var13, var15, var16, var14, var19 + var4.K, var19 + var4.K, var19 + var4.K, var19 + var4.K);

                     for(var20 = var1; var20 <= var9; ++var20) {
                        for(var21 = var6; var21 <= var7; ++var21) {
                           this.S.E[var20][var21][var2].A = (short)(this.S.E[var20][var21][var2].A * -1);
                        }
                     }
                  }
               }
            }
         }
      }

      this.R = true;
   }

   public void I() {
      this.S();
   }

   void I(GSI var1, int var2) {
      W = var1;
      if (this.F && this.Z) {
         if (this.i) {
            this.S.C.I(1748002530);
         }

         W.I(this.G);
         if (this.X != (int)((float)this.G[0] / 3.0F) || this.Y != (int)((float)this.G[1] / 3.0F)) {
            this.X = (int)((float)this.G[0] / 3.0F);
            this.Y = (int)((float)this.G[1] / 3.0F);
            this.T = new int[this.X * this.Y];
         }

         this.L = 0;

         int var3;
         for(var3 = 0; var3 < this.J; ++var3) {
            this.S(W, this.A[var3], var2);
         }

         for(var3 = 0; var3 < this.E; ++var3) {
            this.S(W, this.K[var3], var2);
         }

         for(var3 = 0; var3 < this.H; ++var3) {
            this.S(W, this.Q[var3], var2);
         }

         this.arraycopy.Z = 0;
         if (this.L > 0) {
            var3 = this.T.length;
            int var4 = var3 - var3 & 7;

            int var5;
            for(var5 = 0; var5 < var4; this.T[var5++] = Integer.MAX_VALUE) {
               this.T[var5++] = Integer.MAX_VALUE;
               this.T[var5++] = Integer.MAX_VALUE;
               this.T[var5++] = Integer.MAX_VALUE;
               this.T[var5++] = Integer.MAX_VALUE;
               this.T[var5++] = Integer.MAX_VALUE;
               this.T[var5++] = Integer.MAX_VALUE;
               this.T[var5++] = Integer.MAX_VALUE;
            }

            while(var5 < var3) {
               this.T[var5++] = Integer.MAX_VALUE;
            }

            this.arraycopy.J = 1;

            for(int var6 = 0; var6 < this.L; ++var6) {
               DP var7 = this.M[var6];
               this.arraycopy.I(var7.H[0], var7.H[1], var7.H[3], var7.I[0], var7.I[1], var7.I[3], var7.K[0], var7.K[1], var7.K[3]);
               this.arraycopy.I(var7.H[1], var7.H[2], var7.H[3], var7.I[1], var7.I[2], var7.I[3], var7.K[1], var7.K[2], var7.K[3]);
            }

            this.arraycopy.J = 2;
         }

         if (this.i) {
            this.S.C.I(140602310);
         }
      } else {
         this.L = 0;
      }

   }
}
