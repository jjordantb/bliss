public class BP {
   public BP I;
   public XO Z;
   public NR C;
   public NR B;
   public GR D;
   public GR F;
   public SR J;
   LR S;
   short A;
   short E;
   short G;
   public byte H;
   short K;

   public BP(int var1) {
      this.H = (byte)var1;
   }

   static void I(int var0) {
      try {
         if (LT.Z == null) {
            LT.Z = new int[65536];
            double var1 = 0.7D + (Math.random() * 0.03D - 0.015D);
            int var3 = 0;

            for(int var4 = 0; var4 < 512; ++var4) {
               float var5 = 360.0F * ((float)(var4 >> 3) / 64.0F + 0.0078125F);
               float var6 = 0.0625F + (float)(var4 & 7) / 8.0F;

               for(int var7 = 0; var7 < 128; ++var7) {
                  float var8 = (float)var7 / 128.0F;
                  float var9 = 0.0F;
                  float var10 = 0.0F;
                  float var11 = 0.0F;
                  float var12 = var5 / 60.0F;
                  int var13 = (int)var12;
                  int var14 = var13 % 6;
                  float var15 = var12 - (float)var13;
                  float var16 = (1.0F - var6) * var8;
                  float var17 = (1.0F - var15 * var6) * var8;
                  float var18 = (1.0F - (1.0F - var15) * var6) * var8;
                  if (var14 == 0) {
                     var9 = var8;
                     var10 = var18;
                     var11 = var16;
                  } else if (var14 == 1) {
                     var9 = var17;
                     var10 = var8;
                     var11 = var16;
                  } else if (2 == var14) {
                     var9 = var16;
                     var10 = var8;
                     var11 = var18;
                  } else if (3 == var14) {
                     var9 = var16;
                     var10 = var17;
                     var11 = var8;
                  } else if (4 == var14) {
                     var9 = var18;
                     var10 = var16;
                     var11 = var8;
                  } else if (5 == var14) {
                     var9 = var8;
                     var10 = var16;
                     var11 = var17;
                  }

                  var9 = (float)Math.pow((double)var9, var1);
                  var10 = (float)Math.pow((double)var10, var1);
                  var11 = (float)Math.pow((double)var11, var1);
                  int var19 = (int)(256.0F * var9);
                  int var20 = (int)(var10 * 256.0F);
                  int var21 = (int)(256.0F * var11);
                  int var22 = var21 + (var19 << 16) + -16777216 + (var20 << 8);
                  LT.Z[var3++] = var22;
               }
            }

         }
      } catch (RuntimeException var23) {
         throw DQ.I(var23, "np.b(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         FDI.I(var3, var4, var0, (byte)65);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "np.ju(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         var0.A -= 1938723502;
         var0.J -= -783761378;
         String var2 = (String)var0.S[var0.A * -203050393];
         int var3 = var0.H[681479919 * var0.J];
         int var4 = var0.H[681479919 * var0.J + 1];
         String var5 = (String)var0.S[-203050393 * var0.A + 1];
         PQ.I(var2, var3 == 1, var4, var5, 37914209);
         var0.H[(var0.J += -391880689) * 681479919 - 1] = CQ.L * 367592105;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "np.abb(" + ')');
      }
   }

   static final void I(OU var0, short var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.f.method5612(var2, 1352882135);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "np.aoa(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)24);
         X var4 = IU.F[var2 >> 16];
         RD.I(var3, var4, true, 1, var0, 1939929714);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "np.hy(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         var0.K -= -1365138610;
         if (var0.Q[1685767703 * var0.K] == var0.Q[1 + var0.K * 1685767703]) {
            var0.i += 286750741 * var0.X[var0.i * 1883543357];
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "np.bx(" + ')');
      }
   }

   static void Z(int var0) {
      try {
         PK var1 = GB.I(MEI.tI, XEI.eI.Z, (byte)103);
         var1.J.F(VB.I((byte)-123));
         var1.J.Z(GY.Z * -2110394505, 16711935);
         var1.J.Z(JM.J * -1111710645, 16711935);
         var1.J.F(FW.J.G.Z(-196354448));
         XEI.eI.I(var1, (byte)-93);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "np.gp(" + ')');
      }
   }
}
