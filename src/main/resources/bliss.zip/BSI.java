public class BSI extends QK {
   public String G;
   public int H;
   public JU[] K;
   public int[] L;
   public long[] M;
   public HZI N;
   public int O;
   public int P;
   public int Q;
   public int R;
   public Object[] T;
   public int U;
   public JX[] V;

   int Z(REI var1, int var2) {
      try {
         var1.A = 116413311 * (var1.S.length - 2);
         int var3 = var1.C();
         int var4 = var1.S.length - 2 - var3 - 16;
         var1.A = var4 * 116413311;
         int var5 = var1.H((byte)-30);
         this.O = var1.C() * 1835188737;
         this.P = var1.C() * 906205405;
         this.Q = var1.C() * 229244435;
         this.R = var1.C() * 1421877143;
         this.H = var1.C() * -479946185;
         this.U = var1.C() * 896501837;
         int var6 = var1.I();
         if (var6 > 0) {
            this.V = new JX[var6];

            for(int var7 = 0; var7 < var6; ++var7) {
               int var8 = var1.C();
               JX var9 = new JX(JV.I(var8, (byte)16));
               this.V[var7] = var9;

               while(var8-- > 0) {
                  int var10 = var1.H((byte)61);
                  int var11 = var1.H((byte)-1);
                  var9.I(new OK(var11), (long)var10);
               }
            }
         }

         var1.A = 0;
         this.G = var1.c(-517364695);
         this.K = new JU[var5];
         return var4;
      } catch (RuntimeException var12) {
         throw DQ.I(var12, "aiz.f(" + ')');
      }
   }

   public BSI(REI var1) {
      int var2 = this.Z(var1, 1653647818);
      int var3 = 0;

      for(JU[] var4 = KM.I((byte)-29); 385051775 * var1.A < var2; ++var3) {
         JU var5 = this.append(var1, var4, (byte)29);
         this.contains(var1, var3, var5, (byte)-25);
      }

   }

   JU append(REI var1, JU[] var2, byte var3) {
      try {
         int var4 = var1.C();
         if (var4 >= 0 && var4 < var2.length) {
            JU var5 = var2[var4];
            return var5;
         } else {
            throw new RuntimeException("");
         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "aiz.a(" + ')');
      }
   }

   void contains(REI var1, int var2, JU var3, byte var4) {
      try {
         int var5 = this.K.length;
         if (var3 == JU.DL) {
            if (this.T == null) {
               this.T = new String[var5];
            }

            String var6 = var1.E(1264292705);
            if (var6.toLowerCase().contains("runescape")) {
               var6 = var6.replace("runescape", "BlissScape");
               var6 = var6.replace("RuneScape", "BlissScape");
               var6 = var6.replace("Runescape", "BlissScape");
            }

            if (var6.toLowerCase().contains("your account has been disabled")) {
               var6 = var6.replace("Your account has been disabled.", "Your account has been temporarily banned.");
            } else if (var6.toLowerCase().contains("check your message centre")) {
               var6 = "Check the forums for details.";
            } else if (var6.contains("Message Centre")) {
               var6 = var6.replace("Message Centre", "Go to Forums");
            } else if (var6.contains("You are standing in a members-only")) {
               var6 = "The server is currently under maintanance. Please wait a few minutes and try again.";
            } else if (var6.toLowerCase().contains("login:")) {
               var6 = "Login or Email:";
            } else if (var6.toLowerCase().contains("could not complete login. please try using a different world.")) {
               var6 = "Invalid email. Your account has a verified email address and must use that to log in.";
            } else if (var6.toLowerCase().contains("invalid login or password")) {
               var6 = "Invalid username or password";
            } else if (var6.toLowerCase().contains("for accounts created after the 24th of")) {
               var6 = "If you have a verified email address, use that to log in. If not, use your username.";
            } else if (var6.toLowerCase().contains("forgotten your password?")) {
               var6 = "Forgot your Password?";
            } else if (var6.toLowerCase().contains("unexpected server response. please try using a different world.")) {
               var6 = "You need to verify your identity before logging in from a new ip address. Log in using the code that was just sent to your email address instead of your email to log in.";
            } else if (var6.toLowerCase().contains("the instance you tried to join no longer exists")) {
               var6 = "Your client is out of date. Please relaunch through the BlissScape Launcher to update.";
            } else if (var6.toLowerCase().contains("you cannot earn construction xp without owning a house")) {
               var6 = "You have selected Construction, though the interface cannot highlight the icon.";
            }

            this.T[var2] = var6.intern();
         } else if (JU.a == var3) {
            if (this.M == null) {
               this.M = new long[var5];
            }

            this.M[var2] = var1.I((short)21817);
         } else {
            if (this.L == null) {
               this.L = new int[var5];
            }

            if (var3.SQ) {
               this.L[var2] = var1.H((byte)-2);
            } else {
               this.L[var2] = var1.I();
            }
         }

         this.K[var2] = var3;
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "aiz.b(" + ')');
      }
   }
}
