public class FF {
   static float[] I = new float[16384];
   static float[] Z = new float[16384];

   static {
      double var0 = 3.834951969714103E-4D;

      for(int var2 = 0; var2 < 16384; ++var2) {
         I[var2] = (float)Math.sin((double)var2 * var0);
         Z[var2] = (float)Math.cos((double)var2 * var0);
      }

   }

   FF() throws Throwable {
      throw new Error();
   }
}
