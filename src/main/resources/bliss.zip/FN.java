import java.util.Iterator;
import java.util.LinkedList;

public class FN {
   int B;
   int[] S;
   int add;
   int[] append;
   static int I = 0;
   LinkedList hasNext;
   public static WR Z;

   public FN(GSI var1, REI var2, int var3) {
      this.add = -1657032745 * var3;
      this.B = var2.X(590991010) * -1823687737;
      this.S = new int[-755722761 * this.B];
      this.append = new int[this.B * -755722761];
      int var4 = var2.C();
      int var5 = var2.C();

      for(int var6 = 0; var6 < this.B * -755722761; ++var6) {
         this.S[var6] = var4 + var2.S(-12558881);
         this.append[var6] = var5 + var2.S(-12558881);
      }

      this.I(var1, 1723870683);
   }

   public void I(AP var1, int var2) {
      try {
         if (var1 != null && this.B * -755722761 > 0) {
            this.B(var1, 1331512364);
            Iterator var3 = this.hasNext.iterator();

            while(var3.hasNext()) {
               DR var4 = (DR)var3.next();
               var1.I(var4, false, (byte)0);
            }
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ml.f(" + ')');
      }
   }

   public void Z(AP var1, int var2) {
      try {
         if (var1 != null && this.hasNext != null) {
            Iterator var3 = this.hasNext.iterator();

            while(var3.hasNext()) {
               DR var4 = (DR)var3.next();
               var1.I(var4.K, var4.R, var4.O, (XSI)(new GO(var4)), (short)-25645);
            }
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ml.b(" + ')');
      }
   }

   void B(AP var1, int var2) {
      try {
         this.hasNext = new LinkedList();
         LJ var3 = XEI.mI.M(1102233653);
         XP var4 = XEI.mI.I(681479919);
         XP var5 = new XP(1855729883 * EJI.Z, this.S[0], this.append[0]);

         for(int var6 = 1; var6 < this.B * -755722761; ++var6) {
            XP var7 = new XP(1855729883 * EJI.Z, this.S[var6], this.append[var6]);

            while(var5.I * -1760580017 != var7.I * -1760580017 || var7.Z * 283514611 != 283514611 * var5.Z) {
               if (-1760580017 * var5.I < var7.I * -1760580017) {
                  var5.I += 2061281455;
               } else if (-1760580017 * var5.I > var7.I * -1760580017) {
                  var5.I -= 2061281455;
               }

               if (var5.Z * 283514611 < var7.Z * 283514611) {
                  var5.Z += 1901982267;
               } else if (283514611 * var5.Z > var7.Z * 283514611) {
                  var5.Z -= 1901982267;
               }

               int var8 = 1855729883 * EJI.Z;
               int var9 = var5.I * -1760580017 - -1760580017 * var4.I;
               int var10 = var5.Z * 283514611 - var4.Z * 283514611;
               if (var9 >= 0 && var9 < var1.A * 1988988347 && var10 >= 0 && var10 < var1.i * 1340714547) {
                  int var11 = 256 + (var9 << 9);
                  int var12 = (var10 << 9) + 256;
                  if (var3.I(var9, var10, 1621681169)) {
                     ++var8;
                  }

                  this.hasNext.add(new DR(var1, this, EJI.Z * 1855729883, var8, var11, NQ.I(var11, var12, 1855729883 * EJI.Z, -969266952), var12));
               }
            }

            var5 = var7;
         }

      } catch (RuntimeException var13) {
         throw DQ.I(var13, "ml.p(" + ')');
      }
   }

   UT I(GSI var1, int var2) {
      try {
         MBI var3 = MBI.I((KJ)XP.B, -1002982425 * this.add, (int)0);
         if (var3 == null) {
            return null;
         } else {
            if (var3.P < 13) {
               var3.I(2);
            }

            return var1.method5037(var3, 2048, I * 598483091, 64, 768);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ml.a(" + ')');
      }
   }

   public static JA[] I(int var0) {
      try {
         return new JA[]{JA.F, JA.C, JA.A, JA.Z, JA.I, JA.S, JA.J, JA.B};
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "ml.a(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)16);
         X var4 = IU.F[var2 >> 16];
         SJ.I(var3, var4, var0, -1468199503);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ml.jt(" + ')');
      }
   }

   public static boolean I(int var0, int var1) {
      try {
         return 14 == var0 || 15 == var0 || var0 == 18 || var0 == 16;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ml.fv(" + ')');
      }
   }
}
