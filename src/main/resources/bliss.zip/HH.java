public class HH extends YG {
   static boolean Q = false;
   static int R = 32768;
   int T = 1905754112;

   void append(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.T = (var2.C() << 4) * 2104812335;
         break;
      case 1:
         this.N = var2.I() == 1;
      }

   }

   void I(int var1, REI var2, byte var3) {
      try {
         switch(var1) {
         case 0:
            this.T = (var2.C() << 4) * 2104812335;
            break;
         case 1:
            this.N = var2.I() == 1;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ahh.r(" + ')');
      }
   }

   int[][] I(int var1, byte var2) {
      try {
         int[][] var3 = this.L.I(var1, (byte)67);
         if (this.L.I) {
            int[] var4 = this.I(1, var1, -1887337990);
            int[] var5 = this.I(2, var1, -1887337990);
            int[] var6 = var3[0];
            int[] var7 = var3[1];
            int[] var8 = var3[2];

            for(int var9 = 0; var9 < WJ.C * -1474554145; ++var9) {
               int var10 = 255 * var4[var9] >> 12 & 255;
               int var11 = var5[var9] * -1817623601 * this.T >> 12;
               int var12 = WJ.E[var10] * var11 >> 12;
               int var13 = WJ.S[var10] * var11 >> 12;
               int var14 = var9 + (var12 >> 12) & -901777799 * WJ.I;
               int var15 = (var13 >> 12) + var1 & WJ.F * -289063255;
               int[][] var16 = this.I(0, var15, (byte)8);
               var6[var9] = var16[0][var14];
               var7[var9] = var16[1][var14];
               var8[var9] = var16[2][var14];
            }
         }

         return var3;
      } catch (RuntimeException var17) {
         throw DQ.I(var17, "ahh.k(" + ')');
      }
   }

   void B(int var1) {
      try {
         WJ.I((byte)90);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ahh.x(" + ')');
      }
   }

   int[] toString(int var1) {
      int[] var2 = this.P.I(var1, 787804307);
      if (this.P.D) {
         int[] var3 = this.I(1, var1, -1887337990);
         int[] var4 = this.I(2, var1, -1887337990);

         for(int var5 = 0; var5 < WJ.C * -1474554145; ++var5) {
            int var6 = var3[var5] >> 4 & 255;
            int var7 = var4[var5] * this.T * -1817623601 >> 12;
            int var8 = var7 * WJ.E[var6] >> 12;
            int var9 = WJ.S[var6] * var7 >> 12;
            int var10 = (var8 >> 12) + var5 & -901777799 * WJ.I;
            int var11 = var1 + (var9 >> 12) & -289063255 * WJ.F;
            int[] var12 = this.I(0, var11, -1887337990);
            var2[var5] = var12[var10];
         }
      }

      return var2;
   }

   void toString(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.T = (var2.C() << 4) * 2104812335;
         break;
      case 1:
         this.N = var2.I() == 1;
      }

   }

   int[] D(int var1) {
      int[] var2 = this.P.I(var1, 1675766635);
      if (this.P.D) {
         int[] var3 = this.I(1, var1, -1887337990);
         int[] var4 = this.I(2, var1, -1887337990);

         for(int var5 = 0; var5 < WJ.C * -1474554145; ++var5) {
            int var6 = var3[var5] >> 4 & 255;
            int var7 = var4[var5] * this.T * -1817623601 >> 12;
            int var8 = var7 * WJ.E[var6] >> 12;
            int var9 = WJ.S[var6] * var7 >> 12;
            int var10 = (var8 >> 12) + var5 & -901777799 * WJ.I;
            int var11 = var1 + (var9 >> 12) & -289063255 * WJ.F;
            int[] var12 = this.I(0, var11, -1887337990);
            var2[var5] = var12[var10];
         }
      }

      return var2;
   }

   void I() {
      WJ.I((byte)11);
   }

   void Z() {
      WJ.I((byte)-98);
   }

   int[][] F(int var1) {
      int[][] var2 = this.L.I(var1, (byte)35);
      if (this.L.I) {
         int[] var3 = this.I(1, var1, -1887337990);
         int[] var4 = this.I(2, var1, -1887337990);
         int[] var5 = var2[0];
         int[] var6 = var2[1];
         int[] var7 = var2[2];

         for(int var8 = 0; var8 < WJ.C * -1474554145; ++var8) {
            int var9 = 255 * var3[var8] >> 12 & 255;
            int var10 = var4[var8] * -1817623601 * this.T >> 12;
            int var11 = WJ.E[var9] * var10 >> 12;
            int var12 = WJ.S[var9] * var10 >> 12;
            int var13 = var8 + (var11 >> 12) & -901777799 * WJ.I;
            int var14 = (var12 >> 12) + var1 & WJ.F * -289063255;
            int[][] var15 = this.I(0, var14, (byte)8);
            var5[var8] = var15[0][var13];
            var6[var8] = var15[1][var13];
            var7[var8] = var15[2][var13];
         }
      }

      return var2;
   }

   int[] Z(int var1, int var2) {
      try {
         int[] var3 = this.P.I(var1, 868986810);
         if (this.P.D) {
            int[] var4 = this.I(1, var1, -1887337990);
            int[] var5 = this.I(2, var1, -1887337990);

            for(int var6 = 0; var6 < WJ.C * -1474554145; ++var6) {
               int var7 = var4[var6] >> 4 & 255;
               int var8 = var5[var6] * this.T * -1817623601 >> 12;
               int var9 = var8 * WJ.E[var7] >> 12;
               int var10 = WJ.S[var7] * var8 >> 12;
               int var11 = (var9 >> 12) + var6 & -901777799 * WJ.I;
               int var12 = var1 + (var10 >> 12) & -289063255 * WJ.F;
               int[] var13 = this.I(0, var12, -1887337990);
               var3[var6] = var13[var11];
            }
         }

         return var3;
      } catch (RuntimeException var14) {
         throw DQ.I(var14, "ahh.i(" + ')');
      }
   }

   void C() {
      WJ.I((byte)46);
   }

   public HH() {
      super(3, false);
   }

   int[][] J(int var1) {
      int[][] var2 = this.L.I(var1, (byte)10);
      if (this.L.I) {
         int[] var3 = this.I(1, var1, -1887337990);
         int[] var4 = this.I(2, var1, -1887337990);
         int[] var5 = var2[0];
         int[] var6 = var2[1];
         int[] var7 = var2[2];

         for(int var8 = 0; var8 < WJ.C * -1474554145; ++var8) {
            int var9 = 255 * var3[var8] >> 12 & 255;
            int var10 = var4[var8] * -1817623601 * this.T >> 12;
            int var11 = WJ.E[var9] * var10 >> 12;
            int var12 = WJ.S[var9] * var10 >> 12;
            int var13 = var8 + (var11 >> 12) & -901777799 * WJ.I;
            int var14 = (var12 >> 12) + var1 & WJ.F * -289063255;
            int[][] var15 = this.I(0, var14, (byte)8);
            var5[var8] = var15[0][var13];
            var6[var8] = var15[1][var13];
            var7[var8] = var15[2][var13];
         }
      }

      return var2;
   }
}
