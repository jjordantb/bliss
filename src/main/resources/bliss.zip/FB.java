public class FB {
   public static FB I = new FB(1);
   public int Z;
   public static FB C = new FB(4);
   public static FB B = new FB(2);
   public static FB D = new FB(0);
   public static FB F = new FB(3);

   FB(int var1) {
      this.Z = var1;
   }
}
