public class F {
   public int I;
   public int Z = AI.I(-2067769090) * -740789311;
   public int C;
   public String B;
   public String D;
   public String F;
   public String J;
   public int S;
   public int A;
   public String E;

   void I(int var1, int var2, String var3, String var4, String var5, String var6, int var7, String var8, short var9) {
      try {
         this.Z = AI.I(-2067769090) * -740789311;
         this.I = -1698852737 * XEI.kB;
         this.C = var1 * 392659741;
         this.S = var2 * 849125275;
         this.B = var3;
         this.F = var4;
         this.J = var5;
         this.D = var6;
         this.A = var7 * 1644525439;
         this.E = var8;
      } catch (RuntimeException var11) {
         throw DQ.I(var11, "ed.a(" + ')');
      }
   }

   F(int var1, int var2, String var3, String var4, String var5, String var6, int var7, String var8) {
      this.I = XEI.kB * -1698852737;
      this.C = var1 * 392659741;
      this.S = 849125275 * var2;
      this.B = var3;
      this.F = var4;
      this.J = var5;
      this.D = var6;
      this.A = var7 * 1644525439;
      this.E = var8;
   }

   static final void I(OU var0, byte var1) {
      try {
         if (YX.I && WF.O != null) {
            OQ.I(FW.J.J.Z((byte)92), -1, -1, false, 2006169742);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ed.aej(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = 1243777389 * TQ.I;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ed.ahj(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, int var3) {
      try {
         var0.ZI = var2.H[(var2.J -= -391880689) * 681479919] * -1041514725;
         VEI.I(var0, -1371264268);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ed.db(" + ')');
      }
   }
}
