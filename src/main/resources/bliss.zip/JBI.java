import jaggl.OpenGL;

public class JBI extends IBI {
   int F = 0;
   JO aq;
   boolean glBegin = false;
   int glColor3f = 0;
   MJI glColor4ub;
   int glEnd = 0;
   JO glMultiTexCoord2f;
   int glPixelTransferf = 0;
   int glPopMatrix = 0;

   void method671(float var1, float var2, float var3, float var4, float var5, float var6, int var7, QJI var8, int var9, int var10) {
      JO var11 = ((RJI)var8).I;
      float var12;
      float var13;
      float var14;
      float var15;
      if (this.glBegin) {
         var12 = (float)this.method271();
         var13 = (float)this.method626();
         var14 = (var3 - var1) / var12;
         var15 = (var4 - var2) / var12;
         float var16 = (var5 - var1) / var13;
         float var17 = (var6 - var2) / var13;
         float var18 = var16 * (float)this.glEnd;
         float var19 = var17 * (float)this.glEnd;
         float var20 = var14 * (float)this.F;
         float var21 = var15 * (float)this.F;
         float var22 = -var14 * (float)this.glPopMatrix;
         float var23 = -var15 * (float)this.glPopMatrix;
         float var24 = -var16 * (float)this.glPixelTransferf;
         float var25 = -var17 * (float)this.glPixelTransferf;
         var1 = var1 + var20 + var18;
         var2 = var2 + var21 + var19;
         var3 = var3 + var22 + var18;
         var4 = var4 + var23 + var19;
         var5 = var5 + var20 + var24;
         var6 = var6 + var21 + var25;
      }

      var12 = var5 + (var3 - var1);
      var13 = var4 + (var6 - var2);
      this.glMultiTexCoord2f.I((var7 & 1) != 0);
      this.glColor4ub.B();
      this.glColor4ub.I((SN)this.glMultiTexCoord2f);
      this.glColor4ub.I(1);
      this.glColor4ub.C(1);
      this.glColor4ub.I((SN)var11);
      this.glColor4ub.Z(7681, 8448);
      this.glColor4ub.I(0, 34168, 768);
      this.glColor4ub.B(1);
      var14 = var11.L / (float)var11.K;
      var15 = var11.N / (float)var11.H;
      OpenGL.glBegin(7);
      OpenGL.glColor3f(1.0F, 1.0F, 1.0F);
      OpenGL.glMultiTexCoord2f(33984, 0.0F, this.glMultiTexCoord2f.N);
      OpenGL.glMultiTexCoord2f(33985, var14 * (var1 - (float)var9), var11.N - var15 * (var2 - (float)var10));
      OpenGL.glVertex2f(var1, var2);
      OpenGL.glMultiTexCoord2f(33984, 0.0F, 0.0F);
      OpenGL.glMultiTexCoord2f(33985, var14 * (var5 - (float)var9), var11.N - var15 * (var6 - (float)var10));
      OpenGL.glVertex2f(var5, var6);
      OpenGL.glMultiTexCoord2f(33984, this.glMultiTexCoord2f.L, 0.0F);
      OpenGL.glMultiTexCoord2f(33985, var14 * (var12 - (float)var9), var11.N - var15 * (var13 - (float)var10));
      OpenGL.glVertex2f(var12, var13);
      OpenGL.glMultiTexCoord2f(33984, this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
      OpenGL.glMultiTexCoord2f(33985, var14 * (var3 - (float)var9), var11.N - var15 * (var4 - (float)var10));
      OpenGL.glVertex2f(var3, var4);
      OpenGL.glEnd();
      this.glColor4ub.I(0, 5890, 768);
      this.glColor4ub.I(0);
      this.glColor4ub.I((SN)null);
      this.glColor4ub.C(0);
   }

   JBI(MJI var1, int var2, int var3, int var4, int var5) {
      this.glColor4ub = var1;
      this.glMultiTexCoord2f = JO.I(var1, var2, var3, var4, var5);
   }

   JBI(MJI var1, int var2, int var3, int[] var4, int var5, int var6) {
      this.glColor4ub = var1;
      this.glMultiTexCoord2f = JO.I(var1, var2, var3, false, var4, var6, var5);
   }

   public void method621(int var1, int var2, int var3, int var4) {
      this.F = var1;
      this.glEnd = var2;
      this.glPopMatrix = var3;
      this.glPixelTransferf = var4;
      this.glBegin = this.F != 0 || this.glEnd != 0 || this.glPopMatrix != 0 || this.glPixelTransferf != 0;
   }

   public void method622(int[] var1) {
      var1[0] = this.F;
      var1[1] = this.glEnd;
      var1[2] = this.glPopMatrix;
      var1[3] = this.glPixelTransferf;
   }

   public int method623() {
      return this.glMultiTexCoord2f.K;
   }

   public int method626() {
      return this.glMultiTexCoord2f.H + this.glEnd + this.glPixelTransferf;
   }

   public int method625() {
      return this.glMultiTexCoord2f.H;
   }

   public int method272() {
      return this.glMultiTexCoord2f.K + this.F + this.glPopMatrix;
   }

   void method676(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10) {
      float var11;
      float var12;
      if (this.glBegin) {
         var11 = (float)this.method271();
         var12 = (float)this.method626();
         float var13 = (var3 - var1) / var11;
         float var14 = (var4 - var2) / var11;
         float var15 = (var5 - var1) / var12;
         float var16 = (var6 - var2) / var12;
         float var17 = var15 * (float)this.glEnd;
         float var18 = var16 * (float)this.glEnd;
         float var19 = var13 * (float)this.F;
         float var20 = var14 * (float)this.F;
         float var21 = -var13 * (float)this.glPopMatrix;
         float var22 = -var14 * (float)this.glPopMatrix;
         float var23 = -var15 * (float)this.glPixelTransferf;
         float var24 = -var16 * (float)this.glPixelTransferf;
         var1 = var1 + var19 + var17;
         var2 = var2 + var20 + var18;
         var3 = var3 + var21 + var17;
         var4 = var4 + var22 + var18;
         var5 = var5 + var19 + var23;
         var6 = var6 + var20 + var24;
      }

      var11 = var5 + (var3 - var1);
      var12 = var4 + (var6 - var2);
      this.glMultiTexCoord2f.I((var10 & 1) != 0);
      this.glColor4ub.B();
      this.glColor4ub.I((SN)this.glMultiTexCoord2f);
      this.glColor4ub.B(var9);
      this.glColor4ub.I(var7);
      OpenGL.glColor4ub((byte)(var8 >> 16), (byte)(var8 >> 8), (byte)var8, (byte)(var8 >> 24));
      OpenGL.glBegin(7);
      OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
      OpenGL.glVertex2f(var1, var2);
      OpenGL.glTexCoord2f(0.0F, 0.0F);
      OpenGL.glVertex2f(var5, var6);
      OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
      OpenGL.glVertex2f(var11, var12);
      OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
      OpenGL.glVertex2f(var3, var4);
      OpenGL.glEnd();
   }

   public void method675(int var1, int var2, int var3, int var4, int var5, int var6) {
      if (this.glColor4ub.ZI) {
         int[] var7 = this.glColor4ub.aq(var5, var6, var3, var4);
         if (var7 != null) {
            for(int var8 = 0; var8 < var7.length; ++var8) {
               var7[var8] |= -16777216;
            }

            this.glBegin(var1, var2, var3, var4, var7, 0, var3);
         }
      } else {
         this.glMultiTexCoord2f.I(var1, var2, var3, var4, var5, var6);
      }

   }

   public void method632(int var1, int var2, int var3) {
      OpenGL.glPixelTransferf(3348, 0.5F);
      OpenGL.glPixelTransferf(3349, 0.499F);
      OpenGL.glPixelTransferf(3352, 0.5F);
      OpenGL.glPixelTransferf(3353, 0.499F);
      OpenGL.glPixelTransferf(3354, 0.5F);
      OpenGL.glPixelTransferf(3355, 0.499F);
      this.aq = JO.I(this.glColor4ub, var1, var2, this.glMultiTexCoord2f.K, this.glMultiTexCoord2f.H);
      this.glColor3f = var3;
      OpenGL.glPixelTransferf(3348, 1.0F);
      OpenGL.glPixelTransferf(3349, 0.0F);
      OpenGL.glPixelTransferf(3352, 1.0F);
      OpenGL.glPixelTransferf(3353, 0.0F);
      OpenGL.glPixelTransferf(3354, 1.0F);
      OpenGL.glPixelTransferf(3355, 0.0F);
   }

   JBI(MJI var1, int var2, int var3, boolean var4) {
      this.glColor4ub = var1;
      this.glMultiTexCoord2f = JO.I(var1, var4 ? YCI.Z : YCI.D, SDI.C, var2, var3);
   }

   void F(int var1) {
      this.glColor4ub.C(1);
      this.glColor4ub.I((SN)this.glMultiTexCoord2f);
      this.glColor4ub.Z(this.glColor4ub.S(var1), 7681);
      this.glColor4ub.I(1, 34167, 768);
      this.glColor4ub.C(0, 34168, 770);
      this.glColor4ub.C(0);
      this.glColor4ub.I((SN)this.aq);
      this.glColor4ub.Z(34479, 7681);
      this.glColor4ub.I(1, 34166, 768);
      if (this.glColor3f == 0) {
         this.glColor4ub.I(1.0F, 0.5F, 0.5F, 0.0F);
      } else if (this.glColor3f == 1) {
         this.glColor4ub.I(0.5F, 1.0F, 0.5F, 0.0F);
      } else if (this.glColor3f == 2) {
         this.glColor4ub.I(0.5F, 0.5F, 1.0F, 0.0F);
      } else if (this.glColor3f == 3) {
         this.glColor4ub.I(128.5F, 128.5F, 128.5F, 0.0F);
      }

   }

   void aq() {
      this.glColor4ub.C(1);
      this.glColor4ub.I((SN)null);
      this.glColor4ub.Z(8448, 8448);
      this.glColor4ub.I(1, 34168, 768);
      this.glColor4ub.C(0, 5890, 770);
      this.glColor4ub.C(0);
      this.glColor4ub.I(1, 34168, 768);
   }

   public void method631(int var1, int var2, int var3, int var4, int var5) {
      this.glMultiTexCoord2f.I(false);
      this.glColor4ub.B();
      this.glColor4ub.B(var5);
      OpenGL.glColor4ub((byte)(var4 >> 16), (byte)(var4 >> 8), (byte)var4, (byte)(var4 >> 24));
      var1 += this.F;
      var2 += this.glEnd;
      if (this.aq == null) {
         this.glColor4ub.I((SN)this.glMultiTexCoord2f);
         this.glColor4ub.I(var3);
         OpenGL.glBegin(7);
         OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1, var2);
         OpenGL.glTexCoord2f(0.0F, 0.0F);
         OpenGL.glVertex2i(var1, var2 + this.glMultiTexCoord2f.H);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
         OpenGL.glVertex2i(var1 + this.glMultiTexCoord2f.K, var2 + this.glMultiTexCoord2f.H);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1 + this.glMultiTexCoord2f.K, var2);
         OpenGL.glEnd();
      } else {
         this.F(var3);
         this.aq.I(false);
         OpenGL.glBegin(7);
         OpenGL.glMultiTexCoord2f(33985, 0.0F, this.glMultiTexCoord2f.N);
         OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1, var2);
         OpenGL.glMultiTexCoord2f(33985, 0.0F, 0.0F);
         OpenGL.glTexCoord2f(0.0F, 0.0F);
         OpenGL.glVertex2i(var1, var2 + this.glMultiTexCoord2f.H);
         OpenGL.glMultiTexCoord2f(33985, this.glMultiTexCoord2f.L, 0.0F);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
         OpenGL.glVertex2i(var1 + this.glMultiTexCoord2f.K, var2 + this.glMultiTexCoord2f.H);
         OpenGL.glMultiTexCoord2f(33985, this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1 + this.glMultiTexCoord2f.K, var2);
         OpenGL.glEnd();
         this.aq();
      }

   }

   public void method654(int var1, int var2, QJI var3, int var4, int var5) {
      RJI var6 = (RJI)var3;
      JO var7 = var6.I;
      this.glMultiTexCoord2f.I(false);
      this.glColor4ub.B();
      this.glColor4ub.I((SN)this.glMultiTexCoord2f);
      this.glColor4ub.I(1);
      this.glColor4ub.C(1);
      this.glColor4ub.I((SN)var7);
      this.glColor4ub.Z(7681, 8448);
      this.glColor4ub.I(0, 34168, 768);
      this.glColor4ub.B(1);
      var1 += this.F;
      var2 += this.glEnd;
      int var8 = var1 + this.glMultiTexCoord2f.K;
      int var9 = var2 + this.glMultiTexCoord2f.H;
      float var10 = var7.L / (float)var7.K;
      float var11 = var7.N / (float)var7.H;
      float var12 = (float)(var1 - var4) * var10;
      float var13 = (float)(var8 - var4) * var10;
      float var14 = var7.N - (float)(var2 - var5) * var11;
      float var15 = var7.N - (float)(var9 - var5) * var11;
      OpenGL.glBegin(7);
      OpenGL.glColor3f(1.0F, 1.0F, 1.0F);
      OpenGL.glMultiTexCoord2f(33984, 0.0F, this.glMultiTexCoord2f.N);
      OpenGL.glMultiTexCoord2f(33985, var12, var14);
      OpenGL.glVertex2i(var1, var2);
      OpenGL.glMultiTexCoord2f(33984, 0.0F, 0.0F);
      OpenGL.glMultiTexCoord2f(33985, var12, var15);
      OpenGL.glVertex2i(var1, var2 + this.glMultiTexCoord2f.H);
      OpenGL.glMultiTexCoord2f(33984, this.glMultiTexCoord2f.L, 0.0F);
      OpenGL.glMultiTexCoord2f(33985, var13, var15);
      OpenGL.glVertex2i(var1 + this.glMultiTexCoord2f.K, var2 + this.glMultiTexCoord2f.H);
      OpenGL.glMultiTexCoord2f(33984, this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
      OpenGL.glMultiTexCoord2f(33985, var13, var14);
      OpenGL.glVertex2i(var1 + this.glMultiTexCoord2f.K, var2);
      OpenGL.glEnd();
      this.glColor4ub.I(0, 5890, 768);
      this.glColor4ub.I(0);
      this.glColor4ub.I((SN)null);
      this.glColor4ub.C(0);
   }

   void method635(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      this.glMultiTexCoord2f.I((var8 & 1) != 0);
      this.glColor4ub.B();
      this.glColor4ub.B(var7);
      OpenGL.glColor4ub((byte)(var6 >> 16), (byte)(var6 >> 8), (byte)var6, (byte)(var6 >> 24));
      if (this.glBegin) {
         float var9 = (float)var3 / (float)this.method271();
         float var10 = (float)var4 / (float)this.method626();
         float var11 = (float)var1 + (float)this.F * var9;
         float var12 = (float)var2 + (float)this.glEnd * var10;
         float var13 = var11 + (float)this.glMultiTexCoord2f.K * var9;
         float var14 = var12 + (float)this.glMultiTexCoord2f.H * var10;
         if (this.aq == null) {
            this.glColor4ub.I((SN)this.glMultiTexCoord2f);
            this.glColor4ub.I(var5);
            OpenGL.glBegin(7);
            OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
            OpenGL.glVertex2f(var11, var12);
            OpenGL.glTexCoord2f(0.0F, 0.0F);
            OpenGL.glVertex2f(var11, var14);
            OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
            OpenGL.glVertex2f(var13, var14);
            OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
            OpenGL.glVertex2f(var13, var12);
            OpenGL.glEnd();
         } else {
            this.F(var5);
            this.aq.I(true);
            OpenGL.glBegin(7);
            OpenGL.glMultiTexCoord2f(33985, 0.0F, this.glMultiTexCoord2f.N);
            OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
            OpenGL.glVertex2f(var11, var12);
            OpenGL.glMultiTexCoord2f(33985, 0.0F, 0.0F);
            OpenGL.glTexCoord2f(0.0F, 0.0F);
            OpenGL.glVertex2f(var11, var14);
            OpenGL.glMultiTexCoord2f(33985, this.glMultiTexCoord2f.L, 0.0F);
            OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
            OpenGL.glVertex2f(var13, var14);
            OpenGL.glMultiTexCoord2f(33985, this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
            OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
            OpenGL.glVertex2f(var13, var12);
            OpenGL.glEnd();
            this.aq();
         }
      } else if (this.aq == null) {
         this.glColor4ub.I((SN)this.glMultiTexCoord2f);
         this.glColor4ub.I(var5);
         OpenGL.glBegin(7);
         OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1, var2);
         OpenGL.glTexCoord2f(0.0F, 0.0F);
         OpenGL.glVertex2i(var1, var2 + var4);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
         OpenGL.glVertex2i(var1 + var3, var2 + var4);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1 + var3, var2);
         OpenGL.glEnd();
      } else {
         this.F(var5);
         this.aq.I(true);
         OpenGL.glBegin(7);
         OpenGL.glMultiTexCoord2f(33985, 0.0F, this.glMultiTexCoord2f.N);
         OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1, var2);
         OpenGL.glMultiTexCoord2f(33985, 0.0F, 0.0F);
         OpenGL.glTexCoord2f(0.0F, 0.0F);
         OpenGL.glVertex2i(var1, var2 + var4);
         OpenGL.glMultiTexCoord2f(33985, this.glMultiTexCoord2f.L, 0.0F);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
         OpenGL.glVertex2i(var1 + var3, var2 + var4);
         OpenGL.glMultiTexCoord2f(33985, this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1 + var3, var2);
         OpenGL.glEnd();
         this.aq();
      }

   }

   public void method662(int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      int var8 = var1 + var3;
      int var9 = var2 + var4;
      this.glMultiTexCoord2f.I(false);
      this.glColor4ub.B();
      this.glColor4ub.I((SN)this.glMultiTexCoord2f);
      this.glColor4ub.B(var7);
      this.glColor4ub.I(var5);
      OpenGL.glColor4ub((byte)(var6 >> 16), (byte)(var6 >> 8), (byte)var6, (byte)(var6 >> 24));
      if (this.glMultiTexCoord2f.M && !this.glBegin) {
         float var18 = this.glMultiTexCoord2f.N * (float)var4 / (float)this.glMultiTexCoord2f.H;
         float var19 = this.glMultiTexCoord2f.L * (float)var3 / (float)this.glMultiTexCoord2f.K;
         OpenGL.glBegin(7);
         OpenGL.glTexCoord2f(0.0F, var18);
         OpenGL.glVertex2i(var1, var2);
         OpenGL.glTexCoord2f(0.0F, 0.0F);
         OpenGL.glVertex2i(var1, var9);
         OpenGL.glTexCoord2f(var19, 0.0F);
         OpenGL.glVertex2i(var8, var9);
         OpenGL.glTexCoord2f(var19, var18);
         OpenGL.glVertex2i(var8, var2);
         OpenGL.glEnd();
      } else {
         OpenGL.glPushMatrix();
         OpenGL.glTranslatef((float)this.F, (float)this.glEnd, 0.0F);
         int var10 = this.method271();
         int var11 = this.method626();
         int var12 = var2 + this.glMultiTexCoord2f.H;
         OpenGL.glBegin(7);

         int var13;
         int var15;
         for(var13 = var2; var12 <= var9; var12 += var11) {
            int var14 = var1 + this.glMultiTexCoord2f.K;

            for(var15 = var1; var14 <= var8; var15 += var10) {
               OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
               OpenGL.glVertex2i(var15, var13);
               OpenGL.glTexCoord2f(0.0F, 0.0F);
               OpenGL.glVertex2i(var15, var12);
               OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
               OpenGL.glVertex2i(var14, var12);
               OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
               OpenGL.glVertex2i(var14, var13);
               var14 += var10;
            }

            if (var15 < var8) {
               float var16 = this.glMultiTexCoord2f.L * (float)(var8 - var15) / (float)this.glMultiTexCoord2f.K;
               OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
               OpenGL.glVertex2i(var15, var13);
               OpenGL.glTexCoord2f(0.0F, 0.0F);
               OpenGL.glVertex2i(var15, var12);
               OpenGL.glTexCoord2f(var16, 0.0F);
               OpenGL.glVertex2i(var8, var12);
               OpenGL.glTexCoord2f(var16, this.glMultiTexCoord2f.N);
               OpenGL.glVertex2i(var8, var13);
            }

            var13 += var11;
         }

         if (var13 < var9) {
            float var20 = this.glMultiTexCoord2f.N * (float)(this.glMultiTexCoord2f.H - (var9 - var13)) / (float)this.glMultiTexCoord2f.H;
            var15 = var1 + this.glMultiTexCoord2f.K;

            int var21;
            for(var21 = var1; var15 <= var8; var21 += var10) {
               OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
               OpenGL.glVertex2i(var21, var13);
               OpenGL.glTexCoord2f(0.0F, var20);
               OpenGL.glVertex2i(var21, var9);
               OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, var20);
               OpenGL.glVertex2i(var15, var9);
               OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
               OpenGL.glVertex2i(var15, var13);
               var15 += var10;
            }

            if (var21 < var8) {
               float var17 = this.glMultiTexCoord2f.L * (float)(var8 - var21) / (float)this.glMultiTexCoord2f.K;
               OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
               OpenGL.glVertex2i(var21, var13);
               OpenGL.glTexCoord2f(0.0F, var20);
               OpenGL.glVertex2i(var21, var9);
               OpenGL.glTexCoord2f(var17, var20);
               OpenGL.glVertex2i(var8, var9);
               OpenGL.glTexCoord2f(var17, this.glMultiTexCoord2f.N);
               OpenGL.glVertex2i(var8, var13);
            }
         }

         OpenGL.glEnd();
         OpenGL.glPopMatrix();
      }

   }

   void method642(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10) {
      float var11;
      float var12;
      if (this.glBegin) {
         var11 = (float)this.method271();
         var12 = (float)this.method626();
         float var13 = (var3 - var1) / var11;
         float var14 = (var4 - var2) / var11;
         float var15 = (var5 - var1) / var12;
         float var16 = (var6 - var2) / var12;
         float var17 = var15 * (float)this.glEnd;
         float var18 = var16 * (float)this.glEnd;
         float var19 = var13 * (float)this.F;
         float var20 = var14 * (float)this.F;
         float var21 = -var13 * (float)this.glPopMatrix;
         float var22 = -var14 * (float)this.glPopMatrix;
         float var23 = -var15 * (float)this.glPixelTransferf;
         float var24 = -var16 * (float)this.glPixelTransferf;
         var1 = var1 + var19 + var17;
         var2 = var2 + var20 + var18;
         var3 = var3 + var21 + var17;
         var4 = var4 + var22 + var18;
         var5 = var5 + var19 + var23;
         var6 = var6 + var20 + var24;
      }

      var11 = var5 + (var3 - var1);
      var12 = var4 + (var6 - var2);
      this.glMultiTexCoord2f.I((var10 & 1) != 0);
      this.glColor4ub.B();
      this.glColor4ub.I((SN)this.glMultiTexCoord2f);
      this.glColor4ub.B(var9);
      this.glColor4ub.I(var7);
      OpenGL.glColor4ub((byte)(var8 >> 16), (byte)(var8 >> 8), (byte)var8, (byte)(var8 >> 24));
      OpenGL.glBegin(7);
      OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
      OpenGL.glVertex2f(var1, var2);
      OpenGL.glTexCoord2f(0.0F, 0.0F);
      OpenGL.glVertex2f(var5, var6);
      OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
      OpenGL.glVertex2f(var11, var12);
      OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
      OpenGL.glVertex2f(var3, var4);
      OpenGL.glEnd();
   }

   void method644(float var1, float var2, float var3, float var4, float var5, float var6, int var7, QJI var8, int var9, int var10) {
      JO var11 = ((RJI)var8).I;
      float var12;
      float var13;
      float var14;
      float var15;
      if (this.glBegin) {
         var12 = (float)this.method271();
         var13 = (float)this.method626();
         var14 = (var3 - var1) / var12;
         var15 = (var4 - var2) / var12;
         float var16 = (var5 - var1) / var13;
         float var17 = (var6 - var2) / var13;
         float var18 = var16 * (float)this.glEnd;
         float var19 = var17 * (float)this.glEnd;
         float var20 = var14 * (float)this.F;
         float var21 = var15 * (float)this.F;
         float var22 = -var14 * (float)this.glPopMatrix;
         float var23 = -var15 * (float)this.glPopMatrix;
         float var24 = -var16 * (float)this.glPixelTransferf;
         float var25 = -var17 * (float)this.glPixelTransferf;
         var1 = var1 + var20 + var18;
         var2 = var2 + var21 + var19;
         var3 = var3 + var22 + var18;
         var4 = var4 + var23 + var19;
         var5 = var5 + var20 + var24;
         var6 = var6 + var21 + var25;
      }

      var12 = var5 + (var3 - var1);
      var13 = var4 + (var6 - var2);
      this.glMultiTexCoord2f.I((var7 & 1) != 0);
      this.glColor4ub.B();
      this.glColor4ub.I((SN)this.glMultiTexCoord2f);
      this.glColor4ub.I(1);
      this.glColor4ub.C(1);
      this.glColor4ub.I((SN)var11);
      this.glColor4ub.Z(7681, 8448);
      this.glColor4ub.I(0, 34168, 768);
      this.glColor4ub.B(1);
      var14 = var11.L / (float)var11.K;
      var15 = var11.N / (float)var11.H;
      OpenGL.glBegin(7);
      OpenGL.glColor3f(1.0F, 1.0F, 1.0F);
      OpenGL.glMultiTexCoord2f(33984, 0.0F, this.glMultiTexCoord2f.N);
      OpenGL.glMultiTexCoord2f(33985, var14 * (var1 - (float)var9), var11.N - var15 * (var2 - (float)var10));
      OpenGL.glVertex2f(var1, var2);
      OpenGL.glMultiTexCoord2f(33984, 0.0F, 0.0F);
      OpenGL.glMultiTexCoord2f(33985, var14 * (var5 - (float)var9), var11.N - var15 * (var6 - (float)var10));
      OpenGL.glVertex2f(var5, var6);
      OpenGL.glMultiTexCoord2f(33984, this.glMultiTexCoord2f.L, 0.0F);
      OpenGL.glMultiTexCoord2f(33985, var14 * (var12 - (float)var9), var11.N - var15 * (var13 - (float)var10));
      OpenGL.glVertex2f(var12, var13);
      OpenGL.glMultiTexCoord2f(33984, this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
      OpenGL.glMultiTexCoord2f(33985, var14 * (var3 - (float)var9), var11.N - var15 * (var4 - (float)var10));
      OpenGL.glVertex2f(var3, var4);
      OpenGL.glEnd();
      this.glColor4ub.I(0, 5890, 768);
      this.glColor4ub.I(0);
      this.glColor4ub.I((SN)null);
      this.glColor4ub.C(0);
   }

   public void method650(int var1, int var2, QJI var3, int var4, int var5) {
      RJI var6 = (RJI)var3;
      JO var7 = var6.I;
      this.glMultiTexCoord2f.I(false);
      this.glColor4ub.B();
      this.glColor4ub.I((SN)this.glMultiTexCoord2f);
      this.glColor4ub.I(1);
      this.glColor4ub.C(1);
      this.glColor4ub.I((SN)var7);
      this.glColor4ub.Z(7681, 8448);
      this.glColor4ub.I(0, 34168, 768);
      this.glColor4ub.B(1);
      var1 += this.F;
      var2 += this.glEnd;
      int var8 = var1 + this.glMultiTexCoord2f.K;
      int var9 = var2 + this.glMultiTexCoord2f.H;
      float var10 = var7.L / (float)var7.K;
      float var11 = var7.N / (float)var7.H;
      float var12 = (float)(var1 - var4) * var10;
      float var13 = (float)(var8 - var4) * var10;
      float var14 = var7.N - (float)(var2 - var5) * var11;
      float var15 = var7.N - (float)(var9 - var5) * var11;
      OpenGL.glBegin(7);
      OpenGL.glColor3f(1.0F, 1.0F, 1.0F);
      OpenGL.glMultiTexCoord2f(33984, 0.0F, this.glMultiTexCoord2f.N);
      OpenGL.glMultiTexCoord2f(33985, var12, var14);
      OpenGL.glVertex2i(var1, var2);
      OpenGL.glMultiTexCoord2f(33984, 0.0F, 0.0F);
      OpenGL.glMultiTexCoord2f(33985, var12, var15);
      OpenGL.glVertex2i(var1, var2 + this.glMultiTexCoord2f.H);
      OpenGL.glMultiTexCoord2f(33984, this.glMultiTexCoord2f.L, 0.0F);
      OpenGL.glMultiTexCoord2f(33985, var13, var15);
      OpenGL.glVertex2i(var1 + this.glMultiTexCoord2f.K, var2 + this.glMultiTexCoord2f.H);
      OpenGL.glMultiTexCoord2f(33984, this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
      OpenGL.glMultiTexCoord2f(33985, var13, var14);
      OpenGL.glVertex2i(var1 + this.glMultiTexCoord2f.K, var2);
      OpenGL.glEnd();
      this.glColor4ub.I(0, 5890, 768);
      this.glColor4ub.I(0);
      this.glColor4ub.I((SN)null);
      this.glColor4ub.C(0);
   }

   public TAI method646() {
      return this.glMultiTexCoord2f.I(0);
   }

   public void method640(int[] var1) {
      var1[0] = this.F;
      var1[1] = this.glEnd;
      var1[2] = this.glPopMatrix;
      var1[3] = this.glPixelTransferf;
   }

   public void method643(int var1, int var2, int var3, int var4, int var5) {
      this.glMultiTexCoord2f.I(false);
      this.glColor4ub.B();
      this.glColor4ub.B(var5);
      OpenGL.glColor4ub((byte)(var4 >> 16), (byte)(var4 >> 8), (byte)var4, (byte)(var4 >> 24));
      var1 += this.F;
      var2 += this.glEnd;
      if (this.aq == null) {
         this.glColor4ub.I((SN)this.glMultiTexCoord2f);
         this.glColor4ub.I(var3);
         OpenGL.glBegin(7);
         OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1, var2);
         OpenGL.glTexCoord2f(0.0F, 0.0F);
         OpenGL.glVertex2i(var1, var2 + this.glMultiTexCoord2f.H);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
         OpenGL.glVertex2i(var1 + this.glMultiTexCoord2f.K, var2 + this.glMultiTexCoord2f.H);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1 + this.glMultiTexCoord2f.K, var2);
         OpenGL.glEnd();
      } else {
         this.F(var3);
         this.aq.I(false);
         OpenGL.glBegin(7);
         OpenGL.glMultiTexCoord2f(33985, 0.0F, this.glMultiTexCoord2f.N);
         OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1, var2);
         OpenGL.glMultiTexCoord2f(33985, 0.0F, 0.0F);
         OpenGL.glTexCoord2f(0.0F, 0.0F);
         OpenGL.glVertex2i(var1, var2 + this.glMultiTexCoord2f.H);
         OpenGL.glMultiTexCoord2f(33985, this.glMultiTexCoord2f.L, 0.0F);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
         OpenGL.glVertex2i(var1 + this.glMultiTexCoord2f.K, var2 + this.glMultiTexCoord2f.H);
         OpenGL.glMultiTexCoord2f(33985, this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1 + this.glMultiTexCoord2f.K, var2);
         OpenGL.glEnd();
         this.aq();
      }

   }

   public void method665(int var1, int var2, int var3, int var4, int var5, int var6) {
      if (this.glColor4ub.ZI) {
         int[] var7 = this.glColor4ub.aq(var5, var6, var3, var4);
         if (var7 != null) {
            for(int var8 = 0; var8 < var7.length; ++var8) {
               var7[var8] |= -16777216;
            }

            this.glBegin(var1, var2, var3, var4, var7, 0, var3);
         }
      } else {
         this.glMultiTexCoord2f.I(var1, var2, var3, var4, var5, var6);
      }

   }

   void method670(float var1, float var2, float var3, float var4, float var5, float var6, int var7, QJI var8, int var9, int var10) {
      JO var11 = ((RJI)var8).I;
      float var12;
      float var13;
      float var14;
      float var15;
      if (this.glBegin) {
         var12 = (float)this.method271();
         var13 = (float)this.method626();
         var14 = (var3 - var1) / var12;
         var15 = (var4 - var2) / var12;
         float var16 = (var5 - var1) / var13;
         float var17 = (var6 - var2) / var13;
         float var18 = var16 * (float)this.glEnd;
         float var19 = var17 * (float)this.glEnd;
         float var20 = var14 * (float)this.F;
         float var21 = var15 * (float)this.F;
         float var22 = -var14 * (float)this.glPopMatrix;
         float var23 = -var15 * (float)this.glPopMatrix;
         float var24 = -var16 * (float)this.glPixelTransferf;
         float var25 = -var17 * (float)this.glPixelTransferf;
         var1 = var1 + var20 + var18;
         var2 = var2 + var21 + var19;
         var3 = var3 + var22 + var18;
         var4 = var4 + var23 + var19;
         var5 = var5 + var20 + var24;
         var6 = var6 + var21 + var25;
      }

      var12 = var5 + (var3 - var1);
      var13 = var4 + (var6 - var2);
      this.glMultiTexCoord2f.I((var7 & 1) != 0);
      this.glColor4ub.B();
      this.glColor4ub.I((SN)this.glMultiTexCoord2f);
      this.glColor4ub.I(1);
      this.glColor4ub.C(1);
      this.glColor4ub.I((SN)var11);
      this.glColor4ub.Z(7681, 8448);
      this.glColor4ub.I(0, 34168, 768);
      this.glColor4ub.B(1);
      var14 = var11.L / (float)var11.K;
      var15 = var11.N / (float)var11.H;
      OpenGL.glBegin(7);
      OpenGL.glColor3f(1.0F, 1.0F, 1.0F);
      OpenGL.glMultiTexCoord2f(33984, 0.0F, this.glMultiTexCoord2f.N);
      OpenGL.glMultiTexCoord2f(33985, var14 * (var1 - (float)var9), var11.N - var15 * (var2 - (float)var10));
      OpenGL.glVertex2f(var1, var2);
      OpenGL.glMultiTexCoord2f(33984, 0.0F, 0.0F);
      OpenGL.glMultiTexCoord2f(33985, var14 * (var5 - (float)var9), var11.N - var15 * (var6 - (float)var10));
      OpenGL.glVertex2f(var5, var6);
      OpenGL.glMultiTexCoord2f(33984, this.glMultiTexCoord2f.L, 0.0F);
      OpenGL.glMultiTexCoord2f(33985, var14 * (var12 - (float)var9), var11.N - var15 * (var13 - (float)var10));
      OpenGL.glVertex2f(var12, var13);
      OpenGL.glMultiTexCoord2f(33984, this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
      OpenGL.glMultiTexCoord2f(33985, var14 * (var3 - (float)var9), var11.N - var15 * (var4 - (float)var10));
      OpenGL.glVertex2f(var3, var4);
      OpenGL.glEnd();
      this.glColor4ub.I(0, 5890, 768);
      this.glColor4ub.I(0);
      this.glColor4ub.I((SN)null);
      this.glColor4ub.C(0);
   }

   public void method648(int var1, int var2, int var3, int var4, int var5) {
      this.glMultiTexCoord2f.I(false);
      this.glColor4ub.B();
      this.glColor4ub.B(var5);
      OpenGL.glColor4ub((byte)(var4 >> 16), (byte)(var4 >> 8), (byte)var4, (byte)(var4 >> 24));
      var1 += this.F;
      var2 += this.glEnd;
      if (this.aq == null) {
         this.glColor4ub.I((SN)this.glMultiTexCoord2f);
         this.glColor4ub.I(var3);
         OpenGL.glBegin(7);
         OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1, var2);
         OpenGL.glTexCoord2f(0.0F, 0.0F);
         OpenGL.glVertex2i(var1, var2 + this.glMultiTexCoord2f.H);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
         OpenGL.glVertex2i(var1 + this.glMultiTexCoord2f.K, var2 + this.glMultiTexCoord2f.H);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1 + this.glMultiTexCoord2f.K, var2);
         OpenGL.glEnd();
      } else {
         this.F(var3);
         this.aq.I(false);
         OpenGL.glBegin(7);
         OpenGL.glMultiTexCoord2f(33985, 0.0F, this.glMultiTexCoord2f.N);
         OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1, var2);
         OpenGL.glMultiTexCoord2f(33985, 0.0F, 0.0F);
         OpenGL.glTexCoord2f(0.0F, 0.0F);
         OpenGL.glVertex2i(var1, var2 + this.glMultiTexCoord2f.H);
         OpenGL.glMultiTexCoord2f(33985, this.glMultiTexCoord2f.L, 0.0F);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
         OpenGL.glVertex2i(var1 + this.glMultiTexCoord2f.K, var2 + this.glMultiTexCoord2f.H);
         OpenGL.glMultiTexCoord2f(33985, this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1 + this.glMultiTexCoord2f.K, var2);
         OpenGL.glEnd();
         this.aq();
      }

   }

   public int method669() {
      return this.glMultiTexCoord2f.H;
   }

   void method651(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      this.glMultiTexCoord2f.I((var8 & 1) != 0);
      this.glColor4ub.B();
      this.glColor4ub.B(var7);
      OpenGL.glColor4ub((byte)(var6 >> 16), (byte)(var6 >> 8), (byte)var6, (byte)(var6 >> 24));
      if (this.glBegin) {
         float var9 = (float)var3 / (float)this.method271();
         float var10 = (float)var4 / (float)this.method626();
         float var11 = (float)var1 + (float)this.F * var9;
         float var12 = (float)var2 + (float)this.glEnd * var10;
         float var13 = var11 + (float)this.glMultiTexCoord2f.K * var9;
         float var14 = var12 + (float)this.glMultiTexCoord2f.H * var10;
         if (this.aq == null) {
            this.glColor4ub.I((SN)this.glMultiTexCoord2f);
            this.glColor4ub.I(var5);
            OpenGL.glBegin(7);
            OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
            OpenGL.glVertex2f(var11, var12);
            OpenGL.glTexCoord2f(0.0F, 0.0F);
            OpenGL.glVertex2f(var11, var14);
            OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
            OpenGL.glVertex2f(var13, var14);
            OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
            OpenGL.glVertex2f(var13, var12);
            OpenGL.glEnd();
         } else {
            this.F(var5);
            this.aq.I(true);
            OpenGL.glBegin(7);
            OpenGL.glMultiTexCoord2f(33985, 0.0F, this.glMultiTexCoord2f.N);
            OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
            OpenGL.glVertex2f(var11, var12);
            OpenGL.glMultiTexCoord2f(33985, 0.0F, 0.0F);
            OpenGL.glTexCoord2f(0.0F, 0.0F);
            OpenGL.glVertex2f(var11, var14);
            OpenGL.glMultiTexCoord2f(33985, this.glMultiTexCoord2f.L, 0.0F);
            OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
            OpenGL.glVertex2f(var13, var14);
            OpenGL.glMultiTexCoord2f(33985, this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
            OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
            OpenGL.glVertex2f(var13, var12);
            OpenGL.glEnd();
            this.aq();
         }
      } else if (this.aq == null) {
         this.glColor4ub.I((SN)this.glMultiTexCoord2f);
         this.glColor4ub.I(var5);
         OpenGL.glBegin(7);
         OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1, var2);
         OpenGL.glTexCoord2f(0.0F, 0.0F);
         OpenGL.glVertex2i(var1, var2 + var4);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
         OpenGL.glVertex2i(var1 + var3, var2 + var4);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1 + var3, var2);
         OpenGL.glEnd();
      } else {
         this.F(var5);
         this.aq.I(true);
         OpenGL.glBegin(7);
         OpenGL.glMultiTexCoord2f(33985, 0.0F, this.glMultiTexCoord2f.N);
         OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1, var2);
         OpenGL.glMultiTexCoord2f(33985, 0.0F, 0.0F);
         OpenGL.glTexCoord2f(0.0F, 0.0F);
         OpenGL.glVertex2i(var1, var2 + var4);
         OpenGL.glMultiTexCoord2f(33985, this.glMultiTexCoord2f.L, 0.0F);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
         OpenGL.glVertex2i(var1 + var3, var2 + var4);
         OpenGL.glMultiTexCoord2f(33985, this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1 + var3, var2);
         OpenGL.glEnd();
         this.aq();
      }

   }

   void method652(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      this.glMultiTexCoord2f.I((var8 & 1) != 0);
      this.glColor4ub.B();
      this.glColor4ub.B(var7);
      OpenGL.glColor4ub((byte)(var6 >> 16), (byte)(var6 >> 8), (byte)var6, (byte)(var6 >> 24));
      if (this.glBegin) {
         float var9 = (float)var3 / (float)this.method271();
         float var10 = (float)var4 / (float)this.method626();
         float var11 = (float)var1 + (float)this.F * var9;
         float var12 = (float)var2 + (float)this.glEnd * var10;
         float var13 = var11 + (float)this.glMultiTexCoord2f.K * var9;
         float var14 = var12 + (float)this.glMultiTexCoord2f.H * var10;
         if (this.aq == null) {
            this.glColor4ub.I((SN)this.glMultiTexCoord2f);
            this.glColor4ub.I(var5);
            OpenGL.glBegin(7);
            OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
            OpenGL.glVertex2f(var11, var12);
            OpenGL.glTexCoord2f(0.0F, 0.0F);
            OpenGL.glVertex2f(var11, var14);
            OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
            OpenGL.glVertex2f(var13, var14);
            OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
            OpenGL.glVertex2f(var13, var12);
            OpenGL.glEnd();
         } else {
            this.F(var5);
            this.aq.I(true);
            OpenGL.glBegin(7);
            OpenGL.glMultiTexCoord2f(33985, 0.0F, this.glMultiTexCoord2f.N);
            OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
            OpenGL.glVertex2f(var11, var12);
            OpenGL.glMultiTexCoord2f(33985, 0.0F, 0.0F);
            OpenGL.glTexCoord2f(0.0F, 0.0F);
            OpenGL.glVertex2f(var11, var14);
            OpenGL.glMultiTexCoord2f(33985, this.glMultiTexCoord2f.L, 0.0F);
            OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
            OpenGL.glVertex2f(var13, var14);
            OpenGL.glMultiTexCoord2f(33985, this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
            OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
            OpenGL.glVertex2f(var13, var12);
            OpenGL.glEnd();
            this.aq();
         }
      } else if (this.aq == null) {
         this.glColor4ub.I((SN)this.glMultiTexCoord2f);
         this.glColor4ub.I(var5);
         OpenGL.glBegin(7);
         OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1, var2);
         OpenGL.glTexCoord2f(0.0F, 0.0F);
         OpenGL.glVertex2i(var1, var2 + var4);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
         OpenGL.glVertex2i(var1 + var3, var2 + var4);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1 + var3, var2);
         OpenGL.glEnd();
      } else {
         this.F(var5);
         this.aq.I(true);
         OpenGL.glBegin(7);
         OpenGL.glMultiTexCoord2f(33985, 0.0F, this.glMultiTexCoord2f.N);
         OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1, var2);
         OpenGL.glMultiTexCoord2f(33985, 0.0F, 0.0F);
         OpenGL.glTexCoord2f(0.0F, 0.0F);
         OpenGL.glVertex2i(var1, var2 + var4);
         OpenGL.glMultiTexCoord2f(33985, this.glMultiTexCoord2f.L, 0.0F);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
         OpenGL.glVertex2i(var1 + var3, var2 + var4);
         OpenGL.glMultiTexCoord2f(33985, this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1 + var3, var2);
         OpenGL.glEnd();
         this.aq();
      }

   }

   public void method624(int var1, int var2, int var3, int var4, int var5, int var6) {
      if (this.glColor4ub.ZI) {
         int[] var7 = this.glColor4ub.aq(var5, var6, var3, var4);
         if (var7 != null) {
            for(int var8 = 0; var8 < var7.length; ++var8) {
               var7[var8] |= -16777216;
            }

            this.glBegin(var1, var2, var3, var4, var7, 0, var3);
         }
      } else {
         this.glMultiTexCoord2f.I(var1, var2, var3, var4, var5, var6);
      }

   }

   public TAI method647() {
      return this.glMultiTexCoord2f.I(0);
   }

   public void method655(int var1, int var2, int var3, int var4) {
      this.F = var1;
      this.glEnd = var2;
      this.glPopMatrix = var3;
      this.glPixelTransferf = var4;
      this.glBegin = this.F != 0 || this.glEnd != 0 || this.glPopMatrix != 0 || this.glPixelTransferf != 0;
   }

   public void method656(int[] var1) {
      var1[0] = this.F;
      var1[1] = this.glEnd;
      var1[2] = this.glPopMatrix;
      var1[3] = this.glPixelTransferf;
   }

   public void method628(int var1, int var2, int var3) {
      OpenGL.glPixelTransferf(3348, 0.5F);
      OpenGL.glPixelTransferf(3349, 0.499F);
      OpenGL.glPixelTransferf(3352, 0.5F);
      OpenGL.glPixelTransferf(3353, 0.499F);
      OpenGL.glPixelTransferf(3354, 0.5F);
      OpenGL.glPixelTransferf(3355, 0.499F);
      this.aq = JO.I(this.glColor4ub, var1, var2, this.glMultiTexCoord2f.K, this.glMultiTexCoord2f.H);
      this.glColor3f = var3;
      OpenGL.glPixelTransferf(3348, 1.0F);
      OpenGL.glPixelTransferf(3349, 0.0F);
      OpenGL.glPixelTransferf(3352, 1.0F);
      OpenGL.glPixelTransferf(3353, 0.0F);
      OpenGL.glPixelTransferf(3354, 1.0F);
      OpenGL.glPixelTransferf(3355, 0.0F);
   }

   void glBegin(int var1, int var2, int var3, int var4, int[] var5, int var6, int var7) {
      this.glMultiTexCoord2f.I(var1, var2, var3, var4, var5, var6, var7, true);
   }

   public int method630() {
      return this.glMultiTexCoord2f.K;
   }

   public int method658() {
      return this.glMultiTexCoord2f.K;
   }

   public int method653() {
      return this.glMultiTexCoord2f.H + this.glEnd + this.glPixelTransferf;
   }

   public void method677(int[] var1) {
      var1[0] = this.F;
      var1[1] = this.glEnd;
      var1[2] = this.glPopMatrix;
      var1[3] = this.glPixelTransferf;
   }

   public int method667() {
      return this.glMultiTexCoord2f.H;
   }

   public void method661(int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      int var8 = var1 + var3;
      int var9 = var2 + var4;
      this.glMultiTexCoord2f.I(false);
      this.glColor4ub.B();
      this.glColor4ub.I((SN)this.glMultiTexCoord2f);
      this.glColor4ub.B(var7);
      this.glColor4ub.I(var5);
      OpenGL.glColor4ub((byte)(var6 >> 16), (byte)(var6 >> 8), (byte)var6, (byte)(var6 >> 24));
      if (this.glMultiTexCoord2f.M && !this.glBegin) {
         float var18 = this.glMultiTexCoord2f.N * (float)var4 / (float)this.glMultiTexCoord2f.H;
         float var19 = this.glMultiTexCoord2f.L * (float)var3 / (float)this.glMultiTexCoord2f.K;
         OpenGL.glBegin(7);
         OpenGL.glTexCoord2f(0.0F, var18);
         OpenGL.glVertex2i(var1, var2);
         OpenGL.glTexCoord2f(0.0F, 0.0F);
         OpenGL.glVertex2i(var1, var9);
         OpenGL.glTexCoord2f(var19, 0.0F);
         OpenGL.glVertex2i(var8, var9);
         OpenGL.glTexCoord2f(var19, var18);
         OpenGL.glVertex2i(var8, var2);
         OpenGL.glEnd();
      } else {
         OpenGL.glPushMatrix();
         OpenGL.glTranslatef((float)this.F, (float)this.glEnd, 0.0F);
         int var10 = this.method271();
         int var11 = this.method626();
         int var12 = var2 + this.glMultiTexCoord2f.H;
         OpenGL.glBegin(7);

         int var13;
         int var15;
         for(var13 = var2; var12 <= var9; var12 += var11) {
            int var14 = var1 + this.glMultiTexCoord2f.K;

            for(var15 = var1; var14 <= var8; var15 += var10) {
               OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
               OpenGL.glVertex2i(var15, var13);
               OpenGL.glTexCoord2f(0.0F, 0.0F);
               OpenGL.glVertex2i(var15, var12);
               OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
               OpenGL.glVertex2i(var14, var12);
               OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
               OpenGL.glVertex2i(var14, var13);
               var14 += var10;
            }

            if (var15 < var8) {
               float var16 = this.glMultiTexCoord2f.L * (float)(var8 - var15) / (float)this.glMultiTexCoord2f.K;
               OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
               OpenGL.glVertex2i(var15, var13);
               OpenGL.glTexCoord2f(0.0F, 0.0F);
               OpenGL.glVertex2i(var15, var12);
               OpenGL.glTexCoord2f(var16, 0.0F);
               OpenGL.glVertex2i(var8, var12);
               OpenGL.glTexCoord2f(var16, this.glMultiTexCoord2f.N);
               OpenGL.glVertex2i(var8, var13);
            }

            var13 += var11;
         }

         if (var13 < var9) {
            float var20 = this.glMultiTexCoord2f.N * (float)(this.glMultiTexCoord2f.H - (var9 - var13)) / (float)this.glMultiTexCoord2f.H;
            var15 = var1 + this.glMultiTexCoord2f.K;

            int var21;
            for(var21 = var1; var15 <= var8; var21 += var10) {
               OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
               OpenGL.glVertex2i(var21, var13);
               OpenGL.glTexCoord2f(0.0F, var20);
               OpenGL.glVertex2i(var21, var9);
               OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, var20);
               OpenGL.glVertex2i(var15, var9);
               OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
               OpenGL.glVertex2i(var15, var13);
               var15 += var10;
            }

            if (var21 < var8) {
               float var17 = this.glMultiTexCoord2f.L * (float)(var8 - var21) / (float)this.glMultiTexCoord2f.K;
               OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
               OpenGL.glVertex2i(var21, var13);
               OpenGL.glTexCoord2f(0.0F, var20);
               OpenGL.glVertex2i(var21, var9);
               OpenGL.glTexCoord2f(var17, var20);
               OpenGL.glVertex2i(var8, var9);
               OpenGL.glTexCoord2f(var17, this.glMultiTexCoord2f.N);
               OpenGL.glVertex2i(var8, var13);
            }
         }

         OpenGL.glEnd();
         OpenGL.glPopMatrix();
      }

   }

   void method629(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10) {
      float var11;
      float var12;
      if (this.glBegin) {
         var11 = (float)this.method271();
         var12 = (float)this.method626();
         float var13 = (var3 - var1) / var11;
         float var14 = (var4 - var2) / var11;
         float var15 = (var5 - var1) / var12;
         float var16 = (var6 - var2) / var12;
         float var17 = var15 * (float)this.glEnd;
         float var18 = var16 * (float)this.glEnd;
         float var19 = var13 * (float)this.F;
         float var20 = var14 * (float)this.F;
         float var21 = -var13 * (float)this.glPopMatrix;
         float var22 = -var14 * (float)this.glPopMatrix;
         float var23 = -var15 * (float)this.glPixelTransferf;
         float var24 = -var16 * (float)this.glPixelTransferf;
         var1 = var1 + var19 + var17;
         var2 = var2 + var20 + var18;
         var3 = var3 + var21 + var17;
         var4 = var4 + var22 + var18;
         var5 = var5 + var19 + var23;
         var6 = var6 + var20 + var24;
      }

      var11 = var5 + (var3 - var1);
      var12 = var4 + (var6 - var2);
      this.glMultiTexCoord2f.I((var10 & 1) != 0);
      this.glColor4ub.B();
      this.glColor4ub.I((SN)this.glMultiTexCoord2f);
      this.glColor4ub.B(var9);
      this.glColor4ub.I(var7);
      OpenGL.glColor4ub((byte)(var8 >> 16), (byte)(var8 >> 8), (byte)var8, (byte)(var8 >> 24));
      OpenGL.glBegin(7);
      OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
      OpenGL.glVertex2f(var1, var2);
      OpenGL.glTexCoord2f(0.0F, 0.0F);
      OpenGL.glVertex2f(var5, var6);
      OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
      OpenGL.glVertex2f(var11, var12);
      OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
      OpenGL.glVertex2f(var3, var4);
      OpenGL.glEnd();
   }

   public int method271() {
      return this.glMultiTexCoord2f.K + this.F + this.glPopMatrix;
   }

   void method657(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10) {
      float var11;
      float var12;
      if (this.glBegin) {
         var11 = (float)this.method271();
         var12 = (float)this.method626();
         float var13 = (var3 - var1) / var11;
         float var14 = (var4 - var2) / var11;
         float var15 = (var5 - var1) / var12;
         float var16 = (var6 - var2) / var12;
         float var17 = var15 * (float)this.glEnd;
         float var18 = var16 * (float)this.glEnd;
         float var19 = var13 * (float)this.F;
         float var20 = var14 * (float)this.F;
         float var21 = -var13 * (float)this.glPopMatrix;
         float var22 = -var14 * (float)this.glPopMatrix;
         float var23 = -var15 * (float)this.glPixelTransferf;
         float var24 = -var16 * (float)this.glPixelTransferf;
         var1 = var1 + var19 + var17;
         var2 = var2 + var20 + var18;
         var3 = var3 + var21 + var17;
         var4 = var4 + var22 + var18;
         var5 = var5 + var19 + var23;
         var6 = var6 + var20 + var24;
      }

      var11 = var5 + (var3 - var1);
      var12 = var4 + (var6 - var2);
      this.glMultiTexCoord2f.I((var10 & 1) != 0);
      this.glColor4ub.B();
      this.glColor4ub.I((SN)this.glMultiTexCoord2f);
      this.glColor4ub.B(var9);
      this.glColor4ub.I(var7);
      OpenGL.glColor4ub((byte)(var8 >> 16), (byte)(var8 >> 8), (byte)var8, (byte)(var8 >> 24));
      OpenGL.glBegin(7);
      OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
      OpenGL.glVertex2f(var1, var2);
      OpenGL.glTexCoord2f(0.0F, 0.0F);
      OpenGL.glVertex2f(var5, var6);
      OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
      OpenGL.glVertex2f(var11, var12);
      OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
      OpenGL.glVertex2f(var3, var4);
      OpenGL.glEnd();
   }

   void method664(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10) {
      float var11;
      float var12;
      if (this.glBegin) {
         var11 = (float)this.method271();
         var12 = (float)this.method626();
         float var13 = (var3 - var1) / var11;
         float var14 = (var4 - var2) / var11;
         float var15 = (var5 - var1) / var12;
         float var16 = (var6 - var2) / var12;
         float var17 = var15 * (float)this.glEnd;
         float var18 = var16 * (float)this.glEnd;
         float var19 = var13 * (float)this.F;
         float var20 = var14 * (float)this.F;
         float var21 = -var13 * (float)this.glPopMatrix;
         float var22 = -var14 * (float)this.glPopMatrix;
         float var23 = -var15 * (float)this.glPixelTransferf;
         float var24 = -var16 * (float)this.glPixelTransferf;
         var1 = var1 + var19 + var17;
         var2 = var2 + var20 + var18;
         var3 = var3 + var21 + var17;
         var4 = var4 + var22 + var18;
         var5 = var5 + var19 + var23;
         var6 = var6 + var20 + var24;
      }

      var11 = var5 + (var3 - var1);
      var12 = var4 + (var6 - var2);
      this.glMultiTexCoord2f.I((var10 & 1) != 0);
      this.glColor4ub.B();
      this.glColor4ub.I((SN)this.glMultiTexCoord2f);
      this.glColor4ub.B(var9);
      this.glColor4ub.I(var7);
      OpenGL.glColor4ub((byte)(var8 >> 16), (byte)(var8 >> 8), (byte)var8, (byte)(var8 >> 24));
      OpenGL.glBegin(7);
      OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
      OpenGL.glVertex2f(var1, var2);
      OpenGL.glTexCoord2f(0.0F, 0.0F);
      OpenGL.glVertex2f(var5, var6);
      OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
      OpenGL.glVertex2f(var11, var12);
      OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
      OpenGL.glVertex2f(var3, var4);
      OpenGL.glEnd();
   }

   public void method649(int var1, int var2, int var3, int var4, int var5) {
      this.glMultiTexCoord2f.I(false);
      this.glColor4ub.B();
      this.glColor4ub.B(var5);
      OpenGL.glColor4ub((byte)(var4 >> 16), (byte)(var4 >> 8), (byte)var4, (byte)(var4 >> 24));
      var1 += this.F;
      var2 += this.glEnd;
      if (this.aq == null) {
         this.glColor4ub.I((SN)this.glMultiTexCoord2f);
         this.glColor4ub.I(var3);
         OpenGL.glBegin(7);
         OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1, var2);
         OpenGL.glTexCoord2f(0.0F, 0.0F);
         OpenGL.glVertex2i(var1, var2 + this.glMultiTexCoord2f.H);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
         OpenGL.glVertex2i(var1 + this.glMultiTexCoord2f.K, var2 + this.glMultiTexCoord2f.H);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1 + this.glMultiTexCoord2f.K, var2);
         OpenGL.glEnd();
      } else {
         this.F(var3);
         this.aq.I(false);
         OpenGL.glBegin(7);
         OpenGL.glMultiTexCoord2f(33985, 0.0F, this.glMultiTexCoord2f.N);
         OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1, var2);
         OpenGL.glMultiTexCoord2f(33985, 0.0F, 0.0F);
         OpenGL.glTexCoord2f(0.0F, 0.0F);
         OpenGL.glVertex2i(var1, var2 + this.glMultiTexCoord2f.H);
         OpenGL.glMultiTexCoord2f(33985, this.glMultiTexCoord2f.L, 0.0F);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
         OpenGL.glVertex2i(var1 + this.glMultiTexCoord2f.K, var2 + this.glMultiTexCoord2f.H);
         OpenGL.glMultiTexCoord2f(33985, this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1 + this.glMultiTexCoord2f.K, var2);
         OpenGL.glEnd();
         this.aq();
      }

   }

   public TAI method627() {
      return this.glMultiTexCoord2f.I(0);
   }

   public int method668() {
      return this.glMultiTexCoord2f.H;
   }

   public void method660(int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      int var8 = var1 + var3;
      int var9 = var2 + var4;
      this.glMultiTexCoord2f.I(false);
      this.glColor4ub.B();
      this.glColor4ub.I((SN)this.glMultiTexCoord2f);
      this.glColor4ub.B(var7);
      this.glColor4ub.I(var5);
      OpenGL.glColor4ub((byte)(var6 >> 16), (byte)(var6 >> 8), (byte)var6, (byte)(var6 >> 24));
      if (this.glMultiTexCoord2f.M && !this.glBegin) {
         float var18 = this.glMultiTexCoord2f.N * (float)var4 / (float)this.glMultiTexCoord2f.H;
         float var19 = this.glMultiTexCoord2f.L * (float)var3 / (float)this.glMultiTexCoord2f.K;
         OpenGL.glBegin(7);
         OpenGL.glTexCoord2f(0.0F, var18);
         OpenGL.glVertex2i(var1, var2);
         OpenGL.glTexCoord2f(0.0F, 0.0F);
         OpenGL.glVertex2i(var1, var9);
         OpenGL.glTexCoord2f(var19, 0.0F);
         OpenGL.glVertex2i(var8, var9);
         OpenGL.glTexCoord2f(var19, var18);
         OpenGL.glVertex2i(var8, var2);
         OpenGL.glEnd();
      } else {
         OpenGL.glPushMatrix();
         OpenGL.glTranslatef((float)this.F, (float)this.glEnd, 0.0F);
         int var10 = this.method271();
         int var11 = this.method626();
         int var12 = var2 + this.glMultiTexCoord2f.H;
         OpenGL.glBegin(7);

         int var13;
         int var15;
         for(var13 = var2; var12 <= var9; var12 += var11) {
            int var14 = var1 + this.glMultiTexCoord2f.K;

            for(var15 = var1; var14 <= var8; var15 += var10) {
               OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
               OpenGL.glVertex2i(var15, var13);
               OpenGL.glTexCoord2f(0.0F, 0.0F);
               OpenGL.glVertex2i(var15, var12);
               OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
               OpenGL.glVertex2i(var14, var12);
               OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
               OpenGL.glVertex2i(var14, var13);
               var14 += var10;
            }

            if (var15 < var8) {
               float var16 = this.glMultiTexCoord2f.L * (float)(var8 - var15) / (float)this.glMultiTexCoord2f.K;
               OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
               OpenGL.glVertex2i(var15, var13);
               OpenGL.glTexCoord2f(0.0F, 0.0F);
               OpenGL.glVertex2i(var15, var12);
               OpenGL.glTexCoord2f(var16, 0.0F);
               OpenGL.glVertex2i(var8, var12);
               OpenGL.glTexCoord2f(var16, this.glMultiTexCoord2f.N);
               OpenGL.glVertex2i(var8, var13);
            }

            var13 += var11;
         }

         if (var13 < var9) {
            float var20 = this.glMultiTexCoord2f.N * (float)(this.glMultiTexCoord2f.H - (var9 - var13)) / (float)this.glMultiTexCoord2f.H;
            var15 = var1 + this.glMultiTexCoord2f.K;

            int var21;
            for(var21 = var1; var15 <= var8; var21 += var10) {
               OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
               OpenGL.glVertex2i(var21, var13);
               OpenGL.glTexCoord2f(0.0F, var20);
               OpenGL.glVertex2i(var21, var9);
               OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, var20);
               OpenGL.glVertex2i(var15, var9);
               OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
               OpenGL.glVertex2i(var15, var13);
               var15 += var10;
            }

            if (var21 < var8) {
               float var17 = this.glMultiTexCoord2f.L * (float)(var8 - var21) / (float)this.glMultiTexCoord2f.K;
               OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
               OpenGL.glVertex2i(var21, var13);
               OpenGL.glTexCoord2f(0.0F, var20);
               OpenGL.glVertex2i(var21, var9);
               OpenGL.glTexCoord2f(var17, var20);
               OpenGL.glVertex2i(var8, var9);
               OpenGL.glTexCoord2f(var17, this.glMultiTexCoord2f.N);
               OpenGL.glVertex2i(var8, var13);
            }
         }

         OpenGL.glEnd();
         OpenGL.glPopMatrix();
      }

   }

   void method666(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10) {
      float var11;
      float var12;
      if (this.glBegin) {
         var11 = (float)this.method271();
         var12 = (float)this.method626();
         float var13 = (var3 - var1) / var11;
         float var14 = (var4 - var2) / var11;
         float var15 = (var5 - var1) / var12;
         float var16 = (var6 - var2) / var12;
         float var17 = var15 * (float)this.glEnd;
         float var18 = var16 * (float)this.glEnd;
         float var19 = var13 * (float)this.F;
         float var20 = var14 * (float)this.F;
         float var21 = -var13 * (float)this.glPopMatrix;
         float var22 = -var14 * (float)this.glPopMatrix;
         float var23 = -var15 * (float)this.glPixelTransferf;
         float var24 = -var16 * (float)this.glPixelTransferf;
         var1 = var1 + var19 + var17;
         var2 = var2 + var20 + var18;
         var3 = var3 + var21 + var17;
         var4 = var4 + var22 + var18;
         var5 = var5 + var19 + var23;
         var6 = var6 + var20 + var24;
      }

      var11 = var5 + (var3 - var1);
      var12 = var4 + (var6 - var2);
      this.glMultiTexCoord2f.I((var10 & 1) != 0);
      this.glColor4ub.B();
      this.glColor4ub.I((SN)this.glMultiTexCoord2f);
      this.glColor4ub.B(var9);
      this.glColor4ub.I(var7);
      OpenGL.glColor4ub((byte)(var8 >> 16), (byte)(var8 >> 8), (byte)var8, (byte)(var8 >> 24));
      OpenGL.glBegin(7);
      OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
      OpenGL.glVertex2f(var1, var2);
      OpenGL.glTexCoord2f(0.0F, 0.0F);
      OpenGL.glVertex2f(var5, var6);
      OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
      OpenGL.glVertex2f(var11, var12);
      OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
      OpenGL.glVertex2f(var3, var4);
      OpenGL.glEnd();
   }

   void method663(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10) {
      float var11;
      float var12;
      if (this.glBegin) {
         var11 = (float)this.method271();
         var12 = (float)this.method626();
         float var13 = (var3 - var1) / var11;
         float var14 = (var4 - var2) / var11;
         float var15 = (var5 - var1) / var12;
         float var16 = (var6 - var2) / var12;
         float var17 = var15 * (float)this.glEnd;
         float var18 = var16 * (float)this.glEnd;
         float var19 = var13 * (float)this.F;
         float var20 = var14 * (float)this.F;
         float var21 = -var13 * (float)this.glPopMatrix;
         float var22 = -var14 * (float)this.glPopMatrix;
         float var23 = -var15 * (float)this.glPixelTransferf;
         float var24 = -var16 * (float)this.glPixelTransferf;
         var1 = var1 + var19 + var17;
         var2 = var2 + var20 + var18;
         var3 = var3 + var21 + var17;
         var4 = var4 + var22 + var18;
         var5 = var5 + var19 + var23;
         var6 = var6 + var20 + var24;
      }

      var11 = var5 + (var3 - var1);
      var12 = var4 + (var6 - var2);
      this.glMultiTexCoord2f.I((var10 & 1) != 0);
      this.glColor4ub.B();
      this.glColor4ub.I((SN)this.glMultiTexCoord2f);
      this.glColor4ub.B(var9);
      this.glColor4ub.I(var7);
      OpenGL.glColor4ub((byte)(var8 >> 16), (byte)(var8 >> 8), (byte)var8, (byte)(var8 >> 24));
      OpenGL.glBegin(7);
      OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
      OpenGL.glVertex2f(var1, var2);
      OpenGL.glTexCoord2f(0.0F, 0.0F);
      OpenGL.glVertex2f(var5, var6);
      OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
      OpenGL.glVertex2f(var11, var12);
      OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
      OpenGL.glVertex2f(var3, var4);
      OpenGL.glEnd();
   }

   public void method674(int var1, int var2, int var3, int var4, int var5) {
      this.glMultiTexCoord2f.I(false);
      this.glColor4ub.B();
      this.glColor4ub.B(var5);
      OpenGL.glColor4ub((byte)(var4 >> 16), (byte)(var4 >> 8), (byte)var4, (byte)(var4 >> 24));
      var1 += this.F;
      var2 += this.glEnd;
      if (this.aq == null) {
         this.glColor4ub.I((SN)this.glMultiTexCoord2f);
         this.glColor4ub.I(var3);
         OpenGL.glBegin(7);
         OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1, var2);
         OpenGL.glTexCoord2f(0.0F, 0.0F);
         OpenGL.glVertex2i(var1, var2 + this.glMultiTexCoord2f.H);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
         OpenGL.glVertex2i(var1 + this.glMultiTexCoord2f.K, var2 + this.glMultiTexCoord2f.H);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1 + this.glMultiTexCoord2f.K, var2);
         OpenGL.glEnd();
      } else {
         this.F(var3);
         this.aq.I(false);
         OpenGL.glBegin(7);
         OpenGL.glMultiTexCoord2f(33985, 0.0F, this.glMultiTexCoord2f.N);
         OpenGL.glTexCoord2f(0.0F, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1, var2);
         OpenGL.glMultiTexCoord2f(33985, 0.0F, 0.0F);
         OpenGL.glTexCoord2f(0.0F, 0.0F);
         OpenGL.glVertex2i(var1, var2 + this.glMultiTexCoord2f.H);
         OpenGL.glMultiTexCoord2f(33985, this.glMultiTexCoord2f.L, 0.0F);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, 0.0F);
         OpenGL.glVertex2i(var1 + this.glMultiTexCoord2f.K, var2 + this.glMultiTexCoord2f.H);
         OpenGL.glMultiTexCoord2f(33985, this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
         OpenGL.glTexCoord2f(this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
         OpenGL.glVertex2i(var1 + this.glMultiTexCoord2f.K, var2);
         OpenGL.glEnd();
         this.aq();
      }

   }

   void method672(float var1, float var2, float var3, float var4, float var5, float var6, int var7, QJI var8, int var9, int var10) {
      JO var11 = ((RJI)var8).I;
      float var12;
      float var13;
      float var14;
      float var15;
      if (this.glBegin) {
         var12 = (float)this.method271();
         var13 = (float)this.method626();
         var14 = (var3 - var1) / var12;
         var15 = (var4 - var2) / var12;
         float var16 = (var5 - var1) / var13;
         float var17 = (var6 - var2) / var13;
         float var18 = var16 * (float)this.glEnd;
         float var19 = var17 * (float)this.glEnd;
         float var20 = var14 * (float)this.F;
         float var21 = var15 * (float)this.F;
         float var22 = -var14 * (float)this.glPopMatrix;
         float var23 = -var15 * (float)this.glPopMatrix;
         float var24 = -var16 * (float)this.glPixelTransferf;
         float var25 = -var17 * (float)this.glPixelTransferf;
         var1 = var1 + var20 + var18;
         var2 = var2 + var21 + var19;
         var3 = var3 + var22 + var18;
         var4 = var4 + var23 + var19;
         var5 = var5 + var20 + var24;
         var6 = var6 + var21 + var25;
      }

      var12 = var5 + (var3 - var1);
      var13 = var4 + (var6 - var2);
      this.glMultiTexCoord2f.I((var7 & 1) != 0);
      this.glColor4ub.B();
      this.glColor4ub.I((SN)this.glMultiTexCoord2f);
      this.glColor4ub.I(1);
      this.glColor4ub.C(1);
      this.glColor4ub.I((SN)var11);
      this.glColor4ub.Z(7681, 8448);
      this.glColor4ub.I(0, 34168, 768);
      this.glColor4ub.B(1);
      var14 = var11.L / (float)var11.K;
      var15 = var11.N / (float)var11.H;
      OpenGL.glBegin(7);
      OpenGL.glColor3f(1.0F, 1.0F, 1.0F);
      OpenGL.glMultiTexCoord2f(33984, 0.0F, this.glMultiTexCoord2f.N);
      OpenGL.glMultiTexCoord2f(33985, var14 * (var1 - (float)var9), var11.N - var15 * (var2 - (float)var10));
      OpenGL.glVertex2f(var1, var2);
      OpenGL.glMultiTexCoord2f(33984, 0.0F, 0.0F);
      OpenGL.glMultiTexCoord2f(33985, var14 * (var5 - (float)var9), var11.N - var15 * (var6 - (float)var10));
      OpenGL.glVertex2f(var5, var6);
      OpenGL.glMultiTexCoord2f(33984, this.glMultiTexCoord2f.L, 0.0F);
      OpenGL.glMultiTexCoord2f(33985, var14 * (var12 - (float)var9), var11.N - var15 * (var13 - (float)var10));
      OpenGL.glVertex2f(var12, var13);
      OpenGL.glMultiTexCoord2f(33984, this.glMultiTexCoord2f.L, this.glMultiTexCoord2f.N);
      OpenGL.glMultiTexCoord2f(33985, var14 * (var3 - (float)var9), var11.N - var15 * (var4 - (float)var10));
      OpenGL.glVertex2f(var3, var4);
      OpenGL.glEnd();
      this.glColor4ub.I(0, 5890, 768);
      this.glColor4ub.I(0);
      this.glColor4ub.I((SN)null);
      this.glColor4ub.C(0);
   }
}
