public class KR extends GR implements HAI {
   HP PA;
   CX YA;
   GJI append;
   UT i;
   int m;
   byte method4739;
   byte method4755;
   boolean method4784;
   boolean method4787;
   boolean method5017;
   static String R;
   static FP T;

   boolean method4365() {
      if (this.i != null) {
         return !this.i.u();
      } else {
         return true;
      }
   }

   boolean method4399(byte var1) {
      try {
         if (this.i != null) {
            return !this.i.u();
         } else {
            return true;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wq.bf(" + ')');
      }
   }

   boolean method4376(short var1) {
      try {
         return this.i != null ? this.i.i() : false;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wq.be(" + ')');
      }
   }

   public int method4361(int var1) {
      try {
         return this.i != null ? this.i.YA() : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wq.bm(" + ')');
      }
   }

   UT F(GSI var1, int var2, int var3) {
      try {
         if (this.i != null && var1.method5017(this.i.m(), var2) == 0) {
            return this.i;
         } else {
            ZY var4 = this.PA(var1, var2, false, -1045378786);
            return var4 != null ? (UT)var4.I : null;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "wq.by(" + ')');
      }
   }

   public void method37(GSI var1, int var2) {
      try {
         Object var3 = null;
         GJI var4;
         if (this.append == null && this.method5017) {
            ZY var5 = this.PA(var1, 262144, true, -1658395754);
            var4 = (GJI)(var5 != null ? var5.Z : null);
         } else {
            var4 = this.append;
            this.append = null;
         }

         SF var7 = this.I().I;
         if (var4 != null) {
            this.H.I(var4, this.L, (int)var7.I, (int)var7.Z, (boolean[])null, 1462465403);
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "wq.d(" + ')');
      }
   }

   public int method4379() {
      return this.i != null ? this.i.YA() : 0;
   }

   KP method4394(GSI var1, int var2) {
      try {
         if (this.i == null) {
            return null;
         } else {
            LF var3 = var1.method5178();
            var3.I(this.J());
            var3.C((float)this.O, 0.0F, (float)this.P);
            KP var4 = BDI.I(this.method4787, 1295089573);
            this.i.method4739(var3, this.N[0], 0);
            return var4;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "wq.bo(" + ')');
      }
   }

   public int method30(short var1) {
      try {
         return this.method4755;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wq.b(" + ')');
      }
   }

   boolean method4350(GSI var1, int var2, int var3, byte var4) {
      try {
         UT var5 = this.F(var1, 131072, 1991691041);
         if (var5 != null) {
            LF var6 = this.J();
            return var5.method4787(var2, var3, var6, false, 0);
         } else {
            return false;
         }
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "wq.bu(" + ')');
      }
   }

   public int method32(byte var1) {
      try {
         return 2016845759 * this.m;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wq.a(" + ')');
      }
   }

   public HP method4367(GSI var1) {
      SF var2 = this.I().I;
      if (this.PA == null) {
         this.PA = TY.I((int)var2.I, (int)var2.C, (int)var2.Z, this.F(var1, 0, 2120690814), 2092013456);
      }

      return this.PA;
   }

   boolean method4374() {
      if (this.i != null) {
         return !this.i.u();
      } else {
         return true;
      }
   }

   public void method31(byte var1) {
      try {
         if (this.i != null) {
            this.i.method4784();
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wq.p(" + ')');
      }
   }

   public boolean method39(int var1) {
      try {
         return this.method5017;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wq.i(" + ')');
      }
   }

   public void method33(GSI var1, int var2) {
      try {
         Object var3 = null;
         GJI var4;
         if (this.append == null && this.method5017) {
            ZY var5 = this.PA(var1, 262144, true, 443427270);
            var4 = (GJI)(var5 != null ? var5.Z : null);
         } else {
            var4 = this.append;
            this.append = null;
         }

         SF var7 = this.I().I;
         if (var4 != null) {
            this.H.Z(var4, this.L, (int)var7.I, (int)var7.Z, (boolean[])null, -1121841328);
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "wq.k(" + ')');
      }
   }

   public int method29(int var1) {
      try {
         return this.method4739;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wq.f(" + ')');
      }
   }

   public void method43(GSI var1) {
      Object var2 = null;
      GJI var3;
      if (this.append == null && this.method5017) {
         ZY var4 = this.PA(var1, 262144, true, -1081449109);
         var3 = (GJI)(var4 != null ? var4.Z : null);
      } else {
         var3 = this.append;
         this.append = null;
      }

      SF var5 = this.I().I;
      if (var3 != null) {
         this.H.I(var3, this.L, (int)var5.I, (int)var5.Z, (boolean[])null, 206431233);
      }

   }

   public int method36() {
      return this.method4739;
   }

   public int method35() {
      return this.method4739;
   }

   public int method42() {
      return this.method4755;
   }

   public int method38() {
      return this.method4755;
   }

   public void method34() {
      if (this.i != null) {
         this.i.method4784();
      }

   }

   public boolean method41() {
      return this.method5017;
   }

   public void method28(GSI var1) {
      Object var2 = null;
      GJI var3;
      if (this.append == null && this.method5017) {
         ZY var4 = this.PA(var1, 262144, true, 1299260710);
         var3 = (GJI)(var4 != null ? var4.Z : null);
      } else {
         var3 = this.append;
         this.append = null;
      }

      SF var5 = this.I().I;
      if (var3 != null) {
         this.H.Z(var3, this.L, (int)var5.I, (int)var5.Z, (boolean[])null, 2128182901);
      }

   }

   public KR(AP var1, GSI var2, CX var3, KEI var4, int var5, int var6, int var7, int var8, int var9, boolean var10, int var11, int var12, int var13, int var14) {
      super(var1, var7, var8, var9, var5, var6, var11, var12);
      this.YA = var3;
      this.m = var4.Z * 1469074669;
      this.method4784 = var10;
      this.method4755 = (byte)var14;
      this.method4739 = (byte)var13;
      this.method4787 = var4.K * 1532834983 != 0 && !var10;
      this.method5017 = var2.method5082() && var4.CI && !this.method4784 && FW.J.m.C(-208809184) != 0;
      int var15 = 2048;
      if (var4.GI) {
         var15 |= 524288;
      }

      ZY var16 = this.PA(var2, var15, this.method5017, -772904584);
      if (var16 != null) {
         this.i = (UT)var16.I;
         this.append = (GJI)var16.Z;
         if (var4.GI) {
            this.i = this.i.method4755((byte)0, var15, false);
            if (var4.GI) {
               UA var17 = XEI.mI.D(-2114342399);
               this.i.PA(1599271859 * var17.I, var17.Z * 1630923113, -1560648831 * var17.C, -57569897 * var17.B);
            }
         }
      }

      this.I(1, -1063190052);
   }

   public void method44(GSI var1) {
      Object var2 = null;
      GJI var3;
      if (this.append == null && this.method5017) {
         ZY var4 = this.PA(var1, 262144, true, 833087212);
         var3 = (GJI)(var4 != null ? var4.Z : null);
      } else {
         var3 = this.append;
         this.append = null;
      }

      SF var5 = this.I().I;
      if (var3 != null) {
         this.H.I(var3, this.L, (int)var5.I, (int)var5.Z, (boolean[])null, 1342747444);
      }

   }

   public int method45() {
      return 2016845759 * this.m;
   }

   boolean method4353() {
      if (this.i != null) {
         return !this.i.u();
      } else {
         return true;
      }
   }

   public HP method4358(GSI var1, byte var2) {
      try {
         SF var3 = this.I().I;
         if (this.PA == null) {
            this.PA = TY.I((int)var3.I, (int)var3.C, (int)var3.Z, this.F(var1, 0, 1964135899), 2090651504);
         }

         return this.PA;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "wq.bc(" + ')');
      }
   }

   boolean method4369() {
      return this.i != null ? this.i.i() : false;
   }

   public void method40(GSI var1) {
      Object var2 = null;
      GJI var3;
      if (this.append == null && this.method5017) {
         ZY var4 = this.PA(var1, 262144, true, 258900059);
         var3 = (GJI)(var4 != null ? var4.Z : null);
      } else {
         var3 = this.append;
         this.append = null;
      }

      SF var5 = this.I().I;
      if (var3 != null) {
         this.H.I(var3, this.L, (int)var5.I, (int)var5.Z, (boolean[])null, 510453328);
      }

   }

   public HP method4368(GSI var1) {
      SF var2 = this.I().I;
      if (this.PA == null) {
         this.PA = TY.I((int)var2.I, (int)var2.C, (int)var2.Z, this.F(var1, 0, 1878583731), 1989490846);
      }

      return this.PA;
   }

   KP method4370(GSI var1) {
      if (this.i == null) {
         return null;
      } else {
         LF var2 = var1.method5178();
         var2.I(this.J());
         var2.C((float)this.O, 0.0F, (float)this.P);
         KP var3 = BDI.I(this.method4787, 1438144079);
         this.i.method4739(var2, this.N[0], 0);
         return var3;
      }
   }

   void method4371(GSI var1) {
   }

   void method4373(GSI var1) {
   }

   boolean method4372(GSI var1, int var2, int var3) {
      UT var4 = this.F(var1, 131072, 1910114060);
      if (var4 != null) {
         LF var5 = this.J();
         return var4.method4787(var2, var3, var5, false, 0);
      } else {
         return false;
      }
   }

   boolean method4385(GSI var1, int var2, int var3) {
      UT var4 = this.F(var1, 131072, 2092256266);
      if (var4 != null) {
         LF var5 = this.J();
         return var4.method4787(var2, var3, var5, false, 0);
      } else {
         return false;
      }
   }

   boolean method4352(GSI var1, int var2, int var3) {
      UT var4 = this.F(var1, 131072, 2046392588);
      if (var4 != null) {
         LF var5 = this.J();
         return var4.method4787(var2, var3, var5, false, 0);
      } else {
         return false;
      }
   }

   public int method4380() {
      return this.i != null ? this.i.YA() : 0;
   }

   ZY PA(GSI var1, int var2, boolean var3, int var4) {
      try {
         KEI var5 = this.YA.C(2016845759 * this.m);
         YJI var6;
         YJI var7;
         if (this.method4784) {
            var6 = this.H.M[this.L];
            var7 = this.H.K[0];
         } else {
            var6 = this.H.K[this.L];
            if (this.L < 3) {
               var7 = this.H.K[this.L + 1];
            } else {
               var7 = null;
            }
         }

         SF var8 = this.I().I;
         return var5.I(var1, var2, this.method4739, this.method4755, var6, var7, (int)var8.I, (int)var8.C, (int)var8.Z, var3, (DX)null, -911505460);
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "wq.bl(" + ')');
      }
   }

   void method4357(GSI var1, int var2) {
   }

   boolean method4349() {
      return this.i != null ? this.i.i() : false;
   }

   boolean method4383() {
      return this.i != null ? this.i.i() : false;
   }

   boolean method4351() {
      return this.i != null ? this.i.i() : false;
   }

   boolean method4382() {
      return this.i != null ? this.i.i() : false;
   }

   public int method4381() {
      return this.i != null ? this.i.YA() : 0;
   }

   public static void I(int var0) {
      try {
         QW.D = null;
         DDI.G = null;
         LO.B = null;
         GZI.D = null;
         HFI.C = null;
         QII.C = null;
         RR.R = null;
         FT.O = null;
         NBI.B = null;
         UD.K = null;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "wq.ak(" + ')');
      }
   }

   public static int[] I(int var0, int var1, int var2, int var3, int var4, float var5, boolean var6, int var7) {
      try {
         int[] var8 = new int[var0];
         CK var9 = new CK();
         var9.W = -1333197873 * var1;
         var9.c = var6;
         var9.i = 1143174821 * var2;
         var9.Y = 2124139087 * var3;
         var9.z = -1820512295 * var4;
         var9.X = 52875281 * (int)(4096.0F * var5);
         var9.B(-369839691);
         WJ.I(var0, 1, (byte)24);
         var9.I(0, (int[])var8, (int)-2040071008);
         return var8;
      } catch (RuntimeException var10) {
         throw DQ.I(var10, "wq.bf(" + ')');
      }
   }

   static void I(int var0, int var1, int var2, int var3, int var4, int var5, int var6) {
      try {
         int var7 = var5 + var2;
         int var8 = var3 - var5;

         int var9;
         for(var9 = var2; var9 < var7; ++var9) {
            DFI.I(DT.I[var9], var0, var1, var4, 1081395615);
         }

         for(var9 = var3; var9 > var8; --var9) {
            DFI.I(DT.I[var9], var0, var1, var4, -1329971917);
         }

         var9 = var0 + var5;
         int var10 = var1 - var5;

         for(int var11 = var7; var11 <= var8; ++var11) {
            int[] var12 = DT.I[var11];
            DFI.I(var12, var0, var9, var4, -1691383948);
            DFI.I(var12, var10, var1, var4, -1133427569);
         }

      } catch (RuntimeException var13) {
         throw DQ.I(var13, "wq.y(" + ')');
      }
   }

   static void I(int var0, byte var1) {
      try {
         EV.Z = -249626013 * var0;
         JQ var2 = GY.I;
         synchronized(GY.I) {
            GY.I.I();
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "wq.f(" + ')');
      }
   }
}
