public class DDI {
   static int I;
   static int Z;
   static int C;
   static int B;
   static int D;
   static LZI F;
   static int J;
   static int S;
   static int A;
   static IBI[] E;
   public static IBI G;

   DDI() throws Throwable {
      throw new Error();
   }

   public static int I(int var0) {
      try {
         return WA.B.I(1397176668);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "d.p(" + ')');
      }
   }

   static void I(byte[] var0, int var1) {
      try {
         REI var2 = new REI(var0);

         while(true) {
            int var3 = var2.I();
            if (var3 == 0) {
               if (var1 == -1819630218) {
                  throw new IllegalStateException();
               }

               return;
            }

            if (1 == var3) {
               int[] var4 = XQ.A = new int[6];
               var4[0] = var2.C();
               var4[1] = var2.C();
               var4[2] = var2.C();
               var4[3] = var2.C();
               var4[4] = var2.C();
               var4[5] = var2.C();
            }
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "d.u(" + ')');
      }
   }

   static VO[] Z(int var0) {
      try {
         return new VO[]{VO.Z, VO.I};
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "d.a(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         GN.I(var3, var4, var0, (byte)5);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "d.dy(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.T.Z((byte)0) ? 1 : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "d.anu(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.O.Z((byte)-40) ? 1 : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "d.ang(" + ')');
      }
   }

   static final void B(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = KD.I((byte)89);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "d.ajt(" + ')');
      }
   }

   public static void I(int var0, int var1, int var2, boolean var3, int var4) {
      try {
         if (FW.J.d.I(-1456138007) != 0) {
            GN.j = FW.J.d.I(-993679742) * 485258093;
            WR.I(0, true, 622850291);
         } else {
            QW.I(false, 1336561252);
         }

         GN.e = -1801430445 * var1;
         GN.b = var2 * -1505298155;
         GN.h = var3;
         GN.I(var0);
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "d.cd(" + ')');
      }
   }

   static void I(int var0, int var1, int var2, int var3, int var4) {
      try {
         float var5 = (float)GN.Q / (float)GN.P;
         int var6 = var2;
         int var7 = var3;
         if (var5 < 1.0F) {
            var7 = (int)(var5 * (float)var2);
         } else {
            var6 = (int)((float)var3 / var5);
         }

         var0 -= (var2 - var6) / 2;
         var1 -= (var3 - var7) / 2;
         RDI.D = -2076584633 * (GN.P * var0 / var6);
         GT.F = -435591305 * (GN.Q - GN.Q * var1 / var7);
         GN.k = 433609607;
         GN.s = 789877945;
         OF.C(65536);
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "d.cv(" + ')');
      }
   }

   static void I(int var0, int var1, HSI var2, V var3, int var4, int var5, int var6) {
      try {
         UB[] var7 = XEI.XB;

         for(int var8 = 0; var8 < var7.length; ++var8) {
            UB var9 = var7[var8];
            if (var9 != null && var9.G * 958933333 != 0 && XEI.kB * 443738891 % 20 < 10) {
               int var13;
               if (1 == 958933333 * var9.G) {
                  QG var10 = (QG)XEI.UI.I((long)(-841622081 * var9.I));
                  if (var10 != null) {
                     GEI var11 = (GEI)var10.J;
                     SF var12 = var11.I().I;
                     var13 = (int)var12.I / 128 - var0 / 128;
                     int var14 = (int)var12.Z / 128 - var1 / 128;
                     EU.I(var2, var3, var4, var5, var13, var14, -92466201 * var9.C, 360000L);
                  }
               }

               if (var9.G * 958933333 == 2) {
                  int var16 = var9.D * -1338192389 / 128 - var0 / 128;
                  int var18 = var9.F * 1018128075 / 128 - var1 / 128;
                  long var20 = (long)(var9.Z * 2140036693 << 7);
                  var20 *= var20;
                  EU.I(var2, var3, var4, var5, var16, var18, var9.C * -92466201, var20);
               }

               if (10 == 958933333 * var9.G && -841622081 * var9.I >= 0 && var9.I * -841622081 < XEI.MC.length) {
                  PEI var17 = XEI.MC[-841622081 * var9.I];
                  if (var17 != null) {
                     SF var19 = var17.I().I;
                     int var21 = (int)var19.I / 128 - var0 / 128;
                     var13 = (int)var19.Z / 128 - var1 / 128;
                     EU.I(var2, var3, var4, var5, var21, var13, var9.C * -92466201, 360000L);
                  }
               }
            }
         }

      } catch (RuntimeException var15) {
         throw DQ.I(var15, "d.s(" + ')');
      }
   }
}
