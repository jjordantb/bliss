public class HBI {
   FEI B;
   JQ I = new JQ(256);
   MJI Z;

   FO I(int var1) {
      return this.B(var1, -1);
   }

   FO B(int var1, int var2) {
      Object var3 = this.I.I((long)var1);
      if (var3 != null) {
         return (FO)var3;
      } else if (!this.B.method170(var1, (short)25920)) {
         return null;
      } else {
         WCI var4 = this.B.method174(var1, 107897040);
         if (var2 == -1) {
            var2 = var4.Z ? 64 : this.Z.s;
         }

         FO var5;
         if (var4.P && this.Z.method5054()) {
            float[] var7 = this.B.method181(var1, 0.7F, var2, var2, false, (byte)-119);
            var5 = new FO(this.Z, 3553, YCI.Z, SDI.I, var2, var2, var4.L != 0, var7, YCI.Z);
         } else {
            int[] var6;
            if (var4.F * -2138060883 != 2 && YH.C(var4.J, -769385379)) {
               var6 = this.B.method171(var1, 0.7F, var2, var2, true, 1090878298);
            } else {
               var6 = this.B.method172(var1, 0.7F, var2, var2, false, (byte)2);
            }

            var5 = new FO(this.Z, 3553, var2, var2, var4.L != 0, var6, 0, 0, false);
         }

         var5.I(var4.N, var4.O);
         this.I.I(var5, (long)var1);
         return var5;
      }
   }

   void I() {
      this.I.I(5, -56778652);
   }

   void Z() {
      this.I.I();
   }

   HBI(MJI var1, FEI var2) {
      this.Z = var1;
      this.B = var2;
   }
}
