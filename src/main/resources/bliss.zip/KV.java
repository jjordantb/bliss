public class KV {
   KV() throws Throwable {
      throw new Error();
   }

   static final void I(OU var0, byte var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         KJ.I(var3, var4, var0, -166663467);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "rl.nn(" + ')');
      }
   }
}
