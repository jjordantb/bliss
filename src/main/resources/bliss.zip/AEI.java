public class AEI implements BAI {
   int B;
   public static AEI I = new AEI("LOCAL", "", 4);
   public static AEI Z = new AEI("WTI", "", 5);
   public static AEI C = new AEI("WTQA", "", 2);
   public static AEI D = new AEI("WTRC", "", 1);
   static AEI F = new AEI("INTBETA", "", 6);
   public static AEI J = new AEI("LIVE", "", 0);
   String append;
   static int S;
   public static AEI A = new AEI("WTWIP", "", 3);
   static IBI[] E;
   static int G;

   static {
      I(-2140357445);
   }

   AEI(String var1, String var2, int var3) {
      this.append = var1;
      this.B = var3 * 143252701;
   }

   public static boolean I(AEI var0, int var1) {
      try {
         return D == var0 || var0 == C || A == var0 || Z == var0 || F == var0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "qq.b(" + ')');
      }
   }

   public int method242(int var1) {
      try {
         return this.B * -504243339;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "qq.f(" + ')');
      }
   }

   public int method243() {
      return this.B * -504243339;
   }

   public static final int I(int var0, int var1, int var2, int var3) {
      try {
         if (var2 > 243) {
            var1 >>= 4;
         } else if (var2 > 217) {
            var1 >>= 3;
         } else if (var2 > 192) {
            var1 >>= 2;
         } else if (var2 > 179) {
            var1 >>= 1;
         }

         return (var2 >> 1) + ((var0 & 255) >> 2 << 10) + (var1 >> 5 << 7);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "qq.s(" + ')');
      }
   }

   public int method244() {
      return this.B * -504243339;
   }

   static void I(byte var0) {
      try {
         UB.A.I();
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "qq.b(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         var0.J -= -783761378;
         if (var0.H[var0.J * 681479919] >= var0.H[1 + 681479919 * var0.J]) {
            var0.i += var0.X[var0.i * 1883543357] * 286750741;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "qq.al(" + ')');
      }
   }

   public static AEI[] I(int var0) {
      try {
         return new AEI[]{F, I, Z, J, D, A, C};
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "qq.a(" + ')');
      }
   }

   public static KY I(SEI var0, REI var1, byte var2) {
      try {
         KY var3 = new KY(var0);
         int var4 = var1.I();
         boolean var5 = (var4 & 1) != 0;
         boolean var6 = (var4 & 2) != 0;
         boolean var7 = (var4 & 4) != 0;
         boolean var8 = (var4 & 8) != 0;
         if (var5) {
            var3.C[0] = var1.Y(1235052657);
            var3.B[0] = var1.Y(1235052657);
            if (-1 != 34210967 * var0.e || -1 != -1284247975 * var0.k) {
               var3.C[1] = var1.Y(1235052657);
               var3.B[1] = var1.Y(1235052657);
            }

            if (var0.v * 1313278521 != -1 || -1767718263 * var0.h != -1) {
               var3.C[2] = var1.Y(1235052657);
               var3.B[2] = var1.Y(1235052657);
            }
         }

         if (var6) {
            var3.I[0] = var1.Y(1235052657);
            var3.D[0] = var1.Y(1235052657);
            if (86274879 * var0.m != -1 || var0.y * 1578724433 != -1) {
               var3.I[1] = var1.Y(1235052657);
               var3.D[1] = var1.Y(1235052657);
            }
         }

         int var9;
         int[] var10;
         int var11;
         if (var7) {
            var9 = var1.C();
            var10 = new int[]{var9 & 15, var9 >> 4 & 15, var9 >> 8 & 15, var9 >> 12 & 15};

            for(var11 = 0; var11 < 4; ++var11) {
               if (var10[var11] != 15) {
                  var3.J[var10[var11]] = (short)var1.C();
               }
            }
         }

         if (var8) {
            var9 = var1.I();
            var10 = new int[]{var9 & 15, var9 >> 4 & 15};

            for(var11 = 0; var11 < 2; ++var11) {
               if (15 != var10[var11]) {
                  var3.S[var10[var11]] = (short)var1.C();
               }
            }
         }

         return var3;
      } catch (RuntimeException var12) {
         throw DQ.I(var12, "qq.a(" + ')');
      }
   }

   static void I(int var0, int var1, int var2, int var3, int var4, int var5, int var6, byte var7) {
      try {
         int var8 = HY.I(var2, 1155384281 * DT.C, -1062447355 * DT.B, -1212608691);
         int var9 = HY.I(var3, DT.C * 1155384281, DT.B * -1062447355, -1212608691);
         int var10 = HY.I(var0, DT.D * -1424479739, 1135094847 * DT.Z, -1212608691);
         int var11 = HY.I(var1, -1424479739 * DT.D, DT.Z * 1135094847, -1212608691);
         int var12 = HY.I(var2 + var6, 1155384281 * DT.C, DT.B * -1062447355, -1212608691);
         int var13 = HY.I(var3 - var6, DT.C * 1155384281, -1062447355 * DT.B, -1212608691);

         int var14;
         for(var14 = var8; var14 < var12; ++var14) {
            DFI.I(DT.I[var14], var10, var11, var5, -1884573988);
         }

         for(var14 = var9; var14 > var13; --var14) {
            DFI.I(DT.I[var14], var10, var11, var5, 712014890);
         }

         var14 = HY.I(var0 + var6, -1424479739 * DT.D, DT.Z * 1135094847, -1212608691);
         int var15 = HY.I(var1 - var6, DT.D * -1424479739, DT.Z * 1135094847, -1212608691);

         for(int var16 = var12; var16 <= var13; ++var16) {
            int[] var17 = DT.I[var16];
            DFI.I(var17, var10, var14, var5, -665045806);
            DFI.I(var17, var14, var15, var4, -1572233497);
            DFI.I(var17, var15, var11, var5, -2046400935);
         }

      } catch (RuntimeException var18) {
         throw DQ.I(var18, "qq.q(" + ')');
      }
   }

   static void I(YK var0, int var1, int var2, short var3) {
      try {
         if (var0 != null && FX.K.I != var0) {
            int var4 = -887503319 * var0.H;
            int var5 = var0.O * -502720623;
            int var6 = 946432351 * var0.N;
            int var7 = (int)(var0.M * 2236412381003659263L);
            long var8 = 2236412381003659263L * var0.M;
            if (var6 >= 2000) {
               var6 -= 2000;
            }

            XP var10 = XEI.mI.I(681479919);
            if (23 == var6) {
               if (1806357379 * XEI.QC > 0 && BX.I(1267311211)) {
                  XY.I(UA.F.K, var4 + -1760580017 * var10.I, var5 + var10.Z * 283514611, 2043472934);
               } else {
                  if (Loader.usingRS) {
                     PK var11 = EA.Z(var4, var5, var7);
                     if (1 == var7) {
                        var11.J.F(-1);
                        var11.J.F(-1);
                        var11.J.Z((int)XEI.qD, 16711935);
                        var11.J.F(57);
                        var11.J.F(1227356013 * XEI.GC);
                        var11.J.F(356727603 * XEI.NZ);
                        var11.J.F(89);
                        SF var12 = UA.F.I().I;
                        var11.J.Z((int)var12.I, 16711935);
                        var11.J.Z((int)var12.Z, 16711935);
                        var11.J.F(63);
                     } else {
                        XEI.uZ = var1 * 143636043;
                        XEI.vZ = var2 * 381532777;
                        XEI.MZ = 277162405;
                        XEI.wZ = 0;
                     }

                     XEI.eI.I(var11, (byte)-115);
                  } else {
                     EA.I(var7, EQ.I(var4, var5, (short)808));
                     if (var7 == 0) {
                        XEI.uZ = var1 * 143636043;
                        XEI.vZ = var2 * 381532777;
                        XEI.MZ = 277162405;
                        XEI.wZ = 0;
                     }
                  }

                  BFI.I(var4, var5, true, EQ.I(var4, var5, (short)808), -1776617382);
               }
            }

            MEI var26 = null;
            if (var6 == 18) {
               var26 = MEI.E;
            } else if (var6 == 19) {
               var26 = MEI.FI;
            } else if (var6 == 20) {
               var26 = MEI.b;
            } else if (21 == var6) {
               var26 = MEI.GI;
            } else if (22 == var6) {
               var26 = MEI.r;
            } else if (1004 == var6) {
               var26 = MEI.xI;
            }

            PK var27;
            if (var26 != null) {
               if (var26 != MEI.xI) {
                  EA.I(NA.I(var4, var5, 1, 1, 1978833308));
               }

               XEI.uZ = var1 * 143636043;
               XEI.vZ = var2 * 381532777;
               XEI.MZ = 554324810;
               XEI.wZ = 0;
               var27 = GB.I(var26, XEI.eI.Z, (byte)23);
               var27.J.Z(283514611 * var10.Z + var5, 16711935);
               var27.J.H(var4 + -1760580017 * var10.I, 1653379787);
               var27.J.Z(var7, 16711935);
               var27.J.J(IC.I(984220338) ? 1 : 0, (byte)1);
               XEI.eI.I(var27, (byte)-56);
               ET.I(var4, var5, (byte)-67);
            }

            if (59 == var6) {
               XEI.uZ = 143636043 * var1;
               XEI.vZ = 381532777 * var2;
               XEI.MZ = 277162405;
               XEI.wZ = 0;
               var27 = GB.I(MEI.oI, XEI.eI.Z, (byte)6);
               var27.J.B(1262526353 * LT.D, 969641873);
               var27.J.Z(392084321 * XEI.tC, 16711935);
               var27.J.Z(var10.Z * 283514611 + var5, 16711935);
               var27.J.W(XEI.FD * 1408085039);
               var27.J.H(var10.I * -1760580017 + var4, 1993411127);
               XEI.eI.I(var27, (byte)-125);
               BFI.I(var4, var5, true, EQ.I(var4, var5, (short)808), -1460658515);
            }

            if (var6 == 57 || var6 == 1007) {
               GN.I(var7, var5, var4, var0.G, 400950689);
            }

            if (1008 == var6 || 1009 == var6 || var6 == 1010 || 1011 == var6 || var6 == 1012) {
               HY.Z(var6, var7, var4, 1889973846);
            }

            int var18;
            int var19;
            PK var43;
            if (2 == var6) {
               int var28 = (int)var8 >> 14 & 31;
               int var13 = (int)var8 >> 20 & 3;
               int var14 = (int)(var8 >>> 32) & Integer.MAX_VALUE;
               RW var15 = (RW)IW.I(QP.I(114624527), var28, (byte)2);
               LEI var16;
               if (RW.T != var15 && RW.L != var15 && RW.R != var15) {
                  if (KFI.Z(-1976050083 * var15.V, (byte)28)) {
                     var16 = PP.I(var4, var5, 0, 0, var15, var13, 740164949);
                  } else {
                     var16 = ID.I(var4, var5, 0, 0, var15, var13, (byte)-22);
                  }
               } else {
                  KEI var17 = XEI.mI.E(-1208362615).C(var14);
                  if (var13 != 0 && var13 != 2) {
                     var18 = -565161399 * var17.L;
                     var19 = var17.N * -1125834887;
                  } else {
                     var18 = -1125834887 * var17.N;
                     var19 = -565161399 * var17.L;
                  }

                  var16 = PP.I(var4, var5, var18, var19, RW.W, 0, 1300552038);
               }

               EA.I(var16);
               XEI.uZ = 143636043 * var1;
               XEI.vZ = var2 * 381532777;
               XEI.MZ = 554324810;
               XEI.wZ = 0;
               var43 = GB.I(MEI.h, XEI.eI.Z, (byte)52);
               var43.J.J(IC.I(-427290804) ? 1 : 0, (byte)1);
               var43.J.N(XEI.FD * 1408085039);
               var43.J.N(283514611 * var10.Z + var5);
               var43.J.Q((int)(var8 >>> 32) & Integer.MAX_VALUE);
               var43.J.B(1262526353 * LT.D, 671195475);
               var43.J.H(XEI.tC * 392084321, 462918069);
               var43.J.W(var4 + -1760580017 * var10.I);
               var43.J.F(var13);
               XEI.eI.I(var43, (byte)-39);
               XFI.I(var4, var5, var8);
            }

            if (var6 == 30 && XEI.g == null) {
               V.Z(var5, var4, 1723723267);
               XEI.g = LZ.I(var5, var4, -156511736);
               VEI.I(XEI.g, 194587581);
            }

            MEI var29 = null;
            if (var6 == 44) {
               var29 = MEI.x;
            } else if (var6 == 45) {
               var29 = MEI.t;
            } else if (var6 == 46) {
               var29 = MEI.RI;
            } else if (var6 == 47) {
               var29 = MEI.P;
            } else if (48 == var6) {
               var29 = MEI.YI;
            } else if (var6 == 49) {
               var29 = MEI.w;
            } else if (50 == var6) {
               var29 = MEI.HI;
            } else if (51 == var6) {
               var29 = MEI.sI;
            } else if (var6 == 52) {
               var29 = MEI.DI;
            } else if (var6 == 53) {
               var29 = MEI.S;
            }

            if (var29 != null) {
               PEI var30 = XEI.MC[var7];
               if (var30 != null) {
                  EA.I(CP.I(var30.YI[0], var30.v[0], var30.S(), var30.S(), 0, (byte)13));
                  XEI.uZ = var1 * 143636043;
                  XEI.vZ = 381532777 * var2;
                  XEI.MZ = 554324810;
                  XEI.wZ = 0;
                  PK var32 = GB.I(var29, XEI.eI.Z, (byte)74);
                  var32.J.F(IC.I(1625676244) ? 1 : 0);
                  var32.J.N(var7);
                  XEI.eI.I(var32, (byte)-105);
                  BFI.I(var30.YI[0], var30.v[0], true, CP.I(var30.YI[0], var30.v[0], var30.S(), var30.S(), 0, (byte)13), 278987907);
               }
            }

            PK var31;
            if (var6 == 16) {
               XEI.uZ = 143636043 * var1;
               XEI.vZ = 381532777 * var2;
               XEI.MZ = 554324810;
               XEI.wZ = 0;
               var31 = GB.I(MEI.ZZ, XEI.eI.Z, (byte)82);
               var31.J.Z(1408085039 * XEI.FD, 16711935);
               var31.J.Z(UA.F.W * 1888274983, 16711935);
               var31.J.Q(LT.D * 1262526353);
               var31.J.N(XEI.tC * 392084321);
               var31.J.J(IC.I(-1804963392) ? 1 : 0, (byte)1);
               XEI.eI.I(var31, (byte)-113);
            }

            if (var6 == 17) {
               XEI.uZ = 143636043 * var1;
               XEI.vZ = var2 * 381532777;
               XEI.MZ = 554324810;
               XEI.wZ = 0;
               var31 = GB.I(MEI.PI, XEI.eI.Z, (byte)15);
               var31.J.N(1408085039 * XEI.FD);
               var31.J.N(var4 + var10.I * -1760580017);
               var31.J.W(283514611 * var10.Z + var5);
               var31.J.D(1262526353 * LT.D, (byte)1);
               var31.J.W(XEI.tC * 392084321);
               var31.J.N(var7);
               XEI.eI.I(var31, (byte)-59);
               ET.I(var4, var5, (byte)-97);
            }

            if (58 == var6) {
               HSI var33 = LZ.I(var5, var4, -156511736);
               if (var33 != null) {
                  LW.I(var33, 1371871585);
               }
            }

            MEI var34 = null;
            if (9 == var6) {
               var34 = MEI.f;
            } else if (var6 == 10) {
               var34 = MEI.T;
            } else if (11 == var6) {
               var34 = MEI.wI;
            } else if (12 == var6) {
               var34 = MEI.k;
            } else if (var6 == 13) {
               var34 = MEI.jI;
            } else if (var6 == 1003) {
               var34 = MEI.LI;
            }

            PK var44;
            if (var34 != null) {
               QG var35 = (QG)XEI.UI.I((long)var7);
               if (var35 != null) {
                  GEI var37 = (GEI)var35.J;
                  if (var34 != MEI.LI) {
                     EA.I(CP.I(var37.YI[0], var37.v[0], var37.S(), var37.S(), 0, (byte)-51));
                  }

                  XEI.uZ = 143636043 * var1;
                  XEI.vZ = var2 * 381532777;
                  XEI.MZ = 554324810;
                  XEI.wZ = 0;
                  var44 = GB.I(var34, XEI.eI.Z, (byte)15);
                  var44.J.W(var7);
                  var44.J.J(IC.I(1824393579) ? 1 : 0, (byte)1);
                  XEI.eI.I(var44, (byte)-120);
                  BFI.I(var37.YI[0], var37.v[0], true, CP.I(var37.YI[0], var37.v[0], var37.S(), var37.S(), 0, (byte)-51), -1636676956);
               }
            }

            MEI var36 = null;
            if (3 == var6) {
               var36 = MEI.i;
            } else if (4 == var6) {
               var36 = MEI.SI;
            } else if (5 == var6) {
               var36 = MEI.m;
            } else if (6 == var6) {
               var36 = MEI.W;
            } else if (1001 == var6) {
               var36 = MEI.R;
            } else if (1002 == var6) {
               var36 = MEI.Y;
            }

            if (var36 != null) {
               XEI.uZ = 143636043 * var1;
               XEI.vZ = var2 * 381532777;
               XEI.MZ = 554324810;
               XEI.wZ = 0;
               int var38 = (int)var8 >> 20 & 3;
               if (MEI.Y != var36) {
                  int var45 = (int)var8 >> 14 & 31;
                  int var46 = (int)(var8 >>> 32) & Integer.MAX_VALUE;
                  var18 = var4;
                  var19 = var5;
                  switch(var46) {
                  case 20211:
                     var4 = 2539 - var10.I * -1760580017;
                     var5 = 3545 - var10.Z * 283514611;
                     break;
                  case 43526:
                     var5 = 3553 - var10.Z * 283514611;
                     break;
                  case 43587:
                     var4 = 2533 - var10.I * -1760580017;
                     var5 = 3547 - var10.Z * 283514611;
                     break;
                  case 43597:
                     var4 = 2537 - var10.I * -1760580017;
                     var5 = 3546 - var10.Z * 283514611;
                     break;
                  case 64696:
                     var4 = 3005 - var10.I * -1760580017;
                     var5 = 3954 - var10.Z * 283514611;
                     break;
                  case 65362:
                     var4 = 3004 - var10.I * -1760580017;
                     var5 = 3938 - var10.Z * 283514611;
                     break;
                  case 69377:
                     var4 = 2487 - var10.I * -1760580017;
                     var5 = 3431 - var10.Z * 283514611;
                     break;
                  case 69378:
                     var4 = 2483 - var10.I * -1760580017;
                     var5 = 3431 - var10.Z * 283514611;
                  }

                  RW var20 = (RW)IW.I(QP.I(114624527), var45, (byte)2);
                  LEI var21;
                  if (RW.T != var20 && RW.L != var20 && RW.R != var20) {
                     if (KFI.Z(-1976050083 * var20.V, (byte)28)) {
                        var21 = PP.I(var4, var5, 0, 0, var20, var38, 740164949);
                     } else {
                        var21 = ID.I(var4, var5, 0, 0, var20, var38, (byte)-22);
                     }
                  } else {
                     KEI var22 = XEI.mI.E(-1208362615).C(var46);
                     int var23;
                     int var24;
                     if (var38 != 0 && var38 != 2) {
                        var23 = -565161399 * var22.L;
                        var24 = var22.N * -1125834887;
                     } else {
                        var23 = -1125834887 * var22.N;
                        var24 = -565161399 * var22.L;
                     }

                     var21 = PP.I(var4, var5, var23, var24, RW.W, 0, 1300552038);
                  }

                  EA.I(var21);
                  var4 = var18;
                  var5 = var19;
               }

               var44 = GB.I(var36, XEI.eI.Z, (byte)94);
               var44.J.A(IC.I(1030396767) ? 1 : 0, 1999137832);
               var44.J.D((int)(var8 >>> 32) & Integer.MAX_VALUE, (byte)1);
               var44.J.H(var4 + var10.I * -1760580017, 1077977138);
               var44.J.N(var10.Z * 283514611 + var5);
               var44.J.F(var38);
               XEI.eI.I(var44, (byte)-13);
               XFI.I(var4, var5, var8);
            }

            if (8 == var6) {
               QG var39 = (QG)XEI.UI.I((long)var7);
               if (var39 != null) {
                  GEI var47 = (GEI)var39.J;
                  EA.I(CP.I(var47.YI[0], var47.v[0], var47.S(), var47.S(), 0, (byte)-81));
                  XEI.uZ = 143636043 * var1;
                  XEI.vZ = var2 * 381532777;
                  XEI.MZ = 554324810;
                  XEI.wZ = 0;
                  var43 = GB.I(MEI.A, XEI.eI.Z, (byte)103);
                  var43.J.F(IC.I(-510062351) ? 1 : 0);
                  var43.J.B(1262526353 * LT.D, -828026807);
                  var43.J.H(var7, 1218473206);
                  var43.J.N(XEI.tC * 392084321);
                  var43.J.H(1408085039 * XEI.FD, 249731045);
                  XEI.eI.I(var43, (byte)-11);
                  BFI.I(var47.YI[0], var47.v[0], true, CP.I(var47.YI[0], var47.v[0], var47.S(), var47.S(), 0, (byte)-81), 420897053);
               }
            }

            if (25 == var6) {
               HSI var40 = LZ.I(var5, var4, -156511736);
               if (var40 != null) {
                  PZ.Z((byte)4);
                  OL var48 = XEI.I(var40);
                  TZ.I(var40, var48.C((byte)-122), var48.J * -1133219011, 1387537939);
                  XEI.vC = QFI.I(var40, -447348156);
                  if (XEI.vC == null) {
                     XEI.vC = "Null";
                  }

                  XEI.TZ = var40.wI + RA.I(16777215, -1652576288);
               }
            } else {
               if (15 == var6) {
                  PEI var41 = XEI.MC[var7];
                  if (var41 != null) {
                     EA.I(CP.I(var41.YI[0], var41.v[0], var41.S(), var41.S(), 0, (byte)-81));
                     XEI.uZ = var1 * 143636043;
                     XEI.vZ = var2 * 381532777;
                     XEI.MZ = 554324810;
                     XEI.wZ = 0;
                     var44 = GB.I(MEI.ZZ, XEI.eI.Z, (byte)92);
                     var44.J.Z(XEI.FD * 1408085039, 16711935);
                     var44.J.Z(var7, 16711935);
                     var44.J.Q(LT.D * 1262526353);
                     var44.J.N(392084321 * XEI.tC);
                     var44.J.J(IC.I(1486448273) ? 1 : 0, (byte)1);
                     XEI.eI.I(var44, (byte)-120);
                     BFI.I(var41.YI[0], var41.v[0], true, CP.I(var41.YI[0], var41.v[0], var41.S(), var41.S(), 0, (byte)-81), -1518106468);
                  }
               }

               if (var6 == 60) {
                  if (XEI.QC * 1806357379 > 0 && BX.I(838408640)) {
                     XY.I(UA.F.K, var10.I * -1760580017 + var4, 283514611 * var10.Z + var5, 1886787992);
                  } else {
                     XEI.uZ = var1 * 143636043;
                     XEI.vZ = 381532777 * var2;
                     XEI.MZ = 277162405;
                     XEI.wZ = 0;
                     PK var42 = GB.I(MEI.hI, XEI.eI.Z, (byte)98);
                     var42.J.Z(var10.Z * 283514611 + var5, 16711935);
                     var42.J.W(-1760580017 * var10.I + var4);
                     XEI.eI.I(var42, (byte)-43);
                  }
               }

               if (XEI.rC) {
                  PZ.Z((byte)4);
               }

               if (CJ.C != null && -2018194505 * XEI.yZ == 0) {
                  VEI.I(CJ.C, 1534658392);
               }
            }
         }

      } catch (RuntimeException var25) {
         throw DQ.I(var25, "qq.bs(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = -1372893999 * TQ.B;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "qq.aho(" + ')');
      }
   }
}
