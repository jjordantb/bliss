public class KO {
   int[] I;
   byte[] Z;
   int C;
   byte B;
   byte D;
   byte F;
   byte J;

   KO(int var1, int var2, int var3, int var4, int var5, int[] var6, byte[] var7) {
      this.D = (byte)var1;
      this.F = (byte)var2;
      this.C = var3;
      this.B = (byte)var4;
      this.J = (byte)var5;
      this.I = var6;
      this.Z = var7;
   }
}
