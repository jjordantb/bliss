public final class HX {
   byte[] I;
   int Z = 16;
   int append = 258;
   int equals = 6;
   int[][] C;
   int method2343 = 18002;
   int B;
   int D;
   int F;
   int method3860 = 4096;
   int J;
   int S;
   int A;
   byte[][] E;
   byte[] G;
   int H;
   int K;
   int L;
   int M;
   int N;
   int O;
   int[] P;
   int method5176 = 50;
   int[] Q;
   static int[] R;
   int T;
   byte[] U;
   boolean[] V;
   byte[] W;
   int[][] X;
   int[] Y;
   byte[] i;
   byte[] z;
   int[] c;
   byte b;
   int d;
   int[][] f;
   boolean[] j;
   int s;
   public static KJ a;

   HX() {
      this.Z = 16;
      this.append = 258;
      this.equals = 6;
      this.method5176 = 50;
      this.method2343 = 18002;
      this.D = 0;
      this.J = 0;
      this.P = new int[256];
      this.Q = new int[257];
      this.j = new boolean[256];
      this.V = new boolean[16];
      this.W = new byte[256];
      this.z = new byte[4096];
      this.c = new int[16];
      this.i = new byte[18002];
      this.U = new byte[18002];
      this.E = new byte[6][258];
      this.X = new int[6][258];
      this.C = new int[6][258];
      this.f = new int[6][258];
      this.Y = new int[6];
   }

   public static final void I(String var0, int var1) {
      try {
         if (var0 != null) {
            if ((-1054937867 * XEI.kD < 200 || XEI.OC) && -1054937867 * XEI.kD < 200) {
               String var2 = BB.I((CharSequence)var0, 554575211);
               if (var2 != null) {
                  int var3;
                  String var4;
                  String var5;
                  for(var3 = 0; var3 < XEI.kD * -1054937867; ++var3) {
                     var4 = BB.I((CharSequence)XEI.cI[var3], 460678269);
                     if (var4 != null && var4.equals(var2)) {
                        OS.I(4, var0 + VEI.jZ.I(WO.U, -875414210), (byte)-72);
                        return;
                     }

                     if (XEI.nD[var3] != null) {
                        var5 = BB.I((CharSequence)XEI.nD[var3], -1697709934);
                        if (var5 != null && var5.equals(var2)) {
                           OS.I(4, var0 + VEI.jZ.I(WO.U, -875414210), (byte)-22);
                           return;
                        }
                     }
                  }

                  for(var3 = 0; var3 < -548972447 * XEI.uD; ++var3) {
                     var4 = BB.I((CharSequence)XEI.OB[var3], 629913933);
                     if (var4 != null && var4.equals(var2)) {
                        OS.I(4, VEI.kZ.I(WO.U, -875414210) + var0 + VEI.lZ.I(WO.U, -875414210), (byte)-89);
                        return;
                     }

                     if (XEI.wD[var3] != null) {
                        var5 = BB.I((CharSequence)XEI.wD[var3], -1007795446);
                        if (var5 != null && var5.equals(var2)) {
                           OS.I(4, VEI.kZ.I(WO.U, -875414210) + var0 + VEI.lZ.I(WO.U, -875414210), (byte)-109);
                           return;
                        }
                     }
                  }

                  if (BB.I((CharSequence)UA.F.kI, -712250197).equals(var2)) {
                     OS.I(4, VEI.cZ.I(WO.U, -875414210), (byte)-34);
                  } else {
                     VJ var7 = XW.I((short)512);
                     PK var8 = GB.I(MEI.uI, var7.Z, (byte)14);
                     var8.J.F(SBI.I(var0, -92805385));
                     var8.J.I(var0, 2126537806);
                     var7.I(var8, (byte)-112);
                  }
               }
            } else {
               OS.I(4, VEI.q.I(WO.U, -875414210), (byte)-99);
            }
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "sc.mk(" + ')');
      }
   }

   public static void I(int var0, int var1) {
      try {
         if (var0 != XEI.QZ * -1233866115) {
            XEI.tI = 0;
            if (var0 == 5 || 13 == var0) {
               UY.I(760519077);
            }

            if (var0 != 5 && ZW.F != null) {
               ZW.F.method3860(-2130986966);
               ZW.F = null;
            }

            if (19 == var0) {
               GZI.I(8 == -1233866115 * XEI.QZ || -1233866115 * XEI.QZ == 2 || 747461259 * JX.J.G != XEI.xC * -257444687, -1608675861);
            }

            if (var0 == 14) {
               LSI.I(XEI.xC * -257444687 != JX.J.I * 1349088077, -687019075);
            }

            if (var0 != 4 && 6 != var0) {
               if (3 == var0 || var0 == 18 && -1233866115 * XEI.QZ != 16) {
                  UY.I(1162411214);
               } else if (var0 == 2) {
                  IDI.Z((byte)0);
               }
            } else {
               TZ.I((byte)-8);
            }

            if (PQ.Z(var0, -1178041789)) {
               XEI.mI.J((byte)75);
               QW.I(true, 1336561252);
            }

            if (17 == var0 || var0 == 19) {
               MZ.Z(-1734216597);
            }

            boolean var2 = 7 == var0 || BV.I(var0, 2038230333) || FN.I(var0, 1765230881);
            boolean var3 = 7 == -1233866115 * XEI.QZ || BV.I(XEI.QZ * -1233866115, 2005988447) || FN.I(-1233866115 * XEI.QZ, 1765230881);
            if (var2 != var3) {
               if (var2) {
                  AN.B = AN.J * 1701432991;
                  if (FW.J.t.I(-2145576299) != 0) {
                     ZX.I(2, ST.D, 782166935 * AN.J, 0, FW.J.t.I(-2142499578), false, 1118626209);
                     KZ.I(-656326093);
                  } else {
                     S.I(2, 2140319778);
                  }

                  TJ.Z.method2343(false, -1153302935);
               } else {
                  S.I(2, 1226990292);
                  TJ.Z.method2343(true, -1469822226);
               }
            }

            if (PQ.Z(var0, 299941911) || var0 == 5 || 13 == var0) {
               FT.P.method5176();
            }

            XEI.QZ = -705702187 * var0;
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "sc.fd(" + ')');
      }
   }
}
