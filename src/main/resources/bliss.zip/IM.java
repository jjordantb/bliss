public class IM extends RL {
   String append;
   int toString;
   LC J;

   void method3508(REI var1, int var2) {
      try {
         this.toString = var1.H((byte)-78) * 1400658899;
         this.append = var1.E(951209118);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aga.a(" + ')');
      }
   }

   void method3512(REI var1) {
      this.toString = var1.H((byte)-96) * 1400658899;
      this.append = var1.E(-131087516);
   }

   void method3510(QC var1, byte var2) {
      try {
         var1.I(this.toString * -419842981, this.append, (byte)24);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aga.f(" + ')');
      }
   }

   void method3511(QC var1) {
      var1.I(this.toString * -419842981, this.append, (byte)24);
   }

   IM(LC var1) {
      this.J = var1;
   }

   void method3509(REI var1) {
      this.toString = var1.H((byte)-1) * 1400658899;
      this.append = var1.E(-184200581);
   }
}
