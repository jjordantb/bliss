public class KN extends HN {
   public int C;
   public int B;
   public int D;
   public int F;
   public boolean J = false;
   public int S;

   public boolean Z(int var1, int var2) {
      if (!this.J) {
         return false;
      } else {
         int var3 = this.F - this.B;
         int var4 = this.C - this.D;
         int var5 = var3 * var3 + var4 * var4;
         int var6 = var1 * var3 + var2 * var4 - (this.B * var3 + this.D * var4);
         int var7;
         int var8;
         if (var6 <= 0) {
            var7 = this.B - var1;
            var8 = this.D - var2;
            return var7 * var7 + var8 * var8 < this.S * this.S;
         } else if (var6 > var5) {
            var7 = this.F - var1;
            var8 = this.C - var2;
            return var7 * var7 + var8 * var8 < this.S * this.S;
         } else {
            var6 = (var6 << 10) / var5;
            var7 = this.B + (var3 * var6 >> 10) - var1;
            var8 = this.D + (var4 * var6 >> 10) - var2;
            return var7 * var7 + var8 * var8 < this.S * this.S;
         }
      }
   }
}
