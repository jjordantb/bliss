public class FFI extends LDI {
   IJI append;
   int toString;
   int Z;
   protected static FE C;

   FFI(REI var1) {
      super(var1);
      this.Z = var1.C() * 192120791;
      this.toString = var1.I() * -1335683137;
   }

   public void method869() {
      U.I(this.append, -915613633 * this.toString, (byte)-39);
   }

   boolean Z(int var1) {
      try {
         if (this.append == null) {
            this.append = new IJI(ST.D, this.Z * -949920793);
         }

         return this.append.Z((byte)1);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "yv.p(" + ')');
      }
   }

   public void method868() {
      U.I(this.append, -915613633 * this.toString, (byte)16);
   }

   boolean append() {
      if (this.append == null) {
         this.append = new IJI(ST.D, this.Z * -949920793);
      }

      return this.append.Z((byte)1);
   }

   public void method866(int var1) {
      try {
         U.I(this.append, -915613633 * this.toString, (byte)-9);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "yv.f(" + ')');
      }
   }
}
