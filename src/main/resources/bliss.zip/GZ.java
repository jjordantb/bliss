public final class GZ extends AZ {
   void I() {
      this.B.X();
      this.B.method5335(this.D);
      this.B.method5300(YF.Z, YF.Z, this.D);
      this.B.C(0);
      this.B.I((IEI)this.Z);
      this.B.I(0, MB.Z);
      this.B.Z(0, MB.Z);
      this.B.I(1, MB.B);
      this.B.Z(1, MB.B);
      this.B.M().I(this.F);
      this.B.I(CB.C);
      this.B.method5383(0, this.C);
      this.B.method5455(this.A);
      this.B.method5398(QB.C, this.S, 2);
   }

   public void method1526(int var1, int var2) {
      this.B.B(var1);
      this.B.S(var2);
   }

   public void method1531() {
      this.I();
   }

   public void method1536() {
      this.B.C(1);
      this.B.I((IEI)this.I);
      this.B.M().I(this.J);
      this.B.I(CB.C);
      this.B.I(FB.F, FB.I);
      this.B.I(0, MB.I);
      this.I();
      this.B.C(1);
      this.B.method5359();
   }

   public GZ(NJI var1) {
      super(var1);
   }

   public void method1535() {
      this.I();
   }

   public void method1529(int var1, int var2) {
      this.B.B(var1);
      this.B.S(var2);
   }

   public void method1530(int var1, int var2) {
      this.B.B(var1);
      this.B.S(var2);
   }

   public void method1532() {
      this.I();
   }

   public void method1533() {
      this.B.C(1);
      this.B.I((IEI)this.I);
      this.B.M().I(this.J);
      this.B.I(CB.C);
      this.B.I(FB.F, FB.I);
      this.B.I(0, MB.I);
      this.I();
      this.B.C(1);
      this.B.method5359();
   }

   public void method1525() {
      this.I();
   }

   public void method1534() {
      this.B.C(1);
      this.B.I((IEI)this.I);
      this.B.M().I(this.J);
      this.B.I(CB.C);
      this.B.I(FB.F, FB.I);
      this.B.I(0, MB.I);
      this.I();
      this.B.C(1);
      this.B.method5359();
   }

   public void method1527() {
      this.I();
   }

   public void method1537() {
      this.B.C(1);
      this.B.I((IEI)this.I);
      this.B.M().I(this.J);
      this.B.I(CB.C);
      this.B.I(FB.F, FB.I);
      this.B.I(0, MB.I);
      this.I();
      this.B.C(1);
      this.B.method5359();
   }

   public void method1528() {
      this.B.C(1);
      this.B.I((IEI)this.I);
      this.B.M().I(this.J);
      this.B.I(CB.C);
      this.B.I(FB.F, FB.I);
      this.B.I(0, MB.I);
      this.I();
      this.B.C(1);
      this.B.method5359();
   }

   public void method1538() {
      this.B.C(1);
      this.B.I((IEI)this.I);
      this.B.M().I(this.J);
      this.B.I(CB.C);
      this.B.I(FB.F, FB.I);
      this.B.I(0, MB.I);
      this.I();
      this.B.C(1);
      this.B.method5359();
   }
}
