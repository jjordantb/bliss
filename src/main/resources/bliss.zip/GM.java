import jaclib.hardware_info.HardwareInfo;
import java.util.HashMap;

public class GM extends AE {
   int append;
   static int charAt = 3;
   static int equalsIgnoreCase = 4;
   int get;
   public static int getCPUInfo = 0;
   int getDXDiagDisplayDevicesProps;
   static int getDXDiagSystemProps = 5;
   static int getRawCPUInfo = 1;
   static int indexOf = 2;
   static int length = 3;
   static int parseInt = 3;
   static int put = 2;
   static int startsWith = 4;
   static int substring = 7;
   static int toLowerCase = 8;
   static int toString = 6;
   String valueOf;
   static int J = 21;
   static int S = 22;
   static int A = 23;
   int E;
   static int G = 1;
   static int H = 9;
   int K;
   static int L = 4;
   int M;
   public int N;
   int O;
   public int P;
   boolean Q;
   String R;
   static int T = 0;
   int U;
   static int V = 20;
   static int W = 2;
   int X;
   String Y;
   String i;
   static int z = 1;
   String c;
   int b;
   int d;
   static int f = 6;
   boolean j;
   public int s;
   String a;
   int[] e = new int[3];
   int g;

   void append(int var1) {
      try {
         if (this.Y.length() > 40) {
            this.Y = this.Y.substring(0, 40);
         }

         if (this.i.length() > 40) {
            this.i = this.i.substring(0, 40);
         }

         if (this.valueOf.length() > 10) {
            this.valueOf = this.valueOf.substring(0, 10);
         }

         if (this.c.length() > 10) {
            this.c = this.c.substring(0, 10);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "acc.a(" + ')');
      }
   }

   public void I(REI var1, int var2) {
      try {
         var1.F((int)6);
         var1.F(this.getDXDiagDisplayDevicesProps * -1570985485);
         var1.F(this.j ? 1 : 0);
         var1.F(-1414570243 * this.E);
         var1.F(this.M * 43286197);
         var1.F(this.N * 154600941);
         var1.F(-1529246497 * this.O);
         var1.F(this.P * 1324779323);
         var1.F(this.Q ? 1 : 0);
         var1.Z(this.get * -2088235843, 16711935);
         var1.F(-1837764033 * this.U);
         var1.F(399637415 * this.s, (byte)115);
         var1.Z(-1360789919 * this.X, 16711935);
         var1.I((String)this.Y, (short)14956);
         var1.I((String)this.i, (short)23186);
         var1.I((String)this.valueOf, (short)15519);
         var1.I((String)this.c, (short)4727);
         var1.F(this.d * 1183412533);
         var1.Z(-669549295 * this.b, 16711935);
         var1.I((String)this.R, (short)3988);
         var1.I(this.a, (short)-4559);
         var1.F(78038867 * this.append);
         var1.F(this.K * 664924581);

         for(int var3 = 0; var3 < this.e.length; ++var3) {
            var1.B(this.e[var3], -1856682920);
         }

         var1.B(-277721711 * this.g, -1047358922);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "acc.f(" + ')');
      }
   }

   public int C(int var1) {
      try {
         byte var2 = 38;
         int var4 = var2 + II.I(this.Y, (byte)-1);
         var4 += II.I(this.i, (byte)-1);
         var4 += II.I(this.valueOf, (byte)-1);
         var4 += II.I(this.c, (byte)-1);
         var4 += II.I(this.R, (byte)-1);
         var4 += II.I(this.a, (byte)-1);
         return var4;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "acc.b(" + ')');
      }
   }

   public GM(boolean var1) {
      if (var1) {
         if (HFI.B.startsWith("win")) {
            this.getDXDiagDisplayDevicesProps = -1323296965;
         } else if (HFI.B.startsWith("mac")) {
            this.getDXDiagDisplayDevicesProps = 1648373366;
         } else if (HFI.B.startsWith("linux")) {
            this.getDXDiagDisplayDevicesProps = 325076401;
         } else {
            this.getDXDiagDisplayDevicesProps = -998220564;
         }

         if (!CQ.K.startsWith("amd64") && !CQ.K.startsWith("x86_64")) {
            this.j = false;
         } else {
            this.j = true;
         }

         if (1 == -1570985485 * this.getDXDiagDisplayDevicesProps) {
            if (WJ.G.indexOf("4.0") != -1) {
               this.E = 1791241813;
            } else if (WJ.G.indexOf("4.1") != -1) {
               this.E = -712483670;
            } else if (WJ.G.indexOf("4.9") != -1) {
               this.E = 1078758143;
            } else if (WJ.G.indexOf("5.0") != -1) {
               this.E = -1424967340;
            } else if (WJ.G.indexOf("5.1") != -1) {
               this.E = 366274473;
            } else if (WJ.G.indexOf("5.2") != -1) {
               this.E = 1445032616;
            } else if (WJ.G.indexOf("6.0") != -1) {
               this.E = -2137451010;
            } else if (WJ.G.indexOf("6.1") != -1) {
               this.E = -346209197;
            } else if (WJ.G.indexOf("6.2") != -1) {
               this.E = -1058692867;
            }
         } else if (2 == this.getDXDiagDisplayDevicesProps * -1570985485) {
            if (WJ.G.indexOf("10.4") != -1) {
               this.E = 1465097892;
            } else if (WJ.G.indexOf("10.5") != -1) {
               this.E = -1038627591;
            } else if (WJ.G.indexOf("10.6") != -1) {
               this.E = 752614222;
            } else if (WJ.G.indexOf("10.7") != -1) {
               this.E = -1751111261;
            }
         }

         if (EQ.v.toLowerCase().indexOf("sun") != -1) {
            this.M = 953745309;
         } else if (EQ.v.toLowerCase().indexOf("microsoft") != -1) {
            this.M = 1907490618;
         } else if (EQ.v.toLowerCase().indexOf("apple") != -1) {
            this.M = -1433731369;
         } else {
            this.M = -479986060;
         }

         int var2 = 2;
         int var3 = 0;

         char var4;
         try {
            while(var2 < II.ZI.length()) {
               var4 = II.ZI.charAt(var2);
               if (var4 < '0' || var4 > '9') {
                  break;
               }

               var3 = var4 - 48 + var3 * 10;
               ++var2;
            }
         } catch (Exception var18) {
            ;
         }

         this.N = var3 * 1984962533;
         var2 = II.ZI.indexOf(46, 2) + 1;
         var3 = 0;

         try {
            while(var2 < II.ZI.length()) {
               var4 = II.ZI.charAt(var2);
               if (var4 < '0' || var4 > '9') {
                  break;
               }

               var3 = var4 - 48 + 10 * var3;
               ++var2;
            }
         } catch (Exception var17) {
            ;
         }

         this.O = var3 * 1167404831;
         var2 = II.ZI.indexOf(95, 4) + 1;
         var3 = 0;

         try {
            while(var2 < II.ZI.length()) {
               var4 = II.ZI.charAt(var2);
               if (var4 < '0' || var4 > '9') {
                  break;
               }

               var3 = var3 * 10 + (var4 - 48);
               ++var2;
            }
         } catch (Exception var16) {
            ;
         }

         this.P = -796083725 * var3;
         this.Q = false;
         this.get = ZE.N * -633367115;
         if (154600941 * this.N > 3) {
            this.U = ZE.B * -1360223467;
         } else {
            this.U = 0;
         }

         try {
            int[] var19 = HardwareInfo.getCPUInfo();
            if (var19 != null && 3 == var19.length) {
               this.append = var19[0] * 672863451;
               this.X = var19[1] * -1283906143;
               this.s = var19[2] * -108594153;
            }

            int[] var5 = HardwareInfo.getRawCPUInfo();
            int var7;
            int var9;
            int var10;
            int var11;
            if (var5 != null && var5.length % 5 == 0) {
               HashMap var6 = new HashMap();

               for(var7 = 0; var7 < var5.length / 5; ++var7) {
                  int var8 = var5[var7 * 5];
                  var9 = var5[5 * var7 + 1];
                  var10 = var5[2 + var7 * 5];
                  var11 = var5[var7 * 5 + 3];
                  int var12 = var5[4 + var7 * 5];
                  TY var13 = new TY(var8, var9, var10, var11, var12);
                  var6.put(var8, var13);
               }

               TY var21 = (TY)var6.get(Integer.valueOf(0));
               if (var21 != null) {
                  REI var22 = new REI(13);
                  var22.D(-2056580217 * var21.I, 162325587);
                  var22.D(272393713 * var21.B, -487042280);
                  var22.D(634425393 * var21.C, 164405285);
                  var22.A = 0;
                  this.R = var22.E(512996154);
               }

               TY var24 = (TY)var6.get(Integer.valueOf(1));
               if (var24 != null) {
                  this.g = -1193649755 * var24.Z;
                  var9 = var24.I * -2056580217;
                  this.K = -1403810259 * (var9 >> 16 & 255);
                  this.e[0] = var24.C * 634425393;
                  this.e[1] = 272393713 * var24.B;
               }

               TY var26 = (TY)var6.get(-2147483647);
               if (var26 != null) {
                  this.e[2] = 272393713 * var26.B;
               }

               REI var28 = new REI(49);

               for(var11 = -2147483646; var11 <= -2147483644; ++var11) {
                  TY var30 = (TY)var6.get(var11);
                  if (var30 != null) {
                     var28.D(var30.Z * 1461544821, 1924293641);
                     var28.D(-2056580217 * var30.I, -1273071648);
                     var28.D(var30.C * 634425393, 293591119);
                     var28.D(272393713 * var30.B, -1803597625);
                  }
               }

               var28.A = 0;
               this.a = var28.E(-1784035682);
            }

            String[][] var20 = HardwareInfo.getDXDiagDisplayDevicesProps();
            String var25;
            if (var20 != null && var20.length > 0 && var20[0] != null) {
               for(var7 = 0; var7 < var20[0].length; var7 += 2) {
                  if (var20[0][var7].equalsIgnoreCase("szDescription")) {
                     this.Y = var20[0][var7 + 1];
                  } else if (var20[0][var7].equalsIgnoreCase("szDriverDateEnglish")) {
                     var25 = var20[0][var7 + 1];

                     try {
                        var9 = var25.indexOf("/");
                        var10 = var25.indexOf("/", 1 + var9);
                        this.d = Integer.parseInt(var25.substring(0, var9)) * 1759516957;
                        this.b = Integer.parseInt(var25.substring(1 + var10, var25.indexOf(" ", var10))) * -1242885135;
                     } catch (Exception var14) {
                        ;
                     }
                  }
               }
            }

            String[] var23 = HardwareInfo.getDXDiagSystemProps();
            if (var23 != null) {
               var25 = "";
               String var27 = "";
               String var29 = "";

               for(var11 = 0; var11 < var23.length; var11 += 2) {
                  if (var23[var11].equalsIgnoreCase("dwDirectXVersionMajor")) {
                     var25 = var23[1 + var11];
                  } else if (var23[var11].equalsIgnoreCase("dwDirectXVersionMinor")) {
                     var27 = var23[1 + var11];
                  } else if (var23[var11].equalsIgnoreCase("dwDirectXVersionLetter")) {
                     var29 = var23[1 + var11];
                  }
               }

               this.valueOf = var25 + "." + var27 + var29;
            }
         } catch (Throwable var15) {
            this.s = 0;
         }
      }

      if (this.Y == null) {
         this.Y = "";
      }

      if (this.i == null) {
         this.i = "";
      }

      if (this.valueOf == null) {
         this.valueOf = "";
      }

      if (this.c == null) {
         this.c = "";
      }

      if (this.R == null) {
         this.R = "";
      }

      if (this.a == null) {
         this.a = "";
      }

      this.append(1932457780);
   }

   static JY[] I(byte var0) {
      try {
         return new JY[]{JY.C, JY.Z, JY.I};
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "acc.a(" + ')');
      }
   }
}
