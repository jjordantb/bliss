public class JW extends LV {
   public static int method5611 = 2;
   public static int toString = 1;
   public static int F = 0;
   public static int J = 3;
   public static int S = 4;

   public JW(int var1, MM var2) {
      super(var1, var2);
   }

   int method5611(int var1) {
      try {
         return this.I.B(866674858).I(1731057134) > 1 ? 4 : 2;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aen.a(" + ')');
      }
   }

   int method5615() {
      return this.I.B(-2103071990).I(-711735893) > 1 ? 4 : 2;
   }

   int method5612(int var1, int var2) {
      return 1;
   }

   void method5614(int var1, int var2) {
      try {
         this.C = var1 * 1886334997;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aen.p(" + ')');
      }
   }

   public int Z(byte var1) {
      try {
         return -1598873795 * this.C;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aen.z(" + ')');
      }
   }

   public void I(int var1) {
      try {
         if (this.C * -1598873795 < 0 && this.C * -1598873795 > 4) {
            this.C = this.method5611(1896297259) * 1886334997;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aen.s(" + ')');
      }
   }

   int method5616(int var1) {
      return 1;
   }

   void method5610(int var1) {
      this.C = var1 * 1886334997;
   }

   public JW(MM var1) {
      super(var1);
   }

   static final void I(OU var0, byte var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = 1001535723 * TQ.s;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aen.ahx(" + ')');
      }
   }
}
