public class BT extends CT {
   BT() throws Throwable {
      throw new Error();
   }
}
