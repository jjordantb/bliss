public class LD {
   public static int Z = 6;
   public static int append = 26;
   public static int equals = 1;
   public static int intValue = 14;
   public static int longValue = 24;
   public static int printStackTrace = 8;
   public static int toString = 9;
   public static int I = 22;
   public static int C = 16;
   public static int B = 10;
   public static int D = 15;
   public static int F = 2;
   public static int J = 3;
   public static int S = 4;
   public static int A = 25;
   public static int E = 27;
   public static int G = 23;
   public static int H = 21;
   public static int K = 29;
   public static int L = 7;
   public static int M = 13;
   public static int N = 17;
   public static int O = 5;
   public static int P = 11;
   public static int Q = 28;
   public static int R = 20;
   public static OF T;

   LD() throws Throwable {
      throw new Error();
   }

   static void I(KM var0, int var1, short var2) {
      try {
         Object[] var3 = var0.L;
         int var4 = ((Integer)var3[0]).intValue();
         BSI var5 = JF.I(var4, (byte)1);
         if (var5 != null) {
            OU var6 = UD.Z(974537460);
            var6.N = new int[var5.O * -1516159487];
            int var7 = 0;
            var6.Z = new String[var5.P * 1787035509];
            int var8 = 0;
            var6.C = new long[1679522843 * var5.Q];
            int var9 = 0;

            for(int var10 = 1; var10 < var3.length; ++var10) {
               if (var3[var10] instanceof Integer) {
                  int var11 = ((Integer)var3[var10]).intValue();
                  if (-2147483647 == var11) {
                     var11 = var0.E * 1893415363;
                  }

                  if (var11 == -2147483646) {
                     var11 = -54723935 * var0.G;
                  }

                  if (var11 == -2147483645) {
                     var11 = var0.A != null ? -440872681 * var0.A.V : -1;
                  }

                  if (-2147483644 == var11) {
                     var11 = 426539335 * var0.H;
                  }

                  if (-2147483643 == var11) {
                     var11 = var0.A != null ? -1309843523 * var0.A.a : -1;
                  }

                  if (-2147483642 == var11) {
                     var11 = var0.K != null ? -440872681 * var0.K.V : -1;
                  }

                  if (var11 == -2147483641) {
                     var11 = var0.K != null ? var0.K.a * -1309843523 : -1;
                  }

                  if (-2147483640 == var11) {
                     var11 = -1652898593 * var0.N;
                  }

                  if (-2147483639 == var11) {
                     var11 = var0.M * -2080757995;
                  }

                  var6.N[var7++] = var11;
               } else if (var3[var10] instanceof String) {
                  String var14 = (String)var3[var10];
                  if (var14.equals("event_opbase")) {
                     var14 = var0.J;
                  }

                  var6.Z[var8++] = var14;
               } else if (var3[var10] instanceof Long) {
                  long var15 = ((Long)var3[var10]).longValue();
                  var6.C[var9++] = var15;
               }
            }

            var6.U = var0.S * -323690565;
            FSI.I(var5, var1, var6, 546888884);
         }

      } catch (RuntimeException var13) {
         throw DQ.I(var13, "io.k(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         HSI var5 = JCI.I(var4, var3, -1926129754);
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var5 == null ? -1 : var5.V * -440872681;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "io.oq(" + ')');
      }
   }

   public static void I(int var0) {
      try {
         try {
            int var1;
            if (1 == 617004265 * EDI.I) {
               var1 = EDI.B.I((byte)-56);
               if (var1 > 0 && EDI.B.B(747355627)) {
                  var1 -= EG.A * -1503744809;
                  if (var1 < 0) {
                     var1 = 0;
                  }

                  EDI.B.Z(var1, 2100644467);
                  return;
               }

               EDI.B.C((byte)-38);
               EDI.B.Z((byte)81);
               if (EDI.S != null) {
                  EDI.I = 1770763954;
               } else {
                  EDI.I = 0;
               }

               SV.I = null;
               NH.V = null;
            }

            if (3 == EDI.I * 617004265) {
               var1 = EDI.B.I((byte)-5);
               if (var1 < EDI.F * 643426275 && EDI.B.B(1822181710)) {
                  var1 += 604206485 * AEI.S;
                  if (var1 > 643426275 * EDI.F) {
                     var1 = 643426275 * EDI.F;
                  }

                  EDI.B.Z(var1, 1707423851);
               } else {
                  AEI.S = 0;
                  EDI.I = 0;
               }
            }
         } catch (Exception var2) {
            var2.printStackTrace();
            EDI.B.C((byte)3);
            K.I(-1137434141);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "io.y(" + ')');
      }
   }
}
