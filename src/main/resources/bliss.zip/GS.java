import jaggl.OpenGL;

public class GS implements TAI, XAI, WAI {
   int glBindRenderbufferEXT;
   YCI glDeleteRenderbuffersEXT;
   SDI glFramebufferRenderbufferEXT;
   int glGenRenderbuffersEXT;
   OJI glRenderbufferStorageEXT;
   int I;

   public int a() {
      return this.glGenRenderbuffersEXT;
   }

   public void method168(int var1) {
      OpenGL.glFramebufferRenderbufferEXT(36160, var1, 36161, this.glBindRenderbufferEXT);
   }

   public void method167(int var1) {
      OpenGL.glFramebufferRenderbufferEXT(36160, var1, 36161, this.glBindRenderbufferEXT);
   }

   public void b() {
      if (this.glBindRenderbufferEXT > 0) {
         int[] var1 = new int[]{this.glBindRenderbufferEXT};
         OpenGL.glDeleteRenderbuffersEXT(1, var1, 0);
         this.glBindRenderbufferEXT = 0;
      }

   }

   void glBindRenderbufferEXT() {
      if (this.glBindRenderbufferEXT > 0) {
         this.glRenderbufferStorageEXT.C(this.glBindRenderbufferEXT, this.glGenRenderbuffersEXT * this.I * this.glFramebufferRenderbufferEXT.S * 685647847 * this.glDeleteRenderbuffersEXT.I * 845115459);
         this.glBindRenderbufferEXT = 0;
      }

   }

   public void method165(int var1) {
      OpenGL.glFramebufferRenderbufferEXT(36160, var1, 36161, this.glBindRenderbufferEXT);
   }

   public int p() {
      return this.glGenRenderbuffersEXT;
   }

   public int i() {
      return this.glGenRenderbuffersEXT;
   }

   public int k() {
      return this.I;
   }

   public void u() {
      if (this.glBindRenderbufferEXT > 0) {
         int[] var1 = new int[]{this.glBindRenderbufferEXT};
         OpenGL.glDeleteRenderbuffersEXT(1, var1, 0);
         this.glBindRenderbufferEXT = 0;
      }

   }

   public void x() {
      if (this.glBindRenderbufferEXT > 0) {
         int[] var1 = new int[]{this.glBindRenderbufferEXT};
         OpenGL.glDeleteRenderbuffersEXT(1, var1, 0);
         this.glBindRenderbufferEXT = 0;
      }

   }

   public void d() {
      if (this.glBindRenderbufferEXT > 0) {
         int[] var1 = new int[]{this.glBindRenderbufferEXT};
         OpenGL.glDeleteRenderbuffersEXT(1, var1, 0);
         this.glBindRenderbufferEXT = 0;
      }

   }

   public int f() {
      return this.I;
   }

   public void method166(int var1) {
      OpenGL.glFramebufferRenderbufferEXT(36160, var1, 36161, this.glBindRenderbufferEXT);
   }

   public void method164(int var1) {
      OpenGL.glFramebufferRenderbufferEXT(36160, var1, 36161, this.glBindRenderbufferEXT);
   }

   GS(OJI var1, YCI var2, SDI var3, int var4, int var5) {
      this.glDeleteRenderbuffersEXT = var2;
      this.glFramebufferRenderbufferEXT = var3;
      this.glGenRenderbuffersEXT = var4;
      this.I = var5;
      this.glRenderbufferStorageEXT = var1;
      int[] var6 = new int[1];
      OpenGL.glGenRenderbuffersEXT(1, var6, 0);
      this.glBindRenderbufferEXT = var6[0];
      OpenGL.glBindRenderbufferEXT(36161, this.glBindRenderbufferEXT);
      OpenGL.glRenderbufferStorageEXT(36161, OJI.I(this.glDeleteRenderbuffersEXT, this.glFramebufferRenderbufferEXT), var4, var5);
   }
}
