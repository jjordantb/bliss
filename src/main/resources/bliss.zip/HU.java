public class HU {
   static LQ I = new LQ(128);
   public static KJ Z;
   public static KJ C;

   HU() throws Throwable {
      throw new Error();
   }

   public static void I(int var0, int var1) {
      try {
         if (8 == XEI.QZ * -1233866115) {
            PK var2 = GB.I(MEI.c, XEI.TI.Z, (byte)103);
            var2.J.F(var0);
            XEI.TI.I(var2, (byte)-112);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "qo.k(" + ')');
      }
   }
}
