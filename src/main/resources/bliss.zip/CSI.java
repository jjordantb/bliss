import jaclib.memory.Stream;
import jaggl.OpenGL;

public class CSI extends YJI {
   UO S;
   static int c = 74;
   UO A;
   int d;
   int f;
   int glLoadMatrixf;
   int E;
   static float[] glMatrixMode = new float[16];
   int glPopMatrix;
   int glPushMatrix;
   OM[][][] glTranslatef;
   int[][][] G;
   int[][][] method174;
   float[][] method545;
   int[][][] H;
   int[][][] method552;
   int[][][] method6335;
   AE[] p;
   MJI K;
   FY sqrt = new FY();
   int[][][] L;
   PSI u;
   UO M;
   UO x;
   KX N;
   static int O = 1;
   int P;
   int Q;
   byte[][] R;
   byte[][] T;
   float[][] U;
   float[][] V;
   LX W;
   short[][] X;

   public void LA(int var1, int var2, int var3) {
      if ((this.R[var1][var2] & 255) < var3) {
         this.R[var1][var2] = (byte)var3;
      }

   }

   public GJI aa(int var1, int var2, GJI var3) {
      if ((this.T[var1][var2] & 1) == 0) {
         return null;
      } else {
         int var4 = this.C * -1212653763 >> this.K.H;
         HJI var5 = (HJI)var3;
         HJI var6;
         if (var5 != null && var5.Z(var4, var4)) {
            var6 = var5;
            var5.I();
         } else {
            var6 = new HJI(this.K, var4, var4);
         }

         var6.I(0, 0, var4, var4);
         this.J(var6, var1, var2);
         return var6;
      }
   }

   public void ad(GJI var1, int var2, int var3, int var4, int var5, boolean var6) {
      if (this.N != null && var1 != null) {
         int var7 = var2 - (var3 * this.K.K >> 8) >> this.K.H;
         int var8 = var4 - (var3 * this.K.Z >> 8) >> this.K.H;
         this.N.I(var1, var7, var8);
      }

   }

   public void SA() {
      if (this.P > 0) {
         byte[][] var1 = new byte[this.Z * -506105871 + 1][this.I * -1148794921 + 1];

         int var2;
         for(var2 = 1; var2 < this.Z * -506105871; ++var2) {
            for(int var3 = 1; var3 < this.I * -1148794921; ++var3) {
               var1[var2][var3] = (byte)((this.R[var2 - 1][var3] >> 2) + (this.R[var2 + 1][var3] >> 3) + (this.R[var2][var3 - 1] >> 2) + (this.R[var2][var3 + 1] >> 3) + (this.R[var2][var3] >> 1));
            }
         }

         this.p = new AE[this.W.Z(1429819619)];
         this.W.I(this.p, 2105233647);

         for(var2 = 0; var2 < this.p.length; ++var2) {
            ((OM)this.p[var2]).B(this.P);
         }

         var2 = 24;
         if (this.method6335 != null) {
            var2 += 4;
         }

         if ((this.E & 7) != 0) {
            var2 += 12;
         }

         jaclib.memory.heap.I var64 = this.K.GI.f(this.P * var2, false);
         Stream var4 = new Stream(var64);
         OM[] var5 = new OM[this.P];
         int var6 = KW.C(this.P / 4, 1715118458);
         if (var6 < 1) {
            var6 = 1;
         }

         LX var7 = new LX(var6);
         OM[] var8 = new OM[this.Q];

         int var9;
         int var10;
         for(var9 = 0; var9 < this.Z * -506105871; ++var9) {
            for(var10 = 0; var10 < this.I * -1148794921; ++var10) {
               if (this.G[var9][var10] != null) {
                  OM[] var11 = this.glTranslatef[var9][var10];
                  int[] var12 = this.L[var9][var10];
                  int[] var13 = this.H[var9][var10];
                  int[] var14 = this.method174[var9][var10];
                  int[] var15 = this.G[var9][var10];
                  int[] var16 = this.method552 != null ? this.method552[var9][var10] : null;
                  int[] var17 = this.method6335 != null ? this.method6335[var9][var10] : null;
                  if (var14 == null) {
                     var14 = var15;
                  }

                  float var18 = this.method545[var9][var10];
                  float var19 = this.U[var9][var10];
                  float var20 = this.V[var9][var10];
                  float var21 = this.method545[var9][var10 + 1];
                  float var22 = this.U[var9][var10 + 1];
                  float var23 = this.V[var9][var10 + 1];
                  float var24 = this.method545[var9 + 1][var10 + 1];
                  float var25 = this.U[var9 + 1][var10 + 1];
                  float var26 = this.V[var9 + 1][var10 + 1];
                  float var27 = this.method545[var9 + 1][var10];
                  float var28 = this.U[var9 + 1][var10];
                  float var29 = this.V[var9 + 1][var10];
                  int var30 = var1[var9][var10] & 255;
                  int var31 = var1[var9][var10 + 1] & 255;
                  int var32 = var1[var9 + 1][var10 + 1] & 255;
                  int var33 = var1[var9 + 1][var10] & 255;
                  int var34 = 0;

                  int var37;
                  label343:
                  for(int var35 = 0; var35 < var15.length; ++var35) {
                     OM var36 = var11[var35];

                     for(var37 = 0; var37 < var34; ++var37) {
                        if (var8[var37] == var36) {
                           continue label343;
                        }
                     }

                     var8[var34++] = var36;
                  }

                  short[] var80 = this.X[var10 * this.Z * -506105871 + var9] = new short[var15.length];

                  for(int var81 = 0; var81 < var15.length; ++var81) {
                     var37 = (var9 << this.B * -2137349879) + var12[var81];
                     int var38 = (var10 << this.B * -2137349879) + var13[var81];
                     int var39 = var37 >> this.d;
                     int var40 = var38 >> this.d;
                     int var41 = var15[var81];
                     int var42 = var14[var81];
                     int var43 = var16 != null ? var16[var81] : 0;
                     long var44 = (long)var42 << 48 | (long)var41 << 32 | (long)(var39 << 16) | (long)var40;
                     int var46 = var12[var81];
                     int var47 = var13[var81];
                     byte var48 = 74;
                     int var49 = 0;
                     float var50 = 1.0F;
                     float var51;
                     float var52;
                     float var53;
                     float var58;
                     int var82;
                     if (var46 == 0 && var47 == 0) {
                        var51 = var18;
                        var52 = var19;
                        var53 = var20;
                        var82 = var48 - var30;
                     } else if (var46 == 0 && var47 == this.C * -1212653763) {
                        var51 = var21;
                        var52 = var22;
                        var53 = var23;
                        var82 = var48 - var31;
                     } else if (var46 == this.C * -1212653763 && var47 == this.C * -1212653763) {
                        var51 = var24;
                        var52 = var25;
                        var53 = var26;
                        var82 = var48 - var32;
                     } else if (var46 == this.C * -1212653763 && var47 == 0) {
                        var51 = var27;
                        var52 = var28;
                        var53 = var29;
                        var82 = var48 - var33;
                     } else {
                        float var54 = (float)var46 / (float)(this.C * -1212653763);
                        float var55 = (float)var47 / (float)(this.C * -1212653763);
                        float var56 = var18 + (var27 - var18) * var54;
                        float var57 = var19 + (var28 - var19) * var54;
                        var58 = var20 + (var29 - var20) * var54;
                        float var59 = var21 + (var24 - var21) * var54;
                        float var60 = var22 + (var25 - var22) * var54;
                        float var61 = var23 + (var26 - var23) * var54;
                        var51 = var56 + (var59 - var56) * var55;
                        var52 = var57 + (var60 - var57) * var55;
                        var53 = var58 + (var61 - var58) * var55;
                        int var62 = var30 + ((var33 - var30) * var46 >> this.B * -2137349879);
                        int var63 = var31 + ((var32 - var31) * var46 >> this.B * -2137349879);
                        var82 = var48 - (var62 + ((var63 - var62) * var47 >> this.B * -2137349879));
                     }

                     if (var41 != -1) {
                        int var83 = (var41 & 127) * var82 >> 7;
                        if (var83 < 2) {
                           var83 = 2;
                        } else if (var83 > 126) {
                           var83 = 126;
                        }

                        var49 = DE.I[var41 & 'ﾀ' | var83];
                        if ((this.E & 7) == 0) {
                           var50 = this.K.e[0] * var51 + this.K.e[1] * var52 + this.K.e[2] * var53;
                           var50 = this.K.k + var50 * (var50 > 0.0F ? this.K.l : this.K.m);
                        }
                     }

                     AE var85 = null;
                     if ((var37 & this.f - 1) == 0 && (var38 & this.f - 1) == 0) {
                        var85 = var7.I(var44);
                     }

                     int var84;
                     int var86;
                     if (var85 == null) {
                        if (var42 != var41) {
                           int var87 = (var42 & 127) * var82 >> 7;
                           if (var87 < 2) {
                              var87 = 2;
                           } else if (var87 > 126) {
                              var87 = 126;
                           }

                           var86 = DE.I[var42 & 'ﾀ' | var87];
                           if ((this.E & 7) == 0) {
                              float var10000 = this.K.e[0] * var51 + this.K.e[1] * var52 + this.K.e[2] * var53;
                              var58 = this.K.k + var50 * (var50 > 0.0F ? this.K.l : this.K.m);
                              int var88 = var86 >> 16 & 255;
                              int var89 = var86 >> 8 & 255;
                              int var90 = var86 & 255;
                              var88 = (int)((float)var88 * var58);
                              if (var88 < 0) {
                                 var88 = 0;
                              } else if (var88 > 255) {
                                 var88 = 255;
                              }

                              var89 = (int)((float)var89 * var58);
                              if (var89 < 0) {
                                 var89 = 0;
                              } else if (var89 > 255) {
                                 var89 = 255;
                              }

                              var90 = (int)((float)var90 * var58);
                              if (var90 < 0) {
                                 var90 = 0;
                              } else if (var90 > 255) {
                                 var90 = 255;
                              }

                              var86 = var88 << 16 | var89 << 8 | var90;
                           }
                        } else {
                           var86 = var49;
                        }

                        if (this.K.u) {
                           var4.d((float)var37);
                           var4.d((float)(this.I(var37, var38, -1789282838) + var43));
                           var4.d((float)var38);
                           var4.p((byte)(var86 >> 16));
                           var4.p((byte)(var86 >> 8));
                           var4.p((byte)var86);
                           var4.p(-1);
                           var4.d((float)var37);
                           var4.d((float)var38);
                           if (this.method6335 != null) {
                              var4.d(var17 != null ? (float)(var17[var81] - 1) : 0.0F);
                           }

                           if ((this.E & 7) != 0) {
                              var4.d(var51);
                              var4.d(var52);
                              var4.d(var53);
                           }
                        } else {
                           var4.u((float)var37);
                           var4.u((float)(this.I(var37, var38, -1884194336) + var43));
                           var4.u((float)var38);
                           var4.p((byte)(var86 >> 16));
                           var4.p((byte)(var86 >> 8));
                           var4.p((byte)var86);
                           var4.p(-1);
                           var4.u((float)var37);
                           var4.u((float)var38);
                           if (this.method6335 != null) {
                              var4.u(var17 != null ? (float)(var17[var81] - 1) : 0.0F);
                           }

                           if ((this.E & 7) != 0) {
                              var4.u(var51);
                              var4.u(var52);
                              var4.u(var53);
                           }
                        }

                        var84 = this.glPushMatrix++;
                        var80[var81] = (short)var84;
                        if (var41 != -1) {
                           var5[var84] = var11[var81];
                        }

                        var7.I(new DG(var80[var81]), var44);
                     } else {
                        var80[var81] = ((DG)var85).J;
                        var84 = var80[var81] & '\uffff';
                        if (var41 != -1 && var11[var81].Z * 7051297995265073167L < var5[var84].Z * 7051297995265073167L) {
                           var5[var84] = var11[var81];
                        }
                     }

                     for(var86 = 0; var86 < var34; ++var86) {
                        var8[var86].I(var84, var49, var82, var50);
                     }

                     ++this.glPopMatrix;
                  }
               }
            }
         }

         for(var9 = 0; var9 < this.glPushMatrix; ++var9) {
            OM var65 = var5[var9];
            if (var65 != null) {
               var65.C(var9);
            }
         }

         for(var9 = 0; var9 < this.Z * -506105871; ++var9) {
            for(var10 = 0; var10 < this.I * -1148794921; ++var10) {
               short[] var67 = this.X[var10 * this.Z * -506105871 + var9];
               if (var67 != null) {
                  int var70 = 0;

                  for(int var72 = 0; var72 < var67.length; ++var70) {
                     int var73 = var67[var72++] & '\uffff';
                     int var74 = var67[var72++] & '\uffff';
                     int var75 = var67[var72++] & '\uffff';
                     OM var76 = var5[var73];
                     OM var77 = var5[var74];
                     OM var78 = var5[var75];
                     OM var79 = null;
                     if (var76 != null) {
                        var76.I(var9, var10, var70);
                        var79 = var76;
                     }

                     if (var77 != null) {
                        var77.I(var9, var10, var70);
                        if (var79 == null || var77.Z * 7051297995265073167L < var79.Z * 7051297995265073167L) {
                           var79 = var77;
                        }
                     }

                     if (var78 != null) {
                        var78.I(var9, var10, var70);
                        if (var79 == null || var78.Z * 7051297995265073167L < var79.Z * 7051297995265073167L) {
                           var79 = var78;
                        }
                     }

                     if (var79 != null) {
                        if (var76 != null) {
                           var79.C(var73);
                        }

                        if (var77 != null) {
                           var79.C(var74);
                        }

                        if (var78 != null) {
                           var79.C(var75);
                        }

                        var79.I(var9, var10, var70);
                     }
                  }
               }
            }
         }

         var4.x();
         this.u = this.K.I(var2, (jaclib.memory.I)var64, var4.f(), false);
         if (this.u instanceof XU) {
            var64.t();
         }

         this.M = new UO(this.u, 5126, 3, 0);
         this.x = new UO(this.u, 5121, 4, 12);
         byte var66;
         if (this.method6335 != null) {
            this.S = new UO(this.u, 5126, 3, 16);
            var66 = 28;
         } else {
            this.S = new UO(this.u, 5126, 2, 16);
            var66 = 24;
         }

         if ((this.E & 7) != 0) {
            this.A = new UO(this.u, 5126, 3, var66);
         }

         long[] var68 = new long[this.p.length];

         for(int var69 = 0; var69 < this.p.length; ++var69) {
            OM var71 = (OM)this.p[var69];
            var68[var69] = var71.Z * 7051297995265073167L;
            var71.D(this.glPushMatrix);
         }

         HR.I(var68, this.p, (byte)-115);
         if (this.N != null) {
            this.N.I();
         }
      } else {
         this.N = null;
      }

      if ((this.glLoadMatrixf & 2) == 0) {
         this.H = null;
         this.L = null;
         this.G = null;
      }

      this.method6335 = null;
      this.method174 = null;
      this.method552 = null;
      this.glTranslatef = null;
      this.R = null;
      this.W = null;
      this.V = null;
      this.U = null;
      this.method545 = null;
   }

   public void method6351(int var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean[][] var8) {
      CCI var9 = this.K.I((short)23850);
      if (this.P > 0 && var9 != null) {
         this.K.H();
         this.K.I(false);
         this.K.Z(false);
         this.K.B(false);
         this.K.D(false);
         this.K.B(0);
         this.K.F(-2);
         this.K.I((SN)null);
         glMatrixMode[0] = (float)var3 / (128.0F * (float)(this.C * -1212653763) * (float)var9.method545());
         glMatrixMode[1] = 0.0F;
         glMatrixMode[2] = 0.0F;
         glMatrixMode[3] = 0.0F;
         glMatrixMode[4] = 0.0F;
         glMatrixMode[5] = (float)var3 / (128.0F * (float)(this.C * -1212653763) * (float)var9.method552());
         glMatrixMode[6] = 0.0F;
         glMatrixMode[7] = 0.0F;
         glMatrixMode[8] = 0.0F;
         glMatrixMode[9] = 0.0F;
         glMatrixMode[10] = 0.0F;
         glMatrixMode[11] = 0.0F;
         glMatrixMode[12] = -1.0F - ((float)(var4 * var3) / 128.0F - (float)(var1 * 2)) / (float)var9.method545();
         glMatrixMode[13] = 1.0F - ((float)(2 * var2) + (float)(var7 * var3) / 128.0F) / (float)var9.method552();
         glMatrixMode[14] = 0.0F;
         glMatrixMode[15] = 1.0F;
         OpenGL.glMatrixMode(5889);
         OpenGL.glLoadMatrixf(glMatrixMode, 0);
         glMatrixMode[0] = 1.0F;
         glMatrixMode[1] = 0.0F;
         glMatrixMode[2] = 0.0F;
         glMatrixMode[3] = 0.0F;
         glMatrixMode[4] = 0.0F;
         glMatrixMode[5] = 0.0F;
         glMatrixMode[6] = 1.0F;
         glMatrixMode[7] = 0.0F;
         glMatrixMode[8] = 0.0F;
         glMatrixMode[9] = 1.0F;
         glMatrixMode[10] = 0.0F;
         glMatrixMode[11] = 0.0F;
         glMatrixMode[12] = 0.0F;
         glMatrixMode[13] = 0.0F;
         glMatrixMode[14] = 0.0F;
         glMatrixMode[15] = 1.0F;
         OpenGL.glMatrixMode(5888);
         OpenGL.glLoadMatrixf(glMatrixMode, 0);
         if ((this.E & 7) != 0) {
            this.K.Z(true);
            this.K.A();
         } else {
            this.K.Z(false);
         }

         this.K.I(this.M, this.A, this.x, this.S);
         if (this.K.iI.S.length < this.glPopMatrix * 2) {
            this.K.iI = new TEI(this.glPopMatrix * 2);
         } else {
            this.K.iI.A = 0;
         }

         int var10 = 0;
         TEI var11 = this.K.iI;
         int var12;
         int var13;
         int var14;
         short[] var15;
         int var16;
         if (this.K.u) {
            for(var12 = var5; var12 < var7; ++var12) {
               var13 = var12 * this.Z * -506105871 + var4;

               for(var14 = var4; var14 < var6; ++var14) {
                  if (var8[var14 - var4][var12 - var5]) {
                     var15 = this.X[var13];
                     if (var15 != null) {
                        for(var16 = 0; var16 < var15.length; ++var16) {
                           var11.Z(var15[var16] & '\uffff', 16711935);
                           ++var10;
                        }
                     }
                  }

                  ++var13;
               }
            }
         } else {
            for(var12 = var5; var12 < var7; ++var12) {
               var13 = var12 * this.Z * -506105871 + var4;

               for(var14 = var4; var14 < var6; ++var14) {
                  if (var8[var14 - var4][var12 - var5]) {
                     var15 = this.X[var13];
                     if (var15 != null) {
                        for(var16 = 0; var16 < var15.length; ++var16) {
                           var11.C(var15[var16] & '\uffff', 1368367793);
                           ++var10;
                        }
                     }
                  }

                  ++var13;
               }
            }
         }

         if (var10 > 0) {
            PY var17 = new PY(this.K, 5123, var11.S, var11.A * 385051775);
            this.K.I(var17, 4, 0, var10);
         }
      }

   }

   void F(int var1, int var2, int var3, boolean[][] var4, boolean var5, int var6) {
      if (this.p != null) {
         int var7 = var3 + var3 + 1;
         var7 *= var7;
         if (this.K.bI.length < var7) {
            this.K.bI = new int[var7];
         }

         if (this.K.iI.S.length < this.glPopMatrix * 2) {
            this.K.iI = new TEI(this.glPopMatrix * 2);
         }

         int var8 = var1 - var3;
         int var9 = var8;
         if (var8 < 0) {
            var8 = 0;
         }

         int var10 = var2 - var3;
         int var11 = var10;
         if (var10 < 0) {
            var10 = 0;
         }

         int var12 = var1 + var3;
         if (var12 > this.Z * -506105871 - 1) {
            var12 = this.Z * -506105871 - 1;
         }

         int var13 = var2 + var3;
         if (var13 > this.I * -1148794921 - 1) {
            var13 = this.I * -1148794921 - 1;
         }

         int var14 = 0;
         int[] var15 = this.K.bI;

         int var16;
         for(var16 = var8; var16 <= var12; ++var16) {
            boolean[] var17 = var4[var16 - var9];

            for(int var18 = var10; var18 <= var13; ++var18) {
               if (var17[var18 - var11]) {
                  var15[var14++] = var18 * this.Z * -506105871 + var16;
               }
            }
         }

         this.K.D();
         this.K.Z((this.E & 7) != 0);

         for(var16 = 0; var16 < this.p.length - 0; ++var16) {
            ((OM)this.p[var16]).I(var15, var14);
         }

         if (!this.sqrt.C((byte)115)) {
            var16 = this.K.q;
            int var20 = this.K.I;
            this.K.c(0, var20, this.K.XI);
            this.K.Z(false);
            this.K.D(false);
            this.K.B(128);
            this.K.F(-2);
            this.K.I((SN)this.K.r);
            this.K.Z(8448, 7681);
            this.K.I(0, 34166, 770);
            this.K.C(0, 34167, 770);

            for(AE var21 = this.sqrt.Z(1797943581); var21 != null; var21 = this.sqrt.Z((byte)-37)) {
               RG var19 = (RG)var21;
               var19.I(var1, var2, var3, var4);
            }

            this.K.I(0, 5890, 768);
            this.K.C(0, 5890, 770);
            this.K.I((SN)null);
            this.K.c(var16, var20, this.K.XI);
         }

         if (this.N != null) {
            OpenGL.glPushMatrix();
            OpenGL.glTranslatef(0.0F, -1.0F, 0.0F);
            this.K.I(this.M, (UO)null, (UO)null, this.S);
            this.N.I(var1, var2, var3, var4, var5);
            OpenGL.glPopMatrix();
         }
      }

   }

   public void method6339(int var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean[][] var8) {
      CCI var9 = this.K.I((short)-628);
      if (this.P > 0 && var9 != null) {
         this.K.H();
         this.K.I(false);
         this.K.Z(false);
         this.K.B(false);
         this.K.D(false);
         this.K.B(0);
         this.K.F(-2);
         this.K.I((SN)null);
         glMatrixMode[0] = (float)var3 / (128.0F * (float)(this.C * -1212653763) * (float)var9.method545());
         glMatrixMode[1] = 0.0F;
         glMatrixMode[2] = 0.0F;
         glMatrixMode[3] = 0.0F;
         glMatrixMode[4] = 0.0F;
         glMatrixMode[5] = (float)var3 / (128.0F * (float)(this.C * -1212653763) * (float)var9.method552());
         glMatrixMode[6] = 0.0F;
         glMatrixMode[7] = 0.0F;
         glMatrixMode[8] = 0.0F;
         glMatrixMode[9] = 0.0F;
         glMatrixMode[10] = 0.0F;
         glMatrixMode[11] = 0.0F;
         glMatrixMode[12] = -1.0F - ((float)(var4 * var3) / 128.0F - (float)(var1 * 2)) / (float)var9.method545();
         glMatrixMode[13] = 1.0F - ((float)(2 * var2) + (float)(var7 * var3) / 128.0F) / (float)var9.method552();
         glMatrixMode[14] = 0.0F;
         glMatrixMode[15] = 1.0F;
         OpenGL.glMatrixMode(5889);
         OpenGL.glLoadMatrixf(glMatrixMode, 0);
         glMatrixMode[0] = 1.0F;
         glMatrixMode[1] = 0.0F;
         glMatrixMode[2] = 0.0F;
         glMatrixMode[3] = 0.0F;
         glMatrixMode[4] = 0.0F;
         glMatrixMode[5] = 0.0F;
         glMatrixMode[6] = 1.0F;
         glMatrixMode[7] = 0.0F;
         glMatrixMode[8] = 0.0F;
         glMatrixMode[9] = 1.0F;
         glMatrixMode[10] = 0.0F;
         glMatrixMode[11] = 0.0F;
         glMatrixMode[12] = 0.0F;
         glMatrixMode[13] = 0.0F;
         glMatrixMode[14] = 0.0F;
         glMatrixMode[15] = 1.0F;
         OpenGL.glMatrixMode(5888);
         OpenGL.glLoadMatrixf(glMatrixMode, 0);
         if ((this.E & 7) != 0) {
            this.K.Z(true);
            this.K.A();
         } else {
            this.K.Z(false);
         }

         this.K.I(this.M, this.A, this.x, this.S);
         if (this.K.iI.S.length < this.glPopMatrix * 2) {
            this.K.iI = new TEI(this.glPopMatrix * 2);
         } else {
            this.K.iI.A = 0;
         }

         int var10 = 0;
         TEI var11 = this.K.iI;
         int var12;
         int var13;
         int var14;
         short[] var15;
         int var16;
         if (this.K.u) {
            for(var12 = var5; var12 < var7; ++var12) {
               var13 = var12 * this.Z * -506105871 + var4;

               for(var14 = var4; var14 < var6; ++var14) {
                  if (var8[var14 - var4][var12 - var5]) {
                     var15 = this.X[var13];
                     if (var15 != null) {
                        for(var16 = 0; var16 < var15.length; ++var16) {
                           var11.Z(var15[var16] & '\uffff', 16711935);
                           ++var10;
                        }
                     }
                  }

                  ++var13;
               }
            }
         } else {
            for(var12 = var5; var12 < var7; ++var12) {
               var13 = var12 * this.Z * -506105871 + var4;

               for(var14 = var4; var14 < var6; ++var14) {
                  if (var8[var14 - var4][var12 - var5]) {
                     var15 = this.X[var13];
                     if (var15 != null) {
                        for(var16 = 0; var16 < var15.length; ++var16) {
                           var11.C(var15[var16] & '\uffff', 1368367793);
                           ++var10;
                        }
                     }
                  }

                  ++var13;
               }
            }
         }

         if (var10 > 0) {
            PY var17 = new PY(this.K, 5123, var11.S, var11.A * 385051775);
            this.K.I(var17, 4, 0, var10);
         }
      }

   }

   public GJI w(int var1, int var2, GJI var3) {
      if ((this.T[var1][var2] & 1) == 0) {
         return null;
      } else {
         int var4 = this.C * -1212653763 >> this.K.H;
         HJI var5 = (HJI)var3;
         HJI var6;
         if (var5 != null && var5.Z(var4, var4)) {
            var6 = var5;
            var5.I();
         } else {
            var6 = new HJI(this.K, var4, var4);
         }

         var6.I(0, 0, var4, var4);
         this.J(var6, var1, var2);
         return var6;
      }
   }

   void J(HJI var1, int var2, int var3) {
      int[] var4 = this.L[var2][var3];
      int[] var5 = this.H[var2][var3];
      int var6 = var4.length;
      if (this.K.zI.length < var6) {
         this.K.zI = new int[var6];
         this.K.cI = new int[var6];
      }

      int[] var7 = this.K.zI;
      int[] var8 = this.K.cI;

      int var9;
      for(var9 = 0; var9 < var6; ++var9) {
         var7[var9] = var4[var9] >> this.K.H;
         var8[var9] = var5[var9] >> this.K.H;
      }

      var9 = 0;

      while(var9 < var6) {
         int var10 = var7[var9];
         int var11 = var8[var9++];
         int var12 = var7[var9];
         int var13 = var8[var9++];
         int var14 = var7[var9];
         int var15 = var8[var9++];
         if ((var10 - var12) * (var13 - var15) - (var13 - var11) * (var14 - var12) > 0) {
            var1.I(var11, var13, var15, var10, var12, var14);
         }
      }

   }

   public void method6338(int var1, int var2, int var3, boolean[][] var4, boolean var5, int var6) {
      this.F(var1, var2, var3, var4, var5, var6);
   }

   public void method6335(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, ADI var11, boolean var12) {
      FEI var13 = this.K.LZ;
      if (var6 != null && this.method6335 == null) {
         this.method6335 = new int[this.Z * -506105871][this.I * -1148794921][];
      }

      if (var4 != null && this.method552 == null) {
         this.method552 = new int[this.Z * -506105871][this.I * -1148794921][];
      }

      this.L[var1][var2] = var3;
      this.H[var1][var2] = var5;
      this.G[var1][var2] = var7;
      this.method174[var1][var2] = var8;
      if (this.method6335 != null) {
         this.method6335[var1][var2] = var6;
      }

      if (this.method552 != null) {
         this.method552[var1][var2] = var4;
      }

      OM[] var14 = this.glTranslatef[var1][var2] = new OM[var7.length];

      for(int var15 = 0; var15 < var7.length; ++var15) {
         int var16 = var9[var15];
         int var17 = var10[var15];
         if ((this.E & 32) != 0 && var16 != -1 && var13.method174(var16, 602140986).B) {
            var17 = 128;
            var16 = -1;
         }

         long var18 = (long)(var11.C * -1475891183) << 48 | (long)(var11.I * 1996750669) << 42 | (long)(var11.Z * -1212608691) << 28 | (long)(var17 << 14) | (long)var16;

         AE var20;
         for(var20 = this.W.I(var18); var20 != null; var20 = this.W.I(-1829773748)) {
            OM var21 = (OM)var20;
            if (var21.A == var16 && var21.J == (float)var17 && var21.S.I(var11, (byte)-48)) {
               break;
            }
         }

         if (var20 == null) {
            var14[var15] = new OM(this, var16, var17, var11);
            this.W.I(var14[var15], var18);
         } else {
            var14[var15] = (OM)var20;
         }
      }

      if (var12) {
         this.T[var1][var2] = (byte)(this.T[var1][var2] | 1);
      }

      if (var7.length > this.Q) {
         this.Q = var7.length;
      }

      this.P += var7.length;
   }

   public void NA(GJI var1, int var2, int var3, int var4, int var5, boolean var6) {
      if (this.N != null && var1 != null) {
         int var7 = var2 - (var3 * this.K.K >> 8) >> this.K.H;
         int var8 = var4 - (var3 * this.K.Z >> 8) >> this.K.H;
         this.N.I(var1, var7, var8);
      }

   }

   public void method6342(GE var1, int[] var2) {
      this.sqrt.Z((AE)(new RG(this.K, this, var1, var2)), (int)136823922);
   }

   public void method6356(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, int[] var11, int[] var12, int[] var13, ADI var14, boolean var15) {
      int var16 = var10.length;
      int[] var17 = new int[var16 * 3];
      int[] var18 = new int[var16 * 3];
      int[] var19 = new int[var16 * 3];
      int[] var20 = var11 != null ? new int[var16 * 3] : null;
      int[] var21 = new int[var16 * 3];
      int[] var22 = new int[var16 * 3];
      int[] var23 = var4 != null ? new int[var16 * 3] : null;
      int[] var24 = var6 != null ? new int[var16 * 3] : null;
      int var25 = 0;

      for(int var26 = 0; var26 < var16; ++var26) {
         int var27 = var7[var26];
         int var28 = var8[var26];
         int var29 = var9[var26];
         var17[var25] = var3[var27];
         var18[var25] = var5[var27];
         var19[var25] = var10[var26];
         var21[var25] = var12[var26];
         var22[var25] = var13[var26];
         if (var11 != null) {
            var20[var25] = var11[var26];
         }

         if (var4 != null) {
            var23[var25] = var4[var27];
         }

         if (var6 != null) {
            var24[var25] = var6[var27];
         }

         ++var25;
         var17[var25] = var3[var28];
         var18[var25] = var5[var28];
         var19[var25] = var10[var26];
         var21[var25] = var12[var26];
         var22[var25] = var13[var26];
         if (var11 != null) {
            var20[var25] = var11[var26];
         }

         if (var4 != null) {
            var23[var25] = var4[var28];
         }

         if (var6 != null) {
            var24[var25] = var6[var28];
         }

         ++var25;
         var17[var25] = var3[var29];
         var18[var25] = var5[var29];
         var19[var25] = var10[var26];
         var21[var25] = var12[var26];
         var22[var25] = var13[var26];
         if (var11 != null) {
            var20[var25] = var11[var26];
         }

         if (var4 != null) {
            var23[var25] = var4[var29];
         }

         if (var6 != null) {
            var24[var25] = var6[var29];
         }

         ++var25;
      }

      this.method6335(var1, var2, var17, var23, var18, var24, var19, var20, var21, var22, var14, var15);
   }

   public void method6343(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, int[] var11, int[] var12, int[] var13, ADI var14, boolean var15) {
      int var16 = var10.length;
      int[] var17 = new int[var16 * 3];
      int[] var18 = new int[var16 * 3];
      int[] var19 = new int[var16 * 3];
      int[] var20 = var11 != null ? new int[var16 * 3] : null;
      int[] var21 = new int[var16 * 3];
      int[] var22 = new int[var16 * 3];
      int[] var23 = var4 != null ? new int[var16 * 3] : null;
      int[] var24 = var6 != null ? new int[var16 * 3] : null;
      int var25 = 0;

      for(int var26 = 0; var26 < var16; ++var26) {
         int var27 = var7[var26];
         int var28 = var8[var26];
         int var29 = var9[var26];
         var17[var25] = var3[var27];
         var18[var25] = var5[var27];
         var19[var25] = var10[var26];
         var21[var25] = var12[var26];
         var22[var25] = var13[var26];
         if (var11 != null) {
            var20[var25] = var11[var26];
         }

         if (var4 != null) {
            var23[var25] = var4[var27];
         }

         if (var6 != null) {
            var24[var25] = var6[var27];
         }

         ++var25;
         var17[var25] = var3[var28];
         var18[var25] = var5[var28];
         var19[var25] = var10[var26];
         var21[var25] = var12[var26];
         var22[var25] = var13[var26];
         if (var11 != null) {
            var20[var25] = var11[var26];
         }

         if (var4 != null) {
            var23[var25] = var4[var28];
         }

         if (var6 != null) {
            var24[var25] = var6[var28];
         }

         ++var25;
         var17[var25] = var3[var29];
         var18[var25] = var5[var29];
         var19[var25] = var10[var26];
         var21[var25] = var12[var26];
         var22[var25] = var13[var26];
         if (var11 != null) {
            var20[var25] = var11[var26];
         }

         if (var4 != null) {
            var23[var25] = var4[var29];
         }

         if (var6 != null) {
            var24[var25] = var6[var29];
         }

         ++var25;
      }

      this.method6335(var1, var2, var17, var23, var18, var24, var19, var20, var21, var22, var14, var15);
   }

   public void method6350(int var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean[][] var8) {
      CCI var9 = this.K.I((short)8066);
      if (this.P > 0 && var9 != null) {
         this.K.H();
         this.K.I(false);
         this.K.Z(false);
         this.K.B(false);
         this.K.D(false);
         this.K.B(0);
         this.K.F(-2);
         this.K.I((SN)null);
         glMatrixMode[0] = (float)var3 / (128.0F * (float)(this.C * -1212653763) * (float)var9.method545());
         glMatrixMode[1] = 0.0F;
         glMatrixMode[2] = 0.0F;
         glMatrixMode[3] = 0.0F;
         glMatrixMode[4] = 0.0F;
         glMatrixMode[5] = (float)var3 / (128.0F * (float)(this.C * -1212653763) * (float)var9.method552());
         glMatrixMode[6] = 0.0F;
         glMatrixMode[7] = 0.0F;
         glMatrixMode[8] = 0.0F;
         glMatrixMode[9] = 0.0F;
         glMatrixMode[10] = 0.0F;
         glMatrixMode[11] = 0.0F;
         glMatrixMode[12] = -1.0F - ((float)(var4 * var3) / 128.0F - (float)(var1 * 2)) / (float)var9.method545();
         glMatrixMode[13] = 1.0F - ((float)(2 * var2) + (float)(var7 * var3) / 128.0F) / (float)var9.method552();
         glMatrixMode[14] = 0.0F;
         glMatrixMode[15] = 1.0F;
         OpenGL.glMatrixMode(5889);
         OpenGL.glLoadMatrixf(glMatrixMode, 0);
         glMatrixMode[0] = 1.0F;
         glMatrixMode[1] = 0.0F;
         glMatrixMode[2] = 0.0F;
         glMatrixMode[3] = 0.0F;
         glMatrixMode[4] = 0.0F;
         glMatrixMode[5] = 0.0F;
         glMatrixMode[6] = 1.0F;
         glMatrixMode[7] = 0.0F;
         glMatrixMode[8] = 0.0F;
         glMatrixMode[9] = 1.0F;
         glMatrixMode[10] = 0.0F;
         glMatrixMode[11] = 0.0F;
         glMatrixMode[12] = 0.0F;
         glMatrixMode[13] = 0.0F;
         glMatrixMode[14] = 0.0F;
         glMatrixMode[15] = 1.0F;
         OpenGL.glMatrixMode(5888);
         OpenGL.glLoadMatrixf(glMatrixMode, 0);
         if ((this.E & 7) != 0) {
            this.K.Z(true);
            this.K.A();
         } else {
            this.K.Z(false);
         }

         this.K.I(this.M, this.A, this.x, this.S);
         if (this.K.iI.S.length < this.glPopMatrix * 2) {
            this.K.iI = new TEI(this.glPopMatrix * 2);
         } else {
            this.K.iI.A = 0;
         }

         int var10 = 0;
         TEI var11 = this.K.iI;
         int var12;
         int var13;
         int var14;
         short[] var15;
         int var16;
         if (this.K.u) {
            for(var12 = var5; var12 < var7; ++var12) {
               var13 = var12 * this.Z * -506105871 + var4;

               for(var14 = var4; var14 < var6; ++var14) {
                  if (var8[var14 - var4][var12 - var5]) {
                     var15 = this.X[var13];
                     if (var15 != null) {
                        for(var16 = 0; var16 < var15.length; ++var16) {
                           var11.Z(var15[var16] & '\uffff', 16711935);
                           ++var10;
                        }
                     }
                  }

                  ++var13;
               }
            }
         } else {
            for(var12 = var5; var12 < var7; ++var12) {
               var13 = var12 * this.Z * -506105871 + var4;

               for(var14 = var4; var14 < var6; ++var14) {
                  if (var8[var14 - var4][var12 - var5]) {
                     var15 = this.X[var13];
                     if (var15 != null) {
                        for(var16 = 0; var16 < var15.length; ++var16) {
                           var11.C(var15[var16] & '\uffff', 1368367793);
                           ++var10;
                        }
                     }
                  }

                  ++var13;
               }
            }
         }

         if (var10 > 0) {
            PY var17 = new PY(this.K, 5123, var11.S, var11.A * 385051775);
            this.K.I(var17, 4, 0, var10);
         }
      }

   }

   public void method6359(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, ADI var11, boolean var12) {
      FEI var13 = this.K.LZ;
      if (var6 != null && this.method6335 == null) {
         this.method6335 = new int[this.Z * -506105871][this.I * -1148794921][];
      }

      if (var4 != null && this.method552 == null) {
         this.method552 = new int[this.Z * -506105871][this.I * -1148794921][];
      }

      this.L[var1][var2] = var3;
      this.H[var1][var2] = var5;
      this.G[var1][var2] = var7;
      this.method174[var1][var2] = var8;
      if (this.method6335 != null) {
         this.method6335[var1][var2] = var6;
      }

      if (this.method552 != null) {
         this.method552[var1][var2] = var4;
      }

      OM[] var14 = this.glTranslatef[var1][var2] = new OM[var7.length];

      for(int var15 = 0; var15 < var7.length; ++var15) {
         int var16 = var9[var15];
         int var17 = var10[var15];
         if ((this.E & 32) != 0 && var16 != -1 && var13.method174(var16, 620135548).B) {
            var17 = 128;
            var16 = -1;
         }

         long var18 = (long)(var11.C * -1475891183) << 48 | (long)(var11.I * 1996750669) << 42 | (long)(var11.Z * -1212608691) << 28 | (long)(var17 << 14) | (long)var16;

         AE var20;
         for(var20 = this.W.I(var18); var20 != null; var20 = this.W.I(-2069832948)) {
            OM var21 = (OM)var20;
            if (var21.A == var16 && var21.J == (float)var17 && var21.S.I((ADI)var11, (byte)30)) {
               break;
            }
         }

         if (var20 == null) {
            var14[var15] = new OM(this, var16, var17, var11);
            this.W.I(var14[var15], var18);
         } else {
            var14[var15] = (OM)var20;
         }
      }

      if (var12) {
         this.T[var1][var2] = (byte)(this.T[var1][var2] | 1);
      }

      if (var7.length > this.Q) {
         this.Q = var7.length;
      }

      this.P += var7.length;
   }

   public void method6346(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, ADI var11, boolean var12) {
      FEI var13 = this.K.LZ;
      if (var6 != null && this.method6335 == null) {
         this.method6335 = new int[this.Z * -506105871][this.I * -1148794921][];
      }

      if (var4 != null && this.method552 == null) {
         this.method552 = new int[this.Z * -506105871][this.I * -1148794921][];
      }

      this.L[var1][var2] = var3;
      this.H[var1][var2] = var5;
      this.G[var1][var2] = var7;
      this.method174[var1][var2] = var8;
      if (this.method6335 != null) {
         this.method6335[var1][var2] = var6;
      }

      if (this.method552 != null) {
         this.method552[var1][var2] = var4;
      }

      OM[] var14 = this.glTranslatef[var1][var2] = new OM[var7.length];

      for(int var15 = 0; var15 < var7.length; ++var15) {
         int var16 = var9[var15];
         int var17 = var10[var15];
         if ((this.E & 32) != 0 && var16 != -1 && var13.method174(var16, 1671695698).B) {
            var17 = 128;
            var16 = -1;
         }

         long var18 = (long)(var11.C * -1475891183) << 48 | (long)(var11.I * 1996750669) << 42 | (long)(var11.Z * -1212608691) << 28 | (long)(var17 << 14) | (long)var16;

         AE var20;
         for(var20 = this.W.I(var18); var20 != null; var20 = this.W.I(-1821853943)) {
            OM var21 = (OM)var20;
            if (var21.A == var16 && var21.J == (float)var17 && var21.S.I(var11, (byte)-53)) {
               break;
            }
         }

         if (var20 == null) {
            var14[var15] = new OM(this, var16, var17, var11);
            this.W.I(var14[var15], var18);
         } else {
            var14[var15] = (OM)var20;
         }
      }

      if (var12) {
         this.T[var1][var2] = (byte)(this.T[var1][var2] | 1);
      }

      if (var7.length > this.Q) {
         this.Q = var7.length;
      }

      this.P += var7.length;
   }

   public GJI l(int var1, int var2, GJI var3) {
      if ((this.T[var1][var2] & 1) == 0) {
         return null;
      } else {
         int var4 = this.C * -1212653763 >> this.K.H;
         HJI var5 = (HJI)var3;
         HJI var6;
         if (var5 != null && var5.Z(var4, var4)) {
            var6 = var5;
            var5.I();
         } else {
            var6 = new HJI(this.K, var4, var4);
         }

         var6.I(0, 0, var4, var4);
         this.J(var6, var1, var2);
         return var6;
      }
   }

   public void h() {
      if (this.P > 0) {
         byte[][] var1 = new byte[this.Z * -506105871 + 1][this.I * -1148794921 + 1];

         int var2;
         for(var2 = 1; var2 < this.Z * -506105871; ++var2) {
            for(int var3 = 1; var3 < this.I * -1148794921; ++var3) {
               var1[var2][var3] = (byte)((this.R[var2 - 1][var3] >> 2) + (this.R[var2 + 1][var3] >> 3) + (this.R[var2][var3 - 1] >> 2) + (this.R[var2][var3 + 1] >> 3) + (this.R[var2][var3] >> 1));
            }
         }

         this.p = new AE[this.W.Z(-575368869)];
         this.W.I(this.p, 2072858153);

         for(var2 = 0; var2 < this.p.length; ++var2) {
            ((OM)this.p[var2]).B(this.P);
         }

         var2 = 24;
         if (this.method6335 != null) {
            var2 += 4;
         }

         if ((this.E & 7) != 0) {
            var2 += 12;
         }

         jaclib.memory.heap.I var64 = this.K.GI.f(this.P * var2, false);
         Stream var4 = new Stream(var64);
         OM[] var5 = new OM[this.P];
         int var6 = KW.C(this.P / 4, 1877653209);
         if (var6 < 1) {
            var6 = 1;
         }

         LX var7 = new LX(var6);
         OM[] var8 = new OM[this.Q];

         int var9;
         int var10;
         for(var9 = 0; var9 < this.Z * -506105871; ++var9) {
            for(var10 = 0; var10 < this.I * -1148794921; ++var10) {
               if (this.G[var9][var10] != null) {
                  OM[] var11 = this.glTranslatef[var9][var10];
                  int[] var12 = this.L[var9][var10];
                  int[] var13 = this.H[var9][var10];
                  int[] var14 = this.method174[var9][var10];
                  int[] var15 = this.G[var9][var10];
                  int[] var16 = this.method552 != null ? this.method552[var9][var10] : null;
                  int[] var17 = this.method6335 != null ? this.method6335[var9][var10] : null;
                  if (var14 == null) {
                     var14 = var15;
                  }

                  float var18 = this.method545[var9][var10];
                  float var19 = this.U[var9][var10];
                  float var20 = this.V[var9][var10];
                  float var21 = this.method545[var9][var10 + 1];
                  float var22 = this.U[var9][var10 + 1];
                  float var23 = this.V[var9][var10 + 1];
                  float var24 = this.method545[var9 + 1][var10 + 1];
                  float var25 = this.U[var9 + 1][var10 + 1];
                  float var26 = this.V[var9 + 1][var10 + 1];
                  float var27 = this.method545[var9 + 1][var10];
                  float var28 = this.U[var9 + 1][var10];
                  float var29 = this.V[var9 + 1][var10];
                  int var30 = var1[var9][var10] & 255;
                  int var31 = var1[var9][var10 + 1] & 255;
                  int var32 = var1[var9 + 1][var10 + 1] & 255;
                  int var33 = var1[var9 + 1][var10] & 255;
                  int var34 = 0;

                  int var37;
                  label343:
                  for(int var35 = 0; var35 < var15.length; ++var35) {
                     OM var36 = var11[var35];

                     for(var37 = 0; var37 < var34; ++var37) {
                        if (var8[var37] == var36) {
                           continue label343;
                        }
                     }

                     var8[var34++] = var36;
                  }

                  short[] var80 = this.X[var10 * this.Z * -506105871 + var9] = new short[var15.length];

                  for(int var81 = 0; var81 < var15.length; ++var81) {
                     var37 = (var9 << this.B * -2137349879) + var12[var81];
                     int var38 = (var10 << this.B * -2137349879) + var13[var81];
                     int var39 = var37 >> this.d;
                     int var40 = var38 >> this.d;
                     int var41 = var15[var81];
                     int var42 = var14[var81];
                     int var43 = var16 != null ? var16[var81] : 0;
                     long var44 = (long)var42 << 48 | (long)var41 << 32 | (long)(var39 << 16) | (long)var40;
                     int var46 = var12[var81];
                     int var47 = var13[var81];
                     byte var48 = 74;
                     int var49 = 0;
                     float var50 = 1.0F;
                     float var51;
                     float var52;
                     float var53;
                     float var58;
                     int var82;
                     if (var46 == 0 && var47 == 0) {
                        var51 = var18;
                        var52 = var19;
                        var53 = var20;
                        var82 = var48 - var30;
                     } else if (var46 == 0 && var47 == this.C * -1212653763) {
                        var51 = var21;
                        var52 = var22;
                        var53 = var23;
                        var82 = var48 - var31;
                     } else if (var46 == this.C * -1212653763 && var47 == this.C * -1212653763) {
                        var51 = var24;
                        var52 = var25;
                        var53 = var26;
                        var82 = var48 - var32;
                     } else if (var46 == this.C * -1212653763 && var47 == 0) {
                        var51 = var27;
                        var52 = var28;
                        var53 = var29;
                        var82 = var48 - var33;
                     } else {
                        float var54 = (float)var46 / (float)(this.C * -1212653763);
                        float var55 = (float)var47 / (float)(this.C * -1212653763);
                        float var56 = var18 + (var27 - var18) * var54;
                        float var57 = var19 + (var28 - var19) * var54;
                        var58 = var20 + (var29 - var20) * var54;
                        float var59 = var21 + (var24 - var21) * var54;
                        float var60 = var22 + (var25 - var22) * var54;
                        float var61 = var23 + (var26 - var23) * var54;
                        var51 = var56 + (var59 - var56) * var55;
                        var52 = var57 + (var60 - var57) * var55;
                        var53 = var58 + (var61 - var58) * var55;
                        int var62 = var30 + ((var33 - var30) * var46 >> this.B * -2137349879);
                        int var63 = var31 + ((var32 - var31) * var46 >> this.B * -2137349879);
                        var82 = var48 - (var62 + ((var63 - var62) * var47 >> this.B * -2137349879));
                     }

                     if (var41 != -1) {
                        int var83 = (var41 & 127) * var82 >> 7;
                        if (var83 < 2) {
                           var83 = 2;
                        } else if (var83 > 126) {
                           var83 = 126;
                        }

                        var49 = DE.I[var41 & 'ﾀ' | var83];
                        if ((this.E & 7) == 0) {
                           var50 = this.K.e[0] * var51 + this.K.e[1] * var52 + this.K.e[2] * var53;
                           var50 = this.K.k + var50 * (var50 > 0.0F ? this.K.l : this.K.m);
                        }
                     }

                     AE var85 = null;
                     if ((var37 & this.f - 1) == 0 && (var38 & this.f - 1) == 0) {
                        var85 = var7.I(var44);
                     }

                     int var84;
                     int var86;
                     if (var85 == null) {
                        if (var42 != var41) {
                           int var87 = (var42 & 127) * var82 >> 7;
                           if (var87 < 2) {
                              var87 = 2;
                           } else if (var87 > 126) {
                              var87 = 126;
                           }

                           var86 = DE.I[var42 & 'ﾀ' | var87];
                           if ((this.E & 7) == 0) {
                              float var10000 = this.K.e[0] * var51 + this.K.e[1] * var52 + this.K.e[2] * var53;
                              var58 = this.K.k + var50 * (var50 > 0.0F ? this.K.l : this.K.m);
                              int var88 = var86 >> 16 & 255;
                              int var89 = var86 >> 8 & 255;
                              int var90 = var86 & 255;
                              var88 = (int)((float)var88 * var58);
                              if (var88 < 0) {
                                 var88 = 0;
                              } else if (var88 > 255) {
                                 var88 = 255;
                              }

                              var89 = (int)((float)var89 * var58);
                              if (var89 < 0) {
                                 var89 = 0;
                              } else if (var89 > 255) {
                                 var89 = 255;
                              }

                              var90 = (int)((float)var90 * var58);
                              if (var90 < 0) {
                                 var90 = 0;
                              } else if (var90 > 255) {
                                 var90 = 255;
                              }

                              var86 = var88 << 16 | var89 << 8 | var90;
                           }
                        } else {
                           var86 = var49;
                        }

                        if (this.K.u) {
                           var4.d((float)var37);
                           var4.d((float)(this.I(var37, var38, -1419532745) + var43));
                           var4.d((float)var38);
                           var4.p((byte)(var86 >> 16));
                           var4.p((byte)(var86 >> 8));
                           var4.p((byte)var86);
                           var4.p(-1);
                           var4.d((float)var37);
                           var4.d((float)var38);
                           if (this.method6335 != null) {
                              var4.d(var17 != null ? (float)(var17[var81] - 1) : 0.0F);
                           }

                           if ((this.E & 7) != 0) {
                              var4.d(var51);
                              var4.d(var52);
                              var4.d(var53);
                           }
                        } else {
                           var4.u((float)var37);
                           var4.u((float)(this.I(var37, var38, -2119264527) + var43));
                           var4.u((float)var38);
                           var4.p((byte)(var86 >> 16));
                           var4.p((byte)(var86 >> 8));
                           var4.p((byte)var86);
                           var4.p(-1);
                           var4.u((float)var37);
                           var4.u((float)var38);
                           if (this.method6335 != null) {
                              var4.u(var17 != null ? (float)(var17[var81] - 1) : 0.0F);
                           }

                           if ((this.E & 7) != 0) {
                              var4.u(var51);
                              var4.u(var52);
                              var4.u(var53);
                           }
                        }

                        var84 = this.glPushMatrix++;
                        var80[var81] = (short)var84;
                        if (var41 != -1) {
                           var5[var84] = var11[var81];
                        }

                        var7.I(new DG(var80[var81]), var44);
                     } else {
                        var80[var81] = ((DG)var85).J;
                        var84 = var80[var81] & '\uffff';
                        if (var41 != -1 && var11[var81].Z * 7051297995265073167L < var5[var84].Z * 7051297995265073167L) {
                           var5[var84] = var11[var81];
                        }
                     }

                     for(var86 = 0; var86 < var34; ++var86) {
                        var8[var86].I(var84, var49, var82, var50);
                     }

                     ++this.glPopMatrix;
                  }
               }
            }
         }

         for(var9 = 0; var9 < this.glPushMatrix; ++var9) {
            OM var65 = var5[var9];
            if (var65 != null) {
               var65.C(var9);
            }
         }

         for(var9 = 0; var9 < this.Z * -506105871; ++var9) {
            for(var10 = 0; var10 < this.I * -1148794921; ++var10) {
               short[] var67 = this.X[var10 * this.Z * -506105871 + var9];
               if (var67 != null) {
                  int var70 = 0;

                  for(int var72 = 0; var72 < var67.length; ++var70) {
                     int var73 = var67[var72++] & '\uffff';
                     int var74 = var67[var72++] & '\uffff';
                     int var75 = var67[var72++] & '\uffff';
                     OM var76 = var5[var73];
                     OM var77 = var5[var74];
                     OM var78 = var5[var75];
                     OM var79 = null;
                     if (var76 != null) {
                        var76.I(var9, var10, var70);
                        var79 = var76;
                     }

                     if (var77 != null) {
                        var77.I(var9, var10, var70);
                        if (var79 == null || var77.Z * 7051297995265073167L < var79.Z * 7051297995265073167L) {
                           var79 = var77;
                        }
                     }

                     if (var78 != null) {
                        var78.I(var9, var10, var70);
                        if (var79 == null || var78.Z * 7051297995265073167L < var79.Z * 7051297995265073167L) {
                           var79 = var78;
                        }
                     }

                     if (var79 != null) {
                        if (var76 != null) {
                           var79.C(var73);
                        }

                        if (var77 != null) {
                           var79.C(var74);
                        }

                        if (var78 != null) {
                           var79.C(var75);
                        }

                        var79.I(var9, var10, var70);
                     }
                  }
               }
            }
         }

         var4.x();
         this.u = this.K.I(var2, (jaclib.memory.I)var64, var4.f(), false);
         if (this.u instanceof XU) {
            var64.t();
         }

         this.M = new UO(this.u, 5126, 3, 0);
         this.x = new UO(this.u, 5121, 4, 12);
         byte var66;
         if (this.method6335 != null) {
            this.S = new UO(this.u, 5126, 3, 16);
            var66 = 28;
         } else {
            this.S = new UO(this.u, 5126, 2, 16);
            var66 = 24;
         }

         if ((this.E & 7) != 0) {
            this.A = new UO(this.u, 5126, 3, var66);
         }

         long[] var68 = new long[this.p.length];

         for(int var69 = 0; var69 < this.p.length; ++var69) {
            OM var71 = (OM)this.p[var69];
            var68[var69] = var71.Z * 7051297995265073167L;
            var71.D(this.glPushMatrix);
         }

         HR.I(var68, this.p, (byte)-108);
         if (this.N != null) {
            this.N.I();
         }
      } else {
         this.N = null;
      }

      if ((this.glLoadMatrixf & 2) == 0) {
         this.H = null;
         this.L = null;
         this.G = null;
      }

      this.method6335 = null;
      this.method174 = null;
      this.method552 = null;
      this.glTranslatef = null;
      this.R = null;
      this.W = null;
      this.V = null;
      this.U = null;
      this.method545 = null;
   }

   public void method6357(int var1, int var2, int var3, boolean[][] var4, boolean var5, int var6) {
      this.F(var1, var2, var3, var4, var5, var6);
   }

   public void method6345(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, ADI var11, boolean var12) {
      FEI var13 = this.K.LZ;
      if (var6 != null && this.method6335 == null) {
         this.method6335 = new int[this.Z * -506105871][this.I * -1148794921][];
      }

      if (var4 != null && this.method552 == null) {
         this.method552 = new int[this.Z * -506105871][this.I * -1148794921][];
      }

      this.L[var1][var2] = var3;
      this.H[var1][var2] = var5;
      this.G[var1][var2] = var7;
      this.method174[var1][var2] = var8;
      if (this.method6335 != null) {
         this.method6335[var1][var2] = var6;
      }

      if (this.method552 != null) {
         this.method552[var1][var2] = var4;
      }

      OM[] var14 = this.glTranslatef[var1][var2] = new OM[var7.length];

      for(int var15 = 0; var15 < var7.length; ++var15) {
         int var16 = var9[var15];
         int var17 = var10[var15];
         if ((this.E & 32) != 0 && var16 != -1 && var13.method174(var16, 156111587).B) {
            var17 = 128;
            var16 = -1;
         }

         long var18 = (long)(var11.C * -1475891183) << 48 | (long)(var11.I * 1996750669) << 42 | (long)(var11.Z * -1212608691) << 28 | (long)(var17 << 14) | (long)var16;

         AE var20;
         for(var20 = this.W.I(var18); var20 != null; var20 = this.W.I(-2112383276)) {
            OM var21 = (OM)var20;
            if (var21.A == var16 && var21.J == (float)var17 && var21.S.I((ADI)var11, (byte)12)) {
               break;
            }
         }

         if (var20 == null) {
            var14[var15] = new OM(this, var16, var17, var11);
            this.W.I(var14[var15], var18);
         } else {
            var14[var15] = (OM)var20;
         }
      }

      if (var12) {
         this.T[var1][var2] = (byte)(this.T[var1][var2] | 1);
      }

      if (var7.length > this.Q) {
         this.Q = var7.length;
      }

      this.P += var7.length;
   }

   public void method6347(int var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean[][] var8) {
      CCI var9 = this.K.I((short)-5205);
      if (this.P > 0 && var9 != null) {
         this.K.H();
         this.K.I(false);
         this.K.Z(false);
         this.K.B(false);
         this.K.D(false);
         this.K.B(0);
         this.K.F(-2);
         this.K.I((SN)null);
         glMatrixMode[0] = (float)var3 / (128.0F * (float)(this.C * -1212653763) * (float)var9.method545());
         glMatrixMode[1] = 0.0F;
         glMatrixMode[2] = 0.0F;
         glMatrixMode[3] = 0.0F;
         glMatrixMode[4] = 0.0F;
         glMatrixMode[5] = (float)var3 / (128.0F * (float)(this.C * -1212653763) * (float)var9.method552());
         glMatrixMode[6] = 0.0F;
         glMatrixMode[7] = 0.0F;
         glMatrixMode[8] = 0.0F;
         glMatrixMode[9] = 0.0F;
         glMatrixMode[10] = 0.0F;
         glMatrixMode[11] = 0.0F;
         glMatrixMode[12] = -1.0F - ((float)(var4 * var3) / 128.0F - (float)(var1 * 2)) / (float)var9.method545();
         glMatrixMode[13] = 1.0F - ((float)(2 * var2) + (float)(var7 * var3) / 128.0F) / (float)var9.method552();
         glMatrixMode[14] = 0.0F;
         glMatrixMode[15] = 1.0F;
         OpenGL.glMatrixMode(5889);
         OpenGL.glLoadMatrixf(glMatrixMode, 0);
         glMatrixMode[0] = 1.0F;
         glMatrixMode[1] = 0.0F;
         glMatrixMode[2] = 0.0F;
         glMatrixMode[3] = 0.0F;
         glMatrixMode[4] = 0.0F;
         glMatrixMode[5] = 0.0F;
         glMatrixMode[6] = 1.0F;
         glMatrixMode[7] = 0.0F;
         glMatrixMode[8] = 0.0F;
         glMatrixMode[9] = 1.0F;
         glMatrixMode[10] = 0.0F;
         glMatrixMode[11] = 0.0F;
         glMatrixMode[12] = 0.0F;
         glMatrixMode[13] = 0.0F;
         glMatrixMode[14] = 0.0F;
         glMatrixMode[15] = 1.0F;
         OpenGL.glMatrixMode(5888);
         OpenGL.glLoadMatrixf(glMatrixMode, 0);
         if ((this.E & 7) != 0) {
            this.K.Z(true);
            this.K.A();
         } else {
            this.K.Z(false);
         }

         this.K.I(this.M, this.A, this.x, this.S);
         if (this.K.iI.S.length < this.glPopMatrix * 2) {
            this.K.iI = new TEI(this.glPopMatrix * 2);
         } else {
            this.K.iI.A = 0;
         }

         int var10 = 0;
         TEI var11 = this.K.iI;
         int var12;
         int var13;
         int var14;
         short[] var15;
         int var16;
         if (this.K.u) {
            for(var12 = var5; var12 < var7; ++var12) {
               var13 = var12 * this.Z * -506105871 + var4;

               for(var14 = var4; var14 < var6; ++var14) {
                  if (var8[var14 - var4][var12 - var5]) {
                     var15 = this.X[var13];
                     if (var15 != null) {
                        for(var16 = 0; var16 < var15.length; ++var16) {
                           var11.Z(var15[var16] & '\uffff', 16711935);
                           ++var10;
                        }
                     }
                  }

                  ++var13;
               }
            }
         } else {
            for(var12 = var5; var12 < var7; ++var12) {
               var13 = var12 * this.Z * -506105871 + var4;

               for(var14 = var4; var14 < var6; ++var14) {
                  if (var8[var14 - var4][var12 - var5]) {
                     var15 = this.X[var13];
                     if (var15 != null) {
                        for(var16 = 0; var16 < var15.length; ++var16) {
                           var11.C(var15[var16] & '\uffff', 1368367793);
                           ++var10;
                        }
                     }
                  }

                  ++var13;
               }
            }
         }

         if (var10 > 0) {
            PY var17 = new PY(this.K, 5123, var11.S, var11.A * 385051775);
            this.K.I(var17, 4, 0, var10);
         }
      }

   }

   public void method6349(int var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean[][] var8) {
      CCI var9 = this.K.I((short)-3637);
      if (this.P > 0 && var9 != null) {
         this.K.H();
         this.K.I(false);
         this.K.Z(false);
         this.K.B(false);
         this.K.D(false);
         this.K.B(0);
         this.K.F(-2);
         this.K.I((SN)null);
         glMatrixMode[0] = (float)var3 / (128.0F * (float)(this.C * -1212653763) * (float)var9.method545());
         glMatrixMode[1] = 0.0F;
         glMatrixMode[2] = 0.0F;
         glMatrixMode[3] = 0.0F;
         glMatrixMode[4] = 0.0F;
         glMatrixMode[5] = (float)var3 / (128.0F * (float)(this.C * -1212653763) * (float)var9.method552());
         glMatrixMode[6] = 0.0F;
         glMatrixMode[7] = 0.0F;
         glMatrixMode[8] = 0.0F;
         glMatrixMode[9] = 0.0F;
         glMatrixMode[10] = 0.0F;
         glMatrixMode[11] = 0.0F;
         glMatrixMode[12] = -1.0F - ((float)(var4 * var3) / 128.0F - (float)(var1 * 2)) / (float)var9.method545();
         glMatrixMode[13] = 1.0F - ((float)(2 * var2) + (float)(var7 * var3) / 128.0F) / (float)var9.method552();
         glMatrixMode[14] = 0.0F;
         glMatrixMode[15] = 1.0F;
         OpenGL.glMatrixMode(5889);
         OpenGL.glLoadMatrixf(glMatrixMode, 0);
         glMatrixMode[0] = 1.0F;
         glMatrixMode[1] = 0.0F;
         glMatrixMode[2] = 0.0F;
         glMatrixMode[3] = 0.0F;
         glMatrixMode[4] = 0.0F;
         glMatrixMode[5] = 0.0F;
         glMatrixMode[6] = 1.0F;
         glMatrixMode[7] = 0.0F;
         glMatrixMode[8] = 0.0F;
         glMatrixMode[9] = 1.0F;
         glMatrixMode[10] = 0.0F;
         glMatrixMode[11] = 0.0F;
         glMatrixMode[12] = 0.0F;
         glMatrixMode[13] = 0.0F;
         glMatrixMode[14] = 0.0F;
         glMatrixMode[15] = 1.0F;
         OpenGL.glMatrixMode(5888);
         OpenGL.glLoadMatrixf(glMatrixMode, 0);
         if ((this.E & 7) != 0) {
            this.K.Z(true);
            this.K.A();
         } else {
            this.K.Z(false);
         }

         this.K.I(this.M, this.A, this.x, this.S);
         if (this.K.iI.S.length < this.glPopMatrix * 2) {
            this.K.iI = new TEI(this.glPopMatrix * 2);
         } else {
            this.K.iI.A = 0;
         }

         int var10 = 0;
         TEI var11 = this.K.iI;
         int var12;
         int var13;
         int var14;
         short[] var15;
         int var16;
         if (this.K.u) {
            for(var12 = var5; var12 < var7; ++var12) {
               var13 = var12 * this.Z * -506105871 + var4;

               for(var14 = var4; var14 < var6; ++var14) {
                  if (var8[var14 - var4][var12 - var5]) {
                     var15 = this.X[var13];
                     if (var15 != null) {
                        for(var16 = 0; var16 < var15.length; ++var16) {
                           var11.Z(var15[var16] & '\uffff', 16711935);
                           ++var10;
                        }
                     }
                  }

                  ++var13;
               }
            }
         } else {
            for(var12 = var5; var12 < var7; ++var12) {
               var13 = var12 * this.Z * -506105871 + var4;

               for(var14 = var4; var14 < var6; ++var14) {
                  if (var8[var14 - var4][var12 - var5]) {
                     var15 = this.X[var13];
                     if (var15 != null) {
                        for(var16 = 0; var16 < var15.length; ++var16) {
                           var11.C(var15[var16] & '\uffff', 1368367793);
                           ++var10;
                        }
                     }
                  }

                  ++var13;
               }
            }
         }

         if (var10 > 0) {
            PY var17 = new PY(this.K, 5123, var11.S, var11.A * 385051775);
            this.K.I(var17, 4, 0, var10);
         }
      }

   }

   public boolean method6353(GJI var1, int var2, int var3, int var4, int var5, boolean var6) {
      if (this.N != null && var1 != null) {
         int var7 = var2 - (var3 * this.K.K >> 8) >> this.K.H;
         int var8 = var4 - (var3 * this.K.Z >> 8) >> this.K.H;
         return this.N.Z(var1, var7, var8);
      } else {
         return false;
      }
   }

   public void method6358(GE var1, int[] var2) {
      this.sqrt.Z((AE)(new RG(this.K, this, var1, var2)), (int)2091242360);
   }

   public void method6352(int var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean[][] var8) {
      CCI var9 = this.K.I((short)8148);
      if (this.P > 0 && var9 != null) {
         this.K.H();
         this.K.I(false);
         this.K.Z(false);
         this.K.B(false);
         this.K.D(false);
         this.K.B(0);
         this.K.F(-2);
         this.K.I((SN)null);
         glMatrixMode[0] = (float)var3 / (128.0F * (float)(this.C * -1212653763) * (float)var9.method545());
         glMatrixMode[1] = 0.0F;
         glMatrixMode[2] = 0.0F;
         glMatrixMode[3] = 0.0F;
         glMatrixMode[4] = 0.0F;
         glMatrixMode[5] = (float)var3 / (128.0F * (float)(this.C * -1212653763) * (float)var9.method552());
         glMatrixMode[6] = 0.0F;
         glMatrixMode[7] = 0.0F;
         glMatrixMode[8] = 0.0F;
         glMatrixMode[9] = 0.0F;
         glMatrixMode[10] = 0.0F;
         glMatrixMode[11] = 0.0F;
         glMatrixMode[12] = -1.0F - ((float)(var4 * var3) / 128.0F - (float)(var1 * 2)) / (float)var9.method545();
         glMatrixMode[13] = 1.0F - ((float)(2 * var2) + (float)(var7 * var3) / 128.0F) / (float)var9.method552();
         glMatrixMode[14] = 0.0F;
         glMatrixMode[15] = 1.0F;
         OpenGL.glMatrixMode(5889);
         OpenGL.glLoadMatrixf(glMatrixMode, 0);
         glMatrixMode[0] = 1.0F;
         glMatrixMode[1] = 0.0F;
         glMatrixMode[2] = 0.0F;
         glMatrixMode[3] = 0.0F;
         glMatrixMode[4] = 0.0F;
         glMatrixMode[5] = 0.0F;
         glMatrixMode[6] = 1.0F;
         glMatrixMode[7] = 0.0F;
         glMatrixMode[8] = 0.0F;
         glMatrixMode[9] = 1.0F;
         glMatrixMode[10] = 0.0F;
         glMatrixMode[11] = 0.0F;
         glMatrixMode[12] = 0.0F;
         glMatrixMode[13] = 0.0F;
         glMatrixMode[14] = 0.0F;
         glMatrixMode[15] = 1.0F;
         OpenGL.glMatrixMode(5888);
         OpenGL.glLoadMatrixf(glMatrixMode, 0);
         if ((this.E & 7) != 0) {
            this.K.Z(true);
            this.K.A();
         } else {
            this.K.Z(false);
         }

         this.K.I(this.M, this.A, this.x, this.S);
         if (this.K.iI.S.length < this.glPopMatrix * 2) {
            this.K.iI = new TEI(this.glPopMatrix * 2);
         } else {
            this.K.iI.A = 0;
         }

         int var10 = 0;
         TEI var11 = this.K.iI;
         int var12;
         int var13;
         int var14;
         short[] var15;
         int var16;
         if (this.K.u) {
            for(var12 = var5; var12 < var7; ++var12) {
               var13 = var12 * this.Z * -506105871 + var4;

               for(var14 = var4; var14 < var6; ++var14) {
                  if (var8[var14 - var4][var12 - var5]) {
                     var15 = this.X[var13];
                     if (var15 != null) {
                        for(var16 = 0; var16 < var15.length; ++var16) {
                           var11.Z(var15[var16] & '\uffff', 16711935);
                           ++var10;
                        }
                     }
                  }

                  ++var13;
               }
            }
         } else {
            for(var12 = var5; var12 < var7; ++var12) {
               var13 = var12 * this.Z * -506105871 + var4;

               for(var14 = var4; var14 < var6; ++var14) {
                  if (var8[var14 - var4][var12 - var5]) {
                     var15 = this.X[var13];
                     if (var15 != null) {
                        for(var16 = 0; var16 < var15.length; ++var16) {
                           var11.C(var15[var16] & '\uffff', 1368367793);
                           ++var10;
                        }
                     }
                  }

                  ++var13;
               }
            }
         }

         if (var10 > 0) {
            PY var17 = new PY(this.K, 5123, var11.S, var11.A * 385051775);
            this.K.I(var17, 4, 0, var10);
         }
      }

   }

   public void method6337(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, int[] var11, int[] var12, int[] var13, ADI var14, boolean var15) {
      int var16 = var10.length;
      int[] var17 = new int[var16 * 3];
      int[] var18 = new int[var16 * 3];
      int[] var19 = new int[var16 * 3];
      int[] var20 = var11 != null ? new int[var16 * 3] : null;
      int[] var21 = new int[var16 * 3];
      int[] var22 = new int[var16 * 3];
      int[] var23 = var4 != null ? new int[var16 * 3] : null;
      int[] var24 = var6 != null ? new int[var16 * 3] : null;
      int var25 = 0;

      for(int var26 = 0; var26 < var16; ++var26) {
         int var27 = var7[var26];
         int var28 = var8[var26];
         int var29 = var9[var26];
         var17[var25] = var3[var27];
         var18[var25] = var5[var27];
         var19[var25] = var10[var26];
         var21[var25] = var12[var26];
         var22[var25] = var13[var26];
         if (var11 != null) {
            var20[var25] = var11[var26];
         }

         if (var4 != null) {
            var23[var25] = var4[var27];
         }

         if (var6 != null) {
            var24[var25] = var6[var27];
         }

         ++var25;
         var17[var25] = var3[var28];
         var18[var25] = var5[var28];
         var19[var25] = var10[var26];
         var21[var25] = var12[var26];
         var22[var25] = var13[var26];
         if (var11 != null) {
            var20[var25] = var11[var26];
         }

         if (var4 != null) {
            var23[var25] = var4[var28];
         }

         if (var6 != null) {
            var24[var25] = var6[var28];
         }

         ++var25;
         var17[var25] = var3[var29];
         var18[var25] = var5[var29];
         var19[var25] = var10[var26];
         var21[var25] = var12[var26];
         var22[var25] = var13[var26];
         if (var11 != null) {
            var20[var25] = var11[var26];
         }

         if (var4 != null) {
            var23[var25] = var4[var29];
         }

         if (var6 != null) {
            var24[var25] = var6[var29];
         }

         ++var25;
      }

      this.method6335(var1, var2, var17, var23, var18, var24, var19, var20, var21, var22, var14, var15);
   }

   public GJI ax(int var1, int var2, GJI var3) {
      if ((this.T[var1][var2] & 1) == 0) {
         return null;
      } else {
         int var4 = this.C * -1212653763 >> this.K.H;
         HJI var5 = (HJI)var3;
         HJI var6;
         if (var5 != null && var5.Z(var4, var4)) {
            var6 = var5;
            var5.I();
         } else {
            var6 = new HJI(this.K, var4, var4);
         }

         var6.I(0, 0, var4, var4);
         this.J(var6, var1, var2);
         return var6;
      }
   }

   CSI(MJI var1, int var2, int var3, int var4, int var5, int[][] var6, int[][] var7, int var8) {
      super(var4, var5, var8, var6);
      this.K = var1;
      this.d = this.B * -2137349879 - 2;
      this.f = 1 << this.d;
      this.glLoadMatrixf = var2;
      this.E = var3;
      this.method552 = new int[var4][var5][];
      this.glTranslatef = new OM[var4][var5][];
      this.L = new int[var4][var5][];
      this.H = new int[var4][var5][];
      this.G = new int[var4][var5][];
      this.method174 = new int[var4][var5][];
      this.X = new short[var4 * var5][];
      this.T = new byte[var4][var5];
      this.R = new byte[var4 + 1][var5 + 1];
      this.method545 = new float[this.Z * -506105871 + 1][this.I * -1148794921 + 1];
      this.U = new float[this.Z * -506105871 + 1][this.I * -1148794921 + 1];
      this.V = new float[this.Z * -506105871 + 1][this.I * -1148794921 + 1];

      for(int var9 = 1; var9 < this.I * -1148794921; ++var9) {
         for(int var10 = 1; var10 < this.Z * -506105871; ++var10) {
            int var11 = var7[var10 + 1][var9] - var7[var10 - 1][var9];
            int var12 = var7[var10][var9 + 1] - var7[var10][var9 - 1];
            float var13 = (float)(1.0D / Math.sqrt((double)(var11 * var11 + 4 * var8 * var8 + var12 * var12)));
            this.method545[var10][var9] = (float)var11 * var13;
            this.U[var10][var9] = (float)(-var8 * 2) * var13;
            this.V[var10][var9] = (float)var12 * var13;
         }
      }

      this.W = new LX(128);
      if ((this.E & 16) != 0) {
         this.N = new KX(this.K, this);
      }

   }

   public void ak(GJI var1, int var2, int var3, int var4, int var5, boolean var6) {
      if (this.N != null && var1 != null) {
         int var7 = var2 - (var3 * this.K.K >> 8) >> this.K.H;
         int var8 = var4 - (var3 * this.K.Z >> 8) >> this.K.H;
         this.N.C(var1, var7, var8);
      }

   }

   public boolean method6354(GJI var1, int var2, int var3, int var4, int var5, boolean var6) {
      if (this.N != null && var1 != null) {
         int var7 = var2 - (var3 * this.K.K >> 8) >> this.K.H;
         int var8 = var4 - (var3 * this.K.Z >> 8) >> this.K.H;
         return this.N.Z(var1, var7, var8);
      } else {
         return false;
      }
   }

   public boolean method6355(GJI var1, int var2, int var3, int var4, int var5, boolean var6) {
      if (this.N != null && var1 != null) {
         int var7 = var2 - (var3 * this.K.K >> 8) >> this.K.H;
         int var8 = var4 - (var3 * this.K.Z >> 8) >> this.K.H;
         return this.N.Z(var1, var7, var8);
      } else {
         return false;
      }
   }

   public void method6336(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, int[] var11, int[] var12, int[] var13, ADI var14, boolean var15) {
      int var16 = var10.length;
      int[] var17 = new int[var16 * 3];
      int[] var18 = new int[var16 * 3];
      int[] var19 = new int[var16 * 3];
      int[] var20 = var11 != null ? new int[var16 * 3] : null;
      int[] var21 = new int[var16 * 3];
      int[] var22 = new int[var16 * 3];
      int[] var23 = var4 != null ? new int[var16 * 3] : null;
      int[] var24 = var6 != null ? new int[var16 * 3] : null;
      int var25 = 0;

      for(int var26 = 0; var26 < var16; ++var26) {
         int var27 = var7[var26];
         int var28 = var8[var26];
         int var29 = var9[var26];
         var17[var25] = var3[var27];
         var18[var25] = var5[var27];
         var19[var25] = var10[var26];
         var21[var25] = var12[var26];
         var22[var25] = var13[var26];
         if (var11 != null) {
            var20[var25] = var11[var26];
         }

         if (var4 != null) {
            var23[var25] = var4[var27];
         }

         if (var6 != null) {
            var24[var25] = var6[var27];
         }

         ++var25;
         var17[var25] = var3[var28];
         var18[var25] = var5[var28];
         var19[var25] = var10[var26];
         var21[var25] = var12[var26];
         var22[var25] = var13[var26];
         if (var11 != null) {
            var20[var25] = var11[var26];
         }

         if (var4 != null) {
            var23[var25] = var4[var28];
         }

         if (var6 != null) {
            var24[var25] = var6[var28];
         }

         ++var25;
         var17[var25] = var3[var29];
         var18[var25] = var5[var29];
         var19[var25] = var10[var26];
         var21[var25] = var12[var26];
         var22[var25] = var13[var26];
         if (var11 != null) {
            var20[var25] = var11[var26];
         }

         if (var4 != null) {
            var23[var25] = var4[var29];
         }

         if (var6 != null) {
            var24[var25] = var6[var29];
         }

         ++var25;
      }

      this.method6335(var1, var2, var17, var23, var18, var24, var19, var20, var21, var22, var14, var15);
   }

   public void method6348(int var1, int var2, int var3, boolean[][] var4, boolean var5, int var6) {
      this.F(var1, var2, var3, var4, var5, var6);
   }

   public void at(int var1, int var2, int var3) {
      if ((this.R[var1][var2] & 255) < var3) {
         this.R[var1][var2] = (byte)var3;
      }

   }

   public void av(GJI var1, int var2, int var3, int var4, int var5, boolean var6) {
      if (this.N != null && var1 != null) {
         int var7 = var2 - (var3 * this.K.K >> 8) >> this.K.H;
         int var8 = var4 - (var3 * this.K.Z >> 8) >> this.K.H;
         this.N.I(var1, var7, var8);
      }

   }

   public void method6344(GE var1, int[] var2) {
      this.sqrt.Z((AE)(new RG(this.K, this, var1, var2)), (int)1011020488);
   }

   public void UA(GJI var1, int var2, int var3, int var4, int var5, boolean var6) {
      if (this.N != null && var1 != null) {
         int var7 = var2 - (var3 * this.K.K >> 8) >> this.K.H;
         int var8 = var4 - (var3 * this.K.Z >> 8) >> this.K.H;
         this.N.C(var1, var7, var8);
      }

   }
}
