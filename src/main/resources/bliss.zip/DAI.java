public interface DAI {
   void method245(int var1, int var2, int var3, short var4);

   void method246(int var1, int var2, int var3);

   void method247(boolean var1, byte var2);

   void method248(boolean var1);
}
