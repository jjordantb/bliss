public class DQ {
   public static int B = 1024;
   public static int F = 9;
   public static int Z = 7;
   public static int aString6308 = 512;
   public static int append = 511;
   public static int equals = 8;
   public static int method5125 = 256;
   public static int random = 2;
   public static int sqrt = 128;

   static {
      Math.sqrt(131072.0D);
   }

   DQ() throws Throwable {
      throw new Error();
   }

   static final void I(OU var0, short var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.P.Z(-550588042) ? 1 : 0;
      } catch (RuntimeException var3) {
         throw I(var3, "ol.anh(" + ')');
      }
   }

   static void I(int var0, int var1, HSI var2, QJI var3, int var4, int var5, int var6) {
      try {
         int var7 = C.I * 1168366243;
         int[] var8 = C.J;

         for(int var9 = 0; var9 < var7; ++var9) {
            PEI var10 = XEI.MC[var8[var9]];
            if (var10 != null && var10.D(526198823) && !var10.mI && var10 != UA.F && var10.K == UA.F.K) {
               SF var11 = var10.I().I;
               int var12 = (int)var11.I / 128 - var0 / 128;
               int var13 = (int)var11.Z / 128 - var1 / 128;
               boolean var14 = false;

               for(int var15 = 0; var15 < XEI.kD * -1054937867; ++var15) {
                  if (var10.kI.equals(XEI.cI[var15]) && XEI.oD[var15] != 0) {
                     var14 = true;
                     break;
                  }
               }

               boolean var18 = false;

               for(int var16 = 0; var16 < -1801543887 * UII.I; ++var16) {
                  if (var10.kI.equals(EFI.F[var16].Z)) {
                     var18 = true;
                     break;
                  }
               }

               boolean var19 = false;
               if (-1473655357 * UA.F.wI != 0 && -1473655357 * var10.wI != 0 && var10.wI * -1473655357 == UA.F.wI * -1473655357) {
                  var19 = true;
               }

               if (var10.qI) {
                  OX.I(var2, var3, var4, var5, var12, var13, UEI.S[6], (byte)52);
               } else if (var19) {
                  OX.I(var2, var3, var4, var5, var12, var13, UEI.S[4], (byte)-19);
               } else if (var10.GZ) {
                  OX.I(var2, var3, var4, var5, var12, var13, UEI.S[7], (byte)-81);
               } else if (var14) {
                  OX.I(var2, var3, var4, var5, var12, var13, UEI.S[3], (byte)25);
               } else if (var18) {
                  OX.I(var2, var3, var4, var5, var12, var13, UEI.S[5], (byte)-50);
               } else {
                  OX.I(var2, var3, var4, var5, var12, var13, UEI.S[2], (byte)-40);
               }
            }
         }

      } catch (RuntimeException var17) {
         throw I(var17, "ol.n(" + ')');
      }
   }

   public static void I(String var0, boolean var1, boolean var2, boolean var3, boolean var4, byte var5) {
      try {
         FA.I(var0, var1, var2, "openjs", var3, var4, -1892115895);
      } catch (RuntimeException var7) {
         throw I(var7, "ol.a(" + ')');
      }
   }

   public static void I(GSI var0, KJ var1, int var2) {
      try {
         RFI[] var3 = RFI.Z(var1, DDI.C * -1217066055, 0);
         LC.E = new IBI[var3.length];

         int var4;
         for(var4 = 0; var4 < var3.length; ++var4) {
            LC.E[var4] = var0.method5125(var3[var4], true);
         }

         var3 = RFI.Z(var1, -355151363 * DDI.D, 0);
         AEI.E = new IBI[var3.length];

         for(var4 = 0; var4 < var3.length; ++var4) {
            AEI.E[var4] = var0.method5125(var3[var4], true);
         }

         var3 = RFI.Z(var1, 1838189665 * OZ.I, 0);
         JV.S = new IBI[var3.length];

         for(var4 = 0; var4 < var3.length; ++var4) {
            JV.S[var4] = var0.method5125(var3[var4], true);
         }

         var3 = RFI.Z(var1, MU.I * 1862609057, 0);
         LV.D = new IBI[var3.length];

         for(var4 = 0; var4 < var3.length; ++var4) {
            LV.D[var4] = var0.method5125(var3[var4], true);
         }

         var3 = RFI.Z(var1, -81301735 * DDI.B, 0);
         OI.K = new IBI[var3.length];

         for(var4 = 0; var4 < var3.length; ++var4) {
            OI.K[var4] = var0.method5125(var3[var4], true);
         }

         var3 = RFI.Z(var1, DDI.J * -2088314757, 0);
         DDI.E = new IBI[var3.length];

         for(var4 = 0; var4 < var3.length; ++var4) {
            DDI.E[var4] = var0.method5125(var3[var4], true);
         }

         var3 = RFI.Z(var1, PK.A * -1199789537, 0);
         IJ.C = new IBI[var3.length];
         byte var7 = 25;

         int var5;
         for(var5 = 0; var5 < var3.length; ++var5) {
            var3[var5].I(-var7 + (int)(Math.random() * (double)var7 * 2.0D), -var7 + (int)(Math.random() * (double)var7 * 2.0D), -var7 + (int)(Math.random() * (double)var7 * 2.0D));
            IJ.C[var5] = var0.method5125(var3[var5], true);
         }

         var3 = RFI.Z(var1, EFI.Z * -2107184677, 0);
         ODI.C = new IBI[var3.length];

         for(var5 = 0; var5 < var3.length; ++var5) {
            ODI.C[var5] = var0.method5125(var3[var5], true);
         }

         var3 = RFI.Z(var1, ZZI.Z * -1624054445, 0);
         UEI.S = new IBI[var3.length];
         var7 = 12;

         for(var5 = 0; var5 < var3.length; ++var5) {
            var3[var5].I(-var7 + (int)(Math.random() * (double)var7 * 2.0D), -var7 + (int)(Math.random() * (double)var7 * 2.0D), -var7 + (int)(Math.random() * (double)var7 * 2.0D));
            UEI.S[var5] = var0.method5125(var3[var5], true);
         }

         var3 = RFI.Z(var1, DDI.S * 1200791325, 0);
         WI.D = new IBI[var3.length];
         var7 = 12;

         for(var5 = 0; var5 < var3.length; ++var5) {
            var3[var5].I(-var7 + (int)(Math.random() * (double)var7 * 2.0D), -var7 + (int)(Math.random() * (double)var7 * 2.0D), -var7 + (int)(Math.random() * (double)var7 * 2.0D));
            WI.D[var5] = var0.method5125(var3[var5], true);
         }

         PZ.C = var0.method5125(RFI.I(var1, BJ.I * 1359711467, 0), true);
         ESI.F = var0.method5125(RFI.I(var1, NI.M * -1848350339, 0), true);
         var3 = RFI.Z(var1, EG.E * -328242359, 0);
         WJ.H = new IBI[var3.length];

         for(var5 = 0; var5 < var3.length; ++var5) {
            WJ.H[var5] = var0.method5125(var3[var5], true);
         }

      } catch (RuntimeException var6) {
         throw I(var6, "ol.d(" + ')');
      }
   }

   static String I(EL var0, byte var1) {
      try {
         return var0.K + RA.I(16777215, -1514789129) + " >";
      } catch (RuntimeException var3) {
         throw I(var3, "ol.be(" + ')');
      }
   }

   public static RuntimeException_Sub2 I(Throwable var0, String var1) {
      try {
         RuntimeException_Sub2 var2;
         if (var0 instanceof RuntimeException_Sub2) {
            var2 = (RuntimeException_Sub2)var0;
            StringBuilder var3 = new StringBuilder();
            var2.aString6308 = var3.append(var2.aString6308).append(' ').append(var1).toString();
         } else {
            var2 = new RuntimeException_Sub2(var0, var1);
         }

         return var2;
      } catch (RuntimeException var5) {
         throw I(var5, "ol.f(" + ')');
      }
   }
}
