public class FBI extends IBI {
   int aq;
   CEI method117;
   TAI method1526;
   int method1527;
   boolean method1528;
   boolean method271;
   int method5315;
   int method5353;
   int method5355;
   int method5356;
   NJI method545;
   boolean method552;
   boolean method626;
   boolean method76;

   public int method623() {
      return this.aq;
   }

   FBI(NJI var1, int var2, int var3, int[] var4, int var5, int var6) {
      this.method271 = false;
      this.method5315 = 0;
      this.method1527 = 0;
      this.method5355 = 0;
      this.method5356 = 0;
      this.method545 = var1;
      this.aq = var2;
      this.method5353 = var3;
      this.method1526 = null;
      this.method117 = var1.method5355(var2, var3, false, var4, var5, var6);
      this.method117.method80(true, true);
      this.method76 = this.method117.method92() != var2;
      this.method552 = this.method117.method76() != var3;
      this.method626 = !this.method76 && this.method117.method79();
      this.method1528 = !this.method552 && this.method117.method79();
      this.method545.I(12);
   }

   void method666(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10) {
      this.method545.K();
      this.method545.D(var9);
      float var12;
      float var13;
      if (this.method271) {
         float var11 = (float)this.method271();
         var12 = (float)this.method626();
         var13 = (var3 - var1) / var11;
         float var14 = (var4 - var2) / var11;
         float var15 = (var5 - var1) / var12;
         float var16 = (var6 - var2) / var12;
         float var17 = var15 * (float)this.method5315;
         float var18 = var16 * (float)this.method5315;
         float var19 = var13 * (float)this.method1527;
         float var20 = var14 * (float)this.method1527;
         float var21 = -var13 * (float)this.method5356;
         float var22 = -var14 * (float)this.method5356;
         float var23 = -var15 * (float)this.method5355;
         float var24 = -var16 * (float)this.method5355;
         var1 = var1 + var19 + var17;
         var2 = var2 + var20 + var18;
         var3 = var3 + var21 + var17;
         var4 = var4 + var22 + var18;
         var5 = var5 + var19 + var23;
         var6 = var6 + var20 + var24;
      }

      AZ var25 = this.method545.e;
      var25.Z = this.method117;
      var25.method1526(var7, var8);
      var12 = (float)this.method545.I((short)-3800).method545();
      var13 = (float)this.method545.I((short)-10695).method552();
      var25.D.J();
      var25.D.I[0] = (var3 - var1) * 2.0F / var12;
      var25.D.I[1] = (var4 - var2) * 2.0F / var13;
      var25.D.I[4] = (var5 - var1) * 2.0F / var12;
      var25.D.I[5] = (var6 - var2) * 2.0F / var13;
      var25.D.I[12] = (var1 + this.method545.method5315()) * 2.0F / var12 - 1.0F;
      var25.D.I[13] = (var2 + this.method545.method5315()) * 2.0F / var13 - 1.0F;
      var25.D.I[14] = -1.0F;
      var25.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
      var25.C = this.method545.I;
      var25.S = 0;
      var25.A = this.method545.vI;
      var25.method1527();
   }

   public void method655(int var1, int var2, int var3, int var4) {
      this.method1527 = var1;
      this.method5315 = var2;
      this.method5356 = var3;
      this.method5355 = var4;
      this.method271 = this.method1527 != 0 || this.method5315 != 0 || this.method5356 != 0 || this.method5355 != 0;
   }

   public void method675(int var1, int var2, int var3, int var4, int var5, int var6) {
      int[] var7 = this.method545.aq(var5, var6, var3, var4);
      if (var7 != null) {
         for(int var8 = 0; var8 < var7.length; ++var8) {
            var7[var8] |= -16777216;
         }

         this.aq(var1, var2, var3, var4, var7, 0, var3);
      }

   }

   public void method632(int var1, int var2, int var3) {
      int[] var4 = this.method545.aq(var1, var2, this.aq, this.method5353);
      int[] var5 = new int[this.aq * this.method5353];
      this.method117.method83(0, 0, this.aq, this.method5353, var5, 0);
      int var6;
      int var7;
      int var8;
      if (var3 == 0) {
         for(var6 = 0; var6 < this.method5353; ++var6) {
            var7 = var6 * this.aq;

            for(var8 = 0; var8 < this.aq; ++var8) {
               var5[var7 + var8] = var5[var7 + var8] & 16777215 | var4[var7 + var8] << 8 & -16777216;
            }
         }
      } else if (var3 == 1) {
         for(var6 = 0; var6 < this.method5353; ++var6) {
            var7 = var6 * this.aq;

            for(var8 = 0; var8 < this.aq; ++var8) {
               var5[var7 + var8] = var5[var7 + var8] & 16777215 | var4[var7 + var8] << 16 & -16777216;
            }
         }
      } else if (var3 == 2) {
         for(var6 = 0; var6 < this.method5353; ++var6) {
            var7 = var6 * this.aq;

            for(var8 = 0; var8 < this.aq; ++var8) {
               var5[var7 + var8] = var5[var7 + var8] & 16777215 | var4[var7 + var8] << 24 & -16777216;
            }
         }
      } else if (var3 == 3) {
         for(var6 = 0; var6 < this.method5353; ++var6) {
            var7 = var6 * this.aq;

            for(var8 = 0; var8 < this.aq; ++var8) {
               var5[var7 + var8] = var5[var7 + var8] & 16777215 | (var4[var7 + var8] != 0 ? -16777216 : 0);
            }
         }
      }

      this.aq(0, 0, this.aq, this.method5353, var5, 0, this.aq);
   }

   public void method621(int var1, int var2, int var3, int var4) {
      this.method1527 = var1;
      this.method5315 = var2;
      this.method5356 = var3;
      this.method5355 = var4;
      this.method271 = this.method1527 != 0 || this.method5315 != 0 || this.method5356 != 0 || this.method5355 != 0;
   }

   public int method272() {
      return this.aq + this.method1527 + this.method5356;
   }

   public void method628(int var1, int var2, int var3) {
      int[] var4 = this.method545.aq(var1, var2, this.aq, this.method5353);
      int[] var5 = new int[this.aq * this.method5353];
      this.method117.method83(0, 0, this.aq, this.method5353, var5, 0);
      int var6;
      int var7;
      int var8;
      if (var3 == 0) {
         for(var6 = 0; var6 < this.method5353; ++var6) {
            var7 = var6 * this.aq;

            for(var8 = 0; var8 < this.aq; ++var8) {
               var5[var7 + var8] = var5[var7 + var8] & 16777215 | var4[var7 + var8] << 8 & -16777216;
            }
         }
      } else if (var3 == 1) {
         for(var6 = 0; var6 < this.method5353; ++var6) {
            var7 = var6 * this.aq;

            for(var8 = 0; var8 < this.aq; ++var8) {
               var5[var7 + var8] = var5[var7 + var8] & 16777215 | var4[var7 + var8] << 16 & -16777216;
            }
         }
      } else if (var3 == 2) {
         for(var6 = 0; var6 < this.method5353; ++var6) {
            var7 = var6 * this.aq;

            for(var8 = 0; var8 < this.aq; ++var8) {
               var5[var7 + var8] = var5[var7 + var8] & 16777215 | var4[var7 + var8] << 24 & -16777216;
            }
         }
      } else if (var3 == 3) {
         for(var6 = 0; var6 < this.method5353; ++var6) {
            var7 = var6 * this.aq;

            for(var8 = 0; var8 < this.aq; ++var8) {
               var5[var7 + var8] = var5[var7 + var8] & 16777215 | (var4[var7 + var8] != 0 ? -16777216 : 0);
            }
         }
      }

      this.aq(0, 0, this.aq, this.method5353, var5, 0, this.aq);
   }

   public int method271() {
      return this.aq + this.method1527 + this.method5356;
   }

   public int method625() {
      return this.method5353;
   }

   public int method626() {
      return this.method5353 + this.method5315 + this.method5355;
   }

   public TAI method627() {
      return this.method1526;
   }

   void method671(float var1, float var2, float var3, float var4, float var5, float var6, int var7, QJI var8, int var9, int var10) {
      this.method545.K();
      AZ var11 = this.method545.e;
      var11.Z = this.method117;
      var11.method1526(1, -1);
      float var12 = (float)this.method545.I((short)8222).method545();
      float var13 = (float)this.method545.I((short)-4129).method552();
      var11.D.J();
      if (this.method271) {
         float var14 = (float)this.aq / (float)this.method271();
         float var15 = (float)this.method5353 / (float)this.method626();
         var11.D.I[0] = (var3 - var1) * var14;
         var11.D.I[1] = (var4 - var2) * var14;
         var11.D.I[4] = (var5 - var1) * var15;
         var11.D.I[5] = (var6 - var2) * var15;
         var11.D.I[12] = (var1 + (float)this.method1527) * var14 + this.method545.method5315();
         var11.D.I[13] = (var2 + (float)this.method5315) * var15 + this.method545.method5315();
      } else {
         var11.D.I[0] = var3 - var1;
         var11.D.I[1] = var4 - var2;
         var11.D.I[4] = var5 - var1;
         var11.D.I[5] = var6 - var2;
         var11.D.I[12] = var1 + this.method545.method5315();
         var11.D.I[13] = var2 + this.method545.method5315();
      }

      YF var16 = this.method545.Q;
      var16.J();
      var16.I[0] = 2.0F / var12;
      var16.I[5] = 2.0F / var13;
      var16.I[12] = -1.0F;
      var16.I[13] = -1.0F;
      var16.I[14] = -1.0F;
      var11.D.Z(var16);
      var11.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
      var11.C = this.method545.I;
      var11.S = 0;
      var11.A = this.method545.vI;
      CEI var17 = ((UJI)var8).I;
      var11.I = var17;
      var11.J.J();
      var11.J.I[0] = (var3 - var1) * var17.method77(1.0F);
      var11.J.I[1] = (var4 - var2) * var17.method77(1.0F);
      var11.J.I[4] = (var5 - var1) * var17.method78(1.0F);
      var11.J.I[5] = (var6 - var2) * var17.method78(1.0F);
      var11.J.I[12] = (var1 - (float)var9) * var17.method77(1.0F);
      var11.J.I[13] = (var2 - (float)var10) * var17.method78(1.0F);
      var11.method1528();
   }

   public void method631(int var1, int var2, int var3, int var4, int var5) {
      this.method545.K();
      this.method545.D(var5);
      AZ var6 = this.method545.e;
      var6.Z = this.method117;
      var6.method1526(var3, var4);
      var1 += this.method1527;
      var2 += this.method5315;
      float var7 = (float)this.method545.I((short)-1641).method545();
      float var8 = (float)this.method545.I((short)-380).method552();
      var6.D.I((float)this.aq * 2.0F / var7, (float)this.method5353 * 2.0F / var8, 1.0F, 1.0F);
      var6.D.I[12] = ((float)var1 + this.method545.method5315()) * 2.0F / var7 - 1.0F;
      var6.D.I[13] = ((float)var2 + this.method545.method5315()) * 2.0F / var8 - 1.0F;
      var6.D.I[14] = -1.0F;
      var6.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
      var6.C = this.method545.I;
      var6.S = 0;
      var6.A = this.method545.vI;
      var6.method1527();
   }

   public void method650(int var1, int var2, QJI var3, int var4, int var5) {
      this.method545.K();
      AZ var6 = this.method545.e;
      var6.Z = this.method117;
      var6.method1526(1, -1);
      var1 += this.method1527;
      var2 += this.method5315;
      float var7 = (float)this.method545.I((short)-9173).method545();
      float var8 = (float)this.method545.I((short)-16185).method552();
      var6.D.I((float)this.aq * 2.0F / var7, (float)this.method5353 * 2.0F / var8, 1.0F, 1.0F);
      var6.D.I[12] = ((float)var1 + this.method545.method5315()) * 2.0F / var7 - 1.0F;
      var6.D.I[13] = ((float)var2 + this.method545.method5315()) * 2.0F / var8 - 1.0F;
      var6.D.I[14] = -1.0F;
      var6.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
      var6.C = this.method545.I;
      var6.S = 0;
      var6.A = this.method545.vI;
      CEI var9 = ((UJI)var3).I;
      var6.I = var9;
      var6.J.I(var9.method77((float)this.aq), var9.method78((float)this.method5353), 1.0F, 1.0F);
      var6.J.I[12] = var9.method77((float)(var1 - var4));
      var6.J.I[13] = var9.method78((float)(var2 - var5));
      var6.method1528();
   }

   void method635(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      this.method545.K();
      this.method545.D(var7);
      AZ var9 = this.method545.e;
      var9.Z = this.method117;
      var9.method1526(var5, var6);
      if (this.method271) {
         var3 = var3 * this.aq / this.method271();
         var4 = var4 * this.method5353 / this.method626();
         var1 += this.method1527 * var3 / this.aq;
         var2 += this.method5315 * var4 / this.method5353;
      }

      float var10 = (float)this.method545.I((short)7730).method545();
      float var11 = (float)this.method545.I((short)-15790).method552();
      var9.D.I((float)var3 * 2.0F / var10, (float)var4 * 2.0F / var11, 1.0F, 1.0F);
      var9.D.I[12] = ((float)var1 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
      var9.D.I[13] = ((float)var2 + this.method545.method5315()) * 2.0F / var11 - 1.0F;
      var9.D.I[14] = -1.0F;
      var9.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
      var9.C = this.method545.I;
      var9.S = 0;
      var9.A = this.method545.vI;
      var9.method1527();
   }

   public void method622(int[] var1) {
      var1[0] = this.method1527;
      var1[1] = this.method5315;
      var1[2] = this.method5356;
      var1[3] = this.method5355;
   }

   void method642(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10) {
      this.method545.K();
      this.method545.D(var9);
      float var12;
      float var13;
      if (this.method271) {
         float var11 = (float)this.method271();
         var12 = (float)this.method626();
         var13 = (var3 - var1) / var11;
         float var14 = (var4 - var2) / var11;
         float var15 = (var5 - var1) / var12;
         float var16 = (var6 - var2) / var12;
         float var17 = var15 * (float)this.method5315;
         float var18 = var16 * (float)this.method5315;
         float var19 = var13 * (float)this.method1527;
         float var20 = var14 * (float)this.method1527;
         float var21 = -var13 * (float)this.method5356;
         float var22 = -var14 * (float)this.method5356;
         float var23 = -var15 * (float)this.method5355;
         float var24 = -var16 * (float)this.method5355;
         var1 = var1 + var19 + var17;
         var2 = var2 + var20 + var18;
         var3 = var3 + var21 + var17;
         var4 = var4 + var22 + var18;
         var5 = var5 + var19 + var23;
         var6 = var6 + var20 + var24;
      }

      AZ var25 = this.method545.e;
      var25.Z = this.method117;
      var25.method1526(var7, var8);
      var12 = (float)this.method545.I((short)-6090).method545();
      var13 = (float)this.method545.I((short)1699).method552();
      var25.D.J();
      var25.D.I[0] = (var3 - var1) * 2.0F / var12;
      var25.D.I[1] = (var4 - var2) * 2.0F / var13;
      var25.D.I[4] = (var5 - var1) * 2.0F / var12;
      var25.D.I[5] = (var6 - var2) * 2.0F / var13;
      var25.D.I[12] = (var1 + this.method545.method5315()) * 2.0F / var12 - 1.0F;
      var25.D.I[13] = (var2 + this.method545.method5315()) * 2.0F / var13 - 1.0F;
      var25.D.I[14] = -1.0F;
      var25.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
      var25.C = this.method545.I;
      var25.S = 0;
      var25.A = this.method545.vI;
      var25.method1527();
   }

   void method644(float var1, float var2, float var3, float var4, float var5, float var6, int var7, QJI var8, int var9, int var10) {
      this.method545.K();
      AZ var11 = this.method545.e;
      var11.Z = this.method117;
      var11.method1526(1, -1);
      float var12 = (float)this.method545.I((short)1715).method545();
      float var13 = (float)this.method545.I((short)551).method552();
      var11.D.J();
      if (this.method271) {
         float var14 = (float)this.aq / (float)this.method271();
         float var15 = (float)this.method5353 / (float)this.method626();
         var11.D.I[0] = (var3 - var1) * var14;
         var11.D.I[1] = (var4 - var2) * var14;
         var11.D.I[4] = (var5 - var1) * var15;
         var11.D.I[5] = (var6 - var2) * var15;
         var11.D.I[12] = (var1 + (float)this.method1527) * var14 + this.method545.method5315();
         var11.D.I[13] = (var2 + (float)this.method5315) * var15 + this.method545.method5315();
      } else {
         var11.D.I[0] = var3 - var1;
         var11.D.I[1] = var4 - var2;
         var11.D.I[4] = var5 - var1;
         var11.D.I[5] = var6 - var2;
         var11.D.I[12] = var1 + this.method545.method5315();
         var11.D.I[13] = var2 + this.method545.method5315();
      }

      YF var16 = this.method545.Q;
      var16.J();
      var16.I[0] = 2.0F / var12;
      var16.I[5] = 2.0F / var13;
      var16.I[12] = -1.0F;
      var16.I[13] = -1.0F;
      var16.I[14] = -1.0F;
      var11.D.Z(var16);
      var11.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
      var11.C = this.method545.I;
      var11.S = 0;
      var11.A = this.method545.vI;
      CEI var17 = ((UJI)var8).I;
      var11.I = var17;
      var11.J.J();
      var11.J.I[0] = (var3 - var1) * var17.method77(1.0F);
      var11.J.I[1] = (var4 - var2) * var17.method77(1.0F);
      var11.J.I[4] = (var5 - var1) * var17.method78(1.0F);
      var11.J.I[5] = (var6 - var2) * var17.method78(1.0F);
      var11.J.I[12] = (var1 - (float)var9) * var17.method77(1.0F);
      var11.J.I[13] = (var2 - (float)var10) * var17.method78(1.0F);
      var11.method1528();
   }

   FBI(NJI var1, CEI var2, int var3, int var4) {
      this.method271 = false;
      this.method5315 = 0;
      this.method1527 = 0;
      this.method5355 = 0;
      this.method5356 = 0;
      this.method545 = var1;
      this.aq = var3;
      this.method5353 = var4;
      this.method117 = var2;
      this.method1526 = null;
      this.method76 = this.method117.method92() != var3;
      this.method552 = this.method117.method76() != var4;
      this.method626 = !this.method76 && this.method117.method79();
      this.method1528 = !this.method552 && this.method117.method79();
      this.method545.I(12);
   }

   public void method649(int var1, int var2, int var3, int var4, int var5) {
      this.method545.K();
      this.method545.D(var5);
      AZ var6 = this.method545.e;
      var6.Z = this.method117;
      var6.method1526(var3, var4);
      var1 += this.method1527;
      var2 += this.method5315;
      float var7 = (float)this.method545.I((short)-1445).method545();
      float var8 = (float)this.method545.I((short)11490).method552();
      var6.D.I((float)this.aq * 2.0F / var7, (float)this.method5353 * 2.0F / var8, 1.0F, 1.0F);
      var6.D.I[12] = ((float)var1 + this.method545.method5315()) * 2.0F / var7 - 1.0F;
      var6.D.I[13] = ((float)var2 + this.method545.method5315()) * 2.0F / var8 - 1.0F;
      var6.D.I[14] = -1.0F;
      var6.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
      var6.C = this.method545.I;
      var6.S = 0;
      var6.A = this.method545.vI;
      var6.method1527();
   }

   public TAI method647() {
      return this.method1526;
   }

   public void method643(int var1, int var2, int var3, int var4, int var5) {
      this.method545.K();
      this.method545.D(var5);
      AZ var6 = this.method545.e;
      var6.Z = this.method117;
      var6.method1526(var3, var4);
      var1 += this.method1527;
      var2 += this.method5315;
      float var7 = (float)this.method545.I((short)-24161).method545();
      float var8 = (float)this.method545.I((short)11826).method552();
      var6.D.I((float)this.aq * 2.0F / var7, (float)this.method5353 * 2.0F / var8, 1.0F, 1.0F);
      var6.D.I[12] = ((float)var1 + this.method545.method5315()) * 2.0F / var7 - 1.0F;
      var6.D.I[13] = ((float)var2 + this.method545.method5315()) * 2.0F / var8 - 1.0F;
      var6.D.I[14] = -1.0F;
      var6.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
      var6.C = this.method545.I;
      var6.S = 0;
      var6.A = this.method545.vI;
      var6.method1527();
   }

   public void method648(int var1, int var2, int var3, int var4, int var5) {
      this.method545.K();
      this.method545.D(var5);
      AZ var6 = this.method545.e;
      var6.Z = this.method117;
      var6.method1526(var3, var4);
      var1 += this.method1527;
      var2 += this.method5315;
      float var7 = (float)this.method545.I((short)14710).method545();
      float var8 = (float)this.method545.I((short)15315).method552();
      var6.D.I((float)this.aq * 2.0F / var7, (float)this.method5353 * 2.0F / var8, 1.0F, 1.0F);
      var6.D.I[12] = ((float)var1 + this.method545.method5315()) * 2.0F / var7 - 1.0F;
      var6.D.I[13] = ((float)var2 + this.method545.method5315()) * 2.0F / var8 - 1.0F;
      var6.D.I[14] = -1.0F;
      var6.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
      var6.C = this.method545.I;
      var6.S = 0;
      var6.A = this.method545.vI;
      var6.method1527();
   }

   public void method674(int var1, int var2, int var3, int var4, int var5) {
      this.method545.K();
      this.method545.D(var5);
      AZ var6 = this.method545.e;
      var6.Z = this.method117;
      var6.method1526(var3, var4);
      var1 += this.method1527;
      var2 += this.method5315;
      float var7 = (float)this.method545.I((short)24362).method545();
      float var8 = (float)this.method545.I((short)10959).method552();
      var6.D.I((float)this.aq * 2.0F / var7, (float)this.method5353 * 2.0F / var8, 1.0F, 1.0F);
      var6.D.I[12] = ((float)var1 + this.method545.method5315()) * 2.0F / var7 - 1.0F;
      var6.D.I[13] = ((float)var2 + this.method545.method5315()) * 2.0F / var8 - 1.0F;
      var6.D.I[14] = -1.0F;
      var6.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
      var6.C = this.method545.I;
      var6.S = 0;
      var6.A = this.method545.vI;
      var6.method1527();
   }

   void method676(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10) {
      this.method545.K();
      this.method545.D(var9);
      float var12;
      float var13;
      if (this.method271) {
         float var11 = (float)this.method271();
         var12 = (float)this.method626();
         var13 = (var3 - var1) / var11;
         float var14 = (var4 - var2) / var11;
         float var15 = (var5 - var1) / var12;
         float var16 = (var6 - var2) / var12;
         float var17 = var15 * (float)this.method5315;
         float var18 = var16 * (float)this.method5315;
         float var19 = var13 * (float)this.method1527;
         float var20 = var14 * (float)this.method1527;
         float var21 = -var13 * (float)this.method5356;
         float var22 = -var14 * (float)this.method5356;
         float var23 = -var15 * (float)this.method5355;
         float var24 = -var16 * (float)this.method5355;
         var1 = var1 + var19 + var17;
         var2 = var2 + var20 + var18;
         var3 = var3 + var21 + var17;
         var4 = var4 + var22 + var18;
         var5 = var5 + var19 + var23;
         var6 = var6 + var20 + var24;
      }

      AZ var25 = this.method545.e;
      var25.Z = this.method117;
      var25.method1526(var7, var8);
      var12 = (float)this.method545.I((short)-15231).method545();
      var13 = (float)this.method545.I((short)-4660).method552();
      var25.D.J();
      var25.D.I[0] = (var3 - var1) * 2.0F / var12;
      var25.D.I[1] = (var4 - var2) * 2.0F / var13;
      var25.D.I[4] = (var5 - var1) * 2.0F / var12;
      var25.D.I[5] = (var6 - var2) * 2.0F / var13;
      var25.D.I[12] = (var1 + this.method545.method5315()) * 2.0F / var12 - 1.0F;
      var25.D.I[13] = (var2 + this.method545.method5315()) * 2.0F / var13 - 1.0F;
      var25.D.I[14] = -1.0F;
      var25.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
      var25.C = this.method545.I;
      var25.S = 0;
      var25.A = this.method545.vI;
      var25.method1527();
   }

   public int method653() {
      return this.method5353 + this.method5315 + this.method5355;
   }

   void method651(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      this.method545.K();
      this.method545.D(var7);
      AZ var9 = this.method545.e;
      var9.Z = this.method117;
      var9.method1526(var5, var6);
      if (this.method271) {
         var3 = var3 * this.aq / this.method271();
         var4 = var4 * this.method5353 / this.method626();
         var1 += this.method1527 * var3 / this.aq;
         var2 += this.method5315 * var4 / this.method5353;
      }

      float var10 = (float)this.method545.I((short)-12376).method545();
      float var11 = (float)this.method545.I((short)-8111).method552();
      var9.D.I((float)var3 * 2.0F / var10, (float)var4 * 2.0F / var11, 1.0F, 1.0F);
      var9.D.I[12] = ((float)var1 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
      var9.D.I[13] = ((float)var2 + this.method545.method5315()) * 2.0F / var11 - 1.0F;
      var9.D.I[14] = -1.0F;
      var9.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
      var9.C = this.method545.I;
      var9.S = 0;
      var9.A = this.method545.vI;
      var9.method1527();
   }

   void method652(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      this.method545.K();
      this.method545.D(var7);
      AZ var9 = this.method545.e;
      var9.Z = this.method117;
      var9.method1526(var5, var6);
      if (this.method271) {
         var3 = var3 * this.aq / this.method271();
         var4 = var4 * this.method5353 / this.method626();
         var1 += this.method1527 * var3 / this.aq;
         var2 += this.method5315 * var4 / this.method5353;
      }

      float var10 = (float)this.method545.I((short)3413).method545();
      float var11 = (float)this.method545.I((short)-15345).method552();
      var9.D.I((float)var3 * 2.0F / var10, (float)var4 * 2.0F / var11, 1.0F, 1.0F);
      var9.D.I[12] = ((float)var1 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
      var9.D.I[13] = ((float)var2 + this.method545.method5315()) * 2.0F / var11 - 1.0F;
      var9.D.I[14] = -1.0F;
      var9.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
      var9.C = this.method545.I;
      var9.S = 0;
      var9.A = this.method545.vI;
      var9.method1527();
   }

   public void method665(int var1, int var2, int var3, int var4, int var5, int var6) {
      int[] var7 = this.method545.aq(var5, var6, var3, var4);
      if (var7 != null) {
         for(int var8 = 0; var8 < var7.length; ++var8) {
            var7[var8] |= -16777216;
         }

         this.aq(var1, var2, var3, var4, var7, 0, var3);
      }

   }

   public void method624(int var1, int var2, int var3, int var4, int var5, int var6) {
      int[] var7 = this.method545.aq(var5, var6, var3, var4);
      if (var7 != null) {
         for(int var8 = 0; var8 < var7.length; ++var8) {
            var7[var8] |= -16777216;
         }

         this.aq(var1, var2, var3, var4, var7, 0, var3);
      }

   }

   public TAI method646() {
      return this.method1526;
   }

   public void method656(int[] var1) {
      var1[0] = this.method1527;
      var1[1] = this.method5315;
      var1[2] = this.method5356;
      var1[3] = this.method5355;
   }

   public void method677(int[] var1) {
      var1[0] = this.method1527;
      var1[1] = this.method5315;
      var1[2] = this.method5356;
      var1[3] = this.method5355;
   }

   FBI(NJI var1, CEI var2) {
      this(var1, var2, var2.method92(), var2.method76());
   }

   public int method630() {
      return this.aq;
   }

   public int method658() {
      return this.aq;
   }

   FBI(NJI var1, int var2, int var3, boolean var4, boolean var5) {
      this.method271 = false;
      this.method5315 = 0;
      this.method1527 = 0;
      this.method5355 = 0;
      this.method5356 = 0;
      this.method545 = var1;
      this.aq = var2;
      this.method5353 = var3;
      if (var5) {
         BEI var6 = var1.method5356(var4 ? YCI.Z : YCI.D, SDI.C, var2, var3);
         this.method1526 = var6.method117(0);
         this.method117 = var6;
      } else {
         this.method117 = var1.method5353(var4 ? YCI.Z : YCI.D, SDI.C, var2, var3);
         this.method1526 = null;
      }

      this.method117.method80(true, true);
      this.method76 = this.method117.method92() != var2;
      this.method552 = this.method117.method76() != var3;
      this.method626 = !this.method76 && this.method117.method79();
      this.method1528 = !this.method552 && this.method117.method79();
      this.method545.I(12);
   }

   public void method662(int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      this.method545.K();
      this.method545.D(var7);
      AZ var8 = this.method545.e;
      var8.Z = this.method117;
      var8.method1526(var5, var6);
      float var9 = (float)this.method545.I((short)4017).method545();
      float var10 = (float)this.method545.I((short)-4315).method552();
      var8.C = this.method545.I;
      var8.S = 0;
      var8.A = this.method545.vI;
      boolean var11 = this.method1528 && this.method5315 == 0 && this.method5355 == 0;
      boolean var12 = this.method626 && this.method1527 == 0 && this.method5356 == 0;
      if (var12 & var11) {
         var8.D.I((float)var3 * 2.0F / var9, (float)var4 * 2.0F / var10, 1.0F, 1.0F);
         var8.D.I[12] = ((float)var1 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
         var8.D.I[13] = ((float)var2 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
         var8.D.I[14] = -1.0F;
         var8.F.I(this.method117.method77((float)var3), this.method117.method78((float)var4), 1.0F, 1.0F);
         var8.method1527();
      } else {
         int var13;
         int var14;
         int var15;
         int var16;
         if (var12) {
            var13 = var2 + var4;
            var14 = this.method626();
            var8.F.I(this.method117.method77((float)var3), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
            var15 = var2 + this.method5315;

            for(var16 = var15 + this.method5353; var16 <= var13; var16 += var14) {
               var8.D.I((float)var3 * 2.0F / var9, (float)this.method5353 * 2.0F / var10, 1.0F, 1.0F);
               var8.D.I[12] = ((float)var1 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
               var8.D.I[13] = ((float)var15 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
               var8.D.I[14] = -1.0F;
               var8.method1527();
               var15 += var14;
            }

            if (var15 < var13) {
               var16 = var13 - var15;
               var8.F.I(this.method117.method77((float)var3), this.method117.method78((float)var16), 1.0F, 1.0F);
               var8.D.I((float)var3 * 2.0F / var9, (float)var16 * 2.0F / var10, 1.0F, 1.0F);
               var8.D.I[12] = ((float)var1 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
               var8.D.I[13] = ((float)var15 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
               var8.D.I[14] = -1.0F;
               var8.method1527();
            }
         } else if (var11) {
            var13 = var1 + var3;
            var14 = this.method271();
            var8.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)var4), 1.0F, 1.0F);
            var15 = var1 + this.method1527;

            for(var16 = var15 + this.aq; var16 <= var13; var16 += var14) {
               var8.D.I((float)this.aq * 2.0F / var9, (float)var4 * 2.0F / var10, 1.0F, 1.0F);
               var8.D.I[12] = ((float)var15 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
               var8.D.I[13] = ((float)var2 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
               var8.D.I[14] = -1.0F;
               var8.method1527();
               var15 += var14;
            }

            if (var15 < var13) {
               var16 = var13 - var15;
               var8.F.I(this.method117.method77((float)var16), this.method117.method78((float)var4), 1.0F, 1.0F);
               var8.D.I((float)var16 * 2.0F / var9, (float)var4 * 2.0F / var10, 1.0F, 1.0F);
               var8.D.I[12] = ((float)var15 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
               var8.D.I[13] = ((float)var2 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
               var8.D.I[14] = -1.0F;
               var8.method1527();
            }
         } else {
            var13 = var2 + var4;
            var14 = var1 + var3;
            var15 = this.method271();
            var16 = this.method626();
            int var17 = var2 + this.method5315;

            int var18;
            int var19;
            int var20;
            for(var18 = var17 + this.method5353; var18 <= var13; var18 += var16) {
               var8.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
               var19 = var1 + this.method1527;

               for(var20 = var19 + this.aq; var20 <= var14; var20 += var15) {
                  var8.D.I((float)this.aq * 2.0F / var9, (float)this.method5353 * 2.0F / var10, 1.0F, 1.0F);
                  var8.D.I[12] = ((float)var19 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
                  var8.D.I[13] = ((float)var17 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
                  var8.D.I[14] = -1.0F;
                  var8.method1527();
                  var19 += var15;
               }

               if (var19 < var14) {
                  var20 = var14 - var19;
                  var8.F.I(this.method117.method77((float)var20), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
                  var8.D.I((float)var20 * 2.0F / var9, (float)this.method5353 * 2.0F / var10, 1.0F, 1.0F);
                  var8.D.I[12] = ((float)var19 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
                  var8.D.I[13] = ((float)var17 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
                  var8.D.I[14] = -1.0F;
                  var8.method1527();
               }

               var17 += var16;
            }

            if (var17 < var13) {
               var18 = var13 - var17;
               var8.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)var18), 1.0F, 1.0F);
               var19 = var1 + this.method1527;

               for(var20 = var19 + this.aq; var20 <= var14; var20 += var15) {
                  var8.D.I((float)this.aq * 2.0F / var9, (float)var18 * 2.0F / var10, 1.0F, 1.0F);
                  var8.D.I[12] = ((float)var19 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
                  var8.D.I[13] = ((float)var17 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
                  var8.D.I[14] = -1.0F;
                  var8.method1527();
                  var19 += var15;
               }

               if (var19 < var14) {
                  var20 = var14 - var19;
                  var8.F.I(this.method117.method77((float)var20), this.method117.method78((float)var18), 1.0F, 1.0F);
                  var8.D.I((float)var20 * 2.0F / var9, (float)var18 * 2.0F / var10, 1.0F, 1.0F);
                  var8.D.I[12] = ((float)var19 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
                  var8.D.I[13] = ((float)var17 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
                  var8.D.I[14] = -1.0F;
                  var8.method1527();
               }
            }
         }
      }

   }

   public void method660(int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      this.method545.K();
      this.method545.D(var7);
      AZ var8 = this.method545.e;
      var8.Z = this.method117;
      var8.method1526(var5, var6);
      float var9 = (float)this.method545.I((short)9885).method545();
      float var10 = (float)this.method545.I((short)-16102).method552();
      var8.C = this.method545.I;
      var8.S = 0;
      var8.A = this.method545.vI;
      boolean var11 = this.method1528 && this.method5315 == 0 && this.method5355 == 0;
      boolean var12 = this.method626 && this.method1527 == 0 && this.method5356 == 0;
      if (var12 & var11) {
         var8.D.I((float)var3 * 2.0F / var9, (float)var4 * 2.0F / var10, 1.0F, 1.0F);
         var8.D.I[12] = ((float)var1 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
         var8.D.I[13] = ((float)var2 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
         var8.D.I[14] = -1.0F;
         var8.F.I(this.method117.method77((float)var3), this.method117.method78((float)var4), 1.0F, 1.0F);
         var8.method1527();
      } else {
         int var13;
         int var14;
         int var15;
         int var16;
         if (var12) {
            var13 = var2 + var4;
            var14 = this.method626();
            var8.F.I(this.method117.method77((float)var3), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
            var15 = var2 + this.method5315;

            for(var16 = var15 + this.method5353; var16 <= var13; var16 += var14) {
               var8.D.I((float)var3 * 2.0F / var9, (float)this.method5353 * 2.0F / var10, 1.0F, 1.0F);
               var8.D.I[12] = ((float)var1 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
               var8.D.I[13] = ((float)var15 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
               var8.D.I[14] = -1.0F;
               var8.method1527();
               var15 += var14;
            }

            if (var15 < var13) {
               var16 = var13 - var15;
               var8.F.I(this.method117.method77((float)var3), this.method117.method78((float)var16), 1.0F, 1.0F);
               var8.D.I((float)var3 * 2.0F / var9, (float)var16 * 2.0F / var10, 1.0F, 1.0F);
               var8.D.I[12] = ((float)var1 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
               var8.D.I[13] = ((float)var15 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
               var8.D.I[14] = -1.0F;
               var8.method1527();
            }
         } else if (var11) {
            var13 = var1 + var3;
            var14 = this.method271();
            var8.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)var4), 1.0F, 1.0F);
            var15 = var1 + this.method1527;

            for(var16 = var15 + this.aq; var16 <= var13; var16 += var14) {
               var8.D.I((float)this.aq * 2.0F / var9, (float)var4 * 2.0F / var10, 1.0F, 1.0F);
               var8.D.I[12] = ((float)var15 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
               var8.D.I[13] = ((float)var2 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
               var8.D.I[14] = -1.0F;
               var8.method1527();
               var15 += var14;
            }

            if (var15 < var13) {
               var16 = var13 - var15;
               var8.F.I(this.method117.method77((float)var16), this.method117.method78((float)var4), 1.0F, 1.0F);
               var8.D.I((float)var16 * 2.0F / var9, (float)var4 * 2.0F / var10, 1.0F, 1.0F);
               var8.D.I[12] = ((float)var15 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
               var8.D.I[13] = ((float)var2 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
               var8.D.I[14] = -1.0F;
               var8.method1527();
            }
         } else {
            var13 = var2 + var4;
            var14 = var1 + var3;
            var15 = this.method271();
            var16 = this.method626();
            int var17 = var2 + this.method5315;

            int var18;
            int var19;
            int var20;
            for(var18 = var17 + this.method5353; var18 <= var13; var18 += var16) {
               var8.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
               var19 = var1 + this.method1527;

               for(var20 = var19 + this.aq; var20 <= var14; var20 += var15) {
                  var8.D.I((float)this.aq * 2.0F / var9, (float)this.method5353 * 2.0F / var10, 1.0F, 1.0F);
                  var8.D.I[12] = ((float)var19 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
                  var8.D.I[13] = ((float)var17 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
                  var8.D.I[14] = -1.0F;
                  var8.method1527();
                  var19 += var15;
               }

               if (var19 < var14) {
                  var20 = var14 - var19;
                  var8.F.I(this.method117.method77((float)var20), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
                  var8.D.I((float)var20 * 2.0F / var9, (float)this.method5353 * 2.0F / var10, 1.0F, 1.0F);
                  var8.D.I[12] = ((float)var19 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
                  var8.D.I[13] = ((float)var17 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
                  var8.D.I[14] = -1.0F;
                  var8.method1527();
               }

               var17 += var16;
            }

            if (var17 < var13) {
               var18 = var13 - var17;
               var8.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)var18), 1.0F, 1.0F);
               var19 = var1 + this.method1527;

               for(var20 = var19 + this.aq; var20 <= var14; var20 += var15) {
                  var8.D.I((float)this.aq * 2.0F / var9, (float)var18 * 2.0F / var10, 1.0F, 1.0F);
                  var8.D.I[12] = ((float)var19 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
                  var8.D.I[13] = ((float)var17 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
                  var8.D.I[14] = -1.0F;
                  var8.method1527();
                  var19 += var15;
               }

               if (var19 < var14) {
                  var20 = var14 - var19;
                  var8.F.I(this.method117.method77((float)var20), this.method117.method78((float)var18), 1.0F, 1.0F);
                  var8.D.I((float)var20 * 2.0F / var9, (float)var18 * 2.0F / var10, 1.0F, 1.0F);
                  var8.D.I[12] = ((float)var19 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
                  var8.D.I[13] = ((float)var17 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
                  var8.D.I[14] = -1.0F;
                  var8.method1527();
               }
            }
         }
      }

   }

   public void method661(int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      this.method545.K();
      this.method545.D(var7);
      AZ var8 = this.method545.e;
      var8.Z = this.method117;
      var8.method1526(var5, var6);
      float var9 = (float)this.method545.I((short)-5713).method545();
      float var10 = (float)this.method545.I((short)14689).method552();
      var8.C = this.method545.I;
      var8.S = 0;
      var8.A = this.method545.vI;
      boolean var11 = this.method1528 && this.method5315 == 0 && this.method5355 == 0;
      boolean var12 = this.method626 && this.method1527 == 0 && this.method5356 == 0;
      if (var12 & var11) {
         var8.D.I((float)var3 * 2.0F / var9, (float)var4 * 2.0F / var10, 1.0F, 1.0F);
         var8.D.I[12] = ((float)var1 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
         var8.D.I[13] = ((float)var2 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
         var8.D.I[14] = -1.0F;
         var8.F.I(this.method117.method77((float)var3), this.method117.method78((float)var4), 1.0F, 1.0F);
         var8.method1527();
      } else {
         int var13;
         int var14;
         int var15;
         int var16;
         if (var12) {
            var13 = var2 + var4;
            var14 = this.method626();
            var8.F.I(this.method117.method77((float)var3), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
            var15 = var2 + this.method5315;

            for(var16 = var15 + this.method5353; var16 <= var13; var16 += var14) {
               var8.D.I((float)var3 * 2.0F / var9, (float)this.method5353 * 2.0F / var10, 1.0F, 1.0F);
               var8.D.I[12] = ((float)var1 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
               var8.D.I[13] = ((float)var15 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
               var8.D.I[14] = -1.0F;
               var8.method1527();
               var15 += var14;
            }

            if (var15 < var13) {
               var16 = var13 - var15;
               var8.F.I(this.method117.method77((float)var3), this.method117.method78((float)var16), 1.0F, 1.0F);
               var8.D.I((float)var3 * 2.0F / var9, (float)var16 * 2.0F / var10, 1.0F, 1.0F);
               var8.D.I[12] = ((float)var1 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
               var8.D.I[13] = ((float)var15 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
               var8.D.I[14] = -1.0F;
               var8.method1527();
            }
         } else if (var11) {
            var13 = var1 + var3;
            var14 = this.method271();
            var8.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)var4), 1.0F, 1.0F);
            var15 = var1 + this.method1527;

            for(var16 = var15 + this.aq; var16 <= var13; var16 += var14) {
               var8.D.I((float)this.aq * 2.0F / var9, (float)var4 * 2.0F / var10, 1.0F, 1.0F);
               var8.D.I[12] = ((float)var15 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
               var8.D.I[13] = ((float)var2 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
               var8.D.I[14] = -1.0F;
               var8.method1527();
               var15 += var14;
            }

            if (var15 < var13) {
               var16 = var13 - var15;
               var8.F.I(this.method117.method77((float)var16), this.method117.method78((float)var4), 1.0F, 1.0F);
               var8.D.I((float)var16 * 2.0F / var9, (float)var4 * 2.0F / var10, 1.0F, 1.0F);
               var8.D.I[12] = ((float)var15 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
               var8.D.I[13] = ((float)var2 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
               var8.D.I[14] = -1.0F;
               var8.method1527();
            }
         } else {
            var13 = var2 + var4;
            var14 = var1 + var3;
            var15 = this.method271();
            var16 = this.method626();
            int var17 = var2 + this.method5315;

            int var18;
            int var19;
            int var20;
            for(var18 = var17 + this.method5353; var18 <= var13; var18 += var16) {
               var8.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
               var19 = var1 + this.method1527;

               for(var20 = var19 + this.aq; var20 <= var14; var20 += var15) {
                  var8.D.I((float)this.aq * 2.0F / var9, (float)this.method5353 * 2.0F / var10, 1.0F, 1.0F);
                  var8.D.I[12] = ((float)var19 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
                  var8.D.I[13] = ((float)var17 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
                  var8.D.I[14] = -1.0F;
                  var8.method1527();
                  var19 += var15;
               }

               if (var19 < var14) {
                  var20 = var14 - var19;
                  var8.F.I(this.method117.method77((float)var20), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
                  var8.D.I((float)var20 * 2.0F / var9, (float)this.method5353 * 2.0F / var10, 1.0F, 1.0F);
                  var8.D.I[12] = ((float)var19 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
                  var8.D.I[13] = ((float)var17 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
                  var8.D.I[14] = -1.0F;
                  var8.method1527();
               }

               var17 += var16;
            }

            if (var17 < var13) {
               var18 = var13 - var17;
               var8.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)var18), 1.0F, 1.0F);
               var19 = var1 + this.method1527;

               for(var20 = var19 + this.aq; var20 <= var14; var20 += var15) {
                  var8.D.I((float)this.aq * 2.0F / var9, (float)var18 * 2.0F / var10, 1.0F, 1.0F);
                  var8.D.I[12] = ((float)var19 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
                  var8.D.I[13] = ((float)var17 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
                  var8.D.I[14] = -1.0F;
                  var8.method1527();
                  var19 += var15;
               }

               if (var19 < var14) {
                  var20 = var14 - var19;
                  var8.F.I(this.method117.method77((float)var20), this.method117.method78((float)var18), 1.0F, 1.0F);
                  var8.D.I((float)var20 * 2.0F / var9, (float)var18 * 2.0F / var10, 1.0F, 1.0F);
                  var8.D.I[12] = ((float)var19 + this.method545.method5315()) * 2.0F / var9 - 1.0F;
                  var8.D.I[13] = ((float)var17 + this.method545.method5315()) * 2.0F / var10 - 1.0F;
                  var8.D.I[14] = -1.0F;
                  var8.method1527();
               }
            }
         }
      }

   }

   void method629(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10) {
      this.method545.K();
      this.method545.D(var9);
      float var12;
      float var13;
      if (this.method271) {
         float var11 = (float)this.method271();
         var12 = (float)this.method626();
         var13 = (var3 - var1) / var11;
         float var14 = (var4 - var2) / var11;
         float var15 = (var5 - var1) / var12;
         float var16 = (var6 - var2) / var12;
         float var17 = var15 * (float)this.method5315;
         float var18 = var16 * (float)this.method5315;
         float var19 = var13 * (float)this.method1527;
         float var20 = var14 * (float)this.method1527;
         float var21 = -var13 * (float)this.method5356;
         float var22 = -var14 * (float)this.method5356;
         float var23 = -var15 * (float)this.method5355;
         float var24 = -var16 * (float)this.method5355;
         var1 = var1 + var19 + var17;
         var2 = var2 + var20 + var18;
         var3 = var3 + var21 + var17;
         var4 = var4 + var22 + var18;
         var5 = var5 + var19 + var23;
         var6 = var6 + var20 + var24;
      }

      AZ var25 = this.method545.e;
      var25.Z = this.method117;
      var25.method1526(var7, var8);
      var12 = (float)this.method545.I((short)1083).method545();
      var13 = (float)this.method545.I((short)-13740).method552();
      var25.D.J();
      var25.D.I[0] = (var3 - var1) * 2.0F / var12;
      var25.D.I[1] = (var4 - var2) * 2.0F / var13;
      var25.D.I[4] = (var5 - var1) * 2.0F / var12;
      var25.D.I[5] = (var6 - var2) * 2.0F / var13;
      var25.D.I[12] = (var1 + this.method545.method5315()) * 2.0F / var12 - 1.0F;
      var25.D.I[13] = (var2 + this.method545.method5315()) * 2.0F / var13 - 1.0F;
      var25.D.I[14] = -1.0F;
      var25.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
      var25.C = this.method545.I;
      var25.S = 0;
      var25.A = this.method545.vI;
      var25.method1527();
   }

   void method663(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10) {
      this.method545.K();
      this.method545.D(var9);
      float var12;
      float var13;
      if (this.method271) {
         float var11 = (float)this.method271();
         var12 = (float)this.method626();
         var13 = (var3 - var1) / var11;
         float var14 = (var4 - var2) / var11;
         float var15 = (var5 - var1) / var12;
         float var16 = (var6 - var2) / var12;
         float var17 = var15 * (float)this.method5315;
         float var18 = var16 * (float)this.method5315;
         float var19 = var13 * (float)this.method1527;
         float var20 = var14 * (float)this.method1527;
         float var21 = -var13 * (float)this.method5356;
         float var22 = -var14 * (float)this.method5356;
         float var23 = -var15 * (float)this.method5355;
         float var24 = -var16 * (float)this.method5355;
         var1 = var1 + var19 + var17;
         var2 = var2 + var20 + var18;
         var3 = var3 + var21 + var17;
         var4 = var4 + var22 + var18;
         var5 = var5 + var19 + var23;
         var6 = var6 + var20 + var24;
      }

      AZ var25 = this.method545.e;
      var25.Z = this.method117;
      var25.method1526(var7, var8);
      var12 = (float)this.method545.I((short)16767).method545();
      var13 = (float)this.method545.I((short)18071).method552();
      var25.D.J();
      var25.D.I[0] = (var3 - var1) * 2.0F / var12;
      var25.D.I[1] = (var4 - var2) * 2.0F / var13;
      var25.D.I[4] = (var5 - var1) * 2.0F / var12;
      var25.D.I[5] = (var6 - var2) * 2.0F / var13;
      var25.D.I[12] = (var1 + this.method545.method5315()) * 2.0F / var12 - 1.0F;
      var25.D.I[13] = (var2 + this.method545.method5315()) * 2.0F / var13 - 1.0F;
      var25.D.I[14] = -1.0F;
      var25.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
      var25.C = this.method545.I;
      var25.S = 0;
      var25.A = this.method545.vI;
      var25.method1527();
   }

   void aq(int var1, int var2, int var3, int var4, int[] var5, int var6, int var7) {
      this.method117.method81(var1, var2, var3, var4, var5, var6, var7);
   }

   void method664(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10) {
      this.method545.K();
      this.method545.D(var9);
      float var12;
      float var13;
      if (this.method271) {
         float var11 = (float)this.method271();
         var12 = (float)this.method626();
         var13 = (var3 - var1) / var11;
         float var14 = (var4 - var2) / var11;
         float var15 = (var5 - var1) / var12;
         float var16 = (var6 - var2) / var12;
         float var17 = var15 * (float)this.method5315;
         float var18 = var16 * (float)this.method5315;
         float var19 = var13 * (float)this.method1527;
         float var20 = var14 * (float)this.method1527;
         float var21 = -var13 * (float)this.method5356;
         float var22 = -var14 * (float)this.method5356;
         float var23 = -var15 * (float)this.method5355;
         float var24 = -var16 * (float)this.method5355;
         var1 = var1 + var19 + var17;
         var2 = var2 + var20 + var18;
         var3 = var3 + var21 + var17;
         var4 = var4 + var22 + var18;
         var5 = var5 + var19 + var23;
         var6 = var6 + var20 + var24;
      }

      AZ var25 = this.method545.e;
      var25.Z = this.method117;
      var25.method1526(var7, var8);
      var12 = (float)this.method545.I((short)-2943).method545();
      var13 = (float)this.method545.I((short)-353).method552();
      var25.D.J();
      var25.D.I[0] = (var3 - var1) * 2.0F / var12;
      var25.D.I[1] = (var4 - var2) * 2.0F / var13;
      var25.D.I[4] = (var5 - var1) * 2.0F / var12;
      var25.D.I[5] = (var6 - var2) * 2.0F / var13;
      var25.D.I[12] = (var1 + this.method545.method5315()) * 2.0F / var12 - 1.0F;
      var25.D.I[13] = (var2 + this.method545.method5315()) * 2.0F / var13 - 1.0F;
      var25.D.I[14] = -1.0F;
      var25.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
      var25.C = this.method545.I;
      var25.S = 0;
      var25.A = this.method545.vI;
      var25.method1527();
   }

   public void method654(int var1, int var2, QJI var3, int var4, int var5) {
      this.method545.K();
      AZ var6 = this.method545.e;
      var6.Z = this.method117;
      var6.method1526(1, -1);
      var1 += this.method1527;
      var2 += this.method5315;
      float var7 = (float)this.method545.I((short)-10311).method545();
      float var8 = (float)this.method545.I((short)-2951).method552();
      var6.D.I((float)this.aq * 2.0F / var7, (float)this.method5353 * 2.0F / var8, 1.0F, 1.0F);
      var6.D.I[12] = ((float)var1 + this.method545.method5315()) * 2.0F / var7 - 1.0F;
      var6.D.I[13] = ((float)var2 + this.method545.method5315()) * 2.0F / var8 - 1.0F;
      var6.D.I[14] = -1.0F;
      var6.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
      var6.C = this.method545.I;
      var6.S = 0;
      var6.A = this.method545.vI;
      CEI var9 = ((UJI)var3).I;
      var6.I = var9;
      var6.J.I(var9.method77((float)this.aq), var9.method78((float)this.method5353), 1.0F, 1.0F);
      var6.J.I[12] = var9.method77((float)(var1 - var4));
      var6.J.I[13] = var9.method78((float)(var2 - var5));
      var6.method1528();
   }

   void method672(float var1, float var2, float var3, float var4, float var5, float var6, int var7, QJI var8, int var9, int var10) {
      this.method545.K();
      AZ var11 = this.method545.e;
      var11.Z = this.method117;
      var11.method1526(1, -1);
      float var12 = (float)this.method545.I((short)-1649).method545();
      float var13 = (float)this.method545.I((short)20235).method552();
      var11.D.J();
      if (this.method271) {
         float var14 = (float)this.aq / (float)this.method271();
         float var15 = (float)this.method5353 / (float)this.method626();
         var11.D.I[0] = (var3 - var1) * var14;
         var11.D.I[1] = (var4 - var2) * var14;
         var11.D.I[4] = (var5 - var1) * var15;
         var11.D.I[5] = (var6 - var2) * var15;
         var11.D.I[12] = (var1 + (float)this.method1527) * var14 + this.method545.method5315();
         var11.D.I[13] = (var2 + (float)this.method5315) * var15 + this.method545.method5315();
      } else {
         var11.D.I[0] = var3 - var1;
         var11.D.I[1] = var4 - var2;
         var11.D.I[4] = var5 - var1;
         var11.D.I[5] = var6 - var2;
         var11.D.I[12] = var1 + this.method545.method5315();
         var11.D.I[13] = var2 + this.method545.method5315();
      }

      YF var16 = this.method545.Q;
      var16.J();
      var16.I[0] = 2.0F / var12;
      var16.I[5] = 2.0F / var13;
      var16.I[12] = -1.0F;
      var16.I[13] = -1.0F;
      var16.I[14] = -1.0F;
      var11.D.Z(var16);
      var11.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
      var11.C = this.method545.I;
      var11.S = 0;
      var11.A = this.method545.vI;
      CEI var17 = ((UJI)var8).I;
      var11.I = var17;
      var11.J.J();
      var11.J.I[0] = (var3 - var1) * var17.method77(1.0F);
      var11.J.I[1] = (var4 - var2) * var17.method77(1.0F);
      var11.J.I[4] = (var5 - var1) * var17.method78(1.0F);
      var11.J.I[5] = (var6 - var2) * var17.method78(1.0F);
      var11.J.I[12] = (var1 - (float)var9) * var17.method77(1.0F);
      var11.J.I[13] = (var2 - (float)var10) * var17.method78(1.0F);
      var11.method1528();
   }

   public int method667() {
      return this.method5353;
   }

   public int method668() {
      return this.method5353;
   }

   public int method669() {
      return this.method5353;
   }

   void method670(float var1, float var2, float var3, float var4, float var5, float var6, int var7, QJI var8, int var9, int var10) {
      this.method545.K();
      AZ var11 = this.method545.e;
      var11.Z = this.method117;
      var11.method1526(1, -1);
      float var12 = (float)this.method545.I((short)-20975).method545();
      float var13 = (float)this.method545.I((short)22361).method552();
      var11.D.J();
      if (this.method271) {
         float var14 = (float)this.aq / (float)this.method271();
         float var15 = (float)this.method5353 / (float)this.method626();
         var11.D.I[0] = (var3 - var1) * var14;
         var11.D.I[1] = (var4 - var2) * var14;
         var11.D.I[4] = (var5 - var1) * var15;
         var11.D.I[5] = (var6 - var2) * var15;
         var11.D.I[12] = (var1 + (float)this.method1527) * var14 + this.method545.method5315();
         var11.D.I[13] = (var2 + (float)this.method5315) * var15 + this.method545.method5315();
      } else {
         var11.D.I[0] = var3 - var1;
         var11.D.I[1] = var4 - var2;
         var11.D.I[4] = var5 - var1;
         var11.D.I[5] = var6 - var2;
         var11.D.I[12] = var1 + this.method545.method5315();
         var11.D.I[13] = var2 + this.method545.method5315();
      }

      YF var16 = this.method545.Q;
      var16.J();
      var16.I[0] = 2.0F / var12;
      var16.I[5] = 2.0F / var13;
      var16.I[12] = -1.0F;
      var16.I[13] = -1.0F;
      var16.I[14] = -1.0F;
      var11.D.Z(var16);
      var11.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
      var11.C = this.method545.I;
      var11.S = 0;
      var11.A = this.method545.vI;
      CEI var17 = ((UJI)var8).I;
      var11.I = var17;
      var11.J.J();
      var11.J.I[0] = (var3 - var1) * var17.method77(1.0F);
      var11.J.I[1] = (var4 - var2) * var17.method77(1.0F);
      var11.J.I[4] = (var5 - var1) * var17.method78(1.0F);
      var11.J.I[5] = (var6 - var2) * var17.method78(1.0F);
      var11.J.I[12] = (var1 - (float)var9) * var17.method77(1.0F);
      var11.J.I[13] = (var2 - (float)var10) * var17.method78(1.0F);
      var11.method1528();
   }

   public void method640(int[] var1) {
      var1[0] = this.method1527;
      var1[1] = this.method5315;
      var1[2] = this.method5356;
      var1[3] = this.method5355;
   }

   void method657(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10) {
      this.method545.K();
      this.method545.D(var9);
      float var12;
      float var13;
      if (this.method271) {
         float var11 = (float)this.method271();
         var12 = (float)this.method626();
         var13 = (var3 - var1) / var11;
         float var14 = (var4 - var2) / var11;
         float var15 = (var5 - var1) / var12;
         float var16 = (var6 - var2) / var12;
         float var17 = var15 * (float)this.method5315;
         float var18 = var16 * (float)this.method5315;
         float var19 = var13 * (float)this.method1527;
         float var20 = var14 * (float)this.method1527;
         float var21 = -var13 * (float)this.method5356;
         float var22 = -var14 * (float)this.method5356;
         float var23 = -var15 * (float)this.method5355;
         float var24 = -var16 * (float)this.method5355;
         var1 = var1 + var19 + var17;
         var2 = var2 + var20 + var18;
         var3 = var3 + var21 + var17;
         var4 = var4 + var22 + var18;
         var5 = var5 + var19 + var23;
         var6 = var6 + var20 + var24;
      }

      AZ var25 = this.method545.e;
      var25.Z = this.method117;
      var25.method1526(var7, var8);
      var12 = (float)this.method545.I((short)-18902).method545();
      var13 = (float)this.method545.I((short)5348).method552();
      var25.D.J();
      var25.D.I[0] = (var3 - var1) * 2.0F / var12;
      var25.D.I[1] = (var4 - var2) * 2.0F / var13;
      var25.D.I[4] = (var5 - var1) * 2.0F / var12;
      var25.D.I[5] = (var6 - var2) * 2.0F / var13;
      var25.D.I[12] = (var1 + this.method545.method5315()) * 2.0F / var12 - 1.0F;
      var25.D.I[13] = (var2 + this.method545.method5315()) * 2.0F / var13 - 1.0F;
      var25.D.I[14] = -1.0F;
      var25.F.I(this.method117.method77((float)this.aq), this.method117.method78((float)this.method5353), 1.0F, 1.0F);
      var25.C = this.method545.I;
      var25.S = 0;
      var25.A = this.method545.vI;
      var25.method1527();
   }
}
