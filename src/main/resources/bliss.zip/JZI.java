public class JZI {
   JQ I = new JQ(64);
   KJ Z;
   public static KJ C;

   public JZI(ZV var1, XW var2, KJ var3) {
      this.Z = var3;
      this.Z.F(II.z.y * -1006924897, 236791533);
   }

   public void I(byte var1) {
      try {
         JQ var2 = this.I;
         synchronized(this.I) {
            this.I.I();
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "uq.f(" + ')');
      }
   }

   public void I(int var1) {
      try {
         JQ var2 = this.I;
         synchronized(this.I) {
            this.I.Z();
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "uq.p(" + ')');
      }
   }

   public IZI I(int var1, int var2) {
      try {
         JQ var4 = this.I;
         IZI var3;
         synchronized(this.I) {
            var3 = (IZI)this.I.I((long)var1);
         }

         if (var3 != null) {
            return var3;
         } else {
            KJ var5 = this.Z;
            byte[] var10;
            synchronized(this.Z) {
               var10 = this.Z.I(-1006924897 * II.z.y, var1, (byte)-70);
            }

            var3 = new IZI();
            if (var10 != null) {
               var3.I(new REI(var10), -420636240);
            }

            JQ var11 = this.I;
            synchronized(this.I) {
               this.I.I(var3, (long)var1);
            }

            return var3;
         }
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "uq.a(" + ')');
      }
   }

   public void Z(int var1, int var2) {
      try {
         JQ var3 = this.I;
         synchronized(this.I) {
            this.I.I(var1, -862651401);
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "uq.b(" + ')');
      }
   }

   static ZV[] Z(byte var0) {
      try {
         return new ZV[]{ZV.C, ZV.D, ZV.I, ZV.B, ZV.F};
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "uq.a(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         TO.Z((byte)11);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "uq.wg(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, byte var3) {
      try {
         String var4 = (String)var2.S[(var2.A -= 969361751) * -203050393];
         if (IN.I(var4, var2, -1825255771) != null) {
            var4 = var4.substring(0, var4.length() - 1);
         }

         var0.jZ = OI.I(var4, var2, -2046058202);
         var0.JZ = true;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "uq.lu(" + ')');
      }
   }
}
