import jaggl.OpenGL;

public class HII {
   int I;
   static int glCompileShader = 35632;
   static int glCreateShader = 35633;
   MJI glDeleteShader;
   static int[] glGetShaderInfoLog = new int[2];

   HII(MJI var1, int var2, int var3) {
      this.glDeleteShader = var1;
      this.I = var2;
   }

   static HII I(MJI var0, int var1, String var2) {
      int var3 = OpenGL.glCreateShader(var1);
      OpenGL.glShaderSource(var3, var2);
      OpenGL.glCompileShader(var3);
      OpenGL.glGetShaderiv(var3, 35713, glGetShaderInfoLog, 0);
      if (glGetShaderInfoLog[0] == 0) {
         if (glGetShaderInfoLog[0] == 0) {
            OpenGL.glGetShaderiv(var3, 35716, glGetShaderInfoLog, 1);
         }

         if (glGetShaderInfoLog[1] > 1) {
            byte[] var4 = new byte[glGetShaderInfoLog[1]];
            OpenGL.glGetShaderInfoLog(var3, glGetShaderInfoLog[1], glGetShaderInfoLog, 0, var4, 0);
         }

         if (glGetShaderInfoLog[0] == 0) {
            OpenGL.glDeleteShader(var3);
            return null;
         }
      }

      return new HII(var0, var3, var1);
   }
}
