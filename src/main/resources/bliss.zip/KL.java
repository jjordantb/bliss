public class KL extends QK {
   public char[] G;
   public String H;
   public char[] K;
   public int[] L;
   public int[] M;

   void Z(REI var1, int var2) {
      try {
         while(true) {
            int var3 = var1.I();
            if (var3 == 0) {
               if (var2 == -1650604707) {
                  throw new IllegalStateException();
               }

               return;
            }

            this.toString(var1, var3, -2004307261);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ain.a(" + ')');
      }
   }

   public int I(char var1, int var2) {
      try {
         if (this.M == null) {
            return -1;
         } else {
            for(int var3 = 0; var3 < this.M.length; ++var3) {
               if (this.G[var3] == var1) {
                  return this.M[var3];
               }
            }

            return -1;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ain.b(" + ')');
      }
   }

   void B(int var1) {
      try {
         int var2;
         if (this.L != null) {
            for(var2 = 0; var2 < this.L.length; ++var2) {
               this.L[var2] |= 32768;
            }
         }

         if (this.M != null) {
            for(var2 = 0; var2 < this.M.length; ++var2) {
               this.M[var2] |= 32768;
            }
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ain.i(" + ')');
      }
   }

   public int append(char var1, int var2) {
      try {
         if (this.L == null) {
            return -1;
         } else {
            for(int var3 = 0; var3 < this.L.length; ++var3) {
               if (var1 == this.K[var3]) {
                  return this.L[var3];
               }
            }

            return -1;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ain.p(" + ')');
      }
   }

   void toString(REI var1, int var2, int var3) {
      try {
         if (1 == var2) {
            this.H = var1.E(-1462506580);
         } else {
            int var4;
            int var5;
            byte var6;
            if (2 == var2) {
               var4 = var1.I();
               this.M = new int[var4];
               this.G = new char[var4];

               for(var5 = 0; var5 < var4; ++var5) {
                  this.M[var5] = var1.C();
                  var6 = var1.S(-12558881);
                  this.G[var5] = var6 == 0 ? 0 : IZI.I(var6, 1882768383);
               }
            } else if (var2 == 3) {
               var4 = var1.I();
               this.L = new int[var4];
               this.K = new char[var4];

               for(var5 = 0; var5 < var4; ++var5) {
                  this.L[var5] = var1.C();
                  var6 = var1.S(-12558881);
                  this.K[var5] = var6 == 0 ? 0 : IZI.I(var6, 2133004777);
               }
            } else if (var2 == 4) {
               ;
            }
         }

      } catch (RuntimeException var7) {
         throw DQ.I(var7, "ain.f(" + ')');
      }
   }

   static final void C(OU var0, byte var1) {
      try {
         var0.J -= -783761378;
         int var2 = var0.H[var0.J * 681479919];
         int var3 = var0.H[var0.J * 681479919 + 1];
         if (var3 == -1) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = -1;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = GSI.OZ.I(var2, -1823486068).append((char)var3, -446763636);
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ain.adt(" + ')');
      }
   }
}
