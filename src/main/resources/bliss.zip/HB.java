import java.io.File;

public class HB implements CAI {
   static File I;

   public String method241(RR var1, int[] var2, long var3) {
      try {
         if (var1 == RR.F) {
            DSI var7 = QZI.C.I(var2[0], 1528209569);
            return var7.I((int)var3, (byte)-8);
         } else if (var1 != RR.P && RR.N != var1) {
            return var1 != RR.I && RR.Z != var1 && var1 != RR.E ? null : QZI.C.I(var2[0], 1528209569).I((int)var3, (byte)-101);
         } else {
            SEI var5 = JH.R.I((int)var3);
            return var5.A;
         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "hn.a(" + ')');
      }
   }

   public String method240(RR var1, int[] var2, long var3) {
      if (var1 == RR.F) {
         DSI var6 = QZI.C.I(var2[0], 1528209569);
         return var6.I((int)var3, (byte)-13);
      } else if (var1 != RR.P && RR.N != var1) {
         return var1 != RR.I && RR.Z != var1 && var1 != RR.E ? null : QZI.C.I(var2[0], 1528209569).I((int)var3, (byte)79);
      } else {
         SEI var5 = JH.R.I((int)var3);
         return var5.A;
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = XEI.f ? 1 : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "hn.akv(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = UC.Z.method3894((byte)69);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "hn.un(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = HQ.I(CI.I((byte)1));
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "hn.akx(" + ')');
      }
   }
}
