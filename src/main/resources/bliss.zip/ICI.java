import java.awt.Point;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class ICI {
   KJ I;
   JQ J = new JQ(64);

   public ICI(ZV var1, XW var2, KJ var3) {
      this.I = var3;
      this.I.F(-1006924897 * II.Q.y, 689615038);
   }

   public TK I(int var1, int var2) {
      try {
         JQ var4 = this.J;
         TK var3;
         synchronized(this.J) {
            var3 = (TK)this.J.I((long)var1);
         }

         if (var3 != null) {
            return var3;
         } else {
            KJ var5 = this.I;
            byte[] var10;
            synchronized(this.I) {
               var10 = this.I.I(-1006924897 * II.Q.y, var1, (byte)-26);
            }

            var3 = new TK();
            if (var10 != null) {
               var3.I(new REI(var10), (byte)-66);
            }

            JQ var11 = this.J;
            synchronized(this.J) {
               this.J.I(var3, (long)var1);
            }

            return var3;
         }
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "vu.a(" + ')');
      }
   }

   static void I(int var0) {
      try {
         Class var1 = ClassLoader.class;
         Field var2 = var1.getDeclaredField("nativeLibraries");
         Class var3 = AccessibleObject.class;
         Method var4 = var3.getDeclaredMethod("setAccessible", Boolean.TYPE);
         var4.invoke(var2, Boolean.TRUE);
      } catch (Throwable var5) {
         ;
      }

   }

   public static void I(int var0, byte var1) {
      try {
         QR.J = -1599730439 * var0;
         JQ var2 = QR.F;
         synchronized(QR.F) {
            QR.F.I();
         }

         var2 = QR.D;
         synchronized(QR.D) {
            QR.D.I();
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "vu.q(" + ')');
      }
   }

   public static boolean Z(int var0, int var1) {
      try {
         for(YK var2 = (YK)FX.K.Z(1766612795); var2 != null; var2 = (YK)FX.K.B(49146)) {
            if (HN.I(var2.N * 946432351, -77764350) && (long)var0 == var2.M * 2236412381003659263L) {
               return true;
            }
         }

         return false;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "vu.j(" + ')');
      }
   }

   static void C(int var0, int var1) {
      try {
         if (FW.J.a.I(1899706472) == 0) {
            var0 = -1;
         }

         if (XEI.qC * 1396956439 != var0) {
            if (-1 != var0) {
               YII var2 = GJI.G.I(var0, 16711935);
               RFI var3 = var2.I(1479362312);
               if (var3 != null) {
                  FFI.C.I(PCI.A, var3.D(), var3.Z(), var3.J(), new Point(var2.C * -1954213555, -326899251 * var2.I));
                  XEI.qC = -766301529 * var0;
               } else {
                  var0 = -1;
               }
            }

            if (var0 == -1 && XEI.qC * 1396956439 != -1) {
               FFI.C.I(PCI.A, (int[])null, -1, -1, new Point());
               XEI.qC = 766301529;
            }
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "vu.gv(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, int var3) {
      try {
         var0.RZ = var2.H[(var2.J -= -391880689) * 681479919] * -1448553585;
         VEI.I(var0, -1832191963);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "vu.fn(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         if (!FT.P.method5050()) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 3;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.H.method5612(var2, 1352882135);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "vu.aof(" + ')');
      }
   }
}
