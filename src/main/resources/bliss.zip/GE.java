public class GE extends AE {
   static int[] J;
   int append;
   public SF S = new SF();
   float toString;
   int A;

   public final int C(int var1) {
      try {
         return (int)this.S.C;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aao.f(" + ')');
      }
   }

   public final int B(int var1) {
      try {
         return (int)this.S.I;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aao.a(" + ')');
      }
   }

   public void I(float var1, byte var2) {
      try {
         this.toString = var1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aao.d(" + ')');
      }
   }

   public final int I(byte var1) {
      try {
         return (int)this.S.Z;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aao.b(" + ')');
      }
   }

   public final int D(int var1) {
      try {
         return this.A * 2038595173;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aao.i(" + ')');
      }
   }

   GE(int var1, int var2, int var3, int var4, int var5, float var6) {
      this.S.Z((float)var1, (float)var2, (float)var3);
      this.append = 465610783 * var4;
      this.A = var5 * -430898323;
      this.toString = var6;
   }

   public void I(int var1, int var2, int var3, byte var4) {
      try {
         this.S.Z((float)var1, (float)var2, (float)var3);
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "aao.u(" + ')');
      }
   }

   public final int F(int var1) {
      try {
         return this.append * 333763551;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aao.p(" + ')');
      }
   }

   public final float J(int var1) {
      try {
         return this.toString;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aao.k(" + ')');
      }
   }
}
