import jagtheora.ogg.OggPacket;
import jagtheora.ogg.OggStreamState;
import jagtheora.theora.DecoderContext;
import jagtheora.theora.Frame;
import jagtheora.theora.GranulePos;
import jagtheora.theora.SetupInfo;
import jagtheora.theora.TheoraComment;
import jagtheora.theora.TheoraInfo;

public class HG extends AG {
   boolean a;
   TheoraInfo append = new TheoraInfo();
   SetupInfo decodeFrame = new SetupInfo();
   static int decodeHeader = 2048;
   static int decodePacketIn = 1024;
   DecoderContext f;
   double fpsDenominator;
   Frame fpsNumerator;
   int frameHeight;
   long frameWidth;
   boolean getMaxPostProcessingLevel;
   GranulePos granuleFrame;
   int granuleTime;
   TheoraComment isKeyFrame = new TheoraComment();
   boolean method214;
   Object pixels;
   boolean setPostProcessingLevel;

   HG(OggStreamState var1) {
      super(var1);
   }

   float C(int var1) {
      try {
         return this.getMaxPostProcessingLevel && !this.append.a() ? (float)this.append.fpsNumerator / (float)this.append.fpsDenominator : 0.0F;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ajq.n(" + ')');
      }
   }

   double B(int var1) {
      try {
         return this.fpsDenominator;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ajq.s(" + ')');
      }
   }

   long I(byte var1) {
      try {
         return this.frameWidth * 7179368485346321301L;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ajq.z(" + ')');
      }
   }

   boolean D(int var1) {
      try {
         return this.getMaxPostProcessingLevel;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ajq.y(" + ')');
      }
   }

   void method3075(int var1) {
      try {
         if (this.fpsNumerator != null) {
            this.fpsNumerator.f();
         }

         if (this.f != null) {
            this.f.f();
            this.f = null;
         }

         if (this.granuleFrame != null) {
            this.granuleFrame.f();
            this.granuleFrame = null;
         }

         this.append.f();
         this.isKeyFrame.f();
         this.decodeFrame.f();
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ajq.b(" + ')');
      }
   }

   public Object I(VSI var1, int var2) {
      try {
         if (this.fpsNumerator == null) {
            return null;
         } else if (!this.setPostProcessingLevel && this.pixels != null) {
            return this.pixels;
         } else {
            this.pixels = var1.method214(this.fpsNumerator.pixels, 0, 1264450863 * this.fpsNumerator.a, this.fpsNumerator.a * 1264450863, -1459424961 * this.fpsNumerator.f, false, 1108085908);
            this.setPostProcessingLevel = false;
            return this.pixels;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ajq.c(" + ')');
      }
   }

   void method3077(OggPacket var1) {
      int var2;
      if (!this.getMaxPostProcessingLevel) {
         var2 = this.decodeFrame.decodeHeader(this.append, this.isKeyFrame, var1);
         if (var2 == 0) {
            this.getMaxPostProcessingLevel = true;
            if (this.append.frameWidth > 2048 || this.append.frameHeight > 1024) {
               throw new IllegalStateException();
            }

            this.f = new DecoderContext(this.append, this.decodeFrame);
            this.granuleFrame = new GranulePos();
            this.fpsNumerator = new Frame(this.append.frameWidth, this.append.frameHeight);
            this.granuleTime = this.f.getMaxPostProcessingLevel() * 295322609;
            this.a(-2058603981 * this.frameHeight, (byte)77);
         } else if (var2 < 0) {
            throw new IllegalStateException("" + var2);
         }
      } else {
         this.frameWidth = CI.I((byte)1) * 4704549656485466045L;
         var2 = this.f.decodePacketIn(var1, this.granuleFrame);
         if (var2 < 0) {
            throw new IllegalStateException("" + var2);
         }

         this.f.granuleFrame(this.granuleFrame);
         this.fpsDenominator = this.f.granuleTime(this.granuleFrame);
         if (this.method214) {
            boolean var3 = var1.isKeyFrame() == 1;
            if (!var3) {
               return;
            }

            this.method214 = false;
         }

         if (!this.a || var1.isKeyFrame() == 1) {
            if (this.f.decodeFrame(this.fpsNumerator) != 0) {
               throw new IllegalStateException("" + var2);
            }

            this.setPostProcessingLevel = true;
         }
      }

   }

   void method3078(OggPacket var1) {
      int var2;
      if (!this.getMaxPostProcessingLevel) {
         var2 = this.decodeFrame.decodeHeader(this.append, this.isKeyFrame, var1);
         if (var2 == 0) {
            this.getMaxPostProcessingLevel = true;
            if (this.append.frameWidth > 2048 || this.append.frameHeight > 1024) {
               throw new IllegalStateException();
            }

            this.f = new DecoderContext(this.append, this.decodeFrame);
            this.granuleFrame = new GranulePos();
            this.fpsNumerator = new Frame(this.append.frameWidth, this.append.frameHeight);
            this.granuleTime = this.f.getMaxPostProcessingLevel() * 295322609;
            this.a(-2058603981 * this.frameHeight, (byte)12);
         } else if (var2 < 0) {
            throw new IllegalStateException("" + var2);
         }
      } else {
         this.frameWidth = CI.I((byte)1) * 4704549656485466045L;
         var2 = this.f.decodePacketIn(var1, this.granuleFrame);
         if (var2 < 0) {
            throw new IllegalStateException("" + var2);
         }

         this.f.granuleFrame(this.granuleFrame);
         this.fpsDenominator = this.f.granuleTime(this.granuleFrame);
         if (this.method214) {
            boolean var3 = var1.isKeyFrame() == 1;
            if (!var3) {
               return;
            }

            this.method214 = false;
         }

         if (!this.a || var1.isKeyFrame() == 1) {
            if (this.f.decodeFrame(this.fpsNumerator) != 0) {
               throw new IllegalStateException("" + var2);
            }

            this.setPostProcessingLevel = true;
         }
      }

   }

   void method3072() {
      if (this.fpsNumerator != null) {
         this.fpsNumerator.f();
      }

      if (this.f != null) {
         this.f.f();
         this.f = null;
      }

      if (this.granuleFrame != null) {
         this.granuleFrame.f();
         this.granuleFrame = null;
      }

      this.append.f();
      this.isKeyFrame.f();
      this.decodeFrame.f();
   }

   void method3074(OggPacket var1, int var2) {
      try {
         int var3;
         if (!this.getMaxPostProcessingLevel) {
            var3 = this.decodeFrame.decodeHeader(this.append, this.isKeyFrame, var1);
            if (var3 == 0) {
               this.getMaxPostProcessingLevel = true;
               if (this.append.frameWidth > 2048 || this.append.frameHeight > 1024) {
                  throw new IllegalStateException();
               }

               this.f = new DecoderContext(this.append, this.decodeFrame);
               this.granuleFrame = new GranulePos();
               this.fpsNumerator = new Frame(this.append.frameWidth, this.append.frameHeight);
               this.granuleTime = this.f.getMaxPostProcessingLevel() * 295322609;
               this.a(-2058603981 * this.frameHeight, (byte)41);
            } else if (var3 < 0) {
               throw new IllegalStateException("" + var3);
            }
         } else {
            this.frameWidth = CI.I((byte)1) * 4704549656485466045L;
            var3 = this.f.decodePacketIn(var1, this.granuleFrame);
            if (var3 < 0) {
               throw new IllegalStateException("" + var3);
            }

            this.f.granuleFrame(this.granuleFrame);
            this.fpsDenominator = this.f.granuleTime(this.granuleFrame);
            if (this.method214) {
               boolean var4 = var1.isKeyFrame() == 1;
               if (!var4) {
                  return;
               }

               this.method214 = false;
            }

            if (!this.a || var1.isKeyFrame() == 1) {
               if (this.f.decodeFrame(this.fpsNumerator) != 0) {
                  throw new IllegalStateException("" + var3);
               }

               this.setPostProcessingLevel = true;
            }
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ajq.f(" + ')');
      }
   }

   void a(int var1, byte var2) {
      try {
         this.frameHeight = -703457029 * var1;
         if (this.getMaxPostProcessingLevel) {
            if (-2058603981 * this.frameHeight > -42840815 * this.granuleTime) {
               this.frameHeight = this.granuleTime * -679663701;
            }

            if (-2058603981 * this.frameHeight < 0) {
               this.frameHeight = 0;
            }

            this.f.setPostProcessingLevel(-2058603981 * this.frameHeight);
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ajq.q(" + ')');
      }
   }

   void method3079() {
      if (this.fpsNumerator != null) {
         this.fpsNumerator.f();
      }

      if (this.f != null) {
         this.f.f();
         this.f = null;
      }

      if (this.granuleFrame != null) {
         this.granuleFrame.f();
         this.granuleFrame = null;
      }

      this.append.f();
      this.isKeyFrame.f();
      this.decodeFrame.f();
   }

   void method3076(OggPacket var1) {
      int var2;
      if (!this.getMaxPostProcessingLevel) {
         var2 = this.decodeFrame.decodeHeader(this.append, this.isKeyFrame, var1);
         if (var2 == 0) {
            this.getMaxPostProcessingLevel = true;
            if (this.append.frameWidth > 2048 || this.append.frameHeight > 1024) {
               throw new IllegalStateException();
            }

            this.f = new DecoderContext(this.append, this.decodeFrame);
            this.granuleFrame = new GranulePos();
            this.fpsNumerator = new Frame(this.append.frameWidth, this.append.frameHeight);
            this.granuleTime = this.f.getMaxPostProcessingLevel() * 295322609;
            this.a(-2058603981 * this.frameHeight, (byte)95);
         } else if (var2 < 0) {
            throw new IllegalStateException("" + var2);
         }
      } else {
         this.frameWidth = CI.I((byte)1) * 4704549656485466045L;
         var2 = this.f.decodePacketIn(var1, this.granuleFrame);
         if (var2 < 0) {
            throw new IllegalStateException("" + var2);
         }

         this.f.granuleFrame(this.granuleFrame);
         this.fpsDenominator = this.f.granuleTime(this.granuleFrame);
         if (this.method214) {
            boolean var3 = var1.isKeyFrame() == 1;
            if (!var3) {
               return;
            }

            this.method214 = false;
         }

         if (!this.a || var1.isKeyFrame() == 1) {
            if (this.f.decodeFrame(this.fpsNumerator) != 0) {
               throw new IllegalStateException("" + var2);
            }

            this.setPostProcessingLevel = true;
         }
      }

   }

   public static boolean Z(int var0, int var1) {
      try {
         if (PFI.K * 296787703 != var0 || W.C == null) {
            RF.I(224664390);
            W.C = QFI.C;
            PFI.K = -1692564793 * var0;
         }

         int var4;
         int var5;
         int var6;
         if (W.C == QFI.C) {
            byte[] var2 = HU.C.I(var0, (byte)45);
            if (var2 == null) {
               return false;
            }

            REI var3 = new REI(var2);
            UP.I(var3, -2093041337);
            var4 = var3.I();

            for(var5 = 0; var5 < var4; ++var5) {
               PFI.S.I((AE)(new ZN(var3)), (int)-51345743);
            }

            var5 = var3.B(1723054621);
            PFI.L = new FDI[var5];

            for(var6 = 0; var6 < var5; ++var6) {
               PFI.L[var6] = new FDI(var3);
            }

            var6 = var3.B(1723054621);
            PFI.C = new YFI[var6];

            int var7;
            for(var7 = 0; var7 < var6; ++var7) {
               PFI.C[var7] = new YFI(var3, var7);
            }

            var7 = var3.B(1723054621);
            PFI.J = new OFI[var7];

            int var8;
            for(var8 = 0; var8 < var7; ++var8) {
               PFI.J[var8] = new OFI(var3);
            }

            var8 = var3.B(1723054621);
            PFI.B = new HDI[var8];

            int var9;
            for(var9 = 0; var9 < var8; ++var9) {
               PFI.B[var9] = new HDI(var3);
            }

            var9 = var3.B(1723054621);
            PFI.F = new LDI[var9];

            for(int var10 = 0; var10 < var9; ++var10) {
               PFI.F[var10] = OC.I(var3, (byte)-73);
            }

            W.C = QFI.B;
         }

         if (W.C == QFI.B) {
            boolean var12 = true;
            YFI[] var13 = PFI.C;

            for(var4 = 0; var4 < var13.length; ++var4) {
               YFI var15 = var13[var4];
               if (!var15.Z(1510757465)) {
                  var12 = false;
               }
            }

            LDI[] var14 = PFI.F;

            for(var5 = 0; var5 < var14.length; ++var5) {
               LDI var17 = var14[var5];
               if (!var17.Z(856848171)) {
                  var12 = false;
               }
            }

            OFI[] var16 = PFI.J;

            for(var6 = 0; var6 < var16.length; ++var6) {
               OFI var18 = var16[var6];
               if (!var18.Z((byte)81)) {
                  var12 = false;
               }
            }

            if (!var12) {
               return false;
            }

            W.C = QFI.Z;
         }

         return true;
      } catch (RuntimeException var11) {
         throw DQ.I(var11, "ajq.a(" + ')');
      }
   }
}
