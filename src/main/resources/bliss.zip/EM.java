public final class EM extends AE implements WSI {
   static int append = -1;
   int J;
   int S;
   int A;
   long E;
   char G;

   public int method225() {
      return 122236875 * this.A;
   }

   public int method227(int var1) {
      try {
         return this.J * 1490207653;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "acb.a(" + ')');
      }
   }

   public char method217(byte var1) {
      try {
         return this.G;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "acb.f(" + ')');
      }
   }

   public int method218(byte var1) {
      try {
         return 122236875 * this.A;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "acb.b(" + ')');
      }
   }

   public long method216(int var1) {
      try {
         return 4761371342045314899L * this.E;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "acb.p(" + ')');
      }
   }

   public int method220(byte var1) {
      try {
         return 1312925659 * this.S;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "acb.i(" + ')');
      }
   }

   public int method221() {
      return this.J * 1490207653;
   }

   public char method219() {
      return this.G;
   }

   public char method223() {
      return this.G;
   }

   public int method222() {
      return 122236875 * this.A;
   }

   public long method226() {
      return 4761371342045314899L * this.E;
   }

   public int method224() {
      return 1312925659 * this.S;
   }

   static final void C(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = XEI.UD[var2];
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "acb.ti(" + ')');
      }
   }

   static final void B(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-13);
         X var4 = IU.F[var2 >> 16];
         IR.I(var3, var4, var0, (byte)-6);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "acb.iq(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, byte var3) {
      try {
         var0.eI = var2.H[(var2.J -= -391880689) * 681479919] * -2074006897;
         VEI.I(var0, -542693615);
         if (-1 == var0.a * -1309843523 && !var1.I) {
            CFI.Z(var0.V * -440872681, (byte)7);
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "acb.ez(" + ')');
      }
   }
}
