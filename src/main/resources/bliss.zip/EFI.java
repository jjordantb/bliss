import java.util.Arrays;

public class EFI extends LDI {
   int append;
   int fill;
   int out;
   int[] println;
   static int Z;
   static QF C;
   public static KJ B;
   static String D;
   public static YBI[] F;

   public void method866(int var1) {
      try {
         SSI var2 = PFI.C[this.out * -2094920785].I(1714980357);
         if (237701933 * this.append == 0) {
            ZX.I(var2, this.println, 0, false, (byte)11);
         } else {
            HL.I(var2, new int[]{this.fill * 2090514815}, new int[1], new int[]{this.append * 237701933}, 1644064563);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "xm.f(" + ')');
      }
   }

   boolean Z(int var1) {
      try {
         BU var2 = GZI.C.I(2090514815 * this.fill, (byte)111);
         return var2.I(1778758091);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "xm.p(" + ')');
      }
   }

   public void method869() {
      SSI var1 = PFI.C[this.out * -2094920785].I(318010293);
      if (237701933 * this.append == 0) {
         ZX.I(var1, this.println, 0, false, (byte)-52);
      } else {
         HL.I(var1, new int[]{this.fill * 2090514815}, new int[1], new int[]{this.append * 237701933}, 1644064563);
      }

   }

   public void method868() {
      SSI var1 = PFI.C[this.out * -2094920785].I(1968398843);
      if (237701933 * this.append == 0) {
         ZX.I(var1, this.println, 0, false, (byte)-20);
      } else {
         HL.I(var1, new int[]{this.fill * 2090514815}, new int[1], new int[]{this.append * 237701933}, 1644064563);
      }

   }

   boolean append() {
      BU var1 = GZI.C.I(2090514815 * this.fill, (byte)25);
      return var1.I(524582595);
   }

   EFI(REI var1) {
      super(var1);
      this.out = var1.C() * 838347599;
      this.println = new int[FCI.I((byte)-63).length];
      this.fill = var1.Y(1235052657) * 1100678783;
      Arrays.fill(this.println, 0, this.println.length, this.fill * 2090514815);
      this.append = var1.H((byte)72) * -1086817115;
   }

   public static PK C(int var0) {
      try {
         PK var1 = EZI.I((byte)-12);
         var1.H = null;
         var1.S = 0;
         var1.J = new QEI(5000);
         return var1;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "xm.b(" + ')');
      }
   }

   public static int I(int var0, int var1, boolean var2, int var3) {
      try {
         DN var4 = CS.I(var0, var2, 692761742);
         if (var4 == null) {
            return -1;
         } else {
            return var1 >= 0 && var1 < var4.E.length ? var4.E[var1] : -1;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "xm.a(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         var0.J -= -783761378;
         int var2 = var0.H[681479919 * var0.J];
         int var3 = var0.H[1 + var0.J * 681479919];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var2 | 1 << var3;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "xm.yj(" + ')');
      }
   }

   static final void I(String var0, byte var1) {
      try {
         System.out.println("Error: " + UG.I(var0, "%0a", "\n", -2025331206));
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "xm.p(" + ')');
      }
   }
}
