import java.awt.Canvas;

public class LJI extends GSI {
   int[] I;
   int B;
   int G;
   JQ L;
   int Z;
   int RA;
   float[] C;
   int D;
   JQ S;
   int F;
   int J;
   int A;
   int E;
   int XA;
   int H;
   int K;
   int M;
   LF currentThread;
   boolean floor;
   YF N;
   YF O;
   float[][] P;
   int method170;
   int method172;
   int Q;
   IBI method174;
   float R;
   boolean method176;
   float T;
   float U;
   float V;
   int W;
   int X;
   YF Y;
   WZ[] method5011;
   int i;
   boolean method581;
   float z;
   float c;
   int method621;

   public void m(int var1, float var2, float var3, float var4, float var5, float var6) {
      this.W = (int)(var2 * 65535.0F) * 295067571;
      this.K = -2064023785 * (int)(var3 * 65535.0F);
      float var7 = (float)Math.sqrt((double)(var5 * var5 + var4 * var4 + var6 * var6));
      this.A = (int)(var4 * 65535.0F / var7) * -666627277;
      this.E = (int)(65535.0F * var5 / var7) * 1031065997;
      this.H = 1231602687 * (int)(var6 * 65535.0F / var7);
   }

   LJI(FEI var1) {
      super(var1);
      this.floor = false;
      this.method176 = false;
      this.D = 0;
      this.Q = 0;
      this.F = 0;
      this.J = 0;
      this.W = 324258125;
      this.K = 740517758;
      this.M = -1151176370;
      this.P = new float[6][4];
      this.V = 1.0F;
      this.z = 0.0F;
      this.i = -169217664;
      this.method581 = false;
      this.L = new JQ(16);
      this.method621 = -2116530773;

      try {
         this.S = new JQ(256);
         this.currentThread = new LF();
         this.Y = new YF();
         this.N = new YF();
         this.O = new YF();
         this.XA(1);
         this.B(0);
         ST.I(true, true, -162450455);
         this.method176 = true;
         this.B = (int)CI.I((byte)1) * -1260974911;
      } catch (Throwable var3) {
         var3.printStackTrace();
         this.H(2022818790);
         throw new RuntimeException("");
      }
   }

   void method4989(int var1, int var2) throws Exception_Sub1 {
      this.MZ.method581(var1, var2);
      if (this.LZ != null) {
         this.LZ.method176(-119853711);
      }

   }

   public void hb(int var1) {
   }

   void method5023() {
      if (this.method176) {
         JF.I(true, false, (short)7077);
         this.method176 = false;
      }

      this.floor = true;
   }

   public OS method5114(LZI var1, RFI[] var2, boolean var3) {
      int[] var4 = new int[var2.length];
      int[] var5 = new int[var2.length];
      boolean var6 = false;

      for(int var7 = 0; var7 < var2.length; ++var7) {
         var4[var7] = var2[var7].Z;
         var5[var7] = var2[var7].F;
         if (var2[var7].A != null) {
            var6 = true;
         }
      }

      if (var3) {
         if (var6) {
            return new QS(this, var1, var2, var4, var5);
         } else {
            return new TS(this, var1, var2, var4, var5);
         }
      } else if (var6) {
         throw new IllegalArgumentException("");
      } else {
         return new PS(this, var1, var2, var4, var5);
      }
   }

   boolean I() {
      return this.floor;
   }

   int[] I(int var1) {
      JQ var3 = this.S;
      QL var2;
      synchronized(this.S) {
         var2 = (QL)this.S.I((long)var1 | Long.MIN_VALUE);
         if (var2 == null) {
            WCI var4;
            if (!this.LZ.method170(var1, (short)2824)) {
               var4 = null;
               return (int[])var4;
            }

            var4 = this.LZ.method174(var1, 2098775003);
            int var5 = !var4.Z && !this.method581 ? 1107560907 * this.i : 64;
            var2 = new QL(var1, var5, this.LZ.method172(var1, 0.7F, var5, var5, true, (byte)2), 1 != -2138060883 * var4.F);
            this.S.I(var2, (long)var1 | Long.MIN_VALUE);
         }
      }

      var2.A = true;
      return var2.I();
   }

   public int method5135(int var1, int var2, int var3, int var4, int var5, int var6) {
      int var7 = 0;
      float var8 = (float)var3 * this.O.I[10] + this.O.I[6] * (float)var2 + (float)var1 * this.O.I[2] + this.O.I[14];
      float var9 = (float)var6 * this.O.I[10] + this.O.I[6] * (float)var5 + this.O.I[14] + (float)var4 * this.O.I[2];
      float var10 = (float)var1 * this.O.I[3] + this.O.I[15] + this.O.I[7] * (float)var2 + (float)var3 * this.O.I[11];
      float var11 = (float)var4 * this.O.I[3] + this.O.I[15] + this.O.I[7] * (float)var5 + this.O.I[11] * (float)var6;
      if (var8 < -var10 && var9 < -var11) {
         var7 |= 16;
      } else if (var8 > var10 && var9 > var11) {
         var7 |= 32;
      }

      float var12 = this.O.I[4] * (float)var2 + this.O.I[12] + this.O.I[0] * (float)var1 + this.O.I[8] * (float)var3;
      float var13 = this.O.I[8] * (float)var6 + (float)var4 * this.O.I[0] + this.O.I[12] + this.O.I[4] * (float)var5;
      if (var12 < -var10 && var13 < -var11) {
         var7 |= 1;
      }

      if (var12 > var10 && var13 > var11) {
         var7 |= 2;
      }

      float var14 = (float)var2 * this.O.I[5] + this.O.I[1] * (float)var1 + this.O.I[13] + this.O.I[9] * (float)var3;
      float var15 = (float)var4 * this.O.I[1] + this.O.I[13] + (float)var5 * this.O.I[5] + this.O.I[9] * (float)var6;
      if (var14 < -var10 && var15 < -var11) {
         var7 |= 4;
      }

      if (var14 > var10 && var15 > var11) {
         var7 |= 8;
      }

      return var7;
   }

   public void method5089(int var1, ADI var2) {
      WZ var3 = this.I((Runnable)Thread.currentThread());
      var3.O = 1450505545 * var1;
      var3.D = -1634857629 * var2.Z;
      var3.e = -296597081 * var2.I;
   }

   public void hv(int var1, int var2, int var3) {
      for(int var4 = 0; var4 < this.method5011.length; ++var4) {
         WZ var5 = this.method5011[var4];
         var5.D = 1903335279 * (var1 & 16777215);
         int var6 = 688695183 * var5.D >>> 16 & 255;
         if (var6 < 2) {
            var6 = 2;
         }

         int var7 = 688695183 * var5.D >> 8 & 255;
         if (var7 < 2) {
            var7 = 2;
         }

         int var8 = var5.D * 688695183 & 255;
         if (var8 < 2) {
            var8 = 2;
         }

         var5.D = (var6 << 16 | var7 << 8 | var8) * 1903335279;
         if (var2 < 0) {
            var5.g = false;
         } else {
            var5.g = true;
         }
      }

   }

   public void ey(float var1, float var2) {
      this.V = var2 - var1;
      this.z = var2 + var1 - 1.0F;

      for(int var3 = 0; var3 < this.X * -922307687; ++var3) {
         WZ var4 = this.method5011[var3];
         FD var5 = var4.K;
         var5.d = this.V;
         var5.H = this.z;
      }

   }

   public boolean method5001() {
      return false;
   }

   public void fy(int var1, int var2) {
      if ((var1 & 1) != 0) {
         this.B(0, 0, 692106883 * this.Z, this.RA * 918677455, var2, 0);
      }

      if ((var1 & 2) != 0) {
         this.Z();
      }

   }

   public boolean method4995() {
      return true;
   }

   public boolean method5050() {
      return false;
   }

   public boolean method4996() {
      return false;
   }

   public boolean method5082() {
      return false;
   }

   public boolean method5032() {
      return false;
   }

   public boolean method5144() {
      return false;
   }

   public boolean method4998() {
      return false;
   }

   public boolean method5051() {
      return true;
   }

   public void method5061(boolean var1) {
   }

   OCI method5006(Canvas var1, int var2, int var3) {
      return JEI.I(this, var1, var2, var3, -1465343898);
   }

   public void method4997(int var1, GE[] var2) {
   }

   public void hj(int var1, int var2, int var3) {
      for(int var4 = 0; var4 < this.method5011.length; ++var4) {
         WZ var5 = this.method5011[var4];
         var5.D = 1903335279 * (var1 & 16777215);
         int var6 = 688695183 * var5.D >>> 16 & 255;
         if (var6 < 2) {
            var6 = 2;
         }

         int var7 = 688695183 * var5.D >> 8 & 255;
         if (var7 < 2) {
            var7 = 2;
         }

         int var8 = var5.D * 688695183 & 255;
         if (var8 < 2) {
            var8 = 2;
         }

         var5.D = (var6 << 16 | var7 << 8 | var8) * 1903335279;
         if (var2 < 0) {
            var5.g = false;
         } else {
            var5.g = true;
         }
      }

   }

   public void I(int[] var1) {
      var1[0] = 692106883 * this.Z;
      var1[1] = this.RA * 918677455;
   }

   void Z() {
      if (this.C != null) {
         int var1;
         int var2;
         int var3;
         if (-912871679 * this.D == 0 && this.Q * -1416794725 == this.Z * 692106883 && -1278653805 * this.F == 0 && 63686679 * this.J == 918677455 * this.RA) {
            var1 = this.C.length;
            var2 = var1 - (var1 & 7);

            for(var3 = 0; var3 < var2; this.C[var3++] = 2.14748365E9F) {
               this.C[var3++] = 2.14748365E9F;
               this.C[var3++] = 2.14748365E9F;
               this.C[var3++] = 2.14748365E9F;
               this.C[var3++] = 2.14748365E9F;
               this.C[var3++] = 2.14748365E9F;
               this.C[var3++] = 2.14748365E9F;
               this.C[var3++] = 2.14748365E9F;
            }

            while(var3 < var1) {
               this.C[var3++] = 2.14748365E9F;
            }
         } else {
            var1 = this.Q * -1416794725 - this.D * -912871679;
            var2 = this.J * 63686679 - -1278653805 * this.F;
            var3 = 692106883 * this.Z - var1;
            int var4 = -1278653805 * this.F * 692106883 * this.Z + this.D * -912871679;
            int var5 = var1 >> 3;
            int var6 = var1 & 7;
            var1 = var4 - 1;

            for(int var7 = -var2; var7 < 0; ++var7) {
               int var8;
               if (var5 > 0) {
                  var8 = var5;

                  do {
                     ++var1;
                     this.C[var1] = 2.14748365E9F;
                     ++var1;
                     this.C[var1] = 2.14748365E9F;
                     ++var1;
                     this.C[var1] = 2.14748365E9F;
                     ++var1;
                     this.C[var1] = 2.14748365E9F;
                     ++var1;
                     this.C[var1] = 2.14748365E9F;
                     ++var1;
                     this.C[var1] = 2.14748365E9F;
                     ++var1;
                     this.C[var1] = 2.14748365E9F;
                     ++var1;
                     this.C[var1] = 2.14748365E9F;
                     --var8;
                  } while(var8 > 0);
               }

               if (var6 > 0) {
                  var8 = var6;

                  do {
                     ++var1;
                     this.C[var1] = 2.14748365E9F;
                     --var8;
                  } while(var8 > 0);
               }

               var1 += var3;
            }
         }
      }

   }

   public void RA(boolean var1) {
      WZ var2 = this.I((Runnable)Thread.currentThread());
      var2.z = var1;
   }

   public void method5011() {
      this.method170 = 0;
      this.method172 = 0;
      this.XA = 845086741 * this.Z;
      this.G = -1768491203 * this.RA;
      this.S();
   }

   public void method5112() {
   }

   public void GA(float var1, float var2) {
      this.V = var2 - var1;
      this.z = var2 + var1 - 1.0F;

      for(int var3 = 0; var3 < this.X * -922307687; ++var3) {
         WZ var4 = this.method5011[var3];
         FD var5 = var4.K;
         var5.d = this.V;
         var5.H = this.z;
      }

   }

   public void er(int[] var1) {
      var1[0] = -912871679 * this.D;
      var1[1] = this.F * -1278653805;
      var1[2] = -1416794725 * this.Q;
      var1[3] = this.J * 63686679;
   }

   public void L() {
      this.D = 0;
      this.F = 0;
      this.Q = 2046188857 * this.Z;
      this.J = -482117367 * this.RA;
      this.S();
   }

   public void r(int var1, int var2, int var3, int var4) {
      if (var1 < 0) {
         var1 = 0;
      }

      if (var2 < 0) {
         var2 = 0;
      }

      if (var3 > 692106883 * this.Z) {
         var3 = 692106883 * this.Z;
      }

      if (var4 > this.RA * 918677455) {
         var4 = 918677455 * this.RA;
      }

      this.D = var1 * -1291169535;
      this.Q = var3 * -1912131437;
      this.F = var2 * 104031131;
      this.J = 1656090535 * var4;
      this.S();
   }

   public int method5024(int var1, int var2) {
      var1 |= 133120;
      return var1 & var2 ^ var2;
   }

   boolean Z(int var1) {
      return this.method581 || this.LZ.method174(var1, 507704159).Z;
   }

   public void XA(int var1, int var2, int var3, int var4, int var5) {
      if (this.I != null && var2 >= -1278653805 * this.F && var2 < 63686679 * this.J) {
         if (var1 < -912871679 * this.D) {
            var3 -= -912871679 * this.D - var1;
            var1 = this.D * -912871679;
         }

         if (var1 + var3 > -1416794725 * this.Q) {
            var3 = -1416794725 * this.Q - var1;
         }

         int var6 = var1 + 692106883 * this.Z * var2;
         int var7 = var4 >>> 24;
         int var8;
         if (var5 != 0 && (var5 != 1 || var7 != 255)) {
            int var9;
            int var10;
            if (var5 == 1) {
               var4 = (var7 << 24) + ((var4 & '\uff00') * var7 >> 8 & '\uff00') + (var7 * (var4 & 16711935) >> 8 & 16711935);
               var8 = 256 - var7;

               for(var9 = 0; var9 < var3; ++var9) {
                  var10 = this.I[var9 + var6];
                  var10 = (var8 * (var10 & '\uff00') >> 8 & '\uff00') + (var8 * (var10 & 16711935) >> 8 & 16711935);
                  this.I[var9 + var6] = var4 + var10;
               }
            } else {
               if (var5 != 2) {
                  throw new IllegalArgumentException();
               }

               for(var8 = 0; var8 < var3; ++var8) {
                  var9 = this.I[var6 + var8];
                  var10 = var4 + var9;
                  int var11 = (var9 & 16711935) + (var4 & 16711935);
                  var9 = (var11 & 16777472) + (var10 - var11 & 65536);
                  this.I[var6 + var8] = var10 - var9 | var9 - (var9 >>> 8);
               }
            }
         } else {
            for(var8 = 0; var8 < var3; ++var8) {
               this.I[var6 + var8] = var4;
            }
         }
      }

   }

   public void method5019(int var1, int var2, int var3, int var4, int var5, int var6) {
      this.XA(var1, var2, var3, var5, var6);
      this.XA(var1, var4 + var2 - 1, var3, var5, var6);
      this.G(var1, 1 + var2, var4 - 2, var5, var6);
      this.G(var1 + var3 - 1, 1 + var2, var4 - 2, var5, var6);
   }

   public void B(int var1, int var2, int var3, int var4, int var5, int var6) {
      if (this.I != null) {
         if (var1 < this.D * -912871679) {
            var3 -= -912871679 * this.D - var1;
            var1 = this.D * -912871679;
         }

         if (var2 < -1278653805 * this.F) {
            var4 -= -1278653805 * this.F - var2;
            var2 = -1278653805 * this.F;
         }

         if (var1 + var3 > this.Q * -1416794725) {
            var3 = -1416794725 * this.Q - var1;
         }

         if (var4 + var2 > 63686679 * this.J) {
            var4 = 63686679 * this.J - var2;
         }

         if (var3 > 0 && var4 > 0 && var1 <= this.Q * -1416794725 && var2 <= this.J * 63686679) {
            int var7 = this.Z * 692106883 - var3;
            int var8 = var2 * this.Z * 692106883 + var1;
            int var9 = var5 >>> 24;
            int var10;
            int var11;
            int var12;
            if (var6 == 0 || var6 == 1 && 255 == var9) {
               var10 = var3 >> 3;
               var11 = var3 & 7;
               var3 = var8 - 1;

               for(var12 = -var4; var12 < 0; ++var12) {
                  if (var10 > 0) {
                     var1 = var10;

                     do {
                        ++var3;
                        this.I[var3] = var5;
                        ++var3;
                        this.I[var3] = var5;
                        ++var3;
                        this.I[var3] = var5;
                        ++var3;
                        this.I[var3] = var5;
                        ++var3;
                        this.I[var3] = var5;
                        ++var3;
                        this.I[var3] = var5;
                        ++var3;
                        this.I[var3] = var5;
                        ++var3;
                        this.I[var3] = var5;
                        --var1;
                     } while(var1 > 0);
                  }

                  if (var11 > 0) {
                     var1 = var11;

                     do {
                        ++var3;
                        this.I[var3] = var5;
                        --var1;
                     } while(var1 > 0);
                  }

                  var3 += var7;
               }
            } else {
               int var13;
               if (1 == var6) {
                  var5 = (var9 * (var5 & 16711935) >> 8 & 16711935) + (var9 * ((var5 & -16711936) >>> 8) & -16711936);
                  var10 = 256 - var9;

                  for(var11 = 0; var11 < var4; ++var11) {
                     for(var12 = -var3; var12 < 0; ++var12) {
                        var13 = this.I[var8];
                        var13 = ((var13 & 16711935) * var10 >> 8 & 16711935) + (var10 * ((var13 & -16711936) >>> 8) & -16711936);
                        this.I[var8++] = var13 + var5;
                     }

                     var8 += var7;
                  }
               } else {
                  if (var6 != 2) {
                     throw new IllegalArgumentException();
                  }

                  for(var10 = 0; var10 < var4; ++var10) {
                     for(var11 = -var3; var11 < 0; ++var11) {
                        var12 = this.I[var8];
                        var13 = var5 + var12;
                        int var14 = (var5 & 16711935) + (var12 & 16711935);
                        var12 = (var13 - var14 & 65536) + (var14 & 16777472);
                        this.I[var8++] = var13 - var12 | var12 - (var12 >>> 8);
                     }

                     var8 += var7;
                  }
               }
            }
         }
      }

   }

   public void N(int var1, int var2, int var3, int var4, int var5, int var6, byte[] var7, int var8, int var9) {
      if (this.I != null && var3 > 0 && var4 > 0) {
         int var10 = 0;
         int var11 = 0;
         int var12 = (var8 << 16) / var3;
         int var13 = (var7.length / var8 << 16) / var4;
         int var14 = var1 + var2 * 692106883 * this.Z;
         int var15 = 692106883 * this.Z - var3;
         if (var4 + var2 > this.J * 63686679) {
            var4 -= var2 + var4 - 63686679 * this.J;
         }

         int var16;
         if (var2 < this.F * -1278653805) {
            var16 = -1278653805 * this.F - var2;
            var4 -= var16;
            var14 += var16 * this.Z * 692106883;
            var11 += var16 * var13;
         }

         if (var1 + var3 > -1416794725 * this.Q) {
            var16 = var1 + var3 - this.Q * -1416794725;
            var3 -= var16;
            var15 += var16;
         }

         if (var1 < this.D * -912871679) {
            var16 = -912871679 * this.D - var1;
            var3 -= var16;
            var14 += var16;
            var10 += var12 * var16;
            var15 += var16;
         }

         var16 = var5 >>> 24;
         int var17 = var6 >>> 24;
         int var18;
         int var19;
         int var20;
         int var21;
         if (var9 != 0 && (1 != var9 || var16 != 255 || var17 != 255)) {
            int var22;
            int var23;
            int var24;
            int var25;
            if (1 == var9) {
               var18 = var10;

               for(var19 = -var4; var19 < 0; ++var19) {
                  var20 = (var11 >> 16) * var8;

                  for(var21 = -var3; var21 < 0; ++var21) {
                     var22 = var5;
                     if (var7[(var10 >> 16) + var20] != 0) {
                        var22 = var6;
                     }

                     var23 = var22 >>> 24;
                     var24 = 255 - var23;
                     var25 = this.I[var14];
                     this.I[var14++] = (var23 * (var22 & '\uff00') + (var25 & '\uff00') * var24 & 16711680) + ((var25 & 16711935) * var24 + (var22 & 16711935) * var23 & -16711936) >> 8;
                     var10 += var12;
                  }

                  var11 += var13;
                  var10 = var18;
                  var14 += var15;
               }
            } else {
               if (var9 != 2) {
                  throw new IllegalArgumentException();
               }

               var18 = var10;

               for(var19 = -var4; var19 < 0; ++var19) {
                  var20 = var8 * (var11 >> 16);

                  for(var21 = -var3; var21 < 0; ++var21) {
                     var22 = var5;
                     if (var7[(var10 >> 16) + var20] != 0) {
                        var22 = var6;
                     }

                     if (var22 != 0) {
                        var23 = this.I[var14];
                        var24 = var23 + var22;
                        var25 = (var23 & 16711935) + (var22 & 16711935);
                        var23 = (var25 & 16777472) + (var24 - var25 & 65536);
                        this.I[var14++] = var24 - var23 | var23 - (var23 >>> 8);
                     } else {
                        ++var14;
                     }

                     var10 += var12;
                  }

                  var11 += var13;
                  var10 = var18;
                  var14 += var15;
               }
            }
         } else {
            var18 = var10;

            for(var19 = -var4; var19 < 0; ++var19) {
               var20 = (var11 >> 16) * var8;

               for(var21 = -var3; var21 < 0; ++var21) {
                  if (var7[(var10 >> 16) + var20] != 0) {
                     this.I[var14++] = var6;
                  } else {
                     this.I[var14++] = var5;
                  }

                  var10 += var12;
               }

               var11 += var13;
               var10 = var18;
               var14 += var15;
            }
         }
      }

   }

   void CA(int var1, int var2, int var3, int var4, int var5) {
      if (this.I != null) {
         if (var3 < 0) {
            var3 = -var3;
         }

         int var6 = var2 - var3;
         if (var6 < -1278653805 * this.F) {
            var6 = this.F * -1278653805;
         }

         int var7 = var3 + var2 + 1;
         if (var7 > this.J * 63686679) {
            var7 = 63686679 * this.J;
         }

         int var8 = var6;
         int var9 = var3 * var3;
         int var10 = 0;
         int var11 = var2 - var6;
         int var12 = var11 * var11;
         int var13 = var12 - var11;
         if (var2 > var7) {
            var2 = var7;
         }

         int var14 = var4 >>> 24;
         int var15;
         int var16;
         int var17;
         int var18;
         if (var5 != 0 && (var5 != 1 || var14 != 255)) {
            int var19;
            int var20;
            if (var5 == 1) {
               var4 = (var14 << 24) + (var14 * (var4 & 16711935) >> 8 & 16711935) + (var14 * (var4 & '\uff00') >> 8 & '\uff00');

               for(var15 = 256 - var14; var8 < var2; var13 -= var11 + var11) {
                  while(var13 <= var9 || var12 <= var9) {
                     var12 += var10 + var10;
                     var13 += var10++ + var10;
                  }

                  var16 = 1 + (var1 - var10);
                  if (var16 < -912871679 * this.D) {
                     var16 = this.D * -912871679;
                  }

                  var17 = var1 + var10;
                  if (var17 > -1416794725 * this.Q) {
                     var17 = this.Q * -1416794725;
                  }

                  var18 = this.Z * 692106883 * var8 + var16;

                  for(var19 = var16; var19 < var17; ++var19) {
                     var20 = this.I[var18];
                     var20 = ((var20 & 16711935) * var15 >> 8 & 16711935) + (var15 * (var20 & '\uff00') >> 8 & '\uff00');
                     this.I[var18++] = var4 + var20;
                  }

                  ++var8;
                  var12 -= var11-- + var11;
               }

               var10 = var3;
               var11 = -var11;
               var13 = var9 + var11 * var11;
               var12 = var13 - var3;

               for(var13 -= var11; var8 < var7; var12 += var11++ + var11) {
                  while(var13 > var9 && var12 > var9) {
                     var13 -= var10-- + var10;
                     var12 -= var10 + var10;
                  }

                  var16 = var1 - var10;
                  if (var16 < this.D * -912871679) {
                     var16 = this.D * -912871679;
                  }

                  var17 = var1 + var10;
                  if (var17 > this.Q * -1416794725 - 1) {
                     var17 = -1416794725 * this.Q - 1;
                  }

                  var18 = 692106883 * this.Z * var8 + var16;

                  for(var19 = var16; var19 <= var17; ++var19) {
                     var20 = this.I[var18];
                     var20 = ((var20 & 16711935) * var15 >> 8 & 16711935) + (var15 * (var20 & '\uff00') >> 8 & '\uff00');
                     this.I[var18++] = var4 + var20;
                  }

                  ++var8;
                  var13 += var11 + var11;
               }
            } else {
               if (var5 != 2) {
                  throw new IllegalArgumentException();
               }

               int var21;
               while(var8 < var2) {
                  while(var13 <= var9 || var12 <= var9) {
                     var12 += var10 + var10;
                     var13 += var10++ + var10;
                  }

                  var15 = var1 - var10 + 1;
                  if (var15 < -912871679 * this.D) {
                     var15 = this.D * -912871679;
                  }

                  var16 = var1 + var10;
                  if (var16 > -1416794725 * this.Q) {
                     var16 = this.Q * -1416794725;
                  }

                  var17 = this.Z * 692106883 * var8 + var15;

                  for(var18 = var15; var18 < var16; ++var18) {
                     var19 = this.I[var17];
                     var20 = var4 + var19;
                     var21 = (var4 & 16711935) + (var19 & 16711935);
                     var19 = (var21 & 16777472) + (var20 - var21 & 65536);
                     this.I[var17++] = var20 - var19 | var19 - (var19 >>> 8);
                  }

                  ++var8;
                  var12 -= var11-- + var11;
                  var13 -= var11 + var11;
               }

               var10 = var3;
               var11 = -var11;
               var13 = var11 * var11 + var9;
               var12 = var13 - var3;

               for(var13 -= var11; var8 < var7; var12 += var11++ + var11) {
                  while(var13 > var9 && var12 > var9) {
                     var13 -= var10-- + var10;
                     var12 -= var10 + var10;
                  }

                  var15 = var1 - var10;
                  if (var15 < this.D * -912871679) {
                     var15 = -912871679 * this.D;
                  }

                  var16 = var1 + var10;
                  if (var16 > this.Q * -1416794725 - 1) {
                     var16 = this.Q * -1416794725 - 1;
                  }

                  var17 = var15 + var8 * this.Z * 692106883;

                  for(var18 = var15; var18 <= var16; ++var18) {
                     var19 = this.I[var17];
                     var20 = var19 + var4;
                     var21 = (var19 & 16711935) + (var4 & 16711935);
                     var19 = (var20 - var21 & 65536) + (var21 & 16777472);
                     this.I[var17++] = var20 - var19 | var19 - (var19 >>> 8);
                  }

                  ++var8;
                  var13 += var11 + var11;
               }
            }
         } else {
            while(var8 < var2) {
               while(var13 <= var9 || var12 <= var9) {
                  var12 += var10 + var10;
                  var13 += var10++ + var10;
               }

               var15 = var1 - var10 + 1;
               if (var15 < this.D * -912871679) {
                  var15 = -912871679 * this.D;
               }

               var16 = var10 + var1;
               if (var16 > this.Q * -1416794725) {
                  var16 = this.Q * -1416794725;
               }

               var17 = var15 + this.Z * 692106883 * var8;

               for(var18 = var15; var18 < var16; ++var18) {
                  this.I[var17++] = var4;
               }

               ++var8;
               var12 -= var11-- + var11;
               var13 -= var11 + var11;
            }

            var10 = var3;
            var11 = var8 - var2;
            var13 = var11 * var11 + var9;
            var12 = var13 - var3;

            for(var13 -= var11; var8 < var7; var12 += var11++ + var11) {
               while(var13 > var9 && var12 > var9) {
                  var13 -= var10-- + var10;
                  var12 -= var10 + var10;
               }

               var15 = var1 - var10;
               if (var15 < this.D * -912871679) {
                  var15 = this.D * -912871679;
               }

               var16 = var1 + var10;
               if (var16 > -1416794725 * this.Q - 1) {
                  var16 = -1416794725 * this.Q - 1;
               }

               var17 = var8 * 692106883 * this.Z + var15;

               for(var18 = var15; var18 <= var16; ++var18) {
                  this.I[var17++] = var4;
               }

               ++var8;
               var13 += var11 + var11;
            }

            return;
         }
      }

   }

   public IBI method5108(int var1, int var2, int var3, int var4, boolean var5) {
      if (this.I == null) {
         throw new IllegalStateException("");
      } else {
         int[] var6 = new int[var3 * var4];
         int var7 = var2 * 692106883 * this.Z + var1;
         int var8 = 692106883 * this.Z - var3;

         for(int var9 = 0; var9 < var4; ++var9) {
            int var10 = var3 * var9;

            for(int var11 = 0; var11 < var3; ++var11) {
               var6[var11 + var10] = this.I[var7++];
            }

            var7 += var8;
         }

         if (var5) {
            return new CBI(this, var6, var3, var4);
         } else {
            return new BBI(this, var6, var3, var4);
         }
      }
   }

   public boolean method5077() {
      return false;
   }

   public void G(int var1, int var2, int var3, int var4, int var5) {
      if (this.I != null && var1 >= this.D * -912871679 && var1 < this.Q * -1416794725) {
         if (var2 < -1278653805 * this.F) {
            var3 -= this.F * -1278653805 - var2;
            var2 = this.F * -1278653805;
         }

         if (var3 + var2 > 63686679 * this.J) {
            var3 = 63686679 * this.J - var2;
         }

         int var6 = var1 + var2 * this.Z * 692106883;
         int var7 = var4 >>> 24;
         int var8;
         if (var5 != 0 && (1 != var5 || 255 != var7)) {
            int var9;
            int var10;
            int var11;
            if (var5 == 1) {
               var4 = (var7 * (var4 & '\uff00') >> 8 & '\uff00') + ((var4 & 16711935) * var7 >> 8 & 16711935) + (var7 << 24);
               var8 = 256 - var7;

               for(var9 = 0; var9 < var3; ++var9) {
                  var10 = var9 * 692106883 * this.Z + var6;
                  var11 = this.I[var10];
                  var11 = (var8 * (var11 & 16711935) >> 8 & 16711935) + ((var11 & '\uff00') * var8 >> 8 & '\uff00');
                  this.I[var10] = var11 + var4;
               }
            } else {
               if (2 != var5) {
                  throw new IllegalArgumentException();
               }

               for(var8 = 0; var8 < var3; ++var8) {
                  var9 = var8 * 692106883 * this.Z + var6;
                  var10 = this.I[var9];
                  var11 = var4 + var10;
                  int var12 = (var10 & 16711935) + (var4 & 16711935);
                  var10 = (var12 & 16777472) + (var11 - var12 & 65536);
                  this.I[var9] = var11 - var10 | var10 - (var10 >>> 8);
               }
            }
         } else {
            for(var8 = 0; var8 < var3; ++var8) {
               this.I[var6 + var8 * this.Z * 692106883] = var4;
            }
         }
      }

   }

   public void method5187(int var1, int var2, int var3, int var4) {
      this.method170 = 1021645229 * var1;
      this.method172 = var2 * 574739315;
      this.XA = 626158471 * var3;
      this.G = 370599731 * var4;
      this.S();
   }

   public void es(int[] var1) {
      var1[0] = -912871679 * this.D;
      var1[1] = this.F * -1278653805;
      var1[2] = -1416794725 * this.Q;
      var1[3] = this.J * 63686679;
   }

   public void method5039(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9) {
      if (this.I != null) {
         var3 -= var1;
         var4 -= var2;
         int var10;
         if (var4 == 0) {
            if (var3 >= 0) {
               this.method174(var1, var2, 1 + var3, var5, var6, var7, var8, var9);
            } else {
               var10 = var8 + var7;
               var9 %= var10;
               var9 = var7 + var10 - var9 - (1 + -var3) % var10;
               var9 %= var10;
               if (var9 < 0) {
                  var9 += var10;
               }

               this.method174(var3 + var1, var2, 1 + -var3, var5, var6, var7, var8, var9);
            }
         } else if (var3 == 0) {
            if (var4 >= 0) {
               this.method170(var1, var2, var4 + 1, var5, var6, var7, var8, var9);
            } else {
               var10 = var8 + var7;
               var9 %= var10;
               var9 = var7 + var10 - var9 - (-var4 + 1) % var10;
               var9 %= var10;
               if (var9 < 0) {
                  var9 += var10;
               }

               this.method170(var1, var4 + var2, 1 + -var4, var5, var6, var7, var8, var9);
            }
         } else {
            var9 <<= 8;
            var7 <<= 8;
            var8 <<= 8;
            var10 = var8 + var7;
            var9 %= var10;
            int var11;
            int var12;
            if (var4 + var3 < 0) {
               var11 = (int)(Math.sqrt((double)(var4 * var4 + var3 * var3)) * 256.0D);
               var12 = var11 % var10;
               var9 = var10 + var7 - var9 - var12;
               var9 %= var10;
               if (var9 < 0) {
                  var9 += var10;
               }

               var1 += var3;
               var3 = -var3;
               var2 += var4;
               var4 = -var4;
            }

            int var13;
            int var14;
            int var15;
            int var16;
            int var17;
            int var18;
            if (var3 > var4) {
               var2 <<= 16;
               var2 += 32768;
               var4 <<= 16;
               var11 = (int)Math.floor(0.5D + (double)var4 / (double)var3);
               var3 += var1;
               var12 = var5 >>> 24;
               var13 = (int)Math.sqrt((double)(65536 + (var11 >> 8) * (var11 >> 8)));
               if (var6 != 0 && (1 != var6 || var12 != 255)) {
                  if (var6 == 1) {
                     var5 = (var12 << 24) + ((var5 & '\uff00') * var12 >> 8 & '\uff00') + (var12 * (var5 & 16711935) >> 8 & 16711935);

                     for(var14 = 256 - var12; var1 <= var3; var9 %= var10) {
                        var15 = var2 >> 16;
                        if (var1 >= this.D * -912871679 && var1 < this.Q * -1416794725 && var15 >= this.F * -1278653805 && var15 < 63686679 * this.J && var9 < var7) {
                           var16 = var1 + var15 * 692106883 * this.Z;
                           var17 = this.I[var16];
                           var17 = ((var17 & 16711935) * var14 >> 8 & 16711935) + (var14 * (var17 & '\uff00') >> 8 & '\uff00');
                           this.I[var16] = var17 + var5;
                        }

                        var2 += var11;
                        ++var1;
                        var9 += var13;
                     }
                  } else {
                     if (2 != var6) {
                        throw new IllegalArgumentException();
                     }

                     while(var1 <= var3) {
                        var14 = var2 >> 16;
                        if (var1 >= this.D * -912871679 && var1 < -1416794725 * this.Q && var14 >= -1278653805 * this.F && var14 < 63686679 * this.J && var9 < var7) {
                           var15 = var1 + var14 * this.Z * 692106883;
                           var16 = this.I[var15];
                           var17 = var16 + var5;
                           var18 = (var16 & 16711935) + (var5 & 16711935);
                           var16 = (var18 & 16777472) + (var17 - var18 & 65536);
                           this.I[var15] = var17 - var16 | var16 - (var16 >>> 8);
                        }

                        var2 += var11;
                        ++var1;
                        var9 += var13;
                        var9 %= var10;
                     }
                  }
               } else {
                  while(var1 <= var3) {
                     var14 = var2 >> 16;
                     if (var1 >= this.D * -912871679 && var1 < -1416794725 * this.Q && var14 >= this.F * -1278653805 && var14 < this.J * 63686679 && var9 < var7) {
                        this.I[this.Z * 692106883 * var14 + var1] = var5;
                     }

                     var2 += var11;
                     ++var1;
                     var9 += var13;
                     var9 %= var10;
                  }
               }
            } else {
               var1 <<= 16;
               var1 += 32768;
               var3 <<= 16;
               var11 = (int)Math.floor((double)var3 / (double)var4 + 0.5D);
               var4 += var2;
               var12 = var5 >>> 24;
               var13 = (int)Math.sqrt((double)((var11 >> 8) * (var11 >> 8) + 65536));
               if (var6 == 0 || 1 == var6 && var12 == 255) {
                  while(var2 <= var4) {
                     var14 = var1 >> 16;
                     if (var2 >= this.F * -1278653805 && var2 < 63686679 * this.J && var14 >= -912871679 * this.D && var14 < -1416794725 * this.Q && var9 < var7) {
                        this.I[var2 * this.Z * 692106883 + var14] = var5;
                     }

                     var1 += var11;
                     ++var2;
                     var9 += var13;
                     var9 %= var10;
                  }
               } else if (var6 == 1) {
                  var5 = (var12 << 24) + ((var5 & 16711935) * var12 >> 8 & 16711935) + ((var5 & '\uff00') * var12 >> 8 & '\uff00');

                  for(var14 = 256 - var12; var2 <= var4; var9 %= var10) {
                     var15 = var1 >> 16;
                     if (var2 >= this.F * -1278653805 && var2 < 63686679 * this.J && var15 >= -912871679 * this.D && var15 < -1416794725 * this.Q && var9 < var7) {
                        var16 = 692106883 * this.Z * var2 + var15;
                        var17 = this.I[var16];
                        var17 = (var14 * (var17 & '\uff00') >> 8 & '\uff00') + (var14 * (var17 & 16711935) >> 8 & 16711935);
                        this.I[692106883 * this.Z * var2 + var15] = var5 + var17;
                     }

                     var1 += var11;
                     ++var2;
                     var9 += var13;
                  }
               } else {
                  if (2 != var6) {
                     throw new IllegalArgumentException();
                  }

                  while(var2 <= var4) {
                     var14 = var1 >> 16;
                     if (var2 >= this.F * -1278653805 && var2 < this.J * 63686679 && var14 >= -912871679 * this.D && var14 < this.Q * -1416794725 && var9 < var7) {
                        var15 = var14 + var2 * 692106883 * this.Z;
                        var16 = this.I[var15];
                        var17 = var16 + var5;
                        var18 = (var16 & 16711935) + (var5 & 16711935);
                        var16 = (var18 & 16777472) + (var17 - var18 & 65536);
                        this.I[var15] = var17 - var16 | var16 - (var16 >>> 8);
                     }

                     var1 += var11;
                     ++var2;
                     var9 += var13;
                     var9 %= var10;
                  }
               }
            }
         }
      }

   }

   public SBI method4987() {
      return new SBI(0, "Pure Java", 1, "CPU", 0L);
   }

   public void method5007(int var1, int var2, int var3, int var4, int var5, int var6, QJI var7, int var8, int var9, int var10, int var11, int var12) {
      if (this.I != null) {
         TJI var13 = (TJI)var7;
         int[] var14 = var13.Z;
         int[] var15 = var13.I;
         int var16 = this.F * -1278653805 > var9 ? -1278653805 * this.F : var9;
         int var17 = this.J * 63686679 < var9 + var14.length ? this.J * 63686679 : var9 + var14.length;
         var12 <<= 8;
         var10 <<= 8;
         var11 <<= 8;
         int var18 = var10 + var11;
         var12 %= var18;
         var3 -= var1;
         var4 -= var2;
         int var19;
         int var20;
         if (var4 + var3 < 0) {
            var19 = (int)(Math.sqrt((double)(var4 * var4 + var3 * var3)) * 256.0D);
            var20 = var19 % var18;
            var12 = var10 + var18 - var12 - var20;
            var12 %= var18;
            if (var12 < 0) {
               var12 += var18;
            }

            var1 += var3;
            var3 = -var3;
            var2 += var4;
            var4 = -var4;
         }

         int var21;
         int var22;
         int var23;
         int var24;
         int var25;
         int var26;
         int var27;
         if (var3 > var4) {
            var2 <<= 16;
            var2 += 32768;
            var4 <<= 16;
            var19 = (int)Math.floor((double)var4 / (double)var3 + 0.5D);
            var3 += var1;
            var20 = var5 >>> 24;
            var21 = (int)Math.sqrt((double)(65536 + (var19 >> 8) * (var19 >> 8)));
            if (var6 != 0 && (var6 != 1 || 255 != var20)) {
               if (1 == var6) {
                  var5 = (var20 << 24) + (var20 * (var5 & 16711935) >> 8 & 16711935) + ((var5 & '\uff00') * var20 >> 8 & '\uff00');

                  for(var22 = 256 - var20; var1 <= var3; var12 %= var18) {
                     var23 = var2 >> 16;
                     var24 = var23 - var9;
                     if (var1 >= -912871679 * this.D && var1 < this.Q * -1416794725 && var23 >= var16 && var23 < var17 && var12 < var10) {
                        var25 = var8 + var14[var24];
                        if (var1 >= var25 && var1 < var15[var24] + var25) {
                           var26 = var1 + this.Z * 692106883 * var23;
                           var27 = this.I[var26];
                           var27 = (var22 * (var27 & '\uff00') >> 8 & '\uff00') + (var22 * (var27 & 16711935) >> 8 & 16711935);
                           this.I[var26] = var27 + var5;
                        }
                     }

                     var2 += var19;
                     ++var1;
                     var12 += var21;
                  }
               } else {
                  if (var6 != 2) {
                     throw new IllegalArgumentException();
                  }

                  while(var1 <= var3) {
                     var22 = var2 >> 16;
                     var23 = var22 - var9;
                     if (var1 >= this.D * -912871679 && var1 < -1416794725 * this.Q && var22 >= var16 && var22 < var17 && var12 < var10) {
                        var24 = var14[var23] + var8;
                        if (var1 >= var24 && var1 < var24 + var15[var23]) {
                           var25 = 692106883 * this.Z * var22 + var1;
                           var26 = this.I[var25];
                           var27 = var5 + var26;
                           int var28 = (var5 & 16711935) + (var26 & 16711935);
                           var26 = (var27 - var28 & 65536) + (var28 & 16777472);
                           this.I[var25] = var27 - var26 | var26 - (var26 >>> 8);
                        }
                     }

                     var2 += var19;
                     ++var1;
                     var12 += var21;
                     var12 %= var18;
                  }
               }
            } else {
               while(var1 <= var3) {
                  var22 = var2 >> 16;
                  var23 = var22 - var9;
                  if (var1 >= this.D * -912871679 && var1 < -1416794725 * this.Q && var22 >= var16 && var22 < var17 && var12 < var10) {
                     var24 = var14[var23] + var8;
                     if (var1 >= var24 && var1 < var24 + var15[var23]) {
                        this.I[var1 + 692106883 * this.Z * var22] = var5;
                     }
                  }

                  var2 += var19;
                  ++var1;
                  var12 += var21;
                  var12 %= var18;
               }
            }
         } else {
            var1 <<= 16;
            var1 += 32768;
            var3 <<= 16;
            var19 = (int)Math.floor(0.5D + (double)var3 / (double)var4);
            var20 = (int)Math.sqrt((double)((var19 >> 8) * (var19 >> 8) + 65536));
            var4 += var2;
            var21 = var5 >>> 24;
            if (var6 == 0 || var6 == 1 && var21 == 255) {
               while(var2 <= var4) {
                  var22 = var1 >> 16;
                  var23 = var2 - var9;
                  if (var2 >= var16 && var2 < var17 && var22 >= this.D * -912871679 && var22 < this.Q * -1416794725 && var12 < var10 && var22 >= var8 + var14[var23] && var22 < var15[var23] + var8 + var14[var23]) {
                     this.I[var2 * 692106883 * this.Z + var22] = var5;
                  }

                  var1 += var19;
                  ++var2;
                  var12 += var20;
                  var12 %= var18;
               }
            } else if (1 == var6) {
               var5 = ((var5 & 16711935) * var21 >> 8 & 16711935) + ((var5 & '\uff00') * var21 >> 8 & '\uff00') + (var21 << 24);

               for(var22 = 256 - var21; var2 <= var4; var12 %= var18) {
                  var23 = var1 >> 16;
                  var24 = var2 - var9;
                  if (var2 >= var16 && var2 < var17 && var23 >= this.D * -912871679 && var23 < this.Q * -1416794725 && var12 < var10 && var23 >= var8 + var14[var24] && var23 < var14[var24] + var8 + var15[var24]) {
                     var25 = var23 + var2 * this.Z * 692106883;
                     var26 = this.I[var25];
                     var26 = (var22 * (var26 & '\uff00') >> 8 & '\uff00') + ((var26 & 16711935) * var22 >> 8 & 16711935);
                     this.I[var23 + var2 * this.Z * 692106883] = var5 + var26;
                  }

                  var1 += var19;
                  ++var2;
                  var12 += var20;
               }
            } else {
               if (2 != var6) {
                  throw new IllegalArgumentException();
               }

               while(var2 <= var4) {
                  var22 = var1 >> 16;
                  var23 = var2 - var9;
                  if (var2 >= var16 && var2 < var17 && var22 >= this.D * -912871679 && var22 < this.Q * -1416794725 && var12 < var10 && var22 >= var8 + var14[var23] && var22 < var14[var23] + var8 + var15[var23]) {
                     var24 = 692106883 * this.Z * var2 + var22;
                     var25 = this.I[var24];
                     var26 = var25 + var5;
                     var27 = (var5 & 16711935) + (var25 & 16711935);
                     var25 = (var27 & 16777472) + (var26 - var27 & 65536);
                     this.I[var24] = var26 - var25 | var25 - (var25 >>> 8);
                  }

                  var1 += var19;
                  ++var2;
                  var12 += var20;
                  var12 %= var18;
               }
            }
         }
      }

   }

   public void method4999(int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      if (this.I != null) {
         WZ var8 = this.I((Runnable)Thread.currentThread());
         FD var9 = var8.K;
         int var10 = var3 - var1;
         int var11 = var4 - var2;
         int var12 = var10 >= 0 ? var10 : -var10;
         int var13 = var11 >= 0 ? var11 : -var11;
         int var14 = var12;
         if (var12 < var13) {
            var14 = var13;
         }

         if (var14 != 0) {
            int var15 = (var10 << 16) / var14;
            int var16 = (var11 << 16) / var14;
            var10 += var15 >> 16;
            var11 += var16 >> 16;
            if (var16 <= var15) {
               var15 = -var15;
            } else {
               var16 = -var16;
            }

            int var17 = var16 * var6 >> 17;
            int var18 = var16 * var6 + 1 >> 17;
            int var19 = var15 * var6 >> 17;
            int var20 = 1 + var6 * var15 >> 17;
            var1 -= var9.I();
            var2 -= var9.Z();
            int var21 = var17 + var1;
            int var22 = var1 - var18;
            int var23 = var1 + var10 - var18;
            int var24 = var17 + var1 + var10;
            int var25 = var2 + var19;
            int var26 = var2 - var20;
            int var27 = var11 + var2 - var20;
            int var28 = var2 + var11 + var19;
            if (var7 == 0) {
               var9.B = 0;
            } else {
               if (var7 != 1) {
                  throw new IllegalArgumentException();
               }

               var9.B = 255 - (var5 >>> 24);
            }

            this.RA(false);
            var9.D = var21 < 0 || var21 > var9.J || var22 < 0 || var22 > var9.J || var23 < 0 || var23 > var9.J;
            var9.I(true, false, false, (float)var25, (float)var26, (float)var27, (float)var21, (float)var22, (float)var23, 100.0F, 100.0F, 100.0F, var5);
            var9.D = var21 < 0 || var21 > var9.J || var23 < 0 || var23 > var9.J || var24 < 0 || var24 > var9.J;
            var9.I(true, false, false, (float)var25, (float)var27, (float)var28, (float)var21, (float)var23, (float)var24, 100.0F, 100.0F, 100.0F, var5);
            this.RA(true);
         }
      }

   }

   boolean C(int var1) {
      return this.LZ.method170(var1, (short)19583);
   }

   public VJI method5026(int var1) {
      return null;
   }

   public void method5027(VJI var1) {
   }

   public boolean method5052() {
      return false;
   }

   public QJI method5034(int var1, int var2, int[] var3, int[] var4) {
      return new TJI(var1, var2, var3, var4);
   }

   public OBI method5181(int var1, int var2, int var3, int var4, int var5, int var6) {
      return null;
   }

   public IBI method5033(int var1, int var2, int var3, int var4, boolean var5) {
      if (this.I == null) {
         throw new IllegalStateException("");
      } else {
         int[] var6 = new int[var3 * var4];
         int var7 = var2 * 692106883 * this.Z + var1;
         int var8 = 692106883 * this.Z - var3;

         for(int var9 = 0; var9 < var4; ++var9) {
            int var10 = var3 * var9;

            for(int var11 = 0; var11 < var3; ++var11) {
               var6[var11 + var10] = this.I[var7++];
            }

            var7 += var8;
         }

         if (var5) {
            return new CBI(this, var6, var3, var4);
         } else {
            return new BBI(this, var6, var3, var4);
         }
      }
   }

   public boolean method5146() {
      return false;
   }

   public void DA(int var1, QJI var2, int var3, int var4) {
      if (this.I != null) {
         TJI var5 = (TJI)var2;
         int[] var6 = var5.Z;
         int[] var7 = var5.I;
         int var8;
         if (63686679 * this.J < var6.length + var4) {
            var8 = this.J * 63686679 - var4;
         } else {
            var8 = var6.length;
         }

         int var9;
         if (this.F * -1278653805 > var4) {
            var9 = this.F * -1278653805 - var4;
            var4 = this.F * -1278653805;
         } else {
            var9 = 0;
         }

         if (var8 - var9 > 0) {
            int var10 = 692106883 * this.Z * var4;

            for(int var11 = var9; var11 < var8; ++var11) {
               int var12 = var3 + var6[var11];
               int var13 = var7[var11];
               if (this.D * -912871679 > var12) {
                  var13 -= -912871679 * this.D - var12;
                  var12 = -912871679 * this.D;
               }

               if (-1416794725 * this.Q < var12 + var13) {
                  var13 = -1416794725 * this.Q - var12;
               }

               var12 += var10;

               for(int var14 = -var13; var14 < 0; ++var14) {
                  this.I[var12++] = var1;
               }

               var10 += this.Z * 692106883;
            }
         }
      }

   }

   public void method5128(XBI var1) {
      this.G(this.I != null, this.C != null, false, var1);
   }

   public OBI method5185(int var1, int var2, int var3, int var4, int var5, int var6) {
      return null;
   }

   public void hn(int var1, int var2, int var3) {
      for(int var4 = 0; var4 < this.method5011.length; ++var4) {
         WZ var5 = this.method5011[var4];
         var5.D = 1903335279 * (var1 & 16777215);
         int var6 = 688695183 * var5.D >>> 16 & 255;
         if (var6 < 2) {
            var6 = 2;
         }

         int var7 = 688695183 * var5.D >> 8 & 255;
         if (var7 < 2) {
            var7 = 2;
         }

         int var8 = var5.D * 688695183 & 255;
         if (var8 < 2) {
            var8 = 2;
         }

         var5.D = (var6 << 16 | var7 << 8 | var8) * 1903335279;
         if (var2 < 0) {
            var5.g = false;
         } else {
            var5.g = true;
         }
      }

   }

   public void method5066() {
   }

   public int method5004(int var1, int var2) {
      return var1 | var2;
   }

   public YJI method5040(int var1, int var2, int[][] var3, int[][] var4, int var5, int var6, int var7) {
      return new ZSI(this, var6, var7, var1, var2, var3, var4, var5);
   }

   public LF method5178() {
      WZ var1 = this.I((Runnable)Thread.currentThread());
      return var1.l;
   }

   public void method5132(LF var1) {
      this.currentThread = var1;
      this.RA();
   }

   public GE I(int var1, int var2, int var3, int var4, int var5, float var6) {
      return null;
   }

   public void method5021(int var1, GE[] var2) {
   }

   void B(int var1) {
      this.method5011[var1].I((Runnable)Thread.currentThread(), (byte)-84);
   }

   public boolean method5127() {
      return false;
   }

   WZ I(Runnable var1) {
      for(int var2 = 0; var2 < -922307687 * this.X; ++var2) {
         if (this.method5011[var2].Z == var1) {
            return this.method5011[var2];
         }
      }

      return null;
   }

   public void method5042(XBI var1) {
      this.G(this.I != null, this.C != null, false, var1);
   }

   void G(boolean var1, boolean var2, boolean var3, XBI var4) {
      WZ var5 = this.I((Runnable)Thread.currentThread());
      MN var6 = var4.I.Z;

      for(MN var7 = var6.B; var7 != var6; var7 = var7.B) {
         NN var8 = (NN)var7;
         int var9 = var8.D >> 12;
         int var10 = var8.A >> 12;
         int var11 = var8.E >> 12;
         float var12 = (float)var9 * this.O.I[2] + (float)var10 * this.O.I[6] + this.O.I[10] * (float)var11 + this.O.I[14];
         float var13 = this.O.I[15] + this.O.I[11] * (float)var11 + this.O.I[7] * (float)var10 + (float)var9 * this.O.I[3];
         if (var12 >= -var13) {
            float var14 = this.V * var12 / var13 + this.z;
            if (var12 <= var5.Y) {
               float var15 = this.O.I[12] + (float)var10 * this.O.I[4] + (float)var9 * this.O.I[0] + this.O.I[8] * (float)var11;
               float var16 = this.O.I[13] + (float)var11 * this.O.I[9] + (float)var10 * this.O.I[5] + this.O.I[1] * (float)var9;
               if (var15 >= -var13 && var15 <= var13 && var16 >= -var13 && var16 <= var13) {
                  float var17 = (float)var8.G / 4096.0F;
                  float var18 = var15 + this.N.I[0] * var17;
                  float var19 = var17 * this.N.I[3] + var13;
                  float var20 = this.c + var15 * this.R / var13;
                  float var21 = var16 * this.T / var13 + this.U;
                  float var22 = this.c + var18 * this.R / var19;
                  this.L(var1, var2, var3, var8, (int)var20, (int)var21, var14, (int)(var22 < var20 ? var20 - var22 : var22 - var20));
               }
            }
         }
      }

   }

   void L(boolean var1, boolean var2, boolean var3, NN var4, int var5, int var6, float var7, int var8) {
      int var9 = var4.L;
      int var10 = var8;
      var8 <<= 1;
      if (-1 == var9) {
         this.method5011(var2, var5, var6, var7, var10, var4.H, 1);
      } else {
         if (var9 != this.method621 * -815285507) {
            IBI var11 = (IBI)this.L.I((long)var9);
            if (var11 == null) {
               int[] var12 = this.I(var9);
               if (var12 == null) {
                  return;
               }

               int var13 = this.Z(var9) ? 64 : 1107560907 * this.i;
               var11 = this.I(var12, 0, var13, var13, var13, 105789167);
               this.L.I(var11, (long)var9);
            }

            this.method621 = 2116530773 * var9;
            this.method174 = var11;
         }

         ++var8;
         ((ZBI)this.method174).method678(var1, var2, var3, var5 - var10, var6 - var10, var7, var8, var8, 0, var4.H, 1, 1, false);
      }

   }

   void I(boolean var1, boolean var2, boolean var3, int var4, int var5, float var6, int var7, int var8, int var9, int var10, int var11, int var12) {
      if (var7 != 0 && var8 != 0) {
         if (var9 != 65535) {
            WCI var13 = this.LZ.method174(var9, 1695034515);
            if (!var13.B) {
               if (var9 != this.method621 * -815285507) {
                  IBI var14 = (IBI)this.L.I((long)var9);
                  if (var14 == null) {
                     int[] var15 = this.I(var9);
                     if (var15 == null) {
                        return;
                     }

                     int var16 = this.Z(var9) ? 64 : this.i * 1107560907;
                     var14 = this.I(var15, 0, var16, var16, var16, 2014032256);
                     this.L.I(var14, (long)var9);
                  }

                  this.method621 = var9 * 2116530773;
                  this.method174 = var14;
               }

               ((ZBI)this.method174).method678(var1, var2, var3, var4 - var7, var5 - var8, var6, var7 << 1, var8 << 1, var11, var10, var12, 1, -2138060883 * var13.F != 2);
               return;
            }
         }

         this.method5011(var2, var4, var5, var6, var7, var10, var12);
      }

   }

   int D(int var1) {
      return this.LZ.method174(var1, 2099649978).A & '\uffff';
   }

   void I(int var1, int var2, int[] var3, float[] var4) {
      this.Z = -1336293333 * var1;
      this.RA = var2 * -1138901201;
      this.I = var3;
      this.C = var4;

      for(int var5 = 0; var5 < this.X * -922307687; ++var5) {
         this.method5011[var5].I(-455629367);
      }

      this.L();
      this.method5011();
   }

   public void method5161(float var1, float var2, float var3, float[] var4) {
      float var5 = this.O.I[11] * var3 + var1 * this.O.I[3] + this.O.I[15] + var2 * this.O.I[7];
      float var6 = var3 * this.O.I[8] + this.O.I[12] + this.O.I[0] * var1 + var2 * this.O.I[4];
      float var7 = this.O.I[5] * var2 + this.O.I[1] * var1 + this.O.I[13] + this.O.I[9] * var3;
      float var8 = var1 * this.Y.I[2] + this.Y.I[14] + this.Y.I[6] * var2 + this.Y.I[10] * var3;
      var4[0] = var6 * this.R / var5 + this.c;
      var4[1] = this.U + this.T * var7 / var5;
      var4[2] = var8;
   }

   public void method5182(YF var1) {
      this.N.I(var1);
      this.RA();
   }

   public YF method5045() {
      return new YF(this.N);
   }

   public void IA(float var1) {
      this.M = -1954754855 * (int)(65535.0F * var1);
   }

   public int method5048() {
      return 0;
   }

   public void J(int var1) {
   }

   public LF method5008() {
      WZ var1 = this.I((Runnable)Thread.currentThread());
      return var1.l;
   }

   void RA() {
      this.Y.I(this.currentThread);
      this.O.I(this.Y);
      this.O.Z(this.N);
      this.O.C(this.P[0]);
      this.O.B(this.P[1]);
      this.O.Z(this.P[2]);
      this.O.H(this.P[3]);
      this.O.K(this.P[4]);
      this.O.S(this.P[5]);
      float var1 = this.N.B();
      float var2 = this.N.I[10] * (var1 - 255.0F) + this.N.I[14];
      float var3 = this.N.I[10] * var1 + this.N.I[14];
      float var4 = var3 - var2;

      for(int var5 = 0; var5 < -922307687 * this.X; ++var5) {
         WZ var6 = this.method5011[var5];
         var6.Y = var2;
         var6.B = var4;
      }

   }

   public void method5043(LF var1) {
      this.currentThread = var1;
      this.RA();
   }

   public int[] ev(int var1, int var2, int var3, int var4) {
      if (this.I == null) {
         throw new IllegalStateException("");
      } else {
         int[] var5 = new int[var3 * var4];
         int var6 = 0;

         for(int var7 = 0; var7 < var4; ++var7) {
            int var8 = var1 + this.Z * 692106883 * (var2 + var7);

            for(int var9 = 0; var9 < var3; ++var9) {
               var5[var6++] = this.I[var9 + var8];
            }
         }

         return var5;
      }
   }

   public void method5095(OBI var1) {
   }

   void S() {
      int var1 = -1416794725 * this.Q - this.D * -912871679;
      int var2 = this.J * 63686679 - -1278653805 * this.F;
      float var3 = this.R = (float)(-1840027081 * this.XA) / 2.0F;
      float var4 = this.T = (float)(this.G * 1936944123) / 2.0F;
      this.c = var3 + (float)(this.method170 * 1767406117);
      this.U = var4 + (float)(-457799237 * this.method172);

      int var5;
      for(var5 = 0; var5 < -922307687 * this.X; ++var5) {
         WZ var6 = this.method5011[var5];
         FD var7 = var6.K;
         var7.Z = var3;
         var7.G = var4;
         var7.S = this.c - (float)(-912871679 * this.D);
         var7.E = this.U - (float)(-1278653805 * this.F);
         var7.J = var1;
         var7.V = var2;
      }

      var5 = -1278653805 * this.F * this.Z * 692106883 + -912871679 * this.D;

      for(int var8 = this.F * -1278653805; var8 < 63686679 * this.J; ++var8) {
         for(int var9 = 0; var9 < -922307687 * this.X; ++var9) {
            this.method5011[var9].K.f[var8 - this.F * -1278653805] = var5;
         }

         var5 += 692106883 * this.Z;
      }

   }

   public void method5053() {
   }

   public boolean method5054() {
      return false;
   }

   public void method5022(int var1, int var2, int var3, int var4, int var5, int var6, QJI var7, int var8, int var9) {
      if (this.I != null) {
         TJI var10 = (TJI)var7;
         int[] var11 = var10.Z;
         int[] var12 = var10.I;
         int var13 = this.F * -1278653805 > var9 ? this.F * -1278653805 : var9;
         int var14 = 63686679 * this.J < var9 + var11.length ? 63686679 * this.J : var9 + var11.length;
         var3 -= var1;
         var4 -= var2;
         if (var3 + var4 < 0) {
            var1 += var3;
            var3 = -var3;
            var2 += var4;
            var4 = -var4;
         }

         int var15;
         int var16;
         int var17;
         int var18;
         int var19;
         int var20;
         int var21;
         int var22;
         int var23;
         if (var3 > var4) {
            var2 <<= 16;
            var2 += 32768;
            var4 <<= 16;
            var15 = (int)Math.floor(0.5D + (double)var4 / (double)var3);
            var3 += var1;
            if (var1 < this.D * -912871679) {
               var2 += (-912871679 * this.D - var1) * var15;
               var1 = -912871679 * this.D;
            }

            if (var3 >= -1416794725 * this.Q) {
               var3 = -1416794725 * this.Q - 1;
            }

            var16 = var5 >>> 24;
            if (var6 == 0 || var6 == 1 && 255 == var16) {
               while(var1 <= var3) {
                  var17 = var2 >> 16;
                  var18 = var17 - var9;
                  if (var17 >= var13 && var17 < var14) {
                     var19 = var11[var18] + var8;
                     if (var1 >= var19 && var1 < var12[var18] + var19) {
                        this.I[this.Z * 692106883 * var17 + var1] = var5;
                     }
                  }

                  var2 += var15;
                  ++var1;
               }
            } else if (1 == var6) {
               var5 = (var16 << 24) + (var16 * (var5 & 16711935) >> 8 & 16711935) + ((var5 & '\uff00') * var16 >> 8 & '\uff00');

               for(var17 = 256 - var16; var1 <= var3; ++var1) {
                  var18 = var2 >> 16;
                  var19 = var18 - var9;
                  if (var18 >= var13 && var18 < var14) {
                     var20 = var11[var19] + var8;
                     if (var1 >= var20 && var1 < var12[var19] + var20) {
                        var21 = var1 + this.Z * 692106883 * var18;
                        var22 = this.I[var21];
                        var22 = ((var22 & '\uff00') * var17 >> 8 & '\uff00') + (var17 * (var22 & 16711935) >> 8 & 16711935);
                        this.I[var21] = var22 + var5;
                     }
                  }

                  var2 += var15;
               }
            } else {
               if (2 != var6) {
                  throw new IllegalArgumentException();
               }

               while(var1 <= var3) {
                  var17 = var2 >> 16;
                  var18 = var17 - var9;
                  if (var17 >= var13 && var17 < var14) {
                     var19 = var11[var18] + var8;
                     if (var1 >= var19 && var1 < var19 + var12[var18]) {
                        var20 = var1 + var17 * this.Z * 692106883;
                        var21 = this.I[var20];
                        var22 = var5 + var21;
                        var23 = (var5 & 16711935) + (var21 & 16711935);
                        var21 = (var23 & 16777472) + (var22 - var23 & 65536);
                        this.I[var20] = var22 - var21 | var21 - (var21 >>> 8);
                     }
                  }

                  var2 += var15;
                  ++var1;
               }
            }
         } else {
            var1 <<= 16;
            var1 += 32768;
            var3 <<= 16;
            var15 = (int)Math.floor((double)var3 / (double)var4 + 0.5D);
            var4 += var2;
            if (var2 < var13) {
               var1 += (var13 - var2) * var15;
               var2 = var13;
            }

            if (var4 >= var14) {
               var4 = var14 - 1;
            }

            var16 = var5 >>> 24;
            if (var6 == 0 || 1 == var6 && var16 == 255) {
               while(var2 <= var4) {
                  var17 = var1 >> 16;
                  var18 = var2 - var9;
                  var19 = var11[var18] + var8;
                  if (var17 >= this.D * -912871679 && var17 < -1416794725 * this.Q && var17 >= var19 && var17 < var12[var18] + var19) {
                     this.I[692106883 * this.Z * var2 + var17] = var5;
                  }

                  var1 += var15;
                  ++var2;
               }
            } else if (var6 == 1) {
               var5 = (var16 * (var5 & 16711935) >> 8 & 16711935) + (var16 * (var5 & '\uff00') >> 8 & '\uff00') + (var16 << 24);

               for(var17 = 256 - var16; var2 <= var4; ++var2) {
                  var18 = var1 >> 16;
                  var19 = var2 - var9;
                  var20 = var8 + var11[var19];
                  if (var18 >= -912871679 * this.D && var18 < -1416794725 * this.Q && var18 >= var20 && var18 < var12[var19] + var20) {
                     var21 = 692106883 * this.Z * var2 + var18;
                     var22 = this.I[var21];
                     var22 = ((var22 & '\uff00') * var17 >> 8 & '\uff00') + (var17 * (var22 & 16711935) >> 8 & 16711935);
                     this.I[var2 * 692106883 * this.Z + var18] = var22 + var5;
                  }

                  var1 += var15;
               }
            } else {
               if (var6 != 2) {
                  throw new IllegalArgumentException();
               }

               while(var2 <= var4) {
                  var17 = var1 >> 16;
                  var18 = var2 - var9;
                  var19 = var8 + var11[var18];
                  if (var17 >= -912871679 * this.D && var17 < -1416794725 * this.Q && var17 >= var19 && var17 < var19 + var12[var18]) {
                     var20 = this.Z * 692106883 * var2 + var17;
                     var21 = this.I[var20];
                     var22 = var21 + var5;
                     var23 = (var5 & 16711935) + (var21 & 16711935);
                     var21 = (var22 - var23 & 65536) + (var23 & 16777472);
                     this.I[var20] = var22 - var21 | var21 - (var21 >>> 8);
                  }

                  var1 += var15;
                  ++var2;
               }
            }
         }
      }

   }

   public void method5047(boolean var1) {
      this.method581 = var1;
      this.S.I();
   }

   public YF method5036() {
      WZ var1 = this.I((Runnable)Thread.currentThread());
      return var1.G;
   }

   public OBI method5179(OBI var1, OBI var2, float var3, OBI var4) {
      return null;
   }

   public void O() {
      for(int var1 = 0; var1 < this.method5011.length; ++var1) {
         this.method5011[var1].D = 950886337 * this.method5011[var1].F;
         this.method5011[var1].J = false;
      }

   }

   public void method5020(int var1, int var2, float var3, int var4, int var5, float var6, int var7, int var8, float var9, int var10, int var11, int var12, int var13) {
      boolean var14 = this.I != null;
      boolean var15 = this.C != null;
      if (var14 || var15) {
         WZ var16 = this.I((Runnable)Thread.currentThread());
         FD var17 = var16.K;
         var17.I = false;
         var1 -= -912871679 * this.D;
         var4 -= -912871679 * this.D;
         var7 -= -912871679 * this.D;
         var2 -= this.F * -1278653805;
         var5 -= this.F * -1278653805;
         var8 -= this.F * -1278653805;
         var17.D = var1 < 0 || var1 > var17.J || var4 < 0 || var4 > var17.J || var7 < 0 || var7 > var17.J;
         int var18 = var10 >>> 24;
         if (var13 == 0 || var13 == 1 && 255 == var18) {
            var17.B = 0;
            var17.j = false;
            var17.I(var14, var15, false, (float)var2, (float)var5, (float)var8, (float)var1, (float)var4, (float)var7, var3, var6, var9, var10, var11, var12);
         } else if (1 == var13) {
            var17.B = 255 - var18;
            var17.j = false;
            var17.I(var14, var15, false, (float)var2, (float)var5, (float)var8, (float)var1, (float)var4, (float)var7, var3, var6, var9, var10, var11, var12);
         } else {
            if (2 != var13) {
               throw new IllegalArgumentException();
            }

            var17.B = 128;
            var17.j = true;
            var17.I(var14, var15, false, (float)var2, (float)var5, (float)var8, (float)var1, (float)var4, (float)var7, var3, var6, var9, var10, var11, var12);
         }

         var17.I = true;
      }

   }

   public void method5060(float var1, float var2, float var3, float[] var4) {
      float var5 = this.O.I[11] * var3 + var1 * this.O.I[3] + this.O.I[15] + var2 * this.O.I[7];
      float var6 = var3 * this.O.I[8] + this.O.I[12] + this.O.I[0] * var1 + var2 * this.O.I[4];
      float var7 = this.O.I[5] * var2 + this.O.I[1] * var1 + this.O.I[13] + this.O.I[9] * var3;
      float var8 = var1 * this.Y.I[2] + this.Y.I[14] + this.Y.I[6] * var2 + this.Y.I[10] * var3;
      var4[0] = var6 * this.R / var5 + this.c;
      var4[1] = this.U + this.T * var7 / var5;
      var4[2] = var8;
   }

   public void method5059(float var1, float var2, float var3, float[] var4) {
      float var5 = var3 * this.O.I[10] + this.O.I[2] * var1 + this.O.I[14] + this.O.I[6] * var2;
      float var6 = var3 * this.O.I[11] + this.O.I[15] + this.O.I[3] * var1 + var2 * this.O.I[7];
      if (var5 >= -var6 && var5 <= var6) {
         float var7 = this.O.I[12] + var1 * this.O.I[0] + var2 * this.O.I[4] + var3 * this.O.I[8];
         if (var7 >= -var6 && var7 <= var6) {
            float var8 = this.O.I[5] * var2 + this.O.I[13] + var1 * this.O.I[1] + this.O.I[9] * var3;
            if (var8 >= -var6 && var8 <= var6) {
               float var9 = this.Y.I[10] * var3 + var1 * this.Y.I[2] + this.Y.I[14] + this.Y.I[6] * var2;
               var4[0] = this.c + var7 * this.R / var6;
               var4[1] = this.T * var8 / var6 + this.U;
               var4[2] = var9;
            } else {
               var4[2] = Float.NaN;
               var4[1] = Float.NaN;
               var4[0] = Float.NaN;
            }
         } else {
            var4[2] = Float.NaN;
            var4[1] = Float.NaN;
            var4[0] = Float.NaN;
         }
      } else {
         var4[2] = Float.NaN;
         var4[1] = Float.NaN;
         var4[0] = Float.NaN;
      }

   }

   public void method5058(int var1, ADI var2) {
      WZ var3 = this.I((Runnable)Thread.currentThread());
      var3.O = 1450505545 * var1;
      var3.D = -1634857629 * var2.Z;
      var3.e = -296597081 * var2.I;
   }

   public void method5139(int var1, int var2, float var3, int var4, int var5, float var6, int var7, int var8, float var9, int var10, int var11, int var12, int var13) {
      boolean var14 = this.I != null;
      boolean var15 = this.C != null;
      if (var14 || var15) {
         WZ var16 = this.I((Runnable)Thread.currentThread());
         FD var17 = var16.K;
         var17.I = false;
         var1 -= -912871679 * this.D;
         var4 -= -912871679 * this.D;
         var7 -= -912871679 * this.D;
         var2 -= this.F * -1278653805;
         var5 -= this.F * -1278653805;
         var8 -= this.F * -1278653805;
         var17.D = var1 < 0 || var1 > var17.J || var4 < 0 || var4 > var17.J || var7 < 0 || var7 > var17.J;
         int var18 = var10 >>> 24;
         if (var13 == 0 || var13 == 1 && 255 == var18) {
            var17.B = 0;
            var17.j = false;
            var17.I(var14, var15, false, (float)var2, (float)var5, (float)var8, (float)var1, (float)var4, (float)var7, var3, var6, var9, var10, var11, var12);
         } else if (1 == var13) {
            var17.B = 255 - var18;
            var17.j = false;
            var17.I(var14, var15, false, (float)var2, (float)var5, (float)var8, (float)var1, (float)var4, (float)var7, var3, var6, var9, var10, var11, var12);
         } else {
            if (2 != var13) {
               throw new IllegalArgumentException();
            }

            var17.B = 128;
            var17.j = true;
            var17.I(var14, var15, false, (float)var2, (float)var5, (float)var8, (float)var1, (float)var4, (float)var7, var3, var6, var9, var10, var11, var12);
         }

         var17.I = true;
      }

   }

   public SBI method5062() {
      return new SBI(0, "Pure Java", 1, "CPU", 0L);
   }

   public SBI method5063() {
      return new SBI(0, "Pure Java", 1, "CPU", 0L);
   }

   void method5064(int var1, int var2) throws Exception_Sub1 {
      this.MZ.method581(var1, var2);
      if (this.LZ != null) {
         this.LZ.method176(1621358608);
      }

   }

   void method5065(int var1, int var2) throws Exception_Sub1 {
      this.MZ.method581(var1, var2);
      if (this.LZ != null) {
         this.LZ.method176(557326992);
      }

   }

   void XA(int var1) {
      this.X = var1 * 877981865;
      this.method5011 = new WZ[-922307687 * this.X];

      for(int var2 = 0; var2 < this.X * -922307687; ++var2) {
         this.method5011[var2] = new WZ(this);
      }

   }

   public void method5067() {
   }

   void method5009() {
      if (this.method176) {
         JF.I(true, false, (short)20421);
         this.method176 = false;
      }

      this.floor = true;
   }

   void method5141() {
      if (this.method176) {
         JF.I(true, false, (short)-10994);
         this.method176 = false;
      }

      this.floor = true;
   }

   void method5068() {
      if (this.method176) {
         JF.I(true, false, (short)17485);
         this.method176 = false;
      }

      this.floor = true;
   }

   void method5069() {
      if (this.method176) {
         JF.I(true, false, (short)2760);
         this.method176 = false;
      }

      this.floor = true;
   }

   public void method5174(int var1) {
      int var2 = var1 - -1633713343 * this.B;

      for(QL var3 = (QL)this.S.Z(2090581524); var3 != null; var3 = (QL)this.S.C(-1973419432)) {
         if (var3.A) {
            var3.S += var2;
            int var4 = var3.S / 50;
            if (var4 > 0) {
               WCI var5 = this.LZ.method174(var3.E, 2122690510);
               float var6 = var5.Z ? 64.0F : 128.0F;
               var3.Z((int)((float)var2 / 1000.0F * (float)var5.H / 64.0F * var6), (int)(var6 * ((float)var5.I * ((float)var2 / 1000.0F) / 64.0F)));
               var3.S -= 50 * var4;
            }

            var3.A = false;
         }
      }

      this.B = -1260974911 * var1;
      this.L.I(5, -574753301);
      this.S.I(5, -271424616);
   }

   public int dm() {
      return 0;
   }

   public void eh(int var1, int var2, int var3, int var4) {
      if (-912871679 * this.D < var1) {
         this.D = var1 * -1291169535;
      }

      if (this.F * -1278653805 < var2) {
         this.F = var2 * 104031131;
      }

      if (this.Q * -1416794725 > var3) {
         this.Q = var3 * -1912131437;
      }

      if (63686679 * this.J > var4) {
         this.J = var4 * 1656090535;
      }

      this.S();
   }

   public void method5130(LF var1) {
      this.currentThread = var1;
      this.RA();
   }

   public void ba(int var1, int var2) {
      if ((var1 & 1) != 0) {
         this.B(0, 0, 692106883 * this.Z, this.RA * 918677455, var2, 0);
      }

      if ((var1 & 2) != 0) {
         this.Z();
      }

   }

   public void method5010(int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      if (this.I != null) {
         WZ var8 = this.I((Runnable)Thread.currentThread());
         FD var9 = var8.K;
         int var10 = var3 - var1;
         int var11 = var4 - var2;
         int var12 = var10 >= 0 ? var10 : -var10;
         int var13 = var11 >= 0 ? var11 : -var11;
         int var14 = var12;
         if (var12 < var13) {
            var14 = var13;
         }

         if (var14 != 0) {
            int var15 = (var10 << 16) / var14;
            int var16 = (var11 << 16) / var14;
            var10 += var15 >> 16;
            var11 += var16 >> 16;
            if (var16 <= var15) {
               var15 = -var15;
            } else {
               var16 = -var16;
            }

            int var17 = var16 * var6 >> 17;
            int var18 = var16 * var6 + 1 >> 17;
            int var19 = var15 * var6 >> 17;
            int var20 = 1 + var6 * var15 >> 17;
            var1 -= var9.I();
            var2 -= var9.Z();
            int var21 = var17 + var1;
            int var22 = var1 - var18;
            int var23 = var1 + var10 - var18;
            int var24 = var17 + var1 + var10;
            int var25 = var2 + var19;
            int var26 = var2 - var20;
            int var27 = var11 + var2 - var20;
            int var28 = var2 + var11 + var19;
            if (var7 == 0) {
               var9.B = 0;
            } else {
               if (var7 != 1) {
                  throw new IllegalArgumentException();
               }

               var9.B = 255 - (var5 >>> 24);
            }

            this.RA(false);
            var9.D = var21 < 0 || var21 > var9.J || var22 < 0 || var22 > var9.J || var23 < 0 || var23 > var9.J;
            var9.I(true, false, false, (float)var25, (float)var26, (float)var27, (float)var21, (float)var22, (float)var23, 100.0F, 100.0F, 100.0F, var5);
            var9.D = var21 < 0 || var21 > var9.J || var23 < 0 || var23 > var9.J || var24 < 0 || var24 > var9.J;
            var9.I(true, false, false, (float)var25, (float)var27, (float)var28, (float)var21, (float)var23, (float)var24, 100.0F, 100.0F, 100.0F, var5);
            this.RA(true);
         }
      }

   }

   public GE currentThread(int var1, int var2, int var3, int var4, int var5, float var6) {
      return null;
   }

   public void fn(int var1, int var2) {
      if ((var1 & 1) != 0) {
         this.B(0, 0, 692106883 * this.Z, this.RA * 918677455, var2, 0);
      }

      if ((var1 & 2) != 0) {
         this.Z();
      }

   }

   public void method5157(int var1, int var2, float var3, int var4, int var5, float var6, int var7, int var8, float var9, int var10, int var11, int var12, int var13) {
      boolean var14 = this.I != null;
      boolean var15 = this.C != null;
      if (var14 || var15) {
         WZ var16 = this.I((Runnable)Thread.currentThread());
         FD var17 = var16.K;
         var17.I = false;
         var1 -= -912871679 * this.D;
         var4 -= -912871679 * this.D;
         var7 -= -912871679 * this.D;
         var2 -= this.F * -1278653805;
         var5 -= this.F * -1278653805;
         var8 -= this.F * -1278653805;
         var17.D = var1 < 0 || var1 > var17.J || var4 < 0 || var4 > var17.J || var7 < 0 || var7 > var17.J;
         int var18 = var10 >>> 24;
         if (var13 == 0 || var13 == 1 && 255 == var18) {
            var17.B = 0;
            var17.j = false;
            var17.I(var14, var15, false, (float)var2, (float)var5, (float)var8, (float)var1, (float)var4, (float)var7, var3, var6, var9, var10, var11, var12);
         } else if (1 == var13) {
            var17.B = 255 - var18;
            var17.j = false;
            var17.I(var14, var15, false, (float)var2, (float)var5, (float)var8, (float)var1, (float)var4, (float)var7, var3, var6, var9, var10, var11, var12);
         } else {
            if (2 != var13) {
               throw new IllegalArgumentException();
            }

            var17.B = 128;
            var17.j = true;
            var17.I(var14, var15, false, (float)var2, (float)var5, (float)var8, (float)var1, (float)var4, (float)var7, var3, var6, var9, var10, var11, var12);
         }

         var17.I = true;
      }

   }

   public boolean method5072() {
      return false;
   }

   public boolean method5070() {
      return false;
   }

   public boolean method5071() {
      return false;
   }

   public void method5160(float var1, float var2, float var3, float[] var4) {
      float var5 = this.O.I[11] * var3 + var1 * this.O.I[3] + this.O.I[15] + var2 * this.O.I[7];
      float var6 = var3 * this.O.I[8] + this.O.I[12] + this.O.I[0] * var1 + var2 * this.O.I[4];
      float var7 = this.O.I[5] * var2 + this.O.I[1] * var1 + this.O.I[13] + this.O.I[9] * var3;
      float var8 = var1 * this.Y.I[2] + this.Y.I[14] + this.Y.I[6] * var2 + this.Y.I[10] * var3;
      var4[0] = var6 * this.R / var5 + this.c;
      var4[1] = this.U + this.T * var7 / var5;
      var4[2] = var8;
   }

   public boolean method5073() {
      return true;
   }

   void method5188(float var1, float var2, float var3, float var4, float var5, float var6) {
   }

   public void qa(int[] var1) {
      var1[0] = -912871679 * this.D;
      var1[1] = this.F * -1278653805;
      var1[2] = -1416794725 * this.Q;
      var1[3] = this.J * 63686679;
   }

   public boolean method5111() {
      return false;
   }

   public boolean method5076() {
      return false;
   }

   boolean F(int var1) {
      return this.LZ.method174(var1, 212515321).N || this.LZ.method174(var1, 1397930760).O;
   }

   public boolean method5078() {
      return false;
   }

   public boolean method5079() {
      return false;
   }

   public boolean method4994() {
      return false;
   }

   public OS method5092(LZI var1, RFI[] var2, boolean var3) {
      int[] var4 = new int[var2.length];
      int[] var5 = new int[var2.length];
      boolean var6 = false;

      for(int var7 = 0; var7 < var2.length; ++var7) {
         var4[var7] = var2[var7].Z;
         var5[var7] = var2[var7].F;
         if (var2[var7].A != null) {
            var6 = true;
         }
      }

      if (var3) {
         if (var6) {
            return new QS(this, var1, var2, var4, var5);
         } else {
            return new TS(this, var1, var2, var4, var5);
         }
      } else if (var6) {
         throw new IllegalArgumentException("");
      } else {
         return new PS(this, var1, var2, var4, var5);
      }
   }

   public void method5012(boolean var1) {
   }

   public void method5085(boolean var1) {
   }

   OCI method5117(Canvas var1, int var2, int var3) {
      return JEI.I(this, var1, var2, var3, -1693880696);
   }

   public int[] aq(int var1, int var2, int var3, int var4) {
      if (this.I == null) {
         throw new IllegalStateException("");
      } else {
         int[] var5 = new int[var3 * var4];
         int var6 = 0;

         for(int var7 = 0; var7 < var4; ++var7) {
            int var8 = var1 + this.Z * 692106883 * (var2 + var7);

            for(int var9 = 0; var9 < var3; ++var9) {
               var5[var6++] = this.I[var9 + var8];
            }
         }

         return var5;
      }
   }

   public int[] eg(int var1, int var2, int var3, int var4) {
      if (this.I == null) {
         throw new IllegalStateException("");
      } else {
         int[] var5 = new int[var3 * var4];
         int var6 = 0;

         for(int var7 = 0; var7 < var4; ++var7) {
            int var8 = var1 + this.Z * 692106883 * (var2 + var7);

            for(int var9 = 0; var9 < var3; ++var9) {
               var5[var6++] = this.I[var9 + var8];
            }
         }

         return var5;
      }
   }

   public void method5080() {
   }

   public void el(float var1, float var2) {
      this.V = var2 - var1;
      this.z = var2 + var1 - 1.0F;

      for(int var3 = 0; var3 < this.X * -922307687; ++var3) {
         WZ var4 = this.method5011[var3];
         FD var5 = var4.K;
         var5.d = this.V;
         var5.H = this.z;
      }

   }

   public GE floor(int var1, int var2, int var3, int var4, int var5, float var6) {
      return null;
   }

   public void ec(boolean var1) {
      WZ var2 = this.I((Runnable)Thread.currentThread());
      var2.z = var1;
   }

   public void method5086() {
      this.method170 = 0;
      this.method172 = 0;
      this.XA = 845086741 * this.Z;
      this.G = -1768491203 * this.RA;
      this.S();
   }

   public void gv(int var1, QJI var2, int var3, int var4) {
      if (this.I != null) {
         TJI var5 = (TJI)var2;
         int[] var6 = var5.Z;
         int[] var7 = var5.I;
         int var8;
         if (63686679 * this.J < var6.length + var4) {
            var8 = this.J * 63686679 - var4;
         } else {
            var8 = var6.length;
         }

         int var9;
         if (this.F * -1278653805 > var4) {
            var9 = this.F * -1278653805 - var4;
            var4 = this.F * -1278653805;
         } else {
            var9 = 0;
         }

         if (var8 - var9 > 0) {
            int var10 = 692106883 * this.Z * var4;

            for(int var11 = var9; var11 < var8; ++var11) {
               int var12 = var3 + var6[var11];
               int var13 = var7[var11];
               if (this.D * -912871679 > var12) {
                  var13 -= -912871679 * this.D - var12;
                  var12 = -912871679 * this.D;
               }

               if (-1416794725 * this.Q < var12 + var13) {
                  var13 = -1416794725 * this.Q - var12;
               }

               var12 += var10;

               for(int var14 = -var13; var14 < 0; ++var14) {
                  this.I[var12++] = var1;
               }

               var10 += this.Z * 692106883;
            }
         }
      }

   }

   public void ez(float var1, float var2) {
      this.V = var2 - var1;
      this.z = var2 + var1 - 1.0F;

      for(int var3 = 0; var3 < this.X * -922307687; ++var3) {
         WZ var4 = this.method5011[var3];
         FD var5 = var4.K;
         var5.d = this.V;
         var5.H = this.z;
      }

   }

   public void fi(int var1, int var2, int var3, int var4, int var5, int var6, byte[] var7, int var8, int var9) {
      if (this.I != null && var3 > 0 && var4 > 0) {
         int var10 = 0;
         int var11 = 0;
         int var12 = (var8 << 16) / var3;
         int var13 = (var7.length / var8 << 16) / var4;
         int var14 = var1 + var2 * 692106883 * this.Z;
         int var15 = 692106883 * this.Z - var3;
         if (var4 + var2 > this.J * 63686679) {
            var4 -= var2 + var4 - 63686679 * this.J;
         }

         int var16;
         if (var2 < this.F * -1278653805) {
            var16 = -1278653805 * this.F - var2;
            var4 -= var16;
            var14 += var16 * this.Z * 692106883;
            var11 += var16 * var13;
         }

         if (var1 + var3 > -1416794725 * this.Q) {
            var16 = var1 + var3 - this.Q * -1416794725;
            var3 -= var16;
            var15 += var16;
         }

         if (var1 < this.D * -912871679) {
            var16 = -912871679 * this.D - var1;
            var3 -= var16;
            var14 += var16;
            var10 += var12 * var16;
            var15 += var16;
         }

         var16 = var5 >>> 24;
         int var17 = var6 >>> 24;
         int var18;
         int var19;
         int var20;
         int var21;
         if (var9 != 0 && (1 != var9 || var16 != 255 || var17 != 255)) {
            int var22;
            int var23;
            int var24;
            int var25;
            if (1 == var9) {
               var18 = var10;

               for(var19 = -var4; var19 < 0; ++var19) {
                  var20 = (var11 >> 16) * var8;

                  for(var21 = -var3; var21 < 0; ++var21) {
                     var22 = var5;
                     if (var7[(var10 >> 16) + var20] != 0) {
                        var22 = var6;
                     }

                     var23 = var22 >>> 24;
                     var24 = 255 - var23;
                     var25 = this.I[var14];
                     this.I[var14++] = (var23 * (var22 & '\uff00') + (var25 & '\uff00') * var24 & 16711680) + ((var25 & 16711935) * var24 + (var22 & 16711935) * var23 & -16711936) >> 8;
                     var10 += var12;
                  }

                  var11 += var13;
                  var10 = var18;
                  var14 += var15;
               }
            } else {
               if (var9 != 2) {
                  throw new IllegalArgumentException();
               }

               var18 = var10;

               for(var19 = -var4; var19 < 0; ++var19) {
                  var20 = var8 * (var11 >> 16);

                  for(var21 = -var3; var21 < 0; ++var21) {
                     var22 = var5;
                     if (var7[(var10 >> 16) + var20] != 0) {
                        var22 = var6;
                     }

                     if (var22 != 0) {
                        var23 = this.I[var14];
                        var24 = var23 + var22;
                        var25 = (var23 & 16711935) + (var22 & 16711935);
                        var23 = (var25 & 16777472) + (var24 - var25 & 65536);
                        this.I[var14++] = var24 - var23 | var23 - (var23 >>> 8);
                     } else {
                        ++var14;
                     }

                     var10 += var12;
                  }

                  var11 += var13;
                  var10 = var18;
                  var14 += var15;
               }
            }
         } else {
            var18 = var10;

            for(var19 = -var4; var19 < 0; ++var19) {
               var20 = (var11 >> 16) * var8;

               for(var21 = -var3; var21 < 0; ++var21) {
                  if (var7[(var10 >> 16) + var20] != 0) {
                     this.I[var14++] = var6;
                  } else {
                     this.I[var14++] = var5;
                  }

                  var10 += var12;
               }

               var11 += var13;
               var10 = var18;
               var14 += var15;
            }
         }
      }

   }

   public boolean method5180() {
      return true;
   }

   public void method5055(float var1, float var2, float var3, float[] var4) {
      float var5 = var3 * this.O.I[10] + this.O.I[2] * var1 + this.O.I[14] + this.O.I[6] * var2;
      float var6 = var3 * this.O.I[11] + this.O.I[15] + this.O.I[3] * var1 + var2 * this.O.I[7];
      if (var5 >= -var6 && var5 <= var6) {
         float var7 = this.O.I[12] + var1 * this.O.I[0] + var2 * this.O.I[4] + var3 * this.O.I[8];
         if (var7 >= -var6 && var7 <= var6) {
            float var8 = this.O.I[5] * var2 + this.O.I[13] + var1 * this.O.I[1] + this.O.I[9] * var3;
            if (var8 >= -var6 && var8 <= var6) {
               float var9 = this.Y.I[10] * var3 + var1 * this.Y.I[2] + this.Y.I[14] + this.Y.I[6] * var2;
               var4[0] = this.c + var7 * this.R / var6;
               var4[1] = this.T * var8 / var6 + this.U;
               var4[2] = var9;
            } else {
               var4[2] = Float.NaN;
               var4[1] = Float.NaN;
               var4[0] = Float.NaN;
            }
         } else {
            var4[2] = Float.NaN;
            var4[1] = Float.NaN;
            var4[0] = Float.NaN;
         }
      } else {
         var4[2] = Float.NaN;
         var4[1] = Float.NaN;
         var4[0] = Float.NaN;
      }

   }

   public void eq() {
      this.D = 0;
      this.F = 0;
      this.Q = 2046188857 * this.Z;
      this.J = -482117367 * this.RA;
      this.S();
   }

   public void ep() {
      this.D = 0;
      this.F = 0;
      this.Q = 2046188857 * this.Z;
      this.J = -482117367 * this.RA;
      this.S();
   }

   public void method5176() {
   }

   public void ej(int var1, int var2, int var3, int var4) {
      if (var1 < 0) {
         var1 = 0;
      }

      if (var2 < 0) {
         var2 = 0;
      }

      if (var3 > 692106883 * this.Z) {
         var3 = 692106883 * this.Z;
      }

      if (var4 > this.RA * 918677455) {
         var4 = 918677455 * this.RA;
      }

      this.D = var1 * -1291169535;
      this.Q = var3 * -1912131437;
      this.F = var2 * 104031131;
      this.J = 1656090535 * var4;
      this.S();
   }

   public void ed(int var1, int var2, int var3, int var4) {
      if (var1 < 0) {
         var1 = 0;
      }

      if (var2 < 0) {
         var2 = 0;
      }

      if (var3 > 692106883 * this.Z) {
         var3 = 692106883 * this.Z;
      }

      if (var4 > this.RA * 918677455) {
         var4 = 918677455 * this.RA;
      }

      this.D = var1 * -1291169535;
      this.Q = var3 * -1912131437;
      this.F = var2 * 104031131;
      this.J = 1656090535 * var4;
      this.S();
   }

   public YJI method5122(int var1, int var2, int[][] var3, int[][] var4, int var5, int var6, int var7) {
      return new ZSI(this, var6, var7, var1, var2, var3, var4, var5);
   }

   public void method5057(int var1, ADI var2) {
      for(int var3 = 0; var3 < this.method5011.length; ++var3) {
         this.method5011[var3].F = 329691201 * this.method5011[var3].D;
         this.method5011[var3].O = 1450505545 * var1;
         this.method5011[var3].D = var2.Z * -1634857629;
         this.method5011[var3].e = var2.I * -296597081;
         this.method5011[var3].J = true;
      }

   }

   public void eo(int[] var1) {
      var1[0] = -912871679 * this.D;
      var1[1] = this.F * -1278653805;
      var1[2] = -1416794725 * this.Q;
      var1[3] = this.J * 63686679;
   }

   public void method5075() {
   }

   public boolean method5149() {
      return false;
   }

   public void fb(int var1, int var2) {
      if ((var1 & 1) != 0) {
         this.B(0, 0, 692106883 * this.Z, this.RA * 918677455, var2, 0);
      }

      if ((var1 & 2) != 0) {
         this.Z();
      }

   }

   public void fh(int var1, int var2) {
      if ((var1 & 1) != 0) {
         this.B(0, 0, 692106883 * this.Z, this.RA * 918677455, var2, 0);
      }

      if ((var1 & 2) != 0) {
         this.Z();
      }

   }

   public void method5056(int var1, int var2, int var3, int var4) {
   }

   public void fa(int var1, int var2, int var3, int var4, int var5, int var6) {
      if (this.I != null) {
         if (var1 < this.D * -912871679) {
            var3 -= -912871679 * this.D - var1;
            var1 = this.D * -912871679;
         }

         if (var2 < -1278653805 * this.F) {
            var4 -= -1278653805 * this.F - var2;
            var2 = -1278653805 * this.F;
         }

         if (var1 + var3 > this.Q * -1416794725) {
            var3 = -1416794725 * this.Q - var1;
         }

         if (var4 + var2 > 63686679 * this.J) {
            var4 = 63686679 * this.J - var2;
         }

         if (var3 > 0 && var4 > 0 && var1 <= this.Q * -1416794725 && var2 <= this.J * 63686679) {
            int var7 = this.Z * 692106883 - var3;
            int var8 = var2 * this.Z * 692106883 + var1;
            int var9 = var5 >>> 24;
            int var10;
            int var11;
            int var12;
            if (var6 == 0 || var6 == 1 && 255 == var9) {
               var10 = var3 >> 3;
               var11 = var3 & 7;
               var3 = var8 - 1;

               for(var12 = -var4; var12 < 0; ++var12) {
                  if (var10 > 0) {
                     var1 = var10;

                     do {
                        ++var3;
                        this.I[var3] = var5;
                        ++var3;
                        this.I[var3] = var5;
                        ++var3;
                        this.I[var3] = var5;
                        ++var3;
                        this.I[var3] = var5;
                        ++var3;
                        this.I[var3] = var5;
                        ++var3;
                        this.I[var3] = var5;
                        ++var3;
                        this.I[var3] = var5;
                        ++var3;
                        this.I[var3] = var5;
                        --var1;
                     } while(var1 > 0);
                  }

                  if (var11 > 0) {
                     var1 = var11;

                     do {
                        ++var3;
                        this.I[var3] = var5;
                        --var1;
                     } while(var1 > 0);
                  }

                  var3 += var7;
               }
            } else {
               int var13;
               if (1 == var6) {
                  var5 = (var9 * (var5 & 16711935) >> 8 & 16711935) + (var9 * ((var5 & -16711936) >>> 8) & -16711936);
                  var10 = 256 - var9;

                  for(var11 = 0; var11 < var4; ++var11) {
                     for(var12 = -var3; var12 < 0; ++var12) {
                        var13 = this.I[var8];
                        var13 = ((var13 & 16711935) * var10 >> 8 & 16711935) + (var10 * ((var13 & -16711936) >>> 8) & -16711936);
                        this.I[var8++] = var13 + var5;
                     }

                     var8 += var7;
                  }
               } else {
                  if (var6 != 2) {
                     throw new IllegalArgumentException();
                  }

                  for(var10 = 0; var10 < var4; ++var10) {
                     for(var11 = -var3; var11 < 0; ++var11) {
                        var12 = this.I[var8];
                        var13 = var5 + var12;
                        int var14 = (var5 & 16711935) + (var12 & 16711935);
                        var12 = (var13 - var14 & 65536) + (var14 & 16777472);
                        this.I[var8++] = var13 - var12 | var12 - (var12 >>> 8);
                     }

                     var8 += var7;
                  }
               }
            }
         }
      }

   }

   public void fo(int var1, int var2, int var3, int var4, int var5, int var6, byte[] var7, int var8, int var9) {
      if (this.I != null && var3 > 0 && var4 > 0) {
         int var10 = 0;
         int var11 = 0;
         int var12 = (var8 << 16) / var3;
         int var13 = (var7.length / var8 << 16) / var4;
         int var14 = var1 + var2 * 692106883 * this.Z;
         int var15 = 692106883 * this.Z - var3;
         if (var4 + var2 > this.J * 63686679) {
            var4 -= var2 + var4 - 63686679 * this.J;
         }

         int var16;
         if (var2 < this.F * -1278653805) {
            var16 = -1278653805 * this.F - var2;
            var4 -= var16;
            var14 += var16 * this.Z * 692106883;
            var11 += var16 * var13;
         }

         if (var1 + var3 > -1416794725 * this.Q) {
            var16 = var1 + var3 - this.Q * -1416794725;
            var3 -= var16;
            var15 += var16;
         }

         if (var1 < this.D * -912871679) {
            var16 = -912871679 * this.D - var1;
            var3 -= var16;
            var14 += var16;
            var10 += var12 * var16;
            var15 += var16;
         }

         var16 = var5 >>> 24;
         int var17 = var6 >>> 24;
         int var18;
         int var19;
         int var20;
         int var21;
         if (var9 != 0 && (1 != var9 || var16 != 255 || var17 != 255)) {
            int var22;
            int var23;
            int var24;
            int var25;
            if (1 == var9) {
               var18 = var10;

               for(var19 = -var4; var19 < 0; ++var19) {
                  var20 = (var11 >> 16) * var8;

                  for(var21 = -var3; var21 < 0; ++var21) {
                     var22 = var5;
                     if (var7[(var10 >> 16) + var20] != 0) {
                        var22 = var6;
                     }

                     var23 = var22 >>> 24;
                     var24 = 255 - var23;
                     var25 = this.I[var14];
                     this.I[var14++] = (var23 * (var22 & '\uff00') + (var25 & '\uff00') * var24 & 16711680) + ((var25 & 16711935) * var24 + (var22 & 16711935) * var23 & -16711936) >> 8;
                     var10 += var12;
                  }

                  var11 += var13;
                  var10 = var18;
                  var14 += var15;
               }
            } else {
               if (var9 != 2) {
                  throw new IllegalArgumentException();
               }

               var18 = var10;

               for(var19 = -var4; var19 < 0; ++var19) {
                  var20 = var8 * (var11 >> 16);

                  for(var21 = -var3; var21 < 0; ++var21) {
                     var22 = var5;
                     if (var7[(var10 >> 16) + var20] != 0) {
                        var22 = var6;
                     }

                     if (var22 != 0) {
                        var23 = this.I[var14];
                        var24 = var23 + var22;
                        var25 = (var23 & 16711935) + (var22 & 16711935);
                        var23 = (var25 & 16777472) + (var24 - var25 & 65536);
                        this.I[var14++] = var24 - var23 | var23 - (var23 >>> 8);
                     } else {
                        ++var14;
                     }

                     var10 += var12;
                  }

                  var11 += var13;
                  var10 = var18;
                  var14 += var15;
               }
            }
         } else {
            var18 = var10;

            for(var19 = -var4; var19 < 0; ++var19) {
               var20 = (var11 >> 16) * var8;

               for(var21 = -var3; var21 < 0; ++var21) {
                  if (var7[(var10 >> 16) + var20] != 0) {
                     this.I[var14++] = var6;
                  } else {
                     this.I[var14++] = var5;
                  }

                  var10 += var12;
               }

               var11 += var13;
               var10 = var18;
               var14 += var15;
            }
         }
      }

   }

   public int method5118(int var1, int var2) {
      var1 |= 133120;
      return var1 & var2 ^ var2;
   }

   void fv(int var1, int var2, int var3, int var4, int var5) {
      if (this.I != null) {
         if (var3 < 0) {
            var3 = -var3;
         }

         int var6 = var2 - var3;
         if (var6 < -1278653805 * this.F) {
            var6 = this.F * -1278653805;
         }

         int var7 = var3 + var2 + 1;
         if (var7 > this.J * 63686679) {
            var7 = 63686679 * this.J;
         }

         int var8 = var6;
         int var9 = var3 * var3;
         int var10 = 0;
         int var11 = var2 - var6;
         int var12 = var11 * var11;
         int var13 = var12 - var11;
         if (var2 > var7) {
            var2 = var7;
         }

         int var14 = var4 >>> 24;
         int var15;
         int var16;
         int var17;
         int var18;
         if (var5 != 0 && (var5 != 1 || var14 != 255)) {
            int var19;
            int var20;
            if (var5 == 1) {
               var4 = (var14 << 24) + (var14 * (var4 & 16711935) >> 8 & 16711935) + (var14 * (var4 & '\uff00') >> 8 & '\uff00');

               for(var15 = 256 - var14; var8 < var2; var13 -= var11 + var11) {
                  while(var13 <= var9 || var12 <= var9) {
                     var12 += var10 + var10;
                     var13 += var10++ + var10;
                  }

                  var16 = 1 + (var1 - var10);
                  if (var16 < -912871679 * this.D) {
                     var16 = this.D * -912871679;
                  }

                  var17 = var1 + var10;
                  if (var17 > -1416794725 * this.Q) {
                     var17 = this.Q * -1416794725;
                  }

                  var18 = this.Z * 692106883 * var8 + var16;

                  for(var19 = var16; var19 < var17; ++var19) {
                     var20 = this.I[var18];
                     var20 = ((var20 & 16711935) * var15 >> 8 & 16711935) + (var15 * (var20 & '\uff00') >> 8 & '\uff00');
                     this.I[var18++] = var4 + var20;
                  }

                  ++var8;
                  var12 -= var11-- + var11;
               }

               var10 = var3;
               var11 = -var11;
               var13 = var9 + var11 * var11;
               var12 = var13 - var3;

               for(var13 -= var11; var8 < var7; var12 += var11++ + var11) {
                  while(var13 > var9 && var12 > var9) {
                     var13 -= var10-- + var10;
                     var12 -= var10 + var10;
                  }

                  var16 = var1 - var10;
                  if (var16 < this.D * -912871679) {
                     var16 = this.D * -912871679;
                  }

                  var17 = var1 + var10;
                  if (var17 > this.Q * -1416794725 - 1) {
                     var17 = -1416794725 * this.Q - 1;
                  }

                  var18 = 692106883 * this.Z * var8 + var16;

                  for(var19 = var16; var19 <= var17; ++var19) {
                     var20 = this.I[var18];
                     var20 = ((var20 & 16711935) * var15 >> 8 & 16711935) + (var15 * (var20 & '\uff00') >> 8 & '\uff00');
                     this.I[var18++] = var4 + var20;
                  }

                  ++var8;
                  var13 += var11 + var11;
               }
            } else {
               if (var5 != 2) {
                  throw new IllegalArgumentException();
               }

               int var21;
               while(var8 < var2) {
                  while(var13 <= var9 || var12 <= var9) {
                     var12 += var10 + var10;
                     var13 += var10++ + var10;
                  }

                  var15 = var1 - var10 + 1;
                  if (var15 < -912871679 * this.D) {
                     var15 = this.D * -912871679;
                  }

                  var16 = var1 + var10;
                  if (var16 > -1416794725 * this.Q) {
                     var16 = this.Q * -1416794725;
                  }

                  var17 = this.Z * 692106883 * var8 + var15;

                  for(var18 = var15; var18 < var16; ++var18) {
                     var19 = this.I[var17];
                     var20 = var4 + var19;
                     var21 = (var4 & 16711935) + (var19 & 16711935);
                     var19 = (var21 & 16777472) + (var20 - var21 & 65536);
                     this.I[var17++] = var20 - var19 | var19 - (var19 >>> 8);
                  }

                  ++var8;
                  var12 -= var11-- + var11;
                  var13 -= var11 + var11;
               }

               var10 = var3;
               var11 = -var11;
               var13 = var11 * var11 + var9;
               var12 = var13 - var3;

               for(var13 -= var11; var8 < var7; var12 += var11++ + var11) {
                  while(var13 > var9 && var12 > var9) {
                     var13 -= var10-- + var10;
                     var12 -= var10 + var10;
                  }

                  var15 = var1 - var10;
                  if (var15 < this.D * -912871679) {
                     var15 = -912871679 * this.D;
                  }

                  var16 = var1 + var10;
                  if (var16 > this.Q * -1416794725 - 1) {
                     var16 = this.Q * -1416794725 - 1;
                  }

                  var17 = var15 + var8 * this.Z * 692106883;

                  for(var18 = var15; var18 <= var16; ++var18) {
                     var19 = this.I[var17];
                     var20 = var19 + var4;
                     var21 = (var19 & 16711935) + (var4 & 16711935);
                     var19 = (var20 - var21 & 65536) + (var21 & 16777472);
                     this.I[var17++] = var20 - var19 | var19 - (var19 >>> 8);
                  }

                  ++var8;
                  var13 += var11 + var11;
               }
            }
         } else {
            while(var8 < var2) {
               while(var13 <= var9 || var12 <= var9) {
                  var12 += var10 + var10;
                  var13 += var10++ + var10;
               }

               var15 = var1 - var10 + 1;
               if (var15 < this.D * -912871679) {
                  var15 = -912871679 * this.D;
               }

               var16 = var10 + var1;
               if (var16 > this.Q * -1416794725) {
                  var16 = this.Q * -1416794725;
               }

               var17 = var15 + this.Z * 692106883 * var8;

               for(var18 = var15; var18 < var16; ++var18) {
                  this.I[var17++] = var4;
               }

               ++var8;
               var12 -= var11-- + var11;
               var13 -= var11 + var11;
            }

            var10 = var3;
            var11 = var8 - var2;
            var13 = var11 * var11 + var9;
            var12 = var13 - var3;

            for(var13 -= var11; var8 < var7; var12 += var11++ + var11) {
               while(var13 > var9 && var12 > var9) {
                  var13 -= var10-- + var10;
                  var12 -= var10 + var10;
               }

               var15 = var1 - var10;
               if (var15 < this.D * -912871679) {
                  var15 = this.D * -912871679;
               }

               var16 = var1 + var10;
               if (var16 > -1416794725 * this.Q - 1) {
                  var16 = -1416794725 * this.Q - 1;
               }

               var17 = var8 * 692106883 * this.Z + var15;

               for(var18 = var15; var18 <= var16; ++var18) {
                  this.I[var17++] = var4;
               }

               ++var8;
               var13 += var11 + var11;
            }

            return;
         }
      }

   }

   void fm(int var1, int var2, int var3, int var4, int var5) {
      if (this.I != null) {
         if (var3 < 0) {
            var3 = -var3;
         }

         int var6 = var2 - var3;
         if (var6 < -1278653805 * this.F) {
            var6 = this.F * -1278653805;
         }

         int var7 = var3 + var2 + 1;
         if (var7 > this.J * 63686679) {
            var7 = 63686679 * this.J;
         }

         int var8 = var6;
         int var9 = var3 * var3;
         int var10 = 0;
         int var11 = var2 - var6;
         int var12 = var11 * var11;
         int var13 = var12 - var11;
         if (var2 > var7) {
            var2 = var7;
         }

         int var14 = var4 >>> 24;
         int var15;
         int var16;
         int var17;
         int var18;
         if (var5 != 0 && (var5 != 1 || var14 != 255)) {
            int var19;
            int var20;
            if (var5 == 1) {
               var4 = (var14 << 24) + (var14 * (var4 & 16711935) >> 8 & 16711935) + (var14 * (var4 & '\uff00') >> 8 & '\uff00');

               for(var15 = 256 - var14; var8 < var2; var13 -= var11 + var11) {
                  while(var13 <= var9 || var12 <= var9) {
                     var12 += var10 + var10;
                     var13 += var10++ + var10;
                  }

                  var16 = 1 + (var1 - var10);
                  if (var16 < -912871679 * this.D) {
                     var16 = this.D * -912871679;
                  }

                  var17 = var1 + var10;
                  if (var17 > -1416794725 * this.Q) {
                     var17 = this.Q * -1416794725;
                  }

                  var18 = this.Z * 692106883 * var8 + var16;

                  for(var19 = var16; var19 < var17; ++var19) {
                     var20 = this.I[var18];
                     var20 = ((var20 & 16711935) * var15 >> 8 & 16711935) + (var15 * (var20 & '\uff00') >> 8 & '\uff00');
                     this.I[var18++] = var4 + var20;
                  }

                  ++var8;
                  var12 -= var11-- + var11;
               }

               var10 = var3;
               var11 = -var11;
               var13 = var9 + var11 * var11;
               var12 = var13 - var3;

               for(var13 -= var11; var8 < var7; var12 += var11++ + var11) {
                  while(var13 > var9 && var12 > var9) {
                     var13 -= var10-- + var10;
                     var12 -= var10 + var10;
                  }

                  var16 = var1 - var10;
                  if (var16 < this.D * -912871679) {
                     var16 = this.D * -912871679;
                  }

                  var17 = var1 + var10;
                  if (var17 > this.Q * -1416794725 - 1) {
                     var17 = -1416794725 * this.Q - 1;
                  }

                  var18 = 692106883 * this.Z * var8 + var16;

                  for(var19 = var16; var19 <= var17; ++var19) {
                     var20 = this.I[var18];
                     var20 = ((var20 & 16711935) * var15 >> 8 & 16711935) + (var15 * (var20 & '\uff00') >> 8 & '\uff00');
                     this.I[var18++] = var4 + var20;
                  }

                  ++var8;
                  var13 += var11 + var11;
               }
            } else {
               if (var5 != 2) {
                  throw new IllegalArgumentException();
               }

               int var21;
               while(var8 < var2) {
                  while(var13 <= var9 || var12 <= var9) {
                     var12 += var10 + var10;
                     var13 += var10++ + var10;
                  }

                  var15 = var1 - var10 + 1;
                  if (var15 < -912871679 * this.D) {
                     var15 = this.D * -912871679;
                  }

                  var16 = var1 + var10;
                  if (var16 > -1416794725 * this.Q) {
                     var16 = this.Q * -1416794725;
                  }

                  var17 = this.Z * 692106883 * var8 + var15;

                  for(var18 = var15; var18 < var16; ++var18) {
                     var19 = this.I[var17];
                     var20 = var4 + var19;
                     var21 = (var4 & 16711935) + (var19 & 16711935);
                     var19 = (var21 & 16777472) + (var20 - var21 & 65536);
                     this.I[var17++] = var20 - var19 | var19 - (var19 >>> 8);
                  }

                  ++var8;
                  var12 -= var11-- + var11;
                  var13 -= var11 + var11;
               }

               var10 = var3;
               var11 = -var11;
               var13 = var11 * var11 + var9;
               var12 = var13 - var3;

               for(var13 -= var11; var8 < var7; var12 += var11++ + var11) {
                  while(var13 > var9 && var12 > var9) {
                     var13 -= var10-- + var10;
                     var12 -= var10 + var10;
                  }

                  var15 = var1 - var10;
                  if (var15 < this.D * -912871679) {
                     var15 = -912871679 * this.D;
                  }

                  var16 = var1 + var10;
                  if (var16 > this.Q * -1416794725 - 1) {
                     var16 = this.Q * -1416794725 - 1;
                  }

                  var17 = var15 + var8 * this.Z * 692106883;

                  for(var18 = var15; var18 <= var16; ++var18) {
                     var19 = this.I[var17];
                     var20 = var19 + var4;
                     var21 = (var19 & 16711935) + (var4 & 16711935);
                     var19 = (var20 - var21 & 65536) + (var21 & 16777472);
                     this.I[var17++] = var20 - var19 | var19 - (var19 >>> 8);
                  }

                  ++var8;
                  var13 += var11 + var11;
               }
            }
         } else {
            while(var8 < var2) {
               while(var13 <= var9 || var12 <= var9) {
                  var12 += var10 + var10;
                  var13 += var10++ + var10;
               }

               var15 = var1 - var10 + 1;
               if (var15 < this.D * -912871679) {
                  var15 = -912871679 * this.D;
               }

               var16 = var10 + var1;
               if (var16 > this.Q * -1416794725) {
                  var16 = this.Q * -1416794725;
               }

               var17 = var15 + this.Z * 692106883 * var8;

               for(var18 = var15; var18 < var16; ++var18) {
                  this.I[var17++] = var4;
               }

               ++var8;
               var12 -= var11-- + var11;
               var13 -= var11 + var11;
            }

            var10 = var3;
            var11 = var8 - var2;
            var13 = var11 * var11 + var9;
            var12 = var13 - var3;

            for(var13 -= var11; var8 < var7; var12 += var11++ + var11) {
               while(var13 > var9 && var12 > var9) {
                  var13 -= var10-- + var10;
                  var12 -= var10 + var10;
               }

               var15 = var1 - var10;
               if (var15 < this.D * -912871679) {
                  var15 = this.D * -912871679;
               }

               var16 = var1 + var10;
               if (var16 > -1416794725 * this.Q - 1) {
                  var16 = -1416794725 * this.Q - 1;
               }

               var17 = var8 * 692106883 * this.Z + var15;

               for(var18 = var15; var18 <= var16; ++var18) {
                  this.I[var17++] = var4;
               }

               ++var8;
               var13 += var11 + var11;
            }

            return;
         }
      }

   }

   public void ff(int var1, int var2, int var3, int var4, int var5) {
      if (this.I != null && var2 >= -1278653805 * this.F && var2 < 63686679 * this.J) {
         if (var1 < -912871679 * this.D) {
            var3 -= -912871679 * this.D - var1;
            var1 = this.D * -912871679;
         }

         if (var1 + var3 > -1416794725 * this.Q) {
            var3 = -1416794725 * this.Q - var1;
         }

         int var6 = var1 + 692106883 * this.Z * var2;
         int var7 = var4 >>> 24;
         int var8;
         if (var5 != 0 && (var5 != 1 || var7 != 255)) {
            int var9;
            int var10;
            if (var5 == 1) {
               var4 = (var7 << 24) + ((var4 & '\uff00') * var7 >> 8 & '\uff00') + (var7 * (var4 & 16711935) >> 8 & 16711935);
               var8 = 256 - var7;

               for(var9 = 0; var9 < var3; ++var9) {
                  var10 = this.I[var9 + var6];
                  var10 = (var8 * (var10 & '\uff00') >> 8 & '\uff00') + (var8 * (var10 & 16711935) >> 8 & 16711935);
                  this.I[var9 + var6] = var4 + var10;
               }
            } else {
               if (var5 != 2) {
                  throw new IllegalArgumentException();
               }

               for(var8 = 0; var8 < var3; ++var8) {
                  var9 = this.I[var6 + var8];
                  var10 = var4 + var9;
                  int var11 = (var9 & 16711935) + (var4 & 16711935);
                  var9 = (var11 & 16777472) + (var10 - var11 & 65536);
                  this.I[var6 + var8] = var10 - var9 | var9 - (var9 >>> 8);
               }
            }
         } else {
            for(var8 = 0; var8 < var3; ++var8) {
               this.I[var6 + var8] = var4;
            }
         }
      }

   }

   public void fd(int var1, int var2, int var3, int var4, int var5) {
      if (this.I != null && var2 >= -1278653805 * this.F && var2 < 63686679 * this.J) {
         if (var1 < -912871679 * this.D) {
            var3 -= -912871679 * this.D - var1;
            var1 = this.D * -912871679;
         }

         if (var1 + var3 > -1416794725 * this.Q) {
            var3 = -1416794725 * this.Q - var1;
         }

         int var6 = var1 + 692106883 * this.Z * var2;
         int var7 = var4 >>> 24;
         int var8;
         if (var5 != 0 && (var5 != 1 || var7 != 255)) {
            int var9;
            int var10;
            if (var5 == 1) {
               var4 = (var7 << 24) + ((var4 & '\uff00') * var7 >> 8 & '\uff00') + (var7 * (var4 & 16711935) >> 8 & 16711935);
               var8 = 256 - var7;

               for(var9 = 0; var9 < var3; ++var9) {
                  var10 = this.I[var9 + var6];
                  var10 = (var8 * (var10 & '\uff00') >> 8 & '\uff00') + (var8 * (var10 & 16711935) >> 8 & 16711935);
                  this.I[var9 + var6] = var4 + var10;
               }
            } else {
               if (var5 != 2) {
                  throw new IllegalArgumentException();
               }

               for(var8 = 0; var8 < var3; ++var8) {
                  var9 = this.I[var6 + var8];
                  var10 = var4 + var9;
                  int var11 = (var9 & 16711935) + (var4 & 16711935);
                  var9 = (var11 & 16777472) + (var10 - var11 & 65536);
                  this.I[var6 + var8] = var10 - var9 | var9 - (var9 >>> 8);
               }
            }
         } else {
            for(var8 = 0; var8 < var3; ++var8) {
               this.I[var6 + var8] = var4;
            }
         }
      }

   }

   public void ft(int var1, int var2, int var3, int var4, int var5) {
      if (this.I != null && var1 >= this.D * -912871679 && var1 < this.Q * -1416794725) {
         if (var2 < -1278653805 * this.F) {
            var3 -= this.F * -1278653805 - var2;
            var2 = this.F * -1278653805;
         }

         if (var3 + var2 > 63686679 * this.J) {
            var3 = 63686679 * this.J - var2;
         }

         int var6 = var1 + var2 * this.Z * 692106883;
         int var7 = var4 >>> 24;
         int var8;
         if (var5 != 0 && (1 != var5 || 255 != var7)) {
            int var9;
            int var10;
            int var11;
            if (var5 == 1) {
               var4 = (var7 * (var4 & '\uff00') >> 8 & '\uff00') + ((var4 & 16711935) * var7 >> 8 & 16711935) + (var7 << 24);
               var8 = 256 - var7;

               for(var9 = 0; var9 < var3; ++var9) {
                  var10 = var9 * 692106883 * this.Z + var6;
                  var11 = this.I[var10];
                  var11 = (var8 * (var11 & 16711935) >> 8 & 16711935) + ((var11 & '\uff00') * var8 >> 8 & '\uff00');
                  this.I[var10] = var11 + var4;
               }
            } else {
               if (2 != var5) {
                  throw new IllegalArgumentException();
               }

               for(var8 = 0; var8 < var3; ++var8) {
                  var9 = var8 * 692106883 * this.Z + var6;
                  var10 = this.I[var9];
                  var11 = var4 + var10;
                  int var12 = (var10 & 16711935) + (var4 & 16711935);
                  var10 = (var12 & 16777472) + (var11 - var12 & 65536);
                  this.I[var9] = var11 - var10 | var10 - (var10 >>> 8);
               }
            }
         } else {
            for(var8 = 0; var8 < var3; ++var8) {
               this.I[var6 + var8 * this.Z * 692106883] = var4;
            }
         }
      }

   }

   public void ea(int var1, int var2, int var3, int var4) {
      if (-912871679 * this.D < var1) {
         this.D = var1 * -1291169535;
      }

      if (this.F * -1278653805 < var2) {
         this.F = var2 * 104031131;
      }

      if (this.Q * -1416794725 > var3) {
         this.Q = var3 * -1912131437;
      }

      if (63686679 * this.J > var4) {
         this.J = var4 * 1656090535;
      }

      this.S();
   }

   public void fl(int var1, int var2, int var3, int var4, int var5) {
      if (this.I != null && var1 >= this.D * -912871679 && var1 < this.Q * -1416794725) {
         if (var2 < -1278653805 * this.F) {
            var3 -= this.F * -1278653805 - var2;
            var2 = this.F * -1278653805;
         }

         if (var3 + var2 > 63686679 * this.J) {
            var3 = 63686679 * this.J - var2;
         }

         int var6 = var1 + var2 * this.Z * 692106883;
         int var7 = var4 >>> 24;
         int var8;
         if (var5 != 0 && (1 != var5 || 255 != var7)) {
            int var9;
            int var10;
            int var11;
            if (var5 == 1) {
               var4 = (var7 * (var4 & '\uff00') >> 8 & '\uff00') + ((var4 & 16711935) * var7 >> 8 & 16711935) + (var7 << 24);
               var8 = 256 - var7;

               for(var9 = 0; var9 < var3; ++var9) {
                  var10 = var9 * 692106883 * this.Z + var6;
                  var11 = this.I[var10];
                  var11 = (var8 * (var11 & 16711935) >> 8 & 16711935) + ((var11 & '\uff00') * var8 >> 8 & '\uff00');
                  this.I[var10] = var11 + var4;
               }
            } else {
               if (2 != var5) {
                  throw new IllegalArgumentException();
               }

               for(var8 = 0; var8 < var3; ++var8) {
                  var9 = var8 * 692106883 * this.Z + var6;
                  var10 = this.I[var9];
                  var11 = var4 + var10;
                  int var12 = (var10 & 16711935) + (var4 & 16711935);
                  var10 = (var12 & 16777472) + (var11 - var12 & 65536);
                  this.I[var9] = var11 - var10 | var10 - (var10 >>> 8);
               }
            }
         } else {
            for(var8 = 0; var8 < var3; ++var8) {
               this.I[var6 + var8 * this.Z * 692106883] = var4;
            }
         }
      }

   }

   public int du() {
      return 0;
   }

   public void method5088(int var1, int var2, int var3, int var4, int var5, int var6, QJI var7, int var8, int var9) {
      if (this.I != null) {
         TJI var10 = (TJI)var7;
         int[] var11 = var10.Z;
         int[] var12 = var10.I;
         int var13 = this.F * -1278653805 > var9 ? this.F * -1278653805 : var9;
         int var14 = 63686679 * this.J < var9 + var11.length ? 63686679 * this.J : var9 + var11.length;
         var3 -= var1;
         var4 -= var2;
         if (var3 + var4 < 0) {
            var1 += var3;
            var3 = -var3;
            var2 += var4;
            var4 = -var4;
         }

         int var15;
         int var16;
         int var17;
         int var18;
         int var19;
         int var20;
         int var21;
         int var22;
         int var23;
         if (var3 > var4) {
            var2 <<= 16;
            var2 += 32768;
            var4 <<= 16;
            var15 = (int)Math.floor(0.5D + (double)var4 / (double)var3);
            var3 += var1;
            if (var1 < this.D * -912871679) {
               var2 += (-912871679 * this.D - var1) * var15;
               var1 = -912871679 * this.D;
            }

            if (var3 >= -1416794725 * this.Q) {
               var3 = -1416794725 * this.Q - 1;
            }

            var16 = var5 >>> 24;
            if (var6 == 0 || var6 == 1 && 255 == var16) {
               while(var1 <= var3) {
                  var17 = var2 >> 16;
                  var18 = var17 - var9;
                  if (var17 >= var13 && var17 < var14) {
                     var19 = var11[var18] + var8;
                     if (var1 >= var19 && var1 < var12[var18] + var19) {
                        this.I[this.Z * 692106883 * var17 + var1] = var5;
                     }
                  }

                  var2 += var15;
                  ++var1;
               }
            } else if (1 == var6) {
               var5 = (var16 << 24) + (var16 * (var5 & 16711935) >> 8 & 16711935) + ((var5 & '\uff00') * var16 >> 8 & '\uff00');

               for(var17 = 256 - var16; var1 <= var3; ++var1) {
                  var18 = var2 >> 16;
                  var19 = var18 - var9;
                  if (var18 >= var13 && var18 < var14) {
                     var20 = var11[var19] + var8;
                     if (var1 >= var20 && var1 < var12[var19] + var20) {
                        var21 = var1 + this.Z * 692106883 * var18;
                        var22 = this.I[var21];
                        var22 = ((var22 & '\uff00') * var17 >> 8 & '\uff00') + (var17 * (var22 & 16711935) >> 8 & 16711935);
                        this.I[var21] = var22 + var5;
                     }
                  }

                  var2 += var15;
               }
            } else {
               if (2 != var6) {
                  throw new IllegalArgumentException();
               }

               while(var1 <= var3) {
                  var17 = var2 >> 16;
                  var18 = var17 - var9;
                  if (var17 >= var13 && var17 < var14) {
                     var19 = var11[var18] + var8;
                     if (var1 >= var19 && var1 < var19 + var12[var18]) {
                        var20 = var1 + var17 * this.Z * 692106883;
                        var21 = this.I[var20];
                        var22 = var5 + var21;
                        var23 = (var5 & 16711935) + (var21 & 16711935);
                        var21 = (var23 & 16777472) + (var22 - var23 & 65536);
                        this.I[var20] = var22 - var21 | var21 - (var21 >>> 8);
                     }
                  }

                  var2 += var15;
                  ++var1;
               }
            }
         } else {
            var1 <<= 16;
            var1 += 32768;
            var3 <<= 16;
            var15 = (int)Math.floor((double)var3 / (double)var4 + 0.5D);
            var4 += var2;
            if (var2 < var13) {
               var1 += (var13 - var2) * var15;
               var2 = var13;
            }

            if (var4 >= var14) {
               var4 = var14 - 1;
            }

            var16 = var5 >>> 24;
            if (var6 == 0 || 1 == var6 && var16 == 255) {
               while(var2 <= var4) {
                  var17 = var1 >> 16;
                  var18 = var2 - var9;
                  var19 = var11[var18] + var8;
                  if (var17 >= this.D * -912871679 && var17 < -1416794725 * this.Q && var17 >= var19 && var17 < var12[var18] + var19) {
                     this.I[692106883 * this.Z * var2 + var17] = var5;
                  }

                  var1 += var15;
                  ++var2;
               }
            } else if (var6 == 1) {
               var5 = (var16 * (var5 & 16711935) >> 8 & 16711935) + (var16 * (var5 & '\uff00') >> 8 & '\uff00') + (var16 << 24);

               for(var17 = 256 - var16; var2 <= var4; ++var2) {
                  var18 = var1 >> 16;
                  var19 = var2 - var9;
                  var20 = var8 + var11[var19];
                  if (var18 >= -912871679 * this.D && var18 < -1416794725 * this.Q && var18 >= var20 && var18 < var12[var19] + var20) {
                     var21 = 692106883 * this.Z * var2 + var18;
                     var22 = this.I[var21];
                     var22 = ((var22 & '\uff00') * var17 >> 8 & '\uff00') + (var17 * (var22 & 16711935) >> 8 & 16711935);
                     this.I[var2 * 692106883 * this.Z + var18] = var22 + var5;
                  }

                  var1 += var15;
               }
            } else {
               if (var6 != 2) {
                  throw new IllegalArgumentException();
               }

               while(var2 <= var4) {
                  var17 = var1 >> 16;
                  var18 = var2 - var9;
                  var19 = var8 + var11[var18];
                  if (var17 >= -912871679 * this.D && var17 < -1416794725 * this.Q && var17 >= var19 && var17 < var19 + var12[var18]) {
                     var20 = this.Z * 692106883 * var2 + var17;
                     var21 = this.I[var20];
                     var22 = var21 + var5;
                     var23 = (var5 & 16711935) + (var21 & 16711935);
                     var21 = (var22 - var23 & 65536) + (var23 & 16777472);
                     this.I[var20] = var22 - var21 | var21 - (var21 >>> 8);
                  }

                  var1 += var15;
                  ++var2;
               }
            }
         }
      }

   }

   public void method5096(int var1, int var2, int var3, int var4, int var5, int var6, QJI var7, int var8, int var9) {
      if (this.I != null) {
         TJI var10 = (TJI)var7;
         int[] var11 = var10.Z;
         int[] var12 = var10.I;
         int var13 = this.F * -1278653805 > var9 ? this.F * -1278653805 : var9;
         int var14 = 63686679 * this.J < var9 + var11.length ? 63686679 * this.J : var9 + var11.length;
         var3 -= var1;
         var4 -= var2;
         if (var3 + var4 < 0) {
            var1 += var3;
            var3 = -var3;
            var2 += var4;
            var4 = -var4;
         }

         int var15;
         int var16;
         int var17;
         int var18;
         int var19;
         int var20;
         int var21;
         int var22;
         int var23;
         if (var3 > var4) {
            var2 <<= 16;
            var2 += 32768;
            var4 <<= 16;
            var15 = (int)Math.floor(0.5D + (double)var4 / (double)var3);
            var3 += var1;
            if (var1 < this.D * -912871679) {
               var2 += (-912871679 * this.D - var1) * var15;
               var1 = -912871679 * this.D;
            }

            if (var3 >= -1416794725 * this.Q) {
               var3 = -1416794725 * this.Q - 1;
            }

            var16 = var5 >>> 24;
            if (var6 == 0 || var6 == 1 && 255 == var16) {
               while(var1 <= var3) {
                  var17 = var2 >> 16;
                  var18 = var17 - var9;
                  if (var17 >= var13 && var17 < var14) {
                     var19 = var11[var18] + var8;
                     if (var1 >= var19 && var1 < var12[var18] + var19) {
                        this.I[this.Z * 692106883 * var17 + var1] = var5;
                     }
                  }

                  var2 += var15;
                  ++var1;
               }
            } else if (1 == var6) {
               var5 = (var16 << 24) + (var16 * (var5 & 16711935) >> 8 & 16711935) + ((var5 & '\uff00') * var16 >> 8 & '\uff00');

               for(var17 = 256 - var16; var1 <= var3; ++var1) {
                  var18 = var2 >> 16;
                  var19 = var18 - var9;
                  if (var18 >= var13 && var18 < var14) {
                     var20 = var11[var19] + var8;
                     if (var1 >= var20 && var1 < var12[var19] + var20) {
                        var21 = var1 + this.Z * 692106883 * var18;
                        var22 = this.I[var21];
                        var22 = ((var22 & '\uff00') * var17 >> 8 & '\uff00') + (var17 * (var22 & 16711935) >> 8 & 16711935);
                        this.I[var21] = var22 + var5;
                     }
                  }

                  var2 += var15;
               }
            } else {
               if (2 != var6) {
                  throw new IllegalArgumentException();
               }

               while(var1 <= var3) {
                  var17 = var2 >> 16;
                  var18 = var17 - var9;
                  if (var17 >= var13 && var17 < var14) {
                     var19 = var11[var18] + var8;
                     if (var1 >= var19 && var1 < var19 + var12[var18]) {
                        var20 = var1 + var17 * this.Z * 692106883;
                        var21 = this.I[var20];
                        var22 = var5 + var21;
                        var23 = (var5 & 16711935) + (var21 & 16711935);
                        var21 = (var23 & 16777472) + (var22 - var23 & 65536);
                        this.I[var20] = var22 - var21 | var21 - (var21 >>> 8);
                     }
                  }

                  var2 += var15;
                  ++var1;
               }
            }
         } else {
            var1 <<= 16;
            var1 += 32768;
            var3 <<= 16;
            var15 = (int)Math.floor((double)var3 / (double)var4 + 0.5D);
            var4 += var2;
            if (var2 < var13) {
               var1 += (var13 - var2) * var15;
               var2 = var13;
            }

            if (var4 >= var14) {
               var4 = var14 - 1;
            }

            var16 = var5 >>> 24;
            if (var6 == 0 || 1 == var6 && var16 == 255) {
               while(var2 <= var4) {
                  var17 = var1 >> 16;
                  var18 = var2 - var9;
                  var19 = var11[var18] + var8;
                  if (var17 >= this.D * -912871679 && var17 < -1416794725 * this.Q && var17 >= var19 && var17 < var12[var18] + var19) {
                     this.I[692106883 * this.Z * var2 + var17] = var5;
                  }

                  var1 += var15;
                  ++var2;
               }
            } else if (var6 == 1) {
               var5 = (var16 * (var5 & 16711935) >> 8 & 16711935) + (var16 * (var5 & '\uff00') >> 8 & '\uff00') + (var16 << 24);

               for(var17 = 256 - var16; var2 <= var4; ++var2) {
                  var18 = var1 >> 16;
                  var19 = var2 - var9;
                  var20 = var8 + var11[var19];
                  if (var18 >= -912871679 * this.D && var18 < -1416794725 * this.Q && var18 >= var20 && var18 < var12[var19] + var20) {
                     var21 = 692106883 * this.Z * var2 + var18;
                     var22 = this.I[var21];
                     var22 = ((var22 & '\uff00') * var17 >> 8 & '\uff00') + (var17 * (var22 & 16711935) >> 8 & 16711935);
                     this.I[var2 * 692106883 * this.Z + var18] = var22 + var5;
                  }

                  var1 += var15;
               }
            } else {
               if (var6 != 2) {
                  throw new IllegalArgumentException();
               }

               while(var2 <= var4) {
                  var17 = var1 >> 16;
                  var18 = var2 - var9;
                  var19 = var8 + var11[var18];
                  if (var17 >= -912871679 * this.D && var17 < -1416794725 * this.Q && var17 >= var19 && var17 < var19 + var12[var18]) {
                     var20 = this.Z * 692106883 * var2 + var17;
                     var21 = this.I[var20];
                     var22 = var21 + var5;
                     var23 = (var5 & 16711935) + (var21 & 16711935);
                     var21 = (var22 - var23 & 65536) + (var23 & 16777472);
                     this.I[var20] = var22 - var21 | var21 - (var21 >>> 8);
                  }

                  var1 += var15;
                  ++var2;
               }
            }
         }
      }

   }

   public void method5097(int var1, int var2, int var3, int var4, int var5, int var6, QJI var7, int var8, int var9) {
      if (this.I != null) {
         TJI var10 = (TJI)var7;
         int[] var11 = var10.Z;
         int[] var12 = var10.I;
         int var13 = this.F * -1278653805 > var9 ? this.F * -1278653805 : var9;
         int var14 = 63686679 * this.J < var9 + var11.length ? 63686679 * this.J : var9 + var11.length;
         var3 -= var1;
         var4 -= var2;
         if (var3 + var4 < 0) {
            var1 += var3;
            var3 = -var3;
            var2 += var4;
            var4 = -var4;
         }

         int var15;
         int var16;
         int var17;
         int var18;
         int var19;
         int var20;
         int var21;
         int var22;
         int var23;
         if (var3 > var4) {
            var2 <<= 16;
            var2 += 32768;
            var4 <<= 16;
            var15 = (int)Math.floor(0.5D + (double)var4 / (double)var3);
            var3 += var1;
            if (var1 < this.D * -912871679) {
               var2 += (-912871679 * this.D - var1) * var15;
               var1 = -912871679 * this.D;
            }

            if (var3 >= -1416794725 * this.Q) {
               var3 = -1416794725 * this.Q - 1;
            }

            var16 = var5 >>> 24;
            if (var6 == 0 || var6 == 1 && 255 == var16) {
               while(var1 <= var3) {
                  var17 = var2 >> 16;
                  var18 = var17 - var9;
                  if (var17 >= var13 && var17 < var14) {
                     var19 = var11[var18] + var8;
                     if (var1 >= var19 && var1 < var12[var18] + var19) {
                        this.I[this.Z * 692106883 * var17 + var1] = var5;
                     }
                  }

                  var2 += var15;
                  ++var1;
               }
            } else if (1 == var6) {
               var5 = (var16 << 24) + (var16 * (var5 & 16711935) >> 8 & 16711935) + ((var5 & '\uff00') * var16 >> 8 & '\uff00');

               for(var17 = 256 - var16; var1 <= var3; ++var1) {
                  var18 = var2 >> 16;
                  var19 = var18 - var9;
                  if (var18 >= var13 && var18 < var14) {
                     var20 = var11[var19] + var8;
                     if (var1 >= var20 && var1 < var12[var19] + var20) {
                        var21 = var1 + this.Z * 692106883 * var18;
                        var22 = this.I[var21];
                        var22 = ((var22 & '\uff00') * var17 >> 8 & '\uff00') + (var17 * (var22 & 16711935) >> 8 & 16711935);
                        this.I[var21] = var22 + var5;
                     }
                  }

                  var2 += var15;
               }
            } else {
               if (2 != var6) {
                  throw new IllegalArgumentException();
               }

               while(var1 <= var3) {
                  var17 = var2 >> 16;
                  var18 = var17 - var9;
                  if (var17 >= var13 && var17 < var14) {
                     var19 = var11[var18] + var8;
                     if (var1 >= var19 && var1 < var19 + var12[var18]) {
                        var20 = var1 + var17 * this.Z * 692106883;
                        var21 = this.I[var20];
                        var22 = var5 + var21;
                        var23 = (var5 & 16711935) + (var21 & 16711935);
                        var21 = (var23 & 16777472) + (var22 - var23 & 65536);
                        this.I[var20] = var22 - var21 | var21 - (var21 >>> 8);
                     }
                  }

                  var2 += var15;
                  ++var1;
               }
            }
         } else {
            var1 <<= 16;
            var1 += 32768;
            var3 <<= 16;
            var15 = (int)Math.floor((double)var3 / (double)var4 + 0.5D);
            var4 += var2;
            if (var2 < var13) {
               var1 += (var13 - var2) * var15;
               var2 = var13;
            }

            if (var4 >= var14) {
               var4 = var14 - 1;
            }

            var16 = var5 >>> 24;
            if (var6 == 0 || 1 == var6 && var16 == 255) {
               while(var2 <= var4) {
                  var17 = var1 >> 16;
                  var18 = var2 - var9;
                  var19 = var11[var18] + var8;
                  if (var17 >= this.D * -912871679 && var17 < -1416794725 * this.Q && var17 >= var19 && var17 < var12[var18] + var19) {
                     this.I[692106883 * this.Z * var2 + var17] = var5;
                  }

                  var1 += var15;
                  ++var2;
               }
            } else if (var6 == 1) {
               var5 = (var16 * (var5 & 16711935) >> 8 & 16711935) + (var16 * (var5 & '\uff00') >> 8 & '\uff00') + (var16 << 24);

               for(var17 = 256 - var16; var2 <= var4; ++var2) {
                  var18 = var1 >> 16;
                  var19 = var2 - var9;
                  var20 = var8 + var11[var19];
                  if (var18 >= -912871679 * this.D && var18 < -1416794725 * this.Q && var18 >= var20 && var18 < var12[var19] + var20) {
                     var21 = 692106883 * this.Z * var2 + var18;
                     var22 = this.I[var21];
                     var22 = ((var22 & '\uff00') * var17 >> 8 & '\uff00') + (var17 * (var22 & 16711935) >> 8 & 16711935);
                     this.I[var2 * 692106883 * this.Z + var18] = var22 + var5;
                  }

                  var1 += var15;
               }
            } else {
               if (var6 != 2) {
                  throw new IllegalArgumentException();
               }

               while(var2 <= var4) {
                  var17 = var1 >> 16;
                  var18 = var2 - var9;
                  var19 = var8 + var11[var18];
                  if (var17 >= -912871679 * this.D && var17 < -1416794725 * this.Q && var17 >= var19 && var17 < var19 + var12[var18]) {
                     var20 = this.Z * 692106883 * var2 + var17;
                     var21 = this.I[var20];
                     var22 = var21 + var5;
                     var23 = (var5 & 16711935) + (var21 & 16711935);
                     var21 = (var22 - var23 & 65536) + (var23 & 16777472);
                     this.I[var20] = var22 - var21 | var21 - (var21 >>> 8);
                  }

                  var1 += var15;
                  ++var2;
               }
            }
         }
      }

   }

   public void method5098(int var1, int var2, int var3, int var4, int var5, int var6, QJI var7, int var8, int var9, int var10, int var11, int var12) {
      if (this.I != null) {
         TJI var13 = (TJI)var7;
         int[] var14 = var13.Z;
         int[] var15 = var13.I;
         int var16 = this.F * -1278653805 > var9 ? -1278653805 * this.F : var9;
         int var17 = this.J * 63686679 < var9 + var14.length ? this.J * 63686679 : var9 + var14.length;
         var12 <<= 8;
         var10 <<= 8;
         var11 <<= 8;
         int var18 = var10 + var11;
         var12 %= var18;
         var3 -= var1;
         var4 -= var2;
         int var19;
         int var20;
         if (var4 + var3 < 0) {
            var19 = (int)(Math.sqrt((double)(var4 * var4 + var3 * var3)) * 256.0D);
            var20 = var19 % var18;
            var12 = var10 + var18 - var12 - var20;
            var12 %= var18;
            if (var12 < 0) {
               var12 += var18;
            }

            var1 += var3;
            var3 = -var3;
            var2 += var4;
            var4 = -var4;
         }

         int var21;
         int var22;
         int var23;
         int var24;
         int var25;
         int var26;
         int var27;
         if (var3 > var4) {
            var2 <<= 16;
            var2 += 32768;
            var4 <<= 16;
            var19 = (int)Math.floor((double)var4 / (double)var3 + 0.5D);
            var3 += var1;
            var20 = var5 >>> 24;
            var21 = (int)Math.sqrt((double)(65536 + (var19 >> 8) * (var19 >> 8)));
            if (var6 != 0 && (var6 != 1 || 255 != var20)) {
               if (1 == var6) {
                  var5 = (var20 << 24) + (var20 * (var5 & 16711935) >> 8 & 16711935) + ((var5 & '\uff00') * var20 >> 8 & '\uff00');

                  for(var22 = 256 - var20; var1 <= var3; var12 %= var18) {
                     var23 = var2 >> 16;
                     var24 = var23 - var9;
                     if (var1 >= -912871679 * this.D && var1 < this.Q * -1416794725 && var23 >= var16 && var23 < var17 && var12 < var10) {
                        var25 = var8 + var14[var24];
                        if (var1 >= var25 && var1 < var15[var24] + var25) {
                           var26 = var1 + this.Z * 692106883 * var23;
                           var27 = this.I[var26];
                           var27 = (var22 * (var27 & '\uff00') >> 8 & '\uff00') + (var22 * (var27 & 16711935) >> 8 & 16711935);
                           this.I[var26] = var27 + var5;
                        }
                     }

                     var2 += var19;
                     ++var1;
                     var12 += var21;
                  }
               } else {
                  if (var6 != 2) {
                     throw new IllegalArgumentException();
                  }

                  while(var1 <= var3) {
                     var22 = var2 >> 16;
                     var23 = var22 - var9;
                     if (var1 >= this.D * -912871679 && var1 < -1416794725 * this.Q && var22 >= var16 && var22 < var17 && var12 < var10) {
                        var24 = var14[var23] + var8;
                        if (var1 >= var24 && var1 < var24 + var15[var23]) {
                           var25 = 692106883 * this.Z * var22 + var1;
                           var26 = this.I[var25];
                           var27 = var5 + var26;
                           int var28 = (var5 & 16711935) + (var26 & 16711935);
                           var26 = (var27 - var28 & 65536) + (var28 & 16777472);
                           this.I[var25] = var27 - var26 | var26 - (var26 >>> 8);
                        }
                     }

                     var2 += var19;
                     ++var1;
                     var12 += var21;
                     var12 %= var18;
                  }
               }
            } else {
               while(var1 <= var3) {
                  var22 = var2 >> 16;
                  var23 = var22 - var9;
                  if (var1 >= this.D * -912871679 && var1 < -1416794725 * this.Q && var22 >= var16 && var22 < var17 && var12 < var10) {
                     var24 = var14[var23] + var8;
                     if (var1 >= var24 && var1 < var24 + var15[var23]) {
                        this.I[var1 + 692106883 * this.Z * var22] = var5;
                     }
                  }

                  var2 += var19;
                  ++var1;
                  var12 += var21;
                  var12 %= var18;
               }
            }
         } else {
            var1 <<= 16;
            var1 += 32768;
            var3 <<= 16;
            var19 = (int)Math.floor(0.5D + (double)var3 / (double)var4);
            var20 = (int)Math.sqrt((double)((var19 >> 8) * (var19 >> 8) + 65536));
            var4 += var2;
            var21 = var5 >>> 24;
            if (var6 == 0 || var6 == 1 && var21 == 255) {
               while(var2 <= var4) {
                  var22 = var1 >> 16;
                  var23 = var2 - var9;
                  if (var2 >= var16 && var2 < var17 && var22 >= this.D * -912871679 && var22 < this.Q * -1416794725 && var12 < var10 && var22 >= var8 + var14[var23] && var22 < var15[var23] + var8 + var14[var23]) {
                     this.I[var2 * 692106883 * this.Z + var22] = var5;
                  }

                  var1 += var19;
                  ++var2;
                  var12 += var20;
                  var12 %= var18;
               }
            } else if (1 == var6) {
               var5 = ((var5 & 16711935) * var21 >> 8 & 16711935) + ((var5 & '\uff00') * var21 >> 8 & '\uff00') + (var21 << 24);

               for(var22 = 256 - var21; var2 <= var4; var12 %= var18) {
                  var23 = var1 >> 16;
                  var24 = var2 - var9;
                  if (var2 >= var16 && var2 < var17 && var23 >= this.D * -912871679 && var23 < this.Q * -1416794725 && var12 < var10 && var23 >= var8 + var14[var24] && var23 < var14[var24] + var8 + var15[var24]) {
                     var25 = var23 + var2 * this.Z * 692106883;
                     var26 = this.I[var25];
                     var26 = (var22 * (var26 & '\uff00') >> 8 & '\uff00') + ((var26 & 16711935) * var22 >> 8 & 16711935);
                     this.I[var23 + var2 * this.Z * 692106883] = var5 + var26;
                  }

                  var1 += var19;
                  ++var2;
                  var12 += var20;
               }
            } else {
               if (2 != var6) {
                  throw new IllegalArgumentException();
               }

               while(var2 <= var4) {
                  var22 = var1 >> 16;
                  var23 = var2 - var9;
                  if (var2 >= var16 && var2 < var17 && var22 >= this.D * -912871679 && var22 < this.Q * -1416794725 && var12 < var10 && var22 >= var8 + var14[var23] && var22 < var14[var23] + var8 + var15[var23]) {
                     var24 = 692106883 * this.Z * var2 + var22;
                     var25 = this.I[var24];
                     var26 = var25 + var5;
                     var27 = (var5 & 16711935) + (var25 & 16711935);
                     var25 = (var27 & 16777472) + (var26 - var27 & 65536);
                     this.I[var24] = var26 - var25 | var25 - (var25 >>> 8);
                  }

                  var1 += var19;
                  ++var2;
                  var12 += var20;
                  var12 %= var18;
               }
            }
         }
      }

   }

   public int method5099(int var1, int var2, int var3, int var4, int var5, int var6) {
      int var7 = 0;
      float var8 = (float)var3 * this.O.I[10] + this.O.I[6] * (float)var2 + (float)var1 * this.O.I[2] + this.O.I[14];
      float var9 = (float)var6 * this.O.I[10] + this.O.I[6] * (float)var5 + this.O.I[14] + (float)var4 * this.O.I[2];
      float var10 = (float)var1 * this.O.I[3] + this.O.I[15] + this.O.I[7] * (float)var2 + (float)var3 * this.O.I[11];
      float var11 = (float)var4 * this.O.I[3] + this.O.I[15] + this.O.I[7] * (float)var5 + this.O.I[11] * (float)var6;
      if (var8 < -var10 && var9 < -var11) {
         var7 |= 16;
      } else if (var8 > var10 && var9 > var11) {
         var7 |= 32;
      }

      float var12 = this.O.I[4] * (float)var2 + this.O.I[12] + this.O.I[0] * (float)var1 + this.O.I[8] * (float)var3;
      float var13 = this.O.I[8] * (float)var6 + (float)var4 * this.O.I[0] + this.O.I[12] + this.O.I[4] * (float)var5;
      if (var12 < -var10 && var13 < -var11) {
         var7 |= 1;
      }

      if (var12 > var10 && var13 > var11) {
         var7 |= 2;
      }

      float var14 = (float)var2 * this.O.I[5] + this.O.I[1] * (float)var1 + this.O.I[13] + this.O.I[9] * (float)var3;
      float var15 = (float)var4 * this.O.I[1] + this.O.I[13] + (float)var5 * this.O.I[5] + this.O.I[9] * (float)var6;
      if (var14 < -var10 && var15 < -var11) {
         var7 |= 4;
      }

      if (var14 > var10 && var15 > var11) {
         var7 |= 8;
      }

      return var7;
   }

   public void method4993(int var1) {
      int var2 = var1 - -1633713343 * this.B;

      for(QL var3 = (QL)this.S.Z(1895439164); var3 != null; var3 = (QL)this.S.C(-150689583)) {
         if (var3.A) {
            var3.S += var2;
            int var4 = var3.S / 50;
            if (var4 > 0) {
               WCI var5 = this.LZ.method174(var3.E, 1049472051);
               float var6 = var5.Z ? 64.0F : 128.0F;
               var3.Z((int)((float)var2 / 1000.0F * (float)var5.H / 64.0F * var6), (int)(var6 * ((float)var5.I * ((float)var2 / 1000.0F) / 64.0F)));
               var3.S -= 50 * var4;
            }

            var3.A = false;
         }
      }

      this.B = -1260974911 * var1;
      this.L.I(5, -253785523);
      this.S.I(5, -559517412);
   }

   public VJI method5102(int var1) {
      return null;
   }

   public void method5103(VJI var1) {
   }

   public IBI method5104(int var1, int var2, boolean var3, boolean var4) {
      return (IBI)(var3 ? new CBI(this, var1, var2) : new BBI(this, var1, var2));
   }

   public IBI method5105(int[] var1, int var2, int var3, int var4, int var5, boolean var6) {
      boolean var7 = false;
      int var8 = var2;

      for(int var9 = 0; var9 < var5; ++var9) {
         for(int var10 = 0; var10 < var4; ++var10) {
            int var11 = var1[var8++] >>> 24;
            if (var11 != 0 && 255 != var11) {
               var7 = true;
               return (IBI)(var7 ? new CBI(this, var1, var2, var3, var4, var5, var6) : new BBI(this, var1, var2, var3, var4, var5, var6));
            }
         }
      }

      return (IBI)(var7 ? new CBI(this, var1, var2, var3, var4, var5, var6) : new BBI(this, var1, var2, var3, var4, var5, var6));
   }

   public IBI method5106(int[] var1, int var2, int var3, int var4, int var5, boolean var6) {
      boolean var7 = false;
      int var8 = var2;

      for(int var9 = 0; var9 < var5; ++var9) {
         for(int var10 = 0; var10 < var4; ++var10) {
            int var11 = var1[var8++] >>> 24;
            if (var11 != 0 && 255 != var11) {
               var7 = true;
               return (IBI)(var7 ? new CBI(this, var1, var2, var3, var4, var5, var6) : new BBI(this, var1, var2, var3, var4, var5, var6));
            }
         }
      }

      return (IBI)(var7 ? new CBI(this, var1, var2, var3, var4, var5, var6) : new BBI(this, var1, var2, var3, var4, var5, var6));
   }

   public IBI method5190(int[] var1, int var2, int var3, int var4, int var5, boolean var6) {
      boolean var7 = false;
      int var8 = var2;

      for(int var9 = 0; var9 < var5; ++var9) {
         for(int var10 = 0; var10 < var4; ++var10) {
            int var11 = var1[var8++] >>> 24;
            if (var11 != 0 && 255 != var11) {
               var7 = true;
               return (IBI)(var7 ? new CBI(this, var1, var2, var3, var4, var5, var6) : new BBI(this, var1, var2, var3, var4, var5, var6));
            }
         }
      }

      return (IBI)(var7 ? new CBI(this, var1, var2, var3, var4, var5, var6) : new BBI(this, var1, var2, var3, var4, var5, var6));
   }

   public IBI method5107(RFI var1, boolean var2) {
      int[] var3 = var1.J;
      byte[] var4 = var1.S;
      int var5 = var1.Z;
      int var6 = var1.F;
      Object var7;
      int[] var8;
      byte[] var9;
      int var10;
      int var11;
      int var12;
      if (var2 && var1.A == null) {
         var8 = new int[var3.length];
         var9 = new byte[var6 * var5];

         for(var10 = 0; var10 < var6; ++var10) {
            var11 = var10 * var5;

            for(var12 = 0; var12 < var5; ++var12) {
               var9[var11 + var12] = var4[var12 + var11];
            }
         }

         for(var10 = 0; var10 < var3.length; ++var10) {
            var8[var10] = var3[var10];
         }

         var7 = new DBI(this, var9, var8, var5, var6);
      } else {
         var8 = new int[var6 * var5];
         var9 = var1.A;
         if (var9 != null) {
            for(var10 = 0; var10 < var6; ++var10) {
               var11 = var5 * var10;

               for(var12 = 0; var12 < var5; ++var12) {
                  var8[var11 + var12] = var3[var4[var11 + var12] & 255] | var9[var12 + var11] << 24;
               }
            }

            var7 = new CBI(this, var8, var5, var6);
         } else {
            for(var10 = 0; var10 < var6; ++var10) {
               var11 = var10 * var5;

               for(var12 = 0; var12 < var5; ++var12) {
                  int var13 = var3[var4[var12 + var11] & 255];
                  var8[var11 + var12] = var13 != 0 ? -16777216 | var13 : 0;
               }
            }

            var7 = new BBI(this, var8, var5, var6);
         }
      }

      ((ZBI)var7).method621(var1.D, var1.I, var1.B, var1.C);
      return (IBI)var7;
   }

   public IBI method5101(RFI var1, boolean var2) {
      int[] var3 = var1.J;
      byte[] var4 = var1.S;
      int var5 = var1.Z;
      int var6 = var1.F;
      Object var7;
      int[] var8;
      byte[] var9;
      int var10;
      int var11;
      int var12;
      if (var2 && var1.A == null) {
         var8 = new int[var3.length];
         var9 = new byte[var6 * var5];

         for(var10 = 0; var10 < var6; ++var10) {
            var11 = var10 * var5;

            for(var12 = 0; var12 < var5; ++var12) {
               var9[var11 + var12] = var4[var12 + var11];
            }
         }

         for(var10 = 0; var10 < var3.length; ++var10) {
            var8[var10] = var3[var10];
         }

         var7 = new DBI(this, var9, var8, var5, var6);
      } else {
         var8 = new int[var6 * var5];
         var9 = var1.A;
         if (var9 != null) {
            for(var10 = 0; var10 < var6; ++var10) {
               var11 = var5 * var10;

               for(var12 = 0; var12 < var5; ++var12) {
                  var8[var11 + var12] = var3[var4[var11 + var12] & 255] | var9[var12 + var11] << 24;
               }
            }

            var7 = new CBI(this, var8, var5, var6);
         } else {
            for(var10 = 0; var10 < var6; ++var10) {
               var11 = var10 * var5;

               for(var12 = 0; var12 < var5; ++var12) {
                  int var13 = var3[var4[var12 + var11] & 255];
                  var8[var11 + var12] = var13 != 0 ? -16777216 | var13 : 0;
               }
            }

            var7 = new BBI(this, var8, var5, var6);
         }
      }

      ((ZBI)var7).method621(var1.D, var1.I, var1.B, var1.C);
      return (IBI)var7;
   }

   public void method5091(int var1, int var2, int var3, int var4, int var5, int var6) {
      if (this.I != null) {
         var3 -= var1;
         var4 -= var2;
         if (var4 == 0) {
            if (var3 >= 0) {
               this.XA(var1, var2, 1 + var3, var5, var6);
            } else {
               this.XA(var1 + var3, var2, -var3 + 1, var5, var6);
            }
         } else if (var3 == 0) {
            if (var4 >= 0) {
               this.G(var1, var2, 1 + var4, var5, var6);
            } else {
               this.G(var1, var2 + var4, 1 + -var4, var5, var6);
            }
         } else {
            if (var3 + var4 < 0) {
               var1 += var3;
               var3 = -var3;
               var2 += var4;
               var4 = -var4;
            }

            int var7;
            int var8;
            int var9;
            int var10;
            int var11;
            int var12;
            int var13;
            if (var3 > var4) {
               var2 <<= 16;
               var2 += 32768;
               var4 <<= 16;
               var7 = (int)Math.floor(0.5D + (double)var4 / (double)var3);
               var3 += var1;
               if (var1 < this.D * -912871679) {
                  var2 += var7 * (this.D * -912871679 - var1);
                  var1 = this.D * -912871679;
               }

               if (var3 >= this.Q * -1416794725) {
                  var3 = -1416794725 * this.Q - 1;
               }

               var8 = var5 >>> 24;
               if (var6 == 0 || var6 == 1 && var8 == 255) {
                  while(var1 <= var3) {
                     var9 = var2 >> 16;
                     if (var9 >= -1278653805 * this.F && var9 < this.J * 63686679) {
                        this.I[var1 + var9 * 692106883 * this.Z] = var5;
                     }

                     var2 += var7;
                     ++var1;
                  }
               } else if (1 == var6) {
                  var5 = (var8 << 24) + (var8 * (var5 & '\uff00') >> 8 & '\uff00') + (var8 * (var5 & 16711935) >> 8 & 16711935);

                  for(var9 = 256 - var8; var1 <= var3; ++var1) {
                     var10 = var2 >> 16;
                     if (var10 >= this.F * -1278653805 && var10 < this.J * 63686679) {
                        var11 = var1 + var10 * this.Z * 692106883;
                        var12 = this.I[var11];
                        var12 = (var9 * (var12 & '\uff00') >> 8 & '\uff00') + ((var12 & 16711935) * var9 >> 8 & 16711935);
                        this.I[var11] = var5 + var12;
                     }

                     var2 += var7;
                  }
               } else {
                  if (2 != var6) {
                     throw new IllegalArgumentException();
                  }

                  while(var1 <= var3) {
                     var9 = var2 >> 16;
                     if (var9 >= this.F * -1278653805 && var9 < this.J * 63686679) {
                        var10 = var9 * 692106883 * this.Z + var1;
                        var11 = this.I[var10];
                        var12 = var5 + var11;
                        var13 = (var11 & 16711935) + (var5 & 16711935);
                        var11 = (var12 - var13 & 65536) + (var13 & 16777472);
                        this.I[var10] = var12 - var11 | var11 - (var11 >>> 8);
                     }

                     var2 += var7;
                     ++var1;
                  }
               }
            } else {
               var1 <<= 16;
               var1 += 32768;
               var3 <<= 16;
               var7 = (int)Math.floor(0.5D + (double)var3 / (double)var4);
               var4 += var2;
               if (var2 < this.F * -1278653805) {
                  var1 += (this.F * -1278653805 - var2) * var7;
                  var2 = this.F * -1278653805;
               }

               if (var4 >= 63686679 * this.J) {
                  var4 = this.J * 63686679 - 1;
               }

               var8 = var5 >>> 24;
               if (var6 == 0 || var6 == 1 && var8 == 255) {
                  while(var2 <= var4) {
                     var9 = var1 >> 16;
                     if (var9 >= this.D * -912871679 && var9 < this.Q * -1416794725) {
                        this.I[this.Z * 692106883 * var2 + var9] = var5;
                     }

                     var1 += var7;
                     ++var2;
                  }
               } else if (1 == var6) {
                  var5 = ((var5 & 16711935) * var8 >> 8 & 16711935) + ((var5 & '\uff00') * var8 >> 8 & '\uff00') + (var8 << 24);

                  for(var9 = 256 - var8; var2 <= var4; ++var2) {
                     var10 = var1 >> 16;
                     if (var10 >= -912871679 * this.D && var10 < -1416794725 * this.Q) {
                        var11 = var10 + 692106883 * this.Z * var2;
                        var12 = this.I[var11];
                        var12 = (var9 * (var12 & 16711935) >> 8 & 16711935) + (var9 * (var12 & '\uff00') >> 8 & '\uff00');
                        this.I[var10 + var2 * 692106883 * this.Z] = var5 + var12;
                     }

                     var1 += var7;
                  }
               } else {
                  if (2 != var6) {
                     throw new IllegalArgumentException();
                  }

                  while(var2 <= var4) {
                     var9 = var1 >> 16;
                     if (var9 >= this.D * -912871679 && var9 < this.Q * -1416794725) {
                        var10 = var9 + var2 * this.Z * 692106883;
                        var11 = this.I[var10];
                        var12 = var5 + var11;
                        var13 = (var11 & 16711935) + (var5 & 16711935);
                        var11 = (var12 - var13 & 65536) + (var13 & 16777472);
                        this.I[var10] = var12 - var11 | var11 - (var11 >>> 8);
                     }

                     var1 += var7;
                     ++var2;
                  }
               }
            }
         }
      }

   }

   public QJI method5109(int var1, int var2, int[] var3, int[] var4) {
      return new TJI(var1, var2, var3, var4);
   }

   public QJI method5110(int var1, int var2, int[] var3, int[] var4) {
      return new TJI(var1, var2, var3, var4);
   }

   public void go(int var1, QJI var2, int var3, int var4) {
      if (this.I != null) {
         TJI var5 = (TJI)var2;
         int[] var6 = var5.Z;
         int[] var7 = var5.I;
         int var8;
         if (63686679 * this.J < var6.length + var4) {
            var8 = this.J * 63686679 - var4;
         } else {
            var8 = var6.length;
         }

         int var9;
         if (this.F * -1278653805 > var4) {
            var9 = this.F * -1278653805 - var4;
            var4 = this.F * -1278653805;
         } else {
            var9 = 0;
         }

         if (var8 - var9 > 0) {
            int var10 = 692106883 * this.Z * var4;

            for(int var11 = var9; var11 < var8; ++var11) {
               int var12 = var3 + var6[var11];
               int var13 = var7[var11];
               if (this.D * -912871679 > var12) {
                  var13 -= -912871679 * this.D - var12;
                  var12 = -912871679 * this.D;
               }

               if (-1416794725 * this.Q < var12 + var13) {
                  var13 = -1416794725 * this.Q - var12;
               }

               var12 += var10;

               for(int var14 = -var13; var14 < 0; ++var14) {
                  this.I[var12++] = var1;
               }

               var10 += this.Z * 692106883;
            }
         }
      }

   }

   public void gg(int var1, QJI var2, int var3, int var4) {
      if (this.I != null) {
         TJI var5 = (TJI)var2;
         int[] var6 = var5.Z;
         int[] var7 = var5.I;
         int var8;
         if (63686679 * this.J < var6.length + var4) {
            var8 = this.J * 63686679 - var4;
         } else {
            var8 = var6.length;
         }

         int var9;
         if (this.F * -1278653805 > var4) {
            var9 = this.F * -1278653805 - var4;
            var4 = this.F * -1278653805;
         } else {
            var9 = 0;
         }

         if (var8 - var9 > 0) {
            int var10 = 692106883 * this.Z * var4;

            for(int var11 = var9; var11 < var8; ++var11) {
               int var12 = var3 + var6[var11];
               int var13 = var7[var11];
               if (this.D * -912871679 > var12) {
                  var13 -= -912871679 * this.D - var12;
                  var12 = -912871679 * this.D;
               }

               if (-1416794725 * this.Q < var12 + var13) {
                  var13 = -1416794725 * this.Q - var12;
               }

               var12 += var10;

               for(int var14 = -var13; var14 < 0; ++var14) {
                  this.I[var12++] = var1;
               }

               var10 += this.Z * 692106883;
            }
         }
      }

   }

   public YJI method5087(int var1, int var2, int[][] var3, int[][] var4, int var5, int var6, int var7) {
      return new ZSI(this, var6, var7, var1, var2, var3, var4, var5);
   }

   public OS method5113(LZI var1, RFI[] var2, boolean var3) {
      int[] var4 = new int[var2.length];
      int[] var5 = new int[var2.length];
      boolean var6 = false;

      for(int var7 = 0; var7 < var2.length; ++var7) {
         var4[var7] = var2[var7].Z;
         var5[var7] = var2[var7].F;
         if (var2[var7].A != null) {
            var6 = true;
         }
      }

      if (var3) {
         if (var6) {
            return new QS(this, var1, var2, var4, var5);
         } else {
            return new TS(this, var1, var2, var4, var5);
         }
      } else if (var6) {
         throw new IllegalArgumentException("");
      } else {
         return new PS(this, var1, var2, var4, var5);
      }
   }

   public void method5115(int var1) {
      VT.UI = var1;
      VT.x = var1;
      if (-922307687 * this.X > 1) {
         throw new IllegalStateException();
      } else {
         this.XA(this.X * -922307687);
         this.B(0);
      }
   }

   public UT method5116(MBI var1, int var2, int var3, int var4, int var5) {
      return new VT(this, var1, var2, var4, var5, var3);
   }

   public int method5126(int var1, int var2) {
      var1 |= 133120;
      return var1 & var2 ^ var2;
   }

   int S(int var1) {
      return this.LZ.method174(var1, 1059221897).F * -2138060883;
   }

   public int method5120(int var1, int var2) {
      var1 |= 133120;
      return var1 & var2 ^ var2;
   }

   public YJI method5121(int var1, int var2, int[][] var3, int[][] var4, int var5, int var6, int var7) {
      return new ZSI(this, var6, var7, var1, var2, var3, var4, var5);
   }

   public void method5093(int var1, int var2, int var3, int var4, int var5, int var6) {
      this.XA(var1, var2, var3, var5, var6);
      this.XA(var1, var4 + var2 - 1, var3, var5, var6);
      this.G(var1, 1 + var2, var4 - 2, var5, var6);
      this.G(var1 + var3 - 1, 1 + var2, var4 - 2, var5, var6);
   }

   public YJI method5123(int var1, int var2, int[][] var3, int[][] var4, int var5, int var6, int var7) {
      return new ZSI(this, var6, var7, var1, var2, var3, var4, var5);
   }

   public LF method5044() {
      return new LF(this.currentThread);
   }

   public YF method5083() {
      WZ var1 = this.I((Runnable)Thread.currentThread());
      return var1.G;
   }

   public LF method5183() {
      WZ var1 = this.I((Runnable)Thread.currentThread());
      return var1.l;
   }

   void method170(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      if (this.I != null && var1 >= this.D * -912871679 && var1 < -1416794725 * this.Q) {
         int var9 = this.Z * 692106883 * var2 + var1;
         int var10 = var4 >>> 24;
         int var11 = var7 + var6;
         int var12 = var8 % var11;
         int var13;
         if (var5 != 0 && (1 != var5 || 255 != var10)) {
            int var14;
            int var15;
            int var16;
            if (1 == var5) {
               var4 = (var10 * (var4 & '\uff00') >> 8 & '\uff00') + ((var4 & 16711935) * var10 >> 8 & 16711935) + (var10 << 24);
               var13 = 256 - var10;

               for(var14 = 0; var14 < var3; var12 %= var11) {
                  if (var14 + var2 >= this.F * -1278653805 && var14 + var2 < 63686679 * this.J && var12 < var6) {
                     var15 = var14 * 692106883 * this.Z + var9;
                     var16 = this.I[var15];
                     var16 = ((var16 & 16711935) * var13 >> 8 & 16711935) + ((var16 & '\uff00') * var13 >> 8 & '\uff00');
                     this.I[var15] = var4 + var16;
                  }

                  ++var14;
                  ++var12;
               }
            } else {
               if (var5 != 2) {
                  throw new IllegalArgumentException();
               }

               for(var13 = 0; var13 < var3; var12 %= var11) {
                  if (var13 + var2 >= this.F * -1278653805 && var2 + var13 < this.J * 63686679 && var12 < var6) {
                     var14 = var13 * this.Z * 692106883 + var9;
                     var15 = this.I[var14];
                     var16 = var4 + var15;
                     int var17 = (var15 & 16711935) + (var4 & 16711935);
                     var15 = (var17 & 16777472) + (var16 - var17 & 65536);
                     this.I[var14] = var16 - var15 | var15 - (var15 >>> 8);
                  }

                  ++var13;
                  ++var12;
               }
            }
         } else {
            for(var13 = 0; var13 < var3; var12 %= var11) {
               if (var13 + var2 >= -1278653805 * this.F && var2 + var13 < this.J * 63686679 && var12 < var6) {
                  this.I[var13 * 692106883 * this.Z + var9] = var4;
               }

               ++var13;
               ++var12;
            }
         }
      }

   }

   public LF method5013() {
      WZ var1 = this.I((Runnable)Thread.currentThread());
      return var1.l;
   }

   public int method5100(int var1, int var2, int var3, int var4, int var5, int var6) {
      int var7 = 0;
      float var8 = (float)var3 * this.O.I[10] + this.O.I[6] * (float)var2 + (float)var1 * this.O.I[2] + this.O.I[14];
      float var9 = (float)var6 * this.O.I[10] + this.O.I[6] * (float)var5 + this.O.I[14] + (float)var4 * this.O.I[2];
      float var10 = (float)var1 * this.O.I[3] + this.O.I[15] + this.O.I[7] * (float)var2 + (float)var3 * this.O.I[11];
      float var11 = (float)var4 * this.O.I[3] + this.O.I[15] + this.O.I[7] * (float)var5 + this.O.I[11] * (float)var6;
      if (var8 < -var10 && var9 < -var11) {
         var7 |= 16;
      } else if (var8 > var10 && var9 > var11) {
         var7 |= 32;
      }

      float var12 = this.O.I[4] * (float)var2 + this.O.I[12] + this.O.I[0] * (float)var1 + this.O.I[8] * (float)var3;
      float var13 = this.O.I[8] * (float)var6 + (float)var4 * this.O.I[0] + this.O.I[12] + this.O.I[4] * (float)var5;
      if (var12 < -var10 && var13 < -var11) {
         var7 |= 1;
      }

      if (var12 > var10 && var13 > var11) {
         var7 |= 2;
      }

      float var14 = (float)var2 * this.O.I[5] + this.O.I[1] * (float)var1 + this.O.I[13] + this.O.I[9] * (float)var3;
      float var15 = (float)var4 * this.O.I[1] + this.O.I[13] + (float)var5 * this.O.I[5] + this.O.I[9] * (float)var6;
      if (var14 < -var10 && var15 < -var11) {
         var7 |= 4;
      }

      if (var14 > var10 && var15 > var11) {
         var7 |= 8;
      }

      return var7;
   }

   public void o(int var1, int var2, int var3, int var4) {
      if (-912871679 * this.D < var1) {
         this.D = var1 * -1291169535;
      }

      if (this.F * -1278653805 < var2) {
         this.F = var2 * 104031131;
      }

      if (this.Q * -1416794725 > var3) {
         this.Q = var3 * -1912131437;
      }

      if (63686679 * this.J > var4) {
         this.J = var4 * 1656090535;
      }

      this.S();
   }

   public GE method172(int var1, int var2, int var3, int var4, int var5, float var6) {
      return null;
   }

   void method174(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      if (this.I != null && var2 >= this.F * -1278653805 && var2 < 63686679 * this.J) {
         int var9 = var2 * 692106883 * this.Z + var1;
         int var10 = var4 >>> 24;
         int var11 = var7 + var6;
         int var12 = var8 % var11;
         int var13;
         if (var5 != 0 && (var5 != 1 || 255 != var10)) {
            int var14;
            int var15;
            if (1 == var5) {
               var4 = (var10 << 24) + ((var4 & 16711935) * var10 >> 8 & 16711935) + ((var4 & '\uff00') * var10 >> 8 & '\uff00');
               var13 = 256 - var10;

               for(var14 = 0; var14 < var3; var12 %= var11) {
                  if (var14 + var1 >= -912871679 * this.D && var14 + var1 < -1416794725 * this.Q && var12 < var6) {
                     var15 = this.I[var9 + var14];
                     var15 = ((var15 & 16711935) * var13 >> 8 & 16711935) + (var13 * (var15 & '\uff00') >> 8 & '\uff00');
                     this.I[var9 + var14] = var4 + var15;
                  }

                  ++var14;
                  ++var12;
               }
            } else {
               if (var5 != 2) {
                  throw new IllegalArgumentException();
               }

               for(var13 = 0; var13 < var3; var12 %= var11) {
                  if (var1 + var13 >= -912871679 * this.D && var13 + var1 < -1416794725 * this.Q && var12 < var6) {
                     var14 = this.I[var9 + var13];
                     var15 = var4 + var14;
                     int var16 = (var4 & 16711935) + (var14 & 16711935);
                     var14 = (var15 - var16 & 65536) + (var16 & 16777472);
                     this.I[var9 + var13] = var15 - var14 | var14 - (var14 >>> 8);
                  }

                  ++var13;
                  ++var12;
               }
            }
         } else {
            for(var13 = 0; var13 < var3; var12 %= var11) {
               if (var13 + var1 >= -912871679 * this.D && var13 + var1 < -1416794725 * this.Q && var12 < var6) {
                  this.I[var13 + var9] = var4;
               }

               ++var13;
               ++var12;
            }
         }
      }

   }

   public XAI method5186(int var1, int var2) {
      return new Y(var1, var2);
   }

   public int za() {
      return 0;
   }

   public void em(boolean var1) {
      WZ var2 = this.I((Runnable)Thread.currentThread());
      var2.z = var1;
   }

   public void fu(int var1, int var2, int var3, int var4, int var5) {
      if (this.I != null && var1 >= this.D * -912871679 && var1 < this.Q * -1416794725) {
         if (var2 < -1278653805 * this.F) {
            var3 -= this.F * -1278653805 - var2;
            var2 = this.F * -1278653805;
         }

         if (var3 + var2 > 63686679 * this.J) {
            var3 = 63686679 * this.J - var2;
         }

         int var6 = var1 + var2 * this.Z * 692106883;
         int var7 = var4 >>> 24;
         int var8;
         if (var5 != 0 && (1 != var5 || 255 != var7)) {
            int var9;
            int var10;
            int var11;
            if (var5 == 1) {
               var4 = (var7 * (var4 & '\uff00') >> 8 & '\uff00') + ((var4 & 16711935) * var7 >> 8 & 16711935) + (var7 << 24);
               var8 = 256 - var7;

               for(var9 = 0; var9 < var3; ++var9) {
                  var10 = var9 * 692106883 * this.Z + var6;
                  var11 = this.I[var10];
                  var11 = (var8 * (var11 & 16711935) >> 8 & 16711935) + ((var11 & '\uff00') * var8 >> 8 & '\uff00');
                  this.I[var10] = var11 + var4;
               }
            } else {
               if (2 != var5) {
                  throw new IllegalArgumentException();
               }

               for(var8 = 0; var8 < var3; ++var8) {
                  var9 = var8 * 692106883 * this.Z + var6;
                  var10 = this.I[var9];
                  var11 = var4 + var10;
                  int var12 = (var10 & 16711935) + (var4 & 16711935);
                  var10 = (var12 & 16777472) + (var11 - var12 & 65536);
                  this.I[var9] = var11 - var10 | var10 - (var10 >>> 8);
               }
            }
         } else {
            for(var8 = 0; var8 < var3; ++var8) {
               this.I[var6 + var8 * this.Z * 692106883] = var4;
            }
         }
      }

   }

   public void method5129(LF var1) {
      this.currentThread = var1;
      this.RA();
   }

   public boolean method5159() {
      return false;
   }

   public void method5131(LF var1) {
      this.currentThread = var1;
      this.RA();
   }

   public void method5169(int var1) {
      VT.UI = var1;
      VT.x = var1;
      if (-922307687 * this.X > 1) {
         throw new IllegalStateException();
      } else {
         this.XA(this.X * -922307687);
         this.B(0);
      }
   }

   public void method5133(YF var1) {
      this.N.I(var1);
      this.RA();
   }

   public void method5134(YF var1) {
      this.N.I(var1);
      this.RA();
   }

   public void hu(float var1) {
      this.M = -1954754855 * (int)(65535.0F * var1);
   }

   public void hs(float var1) {
      this.M = -1954754855 * (int)(65535.0F * var1);
   }

   public UT method5037(MBI var1, int var2, int var3, int var4, int var5) {
      return new VT(this, var1, var2, var4, var5, var3);
   }

   public IBI method5030(int[] var1, int var2, int var3, int var4, int var5, boolean var6) {
      boolean var7 = false;
      int var8 = var2;

      for(int var9 = 0; var9 < var5; ++var9) {
         for(int var10 = 0; var10 < var4; ++var10) {
            int var11 = var1[var8++] >>> 24;
            if (var11 != 0 && 255 != var11) {
               var7 = true;
               return (IBI)(var7 ? new CBI(this, var1, var2, var3, var4, var5, var6) : new BBI(this, var1, var2, var3, var4, var5, var6));
            }
         }
      }

      return (IBI)(var7 ? new CBI(this, var1, var2, var3, var4, var5, var6) : new BBI(this, var1, var2, var3, var4, var5, var6));
   }

   public ECI method5094() {
      return new GCI(this);
   }

   public void method5038(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9) {
      if (this.I != null) {
         var3 -= var1;
         var4 -= var2;
         int var10;
         if (var4 == 0) {
            if (var3 >= 0) {
               this.method174(var1, var2, 1 + var3, var5, var6, var7, var8, var9);
            } else {
               var10 = var8 + var7;
               var9 %= var10;
               var9 = var7 + var10 - var9 - (1 + -var3) % var10;
               var9 %= var10;
               if (var9 < 0) {
                  var9 += var10;
               }

               this.method174(var3 + var1, var2, 1 + -var3, var5, var6, var7, var8, var9);
            }
         } else if (var3 == 0) {
            if (var4 >= 0) {
               this.method170(var1, var2, var4 + 1, var5, var6, var7, var8, var9);
            } else {
               var10 = var8 + var7;
               var9 %= var10;
               var9 = var7 + var10 - var9 - (-var4 + 1) % var10;
               var9 %= var10;
               if (var9 < 0) {
                  var9 += var10;
               }

               this.method170(var1, var4 + var2, 1 + -var4, var5, var6, var7, var8, var9);
            }
         } else {
            var9 <<= 8;
            var7 <<= 8;
            var8 <<= 8;
            var10 = var8 + var7;
            var9 %= var10;
            int var11;
            int var12;
            if (var4 + var3 < 0) {
               var11 = (int)(Math.sqrt((double)(var4 * var4 + var3 * var3)) * 256.0D);
               var12 = var11 % var10;
               var9 = var10 + var7 - var9 - var12;
               var9 %= var10;
               if (var9 < 0) {
                  var9 += var10;
               }

               var1 += var3;
               var3 = -var3;
               var2 += var4;
               var4 = -var4;
            }

            int var13;
            int var14;
            int var15;
            int var16;
            int var17;
            int var18;
            if (var3 > var4) {
               var2 <<= 16;
               var2 += 32768;
               var4 <<= 16;
               var11 = (int)Math.floor(0.5D + (double)var4 / (double)var3);
               var3 += var1;
               var12 = var5 >>> 24;
               var13 = (int)Math.sqrt((double)(65536 + (var11 >> 8) * (var11 >> 8)));
               if (var6 != 0 && (1 != var6 || var12 != 255)) {
                  if (var6 == 1) {
                     var5 = (var12 << 24) + ((var5 & '\uff00') * var12 >> 8 & '\uff00') + (var12 * (var5 & 16711935) >> 8 & 16711935);

                     for(var14 = 256 - var12; var1 <= var3; var9 %= var10) {
                        var15 = var2 >> 16;
                        if (var1 >= this.D * -912871679 && var1 < this.Q * -1416794725 && var15 >= this.F * -1278653805 && var15 < 63686679 * this.J && var9 < var7) {
                           var16 = var1 + var15 * 692106883 * this.Z;
                           var17 = this.I[var16];
                           var17 = ((var17 & 16711935) * var14 >> 8 & 16711935) + (var14 * (var17 & '\uff00') >> 8 & '\uff00');
                           this.I[var16] = var17 + var5;
                        }

                        var2 += var11;
                        ++var1;
                        var9 += var13;
                     }
                  } else {
                     if (2 != var6) {
                        throw new IllegalArgumentException();
                     }

                     while(var1 <= var3) {
                        var14 = var2 >> 16;
                        if (var1 >= this.D * -912871679 && var1 < -1416794725 * this.Q && var14 >= -1278653805 * this.F && var14 < 63686679 * this.J && var9 < var7) {
                           var15 = var1 + var14 * this.Z * 692106883;
                           var16 = this.I[var15];
                           var17 = var16 + var5;
                           var18 = (var16 & 16711935) + (var5 & 16711935);
                           var16 = (var18 & 16777472) + (var17 - var18 & 65536);
                           this.I[var15] = var17 - var16 | var16 - (var16 >>> 8);
                        }

                        var2 += var11;
                        ++var1;
                        var9 += var13;
                        var9 %= var10;
                     }
                  }
               } else {
                  while(var1 <= var3) {
                     var14 = var2 >> 16;
                     if (var1 >= this.D * -912871679 && var1 < -1416794725 * this.Q && var14 >= this.F * -1278653805 && var14 < this.J * 63686679 && var9 < var7) {
                        this.I[this.Z * 692106883 * var14 + var1] = var5;
                     }

                     var2 += var11;
                     ++var1;
                     var9 += var13;
                     var9 %= var10;
                  }
               }
            } else {
               var1 <<= 16;
               var1 += 32768;
               var3 <<= 16;
               var11 = (int)Math.floor((double)var3 / (double)var4 + 0.5D);
               var4 += var2;
               var12 = var5 >>> 24;
               var13 = (int)Math.sqrt((double)((var11 >> 8) * (var11 >> 8) + 65536));
               if (var6 == 0 || 1 == var6 && var12 == 255) {
                  while(var2 <= var4) {
                     var14 = var1 >> 16;
                     if (var2 >= this.F * -1278653805 && var2 < 63686679 * this.J && var14 >= -912871679 * this.D && var14 < -1416794725 * this.Q && var9 < var7) {
                        this.I[var2 * this.Z * 692106883 + var14] = var5;
                     }

                     var1 += var11;
                     ++var2;
                     var9 += var13;
                     var9 %= var10;
                  }
               } else if (var6 == 1) {
                  var5 = (var12 << 24) + ((var5 & 16711935) * var12 >> 8 & 16711935) + ((var5 & '\uff00') * var12 >> 8 & '\uff00');

                  for(var14 = 256 - var12; var2 <= var4; var9 %= var10) {
                     var15 = var1 >> 16;
                     if (var2 >= this.F * -1278653805 && var2 < 63686679 * this.J && var15 >= -912871679 * this.D && var15 < -1416794725 * this.Q && var9 < var7) {
                        var16 = 692106883 * this.Z * var2 + var15;
                        var17 = this.I[var16];
                        var17 = (var14 * (var17 & '\uff00') >> 8 & '\uff00') + (var14 * (var17 & 16711935) >> 8 & 16711935);
                        this.I[692106883 * this.Z * var2 + var15] = var5 + var17;
                     }

                     var1 += var11;
                     ++var2;
                     var9 += var13;
                  }
               } else {
                  if (2 != var6) {
                     throw new IllegalArgumentException();
                  }

                  while(var2 <= var4) {
                     var14 = var1 >> 16;
                     if (var2 >= this.F * -1278653805 && var2 < this.J * 63686679 && var14 >= -912871679 * this.D && var14 < this.Q * -1416794725 && var9 < var7) {
                        var15 = var14 + var2 * 692106883 * this.Z;
                        var16 = this.I[var15];
                        var17 = var16 + var5;
                        var18 = (var16 & 16711935) + (var5 & 16711935);
                        var16 = (var18 & 16777472) + (var17 - var18 & 65536);
                        this.I[var15] = var17 - var16 | var16 - (var16 >>> 8);
                     }

                     var1 += var11;
                     ++var2;
                     var9 += var13;
                     var9 %= var10;
                  }
               }
            }
         }
      }

   }

   public void he(int var1, int var2, int var3) {
      for(int var4 = 0; var4 < this.method5011.length; ++var4) {
         WZ var5 = this.method5011[var4];
         var5.D = 1903335279 * (var1 & 16777215);
         int var6 = 688695183 * var5.D >>> 16 & 255;
         if (var6 < 2) {
            var6 = 2;
         }

         int var7 = 688695183 * var5.D >> 8 & 255;
         if (var7 < 2) {
            var7 = 2;
         }

         int var8 = var5.D * 688695183 & 255;
         if (var8 < 2) {
            var8 = 2;
         }

         var5.D = (var6 << 16 | var7 << 8 | var8) * 1903335279;
         if (var2 < 0) {
            var5.g = false;
         } else {
            var5.g = true;
         }
      }

   }

   public void method5137(boolean var1) {
      this.method581 = var1;
      this.S.I();
   }

   public void method5184(boolean var1) {
      this.method581 = var1;
      this.S.I();
   }

   public boolean method5074() {
      return false;
   }

   public void hg(int var1, float var2, float var3, float var4, float var5, float var6) {
      this.W = (int)(var2 * 65535.0F) * 295067571;
      this.K = -2064023785 * (int)(var3 * 65535.0F);
      float var7 = (float)Math.sqrt((double)(var5 * var5 + var4 * var4 + var6 * var6));
      this.A = (int)(var4 * 65535.0F / var7) * -666627277;
      this.E = (int)(65535.0F * var5 / var7) * 1031065997;
      this.H = 1231602687 * (int)(var6 * 65535.0F / var7);
   }

   public OBI method5140(int var1, int var2, int var3, int var4, int var5, int var6) {
      return null;
   }

   public boolean method5081() {
      return false;
   }

   public OBI method5084(int var1, int var2, int var3, int var4, int var5, int var6) {
      return null;
   }

   public OBI method4986(OBI var1, OBI var2, float var3, OBI var4) {
      return null;
   }

   public OBI method5142(OBI var1, OBI var2, float var3, OBI var4) {
      return null;
   }

   public void method5189(OBI var1) {
   }

   public int method5025(int var1, int var2, int var3, int var4, int var5, int var6) {
      int var7 = 0;
      float var8 = (float)var3 * this.O.I[10] + this.O.I[6] * (float)var2 + (float)var1 * this.O.I[2] + this.O.I[14];
      float var9 = (float)var6 * this.O.I[10] + this.O.I[6] * (float)var5 + this.O.I[14] + (float)var4 * this.O.I[2];
      float var10 = (float)var1 * this.O.I[3] + this.O.I[15] + this.O.I[7] * (float)var2 + (float)var3 * this.O.I[11];
      float var11 = (float)var4 * this.O.I[3] + this.O.I[15] + this.O.I[7] * (float)var5 + this.O.I[11] * (float)var6;
      if (var8 < -var10 && var9 < -var11) {
         var7 |= 16;
      } else if (var8 > var10 && var9 > var11) {
         var7 |= 32;
      }

      float var12 = this.O.I[4] * (float)var2 + this.O.I[12] + this.O.I[0] * (float)var1 + this.O.I[8] * (float)var3;
      float var13 = this.O.I[8] * (float)var6 + (float)var4 * this.O.I[0] + this.O.I[12] + this.O.I[4] * (float)var5;
      if (var12 < -var10 && var13 < -var11) {
         var7 |= 1;
      }

      if (var12 > var10 && var13 > var11) {
         var7 |= 2;
      }

      float var14 = (float)var2 * this.O.I[5] + this.O.I[1] * (float)var1 + this.O.I[13] + this.O.I[9] * (float)var3;
      float var15 = (float)var4 * this.O.I[1] + this.O.I[13] + (float)var5 * this.O.I[5] + this.O.I[9] * (float)var6;
      if (var14 < -var10 && var15 < -var11) {
         var7 |= 4;
      }

      if (var14 > var10 && var15 > var11) {
         var7 |= 8;
      }

      return var7;
   }

   public void method5145() {
   }

   public void c(int var1, int var2, int var3) {
      for(int var4 = 0; var4 < this.method5011.length; ++var4) {
         WZ var5 = this.method5011[var4];
         var5.D = 1903335279 * (var1 & 16777215);
         int var6 = 688695183 * var5.D >>> 16 & 255;
         if (var6 < 2) {
            var6 = 2;
         }

         int var7 = 688695183 * var5.D >> 8 & 255;
         if (var7 < 2) {
            var7 = 2;
         }

         int var8 = var5.D * 688695183 & 255;
         if (var8 < 2) {
            var8 = 2;
         }

         var5.D = (var6 << 16 | var7 << 8 | var8) * 1903335279;
         if (var2 < 0) {
            var5.g = false;
         } else {
            var5.g = true;
         }
      }

   }

   public boolean method5119() {
      return false;
   }

   public int method5170(int var1, int var2) {
      return var1 | var2;
   }

   public void method176(int[] var1) {
      var1[0] = 692106883 * this.Z;
      var1[1] = this.RA * 918677455;
   }

   void method5150(float var1, float var2, float var3, float var4, float var5, float var6) {
   }

   public void method4991(int var1, int var2, int var3, int var4) {
   }

   public void method5175() {
   }

   public void method5153() {
   }

   public void method5154() {
   }

   public void method5155(int var1, ADI var2) {
      for(int var3 = 0; var3 < this.method5011.length; ++var3) {
         this.method5011[var3].F = 329691201 * this.method5011[var3].D;
         this.method5011[var3].O = 1450505545 * var1;
         this.method5011[var3].D = var2.Z * -1634857629;
         this.method5011[var3].e = var2.I * -296597081;
         this.method5011[var3].J = true;
      }

   }

   public void method5156(int var1, ADI var2) {
      for(int var3 = 0; var3 < this.method5011.length; ++var3) {
         this.method5011[var3].F = 329691201 * this.method5011[var3].D;
         this.method5011[var3].O = 1450505545 * var1;
         this.method5011[var3].D = var2.Z * -1634857629;
         this.method5011[var3].e = var2.I * -296597081;
         this.method5011[var3].J = true;
      }

   }

   public IBI method5125(RFI var1, boolean var2) {
      int[] var3 = var1.J;
      byte[] var4 = var1.S;
      int var5 = var1.Z;
      int var6 = var1.F;
      Object var7;
      int[] var8;
      byte[] var9;
      int var10;
      int var11;
      int var12;
      if (var2 && var1.A == null) {
         var8 = new int[var3.length];
         var9 = new byte[var6 * var5];

         for(var10 = 0; var10 < var6; ++var10) {
            var11 = var10 * var5;

            for(var12 = 0; var12 < var5; ++var12) {
               var9[var11 + var12] = var4[var12 + var11];
            }
         }

         for(var10 = 0; var10 < var3.length; ++var10) {
            var8[var10] = var3[var10];
         }

         var7 = new DBI(this, var9, var8, var5, var6);
      } else {
         var8 = new int[var6 * var5];
         var9 = var1.A;
         if (var9 != null) {
            for(var10 = 0; var10 < var6; ++var10) {
               var11 = var5 * var10;

               for(var12 = 0; var12 < var5; ++var12) {
                  var8[var11 + var12] = var3[var4[var11 + var12] & 255] | var9[var12 + var11] << 24;
               }
            }

            var7 = new CBI(this, var8, var5, var6);
         } else {
            for(var10 = 0; var10 < var6; ++var10) {
               var11 = var10 * var5;

               for(var12 = 0; var12 < var5; ++var12) {
                  int var13 = var3[var4[var12 + var11] & 255];
                  var8[var11 + var12] = var13 != 0 ? -16777216 | var13 : 0;
               }
            }

            var7 = new BBI(this, var8, var5, var6);
         }
      }

      ((ZBI)var7).method621(var1.D, var1.I, var1.B, var1.C);
      return (IBI)var7;
   }

   public void ih() {
      for(int var1 = 0; var1 < this.method5011.length; ++var1) {
         this.method5011[var1].D = 950886337 * this.method5011[var1].F;
         this.method5011[var1].J = false;
      }

   }

   public void iv() {
      for(int var1 = 0; var1 < this.method5011.length; ++var1) {
         this.method5011[var1].D = 950886337 * this.method5011[var1].F;
         this.method5011[var1].J = false;
      }

   }

   public IBI method5029(int var1, int var2, boolean var3, boolean var4) {
      return (IBI)(var3 ? new CBI(this, var1, var2) : new BBI(this, var1, var2));
   }

   public void method5158(int var1, int var2, float var3, int var4, int var5, float var6, int var7, int var8, float var9, int var10, int var11, int var12, int var13) {
      boolean var14 = this.I != null;
      boolean var15 = this.C != null;
      if (var14 || var15) {
         WZ var16 = this.I((Runnable)Thread.currentThread());
         FD var17 = var16.K;
         var17.I = false;
         var1 -= -912871679 * this.D;
         var4 -= -912871679 * this.D;
         var7 -= -912871679 * this.D;
         var2 -= this.F * -1278653805;
         var5 -= this.F * -1278653805;
         var8 -= this.F * -1278653805;
         var17.D = var1 < 0 || var1 > var17.J || var4 < 0 || var4 > var17.J || var7 < 0 || var7 > var17.J;
         int var18 = var10 >>> 24;
         if (var13 == 0 || var13 == 1 && 255 == var18) {
            var17.B = 0;
            var17.j = false;
            var17.I(var14, var15, false, (float)var2, (float)var5, (float)var8, (float)var1, (float)var4, (float)var7, var3, var6, var9, var10, var11, var12);
         } else if (1 == var13) {
            var17.B = 255 - var18;
            var17.j = false;
            var17.I(var14, var15, false, (float)var2, (float)var5, (float)var8, (float)var1, (float)var4, (float)var7, var3, var6, var9, var10, var11, var12);
         } else {
            if (2 != var13) {
               throw new IllegalArgumentException();
            }

            var17.B = 128;
            var17.j = true;
            var17.I(var14, var15, false, (float)var2, (float)var5, (float)var8, (float)var1, (float)var4, (float)var7, var3, var6, var9, var10, var11, var12);
         }

         var17.I = true;
      }

   }

   public void ei() {
      this.D = 0;
      this.F = 0;
      this.Q = 2046188857 * this.Z;
      this.J = -482117367 * this.RA;
      this.S();
   }

   public OBI method5028(int var1, int var2, int var3, int var4, int var5, int var6) {
      return null;
   }

   public int method5017(int var1, int var2) {
      var1 |= 133120;
      return var1 & var2 ^ var2;
   }

   public void method5162(float var1, float var2, float var3, float[] var4) {
      float var5 = this.O.I[11] * var3 + var1 * this.O.I[3] + this.O.I[15] + var2 * this.O.I[7];
      float var6 = var3 * this.O.I[8] + this.O.I[12] + this.O.I[0] * var1 + var2 * this.O.I[4];
      float var7 = this.O.I[5] * var2 + this.O.I[1] * var1 + this.O.I[13] + this.O.I[9] * var3;
      float var8 = var1 * this.Y.I[2] + this.Y.I[14] + this.Y.I[6] * var2 + this.Y.I[10] * var3;
      var4[0] = var6 * this.R / var5 + this.c;
      var4[1] = this.U + this.T * var7 / var5;
      var4[2] = var8;
   }

   LJI(Canvas var1, FEI var2, int var3, int var4) {
      this(var2);

      try {
         this.I(var1, var3, var4, 288309230);
         this.I(var1, (byte)-11);
      } catch (Throwable var6) {
         var6.printStackTrace();
         this.H(565330132);
         throw new RuntimeException("");
      }
   }

   public void method5164(float var1, float var2, float var3, float[] var4) {
      float var5 = var3 * this.O.I[10] + this.O.I[2] * var1 + this.O.I[14] + this.O.I[6] * var2;
      float var6 = var3 * this.O.I[11] + this.O.I[15] + this.O.I[3] * var1 + var2 * this.O.I[7];
      if (var5 >= -var6 && var5 <= var6) {
         float var7 = this.O.I[12] + var1 * this.O.I[0] + var2 * this.O.I[4] + var3 * this.O.I[8];
         if (var7 >= -var6 && var7 <= var6) {
            float var8 = this.O.I[5] * var2 + this.O.I[13] + var1 * this.O.I[1] + this.O.I[9] * var3;
            if (var8 >= -var6 && var8 <= var6) {
               float var9 = this.Y.I[10] * var3 + var1 * this.Y.I[2] + this.Y.I[14] + this.Y.I[6] * var2;
               var4[0] = this.c + var7 * this.R / var6;
               var4[1] = this.T * var8 / var6 + this.U;
               var4[2] = var9;
            } else {
               var4[2] = Float.NaN;
               var4[1] = Float.NaN;
               var4[0] = Float.NaN;
            }
         } else {
            var4[2] = Float.NaN;
            var4[1] = Float.NaN;
            var4[0] = Float.NaN;
         }
      } else {
         var4[2] = Float.NaN;
         var4[1] = Float.NaN;
         var4[0] = Float.NaN;
      }

   }

   public ECI method5138() {
      return new GCI(this);
   }

   public XAI method5165(int var1, int var2) {
      return new Y(var1, var2);
   }

   public boolean method5166() {
      return false;
   }

   public void method5167(int var1, int var2, int var3, int var4, int var5, int var6) {
      if (this.I != null) {
         var3 -= var1;
         var4 -= var2;
         if (var4 == 0) {
            if (var3 >= 0) {
               this.XA(var1, var2, 1 + var3, var5, var6);
            } else {
               this.XA(var1 + var3, var2, -var3 + 1, var5, var6);
            }
         } else if (var3 == 0) {
            if (var4 >= 0) {
               this.G(var1, var2, 1 + var4, var5, var6);
            } else {
               this.G(var1, var2 + var4, 1 + -var4, var5, var6);
            }
         } else {
            if (var3 + var4 < 0) {
               var1 += var3;
               var3 = -var3;
               var2 += var4;
               var4 = -var4;
            }

            int var7;
            int var8;
            int var9;
            int var10;
            int var11;
            int var12;
            int var13;
            if (var3 > var4) {
               var2 <<= 16;
               var2 += 32768;
               var4 <<= 16;
               var7 = (int)Math.floor(0.5D + (double)var4 / (double)var3);
               var3 += var1;
               if (var1 < this.D * -912871679) {
                  var2 += var7 * (this.D * -912871679 - var1);
                  var1 = this.D * -912871679;
               }

               if (var3 >= this.Q * -1416794725) {
                  var3 = -1416794725 * this.Q - 1;
               }

               var8 = var5 >>> 24;
               if (var6 == 0 || var6 == 1 && var8 == 255) {
                  while(var1 <= var3) {
                     var9 = var2 >> 16;
                     if (var9 >= -1278653805 * this.F && var9 < this.J * 63686679) {
                        this.I[var1 + var9 * 692106883 * this.Z] = var5;
                     }

                     var2 += var7;
                     ++var1;
                  }
               } else if (1 == var6) {
                  var5 = (var8 << 24) + (var8 * (var5 & '\uff00') >> 8 & '\uff00') + (var8 * (var5 & 16711935) >> 8 & 16711935);

                  for(var9 = 256 - var8; var1 <= var3; ++var1) {
                     var10 = var2 >> 16;
                     if (var10 >= this.F * -1278653805 && var10 < this.J * 63686679) {
                        var11 = var1 + var10 * this.Z * 692106883;
                        var12 = this.I[var11];
                        var12 = (var9 * (var12 & '\uff00') >> 8 & '\uff00') + ((var12 & 16711935) * var9 >> 8 & 16711935);
                        this.I[var11] = var5 + var12;
                     }

                     var2 += var7;
                  }
               } else {
                  if (2 != var6) {
                     throw new IllegalArgumentException();
                  }

                  while(var1 <= var3) {
                     var9 = var2 >> 16;
                     if (var9 >= this.F * -1278653805 && var9 < this.J * 63686679) {
                        var10 = var9 * 692106883 * this.Z + var1;
                        var11 = this.I[var10];
                        var12 = var5 + var11;
                        var13 = (var11 & 16711935) + (var5 & 16711935);
                        var11 = (var12 - var13 & 65536) + (var13 & 16777472);
                        this.I[var10] = var12 - var11 | var11 - (var11 >>> 8);
                     }

                     var2 += var7;
                     ++var1;
                  }
               }
            } else {
               var1 <<= 16;
               var1 += 32768;
               var3 <<= 16;
               var7 = (int)Math.floor(0.5D + (double)var3 / (double)var4);
               var4 += var2;
               if (var2 < this.F * -1278653805) {
                  var1 += (this.F * -1278653805 - var2) * var7;
                  var2 = this.F * -1278653805;
               }

               if (var4 >= 63686679 * this.J) {
                  var4 = this.J * 63686679 - 1;
               }

               var8 = var5 >>> 24;
               if (var6 == 0 || var6 == 1 && var8 == 255) {
                  while(var2 <= var4) {
                     var9 = var1 >> 16;
                     if (var9 >= this.D * -912871679 && var9 < this.Q * -1416794725) {
                        this.I[this.Z * 692106883 * var2 + var9] = var5;
                     }

                     var1 += var7;
                     ++var2;
                  }
               } else if (1 == var6) {
                  var5 = ((var5 & 16711935) * var8 >> 8 & 16711935) + ((var5 & '\uff00') * var8 >> 8 & '\uff00') + (var8 << 24);

                  for(var9 = 256 - var8; var2 <= var4; ++var2) {
                     var10 = var1 >> 16;
                     if (var10 >= -912871679 * this.D && var10 < -1416794725 * this.Q) {
                        var11 = var10 + 692106883 * this.Z * var2;
                        var12 = this.I[var11];
                        var12 = (var9 * (var12 & 16711935) >> 8 & 16711935) + (var9 * (var12 & '\uff00') >> 8 & '\uff00');
                        this.I[var10 + var2 * 692106883 * this.Z] = var5 + var12;
                     }

                     var1 += var7;
                  }
               } else {
                  if (2 != var6) {
                     throw new IllegalArgumentException();
                  }

                  while(var2 <= var4) {
                     var9 = var1 >> 16;
                     if (var9 >= this.D * -912871679 && var9 < this.Q * -1416794725) {
                        var10 = var9 + var2 * this.Z * 692106883;
                        var11 = this.I[var10];
                        var12 = var5 + var11;
                        var13 = (var11 & 16711935) + (var5 & 16711935);
                        var11 = (var12 - var13 & 65536) + (var13 & 16777472);
                        this.I[var10] = var12 - var11 | var11 - (var11 >>> 8);
                     }

                     var1 += var7;
                     ++var2;
                  }
               }
            }
         }
      }

   }

   public void method5168(int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      if (this.I != null) {
         WZ var8 = this.I((Runnable)Thread.currentThread());
         FD var9 = var8.K;
         int var10 = var3 - var1;
         int var11 = var4 - var2;
         int var12 = var10 >= 0 ? var10 : -var10;
         int var13 = var11 >= 0 ? var11 : -var11;
         int var14 = var12;
         if (var12 < var13) {
            var14 = var13;
         }

         if (var14 != 0) {
            int var15 = (var10 << 16) / var14;
            int var16 = (var11 << 16) / var14;
            var10 += var15 >> 16;
            var11 += var16 >> 16;
            if (var16 <= var15) {
               var15 = -var15;
            } else {
               var16 = -var16;
            }

            int var17 = var16 * var6 >> 17;
            int var18 = var16 * var6 + 1 >> 17;
            int var19 = var15 * var6 >> 17;
            int var20 = 1 + var6 * var15 >> 17;
            var1 -= var9.I();
            var2 -= var9.Z();
            int var21 = var17 + var1;
            int var22 = var1 - var18;
            int var23 = var1 + var10 - var18;
            int var24 = var17 + var1 + var10;
            int var25 = var2 + var19;
            int var26 = var2 - var20;
            int var27 = var11 + var2 - var20;
            int var28 = var2 + var11 + var19;
            if (var7 == 0) {
               var9.B = 0;
            } else {
               if (var7 != 1) {
                  throw new IllegalArgumentException();
               }

               var9.B = 255 - (var5 >>> 24);
            }

            this.RA(false);
            var9.D = var21 < 0 || var21 > var9.J || var22 < 0 || var22 > var9.J || var23 < 0 || var23 > var9.J;
            var9.I(true, false, false, (float)var25, (float)var26, (float)var27, (float)var21, (float)var22, (float)var23, 100.0F, 100.0F, 100.0F, var5);
            var9.D = var21 < 0 || var21 > var9.J || var23 < 0 || var23 > var9.J || var24 < 0 || var24 > var9.J;
            var9.I(true, false, false, (float)var25, (float)var27, (float)var28, (float)var21, (float)var23, (float)var24, 100.0F, 100.0F, 100.0F, var5);
            this.RA(true);
         }
      }

   }

   public boolean method5148() {
      return false;
   }

   void method5011(boolean var1, int var2, int var3, float var4, int var5, int var6, int var7) {
      if (this.I != null) {
         if (var5 < 0) {
            var5 = -var5;
         }

         int var8 = var3 - var5;
         if (var8 < -1278653805 * this.F) {
            var8 = -1278653805 * this.F;
         }

         int var9 = 1 + var5 + var3;
         if (var9 > 63686679 * this.J) {
            var9 = 63686679 * this.J;
         }

         int var10 = var8;
         int var11 = var5 * var5;
         int var12 = 0;
         int var13 = var3 - var8;
         int var14 = var13 * var13;
         int var15 = var14 - var13;
         if (var3 > var9) {
            var3 = var9;
         }

         int var16 = var6 >>> 24;
         int var17;
         int var18;
         int var19;
         int var20;
         if (var7 != 0 && (1 != var7 || 255 != var16)) {
            int var21;
            int var22;
            if (1 == var7) {
               var6 = (var16 * (var6 & 16711935) >> 8 & 16711935) + ((var6 & '\uff00') * var16 >> 8 & '\uff00') + (var16 << 24);

               for(var17 = 256 - var16; var10 < var3; var15 -= var13 + var13) {
                  while(var15 <= var11 || var14 <= var11) {
                     var14 += var12 + var12;
                     var15 += var12++ + var12;
                  }

                  var18 = var2 - var12 + 1;
                  if (var18 < -912871679 * this.D) {
                     var18 = -912871679 * this.D;
                  }

                  var19 = var2 + var12;
                  if (var19 > this.Q * -1416794725) {
                     var19 = -1416794725 * this.Q;
                  }

                  var20 = var18 + var10 * 692106883 * this.Z;

                  for(var21 = var18; var21 < var19; ++var21) {
                     if (!var1 || var4 < this.C[var20]) {
                        var22 = this.I[var20];
                        var22 = ((var22 & '\uff00') * var17 >> 8 & '\uff00') + (var17 * (var22 & 16711935) >> 8 & 16711935);
                        this.I[var20] = var22 + var6;
                     }

                     ++var20;
                  }

                  ++var10;
                  var14 -= var13-- + var13;
               }

               var12 = var5;
               var13 = -var13;
               var15 = var13 * var13 + var11;
               var14 = var15 - var5;

               for(var15 -= var13; var10 < var9; var14 += var13++ + var13) {
                  while(var15 > var11 && var14 > var11) {
                     var15 -= var12-- + var12;
                     var14 -= var12 + var12;
                  }

                  var18 = var2 - var12;
                  if (var18 < -912871679 * this.D) {
                     var18 = -912871679 * this.D;
                  }

                  var19 = var12 + var2;
                  if (var19 > -1416794725 * this.Q - 1) {
                     var19 = -1416794725 * this.Q - 1;
                  }

                  var20 = var10 * 692106883 * this.Z + var18;

                  for(var21 = var18; var21 <= var19; ++var21) {
                     if (!var1 || var4 < this.C[var20]) {
                        var22 = this.I[var20];
                        var22 = ((var22 & '\uff00') * var17 >> 8 & '\uff00') + (var17 * (var22 & 16711935) >> 8 & 16711935);
                        this.I[var20] = var22 + var6;
                     }

                     ++var20;
                  }

                  ++var10;
                  var15 += var13 + var13;
               }
            } else {
               if (2 != var7) {
                  throw new IllegalArgumentException();
               }

               int var23;
               while(var10 < var3) {
                  while(var15 <= var11 || var14 <= var11) {
                     var14 += var12 + var12;
                     var15 += var12++ + var12;
                  }

                  var17 = var2 - var12 + 1;
                  if (var17 < -912871679 * this.D) {
                     var17 = -912871679 * this.D;
                  }

                  var18 = var2 + var12;
                  if (var18 > -1416794725 * this.Q) {
                     var18 = -1416794725 * this.Q;
                  }

                  var19 = var17 + this.Z * 692106883 * var10;

                  for(var20 = var17; var20 < var18; ++var20) {
                     if (!var1 || var4 < this.C[var19]) {
                        var21 = this.I[var19];
                        var22 = var21 + var6;
                        var23 = (var21 & 16711935) + (var6 & 16711935);
                        var21 = (var23 & 16777472) + (var22 - var23 & 65536);
                        this.I[var19] = var22 - var21 | var21 - (var21 >>> 8);
                     }

                     ++var19;
                  }

                  ++var10;
                  var14 -= var13-- + var13;
                  var15 -= var13 + var13;
               }

               var12 = var5;
               var13 = -var13;
               var15 = var11 + var13 * var13;
               var14 = var15 - var5;

               for(var15 -= var13; var10 < var9; var14 += var13++ + var13) {
                  while(var15 > var11 && var14 > var11) {
                     var15 -= var12-- + var12;
                     var14 -= var12 + var12;
                  }

                  var17 = var2 - var12;
                  if (var17 < this.D * -912871679) {
                     var17 = -912871679 * this.D;
                  }

                  var18 = var12 + var2;
                  if (var18 > this.Q * -1416794725 - 1) {
                     var18 = -1416794725 * this.Q - 1;
                  }

                  var19 = this.Z * 692106883 * var10 + var17;

                  for(var20 = var17; var20 <= var18; ++var20) {
                     if (!var1 || var4 < this.C[var19]) {
                        var21 = this.I[var19];
                        var22 = var21 + var6;
                        var23 = (var6 & 16711935) + (var21 & 16711935);
                        var21 = (var23 & 16777472) + (var22 - var23 & 65536);
                        this.I[var19] = var22 - var21 | var21 - (var21 >>> 8);
                     }

                     ++var19;
                  }

                  ++var10;
                  var15 += var13 + var13;
               }
            }
         } else {
            while(var10 < var3) {
               while(var15 <= var11 || var14 <= var11) {
                  var14 += var12 + var12;
                  var15 += var12++ + var12;
               }

               var17 = 1 + (var2 - var12);
               if (var17 < this.D * -912871679) {
                  var17 = this.D * -912871679;
               }

               var18 = var12 + var2;
               if (var18 > this.Q * -1416794725) {
                  var18 = -1416794725 * this.Q;
               }

               var19 = var10 * 692106883 * this.Z + var17;

               for(var20 = var17; var20 < var18; ++var20) {
                  if (!var1 || var4 < this.C[var19]) {
                     this.I[var19] = var6;
                  }

                  ++var19;
               }

               ++var10;
               var14 -= var13-- + var13;
               var15 -= var13 + var13;
            }

            var12 = var5;
            var13 = var10 - var3;
            var15 = var13 * var13 + var11;
            var14 = var15 - var5;

            for(var15 -= var13; var10 < var9; var14 += var13++ + var13) {
               while(var15 > var11 && var14 > var11) {
                  var15 -= var12-- + var12;
                  var14 -= var12 + var12;
               }

               var17 = var2 - var12;
               if (var17 < this.D * -912871679) {
                  var17 = -912871679 * this.D;
               }

               var18 = var2 + var12;
               if (var18 > -1416794725 * this.Q - 1) {
                  var18 = this.Q * -1416794725 - 1;
               }

               var19 = var17 + var10 * 692106883 * this.Z;

               for(var20 = var17; var20 <= var18; ++var20) {
                  if (!var1 || var4 < this.C[var19]) {
                     this.I[var19] = var6;
                  }

                  ++var19;
               }

               ++var10;
               var15 += var13 + var13;
            }

            return;
         }
      }

   }

   public void method5090(int var1, int var2, int var3, int var4) {
      this.method170 = 1021645229 * var1;
      this.method172 = var2 * 574739315;
      this.XA = 626158471 * var3;
      this.G = 370599731 * var4;
      this.S();
   }

   public LF method5171() {
      return new LF(this.currentThread);
   }

   public YF method5172() {
      return new YF(this.N);
   }

   public YF method5124() {
      return new YF(this.N);
   }

   public int method5177() {
      return 0;
   }
}
