import java.awt.Point;

public class FJ {
   public boolean I = false;
   int F;
   int append;
   int[][][] toString;
   OG[] x;
   int y = 0;
   int Z = 1387168171;
   FY C = new FY();
   static OG B = new OG(0, 0);

   final void I(int var1) {
      try {
         for(int var2 = 0; var2 < this.append * -431482401; ++var2) {
            this.toString[var2][0] = null;
            this.toString[var2][1] = null;
            this.toString[var2][2] = null;
            this.toString[var2] = null;
         }

         this.x = null;
         this.toString = null;
         this.C.B(-1888417482);
         this.C = null;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ka.a(" + ')');
      }
   }

   FJ(int var1, int var2, int var3) {
      this.F = var2 * 982864511;
      this.append = var1 * 1934811679;
      this.toString = new int[this.append * -431482401][3][var3];
      this.x = new OG[1714711935 * this.F];
   }

   public final int[][][] I(byte var1) {
      try {
         if (-431482401 * this.append != this.F * 1714711935) {
            throw new RuntimeException();
         } else {
            for(int var2 = 0; var2 < this.append * -431482401; ++var2) {
               this.x[var2] = B;
            }

            return this.toString;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ka.b(" + ')');
      }
   }

   public final int[][] I(int var1, byte var2) {
      try {
         if (1714711935 * this.F != this.append * -431482401) {
            if (this.append * -431482401 != 1) {
               OG var3 = this.x[var1];
               if (var3 == null) {
                  this.I = true;
                  if (this.y * -1543676323 >= this.append * -431482401) {
                     OG var4 = (OG)this.C.I(-1469951766);
                     var3 = new OG(var1, var4.S * -1217806945);
                     this.x[var4.J * -1336494225] = null;
                     var4.I(-1460969981);
                  } else {
                     var3 = new OG(var1, -1543676323 * this.y);
                     this.y += 1892836853;
                  }

                  this.x[var1] = var3;
               } else {
                  this.I = false;
               }

               this.C.I((AE)var3, (int)-726505062);
               return this.toString[var3.S * -1217806945];
            } else {
               this.I = var1 != -975728899 * this.Z;
               this.Z = -1387168171 * var1;
               return this.toString[0];
            }
         } else {
            this.I = this.x[var1] == null;
            this.x[var1] = B;
            return this.toString[var1];
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ka.f(" + ')');
      }
   }

   static void I(OU var0, int var1) {
      try {
         var0.J -= -783761378;
         int var2 = var0.H[var0.J * 681479919];
         int var3 = var0.H[1 + 681479919 * var0.J];
         DZI var4 = WFI.C.I(var3, 1588900320);
         if (var4.I(1883696427)) {
            String var5 = var4.Z;
            if (-1 == var2) {
               var0.S[(var0.A += 969361751) * -203050393 - 1] = var5;
            } else {
               var0.S[(var0.A += 969361751) * -203050393 - 1] = OO.I.I(var2, 245040087).I(var3, var5, 1005518410);
            }
         } else {
            int var7 = -388931549 * var4.I;
            if (var2 == -1) {
               var0.H[(var0.J += -391880689) * 681479919 - 1] = var7;
            } else {
               var0.H[(var0.J += -391880689) * 681479919 - 1] = OO.I.I(var2, 245040087).I(var3, var7, (byte)-64);
            }
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ka.o(" + ')');
      }
   }

   public static void I(int var0, int var1, byte var2) {
      try {
         IP.I(var0, var1, -1278555731);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ka.l(" + ')');
      }
   }

   public static void I(int var0, int var1) {
      try {
         if (var0 == 37) {
            GN.L = 3.0F;
         } else if (50 == var0) {
            GN.L = 4.0F;
         } else if (var0 == 75) {
            GN.L = 6.0F;
         } else if (100 == var0) {
            GN.L = 8.0F;
         } else if (200 == var0) {
            GN.L = 16.0F;
         }

         GN.s = 789877945;
         GN.s = 789877945;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ka.cw(" + ')');
      }
   }

   static final void I(HSI var0, OU var1, byte var2) {
      try {
         LZI var3 = var0.I(DZI.F, XEI.XI, (byte)-46);
         int var4 = var1.H[(var1.J -= -391880689) * 681479919];
         Point var5 = var3.I(var0.hI, var0.g * -2093041337, var0.RI * 418216501, var4, WI.D, 946663112);
         var1.H[(var1.J += -391880689) * 681479919 - 1] = var5.x;
         var1.H[(var1.J += -391880689) * 681479919 - 1] = var5.y;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ka.qr(" + ')');
      }
   }

   public static SE I(int var0, int var1, int var2, int var3, int var4, int var5) {
      try {
         if (FW.J.L.I(-2141800162) != 0 && var1 != 0 && AN.E * -991384187 < 50 && -1 != var0) {
            SE var6 = new SE((byte)1, var0, var1, var2, var3, 0, var4, (IR)null);
            AN.G[(AN.E += -598588595) * -991384187 - 1] = var6;
            return var6;
         } else {
            return null;
         }
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "ka.n(" + ')');
      }
   }
}
