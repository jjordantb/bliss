final class DJ implements QSI {
   public Object method131(byte[] var1, LZI var2, boolean var3, int var4) {
      try {
         return FT.P.method5092(var2, RFI.I(var1), var3);
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "k.a(" + ')');
      }
   }

   public Object method130(byte[] var1, LZI var2, boolean var3) {
      return FT.P.method5092(var2, RFI.I(var1), var3);
   }

   public Object method132(byte[] var1, LZI var2, boolean var3) {
      return FT.P.method5092(var2, RFI.I(var1), var3);
   }

   static XO I(ZR var0, byte var1) {
      try {
         XO var2;
         if (XO.I == null) {
            var2 = new XO();
         } else {
            var2 = XO.I;
            XO.I = XO.I.C;
            var2.C = null;
            XO.B -= -1998519535;
         }

         var2.Z = var0;
         return var2;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "k.a(" + ')');
      }
   }

   public static void I(HZ var0, IZ var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, int var11) {
      try {
         KZ.B = var0;
         KZ.E = var1;
         KZ.C = var2 * 295365919;
         KZ.F = -1224770727 * var3;
         KZ.D = var4 * -1586864867;
         KZ.S = 1104541761 * var5;
         IV.F = 1351228359 * var6;
         KZ.J = 838462141 * var7;
         QO.Z = var8 * 339871807;
         JJI.S = null;
         HW.F = null;
         RT.L = null;
         WW.J = var9 * 1589600979;
         KZ.I = var10 * -674457001;
         ZO.I(-1268692886);
         DT.J = true;
      } catch (RuntimeException var13) {
         throw DQ.I(var13, "k.a(" + ')');
      }
   }

   static BQ I(REI var0, int var1) {
      try {
         int var2 = var0.I();
         int var3 = var0.I();
         int var4 = var0.I();
         int[] var5 = new int[var4];

         for(int var6 = 0; var6 < var4; ++var6) {
            var5[var6] = var0.I();
         }

         return new BQ(var2, var3, var5);
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "k.p(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.J -= -1175642067;
         int var2 = var0.H[var0.J * 681479919];
         int var3 = var0.H[681479919 * var0.J + 1];
         int var4 = var0.H[2 + 681479919 * var0.J];
         AZI.I(var2, (byte)83);
         QQ.I(IU.F[var2 >>> 16], var2 & '\uffff', var3, var4, var0.c, var0, -782842809);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "k.ba(" + ')');
      }
   }
}
