public class KI extends EI {
   IBI method5019;

   void method1414(boolean var1, int var2, int var3) {
      int var4 = this.I(-1625124707) * -944287579 * this.C.D / 10000;
      int[] var5 = new int[4];
      FT.P.qa(var5);
      FT.P.r(var2, var3 + 2, var2 + var4, this.C.A * -1387457793 + var3);
      this.method5019.Z(var2, 2 + var3, this.C.D * -944287579, -1387457793 * this.C.A);
      FT.P.r(var5[0], var5[1], var5[2], var5[3]);
   }

   public void method53(int var1) {
      try {
         super.method53(567803385);
         this.method5019 = NV.I(this.I, ((NI)this.C).G * -1056757525, (byte)-76);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "zs.a(" + ')');
      }
   }

   void method1411(boolean var1, int var2, int var3, int var4) {
      try {
         int var5 = this.I(1618885491) * -944287579 * this.C.D / 10000;
         int[] var6 = new int[4];
         FT.P.qa(var6);
         FT.P.r(var2, var3 + 2, var2 + var5, this.C.A * -1387457793 + var3);
         this.method5019.Z(var2, 2 + var3, this.C.D * -944287579, -1387457793 * this.C.A);
         FT.P.r(var6[0], var6[1], var6[2], var6[3]);
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "zs.r(" + ')');
      }
   }

   KI(KJ var1, KJ var2, NI var3) {
      super(var1, var2, var3);
   }

   public boolean method52(int var1) {
      try {
         return !super.method52(-1288443228) ? false : this.I.D(-1056757525 * ((NI)this.C).G, -457216440);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "zs.b(" + ')');
      }
   }

   void method1409(boolean var1, int var2, int var3) {
      FT.P.method5019(var2 - 2, var3, this.C.D * -944287579 + 4, 2 + this.C.A * -1387457793, ((NI)this.C).H * 1514768717, 0);
      FT.P.method5019(var2 - 1, var3 + 1, this.C.D * -944287579 + 2, -1387457793 * this.C.A, 0, 0);
   }

   public boolean method57() {
      return !super.method52(-2146778663) ? false : this.I.D(-1056757525 * ((NI)this.C).G, -457216440);
   }

   public boolean method54() {
      return !super.method52(1006079243) ? false : this.I.D(-1056757525 * ((NI)this.C).G, -457216440);
   }

   void method1412(boolean var1, int var2, int var3, int var4) {
      try {
         FT.P.method5019(var2 - 2, var3, this.C.D * -944287579 + 4, 2 + this.C.A * -1387457793, ((NI)this.C).H * 1514768717, 0);
         FT.P.method5019(var2 - 1, var3 + 1, this.C.D * -944287579 + 2, -1387457793 * this.C.A, 0, 0);
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "zs.x(" + ')');
      }
   }

   void method1413(boolean var1, int var2, int var3) {
      int var4 = this.I(1173142113) * -944287579 * this.C.D / 10000;
      int[] var5 = new int[4];
      FT.P.qa(var5);
      FT.P.r(var2, var3 + 2, var2 + var4, this.C.A * -1387457793 + var3);
      this.method5019.Z(var2, 2 + var3, this.C.D * -944287579, -1387457793 * this.C.A);
      FT.P.r(var5[0], var5[1], var5[2], var5[3]);
   }

   public boolean method59() {
      return !super.method52(1700813633) ? false : this.I.D(-1056757525 * ((NI)this.C).G, -457216440);
   }

   void method1415(boolean var1, int var2, int var3) {
      int var4 = this.I(1200646093) * -944287579 * this.C.D / 10000;
      int[] var5 = new int[4];
      FT.P.qa(var5);
      FT.P.r(var2, var3 + 2, var2 + var4, this.C.A * -1387457793 + var3);
      this.method5019.Z(var2, 2 + var3, this.C.D * -944287579, -1387457793 * this.C.A);
      FT.P.r(var5[0], var5[1], var5[2], var5[3]);
   }

   void method1416(boolean var1, int var2, int var3) {
      int var4 = this.I(1506402112) * -944287579 * this.C.D / 10000;
      int[] var5 = new int[4];
      FT.P.qa(var5);
      FT.P.r(var2, var3 + 2, var2 + var4, this.C.A * -1387457793 + var3);
      this.method5019.Z(var2, 2 + var3, this.C.D * -944287579, -1387457793 * this.C.A);
      FT.P.r(var5[0], var5[1], var5[2], var5[3]);
   }

   void method1410(boolean var1, int var2, int var3) {
      FT.P.method5019(var2 - 2, var3, this.C.D * -944287579 + 4, 2 + this.C.A * -1387457793, ((NI)this.C).H * 1514768717, 0);
      FT.P.method5019(var2 - 1, var3 + 1, this.C.D * -944287579 + 2, -1387457793 * this.C.A, 0, 0);
   }

   public void method55() {
      super.method53(-1809113492);
      this.method5019 = NV.I(this.I, ((NI)this.C).G * -1056757525, (byte)-90);
   }

   void method1417(boolean var1, int var2, int var3) {
      FT.P.method5019(var2 - 2, var3, this.C.D * -944287579 + 4, 2 + this.C.A * -1387457793, ((NI)this.C).H * 1514768717, 0);
      FT.P.method5019(var2 - 1, var3 + 1, this.C.D * -944287579 + 2, -1387457793 * this.C.A, 0, 0);
   }
}
