public class DU {
   public static int append = 4;

   DU() throws Throwable {
      throw new Error();
   }

   static final void I(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.W.Z(-2013953489) == 2 ? 1 : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "qf.ajw(" + ')');
      }
   }
}
