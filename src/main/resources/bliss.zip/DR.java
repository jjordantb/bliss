public class DR extends ZR {
   FN YA;
   UT append;

   public HP method4358(GSI var1, byte var2) {
      return null;
   }

   boolean method4350(GSI var1, int var2, int var3, byte var4) {
      return false;
   }

   boolean method4366(int var1) {
      return false;
   }

   boolean method4399(byte var1) {
      try {
         if (this.append != null) {
            return !this.append.u();
         } else {
            return true;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "akx.bf(" + ')');
      }
   }

   void method4377() {
   }

   void method4355(GSI var1, IR var2, int var3, int var4, int var5, boolean var6, int var7) {
   }

   boolean method4384() {
      return false;
   }

   KP method4370(GSI var1) {
      if (this.append == null) {
         this.append = this.YA.I(var1, 222993997);
      }

      if (this.append != null) {
         LF var2 = var1.method5178();
         LF var3 = this.J();
         ZJ var4 = this.I();
         var2.I(var3);
         BP var5 = this.H.E[this.K][(int)var4.I.I >> 9][(int)var4.I.Z >> 9];
         if (var5 != null && var5.J != null) {
            var2.C(0.0F, (float)(-var5.J.O), 0.0F);
         }

         this.append.method4739(var2, (KN)null, 0);
      }

      return null;
   }

   void method4357(GSI var1, int var2) {
   }

   boolean method4372(GSI var1, int var2, int var3) {
      return false;
   }

   public int method4361(int var1) {
      try {
         return this.append != null ? this.append.YA() : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "akx.bm(" + ')');
      }
   }

   boolean method4353() {
      if (this.append != null) {
         return !this.append.u();
      } else {
         return true;
      }
   }

   boolean method4365() {
      if (this.append != null) {
         return !this.append.u();
      } else {
         return true;
      }
   }

   public HP method4367(GSI var1) {
      return null;
   }

   void method4371(GSI var1) {
   }

   public int method4379() {
      return this.append != null ? this.append.YA() : 0;
   }

   public HP method4368(GSI var1) {
      return null;
   }

   void method4398(byte var1) {
   }

   void method4373(GSI var1) {
   }

   KP method4394(GSI var1, int var2) {
      try {
         if (this.append == null) {
            this.append = this.YA.I(var1, 809073544);
         }

         if (this.append != null) {
            LF var3 = var1.method5178();
            LF var4 = this.J();
            ZJ var5 = this.I();
            var3.I(var4);
            BP var6 = this.H.E[this.K][(int)var5.I.I >> 9][(int)var5.I.Z >> 9];
            if (var6 != null && var6.J != null) {
               var3.C(0.0F, (float)(-var6.J.O), 0.0F);
            }

            this.append.method4739(var3, (KN)null, 0);
         }

         return null;
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "akx.bo(" + ')');
      }
   }

   DR(AP var1, FN var2, int var3, int var4, int var5, int var6, int var7) {
      super(var1, var3, var4, var5, var6, var7, var5 >> 9, var5 >> 9, var7 >> 9, var7 >> 9, false, (byte)0);
      this.YA = var2;
   }

   boolean method4352(GSI var1, int var2, int var3) {
      return false;
   }

   void method4375(GSI var1, IR var2, int var3, int var4, int var5, boolean var6) {
   }

   void method4388(GSI var1, IR var2, int var3, int var4, int var5, boolean var6) {
   }

   boolean method4386() {
      return false;
   }

   void method4378() {
   }

   boolean method4374() {
      if (this.append != null) {
         return !this.append.u();
      } else {
         return true;
      }
   }

   public int method4380() {
      return this.append != null ? this.append.YA() : 0;
   }

   public int method4381() {
      return this.append != null ? this.append.YA() : 0;
   }

   boolean method4369() {
      return this.append != null ? this.append.i() : false;
   }

   boolean method4382() {
      return this.append != null ? this.append.i() : false;
   }

   boolean method4349() {
      return this.append != null ? this.append.i() : false;
   }

   boolean method4383() {
      return this.append != null ? this.append.i() : false;
   }

   boolean method4351() {
      return this.append != null ? this.append.i() : false;
   }

   boolean method4385(GSI var1, int var2, int var3) {
      return false;
   }

   boolean method4400() {
      return false;
   }

   boolean method4376(short var1) {
      try {
         return this.append != null ? this.append.i() : false;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "akx.be(" + ')');
      }
   }

   boolean method4387() {
      return false;
   }
}
