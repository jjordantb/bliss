public abstract class AZ {
   public CEI I;
   public CEI Z;
   public OAI C;
   protected NJI B;
   public YF D = new YF();
   public YF F = new YF();
   public YF J = new YF();
   public int S;
   public CC A;

   public abstract void method1525();

   public abstract void method1526(int var1, int var2);

   public abstract void method1527();

   public abstract void method1528();

   public abstract void method1529(int var1, int var2);

   public abstract void method1530(int var1, int var2);

   public abstract void method1531();

   public abstract void method1532();

   public abstract void method1533();

   AZ(NJI var1) {
      this.B = var1;
   }

   public abstract void method1534();

   public abstract void method1535();

   public abstract void method1536();

   public abstract void method1537();

   public abstract void method1538();
}
