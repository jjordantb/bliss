public class GFI extends LDI {
   int Z;
   int append;
   int toString;
   int C;
   int B;
   int D;

   public void method866(int var1) {
      try {
         PFI.L[this.append * 958596181].I(0, -1291875097);
         PFI.L[this.B * 940626959].I(1, -853378806);
         XEI.jZ = 0;
         XEI.aZ = -1367521861 * this.toString;
         XEI.MB = 0;
         XEI.EB = 2019692335 * this.D;
         XEI.kZ = -970762691 * this.C;
         XEI.sZ = -2694169;
         XEI.eZ = this.Z * -1957420531;
         EE.V = -734758223;
         EU.I((byte)66);
         XEI.vI = true;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "xp.f(" + ')');
      }
   }

   public void method869() {
      PFI.L[this.append * 958596181].I(0, -577755381);
      PFI.L[this.B * 940626959].I(1, 1173943462);
      XEI.jZ = 0;
      XEI.aZ = -1367521861 * this.toString;
      XEI.MB = 0;
      XEI.EB = 2019692335 * this.D;
      XEI.kZ = -970762691 * this.C;
      XEI.sZ = -2694169;
      XEI.eZ = this.Z * -1957420531;
      EE.V = -734758223;
      EU.I((byte)83);
      XEI.vI = true;
   }

   public void method868() {
      PFI.L[this.append * 958596181].I(0, -2120641956);
      PFI.L[this.B * 940626959].I(1, -1465561982);
      XEI.jZ = 0;
      XEI.aZ = -1367521861 * this.toString;
      XEI.MB = 0;
      XEI.EB = 2019692335 * this.D;
      XEI.kZ = -970762691 * this.C;
      XEI.sZ = -2694169;
      XEI.eZ = this.Z * -1957420531;
      EE.V = -734758223;
      EU.I((byte)78);
      XEI.vI = true;
   }

   GFI(REI var1) {
      super(var1);
      this.append = var1.C() * 1053415677;
      this.B = var1.C() * -289957137;
      this.toString = var1.C() * -1654642079;
      this.Z = var1.C() * 456781431;
      this.D = var1.C() * -1191092803;
      this.C = var1.C() * 512797893;
   }

   static void I(YF var0, boolean var1, float var2, float var3, float var4, float var5, int var6, int var7, int var8) {
      try {
         int var9 = XEI.mI.J(-115794055);
         int var10 = XEI.mI.Z((byte)-118);
         var0.I(var2, var3, var4, var5, (float)var10, (float)var9, (float)var6, (float)var7);
      } catch (RuntimeException var11) {
         throw DQ.I(var11, "xp.fj(" + ')');
      }
   }

   static final void I(QEI var0, int var1) {
      try {
         for(int var2 = 0; var2 < -1281683379 * C.A; ++var2) {
            int var3 = C.E[var2];
            PEI var4 = XEI.MC[var3];
            int var5 = var0.I();
            if ((var5 & 2) != 0) {
               var5 += var0.I() << 8;
            }

            if ((var5 & 1024) != 0) {
               var5 += var0.I() << 16;
            }

            SE.I(var0, var3, var4, var5);
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "xp.d(" + ')');
      }
   }

   static final void B(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = -2005990483 * TQ.e;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "xp.ahn(" + ')');
      }
   }
}
