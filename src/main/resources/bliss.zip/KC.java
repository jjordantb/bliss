public class KC {
   boolean I;
   int Z;
   byte C;
   short B;
   short D;
   byte F;
   short J;
   int S;

   KC(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, boolean var10, int var11) {
      this.Z = 1348854581 * var1;
      this.D = (short)var5;
      this.J = (short)var6;
      this.B = (short)var7;
      this.F = (byte)var8;
      this.C = (byte)var9;
      this.I = var10;
      this.S = -44074183 * var11;
   }

   public static void I(int var0) {
      try {
         if (WA.B != null) {
            WA.B.C((byte)-63);
         }

         if (JY.D != null) {
            while(true) {
               try {
                  JY.D.join();
                  break;
               } catch (InterruptedException var2) {
                  ;
               }
            }
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aq.y(" + ')');
      }
   }

   static final void I(GSI var0, int var1, int var2, int var3, int var4, int var5) {
      try {
         var0.r(var1, var2, var1 + var3, var2 + var4);
         var0.I(var1, var2, var3, var4, -16777216, (byte)7);
         if (GN.d * -1289394455 >= 100) {
            float var6 = (float)GN.Q / (float)GN.P;
            int var7 = var3;
            int var8 = var4;
            if (var6 < 1.0F) {
               var8 = (int)(var6 * (float)var3);
            } else {
               var7 = (int)((float)var4 / var6);
            }

            var1 += (var3 - var7) / 2;
            var2 += (var4 - var8) / 2;
            if (JA.E == null || JA.E.method623() != var3 || JA.E.method625() != var4) {
               GN.I(GN.U, GN.O + GN.Q, GN.U + GN.P, GN.O, var1, var2, var7 + var1, var8 + var2);
               GN.I(var0);
               JA.E = var0.method5033(var1, var2, var7, var8, false);
            }

            JA.E.I(var1, var2);
            int var9 = var7 * 1484045541 * GN.f / GN.P;
            int var10 = 1464638883 * BV.M * var8 / GN.Q;
            int var11 = var1 + var7 * NU.J * 331474003 / GN.P;
            int var12 = var8 + var2 - 1786832569 * ES.D * var8 / GN.Q - var10;
            int var13 = -1996554240;
            if (ZV.I == XEI.mD) {
               var13 = -1996488705;
            }

            var0.B(var11, var12, var9, var10, var13, 1);
            var0.method5019(var11, var12, var9, var10, var13, 0);
            if (JZ.t * -1983068885 > 0) {
               int var14;
               if (-1581933633 * QFI.D > 50) {
                  var14 = 500 - QFI.D * 680266427;
               } else {
                  var14 = 680266427 * QFI.D;
               }

               for(XM var15 = (XM)GN.N.Z(1766612795); var15 != null; var15 = (XM)GN.N.B(49146)) {
                  HQ var16 = GN.W.I(-530122905 * var15.E, -1892291274);
                  if (EW.I(var16, 1502593597)) {
                     int var17;
                     int var18;
                     if (GN.l * -271159611 == var15.E * -530122905) {
                        var17 = var7 * 2122110429 * var15.A / GN.P + var1;
                        var18 = var2 + (GN.Q - var15.H * -372920341) * var8 / GN.Q;
                        var0.I(var17 - 2, var18 - 2, 4, 4, var14 << 24 | 16776960, (byte)7);
                     } else if (-1 != -484575331 * GN.g && -804513353 * var16.e == GN.g * -484575331) {
                        var17 = var1 + 2122110429 * var15.A * var7 / GN.P;
                        var18 = var8 * (GN.Q - var15.H * -372920341) / GN.Q + var2;
                        var0.I(var17 - 2, var18 - 2, 4, 4, var14 << 24 | 16776960, (byte)7);
                     }
                  }
               }
            }
         }

      } catch (RuntimeException var19) {
         throw DQ.I(var19, "aq.br(" + ')');
      }
   }

   public static XA I(int var0, int var1, int var2) {
      try {
         XA var3 = new XA();
         var3.q = -1780317135;
         var3.r = 599015853;
         var3.t = (1 + var0 + 5) * -2121339651;
         var3.u = (5 + var1 + 1) * -1973125931;
         var3.v = new int[843157589 * var3.t][var3.u * -16196483];
         var3.I(-1639552658);
         return var3;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aq.a(" + ')');
      }
   }
}
