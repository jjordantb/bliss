import java.util.Iterator;

public abstract class JT {
   int B = 570832405;
   IY Z = new IY();
   long I = -142159167877835417L;
   long append = -3541606857845020581L;
   int hasNext = -1631848437;
   public static int[] C;

   abstract void method4612(REI var1, PM var2);

   abstract void method4613();

   void I(int var1) {
      try {
         this.Z.I((byte)1);
         this.append = -3541606857845020581L;
         this.I = -142159167877835417L;
         this.B = 570832405;
         this.hasNext = -1631848437;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "po.f(" + ')');
      }
   }

   int I(PM var1, int var2, byte var3) {
      try {
         long var4;
         if (-1L == this.append * 2660634464725530669L) {
            var4 = (long)var2;
         } else {
            var4 = var1.method3549((byte)97) - 2660634464725530669L * this.append;
            if (var4 > (long)var2) {
               var4 = (long)var2;
            }
         }

         this.append = var1.method3549((byte)19) * 3541606857845020581L;
         return (int)var4;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "po.p(" + ')');
      }
   }

   abstract int method4616(int var1);

   abstract void method4617(REI var1, PM var2, byte var3);

   abstract void method4618(byte var1);

   abstract boolean method4619(int var1);

   void I(PM var1, int var2) {
      try {
         this.Z.I((AE)var1, (int)357494730);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "po.b(" + ')');
      }
   }

   abstract void method4621();

   abstract void method4622();

   abstract boolean method4623();

   abstract boolean method4624();

   abstract PK method4625();

   void Z(int var1) {
      try {
         if (this.method4619(-304373014)) {
            PK var2 = null;
            int var3 = 0;
            int var4 = 0;
            int var5 = 0;
            Iterator var6 = this.Z.iterator();

            label107:
            while(true) {
               while(true) {
                  if (!var6.hasNext()) {
                     break label107;
                  }

                  PM var7 = (PM)var6.next();
                  if (var2 != null && 385051775 * var2.J.A - var3 >= 252 - (6 + this.method4616(-1861387813))) {
                     if (var1 <= 775068819) {
                        throw new IllegalStateException();
                     }
                     break label107;
                  }

                  var7.I(-1460969981);
                  int var8 = var7.method3560(-1730629098);
                  if (var8 < -1) {
                     var8 = -1;
                  } else if (var8 > 65534) {
                     var8 = 65534;
                  }

                  int var9 = var7.method3547((byte)55);
                  if (var9 < -1) {
                     var9 = -1;
                  } else if (var9 > 65534) {
                     var9 = 65534;
                  }

                  if (var9 == 954406595 * this.B && -782291875 * this.hasNext == var8) {
                     var7.method3550(2126248838);
                  } else {
                     if (var2 == null) {
                        var2 = this.method4633((byte)-59);
                        var2.J.F(0);
                        var3 = 385051775 * var2.J.A;
                        var2.J.A += 232826622;
                        var4 = 0;
                        var5 = 0;
                     }

                     int var10;
                     int var11;
                     int var12;
                     if (-1L != this.I * 8383148474145196457L) {
                        var10 = var9 - this.B * 954406595;
                        var11 = var8 - -782291875 * this.hasNext;
                        var12 = (int)((var7.method3549((byte)19) - 8383148474145196457L * this.I) / 20L);
                        var4 = (int)((long)var4 + (var7.method3549((byte)70) - this.I * 8383148474145196457L) % 20L);
                     } else {
                        var10 = var9;
                        var11 = var8;
                        var12 = Integer.MAX_VALUE;
                     }

                     this.B = -570832405 * var9;
                     this.hasNext = var8 * 1631848437;
                     if (var12 < 8 && var10 >= -32 && var10 <= 31 && var11 >= -32 && var11 <= 31) {
                        var10 += 32;
                        var11 += 32;
                        var2.J.Z(var11 + (var10 << 6) + (var12 << 12), 16711935);
                     } else if (var12 < 32 && var10 >= -128 && var10 <= 127 && var11 >= -128 && var11 <= 127) {
                        var10 += 128;
                        var11 += 128;
                        var2.J.F(128 + var12);
                        var2.J.Z((var10 << 8) + var11, 16711935);
                     } else if (var12 < 32) {
                        var2.J.F(var12 + 192);
                        if (-1 != var9 && -1 != var8) {
                           var2.J.B(var9 | var8 << 16, -1192850117);
                        } else {
                           var2.J.B(Integer.MIN_VALUE, -1667030496);
                        }
                     } else {
                        var2.J.Z((var12 & 8191) + '\ue000', 16711935);
                        if (var9 != -1 && var8 != -1) {
                           var2.J.B(var9 | var8 << 16, 84476800);
                        } else {
                           var2.J.B(Integer.MIN_VALUE, -1243424394);
                        }
                     }

                     ++var5;
                     this.method4617(var2.J, var7, (byte)0);
                     this.I = var7.method3549((byte)123) * 142159167877835417L;
                     var7.method3550(1701654239);
                  }
               }
            }

            if (var2 != null) {
               var2.J.A(385051775 * var2.J.A - var3, (byte)-33);
               int var14 = 385051775 * var2.J.A;
               var2.J.A = var3 * 116413311;
               var2.J.F(var4 / var5);
               var2.J.F(var4 % var5);
               var2.J.A = 116413311 * var14;
               XEI.eI.I(var2, (byte)-85);
            }
         }

         this.method4618((byte)1);
      } catch (RuntimeException var13) {
         throw DQ.I(var13, "po.a(" + ')');
      }
   }

   abstract void method4627(REI var1, PM var2);

   abstract int method4628();

   abstract int method4629();

   abstract void method4630(REI var1, PM var2);

   abstract PK method4631();

   abstract void method4632(REI var1, PM var2);

   abstract PK method4633(byte var1);

   abstract boolean method4634();

   abstract int method4635();

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = (int)(Math.random() * (double)var2);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "po.yq(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var0.D.J;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "po.xq(" + ')');
      }
   }

   static final void I(OU var0, short var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         EJ.I(var3, var4, var0, -533196439);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "po.eg(" + ')');
      }
   }
}
