public class ER extends SR implements HAI {
   boolean KA;
   UT PA;
   GJI YA;
   int append;
   boolean i;
   byte m;
   CX method4739;
   boolean method4745;
   HP method4755;
   boolean method4784;

   public HP method4358(GSI var1, byte var2) {
      try {
         SF var3 = this.I().I;
         if (this.method4755 == null) {
            this.method4755 = TY.I((int)var3.I, (int)var3.C, (int)var3.Z, this.F(var1, 0, (byte)68), 2029931481);
         }

         return this.method4755;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "wo.bc(" + ')');
      }
   }

   boolean method4369() {
      return this.PA != null ? this.PA.i() : false;
   }

   public int method4361(int var1) {
      try {
         return this.PA != null ? this.PA.YA() : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wo.bm(" + ')');
      }
   }

   UT F(GSI var1, int var2, byte var3) {
      try {
         if (this.PA != null && var1.method5017(this.PA.m(), var2) == 0) {
            return this.PA;
         } else {
            ZY var4 = this.KA(var1, var2, false, -1886813239);
            return var4 != null ? (UT)var4.I : null;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "wo.by(" + ')');
      }
   }

   ZY KA(GSI var1, int var2, boolean var3, int var4) {
      try {
         KEI var5 = this.method4739.C(2049836463 * this.append);
         YJI var6;
         YJI var7;
         if (this.i) {
            var6 = this.H.M[this.L];
            var7 = this.H.K[0];
         } else {
            var6 = this.H.K[this.L];
            if (this.L < 3) {
               var7 = this.H.K[this.L + 1];
            } else {
               var7 = null;
            }
         }

         SF var8 = this.I().I;
         return var5.I(var1, var2, RW.R.V * -1976050083, this.m, var6, var7, (int)var8.I, (int)var8.C, (int)var8.Z, var3, (DX)null, -474476261);
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "wo.bl(" + ')');
      }
   }

   boolean method4351() {
      return this.PA != null ? this.PA.i() : false;
   }

   public int method38() {
      return this.m;
   }

   void method4357(GSI var1, int var2) {
   }

   boolean method4350(GSI var1, int var2, int var3, byte var4) {
      try {
         UT var5 = this.F(var1, 131072, (byte)22);
         if (var5 != null) {
            LF var6 = this.J();
            return var5.method4787(var2, var3, var6, false, 0);
         } else {
            return false;
         }
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "wo.bu(" + ')');
      }
   }

   boolean method4366(int var1) {
      try {
         return this.KA;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wo.bw(" + ')');
      }
   }

   void method4355(GSI var1, IR var2, int var3, int var4, int var5, boolean var6, int var7) {
      try {
         if (var2 instanceof ER) {
            ER var8 = (ER)var2;
            if (this.PA != null && var8.PA != null) {
               this.PA.method4745(var8.PA, var3, var4, var5, var6);
            }
         }

      } catch (RuntimeException var9) {
         throw DQ.I(var9, "wo.bk(" + ')');
      }
   }

   void method4398(byte var1) {
      try {
         this.KA = false;
         if (this.PA != null) {
            this.PA.KA(this.PA.m() & -65537);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wo.bq(" + ')');
      }
   }

   boolean method4382() {
      return this.PA != null ? this.PA.i() : false;
   }

   public int method29(int var1) {
      try {
         return RW.R.V * -1976050083;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wo.f(" + ')');
      }
   }

   public int method30(short var1) {
      try {
         return this.m;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wo.b(" + ')');
      }
   }

   public void method31(byte var1) {
      try {
         if (this.PA != null) {
            this.PA.method4784();
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wo.p(" + ')');
      }
   }

   public boolean method39(int var1) {
      try {
         return this.method4784;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wo.i(" + ')');
      }
   }

   boolean method4383() {
      return this.PA != null ? this.PA.i() : false;
   }

   public void method37(GSI var1, int var2) {
      try {
         Object var3 = null;
         GJI var4;
         if (this.YA == null && this.method4784) {
            ZY var5 = this.KA(var1, 262144, true, -1850458180);
            var4 = (GJI)(var5 != null ? var5.Z : null);
         } else {
            var4 = this.YA;
            this.YA = null;
         }

         SF var7 = this.I().I;
         if (var4 != null) {
            this.H.I(var4, this.L, (int)var7.I, (int)var7.Z, (boolean[])null, 174451452);
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "wo.d(" + ')');
      }
   }

   public int method45() {
      return this.append * 2049836463;
   }

   public int method4380() {
      return this.PA != null ? this.PA.YA() : 0;
   }

   public int method35() {
      return RW.R.V * -1976050083;
   }

   public int method42() {
      return this.m;
   }

   boolean method4384() {
      return this.KA;
   }

   public void method34() {
      if (this.PA != null) {
         this.PA.method4784();
      }

   }

   public boolean method41() {
      return this.method4784;
   }

   public void method28(GSI var1) {
      Object var2 = null;
      GJI var3;
      if (this.YA == null && this.method4784) {
         ZY var4 = this.KA(var1, 262144, true, -1804274121);
         var3 = (GJI)(var4 != null ? var4.Z : null);
      } else {
         var3 = this.YA;
         this.YA = null;
      }

      SF var5 = this.I().I;
      if (var3 != null) {
         this.H.Z(var3, this.L, (int)var5.I, (int)var5.Z, (boolean[])null, -1115505976);
      }

   }

   public void method43(GSI var1) {
      Object var2 = null;
      GJI var3;
      if (this.YA == null && this.method4784) {
         ZY var4 = this.KA(var1, 262144, true, -2127866030);
         var3 = (GJI)(var4 != null ? var4.Z : null);
      } else {
         var3 = this.YA;
         this.YA = null;
      }

      SF var5 = this.I().I;
      if (var3 != null) {
         this.H.I(var3, this.L, (int)var5.I, (int)var5.Z, (boolean[])null, 1644514804);
      }

   }

   public void method40(GSI var1) {
      Object var2 = null;
      GJI var3;
      if (this.YA == null && this.method4784) {
         ZY var4 = this.KA(var1, 262144, true, -2044645596);
         var3 = (GJI)(var4 != null ? var4.Z : null);
      } else {
         var3 = this.YA;
         this.YA = null;
      }

      SF var5 = this.I().I;
      if (var3 != null) {
         this.H.I(var3, this.L, (int)var5.I, (int)var5.Z, (boolean[])null, 710992193);
      }

   }

   public ER(AP var1, GSI var2, CX var3, KEI var4, int var5, int var6, int var7, int var8, int var9, boolean var10, int var11, boolean var12) {
      super(var1, var7, var8, var9, var5, var6, var4.n * -228547261);
      this.method4739 = var3;
      this.append = 646380829 * var4.Z;
      this.i = var10;
      this.m = (byte)var11;
      this.method4745 = var4.K * 1532834983 != 0 && !var10;
      this.KA = var12;
      this.method4784 = var2.method5082() && var4.CI && !this.i && FW.J.m.C(-1930969884) != 0;
      int var13 = 2048;
      if (this.KA) {
         var13 |= 65536;
      }

      if (var4.GI) {
         var13 |= 524288;
      }

      ZY var14 = this.KA(var2, var13, this.method4784, -2037171144);
      if (var14 != null) {
         this.PA = (UT)var14.I;
         this.YA = (GJI)var14.Z;
         if (this.KA || var4.GI) {
            this.PA = this.PA.method4755((byte)0, var13, false);
            if (var4.GI) {
               UA var15 = XEI.mI.D(-1945230052);
               this.PA.PA(1599271859 * var15.I, var15.Z * 1630923113, -1560648831 * var15.C, -57569897 * var15.B);
            }
         }
      }

      this.I(1, -105360757);
   }

   boolean method4365() {
      if (this.PA != null) {
         return !this.PA.u();
      } else {
         return true;
      }
   }

   boolean method4374() {
      if (this.PA != null) {
         return !this.PA.u();
      } else {
         return true;
      }
   }

   public HP method4367(GSI var1) {
      SF var2 = this.I().I;
      if (this.method4755 == null) {
         this.method4755 = TY.I((int)var2.I, (int)var2.C, (int)var2.Z, this.F(var1, 0, (byte)71), 1982463178);
      }

      return this.method4755;
   }

   public HP method4368(GSI var1) {
      SF var2 = this.I().I;
      if (this.method4755 == null) {
         this.method4755 = TY.I((int)var2.I, (int)var2.C, (int)var2.Z, this.F(var1, 0, (byte)44), 2033804861);
      }

      return this.method4755;
   }

   public int method36() {
      return RW.R.V * -1976050083;
   }

   void method4371(GSI var1) {
   }

   void method4373(GSI var1) {
   }

   boolean method4372(GSI var1, int var2, int var3) {
      UT var4 = this.F(var1, 131072, (byte)43);
      if (var4 != null) {
         LF var5 = this.J();
         return var4.method4787(var2, var3, var5, false, 0);
      } else {
         return false;
      }
   }

   boolean method4385(GSI var1, int var2, int var3) {
      UT var4 = this.F(var1, 131072, (byte)125);
      if (var4 != null) {
         LF var5 = this.J();
         return var4.method4787(var2, var3, var5, false, 0);
      } else {
         return false;
      }
   }

   boolean method4352(GSI var1, int var2, int var3) {
      UT var4 = this.F(var1, 131072, (byte)126);
      if (var4 != null) {
         LF var5 = this.J();
         return var4.method4787(var2, var3, var5, false, 0);
      } else {
         return false;
      }
   }

   void method4375(GSI var1, IR var2, int var3, int var4, int var5, boolean var6) {
      if (var2 instanceof ER) {
         ER var7 = (ER)var2;
         if (this.PA != null && var7.PA != null) {
            this.PA.method4745(var7.PA, var3, var4, var5, var6);
         }
      }

   }

   KP method4370(GSI var1) {
      if (this.PA == null) {
         return null;
      } else {
         LF var2 = this.J();
         KP var3 = BDI.I(this.method4745, 1241916364);
         this.PA.method4739(var2, this.N[0], 0);
         return var3;
      }
   }

   void method4377() {
      this.KA = false;
      if (this.PA != null) {
         this.PA.KA(this.PA.m() & -65537);
      }

   }

   void method4378() {
      this.KA = false;
      if (this.PA != null) {
         this.PA.KA(this.PA.m() & -65537);
      }

   }

   public int method4379() {
      return this.PA != null ? this.PA.YA() : 0;
   }

   public void method44(GSI var1) {
      Object var2 = null;
      GJI var3;
      if (this.YA == null && this.method4784) {
         ZY var4 = this.KA(var1, 262144, true, -1967364085);
         var3 = (GJI)(var4 != null ? var4.Z : null);
      } else {
         var3 = this.YA;
         this.YA = null;
      }

      SF var5 = this.I().I;
      if (var3 != null) {
         this.H.I(var3, this.L, (int)var5.I, (int)var5.Z, (boolean[])null, 193928700);
      }

   }

   public int method4381() {
      return this.PA != null ? this.PA.YA() : 0;
   }

   KP method4394(GSI var1, int var2) {
      try {
         if (this.PA == null) {
            return null;
         } else {
            LF var3 = this.J();
            KP var4 = BDI.I(this.method4745, 2139686110);
            this.PA.method4739(var3, this.N[0], 0);
            return var4;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "wo.bo(" + ')');
      }
   }

   public void method33(GSI var1, int var2) {
      try {
         Object var3 = null;
         GJI var4;
         if (this.YA == null && this.method4784) {
            ZY var5 = this.KA(var1, 262144, true, -2121821591);
            var4 = (GJI)(var5 != null ? var5.Z : null);
         } else {
            var4 = this.YA;
            this.YA = null;
         }

         SF var7 = this.I().I;
         if (var4 != null) {
            this.H.Z(var4, this.L, (int)var7.I, (int)var7.Z, (boolean[])null, -412237236);
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "wo.k(" + ')');
      }
   }

   boolean method4349() {
      return this.PA != null ? this.PA.i() : false;
   }

   void method4388(GSI var1, IR var2, int var3, int var4, int var5, boolean var6) {
      if (var2 instanceof ER) {
         ER var7 = (ER)var2;
         if (this.PA != null && var7.PA != null) {
            this.PA.method4745(var7.PA, var3, var4, var5, var6);
         }
      }

   }

   public int method32(byte var1) {
      try {
         return this.append * 2049836463;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wo.a(" + ')');
      }
   }

   boolean method4353() {
      if (this.PA != null) {
         return !this.PA.u();
      } else {
         return true;
      }
   }

   boolean method4400() {
      return this.KA;
   }

   boolean method4386() {
      return this.KA;
   }

   boolean method4387() {
      return this.KA;
   }

   boolean method4376(short var1) {
      try {
         return this.PA != null ? this.PA.i() : false;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wo.be(" + ')');
      }
   }

   boolean method4399(byte var1) {
      try {
         if (this.PA != null) {
            return !this.PA.u();
         } else {
            return true;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wo.bf(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.X[var0.i * 1883543357];
         int var3 = var0.H[(var0.J -= -391880689) * 681479919];
         if (var3 >= 0 && var3 < var0.B[var2]) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = var0.F[var2][var3];
         } else {
            throw new RuntimeException();
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "wo.au(" + ')');
      }
   }
}
