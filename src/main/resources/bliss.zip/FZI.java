public class FZI {
   public short[] I;
   public int[] Z;
   public short[] C;
   public long B;

   public FZI(HEI var1, boolean var2) {
      if (var2) {
         this.Z = new int[var1.F.length];
         System.arraycopy(var1.F, 0, this.Z, 0, this.Z.length);
      } else {
         this.Z = new int[var1.J.length];
         System.arraycopy(var1.J, 0, this.Z, 0, this.Z.length);
      }

      if (var1.E != null) {
         this.C = new short[var1.E.length];
         System.arraycopy(var1.E, 0, this.C, 0, this.C.length);
      }

      if (var1.V != null) {
         this.I = new short[var1.V.length];
         System.arraycopy(var1.V, 0, this.I, 0, this.I.length);
      }

   }

   public FZI(long var1, int[] var3, short[] var4, short[] var5) {
      this.B = 3177550440302969639L * var1;
      this.Z = var3;
      this.C = var4;
      this.I = var5;
   }

   public static SB I(REI var0, byte var1) {
      try {
         SB var2 = new SB();
         var2.I = var0.C() * -1496580327;
         var2.Z = TX.C.I(var2.I * -2034569943, (short)-12386);
         return var2;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "up.a(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.t.I(-2147059683);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "up.akq(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.A -= 1938723502;
         String var2 = (String)var0.S[-203050393 * var0.A];
         String var3 = (String)var0.S[-203050393 * var0.A + 1];
         int var4 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var2.indexOf(var3, var4);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "up.aay(" + ')');
      }
   }
}
