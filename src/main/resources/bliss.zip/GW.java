public class GW extends LV {
   public static int method5611 = 0;
   public static int toString = 1;
   static int[] F;

   public GW(int var1, MM var2) {
      super(var1, var2);
   }

   public int method5616(int var1) {
      if (var1 != 0 && this.I.A.Z((byte)108) == 2) {
         return 3;
      } else {
         return var1 != 0 && this.I.j.Z(1875039574) != 1 ? 2 : 1;
      }
   }

   public boolean Z(byte var1) {
      return true;
   }

   public int method5612(int var1, int var2) {
      try {
         if (var1 != 0 && this.I.A.Z((byte)10) == 2) {
            return 3;
         } else {
            return var1 != 0 && this.I.j.Z(948081550) != 1 ? 2 : 1;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "add.f(" + ')');
      }
   }

   void method5614(int var1, int var2) {
      try {
         this.C = 1886334997 * var1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "add.p(" + ')');
      }
   }

   public int I(int var1) {
      try {
         return -1598873795 * this.C;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "add.y(" + ')');
      }
   }

   int method5615() {
      return 1;
   }

   int method5611(int var1) {
      return 1;
   }

   public void C(byte var1) {
      try {
         if (this.C * -1598873795 != 0 && this.I.j.Z(1435565446) != 1) {
            this.C = 0;
         }

         if (this.C * -1598873795 != 0 && this.I.A.Z((byte)20) == 2) {
            this.C = 0;
         }

         if (-1598873795 * this.C < 0 || -1598873795 * this.C > 1) {
            this.C = this.method5611(-1720172189) * 1886334997;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "add.s(" + ')');
      }
   }

   void method5610(int var1) {
      this.C = 1886334997 * var1;
   }

   public GW(MM var1) {
      super(var1);
   }

   static final void Z(int var0) {
      try {
         int[] var1 = C.J;

         int var2;
         for(var2 = 0; var2 < C.I * 1168366243; ++var2) {
            PEI var3 = XEI.MC[var1[var2]];
            if (var3 != null) {
               var3.B(-586581534);
            }
         }

         for(var2 = 0; var2 < -1230451913 * XEI.zI; ++var2) {
            long var7 = (long)XEI.WI[var2];
            QG var5 = (QG)XEI.UI.I(var7);
            if (var5 == null) {
               if (var0 == -1062447355) {
                  throw new IllegalStateException();
               }
            } else {
               ((SSI)var5.J).B(1089221669);
            }
         }

         if (1596783995 * XEI.uI == 0) {
            for(var2 = 0; var2 < PFI.C.length; ++var2) {
               YFI var8 = PFI.C[var2];
               if (var8.D) {
                  var8.I(1581721425).B(390417691);
               }
            }
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "add.gz(" + ')');
      }
   }
}
