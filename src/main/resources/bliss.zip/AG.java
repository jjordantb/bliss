import jagtheora.ogg.OggPacket;
import jagtheora.ogg.OggStreamState;

public abstract class AG extends AE {
   OggStreamState J;
   int S;

   abstract void method3072();

   void I(OggPacket var1, int var2) {
      try {
         this.method3074(var1, -441826665);
         this.S += 1765581491;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "abi.a(" + ')');
      }
   }

   abstract void method3074(OggPacket var1, int var2);

   abstract void method3075(int var1);

   abstract void method3076(OggPacket var1);

   abstract void method3077(OggPacket var1);

   abstract void method3078(OggPacket var1);

   AG(OggStreamState var1) {
      this.J = var1;
   }

   abstract void method3079();

   public static void I(KJ var0, KJ var1, KJ var2, KJ var3, int var4) {
      try {
         CA.I = var0;
         RuntimeException_Sub3.aClass243_6310 = var1;
         JI.Z = var2;
         IU.F = new X[CA.I.Z(1202427542)];
         MX.S = new boolean[CA.I.Z(1827823316)];
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "abi.a(" + ')');
      }
   }
}
