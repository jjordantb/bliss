public class IF extends XD {
   byte[] G;

   byte[] Z(int var1, int var2, int var3) {
      this.G = new byte[var1 * var2 * var3 * 2];
      this.I(var1, var2, var3);
      return this.G;
   }

   void I(int var1, byte var2) {
      int var3 = var1 * 2;
      var2 = (byte)(127 + ((var2 & 255) >> 1));
      this.G[var3++] = var2;
      this.G[var3] = var2;
   }

   void Z(int var1, byte var2) {
      int var3 = var1 * 2;
      var2 = (byte)(127 + ((var2 & 255) >> 1));
      this.G[var3++] = var2;
      this.G[var3] = var2;
   }

   IF() {
      super(12, 5, 16, 2, 2, 0.45F);
   }
}
