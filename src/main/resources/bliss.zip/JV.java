public class JV {
   static byte[][] I = new byte[250][];
   static int Z = 0;
   static int C = 0;
   static int B = 0;
   public static int[] D;
   static byte[][] F = new byte[1000][];
   static byte[][] J = new byte[50][];
   static IBI[] S;

   public static synchronized byte[] I(int var0, short var1) {
      try {
         byte[] var5;
         if (100 == var0 && B * 355907107 > 0) {
            var5 = F[(B -= -996497013) * 355907107];
            F[B * 355907107] = null;
            return var5;
         } else if (var0 == 5000 && 1904890379 * Z > 0) {
            var5 = I[(Z -= -1583470173) * 1904890379];
            I[1904890379 * Z] = null;
            return var5;
         } else if (var0 == 30000 && C * -1426745913 > 0) {
            var5 = J[(C -= 1975229431) * -1426745913];
            J[C * -1426745913] = null;
            return var5;
         } else {
            if (NL.H != null) {
               for(int var2 = 0; var2 < BZ.C.length; ++var2) {
                  if (BZ.C[var2] == var0 && D[var2] > 0) {
                     byte[] var3 = NL.H[var2][--D[var2]];
                     NL.H[var2][D[var2]] = null;
                     return var3;
                  }
               }
            }

            return new byte[var0];
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "rg.a(" + ')');
      }
   }

   JV() throws Throwable {
      throw new Error();
   }

   public static int I(int var0, byte var1) {
      try {
         --var0;
         var0 |= var0 >>> 1;
         var0 |= var0 >>> 2;
         var0 |= var0 >>> 4;
         var0 |= var0 >>> 8;
         var0 |= var0 >>> 16;
         return 1 + var0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "rg.p(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         YBI.I(var3, var4, var0, (byte)119);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "rg.ou(" + ')');
      }
   }
}
