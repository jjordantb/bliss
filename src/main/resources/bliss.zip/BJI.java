final class BJI extends CJI {
   void method1038() {
      AN.I = AN.H;
      AN.H = null;
   }

   void method1037(int var1) {
      try {
         AN.I = AN.H;
         AN.H = null;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "yz.a(" + ')');
      }
   }

   void method1036() {
      AN.I = AN.H;
      AN.H = null;
   }

   void method1039() {
      AN.I = AN.H;
      AN.H = null;
   }

   public static final void I(int var0, int var1, int var2, int var3, int var4, boolean var5) {
      try {
         GT.D = var0 * 2140348215;
         SFI.F = -2108764285 * var1;
         SJI.A = var2 * 1219077157;
         RI.I = -346020243 * var3;
         RD.C = var4 * 1510337323;
         if (var5 && RD.C * 1534163843 >= 100) {
            RR.Q = -1222509056 * GT.D + -1475884800;
            RZ.H = 2009399552 + 1453086208 * SFI.F;
            L.B = (NQ.I(-1740717447 * RR.Q, RZ.H * -299812095, 1855729883 * EJI.Z, -2087363822) - -1439836243 * SJI.A) * 1078403147;
         }

         EE.V = 2090692627;
         AV.I = -1001372047;
         B.XZ = 178575833;
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "yz.hu(" + ')');
      }
   }

   public static void I(AE var0, AE var1, int var2) {
      try {
         if (var0.C != null) {
            var0.I(-1460969981);
         }

         var0.C = var1.C;
         var0.I = var1;
         var0.C.I = var0;
         var0.I.C = var0;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "yz.b(" + ')');
      }
   }

   static VK I(byte var0) {
      try {
         VK var1 = (VK)VK.l.Z(1993015786);
         if (var1 != null) {
            var1.I(-1460969981);
            var1.C(-834696673);
            return var1;
         } else {
            do {
               var1 = (VK)VK.G.Z(-962629622);
               if (var1 == null) {
                  return null;
               }

               if (var1.J(1111075384) > CI.I((byte)1)) {
                  return null;
               }

               var1.I(-1460969981);
               var1.C(1430055356);
            } while(0L == (var1.A * -5533549728640346679L & Long.MIN_VALUE));

            return var1;
         }
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "yz.b(" + ')');
      }
   }
}
