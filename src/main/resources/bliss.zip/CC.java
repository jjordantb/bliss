public abstract class CC implements QAI {
   public KB[] I;

   CC(KB[] var1) {
      this.I = var1;
   }
}
