public interface GAI {
   int method271();

   int method272();
}
