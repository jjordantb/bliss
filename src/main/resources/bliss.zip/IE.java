public class IE {
   static int append = 62;
   static int toString = 2;
   static int I = 16;
   static int Z = 1;
   static int C = 8;
   static int B = 63;

   IE() throws Throwable {
      throw new Error();
   }

   static final void I(OU var0, int var1) {
      try {
         HSI var2 = AZI.I(var0.H[(var0.J -= -391880689) * 681479919], (byte)-49);
         if (-1232467723 * var2.uZ != -1) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = -66163287 * var2.vZ;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "mb.rw(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         var0.J -= -783761378;
         int var2 = var0.H[681479919 * var0.J];
         int var3 = var0.H[1 + var0.J * 681479919];
         var0.G.C[var2] = var3;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "mb.adb(" + ')');
      }
   }

   public static final int I(int var0, int var1, int var2) {
      try {
         if (-1 == var0) {
            return 12345678;
         } else {
            var1 = (var0 & 127) * var1 >> 7;
            if (var1 < 2) {
               var1 = 2;
            } else if (var1 > 126) {
               var1 = 126;
            }

            return (var0 & 'ﾀ') + var1;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "mb.q(" + ')');
      }
   }

   public static void I(int var0, int var1) {
      try {
         VK var2 = IV.I(22, (long)var0);
         var2.B(-926641552);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "mb.d(" + ')');
      }
   }
}
