public class Exception_Sub2_Sub2 extends Exception_Sub2 {
   Exception_Sub2_Sub2(String var1) {
      super(var1);
   }
}
