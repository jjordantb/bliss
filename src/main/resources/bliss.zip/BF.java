public class BF extends ZF {
   byte[] O;

   void Z(int var1, byte var2) {
      int var3 = var1 * 2;
      int var4 = var2 & 255;
      this.O[var3++] = (byte)(3 * var4 >> 5);
      this.O[var3] = (byte)(3 * var4 >> 5);
   }

   BF() {
      super(8, 5, 8, 8, 2, 0.1F, 0.55F, 3.0F);
   }

   void I(int var1, byte var2) {
      int var3 = var1 * 2;
      int var4 = var2 & 255;
      this.O[var3++] = (byte)(3 * var4 >> 5);
      this.O[var3] = (byte)(3 * var4 >> 5);
   }

   byte[] Z(int var1, int var2, int var3) {
      this.O = new byte[var1 * var2 * var3 * 2];
      this.I(var1, var2, var3);
      return this.O;
   }

   void C(int var1, byte var2) {
      int var3 = var1 * 2;
      int var4 = var2 & 255;
      this.O[var3++] = (byte)(3 * var4 >> 5);
      this.O[var3] = (byte)(3 * var4 >> 5);
   }

   void B(int var1, byte var2) {
      int var3 = var1 * 2;
      int var4 = var2 & 255;
      this.O[var3++] = (byte)(3 * var4 >> 5);
      this.O[var3] = (byte)(3 * var4 >> 5);
   }
}
