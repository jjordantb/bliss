public class BW extends LV {
   public static int F = 1;
   public static int method5611 = 3;
   public static int toString = 4;
   public static int J = 0;
   public static int S = 2;

   int method5612(int var1, int var2) {
      return 1;
   }

   public BW(int var1, MM var2) {
      super(var1, var2);
   }

   public void I(int var1) {
      try {
         if (-1598873795 * this.C < 0 || -1598873795 * this.C > 4) {
            this.C = this.method5611(843701468) * 1886334997;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aeg.s(" + ')');
      }
   }

   int method5611(int var1) {
      return 0;
   }

   void method5610(int var1) {
      this.C = 1886334997 * var1;
   }

   int method5615() {
      return 0;
   }

   public int Z(int var1) {
      try {
         return this.C * -1598873795;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aeg.z(" + ')');
      }
   }

   public BW(MM var1) {
      super(var1);
   }

   void method5614(int var1, int var2) {
      try {
         this.C = 1886334997 * var1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aeg.p(" + ')');
      }
   }

   int method5616(int var1) {
      return 1;
   }

   static final void C(int var0) {
      try {
         if (FW.J.X.Z(-2013953489) == 2) {
            byte[][][] var1 = XEI.mI.G(899241973);
            byte var2 = (byte)(-1953789277 * XEI.nZ - 4 & 255);
            int var3 = -1953789277 * XEI.nZ % XEI.mI.Z(-2129604944);

            int var4;
            int var5;
            for(var4 = 0; var4 < 4; ++var4) {
               for(var5 = 0; var5 < XEI.mI.C(-605085367); ++var5) {
                  var1[var4][var3][var5] = var2;
               }
            }

            if (EJI.Z * 1855729883 != 3) {
               for(var4 = 0; var4 < 2; ++var4) {
                  XEI.CC[var4] = -1000000;
                  XEI.ZI[var4] = 1000000;
                  XEI.DC[var4] = 0;
                  XEI.JC[var4] = 1000000;
                  XEI.Y[var4] = 0;
               }

               SF var18 = UA.F.I().I;
               var5 = (int)var18.I;
               int var6 = (int)var18.Z;
               LJ var7 = XEI.mI.M(688600578);
               AP var8 = XEI.mI.T(-1611682495);
               int var9;
               if (EE.V * -863531439 != 4 && B.XZ * 1329981847 == -1) {
                  var9 = NQ.I(RR.Q * -1740717447, RZ.H * -299812095, EJI.Z * 1855729883, -1780642340);
                  if (var9 - L.B * 1449634147 < 3200 && (var7.C[EJI.Z * 1855729883][RR.Q * -1740717447 >> 9][-299812095 * RZ.H >> 9] & 4) != 0) {
                     OZ.I(var8.E, 1, RR.Q * -1740717447 >> 9, -299812095 * RZ.H >> 9, false, -777988087);
                  }
               } else {
                  if (-863531439 * EE.V != 4) {
                     var5 = 1329981847 * B.XZ;
                     var6 = AV.I * -1106950801;
                  }

                  if ((var7.C[1855729883 * EJI.Z][var5 >> 9][var6 >> 9] & 4) != 0) {
                     OZ.I(var8.E, 0, var5 >> 9, var6 >> 9, false, -777988087);
                  } else if (XEI.VZ * -104436553 < 2560) {
                     var9 = -1740717447 * RR.Q >> 9;
                     int var10 = RZ.H * -299812095 >> 9;
                     int var11 = var5 >> 9;
                     int var12 = var6 >> 9;
                     int var13;
                     if (var11 > var9) {
                        var13 = var11 - var9;
                     } else {
                        var13 = var9 - var11;
                     }

                     int var14;
                     if (var12 > var10) {
                        var14 = var12 - var10;
                     } else {
                        var14 = var10 - var12;
                     }

                     if ((var13 != 0 || var14 != 0) && var13 > -XEI.mI.Z(-1952640446) && var13 < XEI.mI.Z(-2135239698) && var14 > -XEI.mI.C(115807107) && var14 < XEI.mI.C(-1212701794)) {
                        int var16;
                        int var19;
                        if (var13 > var14) {
                           var19 = var14 * 65536 / var13;
                           var16 = 32768;

                           while(var11 != var9) {
                              if (var9 < var11) {
                                 ++var9;
                              } else if (var9 > var11) {
                                 --var9;
                              }

                              if ((var7.C[1855729883 * EJI.Z][var9][var10] & 4) != 0) {
                                 OZ.I(var8.E, 1, var9, var10, false, -777988087);
                                 break;
                              }

                              var16 += var19;
                              if (var16 >= 65536) {
                                 var16 -= 65536;
                                 if (var10 < var12) {
                                    ++var10;
                                 } else if (var10 > var12) {
                                    --var10;
                                 }

                                 if ((var7.C[1855729883 * EJI.Z][var9][var10] & 4) != 0) {
                                    OZ.I(var8.E, 1, var9, var10, false, -777988087);
                                    break;
                                 }
                              }
                           }
                        } else {
                           var19 = 65536 * var13 / var14;
                           var16 = 32768;

                           while(var10 != var12) {
                              if (var10 < var12) {
                                 ++var10;
                              } else if (var10 > var12) {
                                 --var10;
                              }

                              if ((var7.C[EJI.Z * 1855729883][var9][var10] & 4) != 0) {
                                 OZ.I(var8.E, 1, var9, var10, false, -777988087);
                                 break;
                              }

                              var16 += var19;
                              if (var16 >= 65536) {
                                 var16 -= 65536;
                                 if (var9 < var11) {
                                    ++var9;
                                 } else if (var9 > var11) {
                                    --var9;
                                 }

                                 if ((var7.C[1855729883 * EJI.Z][var9][var10] & 4) != 0) {
                                    OZ.I(var8.E, 1, var9, var10, false, -777988087);
                                    break;
                                 }
                              }
                           }
                        }
                     } else {
                        XP var15 = XEI.mI.I(681479919);
                        KSI.I(var9 + SS.D + var10 + " " + var11 + SS.D + var12 + " " + var15.I * -1760580017 + SS.D + var15.Z * 283514611, new RuntimeException(), (short)-16769);
                     }
                  }
               }
            }
         }

      } catch (RuntimeException var17) {
         throw DQ.I(var17, "aeg.io(" + ')');
      }
   }

   public static void I(String var0, short var1) {
      try {
         HJ.I(0, 0, "", "", "", var0, -1848058692);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aeg.f(" + ')');
      }
   }
}
