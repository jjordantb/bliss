public class BJ implements JAI {
   KJ Z;
   String append;
   static int I;
   public static JZI C;

   public HY method261() {
      return HY.I;
   }

   public int method256(int var1) {
      try {
         return this.Z.F(this.append, 1689280899) ? 100 : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jz.a(" + ')');
      }
   }

   public HY method260(int var1) {
      try {
         return HY.I;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jz.f(" + ')');
      }
   }

   public int method258() {
      return this.Z.F(this.append, 1689280899) ? 100 : 0;
   }

   BJ(KJ var1, String var2) {
      this.Z = var1;
      this.append = var2;
   }

   public HY method257() {
      return HY.I;
   }

   public HY method259() {
      return HY.I;
   }

   public static JE I(KJ var0, String var1, boolean var2, int var3) {
      try {
         int var4 = var0.B(var1, -912375473);
         if (-1 == var4) {
            return new JE(0);
         } else {
            int[] var5 = var0.B(var4, -2131857689);
            JE var6 = new JE(var5.length);
            int var7 = 0;
            int var8 = 0;

            while(true) {
               while(var7 < var6.Z * -1407078377) {
                  REI var9 = new REI(var0.I(var4, var5[var8++], (byte)-34));
                  int var10 = var9.H((byte)101);
                  int var11 = var9.C();
                  int var12 = var9.I();
                  if (!var2 && var12 == 1) {
                     var6.Z -= 526813095;
                  } else {
                     var6.I[var7] = var10;
                     var6.C[var7] = var11;
                     ++var7;
                  }
               }

               return var6;
            }
         }
      } catch (RuntimeException var13) {
         throw DQ.I(var13, "jz.a(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         XM var2 = ECI.I(-1558918044);
         if (var2 == null) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = -1;
            var0.H[(var0.J += -391880689) * 681479919 - 1] = -1;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = var2.E * -530122905;
            int var3 = var2.J * -1740053407 << 28 | EN.U + 2122110429 * var2.A << 14 | EN.O + var2.H * -372920341;
            var0.H[(var0.J += -391880689) * 681479919 - 1] = var3;
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "jz.adg(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = XEI.TC && !XEI.UC ? 1 : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jz.amz(" + ')');
      }
   }

   static QQ I(REI var0, byte var1) {
      try {
         int var2 = var0.I();
         int var3 = var0.I();
         return new QQ(var2, var3);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "jz.p(" + ')');
      }
   }

   public static void I(int var0) {
      try {
         JCI.I(2037731231);
         CU.I(22050, FW.J.r.Z((byte)39) == 1, 2, 1903660565);
         AN.A = FDI.I(PCI.A, 0, 22050, -1188056324);
         WBI.I(true, GDI.I((XE)null, (int)-1296770048), 1539003934);
         JN.L = FDI.I(PCI.A, 1, 2048, -1833287234);
         JN.L.I((WE)RA.S, (int)2098926435);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "jz.b(" + ')');
      }
   }

   public static void I(int var0, byte var1) {
      try {
         HSI.N.I(var0, -450593639);
         HSI.Q.I(var0, -631173514);
         HSI.O.I(var0, -826447089);
         HSI.HC.I(var0, -1629354763);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jz.e(" + ')');
      }
   }

   static void I(int var0, int var1, int var2, int var3, short var4) {
      try {
         VK var5 = IV.I(19, (long)var1 << 32 | (long)var0);
         var5.I((byte)2);
         var5.L = 1274450087 * var2;
         var5.H = 293101103 * var3;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "jz.bd(" + ')');
      }
   }
}
