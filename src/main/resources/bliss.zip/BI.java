public abstract class BI {
   U F;
   L[] append;
   String equals;
   U indexOf;
   int length;
   int method1159;
   static KAI method1161 = new ZI();
   protected int I = 1776466383;

   public int I(int var1) {
      try {
         return -140989799 * this.length;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ez.az(" + ')');
      }
   }

   public final void I(VG var1, float var2, float var3, int var4) {
      try {
         this.append[-33664303 * this.I].method1161(var1, var2, var3);
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ez.t(" + ')');
      }
   }

   public String Z(int var1) {
      try {
         return this.equals;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ez.p(" + ')');
      }
   }

   BI(NJI var1, H var2) {
      this.equals = var2.Z;
      this.length = 2063075753 * var2.I.length;
      this.F = new U(-140989799 * this.length, method1161);

      int var3;
      for(var3 = 0; var3 < this.length * -140989799; ++var3) {
         this.F.I(var3, var2.I[var3].B, this.method1367(var2.I[var3]), -1301495890);
      }

      this.method1159 = -1642721829 * var2.C.length;
      this.indexOf = new U(this.method1159 * 1271998035, method1161);

      for(var3 = 0; var3 < this.method1159 * 1271998035; ++var3) {
         this.indexOf.I(var3, var2.C[var3].B, this.method1367(var2.C[var3]), -498373902);
      }

      this.append = new L[var2.D.length];

      for(var3 = 0; var3 < var2.D.length; ++var3) {
         this.append[var3] = this.method1326(var1, var2.D[var3]);
      }

   }

   abstract L method1326(NJI var1, G var2);

   public L I(String var1, byte var2) throws Exception_Sub2_Sub2 {
      try {
         L[] var3 = this.append;

         for(int var4 = 0; var4 < var3.length; ++var4) {
            L var5 = var3[var4];
            String var6 = var5.I(-1921195754);
            if (var6 != null && var6.equals(var1)) {
               if (!var5.method1221()) {
                  throw new Exception_Sub2_Sub2(var1);
               }

               return var5;
            }
         }

         throw new Exception_Sub2_Sub2(var1);
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "ez.k(" + ')');
      }
   }

   public final int C(int var1) {
      try {
         return this.append.length;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ez.d(" + ')');
      }
   }

   public int I(L var1, int var2) {
      try {
         for(int var3 = 0; var3 < this.append.length; ++var3) {
            if (this.append[var3] == var1) {
               return var3;
            }
         }

         return -1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ez.x(" + ')');
      }
   }

   public L B(int var1) {
      try {
         L[] var2 = this.append;

         for(int var3 = 0; var3 < var2.length; ++var3) {
            L var4 = var2[var3];
            if (var4.method1221()) {
               return var4;
            }
         }

         return null;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ez.r(" + ')');
      }
   }

   public abstract boolean method1331(L var1);

   public final L D(int var1) {
      try {
         return -33664303 * this.I >= 0 ? this.append[this.I * -33664303] : null;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ez.n(" + ')');
      }
   }

   public final int F(int var1) {
      try {
         return -33664303 * this.I;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ez.s(" + ')');
      }
   }

   public final void I(VG var1, float var2, float var3, float var4, int var5) {
      try {
         this.append[this.I * -33664303].method1162(var1, var2, var3, var4);
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "ez.h(" + ')');
      }
   }

   public final void I(VG var1, float var2, int var3) {
      try {
         this.append[-33664303 * this.I].method1176(var1, var2);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ez.y(" + ')');
      }
   }

   public final void I(int var1, YF var2, byte var3) {
      try {
         this.append[-33664303 * this.I].method1173(var1, var2);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ez.ad(" + ')');
      }
   }

   public final void I(VG var1, YF var2, byte var3) {
      try {
         this.append[-33664303 * this.I].method1192(var1, var2);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ez.w(" + ')');
      }
   }

   public final void I(VG var1, SF var2, int var3) {
      try {
         this.append[-33664303 * this.I].method1162(var1, var2.I, var2.C, var2.Z);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ez.g(" + ')');
      }
   }

   public final void I(VG var1, XF var2, int var3) {
      try {
         this.append[this.I * -33664303].method1163(var1, var2.B, var2.C, var2.I, var2.Z);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ez.e(" + ')');
      }
   }

   public abstract void method1340();

   public final void I(VG var1, int var2, IEI var3, int var4) {
      try {
         this.append[-33664303 * this.I].method1167(var1, var2, var3);
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ez.o(" + ')');
      }
   }

   public final void I(int var1, float var2, float var3, float var4, float var5, byte var6) {
      try {
         this.append[-33664303 * this.I].method1169(var1, var2, var3, var4, var5);
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "ez.ax(" + ')');
      }
   }

   public final void I(int var1, SF var2, int var3) {
      try {
         this.append[this.I * -33664303].method1168(var1, var2.I, var2.C, var2.Z);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ez.aa(" + ')');
      }
   }

   public final void I(int var1, float[] var2, int var3, int var4) {
      try {
         this.append[-33664303 * this.I].method1170(var1, var2, var3);
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ez.ak(" + ')');
      }
   }

   public final void Z(int var1, YF var2, byte var3) {
      try {
         this.append[this.I * -33664303].method1171(var1, var2);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ez.ae(" + ')');
      }
   }

   public final void I(int var1, YF var2, int var3) {
      try {
         this.append[this.I * -33664303].method1159(var1, var2);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ez.ao(" + ')');
      }
   }

   public final void I(VG var1, float[] var2, byte var3) {
      try {
         this.append[this.I * -33664303].method1164(var1, var2, var2.length);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ez.c(" + ')');
      }
   }

   public final void I(int var1, int var2, IEI var3, int var4) {
      try {
         this.append[-33664303 * this.I].method1174(var1, var2, var3);
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ez.av(" + ')');
      }
   }

   public abstract boolean method1349(L var1);

   public int I(byte var1) {
      try {
         return this.method1159 * 1271998035;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ez.ah(" + ')');
      }
   }

   public VG Z(String var1, byte var2) {
      try {
         return (VG)this.indexOf.I(var1, -1795999546);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ez.al(" + ')');
      }
   }

   public VG I(int var1, int var2) {
      try {
         return (VG)this.F.I(var1, (byte)-22);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ez.as(" + ')');
      }
   }

   void I() {
   }

   public abstract void method1354();

   public abstract void method1355();

   public abstract void method1356();

   public abstract void method1357();

   public abstract void method1358();

   public abstract boolean method1359();

   public VG I(String var1, int var2) throws Exception_Sub2_Sub1 {
      try {
         VG var3 = (VG)this.F.I(var1, 542987786);
         if (var3 == null) {
            throw new Exception_Sub2_Sub1(var1);
         } else {
            return var3;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ez.at(" + ')');
      }
   }

   abstract L method1361(NJI var1, G var2);

   abstract L method1362(NJI var1, G var2);

   public final void I(VG var1, int var2, int var3) {
      try {
         float var4 = (float)(var2 >> 16 & 255) / 255.0F;
         float var5 = (float)(var2 >> 8 & 255) / 255.0F;
         float var6 = (float)(var2 & 255) / 255.0F;
         float var7 = (float)(var2 >> 24 & 255) / 255.0F;
         this.I(var1, var4, var5, var6, var7, 205525128);
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "ez.m(" + ')');
      }
   }

   abstract VG method1364(R var1);

   public final void I(int var1, float var2, float var3, float var4, int var5) {
      try {
         this.append[-33664303 * this.I].method1168(var1, var2, var3, var4);
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "ez.l(" + ')');
      }
   }

   public final void I(VG var1, float var2, float var3, float var4, float var5, int var6) {
      try {
         this.append[this.I * -33664303].method1163(var1, var2, var3, var4, var5);
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "ez.v(" + ')');
      }
   }

   abstract VG method1367(R var1);

   public final void I(VG var1, YF var2, int var3) {
      try {
         this.append[-33664303 * this.I].method1166(var1, var2);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ez.j(" + ')');
      }
   }

   public final L Z(int var1, int var2) {
      try {
         return this.append[var1];
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ez.u(" + ')');
      }
   }

   public VG C(int var1, int var2) {
      try {
         return (VG)this.indexOf.I(var1, (byte)-95);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ez.ai(" + ')');
      }
   }

   public abstract boolean method1371();

   public abstract void method1372();

   public abstract void method1373();

   public abstract boolean method1374();

   public abstract boolean method1375(L var1);

   public abstract boolean method1376(L var1);

   static final void I(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)75);
         X var4 = IU.F[var2 >> 16];
         ZO.I(var3, var4, var0, (byte)12);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ez.fu(" + ')');
      }
   }

   public static String I(String var0, char var1, String var2, short var3) {
      try {
         int var4 = var0.length();
         int var5 = var2.length();
         int var6 = var4;
         int var7 = var5 - 1;
         if (var7 != 0) {
            int var8 = 0;

            while(true) {
               var8 = var0.indexOf(var1, var8);
               if (var8 < 0) {
                  break;
               }

               ++var8;
               var6 += var7;
            }
         }

         StringBuilder var12 = new StringBuilder(var6);
         int var9 = 0;

         while(true) {
            int var10 = var0.indexOf(var1, var9);
            if (var10 < 0) {
               if (var3 != 316) {
                  throw new IllegalStateException();
               } else {
                  var12.append(var0.substring(var9));
                  return var12.toString();
               }
            }

            var12.append(var0.substring(var9, var10));
            var12.append(var2);
            var9 = var10 + 1;
         }
      } catch (RuntimeException var11) {
         throw DQ.I(var11, "ez.t(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = JH.R.I(var2).J * 789409129 == 1 ? 1 : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ez.aah(" + ')');
      }
   }
}
