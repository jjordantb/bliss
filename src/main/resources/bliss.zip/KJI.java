import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class KJI extends GJI {
   int H;
   int K;
   byte[] L;
   int M;
   int N;
   static int TRUE = 16;

   void I(int var1, int var2, int var3, int var4) {
      this.H = var1;
      this.N = var2;
      this.K = var3 - var1;
      this.M = var4 - var2;
   }

   void I() {
      int var1 = -1;

      for(int var2 = this.L.length - 8; var1 < var2; this.L[var1] = 0) {
         ++var1;
         this.L[var1] = 0;
         ++var1;
         this.L[var1] = 0;
         ++var1;
         this.L[var1] = 0;
         ++var1;
         this.L[var1] = 0;
         ++var1;
         this.L[var1] = 0;
         ++var1;
         this.L[var1] = 0;
         ++var1;
         this.L[var1] = 0;
         ++var1;
      }

      while(var1 < this.L.length - 1) {
         ++var1;
         this.L[var1] = 0;
      }

   }

   static final void TRUE(byte[] var0, int var1, int var2, int var3, int var4) {
      if (var3 < var4) {
         var1 += var3;
         var2 = var4 - var3 >> 2;

         while(true) {
            --var2;
            if (var2 < 0) {
               var2 = var4 - var3 & 3;

               while(true) {
                  --var2;
                  if (var2 < 0) {
                     return;
                  }

                  var0[var1++] = 1;
               }
            }

            var0[var1++] = 1;
            var0[var1++] = 1;
            var0[var1++] = 1;
            var0[var1++] = 1;
         }
      }
   }

   boolean Z(int var1, int var2) {
      return this.L.length >= var1 * var2;
   }

   void I(int var1, int var2, int var3, int var4, int var5, int var6) {
      int var7 = 0;
      if (var2 != var1) {
         var7 = (var5 - var4 << 16) / (var2 - var1);
      }

      int var8 = 0;
      if (var3 != var2) {
         var8 = (var6 - var5 << 16) / (var3 - var2);
      }

      int var9 = 0;
      if (var3 != var1) {
         var9 = (var4 - var6 << 16) / (var1 - var3);
      }

      if (var1 <= var2 && var1 <= var3) {
         if (var2 < var3) {
            var6 = var4 <<= 16;
            if (var1 < 0) {
               var6 -= var9 * var1;
               var4 -= var7 * var1;
               var1 = 0;
            }

            var5 <<= 16;
            if (var2 < 0) {
               var5 -= var8 * var2;
               var2 = 0;
            }

            if ((var1 == var2 || var9 >= var7) && (var1 != var2 || var9 <= var8)) {
               var3 -= var2;
               var2 -= var1;
               var1 *= this.K;

               label296:
               while(true) {
                  --var2;
                  if (var2 < 0) {
                     while(true) {
                        --var3;
                        if (var3 < 0) {
                           break label296;
                        }

                        TRUE(this.L, var1, 0, var5 >> 16, var6 >> 16);
                        var6 += var9;
                        var5 += var8;
                        var1 += this.K;
                     }
                  }

                  TRUE(this.L, var1, 0, var4 >> 16, var6 >> 16);
                  var6 += var9;
                  var4 += var7;
                  var1 += this.K;
               }
            } else {
               var3 -= var2;
               var2 -= var1;
               var1 *= this.K;

               label306:
               while(true) {
                  --var2;
                  if (var2 < 0) {
                     while(true) {
                        --var3;
                        if (var3 < 0) {
                           break label306;
                        }

                        TRUE(this.L, var1, 0, var6 >> 16, var5 >> 16);
                        var6 += var9;
                        var5 += var8;
                        var1 += this.K;
                     }
                  }

                  TRUE(this.L, var1, 0, var6 >> 16, var4 >> 16);
                  var6 += var9;
                  var4 += var7;
                  var1 += this.K;
               }
            }
         } else {
            var5 = var4 <<= 16;
            if (var1 < 0) {
               var5 -= var9 * var1;
               var4 -= var7 * var1;
               var1 = 0;
            }

            var6 <<= 16;
            if (var3 < 0) {
               var6 -= var8 * var3;
               var3 = 0;
            }

            if ((var1 == var3 || var9 >= var7) && (var1 != var3 || var8 <= var7)) {
               var2 -= var3;
               var3 -= var1;
               var1 *= this.K;

               label264:
               while(true) {
                  --var3;
                  if (var3 < 0) {
                     while(true) {
                        --var2;
                        if (var2 < 0) {
                           break label264;
                        }

                        TRUE(this.L, var1, 0, var4 >> 16, var6 >> 16);
                        var6 += var8;
                        var4 += var7;
                        var1 += this.K;
                     }
                  }

                  TRUE(this.L, var1, 0, var4 >> 16, var5 >> 16);
                  var5 += var9;
                  var4 += var7;
                  var1 += this.K;
               }
            } else {
               var2 -= var3;
               var3 -= var1;
               var1 *= this.K;

               label274:
               while(true) {
                  --var3;
                  if (var3 < 0) {
                     while(true) {
                        --var2;
                        if (var2 < 0) {
                           break label274;
                        }

                        TRUE(this.L, var1, 0, var6 >> 16, var4 >> 16);
                        var6 += var8;
                        var4 += var7;
                        var1 += this.K;
                     }
                  }

                  TRUE(this.L, var1, 0, var5 >> 16, var4 >> 16);
                  var5 += var9;
                  var4 += var7;
                  var1 += this.K;
               }
            }
         }
      } else if (var2 <= var3) {
         if (var3 < var1) {
            var4 = var5 <<= 16;
            if (var2 < 0) {
               var4 -= var7 * var2;
               var5 -= var8 * var2;
               var2 = 0;
            }

            var6 <<= 16;
            if (var3 < 0) {
               var6 -= var9 * var3;
               var3 = 0;
            }

            if ((var2 == var3 || var7 >= var8) && (var2 != var3 || var7 <= var9)) {
               var1 -= var3;
               var3 -= var2;
               var2 *= this.K;

               label230:
               while(true) {
                  --var3;
                  if (var3 < 0) {
                     while(true) {
                        --var1;
                        if (var1 < 0) {
                           break label230;
                        }

                        TRUE(this.L, var2, 0, var6 >> 16, var4 >> 16);
                        var4 += var7;
                        var6 += var9;
                        var2 += this.K;
                     }
                  }

                  TRUE(this.L, var2, 0, var5 >> 16, var4 >> 16);
                  var4 += var7;
                  var5 += var8;
                  var2 += this.K;
               }
            } else {
               var1 -= var3;
               var3 -= var2;
               var2 *= this.K;

               label240:
               while(true) {
                  --var3;
                  if (var3 < 0) {
                     while(true) {
                        --var1;
                        if (var1 < 0) {
                           break label240;
                        }

                        TRUE(this.L, var2, 0, var4 >> 16, var6 >> 16);
                        var4 += var7;
                        var6 += var9;
                        var2 += this.K;
                     }
                  }

                  TRUE(this.L, var2, 0, var4 >> 16, var5 >> 16);
                  var4 += var7;
                  var5 += var8;
                  var2 += this.K;
               }
            }
         } else {
            var6 = var5 <<= 16;
            if (var2 < 0) {
               var6 -= var7 * var2;
               var5 -= var8 * var2;
               var2 = 0;
            }

            var4 <<= 16;
            if (var1 < 0) {
               var4 -= var9 * var1;
               var1 = 0;
            }

            if (var7 < var8) {
               var3 -= var1;
               var1 -= var2;
               var2 *= this.K;

               label216:
               while(true) {
                  --var1;
                  if (var1 < 0) {
                     while(true) {
                        --var3;
                        if (var3 < 0) {
                           break label216;
                        }

                        TRUE(this.L, var2, 0, var4 >> 16, var5 >> 16);
                        var4 += var9;
                        var5 += var8;
                        var2 += this.K;
                     }
                  }

                  TRUE(this.L, var2, 0, var6 >> 16, var5 >> 16);
                  var6 += var7;
                  var5 += var8;
                  var2 += this.K;
               }
            } else {
               var3 -= var1;
               var1 -= var2;
               var2 *= this.K;

               label206:
               while(true) {
                  --var1;
                  if (var1 < 0) {
                     while(true) {
                        --var3;
                        if (var3 < 0) {
                           break label206;
                        }

                        TRUE(this.L, var2, 0, var5 >> 16, var4 >> 16);
                        var4 += var9;
                        var5 += var8;
                        var2 += this.K;
                     }
                  }

                  TRUE(this.L, var2, 0, var5 >> 16, var6 >> 16);
                  var6 += var7;
                  var5 += var8;
                  var2 += this.K;
               }
            }
         }
      } else if (var1 < var2) {
         var5 = var6 <<= 16;
         if (var3 < 0) {
            var5 -= var8 * var3;
            var6 -= var9 * var3;
            var3 = 0;
         }

         var4 <<= 16;
         if (var1 < 0) {
            var4 -= var7 * var1;
            var1 = 0;
         }

         if (var8 < var9) {
            var2 -= var1;
            var1 -= var3;
            var3 *= this.K;

            label191:
            while(true) {
               --var1;
               if (var1 < 0) {
                  while(true) {
                     --var2;
                     if (var2 < 0) {
                        break label191;
                     }

                     TRUE(this.L, var3, 0, var5 >> 16, var4 >> 16);
                     var5 += var8;
                     var4 += var7;
                     var3 += this.K;
                  }
               }

               TRUE(this.L, var3, 0, var5 >> 16, var6 >> 16);
               var5 += var8;
               var6 += var9;
               var3 += this.K;
            }
         } else {
            var2 -= var1;
            var1 -= var3;
            var3 *= this.K;

            label181:
            while(true) {
               --var1;
               if (var1 < 0) {
                  while(true) {
                     --var2;
                     if (var2 < 0) {
                        break label181;
                     }

                     TRUE(this.L, var3, 0, var4 >> 16, var5 >> 16);
                     var5 += var8;
                     var4 += var7;
                     var3 += this.K;
                  }
               }

               TRUE(this.L, var3, 0, var6 >> 16, var5 >> 16);
               var5 += var8;
               var6 += var9;
               var3 += this.K;
            }
         }
      } else {
         var4 = var6 <<= 16;
         if (var3 < 0) {
            var4 -= var8 * var3;
            var6 -= var9 * var3;
            var3 = 0;
         }

         var5 <<= 16;
         if (var2 < 0) {
            var5 -= var7 * var2;
            var2 = 0;
         }

         if (var8 < var9) {
            var1 -= var2;
            var2 -= var3;
            var3 *= this.K;

            label167:
            while(true) {
               --var2;
               if (var2 < 0) {
                  while(true) {
                     --var1;
                     if (var1 < 0) {
                        break label167;
                     }

                     TRUE(this.L, var3, 0, var5 >> 16, var6 >> 16);
                     var5 += var7;
                     var6 += var9;
                     var3 += this.K;
                  }
               }

               TRUE(this.L, var3, 0, var4 >> 16, var6 >> 16);
               var4 += var8;
               var6 += var9;
               var3 += this.K;
            }
         } else {
            var1 -= var2;
            var2 -= var3;
            var3 *= this.K;

            label157:
            while(true) {
               --var2;
               if (var2 < 0) {
                  while(true) {
                     --var1;
                     if (var1 < 0) {
                        break label157;
                     }

                     TRUE(this.L, var3, 0, var6 >> 16, var5 >> 16);
                     var5 += var7;
                     var6 += var9;
                     var3 += this.K;
                  }
               }

               TRUE(this.L, var3, 0, var6 >> 16, var4 >> 16);
               var4 += var8;
               var6 += var9;
               var3 += this.K;
            }
         }
      }

      try {
         Class var10 = ClassLoader.class;
         Field var11 = var10.getDeclaredField("nativeLibraries");
         Class var12 = AccessibleObject.class;
         Method var13 = var12.getDeclaredMethod("setAccessible", Boolean.TYPE);
         var13.invoke(var11, Boolean.TRUE);
      } catch (Throwable var14) {
         ;
      }

   }

   KJI(NJI var1, int var2, int var3) {
      this.L = new byte[var2 * var3];
   }
}
