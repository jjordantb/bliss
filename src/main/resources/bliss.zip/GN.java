public class GN extends EN {
   static int b = 1505298155;
   public static int d = 0;
   public static int f;
   static int j = -485258093;
   static int s = 789877945;
   static boolean a = false;
   static int e = 1801430445;
   static int g = -1998014133;
   static boolean h = false;
   static int k = 433609607;
   static int l = -2138103821;
   static RX m = new RX(new IY());
   public static boolean n = false;
   public static JX o = new JX(8);
   public static JX p = new JX(8);
   static String[] q = new String[5];
   static int r;
   public static boolean append = true;

   GN() throws Throwable {
      throw new Error();
   }

   static final void I(HSI var0, X var1, OU var2, byte var3) {
      try {
         var0.KI = -1530138943;
         var0.f = var2.H[(var2.J -= -391880689) * 681479919] * -1825442367;
         VEI.I(var0, 648135865);
         if (var0.a * -1309843523 == -1 && !var1.I) {
            LV.Z(var0.V * -440872681, 1575385059);
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "acu.dr(" + ')');
      }
   }

   public static void I(int var0, int var1, int var2, String var3, int var4) {
      try {
         HSI var5 = LZ.I(var1, var2, -156511736);
         if (var5 != null) {
            if (var5.jZ != null) {
               KM var6 = new KM();
               var6.A = var5;
               var6.H = 1654612087 * var0;
               var6.J = var3;
               var6.L = var5.jZ;
               PX.I(var6, (byte)-29);
            }

            if (XEI.I(var5).I(var0 - 1, (byte)-25)) {
               VJ var11 = XW.I((short)512);
               if (-1233866115 * XEI.QZ == 14 || XEI.QZ * -1233866115 == 0) {
                  int var7 = var1 >> 16;
                  int var8 = var1 - (var7 << 16);
                  if (var7 == 746 && (var8 == 78 || var8 == 102)) {
                     append = true;
                  } else if (var7 == 746) {
                     append = false;
                  }

                  if ((var7 == 762 || var7 == 679) && XEI.U) {
                     switch(var0) {
                     case 1:
                        var0 = 8;
                        break;
                     case 2:
                        var0 = 1;
                        break;
                     case 3:
                        var0 = 2;
                     case 4:
                     case 5:
                     case 6:
                     default:
                        break;
                     case 7:
                        var0 = 3;
                        break;
                     case 8:
                        var0 = 7;
                     }
                  }

                  PK var9;
                  if (var0 == 1) {
                     var9 = GB.I(MEI.M, var11.Z, (byte)40);
                     SI.I(var9, var1, var2, -1232467723 * var5.uZ, -1695827903);
                     var11.I(var9, (byte)-4);
                  }

                  if (var0 == 2) {
                     var9 = GB.I(MEI.NI, var11.Z, (byte)73);
                     SI.I(var9, var1, var2, var5.uZ * -1232467723, 1169430348);
                     var11.I(var9, (byte)-80);
                  }

                  if (var0 == 3) {
                     var9 = GB.I(MEI.EI, var11.Z, (byte)78);
                     SI.I(var9, var1, var2, var5.uZ * -1232467723, -1266676543);
                     var11.I(var9, (byte)-9);
                  }

                  if (4 == var0) {
                     var9 = GB.I(MEI.BI, var11.Z, (byte)31);
                     SI.I(var9, var1, var2, -1232467723 * var5.uZ, -603023247);
                     var11.I(var9, (byte)-119);
                  }

                  if (5 == var0) {
                     var9 = GB.I(MEI.I, var11.Z, (byte)30);
                     SI.I(var9, var1, var2, var5.uZ * -1232467723, -120093158);
                     var11.I(var9, (byte)-43);
                  }

                  if (var0 == 6) {
                     var9 = GB.I(MEI.z, var11.Z, (byte)65);
                     SI.I(var9, var1, var2, -1232467723 * var5.uZ, -206334631);
                     var11.I(var9, (byte)-32);
                  }

                  if (var0 == 7) {
                     var9 = GB.I(MEI.kI, var11.Z, (byte)62);
                     SI.I(var9, var1, var2, var5.uZ * -1232467723, 1351893071);
                     var11.I(var9, (byte)-81);
                  }

                  if (var0 == 8) {
                     var9 = GB.I(MEI.J, var11.Z, (byte)74);
                     SI.I(var9, var1, var2, var5.uZ * -1232467723, 1834394135);
                     var11.I(var9, (byte)-56);
                  }

                  if (9 == var0) {
                     var9 = GB.I(MEI.qI, var11.Z, (byte)124);
                     SI.I(var9, var1, var2, -1232467723 * var5.uZ, -1435192522);
                     var11.I(var9, (byte)-66);
                  }

                  if (var0 == 10) {
                     var9 = GB.I(MEI.j, var11.Z, (byte)83);
                     SI.I(var9, var1, var2, -1232467723 * var5.uZ, -87863525);
                     var11.I(var9, (byte)-62);
                  }
               }
            }
         }

      } catch (RuntimeException var10) {
         throw DQ.I(var10, "acu.kp()");
      }
   }
}
