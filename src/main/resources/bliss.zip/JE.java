public class JE {
   public int[] I;
   public int Z;
   public int[] C;

   public JE(int var1) {
      this.Z = 526813095 * var1;
      this.I = new int[this.Z * -1407078377];
      this.C = new int[this.Z * -1407078377];
   }

   static final void I(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         XK var3 = TX.C.I(var2, (short)-22209);
         if (var3.H == null) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = var3.H.length;
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "mi.acn(" + ')');
      }
   }

   public static long I(int var0, int var1, int var2, int var3, int var4, int var5, byte var6) {
      try {
         WII.C.clear();
         WII.C.set(var5, var4, var3, var2, var1, var0);
         return WII.C.getTime().getTime();
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "mi.x(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.T.Z(-919235605) == 1 ? 1 : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "mi.ajl(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         int var2 = var0.X[var0.i * 1883543357];
         var0.A -= var2 * 969361751;
         String var3 = QJI.I(var0.S, -203050393 * var0.A, var2, (byte)0);
         var0.S[(var0.A += 969361751) * -203050393 - 1] = var3;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "mi.aw(" + ')');
      }
   }

   static final void C(OU var0, byte var1) {
      try {
         var0.A -= 1938723502;
         var0.J -= -783761378;
         GB.I((String)var0.S[var0.A * -203050393], (String)var0.S[-203050393 * var0.A + 1], var0.H[var0.J * 681479919], 1 == var0.H[1 + 681479919 * var0.J], -1761866879);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "mi.age(" + ')');
      }
   }

   static void I(int var0, int var1, int var2, int var3, int var4, int var5) {
      try {
         int var6 = 0;
         int var7 = var3;
         int var8 = var2 * var2;
         int var9 = var3 * var3;
         int var10 = var9 << 1;
         int var11 = var8 << 1;
         int var12 = var3 << 1;
         int var13 = (1 - var12) * var8 + var10;
         int var14 = var9 - var11 * (var12 - 1);
         int var15 = var8 << 2;
         int var16 = var9 << 2;
         int var17 = var10 * ((var6 << 1) + 3);
         int var18 = var11 * ((var3 << 1) - 3);
         int var19 = var16 * (1 + var6);
         int var20 = var15 * (var3 - 1);
         int var21;
         int var22;
         if (var1 >= ZT.C * 1155384281 && var1 <= ZT.B * -1062447355) {
            var21 = HY.I(var2 + var0, ZT.D * -1424479739, ZT.Z * 1135094847, -1212608691);
            var22 = HY.I(var0 - var2, ZT.D * -1424479739, ZT.Z * 1135094847, -1212608691);
            DFI.I(ZT.I[var1], var22, var21, var4, 1327265891);
         }

         while(var7 > 0) {
            if (var13 < 0) {
               while(var13 < 0) {
                  var13 += var17;
                  var14 += var19;
                  var17 += var16;
                  var19 += var16;
                  ++var6;
               }
            }

            if (var14 < 0) {
               var13 += var17;
               var14 += var19;
               var17 += var16;
               var19 += var16;
               ++var6;
            }

            var13 += -var20;
            var14 += -var18;
            var18 -= var15;
            var20 -= var15;
            --var7;
            var21 = var1 - var7;
            var22 = var7 + var1;
            if (var22 >= ZT.C * 1155384281 && var21 <= ZT.B * -1062447355) {
               int var23 = HY.I(var0 + var6, -1424479739 * ZT.D, 1135094847 * ZT.Z, -1212608691);
               int var24 = HY.I(var0 - var6, -1424479739 * ZT.D, ZT.Z * 1135094847, -1212608691);
               if (var21 >= 1155384281 * ZT.C) {
                  DFI.I(ZT.I[var21], var24, var23, var4, -2141002125);
               }

               if (var22 <= -1062447355 * ZT.B) {
                  DFI.I(ZT.I[var22], var24, var23, var4, 1394048143);
               }
            }
         }

      } catch (RuntimeException var25) {
         throw DQ.I(var25, "mi.ah(" + ')');
      }
   }
}
