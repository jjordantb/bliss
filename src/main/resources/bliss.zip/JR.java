public class JR extends ZR implements HAI {
   UT V;
   byte KA;
   GJI PA;
   HP YA;
   int append;
   CX i;
   byte m;
   boolean method4739;
   boolean method4745;
   boolean method4755;
   boolean method4784;

   boolean method4400() {
      return this.method4784;
   }

   public void method40(GSI var1) {
      Object var2 = null;
      GJI var3;
      if (this.PA == null && this.method4745) {
         ZY var4 = this.KA(var1, 262144, true, -1968877061);
         var3 = (GJI)(var4 != null ? var4.Z : null);
      } else {
         var3 = this.PA;
         this.PA = null;
      }

      SF var5 = this.I().I;
      if (var3 != null) {
         this.H.I(var3, this.L, (int)var5.I, (int)var5.Z, (boolean[])null, 612367667);
      }

   }

   boolean method4369() {
      return this.V != null ? this.V.i() : false;
   }

   public int method4361(int var1) {
      try {
         return this.V != null ? this.V.YA() : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wf.bm(" + ')');
      }
   }

   UT F(GSI var1, int var2, int var3) {
      try {
         if (this.V != null && var1.method5017(this.V.m(), var2) == 0) {
            return this.V;
         } else {
            ZY var4 = this.KA(var1, var2, false, -1828314772);
            return var4 != null ? (UT)var4.I : null;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "wf.bl(" + ')');
      }
   }

   void method4371(GSI var1) {
   }

   public HP method4358(GSI var1, byte var2) {
      try {
         SF var3 = this.I().I;
         if (this.YA == null) {
            this.YA = TY.I((int)var3.I, (int)var3.C, (int)var3.Z, this.F(var1, 0, 720922451), 2111696382);
         }

         return this.YA;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "wf.bc(" + ')');
      }
   }

   public int method29(int var1) {
      try {
         return this.KA;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wf.f(" + ')');
      }
   }

   public void method28(GSI var1) {
      Object var2 = null;
      GJI var3;
      if (this.PA == null && this.method4745) {
         ZY var4 = this.KA(var1, 262144, true, -1624110229);
         var3 = (GJI)(var4 != null ? var4.Z : null);
      } else {
         var3 = this.PA;
         this.PA = null;
      }

      SF var5 = this.I().I;
      if (var3 != null) {
         this.H.Z(var3, this.L, (int)var5.I, (int)var5.Z, (boolean[])null, 1156448479);
      }

   }

   boolean method4350(GSI var1, int var2, int var3, byte var4) {
      try {
         UT var5 = this.F(var1, 131072, -114494856);
         if (var5 != null) {
            LF var6 = this.J();
            return var5.method4787(var2, var3, var6, false, 0);
         } else {
            return false;
         }
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "wf.bu(" + ')');
      }
   }

   boolean method4366(int var1) {
      try {
         return this.method4784;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wf.bw(" + ')');
      }
   }

   void method4355(GSI var1, IR var2, int var3, int var4, int var5, boolean var6, int var7) {
      try {
         if (var2 instanceof OR) {
            OR var8 = (OR)var2;
            if (this.V != null && var8.i != null) {
               this.V.method4745(var8.i, var3, var4, var5, var6);
            }
         } else if (var2 instanceof JR) {
            JR var10 = (JR)var2;
            if (this.V != null && var10.V != null) {
               this.V.method4745(var10.V, var3, var4, var5, var6);
            }
         }

      } catch (RuntimeException var9) {
         throw DQ.I(var9, "wf.bk(" + ')');
      }
   }

   void method4398(byte var1) {
      try {
         this.method4784 = false;
         if (this.V != null) {
            this.V.KA(this.V.m() & -65537);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wf.bq(" + ')');
      }
   }

   boolean method4349() {
      return this.V != null ? this.V.i() : false;
   }

   public int method30(short var1) {
      try {
         return this.m;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wf.b(" + ')');
      }
   }

   public void method31(byte var1) {
      try {
         if (this.V != null) {
            this.V.method4784();
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wf.p(" + ')');
      }
   }

   public boolean method39(int var1) {
      try {
         return this.method4745;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wf.i(" + ')');
      }
   }

   public void method44(GSI var1) {
      Object var2 = null;
      GJI var3;
      if (this.PA == null && this.method4745) {
         ZY var4 = this.KA(var1, 262144, true, -1865263954);
         var3 = (GJI)(var4 != null ? var4.Z : null);
      } else {
         var3 = this.PA;
         this.PA = null;
      }

      SF var5 = this.I().I;
      if (var3 != null) {
         this.H.I(var3, this.L, (int)var5.I, (int)var5.Z, (boolean[])null, 1005842960);
      }

   }

   void method4357(GSI var1, int var2) {
   }

   KP method4394(GSI var1, int var2) {
      try {
         if (this.V == null) {
            return null;
         } else {
            LF var3 = this.J();
            KP var4 = BDI.I(this.method4755, 1956566103);
            this.V.method4739(var3, this.N[0], 0);
            return var4;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "wf.bo(" + ')');
      }
   }

   public int method45() {
      return 614847827 * this.append;
   }

   public int method36() {
      return this.KA;
   }

   boolean method4365() {
      if (this.V != null) {
         return !this.V.u();
      } else {
         return true;
      }
   }

   public int method42() {
      return this.m;
   }

   public int method38() {
      return this.m;
   }

   public void method34() {
      if (this.V != null) {
         this.V.method4784();
      }

   }

   public boolean method41() {
      return this.method4745;
   }

   public int method4381() {
      return this.V != null ? this.V.YA() : 0;
   }

   public void method43(GSI var1) {
      Object var2 = null;
      GJI var3;
      if (this.PA == null && this.method4745) {
         ZY var4 = this.KA(var1, 262144, true, -1678242522);
         var3 = (GJI)(var4 != null ? var4.Z : null);
      } else {
         var3 = this.PA;
         this.PA = null;
      }

      SF var5 = this.I().I;
      if (var3 != null) {
         this.H.I(var3, this.L, (int)var5.I, (int)var5.Z, (boolean[])null, 2123208646);
      }

   }

   public JR(AP var1, GSI var2, CX var3, KEI var4, int var5, int var6, int var7, int var8, int var9, boolean var10, int var11, int var12, int var13, int var14, int var15, int var16, boolean var17) {
      super(var1, var5, var6, var7, var8, var9, var11, var12, var13, var14, 512737201 * var4.h == 1, EDI.I(var15, var16, (byte)27));
      this.i = var3;
      this.append = var4.Z * 1514496897;
      this.L = (byte)var6;
      this.method4739 = var10;
      this.KA = (byte)var15;
      this.m = (byte)var16;
      this.method4755 = 1532834983 * var4.K != 0 && !var10;
      this.method4784 = var17;
      this.method4745 = var2.method5082() && var4.CI && !this.method4739 && FW.J.m.C(3122198) != 0;
      int var18 = 2048;
      if (this.method4784) {
         var18 |= 65536;
      }

      if (var4.GI) {
         var18 |= 524288;
      }

      ZY var19 = this.KA(var2, var18, this.method4745, -1835687018);
      if (var19 != null) {
         this.V = (UT)var19.I;
         this.PA = (GJI)var19.Z;
         if (this.method4784 || var4.GI) {
            this.V = this.V.method4755((byte)0, var18, false);
            if (var4.GI) {
               UA var20 = XEI.mI.D(-1997873817);
               this.V.PA(1599271859 * var20.I, var20.Z * 1630923113, var20.C * -1560648831, var20.B * -57569897);
            }
         }
      }

      this.I(1, 1215264227);
   }

   boolean method4353() {
      if (this.V != null) {
         return !this.V.u();
      } else {
         return true;
      }
   }

   KP method4370(GSI var1) {
      if (this.V == null) {
         return null;
      } else {
         LF var2 = this.J();
         KP var3 = BDI.I(this.method4755, 1628879403);
         this.V.method4739(var2, this.N[0], 0);
         return var3;
      }
   }

   boolean method4374() {
      if (this.V != null) {
         return !this.V.u();
      } else {
         return true;
      }
   }

   public HP method4367(GSI var1) {
      SF var2 = this.I().I;
      if (this.YA == null) {
         this.YA = TY.I((int)var2.I, (int)var2.C, (int)var2.Z, this.F(var1, 0, 489982768), 2048305004);
      }

      return this.YA;
   }

   public HP method4368(GSI var1) {
      SF var2 = this.I().I;
      if (this.YA == null) {
         this.YA = TY.I((int)var2.I, (int)var2.C, (int)var2.Z, this.F(var1, 0, 2128967957), 2011596409);
      }

      return this.YA;
   }

   ZY KA(GSI var1, int var2, boolean var3, int var4) {
      try {
         KEI var5 = this.i.C(this.append * 614847827);
         YJI var6;
         YJI var7;
         if (this.method4739) {
            var6 = this.H.M[this.L];
            var7 = this.H.K[0];
         } else {
            var6 = this.H.K[this.L];
            if (this.L < 3) {
               var7 = this.H.K[1 + this.L];
            } else {
               var7 = null;
            }
         }

         SF var8 = this.I().I;
         return var5.I(var1, var2, this.KA != RW.L.V * -1976050083 ? this.KA : RW.T.V * -1976050083, RW.L.V * -1976050083 == this.KA ? this.m + 4 : this.m, var6, var7, (int)var8.I, (int)var8.C, (int)var8.Z, var3, (DX)null, -920698887);
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "wf.br(" + ')');
      }
   }

   public int I(short var1) {
      try {
         return this.V != null ? this.V.N() / 4 : 15;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wf.bz(" + ')');
      }
   }

   void method4373(GSI var1) {
   }

   boolean method4372(GSI var1, int var2, int var3) {
      UT var4 = this.F(var1, 131072, -259800971);
      if (var4 != null) {
         LF var5 = this.J();
         return var4.method4787(var2, var3, var5, false, 0);
      } else {
         return false;
      }
   }

   boolean method4385(GSI var1, int var2, int var3) {
      UT var4 = this.F(var1, 131072, 547557370);
      if (var4 != null) {
         LF var5 = this.J();
         return var4.method4787(var2, var3, var5, false, 0);
      } else {
         return false;
      }
   }

   boolean method4352(GSI var1, int var2, int var3) {
      UT var4 = this.F(var1, 131072, -943107376);
      if (var4 != null) {
         LF var5 = this.J();
         return var4.method4787(var2, var3, var5, false, 0);
      } else {
         return false;
      }
   }

   void method4375(GSI var1, IR var2, int var3, int var4, int var5, boolean var6) {
      if (var2 instanceof OR) {
         OR var7 = (OR)var2;
         if (this.V != null && var7.i != null) {
            this.V.method4745(var7.i, var3, var4, var5, var6);
         }
      } else if (var2 instanceof JR) {
         JR var8 = (JR)var2;
         if (this.V != null && var8.V != null) {
            this.V.method4745(var8.V, var3, var4, var5, var6);
         }
      }

   }

   void method4388(GSI var1, IR var2, int var3, int var4, int var5, boolean var6) {
      if (var2 instanceof OR) {
         OR var7 = (OR)var2;
         if (this.V != null && var7.i != null) {
            this.V.method4745(var7.i, var3, var4, var5, var6);
         }
      } else if (var2 instanceof JR) {
         JR var8 = (JR)var2;
         if (this.V != null && var8.V != null) {
            this.V.method4745(var8.V, var3, var4, var5, var6);
         }
      }

   }

   boolean method4351() {
      return this.V != null ? this.V.i() : false;
   }

   void method4378() {
      this.method4784 = false;
      if (this.V != null) {
         this.V.KA(this.V.m() & -65537);
      }

   }

   public int method4379() {
      return this.V != null ? this.V.YA() : 0;
   }

   public int method4380() {
      return this.V != null ? this.V.YA() : 0;
   }

   public void method37(GSI var1, int var2) {
      try {
         Object var3 = null;
         GJI var4;
         if (this.PA == null && this.method4745) {
            ZY var5 = this.KA(var1, 262144, true, -2139710295);
            var4 = (GJI)(var5 != null ? var5.Z : null);
         } else {
            var4 = this.PA;
            this.PA = null;
         }

         SF var7 = this.I().I;
         if (var4 != null) {
            this.H.I(var4, this.L, (int)var7.I, (int)var7.Z, (boolean[])null, 1871597287);
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "wf.d(" + ')');
      }
   }

   boolean method4399(byte var1) {
      try {
         if (this.V != null) {
            return !this.V.u();
         } else {
            return true;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wf.bf(" + ')');
      }
   }

   boolean method4382() {
      return this.V != null ? this.V.i() : false;
   }

   boolean method4376(short var1) {
      try {
         return this.V != null ? this.V.i() : false;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wf.be(" + ')');
      }
   }

   boolean method4383() {
      return this.V != null ? this.V.i() : false;
   }

   void method4377() {
      this.method4784 = false;
      if (this.V != null) {
         this.V.KA(this.V.m() & -65537);
      }

   }

   boolean method4384() {
      return this.method4784;
   }

   public void method33(GSI var1, int var2) {
      try {
         Object var3 = null;
         GJI var4;
         if (this.PA == null && this.method4745) {
            ZY var5 = this.KA(var1, 262144, true, -1616676956);
            var4 = (GJI)(var5 != null ? var5.Z : null);
         } else {
            var4 = this.PA;
            this.PA = null;
         }

         SF var7 = this.I().I;
         if (var4 != null) {
            this.H.Z(var4, this.L, (int)var7.I, (int)var7.Z, (boolean[])null, -808327981);
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "wf.k(" + ')');
      }
   }

   boolean method4386() {
      return this.method4784;
   }

   boolean method4387() {
      return this.method4784;
   }

   public int method35() {
      return this.KA;
   }

   public int method32(byte var1) {
      try {
         return 614847827 * this.append;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wf.a(" + ')');
      }
   }

   static void I(GSI var0, int var1) {
      try {
         if (UA.F.K != -1694437021 * JN.B && XEI.mI.T(-1611682495) != null) {
            CI.I((byte)1);
            if (QZ.I(var0, UA.F.K, 1177065502)) {
               JN.B = UA.F.K * -955770805;
            }
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wf.p(" + ')');
      }
   }
}
