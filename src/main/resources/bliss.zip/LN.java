public class LN extends HN {
   short C;
   int B = (int)(CI.I((byte)1) / 1000L) * -576925551;
   String D;

   LN(String var1, int var2) {
      this.D = var1;
      this.C = (short)var2;
   }

   public static void I(int var0, byte var1) {
      try {
         VK var2 = IV.I(17, (long)var0);
         var2.B(-1772707008);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aan.ak(" + ')');
      }
   }
}
