public class BM extends RL {
   LC append;
   byte toString;
   byte J;
   boolean S;
   byte A;
   byte E;

   void method3509(REI var1) {
      this.S = var1.I() == 1;
      this.toString = var1.S(-12558881);
      this.J = var1.S(-12558881);
      this.E = var1.S(-12558881);
      this.A = var1.S(-12558881);
   }

   void method3508(REI var1, int var2) {
      try {
         this.S = var1.I() == 1;
         this.toString = var1.S(-12558881);
         this.J = var1.S(-12558881);
         this.E = var1.S(-12558881);
         this.A = var1.S(-12558881);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "agi.a(" + ')');
      }
   }

   BM(LC var1) {
      this.append = var1;
   }

   void method3511(QC var1) {
      var1.B = this.S;
      var1.Q = this.toString;
      var1.F = this.J;
      var1.J = this.E;
      var1.S = this.A;
   }

   void method3510(QC var1, byte var2) {
      try {
         var1.B = this.S;
         var1.Q = this.toString;
         var1.F = this.J;
         var1.J = this.E;
         var1.S = this.A;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "agi.f(" + ')');
      }
   }

   void method3512(REI var1) {
      this.S = var1.I() == 1;
      this.toString = var1.S(-12558881);
      this.J = var1.S(-12558881);
      this.E = var1.S(-12558881);
      this.A = var1.S(-12558881);
   }
}
