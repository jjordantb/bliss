public class HO {
   int C;
   String Z;
   int append;
   int indexOf;
   int intValue;

   int I(byte var1) {
      try {
         return 1497963413 * this.intValue;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "my.a(" + ')');
      }
   }

   int Z(byte var1) {
      try {
         return -731303013 * this.append;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "my.b(" + ')');
      }
   }

   int I(int var1) {
      try {
         return 623816081 * this.indexOf;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "my.p(" + ')');
      }
   }

   String Z(int var1) {
      try {
         return this.Z;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "my.i(" + ')');
      }
   }

   int C(int var1) {
      try {
         return this.C * -1285373955;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "my.f(" + ')');
      }
   }

   public HO(int var1, int var2, int var3, int var4, String var5) {
      this.intValue = var1 * -2008328259;
      this.C = var2 * -1378314923;
      this.append = 28768915 * var3;
      this.indexOf = -1845906575 * var4;
      this.Z = var5;
   }

   static void I(OU var0, int var1) {
      try {
         var0.H[681479919 * var0.J - 2] = OO.I.I(var0.H[var0.J * 681479919 - 2], 245040087).I((int[])XEI.hC, var0.H[var0.J * 681479919 - 1], (byte)47) ? 1 : 0;
         var0.J -= -391880689;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "my.y(" + ')');
      }
   }

   public static void I(String var0, boolean var1, int var2) {
      try {
         var0 = var0.toLowerCase();
         short[] var3 = new short[16];
         int var4 = 0;
         int var5 = var1 ? '耀' : 0;
         int var6 = (var1 ? TX.C.C * 1637004669 : TX.C.I * 1143516897) + var5;

         for(int var7 = var5; var7 < var6; ++var7) {
            XK var8 = TX.C.I(var7, (short)-11352);
            if (var8.K) {
               if (var8.I((byte)-92).toLowerCase().indexOf(var0) == -1) {
                  if (var2 <= -1272557020) {
                     return;
                  }
               } else {
                  if (var4 >= 50) {
                     CQ.L = -140296601;
                     WBI.S = null;
                     return;
                  }

                  if (var4 >= var3.length) {
                     short[] var9 = new short[var3.length * 2];

                     for(int var10 = 0; var10 < var4; ++var10) {
                        var9[var10] = var3[var10];
                     }

                     var3 = var9;
                  }

                  var3[var4++] = (short)var7;
               }
            }
         }

         WBI.S = var3;
         GJ.Z = 0;
         CQ.L = var4 * 140296601;
         String[] var12 = new String[CQ.L * 367592105];

         for(int var13 = 0; var13 < CQ.L * 367592105; ++var13) {
            var12[var13] = TX.C.I(var3[var13], (short)-23170).I((byte)-73);
         }

         MF.I(var12, WBI.S, -1747372319);
      } catch (RuntimeException var11) {
         throw DQ.I(var11, "my.nc(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         ODI.C(-1563671491);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "my.agf(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         int var2 = var0.X[var0.i * 1883543357];
         BCI var3 = EJI.I.Z(var2, 65536);
         if ('\u0001' != var3.C) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
         }

         Integer var4 = (Integer)LO.C[var3.Z * 216249401];
         if (var4 == null) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
         } else {
            int var5 = -1635784577 * var3.B == 31 ? -1 : (1 << -1635784577 * var3.B + 1) - 1;
            var0.H[(var0.J += -391880689) * 681479919 - 1] = (var4.intValue() & var5) >>> -1673918633 * var3.I;
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "my.bg(" + ')');
      }
   }
}
