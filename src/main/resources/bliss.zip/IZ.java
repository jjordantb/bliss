public class IZ {
   static IZ I = new IZ();
   static IZ Z = new IZ();
   static IZ C = new IZ();
   public static KJ B;

   public int I(int var1, int var2, int var3) {
      try {
         int var4 = JM.J * -1111710645 > var2 ? -1111710645 * JM.J : var2;
         if (this == Z) {
            return 0;
         } else if (I == this) {
            return var4 - var1;
         } else {
            return C == this ? (var4 - var1) / 2 : 0;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "fj.f(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         GEI var2 = (GEI)var0.E;
         boolean var3 = false;
         HEI var4 = var2.tI;
         if (var4.ZI != null) {
            var4 = var4.I((FAI)MI.E, 1885989341);
         }

         if (var4 != null) {
            var3 = var4.c;
         }

         var0.H[(var0.J += -391880689) * 681479919 - 1] = var3 ? 1 : 0;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "fj.apz(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         DT.I(var3, var4, var0, 1567634168);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "fj.hr(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         MI.I(var3, var4, var0, -588058138);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "fj.hz(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         int var3 = var2 >> 14 & 16383;
         int var4 = var2 & 16383;
         XP var5 = XEI.mI.I(681479919);
         var3 -= -1760580017 * var5.I;
         if (var3 < 0) {
            var3 = 0;
         } else if (var3 >= XEI.mI.Z(-1870653657)) {
            var3 = XEI.mI.Z(-2106000427);
         }

         var4 -= var5.Z * 283514611;
         if (var4 < 0) {
            var4 = 0;
         } else if (var4 >= XEI.mI.C(787275205)) {
            var4 = XEI.mI.C(11403406);
         }

         XEI.RZ = 672497503 * ((var3 << 9) + 256);
         XEI.UZ = 957476733 * ((var4 << 9) + 256);
         EE.V = -1469516446;
         AV.I = -1001372047;
         B.XZ = 178575833;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "fj.agl(" + ')');
      }
   }
}
