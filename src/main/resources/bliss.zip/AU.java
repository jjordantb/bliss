public final class AU {
   static short I;
   volatile String Z;
   public volatile int C = -842879005;
   static boolean B;

   AU(String var1) {
      this.Z = var1;
   }

   static void I(String var0, int var1) {
      try {
         XEI.XD = var0;
         if (IU.I((byte)-104) != CE.I) {
            try {
               String var2 = DSI.C.getParameter(QD.N.j);
               String var3 = DSI.C.getParameter(QD.R.j);
               String var4 = var2 + "settings=" + var0 + "; version=1; path=/; domain=" + var3;
               if (var0.length() == 0) {
                  var4 = var4 + "; Expires=Thu, 01-Jan-1970 00:00:00 GMT; Max-Age=0";
               } else {
                  var4 = var4 + "; Expires=" + TN.I(CI.I((byte)1) + 94608000000L) + "; Max-Age=" + 94608000L;
               }

               MY.I(DSI.C, "document.cookie=\"" + var4 + "\"", -1926451476);
            } catch (Throwable var5) {
               ;
            }
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "qk.nf(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         if (OZI.Z != null) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 1;
            var0.R = OZI.Z;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "qk.wk(" + ')');
      }
   }

   public static final boolean I(String var0, String var1, String var2, String var3, int var4) {
      try {
         if (var0 != null && var2 != null) {
            return !var0.startsWith("#") && !var2.startsWith("#") ? var1.equals(var3) : var0.equals(var2);
         } else {
            return false;
         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "qk.a(" + ')');
      }
   }
}
