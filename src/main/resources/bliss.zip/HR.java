public class HR extends GR implements HAI {
   boolean append = true;
   boolean charAt;
   HP i;
   public GBI R;

   public void method34() {
   }

   boolean method4376(short var1) {
      try {
         return this.append;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wl.be(" + ')');
      }
   }

   public HP method4358(GSI var1, byte var2) {
      try {
         return this.i;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "wl.bc(" + ')');
      }
   }

   public int method4361(int var1) {
      try {
         return this.R.Z(128726833);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wl.bm(" + ')');
      }
   }

   public int Z(byte var1) {
      try {
         return this.R.I(2145016917);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wl.bx(" + ')');
      }
   }

   public void I(DX var1, byte var2) {
      try {
         this.R.I(var1, -1138005946);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "wl.by(" + ')');
      }
   }

   boolean method4351() {
      return this.append;
   }

   void method4357(GSI var1, int var2) {
      try {
         UT var3 = this.R.I(var1, 262144, false, true, (byte)75);
         if (var3 != null) {
            LF var4 = this.J();
            ZJ var5 = this.I();
            int var6 = (int)var5.I.I >> 9;
            int var7 = (int)var5.I.Z >> 9;
            this.R.I(var1, var3, var4, var6, var6, var7, var7, false, 1852542070);
         }

      } catch (RuntimeException var8) {
         throw DQ.I(var8, "wl.bb(" + ')');
      }
   }

   boolean method4350(GSI var1, int var2, int var3, byte var4) {
      try {
         UT var5 = this.R.I(var1, 131072, false, false, (byte)63);
         return var5 == null ? false : var5.method4787(var2, var3, this.J(), false, 0);
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "wl.bu(" + ')');
      }
   }

   public int method32(byte var1) {
      try {
         return 1686561661 * this.R.S;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wl.a(" + ')');
      }
   }

   public int method29(int var1) {
      try {
         return this.R.I * -1598457753;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wl.f(" + ')');
      }
   }

   public int method30(short var1) {
      try {
         return 748228569 * this.R.Z;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wl.b(" + ')');
      }
   }

   public void method31(byte var1) {
   }

   public boolean method39(int var1) {
      try {
         return this.R.C(-1796811837);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wl.i(" + ')');
      }
   }

   boolean method4365() {
      return false;
   }

   public void method37(GSI var1, int var2) {
      try {
         this.R.Z(var1, -475225909);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "wl.d(" + ')');
      }
   }

   public void method33(GSI var1, int var2) {
      try {
         this.R.I(var1, 174352681);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "wl.k(" + ')');
      }
   }

   public int method36() {
      return this.R.I * -1598457753;
   }

   boolean method4383() {
      return this.append;
   }

   public int method42() {
      return 748228569 * this.R.Z;
   }

   public int method38() {
      return 748228569 * this.R.Z;
   }

   boolean method4349() {
      return this.append;
   }

   boolean method4399(byte var1) {
      return false;
   }

   KP method4370(GSI var1) {
      UT var2 = this.R.I(var1, 2048, false, true, (byte)-76);
      if (var2 == null) {
         return null;
      } else {
         LF var3 = var1.method5178();
         var3.I(this.J());
         var3.C((float)this.O, 0.0F, (float)this.P);
         ZJ var4 = this.I();
         KP var5 = BDI.I(this.charAt, 1290253643);
         int var6 = (int)var4.I.I >> 9;
         int var7 = (int)var4.I.Z >> 9;
         this.R.I(var1, var2, var3, var6, var6, var7, var7, true, 1549011469);
         var2.method4739(var3, this.N[0], 0);
         if (this.R.A != null) {
            XBI var8 = this.R.A.D();
            var1.method5042(var8);
         }

         this.append = var2.i() || this.R.A != null;
         if (this.i == null) {
            this.i = TY.I((int)var4.I.I, (int)var4.I.C, (int)var4.I.Z, var2, 1999311873);
         } else {
            QS.I(this.i, (int)var4.I.I, (int)var4.I.C, (int)var4.I.Z, var2, (byte)74);
         }

         return var5;
      }
   }

   public void method43(GSI var1) {
      this.R.Z(var1, -475225909);
   }

   public void method44(GSI var1) {
      this.R.Z(var1, -475225909);
   }

   public void method40(GSI var1) {
      this.R.Z(var1, -475225909);
   }

   boolean method4353() {
      return false;
   }

   boolean method4369() {
      return this.append;
   }

   boolean method4374() {
      return false;
   }

   void method4371(GSI var1) {
      UT var2 = this.R.I(var1, 262144, false, true, (byte)34);
      if (var2 != null) {
         LF var3 = this.J();
         ZJ var4 = this.I();
         int var5 = (int)var4.I.I >> 9;
         int var6 = (int)var4.I.Z >> 9;
         this.R.I(var1, var2, var3, var5, var5, var6, var6, false, 22822212);
      }

   }

   public int method35() {
      return this.R.I * -1598457753;
   }

   public int S() {
      return this.R.I(2068020131);
   }

   public int append() {
      return this.R.I(2094377016);
   }

   void method4373(GSI var1) {
      UT var2 = this.R.I(var1, 262144, false, true, (byte)16);
      if (var2 != null) {
         LF var3 = this.J();
         ZJ var4 = this.I();
         int var5 = (int)var4.I.I >> 9;
         int var6 = (int)var4.I.Z >> 9;
         this.R.I(var1, var2, var3, var5, var5, var6, var6, false, 386620711);
      }

   }

   KP method4394(GSI var1, int var2) {
      try {
         UT var3 = this.R.I(var1, 2048, false, true, (byte)-55);
         if (var3 == null) {
            return null;
         } else {
            LF var4 = var1.method5178();
            var4.I(this.J());
            var4.C((float)this.O, 0.0F, (float)this.P);
            ZJ var5 = this.I();
            KP var6 = BDI.I(this.charAt, 1881845078);
            int var7 = (int)var5.I.I >> 9;
            int var8 = (int)var5.I.Z >> 9;
            this.R.I(var1, var3, var4, var7, var7, var8, var8, true, -43742513);
            var3.method4739(var4, this.N[0], 0);
            if (this.R.A != null) {
               XBI var9 = this.R.A.D();
               var1.method5042(var9);
            }

            this.append = var3.i() || this.R.A != null;
            if (this.i == null) {
               this.i = TY.I((int)var5.I.I, (int)var5.I.C, (int)var5.I.Z, var3, 2072413227);
            } else {
               QS.I(this.i, (int)var5.I.I, (int)var5.I.C, (int)var5.I.Z, var3, (byte)84);
            }

            return var6;
         }
      } catch (RuntimeException var10) {
         throw DQ.I(var10, "wl.bo(" + ')');
      }
   }

   public HP method4368(GSI var1) {
      return this.i;
   }

   boolean method4372(GSI var1, int var2, int var3) {
      UT var4 = this.R.I(var1, 131072, false, false, (byte)4);
      return var4 == null ? false : var4.method4787(var2, var3, this.J(), false, 0);
   }

   public void method28(GSI var1) {
      this.R.I(var1, 2051751369);
   }

   boolean method4352(GSI var1, int var2, int var3) {
      UT var4 = this.R.I(var1, 131072, false, false, (byte)-39);
      return var4 == null ? false : var4.method4787(var2, var3, this.J(), false, 0);
   }

   public int method4379() {
      return this.R.Z(1794626017);
   }

   public int method4380() {
      return this.R.Z(-1950259661);
   }

   public int method4381() {
      return this.R.Z(-398878374);
   }

   public HR(AP var1, GSI var2, CX var3, KEI var4, int var5, int var6, int var7, int var8, int var9, boolean var10, int var11, int var12, int var13, int var14, int var15) {
      super(var1, var7, var8, var9, var5, var6, var11, var12);
      this.R = new GBI(var2, var3, var4, var13, var14, this.K, var6, this, var10, var15);
      this.charAt = 1532834983 * var4.K != 0 && !var10;
      this.I(1, -659392218);
   }

   boolean method4382() {
      return this.append;
   }

   public int method45() {
      return 1686561661 * this.R.S;
   }

   public boolean method41() {
      return this.R.C(1916662090);
   }

   boolean method4385(GSI var1, int var2, int var3) {
      UT var4 = this.R.I(var1, 131072, false, false, (byte)-72);
      return var4 == null ? false : var4.method4787(var2, var3, this.J(), false, 0);
   }

   public HP method4367(GSI var1) {
      return this.i;
   }

   public static void I(long[] var0, Object[] var1, byte var2) {
      try {
         UC.I(var0, var1, 0, var0.length - 1, 1394023611);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "wl.r(" + ')');
      }
   }

   public static String[] I(String var0, char var1, int var2) {
      try {
         int var3 = MO.I(var0, var1, -452041917);
         String[] var4 = new String[1 + var3];
         int var5 = 0;
         int var6 = 0;

         for(int var7 = 0; var7 < var3; ++var7) {
            int var8;
            for(var8 = var6; var0.charAt(var8) != var1; ++var8) {
               ;
            }

            var4[var5++] = var0.substring(var6, var8);
            var6 = 1 + var8;
         }

         var4[var3] = var0.substring(var6);
         return var4;
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "wl.h(" + ')');
      }
   }

   static final void Z(HSI var0, X var1, OU var2, byte var3) {
      try {
         var0.I(333321190);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "wl.kx(" + ')');
      }
   }
}
