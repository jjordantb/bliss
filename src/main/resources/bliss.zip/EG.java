import jagtheora.ogg.OggPacket;
import jagtheora.ogg.OggStreamState;
import jagtheora.vorbis.DSPState;
import jagtheora.vorbis.VorbisBlock;
import jagtheora.vorbis.VorbisComment;
import jagtheora.vorbis.VorbisInfo;

public class EG extends AG {
   VorbisInfo append = new VorbisInfo();
   VorbisComment blockIn = new VorbisComment();
   VorbisBlock channels;
   static int A;
   CA f;
   IG granuleTime;
   double headerIn;
   int pcmOut;
   static int E;
   DSPState rate;

   void method3074(OggPacket var1, int var2) {
      try {
         if (this.S * -1312498565 < 3) {
            int var7 = this.append.headerIn(this.blockIn, var1);
            if (var7 < 0) {
               throw new IllegalStateException("" + var7);
            }

            if (-1312498565 * this.S == 2) {
               if (this.append.channels > 2 || this.append.channels < 1) {
                  throw new RuntimeException("" + this.append.channels);
               }

               this.rate = new DSPState(this.append);
               this.channels = new VorbisBlock(this.rate);
               this.f = new CA(this.append.rate, 1164070869 * PA.F);
               this.granuleTime = new IG(this.append.channels);
            }
         } else {
            if (this.channels.synthesis(var1) == 0) {
               this.rate.blockIn(this.channels);
            }

            float[][] var3 = this.rate.pcmOut(this.append.channels);
            this.headerIn = this.rate.granuleTime();
            if (-1.0D == this.headerIn) {
               this.headerIn = (double)((float)(253299067 * this.pcmOut) / (float)this.append.rate);
            }

            this.rate.read(var3[0].length);
            this.pcmOut += var3[0].length * -87069261;
            TG var4 = this.granuleTime.I(var3[0].length, this.headerIn);
            NII.I(var3, var4.S, (byte)-17);

            for(int var5 = 0; var5 < this.append.channels; ++var5) {
               var4.S[var5] = this.f.I((short[])var4.S[var5], (byte)3);
            }

            this.granuleTime.I(var4, -1634784761);
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "aiy.f(" + ')');
      }
   }

   void method3079() {
      if (this.channels != null) {
         this.channels.f();
      }

      if (this.rate != null) {
         this.rate.f();
      }

      this.blockIn.f();
      this.append.f();
      if (this.granuleTime != null) {
         this.granuleTime.B(1484582250);
      }

   }

   EG(OggStreamState var1) {
      super(var1);
   }

   void method3075(int var1) {
      try {
         if (this.channels != null) {
            this.channels.f();
         }

         if (this.rate != null) {
            this.rate.f();
         }

         this.blockIn.f();
         this.append.f();
         if (this.granuleTime != null) {
            this.granuleTime.B(141709442);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aiy.b(" + ')');
      }
   }

   void method3072() {
      if (this.channels != null) {
         this.channels.f();
      }

      if (this.rate != null) {
         this.rate.f();
      }

      this.blockIn.f();
      this.append.f();
      if (this.granuleTime != null) {
         this.granuleTime.B(-1123680185);
      }

   }

   void method3076(OggPacket var1) {
      if (this.S * -1312498565 < 3) {
         int var5 = this.append.headerIn(this.blockIn, var1);
         if (var5 < 0) {
            throw new IllegalStateException("" + var5);
         }

         if (-1312498565 * this.S == 2) {
            if (this.append.channels > 2 || this.append.channels < 1) {
               throw new RuntimeException("" + this.append.channels);
            }

            this.rate = new DSPState(this.append);
            this.channels = new VorbisBlock(this.rate);
            this.f = new CA(this.append.rate, 1164070869 * PA.F);
            this.granuleTime = new IG(this.append.channels);
         }
      } else {
         if (this.channels.synthesis(var1) == 0) {
            this.rate.blockIn(this.channels);
         }

         float[][] var2 = this.rate.pcmOut(this.append.channels);
         this.headerIn = this.rate.granuleTime();
         if (-1.0D == this.headerIn) {
            this.headerIn = (double)((float)(253299067 * this.pcmOut) / (float)this.append.rate);
         }

         this.rate.read(var2[0].length);
         this.pcmOut += var2[0].length * -87069261;
         TG var3 = this.granuleTime.I(var2[0].length, this.headerIn);
         NII.I(var2, var3.S, (byte)-116);

         for(int var4 = 0; var4 < this.append.channels; ++var4) {
            var3.S[var4] = this.f.I((short[])var3.S[var4], (byte)12);
         }

         this.granuleTime.I(var3, -585602714);
      }

   }

   void method3077(OggPacket var1) {
      if (this.S * -1312498565 < 3) {
         int var5 = this.append.headerIn(this.blockIn, var1);
         if (var5 < 0) {
            throw new IllegalStateException("" + var5);
         }

         if (-1312498565 * this.S == 2) {
            if (this.append.channels > 2 || this.append.channels < 1) {
               throw new RuntimeException("" + this.append.channels);
            }

            this.rate = new DSPState(this.append);
            this.channels = new VorbisBlock(this.rate);
            this.f = new CA(this.append.rate, 1164070869 * PA.F);
            this.granuleTime = new IG(this.append.channels);
         }
      } else {
         if (this.channels.synthesis(var1) == 0) {
            this.rate.blockIn(this.channels);
         }

         float[][] var2 = this.rate.pcmOut(this.append.channels);
         this.headerIn = this.rate.granuleTime();
         if (-1.0D == this.headerIn) {
            this.headerIn = (double)((float)(253299067 * this.pcmOut) / (float)this.append.rate);
         }

         this.rate.read(var2[0].length);
         this.pcmOut += var2[0].length * -87069261;
         TG var3 = this.granuleTime.I(var2[0].length, this.headerIn);
         NII.I(var2, var3.S, (byte)-54);

         for(int var4 = 0; var4 < this.append.channels; ++var4) {
            var3.S[var4] = this.f.I(var3.S[var4], (byte)-8);
         }

         this.granuleTime.I(var3, -830115957);
      }

   }

   void method3078(OggPacket var1) {
      if (this.S * -1312498565 < 3) {
         int var5 = this.append.headerIn(this.blockIn, var1);
         if (var5 < 0) {
            throw new IllegalStateException("" + var5);
         }

         if (-1312498565 * this.S == 2) {
            if (this.append.channels > 2 || this.append.channels < 1) {
               throw new RuntimeException("" + this.append.channels);
            }

            this.rate = new DSPState(this.append);
            this.channels = new VorbisBlock(this.rate);
            this.f = new CA(this.append.rate, 1164070869 * PA.F);
            this.granuleTime = new IG(this.append.channels);
         }
      } else {
         if (this.channels.synthesis(var1) == 0) {
            this.rate.blockIn(this.channels);
         }

         float[][] var2 = this.rate.pcmOut(this.append.channels);
         this.headerIn = this.rate.granuleTime();
         if (-1.0D == this.headerIn) {
            this.headerIn = (double)((float)(253299067 * this.pcmOut) / (float)this.append.rate);
         }

         this.rate.read(var2[0].length);
         this.pcmOut += var2[0].length * -87069261;
         TG var3 = this.granuleTime.I(var2[0].length, this.headerIn);
         NII.I(var2, var3.S, (byte)-23);

         for(int var4 = 0; var4 < this.append.channels; ++var4) {
            var3.S[var4] = this.f.I(var3.S[var4], (byte)-76);
         }

         this.granuleTime.I(var3, -1886056518);
      }

   }

   double C(int var1) {
      try {
         double var2 = this.headerIn;
         if (this.granuleTime != null) {
            var2 = this.granuleTime.J(1578639792);
            if (var2 < 0.0D) {
               var2 = this.headerIn;
            }
         }

         return var2 - (double)(256.0F / (float)(PA.F * 1164070869));
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aiy.s(" + ')');
      }
   }

   public IG B(int var1) {
      try {
         return this.granuleTime;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aiy.n(" + ')');
      }
   }

   int D(int var1) {
      try {
         return this.granuleTime == null ? 0 : this.granuleTime.C(920577613);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aiy.z(" + ')');
      }
   }
}
