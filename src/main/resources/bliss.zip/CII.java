public class CII extends RY {
   boolean method520() {
      return true;
   }

   boolean method501() {
      return true;
   }

   void method505(boolean var1) {
      this.I.C(true);
   }

   CII(MJI var1) {
      super(var1);
   }

   void method510(boolean var1) {
   }

   void method503(int var1, int var2) {
   }

   void method515(int var1, int var2) {
   }

   void method506(boolean var1) {
      this.I.C(true);
   }

   void method507(boolean var1) {
      this.I.C(true);
   }

   void method508(boolean var1) {
   }

   void method509(boolean var1) {
   }

   void method518(boolean var1) {
   }

   void method511() {
      this.I.C(false);
   }

   void method500(SN var1, int var2) {
      this.I.I(var1);
      this.I.I(var2);
   }

   void method513(int var1, int var2) {
   }

   void method502(int var1, int var2) {
   }

   void method514(SN var1, int var2) {
      this.I.I(var1);
      this.I.I(var2);
   }

   void method516(int var1, int var2) {
   }

   void method517(int var1, int var2) {
   }

   void method504() {
      this.I.C(false);
   }

   void method519(SN var1, int var2) {
      this.I.I(var1);
      this.I.I(var2);
   }

   void method512() {
      this.I.C(false);
   }
}
