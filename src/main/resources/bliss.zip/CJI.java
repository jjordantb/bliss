public abstract class CJI {
   public static KJ I;

   abstract void method1036();

   abstract void method1037(int var1);

   abstract void method1038();

   abstract void method1039();

   static final void I(OU var0, int var1) {
      try {
         var0.J -= -1175642067;
         int var2 = var0.H[var0.J * 681479919];
         int var3 = var0.H[var0.J * 681479919 + 1];
         int var4 = var0.H[2 + 681479919 * var0.J];
         GN.I(5, var2 << 16 | var3, var4, "", 761274889);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "dy.aln(" + ')');
      }
   }

   static void I(int var0, int var1) {
      try {
         if (IT.J == null || IT.J.length < var0) {
            IT.J = new int[var0];
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "dy.z(" + ')');
      }
   }

   public static void I(String var0, int var1) {
      try {
         if (8 == -1233866115 * XEI.QZ) {
            PK var2 = GB.I(MEI.q, XEI.TI.Z, (byte)6);
            var2.J.Z(0, 16711935);
            int var3 = 385051775 * var2.J.A;
            var2.J.I(var0, 2135681130);
            var2.J.A += 814893177;
            var2.J.I(UQ.I, var3, 385051775 * var2.J.A, -1237713398);
            var2.J.F(385051775 * var2.J.A - var3, 1585504133);
            XEI.TI.I(var2, (byte)-126);
            KT.I = WW.D;
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "dy.p(" + ')');
      }
   }
}
