import jagdx.IDirect3DDevice;
import jagdx.IDirect3DTexture;
import java.nio.ByteBuffer;

public class GD extends SD implements CEI {
   int CreateTexture;
   int Download;
   boolean F;
   boolean J;

   public float method94(float var1) {
      return var1 / (float)this.Download;
   }

   public boolean Z() {
      return false;
   }

   GD(PJI var1, int var2, int var3, boolean var4, int[] var5, int var6, int var7) {
      super(var1, YCI.Z, SDI.C, var4 && var1.DZ, var2 * var3);
      if (!this.D.EZ) {
         this.CreateTexture = JV.I(var2, (byte)16);
         this.Download = JV.I(var3, (byte)16);
      } else {
         this.CreateTexture = var2;
         this.Download = var3;
      }

      if (var4) {
         this.Z = IDirect3DDevice.CreateTexture(this.D.FZ, this.CreateTexture, this.Download, 0, 1024, 21, 1);
      } else {
         this.Z = IDirect3DDevice.CreateTexture(this.D.FZ, this.CreateTexture, this.Download, 1, 0, 21, 1);
      }

      if (var7 == 0) {
         var7 = var2;
      }

      ByteBuffer var8 = this.D.F;
      var8.clear();
      var8.asIntBuffer().put(var5, var6, var7 * var3);
      IDirect3DTexture.Upload(this.Z, 0, 0, 0, var2, var3, var7 * this.B.I * 845115459, 0, this.D.J);
   }

   GD(PJI var1, YCI var2, int var3, int var4, boolean var5, byte[] var6, int var7, int var8) {
      super(var1, var2, SDI.C, var5 && var1.DZ, var3 * var4);
      if (!this.D.EZ) {
         this.CreateTexture = JV.I(var3, (byte)16);
         this.Download = JV.I(var4, (byte)16);
      } else {
         this.CreateTexture = var3;
         this.Download = var4;
      }

      if (var5) {
         this.Z = IDirect3DDevice.CreateTexture(this.D.FZ, this.CreateTexture, this.Download, 0, 1024, PJI.I(this.B, SDI.C), 1);
      } else {
         this.Z = IDirect3DDevice.CreateTexture(this.D.FZ, this.CreateTexture, this.Download, 1, 0, PJI.I(this.B, SDI.C), 1);
      }

      if (var8 == 0) {
         var8 = var3;
      }

      ByteBuffer var9 = this.D.F;
      var9.clear();
      YCI var10 = this.B;
      YCI var10000 = this.B;
      if (var10 == YCI.S) {
         var9.put(var6, var7, var4 * var3 / 2);
         IDirect3DTexture.Upload(this.Z, 0, 0, 0, var3, var4 / 4, var3 / 4 * 8, 0, this.D.J);
      } else {
         YCI var11 = this.B;
         var10000 = this.B;
         if (var11 == YCI.C) {
            var9.put(var6, var7, var4 * var3);
            IDirect3DTexture.Upload(this.Z, 0, 0, 0, var3, var4 / 4, var3 / 4 * 16, 0, this.D.J);
         } else {
            var9.put(var6, var7, var8 * var4);
            IDirect3DTexture.Upload(this.Z, 0, 0, 0, var3, var4, var8 * this.B.I * 845115459, 0, this.D.J);
         }
      }

   }

   GD(PJI var1, YCI var2, int var3, int var4, boolean var5, float[] var6, int var7, int var8) {
      super(var1, var2, SDI.C, var5 && var1.DZ, var3 * var4);
      if (!this.D.EZ) {
         this.CreateTexture = JV.I(var3, (byte)16);
         this.Download = JV.I(var4, (byte)16);
      } else {
         this.CreateTexture = var3;
         this.Download = var4;
      }

      if (var5) {
         this.Z = IDirect3DDevice.CreateTexture(this.D.FZ, this.CreateTexture, this.Download, 0, 1024, PJI.I(this.B, SDI.F), 1);
      } else {
         this.Z = IDirect3DDevice.CreateTexture(this.D.FZ, this.CreateTexture, this.Download, 1, 0, PJI.I(this.B, SDI.F), 1);
      }

      if (var8 == 0) {
         var8 = var3;
      }

      ByteBuffer var9 = this.D.F;
      var9.clear();
      var9.asFloatBuffer().put(var6, var7, var8 * var4 * this.B.I * 845115459);
      IDirect3DTexture.Upload(this.Z, 0, 0, 0, var3, var4, var8 * this.B.I * 845115459 * 4, 0, this.D.J);
   }

   public int method92() {
      return this.CreateTexture;
   }

   public void method126() {
      this.D.I(this);
   }

   public float method77(float var1) {
      return var1 / (float)this.CreateTexture;
   }

   public float method78(float var1) {
      return var1 / (float)this.Download;
   }

   public void method97(boolean var1, boolean var2) {
      this.F = var1;
      this.J = var2;
   }

   long I() {
      return this.Z;
   }

   public boolean method79() {
      return true;
   }

   public void method80(boolean var1, boolean var2) {
      this.F = var1;
      this.J = var2;
   }

   public void method101(int var1, int var2, int var3, int var4, int[] var5, int var6, int var7) {
      if (this.B == YCI.Z && this.C == SDI.C) {
         if (var7 == 0) {
            var7 = var3;
         }

         ByteBuffer var8 = this.D.F;
         var8.clear();
         var8.asIntBuffer().put(var5, var6, var7 * var4);
         IDirect3DTexture.Upload(this.Z, 0, var1, var2, var3, var4, var7 * this.B.I * 845115459, 0, this.D.J);
      } else {
         throw new RuntimeException();
      }
   }

   public void method82(int var1, int var2, int var3, int var4, byte[] var5, YCI var6, int var7, int var8) {
      if (this.B == var6 && this.C == SDI.C) {
         if (var8 == 0) {
            var8 = var3;
         }

         ByteBuffer var9 = this.D.F;
         var9.clear();
         var9.put(var5, var7, var8 * var4);
         IDirect3DTexture.Upload(this.Z, 0, var1, var2, var3, var4, var8 * this.B.I * 845115459, 0, this.D.J);
      } else {
         throw new RuntimeException();
      }
   }

   public void method83(int var1, int var2, int var3, int var4, int[] var5, int var6) {
      if (this.B == YCI.Z && this.C == SDI.C) {
         ByteBuffer var7 = this.D.F;
         var7.clear();
         IDirect3DTexture.Download(this.Z, 0, var1, var2, var3, var4, var3 * 4, 0, this.D.J);
         var7.asIntBuffer().get(var5, var6, var3 * var4);
      } else {
         throw new RuntimeException();
      }
   }

   public int method86() {
      return this.CreateTexture;
   }

   public void method107(int var1, int var2, int var3, int var4, int[] var5, int var6) {
      if (this.B == YCI.Z && this.C == SDI.C) {
         ByteBuffer var7 = this.D.F;
         var7.clear();
         IDirect3DTexture.Download(this.Z, 0, var1, var2, var3, var4, var3 * 4, 0, this.D.J);
         var7.asIntBuffer().get(var5, var6, var3 * var4);
      } else {
         throw new RuntimeException();
      }
   }

   public void b() {
      super.b();
   }

   public void d() {
      super.b();
   }

   public void u() {
      super.b();
   }

   long CreateTexture() {
      return this.Z;
   }

   public void method99(boolean var1, boolean var2) {
      this.F = var1;
      this.J = var2;
   }

   public void method127(EB var1) {
      super.method122(var1);
   }

   public int method84() {
      return this.Download;
   }

   public int method88() {
      return this.Download;
   }

   public float method89(float var1) {
      return var1 / (float)this.CreateTexture;
   }

   public float method90(float var1) {
      return var1 / (float)this.CreateTexture;
   }

   public float method91(float var1) {
      return var1 / (float)this.CreateTexture;
   }

   public float method105(float var1) {
      return var1 / (float)this.Download;
   }

   public float method109(float var1) {
      return var1 / (float)this.Download;
   }

   public void method93(int var1, int var2, int var3, int var4, int[] var5, int var6) {
      if (this.B == YCI.Z && this.C == SDI.C) {
         ByteBuffer var7 = this.D.F;
         var7.clear();
         IDirect3DTexture.Download(this.Z, 0, var1, var2, var3, var4, var3 * 4, 0, this.D.J);
         var7.asIntBuffer().get(var5, var6, var3 * var4);
      } else {
         throw new RuntimeException();
      }
   }

   public float method95(float var1) {
      return var1 / (float)this.Download;
   }

   public void method129(EB var1) {
      super.method122(var1);
   }

   public void method128() {
      this.D.I(this);
   }

   public void method98(boolean var1, boolean var2) {
      this.F = var1;
      this.J = var2;
   }

   public void method106(boolean var1, boolean var2) {
      this.F = var1;
      this.J = var2;
   }

   GD(PJI var1, YCI var2, SDI var3, int var4, int var5) {
      this(var1, var2, var3, var4, var5, 0, 1);
   }

   public int method76() {
      return this.Download;
   }

   public void method122(EB var1) {
      super.method122(var1);
   }

   public void method100(int var1, int var2, int var3, int var4, byte[] var5, YCI var6, int var7, int var8) {
      if (this.B == var6 && this.C == SDI.C) {
         if (var8 == 0) {
            var8 = var3;
         }

         ByteBuffer var9 = this.D.F;
         var9.clear();
         var9.put(var5, var7, var8 * var4);
         IDirect3DTexture.Upload(this.Z, 0, var1, var2, var3, var4, var8 * this.B.I * 845115459, 0, this.D.J);
      } else {
         throw new RuntimeException();
      }
   }

   public void method104(int var1, int var2, int var3, int var4, byte[] var5, YCI var6, int var7, int var8) {
      if (this.B == var6 && this.C == SDI.C) {
         if (var8 == 0) {
            var8 = var3;
         }

         ByteBuffer var9 = this.D.F;
         var9.clear();
         var9.put(var5, var7, var8 * var4);
         IDirect3DTexture.Upload(this.Z, 0, var1, var2, var3, var4, var8 * this.B.I * 845115459, 0, this.D.J);
      } else {
         throw new RuntimeException();
      }
   }

   public void method87(int var1, int var2, int var3, int var4, byte[] var5, YCI var6, int var7, int var8) {
      if (this.B == var6 && this.C == SDI.C) {
         if (var8 == 0) {
            var8 = var3;
         }

         ByteBuffer var9 = this.D.F;
         var9.clear();
         var9.put(var5, var7, var8 * var4);
         IDirect3DTexture.Upload(this.Z, 0, var1, var2, var3, var4, var8 * this.B.I * 845115459, 0, this.D.J);
      } else {
         throw new RuntimeException();
      }
   }

   GD(PJI var1, YCI var2, SDI var3, int var4, int var5, int var6, int var7) {
      super(var1, var2, var3, false, var4 * var5);
      if (!this.D.EZ) {
         this.CreateTexture = JV.I(var4, (byte)16);
         this.Download = JV.I(var5, (byte)16);
      } else {
         this.CreateTexture = var4;
         this.Download = var5;
      }

      this.Z = IDirect3DDevice.CreateTexture(this.D.FZ, var4, var5, 0, var6, PJI.I(this.B, this.C), var7);
   }

   public void method96(boolean var1, boolean var2) {
      this.F = var1;
      this.J = var2;
   }

   public boolean method108() {
      return false;
   }

   public boolean method111() {
      return false;
   }

   public void method125() {
      this.D.I(this);
   }

   public void x() {
      super.b();
   }

   public void method123() {
      this.D.I(this);
   }

   public void method102(int var1, int var2, int var3, int var4, int[] var5, int var6, int var7) {
      if (this.B == YCI.Z && this.C == SDI.C) {
         if (var7 == 0) {
            var7 = var3;
         }

         ByteBuffer var8 = this.D.F;
         var8.clear();
         var8.asIntBuffer().put(var5, var6, var7 * var4);
         IDirect3DTexture.Upload(this.Z, 0, var1, var2, var3, var4, var7 * this.B.I * 845115459, 0, this.D.J);
      } else {
         throw new RuntimeException();
      }
   }

   public void method124(EB var1) {
      super.method122(var1);
   }

   public void method81(int var1, int var2, int var3, int var4, int[] var5, int var6, int var7) {
      if (this.B == YCI.Z && this.C == SDI.C) {
         if (var7 == 0) {
            var7 = var3;
         }

         ByteBuffer var8 = this.D.F;
         var8.clear();
         var8.asIntBuffer().put(var5, var6, var7 * var4);
         IDirect3DTexture.Upload(this.Z, 0, var1, var2, var3, var4, var7 * this.B.I * 845115459, 0, this.D.J);
      } else {
         throw new RuntimeException();
      }
   }

   public boolean method110() {
      return true;
   }

   public boolean method85() {
      return true;
   }

   long Download() {
      return this.Z;
   }

   public int method75() {
      return this.Download;
   }
}
