public class HP {
   int I;
   int Z;
   int C;
   int B;
   int D;
   int F;
   int J;
   int S;
   int A;
   int E;

   HP(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10) {
      this.F = var1;
      this.I = var2;
      this.C = var3;
      this.B = var4 * var4;
      this.D = this.F + var5;
      this.A = this.F + var6;
      this.J = this.I + var7;
      this.Z = this.I + var8;
      this.S = this.C + var9;
      this.E = this.C + var10;
   }

   public boolean I(int var1, int var2, int var3) {
      if (var1 >= this.D && var1 <= this.A) {
         if (var2 >= this.J && var2 <= this.Z) {
            if (var3 >= this.S && var3 <= this.E) {
               int var4 = var1 - this.F;
               int var5 = var3 - this.C;
               return var4 * var4 + var5 * var5 < this.B;
            } else {
               return false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   void I(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10) {
      this.F = var1;
      this.I = var2;
      this.C = var3;
      this.B = var4 * var4;
      this.D = this.F + var5;
      this.A = this.F + var6;
      this.J = this.I + var7;
      this.Z = this.I + var8;
      this.S = this.C + var9;
      this.E = this.C + var10;
   }
}
