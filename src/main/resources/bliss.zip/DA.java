public class DA {
   LX Z = new LX(256);
   KJ append;
   KJ length;
   LX toString = new LX(256);
   static int I;

   NG Z(int var1, int var2, int[] var3, int var4) {
      try {
         int var5 = var2 ^ (var1 << 4 & '\uffff' | var1 >>> 12);
         var5 |= var1 << 16;
         long var6 = (long)var5;
         NG var8 = (NG)this.toString.I(var6);
         if (var8 != null) {
            return var8;
         } else if (var3 != null && var3[0] <= 0) {
            return null;
         } else {
            GA var9 = GA.I(this.length, var1, var2);
            if (var9 == null) {
               return null;
            } else {
               var8 = var9.I();
               this.toString.I(var8, var6);
               if (var3 != null) {
                  var3[0] -= var8.S.length;
               }

               return var8;
            }
         }
      } catch (RuntimeException var10) {
         throw DQ.I(var10, "lh.a(" + ')');
      }
   }

   NG append(int var1, int var2, int[] var3, int var4) {
      try {
         int var5 = var2 ^ (var1 << 4 & '\uffff' | var1 >>> 12);
         var5 |= var1 << 16;
         long var6 = (long)var5 ^ 4294967296L;
         NG var8 = (NG)this.toString.I(var6);
         if (var8 != null) {
            return var8;
         } else if (var3 != null && var3[0] <= 0) {
            return null;
         } else {
            SG var9 = (SG)this.Z.I(var6);
            if (var9 == null) {
               var9 = SG.I(this.append, var1, var2);
               if (var9 == null) {
                  return null;
               }

               this.Z.I(var9, var6);
            }

            var8 = var9.I(var3);
            if (var8 == null) {
               return null;
            } else {
               var9.I(-1460969981);
               this.toString.I(var8, var6);
               return var8;
            }
         }
      } catch (RuntimeException var10) {
         throw DQ.I(var10, "lh.f(" + ')');
      }
   }

   public NG I(int var1, int[] var2, int var3) {
      try {
         if (this.length.Z(1029061077) == 1) {
            return this.Z(0, var1, var2, 1909168122);
         } else if (this.length.F(var1, -1941901563) == 1) {
            return this.Z(var1, 0, var2, -1018556227);
         } else {
            throw new RuntimeException();
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "lh.b(" + ')');
      }
   }

   public NG I(int var1, int[] var2, byte var3) {
      try {
         if (this.append.Z(853704793) == 1) {
            return this.append(0, var1, var2, -745389241);
         } else if (this.append.F(var1, -1796273847) == 1) {
            return this.append(var1, 0, var2, -745389241);
         } else {
            throw new RuntimeException();
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "lh.p(" + ')');
      }
   }

   public DA(KJ var1, KJ var2) {
      this.length = var1;
      this.append = var2;
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)22);
         X var4 = IU.F[var2 >> 16];
         EM.I(var3, var4, var0, (byte)-127);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "lh.el(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         String var2 = (String)var0.S[(var0.A -= 969361751) * -203050393];
         PK var3 = GB.I(MEI.a, XEI.eI.Z, (byte)34);
         var3.J.F(var2.length() + 1);
         var3.J.I(var2, 2114518021);
         XEI.eI.I(var3, (byte)-1);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "lh.sb(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         if (var2 == -1) {
            int var3 = var2 >> 14 & 16383;
            int var4 = var2 & 16383;
            XP var5 = XEI.mI.I(681479919);
            var3 -= var5.I * -1760580017;
            if (var3 < 0) {
               var3 = 0;
            } else if (var3 >= XEI.mI.Z(-1866822819)) {
               var3 = XEI.mI.Z(-1973847066);
            }

            var4 -= 283514611 * var5.Z;
            if (var4 < 0) {
               var4 = 0;
            } else if (var4 >= XEI.mI.C(922370140)) {
               var4 = XEI.mI.C(271939870);
            }

            B.XZ = ((var3 << 9) + 256) * -178575833;
            AV.I = 1001372047 * ((var4 << 9) + 256);
         } else {
            B.XZ = 178575833;
            AV.I = -1001372047;
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "lh.agw(" + ')');
      }
   }

   static final void B(OU var0, int var1) {
      try {
         FW.J.I(FW.J.S, var0.H[(var0.J -= -391880689) * 681479919] == 1 ? 1 : 0, 1031457025);
         XEI.mI.P(2089019629);
         JN.I(656179282);
         XEI.w = false;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "lh.ahq(" + ')');
      }
   }

   public static YK I(int var0) {
      try {
         return HM.L;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "lh.ai(" + ')');
      }
   }

   public static void I(int var0, int var1) {
      try {
         VK var2 = IV.I(2, (long)var0);
         var2.B(-1442934147);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "lh.i(" + ')');
      }
   }
}
