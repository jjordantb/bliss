public class AL extends QK {
   ZJI[] G;
   int append;
   byte[][] toString;
   static KJ H;

   public boolean I(byte var1) {
      try {
         if (this.G != null) {
            return true;
         } else {
            if (this.toString == null) {
               KJ var2 = PO.C;
               synchronized(PO.C) {
                  if (!PO.C.I(1899473659 * this.append, 334179097)) {
                     boolean var19 = false;
                     return var19;
                  }

                  int[] var3 = PO.C.B(this.append * 1899473659, -2074944518);
                  this.toString = new byte[var3.length][];

                  for(int var4 = 0; var4 < var3.length; ++var4) {
                     this.toString[var4] = PO.C.I(1899473659 * this.append, var3[var4], (byte)-7);
                  }
               }
            }

            boolean var16 = true;

            int var6;
            for(int var17 = 0; var17 < this.toString.length; ++var17) {
               byte[] var20 = this.toString[var17];
               REI var5 = new REI(var20);
               var5.A = 116413311;
               var6 = var5.C();
               KJ var7 = H;
               synchronized(H) {
                  var16 &= H.D(var6, -457216440);
               }
            }

            if (!var16) {
               return false;
            } else {
               FY var18 = new FY();
               KJ var22 = PO.C;
               int[] var21;
               synchronized(PO.C) {
                  var6 = PO.C.F(this.append * 1899473659, -222662329);
                  this.G = new ZJI[var6];
                  var21 = PO.C.B(this.append * 1899473659, -2046558264);
               }

               for(int var23 = 0; var23 < var21.length; ++var23) {
                  byte[] var24 = this.toString[var23];
                  REI var25 = new REI(var24);
                  var25.A = 116413311;
                  int var8 = var25.C();
                  NE var9 = null;

                  for(NE var10 = (NE)var18.Z(2084946117); var10 != null; var10 = (NE)var18.Z((byte)-23)) {
                     if (var8 == var10.M * 1029066723) {
                        var9 = var10;
                        break;
                     }
                  }

                  if (var9 == null) {
                     KJ var26 = H;
                     synchronized(H) {
                        var9 = new NE(var8, H.I(var8, (byte)34));
                     }

                     var18.Z((AE)var9, (int)805140432);
                  }

                  this.G[var21[var23]] = new ZJI(var24, var9);
               }

               this.toString = null;
               return true;
            }
         }
      } catch (RuntimeException var15) {
         throw DQ.I(var15, "aih.f(" + ')');
      }
   }

   public boolean I(int var1, byte var2) {
      try {
         return this.G[var1].N;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aih.p(" + ')');
      }
   }

   public boolean Z(int var1, byte var2) {
      try {
         return this.G[var1].O;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aih.i(" + ')');
      }
   }

   public AL(int var1) {
      this.append = -2073571277 * var1;
   }

   public boolean Z(int var1, int var2) {
      try {
         return this.G[var1].M;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aih.b(" + ')');
      }
   }
}
