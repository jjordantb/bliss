import java.util.LinkedList;
import java.util.Queue;

public class AT extends JT {
   Queue J = new LinkedList();

   void method4618(byte var1) {
      try {
         RM var2 = (RM)this.J.poll();
         if (var2 != null) {
            PK var3 = GB.I(MEI.L, XEI.eI.Z, (byte)24);
            var3.J.B(var2.method3547((byte)-44) | var2.method3560(-1824201705) << 16, 126259689);
            var3.J.N(this.I(var2, 65535, (byte)33));
            var3.J.E(var2.Z((byte)113) << 1 | var2.I((byte)-17) & 1, 2075950579);
            XEI.eI.I(var3, (byte)-50);
            var2.method3550(29456166);
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "adt.d(" + ')');
      }
   }

   void I(RM var1, byte var2) {
      try {
         this.J.add(var1);
         if (this.J.size() > 10) {
            this.J.poll();
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "adt.az(" + ')');
      }
   }

   PK method4633(byte var1) {
      try {
         return GB.I(MEI.MI, XEI.eI.Z, (byte)31);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "adt.x(" + ')');
      }
   }

   boolean method4619(int var1) {
      try {
         return !this.J.isEmpty() || this.I * 8383148474145196457L < CI.I((byte)1) - 2000L;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "adt.u(" + ')');
      }
   }

   void I(REI var1, RM var2, int var3) {
      try {
         var1.F(var2.I((byte)-71));
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "adt.as(" + ')');
      }
   }

   void method4622() {
      RM var1 = (RM)this.J.poll();
      if (var1 != null) {
         PK var2 = GB.I(MEI.L, XEI.eI.Z, (byte)10);
         var2.J.B(var1.method3547((byte)-64) | var1.method3560(-1366988076) << 16, -1149175207);
         var2.J.N(this.I(var1, 65535, (byte)100));
         var2.J.E(var1.Z((byte)32) << 1 | var1.I((byte)-124) & 1, 1797403189);
         XEI.eI.I(var2, (byte)-27);
         var1.method3550(1518067003);
      }

   }

   PK method4625() {
      return GB.I(MEI.MI, XEI.eI.Z, (byte)45);
   }

   int method4628() {
      return 1;
   }

   void method4621() {
      RM var1 = (RM)this.J.poll();
      if (var1 != null) {
         PK var2 = GB.I(MEI.L, XEI.eI.Z, (byte)51);
         var2.J.B(var1.method3547((byte)-14) | var1.method3560(-1950900559) << 16, -582997683);
         var2.J.N(this.I(var1, 65535, (byte)125));
         var2.J.E(var1.Z((byte)37) << 1 | var1.I((byte)-48) & 1, 1887595218);
         XEI.eI.I(var2, (byte)-104);
         var1.method3550(1749258704);
      }

   }

   void method4617(REI var1, PM var2, byte var3) {
      try {
         this.I(var1, (RM)var2, -1392580670);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "adt.k(" + ')');
      }
   }

   int method4616(int var1) {
      return 1;
   }

   boolean method4623() {
      return !this.J.isEmpty() || this.I * 8383148474145196457L < CI.I((byte)1) - 2000L;
   }

   boolean method4634() {
      return !this.J.isEmpty() || this.I * 8383148474145196457L < CI.I((byte)1) - 2000L;
   }

   boolean method4624() {
      return !this.J.isEmpty() || this.I * 8383148474145196457L < CI.I((byte)1) - 2000L;
   }

   void method4632(REI var1, PM var2) {
      this.I(var1, (RM)var2, -1850528986);
   }

   PK method4631() {
      return GB.I(MEI.MI, XEI.eI.Z, (byte)58);
   }

   int method4635() {
      return 1;
   }

   void method4613() {
      RM var1 = (RM)this.J.poll();
      if (var1 != null) {
         PK var2 = GB.I(MEI.L, XEI.eI.Z, (byte)30);
         var2.J.B(var1.method3547((byte)14) | var1.method3560(-1929012233) << 16, -836695878);
         var2.J.N(this.I(var1, 65535, (byte)100));
         var2.J.E(var1.Z((byte)83) << 1 | var1.I((byte)-60) & 1, 1757564259);
         XEI.eI.I(var2, (byte)-126);
         var1.method3550(-718347820);
      }

   }

   int method4629() {
      return 1;
   }

   void method4627(REI var1, PM var2) {
      this.I(var1, (RM)var2, -1691760036);
   }

   void method4630(REI var1, PM var2) {
      this.I(var1, (RM)var2, -710116883);
   }

   void method4612(REI var1, PM var2) {
      this.I(var1, (RM)var2, -2014256695);
   }

   static final void C(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         if (EFI.F != null && var2 < -1801543887 * UII.I && EFI.F[var2].Z.equalsIgnoreCase(UA.F.kI)) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 1;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "adt.wa(" + ')');
      }
   }
}
