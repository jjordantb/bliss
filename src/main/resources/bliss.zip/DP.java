public class DP {
   public static int Z = 1;
   short[] I;
   public static int append = 4;
   public static int charAt = 8;
   public static int length = 16;
   public static int toString = 2;
   byte C;
   short B;
   short D;
   byte F;
   short J;
   int[] S;
   int[] A;
   int[] E;
   short G;
   short[] H;
   short[] K;

   DP(AP var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, int var11, int var12, int var13, int var14, int var15) {
      this.F = (byte)var2;
      this.C = (byte)var3;
      this.S = new int[4];
      this.A = new int[4];
      this.E = new int[4];
      this.S[0] = var4;
      this.S[1] = var5;
      this.S[2] = var6;
      this.S[3] = var7;
      this.A[0] = var8;
      this.A[1] = var9;
      this.A[2] = var10;
      this.A[3] = var11;
      this.E[0] = var12;
      this.E[1] = var13;
      this.E[2] = var14;
      this.E[3] = var15;
      this.G = (short)(var4 >> -1688804109 * var1.I);
      this.D = (short)(var6 >> -1688804109 * var1.I);
      this.B = (short)(var12 >> -1688804109 * var1.I);
      this.J = (short)(var14 >> var1.I * -1688804109);
      this.I = new short[4];
      this.H = new short[4];
      this.K = new short[4];
   }

   static final void I(OU var0, byte var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         MX.I(var3, var4, var0, 1592585834);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "nr.kz(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = XEI.i * -442628795;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "nr.vd(" + ')');
      }
   }

   static final void C(OU var0, byte var1) {
      try {
         var0.A -= 1938723502;
         String var2 = (String)var0.S[var0.A * -203050393];
         String var3 = (String)var0.S[-203050393 * var0.A + 1];
         LBI.I(var2, var3, 2101690439);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "nr.agx(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.b.C(-1938875884) ? 1 : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "nr.aot(" + ')');
      }
   }

   public static String I(String var0, int var1) {
      try {
         StringBuilder var2 = new StringBuilder();
         int var3 = var0.length();

         for(int var4 = 0; var4 < var3; ++var4) {
            char var5 = var0.charAt(var4);
            if ('%' == var5 && var3 > var4 + 2) {
               var5 = var0.charAt(var4 + 1);
               boolean var6 = false;
               int var7;
               if (var5 >= '0' && var5 <= '9') {
                  var7 = var5 - 48;
               } else if (var5 >= 'a' && var5 <= 'f') {
                  var7 = 10 + var5 - 97;
               } else {
                  if (var5 < 'A' || var5 > 'F') {
                     var2.append('%');
                     continue;
                  }

                  var7 = var5 + 10 - 65;
               }

               var7 *= 16;
               char var8 = var0.charAt(var4 + 2);
               if (var8 >= '0' && var8 <= '9') {
                  var7 += var8 - 48;
               } else if (var8 >= 'a' && var8 <= 'f') {
                  var7 += var8 + 10 - 97;
               } else {
                  if (var8 < 'A' || var8 > 'F') {
                     var2.append('%');
                     continue;
                  }

                  var7 += var8 + 10 - 65;
               }

               if (var7 != 0 && EW.I((byte)var7, (short)18002)) {
                  var2.append(IZI.I((byte)var7, 2122534616));
               }

               var4 += 2;
            } else if (var5 == '+') {
               var2.append(' ');
            } else {
               var2.append(var5);
            }
         }

         return var2.toString();
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "nr.a(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         if (-1309843523 * var2.Z.a == -1) {
            if (var0.c) {
               throw new RuntimeException("");
            } else {
               throw new RuntimeException("");
            }
         } else {
            HSI var3 = var2.I(-2049654672);
            var3.SC[-1309843523 * var2.Z.a] = null;
            VEI.I(var3, 575626440);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "nr.bt(" + ')');
      }
   }
}
