public abstract class IBI implements GAI {
   final void cos(float var1, float var2, float var3, float var4, float var5, float var6, QJI var7, int var8, int var9) {
      this.method644(var1, var2, var3, var4, var5, var6, 1, var7, var8, var9);
   }

   public abstract void method621(int var1, int var2, int var3, int var4);

   public abstract void method622(int[] var1);

   public abstract int method623();

   public abstract void method624(int var1, int var2, int var3, int var4, int var5, int var6);

   public abstract int method625();

   public abstract int method626();

   public abstract TAI method627();

   public abstract void method628(int var1, int var2, int var3);

   abstract void method629(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10);

   public abstract int method630();

   public abstract void method631(int var1, int var2, int var3, int var4, int var5);

   public abstract void method632(int var1, int var2, int var3);

   public final void I(int var1, int var2, int var3, int var4) {
      this.method635(var1, var2, var3, var4, 1, 0, 1, 1);
   }

   public final void I(int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      this.method635(var1, var2, var3, var4, var5, var6, var7, 1);
   }

   abstract void method635(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8);

   public final void Z(int var1, int var2, int var3, int var4) {
      this.method662(var1, var2, var3, var4, 1, 0, 1);
   }

   public abstract int method271();

   final void method271(float var1, float var2, float var3, float var4, int var5, int var6, int var7, int var8, int var9) {
      if (var5 != 0) {
         double var10 = (double)(var6 & '\uffff') * 9.587379924285257E-5D;
         float var12 = (float)Math.sin(var10) * (float)var5;
         float var13 = (float)Math.cos(var10) * (float)var5;
         float var14 = (-var3 * var13 + -var4 * var12) / 4096.0F + var1;
         float var15 = (--var3 * var12 + -var4 * var13) / 4096.0F + var2;
         float var16 = (((float)this.method271() - var3) * var13 + -var4 * var12) / 4096.0F + var1;
         float var17 = (-((float)this.method271() - var3) * var12 + -var4 * var13) / 4096.0F + var2;
         float var18 = (-var3 * var13 + ((float)this.method626() - var4) * var12) / 4096.0F + var1;
         float var19 = (--var3 * var12 + ((float)this.method626() - var4) * var13) / 4096.0F + var2;
         this.I(var14, var15, var16, var17, var18, var19, var7, var8, var9);
      }

   }

   public final void I(float var1, float var2, int var3, int var4, int var5, int var6, int var7) {
      this.method271(var1, var2, (float)this.method271() / 2.0F, (float)this.method626() / 2.0F, var3, var4, var5, var6, var7);
   }

   public final void I(float var1, float var2, int var3, int var4, QJI var5, int var6, int var7) {
      this.I(var1, var2, (float)this.method271() / 2.0F, (float)this.method626() / 2.0F, var3, var4, var5, var6, var7);
   }

   public abstract void method640(int[] var1);

   public final void I(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9) {
      this.method642(var1, var2, var3, var4, var5, var6, var7, var8, var9, 1);
   }

   abstract void method642(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10);

   public abstract void method643(int var1, int var2, int var3, int var4, int var5);

   abstract void method644(float var1, float var2, float var3, float var4, float var5, float var6, int var7, QJI var8, int var9, int var10);

   public final void I(int var1, int var2) {
      this.method631(var1, var2, 1, 0, 1);
   }

   public abstract TAI method646();

   public abstract TAI method647();

   public abstract void method648(int var1, int var2, int var3, int var4, int var5);

   public abstract void method649(int var1, int var2, int var3, int var4, int var5);

   public abstract void method650(int var1, int var2, QJI var3, int var4, int var5);

   abstract void method651(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8);

   abstract void method652(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8);

   public abstract int method653();

   public abstract void method654(int var1, int var2, QJI var3, int var4, int var5);

   public abstract void method655(int var1, int var2, int var3, int var4);

   public abstract void method656(int[] var1);

   abstract void method657(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10);

   public abstract int method658();

   public abstract int method272();

   public final void I(float var1, float var2, float var3, float var4, int var5, int var6, QJI var7, int var8, int var9) {
      if (var5 != 0) {
         double var10 = (double)(var6 & '\uffff') * 9.587379924285257E-5D;
         float var12 = (float)Math.sin(var10) * (float)var5;
         float var13 = (float)Math.cos(var10) * (float)var5;
         float var14 = (-var3 * var13 + -var4 * var12) / 4096.0F + var1;
         float var15 = (--var3 * var12 + -var4 * var13) / 4096.0F + var2;
         float var16 = (((float)this.method271() - var3) * var13 + -var4 * var12) / 4096.0F + var1;
         float var17 = (-((float)this.method271() - var3) * var12 + -var4 * var13) / 4096.0F + var2;
         float var18 = (-var3 * var13 + ((float)this.method626() - var4) * var12) / 4096.0F + var1;
         float var19 = (--var3 * var12 + ((float)this.method626() - var4) * var13) / 4096.0F + var2;
         this.cos(var14, var15, var16, var17, var18, var19, var7, var8, var9);
      }

   }

   public abstract void method660(int var1, int var2, int var3, int var4, int var5, int var6, int var7);

   public abstract void method661(int var1, int var2, int var3, int var4, int var5, int var6, int var7);

   public abstract void method662(int var1, int var2, int var3, int var4, int var5, int var6, int var7);

   abstract void method663(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10);

   abstract void method664(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10);

   public abstract void method665(int var1, int var2, int var3, int var4, int var5, int var6);

   abstract void method666(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10);

   public abstract int method667();

   public abstract int method668();

   public abstract int method669();

   abstract void method670(float var1, float var2, float var3, float var4, float var5, float var6, int var7, QJI var8, int var9, int var10);

   abstract void method671(float var1, float var2, float var3, float var4, float var5, float var6, int var7, QJI var8, int var9, int var10);

   abstract void method672(float var1, float var2, float var3, float var4, float var5, float var6, int var7, QJI var8, int var9, int var10);

   public final void I(float var1, float var2, int var3, int var4) {
      this.method271(var1, var2, (float)this.method271() / 2.0F, (float)this.method626() / 2.0F, var3, var4, 1, 0, 1);
   }

   public abstract void method674(int var1, int var2, int var3, int var4, int var5);

   public abstract void method675(int var1, int var2, int var3, int var4, int var5, int var6);

   abstract void method676(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10);

   public abstract void method677(int[] var1);
}
