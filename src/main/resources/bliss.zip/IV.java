public class IV {
   int I;
   int Z;
   boolean C;
   int B;
   boolean D;
   static int F;

   static final void I(OU var0, byte var1) {
      try {
         IC.Z(-283526771);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "r.agk(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, byte var3) {
      try {
         var0.x = var2.H[(var2.J -= -391880689) * 681479919] * -695431873;
         VEI.I(var0, 230725327);
         if (var0.a * -1309843523 == -1 && !var1.I) {
            XM.I(-440872681 * var0.V, (byte)-11);
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "r.dg(" + ')');
      }
   }

   static final void I(OU var0, short var1) {
      try {
         if (L.D == null) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = -1;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 1790024195 * L.D.B;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "r.abm(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         LFI.I(var2, -1700743284);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "r.aew(" + ')');
      }
   }

   static final void Z(HSI var0, X var1, OU var2, byte var3) {
      try {
         String var4 = (String)var2.S[(var2.A -= 969361751) * -203050393];
         if (IN.I(var4, var2, -1037591394) != null) {
            var4 = var4.substring(0, var4.length() - 1);
         }

         var0.NZ = OI.I(var4, var2, -2046058202);
         var0.JZ = true;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "r.oj(" + ')');
      }
   }

   static VK I(int var0, long var1) {
      try {
         VK var3 = (VK)VK.V.I((long)var0 << 56 | var1);
         if (var3 == null) {
            var3 = new VK(var0, var1);
            VK.V.I(var3, 7051297995265073167L * var3.Z);
         }

         return var3;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "r.a(" + ')');
      }
   }
}
