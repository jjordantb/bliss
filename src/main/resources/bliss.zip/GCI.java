public class GCI extends ECI {
   LJI method136;
   Y toString;
   JJ C;
   int B = 0;
   int D = 0;

   public void method563(int var1, TAI var2) {
      try {
         JJ var3 = (JJ)var2;
         if (this.toString == null || var3 == null || var3.I * 215983317 == this.toString.I * 1026825677 && 1671547161 * this.toString.Z == 467687639 * var3.Z) {
            this.C = var3;
            if (var3 != null) {
               this.D = 1103799935 * var3.I;
               this.B = var3.Z * 1322627015;
            } else if (this.toString == null) {
               this.D = 0;
               this.B = 0;
            }

            if (this == this.method136.I((short)7140)) {
               this.method136();
            }

         } else {
            throw new RuntimeException();
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aeu.z(" + ')');
      }
   }

   public int method545() {
      try {
         return this.D * 494047915;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "aeu.a(" + ')');
      }
   }

   public int method547() {
      return this.D * 494047915;
   }

   public int method549() {
      return this.D * 494047915;
   }

   GCI(LJI var1) {
      this.method136 = var1;
   }

   public boolean method560() {
      return true;
   }

   public void method558(XAI var1) {
      try {
         Y var2 = (Y)var1;
         if (this.C == null || var2 == null || var2.I * 1026825677 == this.C.I * 215983317 && this.C.Z * 467687639 == 1671547161 * var2.Z) {
            this.toString = var2;
            if (var2 != null) {
               this.D = var2.I * 1931039079;
               this.B = var2.Z * 1986423081;
            } else if (this.C == null) {
               this.D = 0;
               this.B = 0;
            }

            if (this == this.method136.I((short)-7778)) {
               this.method136();
            }

         } else {
            throw new RuntimeException();
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aeu.n(" + ')');
      }
   }

   public int method552() {
      try {
         return -1236783503 * this.B;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "aeu.f(" + ')');
      }
   }

   public void method135() {
   }

   public int method544() {
      return -1236783503 * this.B;
   }

   public void method561(int var1, TAI var2) {
      JJ var3 = (JJ)var2;
      if (this.toString != null && var3 != null && (var3.I * 215983317 != this.toString.I * 1026825677 || 1671547161 * this.toString.Z != 467687639 * var3.Z)) {
         throw new RuntimeException();
      } else {
         this.C = var3;
         if (var3 != null) {
            this.D = 1103799935 * var3.I;
            this.B = var3.Z * 1322627015;
         } else if (this.toString == null) {
            this.D = 0;
            this.B = 0;
         }

         if (this == this.method136.I((short)22848)) {
            this.method136();
         }

      }
   }

   public void method562(int var1, TAI var2) {
      JJ var3 = (JJ)var2;
      if (this.toString != null && var3 != null && (var3.I * 215983317 != this.toString.I * 1026825677 || 1671547161 * this.toString.Z != 467687639 * var3.Z)) {
         throw new RuntimeException();
      } else {
         this.C = var3;
         if (var3 != null) {
            this.D = 1103799935 * var3.I;
            this.B = var3.Z * 1322627015;
         } else if (this.toString == null) {
            this.D = 0;
            this.B = 0;
         }

         if (this == this.method136.I((short)5099)) {
            this.method136();
         }

      }
   }

   public void method564(XAI var1) {
      Y var2 = (Y)var1;
      if (this.C != null && var2 != null && (var2.I * 1026825677 != this.C.I * 215983317 || this.C.Z * 467687639 != 1671547161 * var2.Z)) {
         throw new RuntimeException();
      } else {
         this.toString = var2;
         if (var2 != null) {
            this.D = var2.I * 1931039079;
            this.B = var2.Z * 1986423081;
         } else if (this.C == null) {
            this.D = 0;
            this.B = 0;
         }

         if (this == this.method136.I((short)-335)) {
            this.method136();
         }

      }
   }

   public boolean method557() {
      return true;
   }

   public boolean method559() {
      return true;
   }

   public boolean method565() {
      return true;
   }

   boolean method134() {
      this.method136.I(494047915 * this.D, -1236783503 * this.B, this.C == null ? null : this.C.C, this.toString == null ? null : this.toString.C);
      return true;
   }

   boolean method136() {
      try {
         this.method136.I(494047915 * this.D, -1236783503 * this.B, this.C == null ? null : this.C.C, this.toString == null ? null : this.toString.C);
         return true;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "aeu.p(" + ')');
      }
   }

   public void method137() {
   }

   public void method138() {
   }

   boolean method546() {
      return true;
   }

   public int method550() {
      return this.D * 494047915;
   }

   public int method551() {
      return this.D * 494047915;
   }

   boolean method548() {
      return true;
   }

   static final void I(HSI var0, X var1, OU var2, byte var3) {
      try {
         var0.XI = var2.H[(var2.J -= -391880689) * 681479919] == 1;
         VEI.I(var0, -1121165811);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aeu.dz(" + ')');
      }
   }
}
