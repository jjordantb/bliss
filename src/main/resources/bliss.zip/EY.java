import java.util.Iterator;

public class EY implements Iterable {
   public QK I = new QK();
   QK Z;
   static int C;

   public EY() {
      this.I.S = this.I;
      this.I.J = this.I;
   }

   public void I(QK var1, byte var2) {
      try {
         if (var1.J != null) {
            var1.C(1066671336);
         }

         var1.J = this.I.J;
         var1.S = this.I;
         var1.J.S = var1;
         var1.S.J = var1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "sz.f(" + ')');
      }
   }

   public QK I(int var1) {
      try {
         QK var2 = this.I.S;
         if (this.I == var2) {
            return null;
         } else {
            var2.C(-785195500);
            return var2;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sz.i(" + ')');
      }
   }

   public QK Z(int var1) {
      try {
         return this.Z((QK)null, -232966576);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sz.k(" + ')');
      }
   }

   public QK C(int var1) {
      try {
         QK var2 = this.Z;
         if (this.I == var2) {
            this.Z = null;
            return null;
         } else {
            this.Z = var2.S;
            return var2;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sz.u(" + ')');
      }
   }

   public int I(short var1) {
      try {
         int var2 = 0;

         for(QK var3 = this.I.S; this.I != var3; var3 = var3.S) {
            ++var2;
         }

         return var2;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "sz.x(" + ')');
      }
   }

   public Iterator iterator() {
      try {
         return new TX(this);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "sz.iterator(" + ')');
      }
   }

   QK Z(QK var1, int var2) {
      try {
         QK var3;
         if (var1 == null) {
            var3 = this.I.S;
         } else {
            var3 = var1;
         }

         if (this.I == var3) {
            this.Z = null;
            return null;
         } else {
            this.Z = var3.S;
            return var3;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "sz.d(" + ')');
      }
   }

   public void B(int var1) {
      try {
         while(this.I.S != this.I) {
            this.I.S.C(834138083);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sz.a(" + ')');
      }
   }

   static void I(SM var0, int var1, int var2, int var3, int var4, int var5) {
      try {
         if (-1 != var0.z * 391847895 || var0.P != null) {
            int var6 = 0;
            int var7 = var0.s * 43235291 * FW.J.n.I(-2144866042) >> 8;
            if (var2 > -1012062621 * var0.L) {
               var6 += var2 - -1012062621 * var0.L;
            } else if (var2 < -1808325887 * var0.H) {
               var6 += -1808325887 * var0.H - var2;
            }

            if (var3 > -720500331 * var0.M) {
               var6 += var3 - -720500331 * var0.M;
            } else if (var3 < var0.E * 757346071) {
               var6 += 757346071 * var0.E - var3;
            }

            if (826975881 * var0.O != 0 && var6 - 256 <= 826975881 * var0.O && FW.J.n.I(-2144778383) != 0 && -1926928785 * var0.G == var1) {
               var6 -= 256;
               if (var6 < 0) {
                  var6 = 0;
               }

               int var8 = 826975881 * var0.O - -2024907801 * var0.N;
               if (var8 < 0) {
                  var8 = var0.O * 826975881;
               }

               int var9 = var7;
               int var10 = var6 - -2024907801 * var0.N;
               if (var10 > 0 && var8 > 0) {
                  var9 = (var8 - var10) * var7 / var8;
               }

               UA.F.S();
               int var11 = 8192;
               int var12 = (var0.H * -1808325887 + var0.L * -1012062621) / 2 - var2;
               int var13 = (-720500331 * var0.M + 757346071 * var0.E) / 2 - var3;
               if (var12 != 0 || var13 != 0) {
                  int var14 = -(-1847894591 * CZ.I) - (int)(Math.atan2((double)var12, (double)var13) * 2607.5945876176133D) - 4096 & 16383;
                  if (var14 > 8192) {
                     var14 = 16384 - var14;
                  }

                  int var15;
                  if (var6 <= 0) {
                     var15 = 8192;
                  } else if (var6 >= 4096) {
                     var15 = 16384;
                  } else {
                     var15 = var6 * 8192 / 4096 + 8192;
                  }

                  var11 = var14 * var15 / 8192 + (16384 - var15 >> 1);
               }

               YE var16;
               YE var18;
               GA var19;
               NG var20;
               if (var0.f == null) {
                  if (391847895 * var0.z >= 0) {
                     var12 = -455518897 * var0.g == 256 && var0.Y * 1495381837 == 256 ? 256 : BU.Z(1495381837 * var0.Y, var0.g * -455518897, -1122963701);
                     if (var0.c) {
                        if (var0.b == null) {
                           var0.b = SG.I(HX.a, var0.z * 391847895);
                        }

                        if (var0.b != null) {
                           if (var0.d == null) {
                              var0.d = var0.b.I(new int[]{22050});
                           }

                           if (var0.d != null) {
                              var18 = YE.I(var0.d, var12, var9 << 6, var11);
                              var18.B(-1);
                              RA.S.I(var18);
                              var0.f = var18;
                           }
                        }
                     } else {
                        var19 = GA.I(CCI.I, var0.z * 391847895, 0);
                        if (var19 != null) {
                           var20 = var19.I().I(NA.F);
                           var16 = YE.I(var20, var12, var9 << 6, var11);
                           var16.B(-1);
                           RA.S.I(var16);
                           var0.f = var16;
                        }
                     }
                  }
               } else {
                  var0.f.D(var9);
                  var0.f.C(var11);
               }

               if (var0.K == null) {
                  if (var0.P != null && (var0.k -= 950219665 * var4) * -1221989007 <= 0) {
                     var12 = var0.g * -455518897 == 256 && 256 == var0.Y * 1495381837 ? 256 : (int)(Math.random() * (double)(-455518897 * var0.g - var0.Y * 1495381837)) + var0.Y * 1495381837;
                     if (var0.e) {
                        if (var0.J == null) {
                           var13 = (int)(Math.random() * (double)var0.P.length);
                           var0.J = SG.I(HX.a, var0.P[var13]);
                        }

                        if (var0.J != null) {
                           if (var0.h == null) {
                              var0.h = var0.J.I(new int[]{22050});
                           }

                           if (var0.h != null) {
                              var18 = YE.I(var0.h, var12, var9 << 6, var11);
                              var18.B(0);
                              RA.S.I(var18);
                              var0.K = var18;
                              var0.k = (var0.a * -15898815 + (int)(Math.random() * (double)(-1398300237 * var0.A - -15898815 * var0.a))) * 950219665;
                           }
                        }
                     } else {
                        var13 = (int)(Math.random() * (double)var0.P.length);
                        var19 = GA.I(CCI.I, var0.P[var13], 0);
                        if (var19 != null) {
                           var20 = var19.I().I(NA.F);
                           var16 = YE.I(var20, var12, var9 << 6, var11);
                           var16.B(0);
                           RA.S.I(var16);
                           var0.K = var16;
                           var0.k = (-15898815 * var0.a + (int)(Math.random() * (double)(var0.A * -1398300237 - -15898815 * var0.a))) * 950219665;
                        }
                     }
                  }
               } else {
                  var0.K.D(var9);
                  var0.K.C(var11);
                  if (!var0.K.Z(-629325116)) {
                     var0.K = null;
                     var0.J = null;
                     var0.h = null;
                  }
               }
            } else {
               if (var0.f != null) {
                  RA.S.Z(var0.f);
                  var0.f = null;
                  var0.d = null;
                  var0.b = null;
               }

               if (var0.K != null) {
                  RA.S.Z(var0.K);
                  var0.K = null;
                  var0.J = null;
                  var0.h = null;
               }
            }
         }

      } catch (RuntimeException var17) {
         throw DQ.I(var17, "sz.n(" + ')');
      }
   }
}
