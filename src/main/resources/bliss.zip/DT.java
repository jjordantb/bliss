public class DT extends YR {
   static boolean J;

   DT() throws Throwable {
      throw new Error();
   }

   static void C(int var0) {
      try {
         GDI.S = -445162670 + -123784141 * YDI.D.B + YDI.D.I * -1877198679;
         GDI.H = 524676266 + YV.F.B * 294342359 + 1292125525 * YV.F.I;
         GDI.A = new String[500];

         for(int var1 = 0; var1 < GDI.A.length; ++var1) {
            GDI.A[var1] = "";
         }

         CS.I(VEI.SC.I(WO.U, -875414210), 1099175264);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "adx.b(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = -560594807 * YT.C;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "adx.amp(" + ')');
      }
   }

   static final void I(OU var0, short var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         HM.I(var3, var4, var0, (byte)36);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "adx.dk(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, int var3) {
      try {
         var0.KI = -295449533;
         var0.f = 1825442367;
         if (-1309843523 * var0.a == -1 && !var1.I) {
            LV.Z(-440872681 * var0.V, 1454915163);
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "adx.hq(" + ')');
      }
   }
}
