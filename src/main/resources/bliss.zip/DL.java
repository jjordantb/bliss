public class DL extends RK {
   Object K;

   DL(YSI var1, Object var2, int var3) {
      super(var1, var3);
      this.K = var2;
   }

   boolean method3409() {
      return false;
   }

   boolean method3407() {
      return false;
   }

   Object method3410() {
      return this.K;
   }

   Object method3408() {
      return this.K;
   }

   Object method3406() {
      return this.K;
   }
}
