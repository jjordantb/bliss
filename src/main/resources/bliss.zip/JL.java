public class JL extends QK {
   CR G;

   public JL(CR var1) {
      this.G = var1;
   }

   static final void C(OU var0, byte var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         SJ.I(var3, var4, var0, -1468199503);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aid.jy(" + ')');
      }
   }
}
