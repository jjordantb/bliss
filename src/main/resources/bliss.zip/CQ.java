import java.util.List;

public class CQ {
   static int I = 1483930890;
   static ON[] Z;
   static int C = 0;
   static int B = 0;
   static GQ[] D;
   static int F = 0;
   static int J = 0;
   static int S = 0;
   static List A;
   static JX E = new JX(8);
   static int G = 0;
   static int H = 0;
   public static String K;
   public static int L;

   CQ() throws Throwable {
      throw new Error();
   }

   static final void I(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)9);
         X var4 = IU.F[var2 >> 16];
         IU.I(var3, var4, var0, -2144331170);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "oi.cu(" + ')');
      }
   }

   public static void I(int var0, int var1, int var2, int var3) {
      try {
         var0 <<= 3;
         var1 <<= 3;
         var2 <<= 3;
         XEI.WZ = (float)var0;
         XEI.qD = (float)var1;
         if (EE.V * -863531439 == 3) {
            XEI.VZ = -648269561 * var0;
            CZ.I = -1587695039 * var1;
            TF.C = -851711283 * var2;
         }

         VFI.I((byte)63);
         XEI.bZ = true;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "oi.hh(" + ')');
      }
   }
}
