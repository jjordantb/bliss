public class BQ implements IAI {
   int Z;
   int append;
   int[] method3546;

   public boolean method238(PM var1, WSI[] var2, int var3, YO var4) {
      if (var1 == null) {
         if (-1 != this.append * 1099340307) {
            return false;
         }
      } else {
         if (1099340307 * this.append != var1.method3546(-1372966703)) {
            return false;
         }

         if (this.Z * 1026337135 > var1.method3548(49279861)) {
            return false;
         }

         int[] var5 = this.method3546;

         for(int var6 = 0; var6 < var5.length; ++var6) {
            int var7 = var5[var6];
            if (!var4.method3936(var7, 311958108)) {
               return false;
            }
         }
      }

      return true;
   }

   public boolean method239(PM var1, WSI[] var2, int var3, YO var4, int var5) {
      try {
         if (var1 == null) {
            if (-1 != this.append * 1099340307) {
               return false;
            }
         } else {
            if (1099340307 * this.append != var1.method3546(-1372966703)) {
               return false;
            }

            if (this.Z * 1026337135 > var1.method3548(1840203341)) {
               return false;
            }

            int[] var6 = this.method3546;

            for(int var7 = 0; var7 < var6.length; ++var7) {
               int var8 = var6[var7];
               if (!var4.method3936(var8, 741080989)) {
                  return false;
               }
            }
         }

         return true;
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "oj.a(" + ')');
      }
   }

   public boolean method237(PM var1, WSI[] var2, int var3, YO var4) {
      if (var1 == null) {
         if (-1 != this.append * 1099340307) {
            return false;
         }
      } else {
         if (1099340307 * this.append != var1.method3546(-1372966703)) {
            return false;
         }

         if (this.Z * 1026337135 > var1.method3548(966339099)) {
            return false;
         }

         int[] var5 = this.method3546;

         for(int var6 = 0; var6 < var5.length; ++var6) {
            int var7 = var5[var6];
            if (!var4.method3936(var7, 226662543)) {
               return false;
            }
         }
      }

      return true;
   }

   BQ(int var1, int var2, int[] var3) {
      this.append = var1 * 397623323;
      this.Z = 875353487 * var2;
      this.method3546 = var3;
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)23);
         X var4 = IU.F[var2 >> 16];
         EA.I(var3, var4, var0, 2094067145);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "oj.di(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)69);
         X var4 = IU.F[var2 >> 16];
         ESI.I(var3, var4, var0, 230712598);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "oj.jc(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         var0.J -= -783761378;
         int var2 = var0.H[var0.J * 681479919];
         int var3 = var0.H[var0.J * 681479919 + 1];
         if (var2 >= 0 && var2 < 2) {
            XEI.fZ[var2] = new int[var3 << 1][4];
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "oj.afc(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         IT.I(var3, var4, var0, 2138038025);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "oj.ns(" + ')');
      }
   }
}
