public class JZ extends FZ {
   static int append = 13;
   int[][] method1331 = new int[18][17];
   static int method1340 = 1;
   static int method3119 = 0;
   static int method5297 = 2;
   static int method5392 = 4;
   static int toString = 5;
   static int W = 6;
   static int X = 15;
   static int Y = 8;
   static int i = 9;
   static int z = 10;
   static int c = 1;
   static int b = 12;
   static int d = 7;
   static int f = 14;
   YF j = new YF();
   static int s = 16;
   static int a = 17;
   static int e = 2;
   static int g = 11;
   static int h = 3;
   static int k = 7;
   static int l = 12;
   static int m = 17;
   static int n = 18;
   BI o;
   L[] p = new L[18];
   static int q = 0;
   int[] r;
   static int t;

   boolean F(int var1) throws Exception_Sub2 {
      try {
         this.o = this.S.method5297("Model");
         VG var2 = this.o.I("DiffuseSampler", 1135001419);
         VG var3 = this.o.I("EnvironmentSampler", -972656168);
         VG var4 = this.o.I("PointLightsPosAndRadiusSq", 585215200);
         VG var5 = this.o.I("PointLightsDiffuseColour", -1873919067);
         VG var6 = this.o.I("WVPMatrix", 43401113);
         VG var7 = this.o.I("TexCoordMatrix", -706631042);
         VG var8 = this.o.I("HeightFogPlane", 363843467);
         VG var9 = this.o.I("HeightFogColour", 177108279);
         VG var10 = this.o.I("DistanceFogPlane", -1871545778);
         VG var11 = this.o.I("DistanceFogColour", 245551574);
         VG var12 = this.o.I("SunDir", 1373721238);
         VG var13 = this.o.I("SunColour", -1112379488);
         VG var14 = this.o.I("AntiSunColour", 737015999);
         VG var15 = this.o.I("AmbientColour", -602820050);
         VG var16 = this.o.I("EyePos", -2130760607);
         VG var17 = this.o.I("SpecularExponent", -893975178);
         VG var18 = this.o.I("WorldMatrix", -1633360167);
         this.p[0] = this.o.I("Unlit", (byte)-128);
         this.p[1] = this.o.I("Unlit_IgnoreAlpha", (byte)-73);
         this.p[17] = this.o.I("UnderwaterGround", (byte)-78);

         int var19;
         for(var19 = 0; var19 <= 4; ++var19) {
            this.p[var19 + 2] = this.o.I("Standard_" + var19 + "PointLights", (byte)-123);
            this.p[var19 + 7] = this.o.I("Specular_" + var19 + "PointLights", (byte)-11);
            this.p[12 + var19] = this.o.I("EnvironmentalMapping_" + var19 + "PointLights", (byte)-25);
         }

         for(var19 = 0; var19 < 18; ++var19) {
            int var20 = this.o.I(this.p[var19], -180449856);
            this.method1331[var19][2] = var2.method3119(var20);
            this.method1331[var19][3] = var3.method3119(var20);
            this.method1331[var19][1] = var4.method3119(var20);
            this.method1331[var19][0] = var5.method3119(var20);
            this.method1331[var19][4] = var6.method3119(var20);
            this.method1331[var19][5] = var7.method3119(var20);
            this.method1331[var19][7] = var8.method3119(var20);
            this.method1331[var19][8] = var9.method3119(var20);
            this.method1331[var19][9] = var10.method3119(var20);
            this.method1331[var19][10] = var11.method3119(var20);
            this.method1331[var19][11] = var12.method3119(var20);
            this.method1331[var19][12] = var13.method3119(var20);
            this.method1331[var19][13] = var14.method3119(var20);
            this.method1331[var19][14] = var15.method3119(var20);
            this.method1331[var19][6] = var16.method3119(var20);
            this.method1331[var19][15] = var18.method3119(var20);
            this.method1331[var19][16] = var17.method3119(var20);
         }

         this.o.method1331(this.p[2]);
         return true;
      } catch (RuntimeException var21) {
         throw DQ.I(var21, "yg.m(" + ')');
      }
   }

   public void method1519() {
      this.o.method1331(this.p[17]);
      this.r = this.method1331[this.o.F(1705171320)];
      this.o.method1340();
      this.append(0, -1073004345);
   }

   public void method1506(YF var1) {
      try {
         this.j.I(var1);
         this.j.Z(this.S.z);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "yg.f(" + ')');
      }
   }

   public void method1504(boolean var1) {
      if (var1) {
         this.o.method1331(this.p[1]);
      } else {
         this.o.method1331(this.p[0]);
      }

      this.r = this.method1331[this.o.F(1149539641)];
      this.o.method1340();
      this.o.I(this.r[2], 0, this.D, -1231900613);
      this.o.I(this.r[4], this.j, (byte)-9);
      this.o.I(this.r[5], this.J, -1599730439);
      this.o.I(this.r[7], this.G.B, this.G.C, this.G.I, this.G.Z, (byte)40);
      this.o.I(this.r[8], this.H.I, this.H.C, this.H.Z, 123660505);
      this.o.I(this.r[9], this.K.B, this.K.C, this.K.I, this.K.Z, (byte)95);
      this.o.I(this.r[10], this.E.I, this.E.C, this.E.Z, -461195201);
      this.S.method5392(QB.B, this.R, this.T, this.U, this.Z);
   }

   public void method1510() {
      try {
         this.o.method1331(this.p[17]);
         this.r = this.method1331[this.o.F(1837632307)];
         this.o.method1340();
         this.append(0, -445981727);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "yg.d(" + ')');
      }
   }

   public void method1508(int var1) {
      try {
         this.o.method1331(this.p[7 + var1]);
         this.r = this.method1331[this.o.F(1308408550)];
         this.o.method1340();
         this.o.I(this.r[6], this.P.I, this.P.C, this.P.Z, 526269137);
         this.o.I(this.r[16], this.A, this.I, 0.0F, 0.0F, (byte)86);
         this.append(var1, -283020523);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "yg.i(" + ')');
      }
   }

   public void method1507(int var1) {
      try {
         this.o.method1331(this.p[var1 + 2]);
         this.r = this.method1331[this.o.F(1833355992)];
         this.o.method1340();
         this.append(var1, -1046248356);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "yg.p(" + ')');
      }
   }

   void append(int var1, int var2) {
      try {
         this.o.I(this.r[2], 0, this.D, -1687300053);
         this.o.I(this.r[4], this.j, (byte)-39);
         this.o.I(this.r[5], this.J, -1599730439);
         this.o.I(this.r[7], this.G.B, this.G.C, this.G.I, this.G.Z, (byte)81);
         this.o.I(this.r[8], this.H.I, this.H.C, this.H.Z, -1324328823);
         this.o.I(this.r[9], this.K.B, this.K.C, this.K.I, this.K.Z, (byte)20);
         this.o.I(this.r[10], this.E.I, this.E.C, this.E.Z, 168782883);
         this.o.I(this.r[11], this.M, 902988581);
         this.o.I(this.r[12], this.N, -1254001480);
         this.o.I(this.r[13], this.O, 2097192794);
         this.o.I(this.r[14], this.C, -1756213043);
         if (var1 > 0) {
            this.o.I(this.r[1], this.B, 4 * var1, 2080438398);
            this.o.I(this.r[0], this.L, 4 * var1, 358111941);
         }

         this.S.method5392(QB.B, this.R, this.T, this.U, this.Z);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "yg.w(" + ')');
      }
   }

   public void method1520(int var1) {
      this.o.method1331(this.p[7 + var1]);
      this.r = this.method1331[this.o.F(1161240102)];
      this.o.method1340();
      this.o.I(this.r[6], this.P.I, this.P.C, this.P.Z, 246564478);
      this.o.I(this.r[16], this.A, this.I, 0.0F, 0.0F, (byte)76);
      this.append(var1, -277375124);
   }

   public void method1511(YF var1) {
      this.j.I(var1);
      this.j.Z(this.S.z);
   }

   public void method1512(YF var1) {
      this.j.I(var1);
      this.j.Z(this.S.z);
   }

   public void method1513(boolean var1) {
      if (var1) {
         this.o.method1331(this.p[1]);
      } else {
         this.o.method1331(this.p[0]);
      }

      this.r = this.method1331[this.o.F(2019533415)];
      this.o.method1340();
      this.o.I(this.r[2], 0, this.D, 26639341);
      this.o.I(this.r[4], this.j, (byte)-12);
      this.o.I(this.r[5], this.J, -1599730439);
      this.o.I(this.r[7], this.G.B, this.G.C, this.G.I, this.G.Z, (byte)115);
      this.o.I(this.r[8], this.H.I, this.H.C, this.H.Z, 1153447117);
      this.o.I(this.r[9], this.K.B, this.K.C, this.K.I, this.K.Z, (byte)32);
      this.o.I(this.r[10], this.E.I, this.E.C, this.E.Z, -25851858);
      this.S.method5392(QB.B, this.R, this.T, this.U, this.Z);
   }

   public void method1514(boolean var1) {
      try {
         if (var1) {
            this.o.method1331(this.p[1]);
         } else {
            this.o.method1331(this.p[0]);
         }

         this.r = this.method1331[this.o.F(1072994601)];
         this.o.method1340();
         this.o.I(this.r[2], 0, this.D, 1542479016);
         this.o.I(this.r[4], this.j, (byte)-116);
         this.o.I(this.r[5], this.J, -1599730439);
         this.o.I(this.r[7], this.G.B, this.G.C, this.G.I, this.G.Z, (byte)50);
         this.o.I(this.r[8], this.H.I, this.H.C, this.H.Z, 105504318);
         this.o.I(this.r[9], this.K.B, this.K.C, this.K.I, this.K.Z, (byte)87);
         this.o.I(this.r[10], this.E.I, this.E.C, this.E.Z, 937631726);
         this.S.method5392(QB.B, this.R, this.T, this.U, this.Z);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "yg.b(" + ')');
      }
   }

   public void method1515(boolean var1) {
      if (var1) {
         this.o.method1331(this.p[1]);
      } else {
         this.o.method1331(this.p[0]);
      }

      this.r = this.method1331[this.o.F(1256833385)];
      this.o.method1340();
      this.o.I(this.r[2], 0, this.D, -1297905269);
      this.o.I(this.r[4], this.j, (byte)-110);
      this.o.I(this.r[5], this.J, -1599730439);
      this.o.I(this.r[7], this.G.B, this.G.C, this.G.I, this.G.Z, (byte)8);
      this.o.I(this.r[8], this.H.I, this.H.C, this.H.Z, 1284230441);
      this.o.I(this.r[9], this.K.B, this.K.C, this.K.I, this.K.Z, (byte)22);
      this.o.I(this.r[10], this.E.I, this.E.C, this.E.Z, 140507609);
      this.S.method5392(QB.B, this.R, this.T, this.U, this.Z);
   }

   public void method1518(int var1) {
      this.o.method1331(this.p[var1 + 2]);
      this.r = this.method1331[this.o.F(1157195426)];
      this.o.method1340();
      this.append(var1, -591376513);
   }

   public void method1516(int var1) {
      this.o.method1331(this.p[var1 + 12]);
      this.r = this.method1331[this.o.F(1091683918)];
      this.o.method1340();
      this.o.Z(this.r[15], this.V, (byte)-55);
      this.o.I(this.r[6], this.P.I, this.P.C, this.P.Z, 822436728);
      this.o.I(this.r[3], 1, this.F, 1019506106);
      this.append(var1, -410682702);
   }

   public void method1517(int var1) {
      this.o.method1331(this.p[var1 + 12]);
      this.r = this.method1331[this.o.F(1368039593)];
      this.o.method1340();
      this.o.Z(this.r[15], this.V, (byte)-88);
      this.o.I(this.r[6], this.P.I, this.P.C, this.P.Z, 852060499);
      this.o.I(this.r[3], 1, this.F, -1849462852);
      this.append(var1, 108146039);
   }

   public void method1521(int var1) {
      this.o.method1331(this.p[7 + var1]);
      this.r = this.method1331[this.o.F(2005581211)];
      this.o.method1340();
      this.o.I(this.r[6], this.P.I, this.P.C, this.P.Z, 1321729054);
      this.o.I(this.r[16], this.A, this.I, 0.0F, 0.0F, (byte)102);
      this.append(var1, 1261826682);
   }

   public JZ(NJI var1) throws Exception_Sub2 {
      super(var1);
      this.F(-1327173096);
   }

   public void method1503(int var1) {
      try {
         this.o.method1331(this.p[var1 + 12]);
         this.r = this.method1331[this.o.F(1210039282)];
         this.o.method1340();
         this.o.Z(this.r[15], this.V, (byte)-116);
         this.o.I(this.r[6], this.P.I, this.P.C, this.P.Z, -1454092733);
         this.o.I(this.r[3], 1, this.F, 67553741);
         this.append(var1, -50147859);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "yg.k(" + ')');
      }
   }

   public void method1505(int var1) {
      this.o.method1331(this.p[7 + var1]);
      this.r = this.method1331[this.o.F(1300617197)];
      this.o.method1340();
      this.o.I(this.r[6], this.P.I, this.P.C, this.P.Z, -1538662459);
      this.o.I(this.r[16], this.A, this.I, 0.0F, 0.0F, (byte)124);
      this.append(var1, 1244225223);
   }
}
