public class DG extends AE {
   public short J;

   public DG(short var1) {
      this.J = var1;
   }

   static void I(int var0, int var1, int var2, int var3, int var4, int var5) {
      try {
         int var6 = HY.I(var2, 1155384281 * DT.C, DT.B * -1062447355, -1212608691);
         int var7 = HY.I(var3, DT.C * 1155384281, DT.B * -1062447355, -1212608691);
         int var8 = HY.I(var0, -1424479739 * DT.D, 1135094847 * DT.Z, -1212608691);
         int var9 = HY.I(var1, DT.D * -1424479739, 1135094847 * DT.Z, -1212608691);

         for(int var10 = var6; var10 <= var7; ++var10) {
            DFI.I(DT.I[var10], var8, var9, var4, 420313117);
         }

      } catch (RuntimeException var11) {
         throw DQ.I(var11, "abe.s(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         var0.J -= -783761378;
         BZ.I(var0.H[681479919 * var0.J], var0.H[681479919 * var0.J + 1], 255, -649427988);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "abe.sj(" + ')');
      }
   }
}
