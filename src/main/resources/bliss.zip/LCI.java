import jaggl.OpenGL;

public class LCI extends KCI {
   int a;
   OJI f;
   static int glBindFramebufferEXT = 16;
   int glCheckFramebufferStatusEXT;
   int glFramebufferRenderbufferEXT;
   int glGenFramebuffersEXT;
   WAI method136;
   int method167;
   WAI[] B = new WAI[4];

   public boolean method560() {
      int var1 = OpenGL.glCheckFramebufferStatusEXT(36160);
      return var1 == 36053;
   }

   public int method545() {
      return this.method167;
   }

   public int method552() {
      return this.glFramebufferRenderbufferEXT;
   }

   public void method563(int var1, TAI var2) {
      int var3 = 1 << var1;
      WAI var4 = (WAI)var2;
      if (var2 == null) {
         this.glCheckFramebufferStatusEXT &= ~var3;
         this.B[var1] = null;
         if (this.glCheckFramebufferStatusEXT == 0) {
            this.glFramebufferRenderbufferEXT = 0;
            this.method167 = 0;
         }
      } else {
         if (this.glCheckFramebufferStatusEXT != 0) {
            if (this.method167 != var4.a() || this.glFramebufferRenderbufferEXT != var4.f()) {
               throw new RuntimeException();
            }
         } else {
            this.glFramebufferRenderbufferEXT = var4.f();
            this.method167 = var4.a();
            this.I();
         }

         this.glCheckFramebufferStatusEXT |= var3;
         this.B[var1] = var4;
      }

      if (this == this.f.I((short)-4810)) {
         this.f(var1);
      } else {
         this.a |= var3;
      }

   }

   void a() {
      if (this.method136 == null) {
         OpenGL.glFramebufferRenderbufferEXT(36160, 36096, 36161, 0);
      } else {
         this.method136.method167(36096);
      }

   }

   public void method138() {
      if (this.glGenFramebuffersEXT != 0) {
         this.f.A(this.glGenFramebuffersEXT);
         this.glGenFramebuffersEXT = 0;
      }

   }

   LCI(OJI var1) {
      super(var1);
      this.f = var1;
      int[] var2 = new int[1];
      OpenGL.glGenFramebuffersEXT(1, var2, 0);
      this.glGenFramebuffersEXT = var2[0];
   }

   public void method135() {
      if (this.glGenFramebuffersEXT != 0) {
         this.f.A(this.glGenFramebuffersEXT);
         this.glGenFramebuffersEXT = 0;
      }

   }

   boolean method136() {
      OpenGL.glBindFramebufferEXT(36160, this.glGenFramebuffersEXT);

      for(int var1 = 0; var1 < 4; ++var1) {
         if ((this.a & 1 << var1) != 0) {
            this.f(var1);
         }
      }

      if ((this.a & 16) != 0) {
         this.a();
      }

      this.a = 0;
      return super.method136();
   }

   boolean method546() {
      OpenGL.glBindFramebufferEXT(36160, 0);
      return true;
   }

   public int method549() {
      return this.method167;
   }

   void f(int var1) {
      WAI var2 = this.B[var1];
      if (var2 == null) {
         OpenGL.glFramebufferRenderbufferEXT(36160, '賠' + var1, 36161, 0);
      } else {
         var2.method167('賠' + var1);
      }

   }

   public int method544() {
      return this.glFramebufferRenderbufferEXT;
   }

   public void method561(int var1, TAI var2) {
      int var3 = 1 << var1;
      WAI var4 = (WAI)var2;
      if (var2 == null) {
         this.glCheckFramebufferStatusEXT &= ~var3;
         this.B[var1] = null;
         if (this.glCheckFramebufferStatusEXT == 0) {
            this.glFramebufferRenderbufferEXT = 0;
            this.method167 = 0;
         }
      } else {
         if (this.glCheckFramebufferStatusEXT != 0) {
            if (this.method167 != var4.a() || this.glFramebufferRenderbufferEXT != var4.f()) {
               throw new RuntimeException();
            }
         } else {
            this.glFramebufferRenderbufferEXT = var4.f();
            this.method167 = var4.a();
            this.I();
         }

         this.glCheckFramebufferStatusEXT |= var3;
         this.B[var1] = var4;
      }

      if (this == this.f.I((short)-5292)) {
         this.f(var1);
      } else {
         this.a |= var3;
      }

   }

   public void method562(int var1, TAI var2) {
      int var3 = 1 << var1;
      WAI var4 = (WAI)var2;
      if (var2 == null) {
         this.glCheckFramebufferStatusEXT &= ~var3;
         this.B[var1] = null;
         if (this.glCheckFramebufferStatusEXT == 0) {
            this.glFramebufferRenderbufferEXT = 0;
            this.method167 = 0;
         }
      } else {
         if (this.glCheckFramebufferStatusEXT != 0) {
            if (this.method167 != var4.a() || this.glFramebufferRenderbufferEXT != var4.f()) {
               throw new RuntimeException();
            }
         } else {
            this.glFramebufferRenderbufferEXT = var4.f();
            this.method167 = var4.a();
            this.I();
         }

         this.glCheckFramebufferStatusEXT |= var3;
         this.B[var1] = var4;
      }

      if (this == this.f.I((short)4564)) {
         this.f(var1);
      } else {
         this.a |= var3;
      }

   }

   public void method564(XAI var1) {
      WAI var2 = (WAI)var1;
      if (var1 == null) {
         this.glCheckFramebufferStatusEXT &= -17;
         this.method136 = null;
         if (this.glCheckFramebufferStatusEXT == 0) {
            this.glFramebufferRenderbufferEXT = 0;
            this.method167 = 0;
         }
      } else {
         if (this.glCheckFramebufferStatusEXT != 0) {
            if (this.method167 != var2.a() || this.glFramebufferRenderbufferEXT != var2.f()) {
               throw new RuntimeException();
            }
         } else {
            this.glFramebufferRenderbufferEXT = var2.f();
            this.method167 = var2.a();
            this.I();
         }

         this.glCheckFramebufferStatusEXT |= 16;
         this.method136 = var2;
      }

      if (this == this.f.I((short)18572)) {
         this.a();
      } else {
         this.a |= 16;
      }

   }

   public boolean method557() {
      int var1 = OpenGL.glCheckFramebufferStatusEXT(36160);
      return var1 == 36053;
   }

   public boolean method559() {
      int var1 = OpenGL.glCheckFramebufferStatusEXT(36160);
      return var1 == 36053;
   }

   boolean method134() {
      OpenGL.glBindFramebufferEXT(36160, this.glGenFramebuffersEXT);

      for(int var1 = 0; var1 < 4; ++var1) {
         if ((this.a & 1 << var1) != 0) {
            this.f(var1);
         }
      }

      if ((this.a & 16) != 0) {
         this.a();
      }

      this.a = 0;
      return super.method136();
   }

   boolean method548() {
      OpenGL.glBindFramebufferEXT(36160, 0);
      return true;
   }

   public void method137() {
      if (this.glGenFramebuffersEXT != 0) {
         this.f.A(this.glGenFramebuffersEXT);
         this.glGenFramebuffersEXT = 0;
      }

   }

   public void method558(XAI var1) {
      WAI var2 = (WAI)var1;
      if (var1 == null) {
         this.glCheckFramebufferStatusEXT &= -17;
         this.method136 = null;
         if (this.glCheckFramebufferStatusEXT == 0) {
            this.glFramebufferRenderbufferEXT = 0;
            this.method167 = 0;
         }
      } else {
         if (this.glCheckFramebufferStatusEXT != 0) {
            if (this.method167 != var2.a() || this.glFramebufferRenderbufferEXT != var2.f()) {
               throw new RuntimeException();
            }
         } else {
            this.glFramebufferRenderbufferEXT = var2.f();
            this.method167 = var2.a();
            this.I();
         }

         this.glCheckFramebufferStatusEXT |= 16;
         this.method136 = var2;
      }

      if (this == this.f.I((short)-4671)) {
         this.a();
      } else {
         this.a |= 16;
      }

   }

   public int method550() {
      return this.method167;
   }

   public int method551() {
      return this.method167;
   }

   public int method547() {
      return this.method167;
   }

   public boolean method565() {
      int var1 = OpenGL.glCheckFramebufferStatusEXT(36160);
      return var1 == 36053;
   }
}
