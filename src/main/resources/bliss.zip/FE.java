import java.awt.Component;
import java.awt.Cursor;
import java.awt.Point;
import java.awt.Robot;
import java.awt.image.BufferedImage;

public class FE {
   Robot append = new Robot();

   public FE() throws Exception {
   }

   public void append(int var1, int var2) {
      try {
         this.append.mouseMove(var1, var2);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "mg.movemouse(" + ')');
      }
   }

   public void I(Component var1, int[] var2, int var3, int var4, Point var5) {
      try {
         if (var2 != null) {
            BufferedImage var6 = new BufferedImage(var3, var4, 2);
            var6.setRGB(0, 0, var3, var4, var2, 0, var3);
            var1.setCursor(var1.getToolkit().createCustomCursor(var6, var5, (String)null));
         } else {
            var1.setCursor((Cursor)null);
         }

      } catch (RuntimeException var7) {
         throw DQ.I(var7, "mg.setcustomcursor(" + ')');
      }
   }
}
