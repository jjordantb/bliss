public class JH extends YG {
   static boolean Q = false;
   public static YY R;

   void I(int var1, REI var2, byte var3) {
      try {
         if (var1 == 0) {
            this.N = var2.I() == 1;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ahc.r(" + ')');
      }
   }

   void I(int var1, REI var2) {
      if (var1 == 0) {
         this.N = var2.I() == 1;
      }

   }

   int[][] I(int var1, byte var2) {
      try {
         int[][] var3 = this.L.I(var1, (byte)45);
         if (this.L.I) {
            int[][] var4 = this.I(0, var1, (byte)8);
            int[] var5 = var4[0];
            int[] var6 = var4[1];
            int[] var7 = var4[2];
            int[] var8 = var3[0];
            int[] var9 = var3[1];
            int[] var10 = var3[2];

            for(int var11 = 0; var11 < -1474554145 * WJ.C; ++var11) {
               var8[var11] = 4096 - var5[var11];
               var9[var11] = 4096 - var6[var11];
               var10[var11] = 4096 - var7[var11];
            }
         }

         return var3;
      } catch (RuntimeException var12) {
         throw DQ.I(var12, "ahc.k(" + ')');
      }
   }

   int[] append(int var1) {
      int[] var2 = this.P.I(var1, 2004100981);
      if (this.P.D) {
         int[] var3 = this.I(0, var1, -1887337990);

         for(int var4 = 0; var4 < WJ.C * -1474554145; ++var4) {
            var2[var4] = 4096 - var3[var4];
         }
      }

      return var2;
   }

   public JH() {
      super(1, false);
   }

   int[] toString(int var1) {
      int[] var2 = this.P.I(var1, 861368495);
      if (this.P.D) {
         int[] var3 = this.I(0, var1, -1887337990);

         for(int var4 = 0; var4 < WJ.C * -1474554145; ++var4) {
            var2[var4] = 4096 - var3[var4];
         }
      }

      return var2;
   }

   int[] Z(int var1, int var2) {
      try {
         int[] var3 = this.P.I(var1, 1893218211);
         if (this.P.D) {
            int[] var4 = this.I(0, var1, -1887337990);

            for(int var5 = 0; var5 < WJ.C * -1474554145; ++var5) {
               var3[var5] = 4096 - var4[var5];
            }
         }

         return var3;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ahc.i(" + ')');
      }
   }

   void append(int var1, REI var2) {
      if (var1 == 0) {
         this.N = var2.I() == 1;
      }

   }

   int[][] D(int var1) {
      int[][] var2 = this.L.I(var1, (byte)72);
      if (this.L.I) {
         int[][] var3 = this.I(0, var1, (byte)8);
         int[] var4 = var3[0];
         int[] var5 = var3[1];
         int[] var6 = var3[2];
         int[] var7 = var2[0];
         int[] var8 = var2[1];
         int[] var9 = var2[2];

         for(int var10 = 0; var10 < -1474554145 * WJ.C; ++var10) {
            var7[var10] = 4096 - var4[var10];
            var8[var10] = 4096 - var5[var10];
            var9[var10] = 4096 - var6[var10];
         }
      }

      return var2;
   }

   int[][] F(int var1) {
      int[][] var2 = this.L.I(var1, (byte)123);
      if (this.L.I) {
         int[][] var3 = this.I(0, var1, (byte)8);
         int[] var4 = var3[0];
         int[] var5 = var3[1];
         int[] var6 = var3[2];
         int[] var7 = var2[0];
         int[] var8 = var2[1];
         int[] var9 = var2[2];

         for(int var10 = 0; var10 < -1474554145 * WJ.C; ++var10) {
            var7[var10] = 4096 - var4[var10];
            var8[var10] = 4096 - var5[var10];
            var9[var10] = 4096 - var6[var10];
         }
      }

      return var2;
   }
}
