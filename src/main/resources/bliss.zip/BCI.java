public class BCI {
   public int I;
   public int Z;
   public char C;
   public int B;

   void append(REI var1, int var2, int var3) {
      try {
         if (var2 == 1) {
            this.C = IZI.I(var1.S(-12558881), 1830993802);
         } else if (3 == var2) {
            this.Z = var1.C() * -1544029687;
            this.I = var1.I() * -786049945;
            this.B = var1.I() * -2127046785;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "vy.f(" + ')');
      }
   }

   void I(REI var1, int var2) {
      try {
         while(true) {
            int var3 = var1.I();
            if (var3 == 0) {
               if (var2 == -1099657695) {
                  ;
               }

               return;
            }

            this.append(var1, var3, 1972113647);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "vy.a(" + ')');
      }
   }
}
