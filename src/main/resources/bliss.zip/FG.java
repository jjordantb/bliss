public class FG extends AE {
   RSI J;

   FG(RSI var1) {
      this.J = var1;
   }
}
