public class III {
   static IY I = new IY();

   III() throws Throwable {
      throw new Error();
   }

   static final void I(HSI var0, X var1, OU var2, int var3) {
      try {
         int var4 = var2.H[(var2.J -= -391880689) * 681479919];
         if (var4 == 270446479 * HSI.aZ || -1179480373 * HSI.I == var4 || 1432814379 * HSI.fI == var4) {
            var0.DZ = var4 * 2138287179;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ts.id(" + ')');
      }
   }

   public static final int I(String var0, int var1) {
      try {
         if (var0 == null) {
            return -1;
         } else {
            for(int var2 = 0; var2 < -1054937867 * XEI.kD; ++var2) {
               if (var0.equalsIgnoreCase(XEI.cI[var2])) {
                  return var2;
               }
            }

            return -1;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ts.lg(" + ')');
      }
   }

   static void I(KJ var0, int var1, int var2, int var3, boolean var4, long var5) {
      try {
         XP.I(var0, var1, var2, var3, var4, var5, 0, -1584646162);
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "ts.p(" + ')');
      }
   }
}
