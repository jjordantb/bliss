public class KH extends YG {
   DJI[] method1047;
   static boolean method1048 = true;

   final void I(int[][] var1, byte var2) {
      try {
         int var3 = WJ.C * -1474554145;
         int var4 = 461985445 * WJ.B;
         PT.I((int[][])var1, (byte)1);
         HY.I(0, 0, WJ.I * -901777799, WJ.F * -289063255, -252258015);
         if (this.method1047 != null) {
            for(int var5 = 0; var5 < this.method1047.length; ++var5) {
               DJI var6 = this.method1047[var5];
               int var7 = var6.C * 699194661;
               int var8 = 1785836763 * var6.Z;
               if (var7 >= 0) {
                  if (var8 >= 0) {
                     var6.method1048(var3, var4, (byte)1);
                  } else {
                     var6.method1047(var3, var4, (byte)1);
                  }
               } else if (var8 >= 0) {
                  var6.method1054(var3, var4, (byte)88);
               }
            }
         }

      } catch (RuntimeException var9) {
         throw DQ.I(var9, "agd.ac(" + ')');
      }
   }

   int[] Z(int var1, int var2) {
      try {
         int[] var3 = this.P.I(var1, 22480626);
         if (this.P.D) {
            this.I(this.P.Z(-45371310), (byte)24);
         }

         return var3;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "agd.i(" + ')');
      }
   }

   int[][] I(int var1, byte var2) {
      try {
         int[][] var3 = this.L.I(var1, (byte)90);
         if (this.L.I) {
            int var4 = -1474554145 * WJ.C;
            int var5 = WJ.B * 461985445;
            int[][] var6 = new int[var5][var4];
            int[][][] var7 = this.L.I((byte)53);
            this.I(var6, (byte)121);

            for(int var8 = 0; var8 < 461985445 * WJ.B; ++var8) {
               int[] var9 = var6[var8];
               int[][] var10 = var7[var8];
               int[] var11 = var10[0];
               int[] var12 = var10[1];
               int[] var13 = var10[2];

               for(int var14 = 0; var14 < WJ.C * -1474554145; ++var14) {
                  int var15 = var9[var14];
                  var13[var14] = (var15 & 255) << 4;
                  var12[var14] = (var15 & '\uff00') >> 4;
                  var11[var14] = (var15 & 16711680) >> 12;
               }
            }
         }

         return var3;
      } catch (RuntimeException var16) {
         throw DQ.I(var16, "agd.k(" + ')');
      }
   }

   void I(int var1, REI var2, byte var3) {
      try {
         if (var1 == 0) {
            this.method1047 = new DJI[var2.I()];

            for(int var4 = 0; var4 < this.method1047.length; ++var4) {
               int var5 = var2.I();
               switch(var5) {
               case 0:
                  this.method1047[var4] = QK.I(var2, -920913322);
                  break;
               case 1:
                  this.method1047[var4] = UEI.I(var2, -1403634291);
                  break;
               case 2:
                  this.method1047[var4] = WBI.I(var2, 505653408);
                  break;
               case 3:
                  this.method1047[var4] = YBI.I(var2, 2061944382);
               }
            }
         } else if (var1 == 1) {
            this.N = var2.I() == 1;
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "agd.r(" + ')');
      }
   }

   int[] append(int var1) {
      int[] var2 = this.P.I(var1, 294665976);
      if (this.P.D) {
         this.I(this.P.Z(-654420077), (byte)118);
      }

      return var2;
   }

   int[] method1047(int var1) {
      int[] var2 = this.P.I(var1, 569359385);
      if (this.P.D) {
         this.I(this.P.Z(226434011), (byte)55);
      }

      return var2;
   }

   void method1048(int var1, REI var2) {
      if (var1 == 0) {
         this.method1047 = new DJI[var2.I()];

         for(int var3 = 0; var3 < this.method1047.length; ++var3) {
            int var4 = var2.I();
            switch(var4) {
            case 0:
               this.method1047[var3] = QK.I(var2, -205247731);
               break;
            case 1:
               this.method1047[var3] = UEI.I(var2, -1904035175);
               break;
            case 2:
               this.method1047[var3] = WBI.I(var2, 634970133);
               break;
            case 3:
               this.method1047[var3] = YBI.I(var2, -291977486);
            }
         }
      } else if (var1 == 1) {
         this.N = var2.I() == 1;
      }

   }

   public KH() {
      super(0, true);
   }

   void method1054(int var1, REI var2) {
      if (var1 == 0) {
         this.method1047 = new DJI[var2.I()];

         for(int var3 = 0; var3 < this.method1047.length; ++var3) {
            int var4 = var2.I();
            switch(var4) {
            case 0:
               this.method1047[var3] = QK.I(var2, 492697170);
               break;
            case 1:
               this.method1047[var3] = UEI.I(var2, 388197853);
               break;
            case 2:
               this.method1047[var3] = WBI.I(var2, 892412290);
               break;
            case 3:
               this.method1047[var3] = YBI.I(var2, -646790238);
            }
         }
      } else if (var1 == 1) {
         this.N = var2.I() == 1;
      }

   }

   int[][] toString(int var1) {
      int[][] var2 = this.L.I(var1, (byte)78);
      if (this.L.I) {
         int var3 = -1474554145 * WJ.C;
         int var4 = WJ.B * 461985445;
         int[][] var5 = new int[var4][var3];
         int[][][] var6 = this.L.I((byte)97);
         this.I(var5, (byte)120);

         for(int var7 = 0; var7 < 461985445 * WJ.B; ++var7) {
            int[] var8 = var5[var7];
            int[][] var9 = var6[var7];
            int[] var10 = var9[0];
            int[] var11 = var9[1];
            int[] var12 = var9[2];

            for(int var13 = 0; var13 < WJ.C * -1474554145; ++var13) {
               int var14 = var8[var13];
               var12[var13] = (var14 & 255) << 4;
               var11[var13] = (var14 & '\uff00') >> 4;
               var10[var13] = (var14 & 16711680) >> 12;
            }
         }
      }

      return var2;
   }

   int[][] method1048(int var1) {
      int[][] var2 = this.L.I(var1, (byte)34);
      if (this.L.I) {
         int var3 = -1474554145 * WJ.C;
         int var4 = WJ.B * 461985445;
         int[][] var5 = new int[var4][var3];
         int[][][] var6 = this.L.I((byte)114);
         this.I(var5, (byte)39);

         for(int var7 = 0; var7 < 461985445 * WJ.B; ++var7) {
            int[] var8 = var5[var7];
            int[][] var9 = var6[var7];
            int[] var10 = var9[0];
            int[] var11 = var9[1];
            int[] var12 = var9[2];

            for(int var13 = 0; var13 < WJ.C * -1474554145; ++var13) {
               int var14 = var8[var13];
               var12[var13] = (var14 & 255) << 4;
               var11[var13] = (var14 & '\uff00') >> 4;
               var10[var13] = (var14 & 16711680) >> 12;
            }
         }
      }

      return var2;
   }

   static final void C(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-15);
         X var4 = IU.F[var2 >> 16];
         GN.I(var3, var4, var0, (byte)31);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "agd.de(" + ')');
      }
   }
}
