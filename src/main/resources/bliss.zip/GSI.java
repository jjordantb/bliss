import java.awt.Canvas;
import java.util.Enumeration;
import java.util.Hashtable;

public abstract class GSI {
   static int CA = 4;
   protected CCI HZ;
   public static int DA = 2;
   public static int append = 3;
   public static int containsKey = 5;
   public static int hasMoreElements = 1;
   static boolean[] keys = new boolean[8];
   public int KZ;
   public FEI LZ;
   public static int method135 = 0;
   protected static int method136 = 2;
   public static int method4989 = 2;
   protected static int method5006 = 1;
   ECI[] method5019 = new ECI[4];
   public static int method5023 = 0;
   protected static int method5029 = 8;
   protected static int method5030 = 16;
   protected static int method5188 = 32;
   public static int method546 = 1;
   int method582 = -1780694629;
   protected static int nextElement = 4;
   protected OCI MZ;
   protected Hashtable NZ = new Hashtable();
   static int put = 8;
   public static BS OZ;

   public abstract OBI method4986(OBI var1, OBI var2, float var3, OBI var4);

   public abstract SBI method4987();

   public final void I(byte var1) throws Exception_Sub1 {
      try {
         this.method4989(0, 0);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ra.u(" + ')');
      }
   }

   abstract void method4989(int var1, int var2) throws Exception_Sub1;

   public final void I(int var1, int var2, int var3, int var4, int var5) {
      try {
         this.XA(var1, var2, var3, var4, 1);
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "ra.bd(" + ')');
      }
   }

   public abstract void method4991(int var1, int var2, int var3, int var4);

   public final CCI I(short var1) {
      try {
         return this.HZ;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ra.at(" + ')');
      }
   }

   public abstract void method4993(int var1);

   public abstract int za();

   public abstract boolean method4994();

   public abstract boolean method4995();

   public abstract void er(int[] var1);

   public abstract void ep();

   public abstract boolean method4996();

   public abstract void method4997(int var1, GE[] var2);

   public abstract void N(int var1, int var2, int var3, int var4, int var5, int var6, byte[] var7, int var8, int var9);

   public abstract boolean method4998();

   public abstract void method4999(int var1, int var2, int var3, int var4, int var5, int var6, int var7);

   public void I(int[] var1) {
      try {
         if (this.MZ != null) {
            var1[0] = this.MZ.method545();
            var1[1] = this.MZ.method552();
         } else {
            var1[1] = 0;
            var1[0] = 0;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ra.av(" + ')');
      }
   }

   public abstract int[] ev(int var1, int var2, int var3, int var4);

   public abstract boolean method5001();

   public final void I(Canvas var1, int var2) {
      try {
         if (this.NZ.containsKey(var1)) {
            OCI var3 = (OCI)this.NZ.get(var1);
            var3.method135();
            this.NZ.remove(var1);
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ra.az(" + ')');
      }
   }

   public final void I(Canvas var1, byte var2) {
      try {
         OCI var3 = (OCI)this.NZ.get(var1);
         if (var3 == null) {
            throw new RuntimeException();
         } else if (929186669 * this.method582 <= 0 && this.HZ == this.MZ) {
            if (this.HZ != null) {
               this.HZ.method546();
            }

            if (this.method582 * 929186669 < 0) {
               this.HZ = var3;
            }

            this.MZ = var3;
            var3.method136();
         } else {
            throw new RuntimeException();
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ra.as(" + ')');
      }
   }

   public abstract int method5004(int var1, int var2);

   public final void I(ECI var1, byte var2) {
      try {
         if (929186669 * this.method582 >= 0 && this.method5019[this.method582 * 929186669] == var1) {
            this.method5019[(this.method582 -= 1780694629) * 929186669 + 1] = null;
            var1.method546();
            if (this.method582 * 929186669 >= 0) {
               this.HZ = this.method5019[this.method582 * 929186669];
               this.method5019[this.method582 * 929186669].method136();
            } else {
               this.HZ = this.MZ;
               this.MZ.method136();
            }

         } else {
            throw new RuntimeException();
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ra.aw(" + ')');
      }
   }

   abstract OCI method5006(Canvas var1, int var2, int var3);

   public abstract void method5007(int var1, int var2, int var3, int var4, int var5, int var6, QJI var7, int var8, int var9, int var10, int var11, int var12);

   public abstract LF method5008();

   abstract void method5009();

   public abstract void method5010(int var1, int var2, int var3, int var4, int var5, int var6, int var7);

   public abstract void method5011();

   public abstract void method5012(boolean var1);

   public abstract void GA(float var1, float var2);

   public abstract void L();

   public abstract LF method5013();

   public abstract void o(int var1, int var2, int var3, int var4);

   public abstract void qa(int[] var1);

   public abstract void ba(int var1, int var2);

   public final void I(int var1, int var2, int var3, int var4, int var5, int var6) {
      try {
         this.method5019(var1, var2, var3, var4, var5, 1);
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "ra.ar(" + ')');
      }
   }

   public final void I(int var1, int var2, int var3, int var4, int var5, byte var6) {
      try {
         this.B(var1, var2, var3, var4, var5, 1);
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "ra.ac(" + ')');
      }
   }

   public final void Z(int var1, int var2, int var3, int var4, int var5) {
      try {
         this.CA(var1, var2, var3, var4, 1);
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "ra.am(" + ')');
      }
   }

   public abstract void J(int var1);

   public abstract int method5017(int var1, int var2);

   public final void Z(int var1, int var2, int var3, int var4, int var5, int var6) {
      try {
         this.method5091(var1, var2, var3, var4, var5, 1);
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "ra.be(" + ')');
      }
   }

   public abstract void method5019(int var1, int var2, int var3, int var4, int var5, int var6);

   public abstract void XA(int var1, int var2, int var3, int var4, int var5);

   public abstract void method5020(int var1, int var2, float var3, int var4, int var5, float var6, int var7, int var8, float var9, int var10, int var11, int var12, int var13);

   abstract void CA(int var1, int var2, int var3, int var4, int var5);

   public abstract void hv(int var1, int var2, int var3);

   public abstract void G(int var1, int var2, int var3, int var4, int var5);

   public abstract void method5021(int var1, GE[] var2);

   public abstract void method5022(int var1, int var2, int var3, int var4, int var5, int var6, QJI var7, int var8, int var9);

   abstract void method5023();

   public abstract int method5024(int var1, int var2);

   public abstract int method5025(int var1, int var2, int var3, int var4, int var5, int var6);

   public abstract VJI method5026(int var1);

   public abstract void method5027(VJI var1);

   public abstract OBI method5028(int var1, int var2, int var3, int var4, int var5, int var6);

   public abstract IBI method5029(int var1, int var2, boolean var3, boolean var4);

   public abstract IBI method5030(int[] var1, int var2, int var3, int var4, int var5, boolean var6);

   public IBI I(int[] var1, int var2, int var3, int var4, int var5, int var6) {
      try {
         return this.method5030(var1, var2, var3, var4, var5, true);
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "ra.bp(" + ')');
      }
   }

   public abstract boolean method5032();

   public abstract IBI method5033(int var1, int var2, int var3, int var4, boolean var5);

   public abstract QJI method5034(int var1, int var2, int[] var3, int[] var4);

   public final void I(int var1, int var2, int var3, int var4, short var5) {
      try {
         this.G(var1, var2, var3, var4, 1);
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "ra.bf(" + ')');
      }
   }

   public abstract void em(boolean var1);

   public abstract YF method5036();

   public abstract UT method5037(MBI var1, int var2, int var3, int var4, int var5);

   public abstract void method5038(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9);

   public abstract void method5039(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9);

   public abstract YJI method5040(int var1, int var2, int[][] var3, int[][] var4, int var5, int var6, int var7);

   public boolean G(int var1) {
      return true;
   }

   public abstract void method5042(XBI var1);

   public abstract void method5043(LF var1);

   public abstract LF method5044();

   public abstract void RA(boolean var1);

   public abstract YF method5045();

   public abstract void ey(float var1, float var2);

   public abstract void m(int var1, float var2, float var3, float var4, float var5, float var6);

   public IBI I(int var1, int var2, boolean var3, int var4) {
      try {
         return this.method5029(var1, var2, var3, false);
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ra.bq(" + ')');
      }
   }

   public abstract void c(int var1, int var2, int var3);

   public abstract void method5047(boolean var1);

   public abstract int method5048();

   public GE I(int var1, int var2, int var3, int var4, int var5, float var6) {
      try {
         return new GE(var1, var2, var3, var4, var5, var6);
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "ra.cg(" + ')');
      }
   }

   public abstract boolean method5050();

   public abstract boolean method5051();

   public abstract void DA(int var1, QJI var2, int var3, int var4);

   public abstract boolean method5052();

   public abstract void method5053();

   public abstract boolean method5054();

   public abstract void method5055(float var1, float var2, float var3, float[] var4);

   public abstract void method5056(int var1, int var2, int var3, int var4);

   public abstract void method5057(int var1, ADI var2);

   public abstract void method5058(int var1, ADI var2);

   public abstract void O();

   public abstract void method5059(float var1, float var2, float var3, float[] var4);

   public abstract void method5060(float var1, float var2, float var3, float[] var4);

   public abstract void method5061(boolean var1);

   public abstract SBI method5062();

   public abstract SBI method5063();

   abstract void method5064(int var1, int var2) throws Exception_Sub1;

   abstract void method5065(int var1, int var2) throws Exception_Sub1;

   public abstract void method5066();

   public abstract void method5067();

   public abstract void hs(float var1);

   abstract void method5068();

   abstract void method5069();

   public abstract void gg(int var1, QJI var2, int var3, int var4);

   public abstract int dm();

   public abstract int du();

   public abstract boolean method5070();

   public abstract boolean method5071();

   public abstract boolean method5072();

   public abstract boolean method5073();

   public abstract boolean method5074();

   public abstract void method5075();

   public abstract boolean method5076();

   public abstract boolean method5077();

   public abstract boolean method5078();

   public abstract boolean method5079();

   public abstract void method5080();

   public abstract boolean method5081();

   public abstract boolean method5082();

   public abstract YF method5083();

   public abstract int[] eg(int var1, int var2, int var3, int var4);

   public abstract OBI method5084(int var1, int var2, int var3, int var4, int var5, int var6);

   public abstract void method5085(boolean var1);

   public abstract void method5086();

   public abstract YJI method5087(int var1, int var2, int[][] var3, int[][] var4, int var5, int var6, int var7);

   public abstract void es(int[] var1);

   public abstract void el(float var1, float var2);

   public abstract void eq();

   public abstract void method5088(int var1, int var2, int var3, int var4, int var5, int var6, QJI var7, int var8, int var9);

   public abstract void ei();

   public abstract void ej(int var1, int var2, int var3, int var4);

   public abstract void method5089(int var1, ADI var2);

   public abstract void ea(int var1, int var2, int var3, int var4);

   public abstract void eh(int var1, int var2, int var3, int var4);

   public abstract void method5090(int var1, int var2, int var3, int var4);

   public abstract void eo(int[] var1);

   public abstract void method5091(int var1, int var2, int var3, int var4, int var5, int var6);

   public abstract void fy(int var1, int var2);

   public abstract OS method5092(LZI var1, RFI[] var2, boolean var3);

   public abstract void fh(int var1, int var2);

   public abstract void fn(int var1, int var2);

   public abstract void method5093(int var1, int var2, int var3, int var4, int var5, int var6);

   public abstract void fa(int var1, int var2, int var3, int var4, int var5, int var6);

   public abstract void fo(int var1, int var2, int var3, int var4, int var5, int var6, byte[] var7, int var8, int var9);

   public abstract ECI method5094();

   abstract void fv(int var1, int var2, int var3, int var4, int var5);

   abstract void fm(int var1, int var2, int var3, int var4, int var5);

   public abstract void ff(int var1, int var2, int var3, int var4, int var5);

   public abstract void fd(int var1, int var2, int var3, int var4, int var5);

   public abstract void ft(int var1, int var2, int var3, int var4, int var5);

   public abstract void fu(int var1, int var2, int var3, int var4, int var5);

   public abstract void fl(int var1, int var2, int var3, int var4, int var5);

   public abstract void method5095(OBI var1);

   public abstract void ed(int var1, int var2, int var3, int var4);

   public abstract void method5096(int var1, int var2, int var3, int var4, int var5, int var6, QJI var7, int var8, int var9);

   public abstract void method5097(int var1, int var2, int var3, int var4, int var5, int var6, QJI var7, int var8, int var9);

   public abstract void method5098(int var1, int var2, int var3, int var4, int var5, int var6, QJI var7, int var8, int var9, int var10, int var11, int var12);

   public abstract int method5099(int var1, int var2, int var3, int var4, int var5, int var6);

   public abstract int method5100(int var1, int var2, int var3, int var4, int var5, int var6);

   public abstract IBI method5101(RFI var1, boolean var2);

   public abstract VJI method5102(int var1);

   public abstract void method5103(VJI var1);

   public abstract IBI method5104(int var1, int var2, boolean var3, boolean var4);

   public abstract IBI method5105(int[] var1, int var2, int var3, int var4, int var5, boolean var6);

   public abstract IBI method5106(int[] var1, int var2, int var3, int var4, int var5, boolean var6);

   public abstract IBI method5107(RFI var1, boolean var2);

   public abstract IBI method5108(int var1, int var2, int var3, int var4, boolean var5);

   public abstract QJI method5109(int var1, int var2, int[] var3, int[] var4);

   public abstract QJI method5110(int var1, int var2, int[] var3, int[] var4);

   public abstract boolean method5111();

   public abstract void method5112();

   public abstract void gv(int var1, QJI var2, int var3, int var4);

   public abstract OS method5113(LZI var1, RFI[] var2, boolean var3);

   public abstract OS method5114(LZI var1, RFI[] var2, boolean var3);

   public abstract void method5115(int var1);

   public abstract UT method5116(MBI var1, int var2, int var3, int var4, int var5);

   abstract OCI method5117(Canvas var1, int var2, int var3);

   public abstract int method5118(int var1, int var2);

   public abstract boolean method5119();

   public abstract int method5120(int var1, int var2);

   public abstract YJI method5121(int var1, int var2, int[][] var3, int[][] var4, int var5, int var6, int var7);

   public abstract YJI method5122(int var1, int var2, int[][] var3, int[][] var4, int var5, int var6, int var7);

   public abstract YJI method5123(int var1, int var2, int[][] var3, int[][] var4, int var5, int var6, int var7);

   public abstract YF method5124();

   public abstract IBI method5125(RFI var1, boolean var2);

   public abstract int method5126(int var1, int var2);

   public abstract void B(int var1, int var2, int var3, int var4, int var5, int var6);

   public abstract boolean method5127();

   public abstract void r(int var1, int var2, int var3, int var4);

   public abstract void go(int var1, QJI var2, int var3, int var4);

   public abstract void method5128(XBI var1);

   public abstract void method5129(LF var1);

   public abstract void method5130(LF var1);

   public abstract void method5131(LF var1);

   public abstract void method5132(LF var1);

   public abstract void method5133(YF var1);

   public abstract void method5134(YF var1);

   public abstract int method5135(int var1, int var2, int var3, int var4, int var5, int var6);

   public void H(int var1) {
      try {
         keys[580915349 * this.KZ] = false;
         Enumeration var2 = this.NZ.keys();

         while(var2.hasMoreElements()) {
            Canvas var3 = (Canvas)var2.nextElement();
            OCI var4 = (OCI)this.NZ.get(var3);
            var4.method135();
         }

         this.method5023();
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ra.y(" + ')');
      }
   }

   public abstract void hg(int var1, float var2, float var3, float var4, float var5, float var6);

   public abstract void hb(int var1);

   public abstract void ec(boolean var1);

   public abstract void hu(float var1);

   public abstract void hn(int var1, int var2, int var3);

   public abstract void he(int var1, int var2, int var3);

   public abstract void method5137(boolean var1);

   public abstract ECI method5138();

   public abstract void method5139(int var1, int var2, float var3, int var4, int var5, float var6, int var7, int var8, float var9, int var10, int var11, int var12, int var13);

   public abstract OBI method5140(int var1, int var2, int var3, int var4, int var5, int var6);

   abstract void method5141();

   public abstract OBI method5142(OBI var1, OBI var2, float var3, OBI var4);

   public final void Z(ECI var1, byte var2) {
      try {
         if (929186669 * this.method582 >= 3) {
            throw new RuntimeException();
         } else {
            if (this.method582 * 929186669 >= 0) {
               this.method5019[929186669 * this.method582].method546();
            } else {
               this.MZ.method546();
            }

            this.HZ = this.method5019[(this.method582 += 1780694629) * 929186669] = var1;
            var1.method136();
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ra.af(" + ')');
      }
   }

   public abstract boolean method5144();

   public abstract void method5145();

   public abstract boolean method5146();

   final OCI K(int var1) {
      try {
         return this.MZ;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ra.ah(" + ')');
      }
   }

   public abstract boolean method5148();

   public abstract boolean method5149();

   abstract void method5150(float var1, float var2, float var3, float var4, float var5, float var6);

   final void I(Canvas var1, OCI var2, byte var3) {
      try {
         if (var2 == null) {
            throw new RuntimeException();
         } else {
            this.NZ.put(var1, var2);
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ra.al(" + ')');
      }
   }

   public void I(float var1, float var2, float var3, int var4) {
      try {
         this.method5188(var1, var2, var3, 0.0F, 1.0F, 1.0F);
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ra.ce(" + ')');
      }
   }

   public abstract void method5153();

   public abstract void method5154();

   public abstract void method5155(int var1, ADI var2);

   public abstract void method5156(int var1, ADI var2);

   public abstract void fb(int var1, int var2);

   public abstract void ih();

   public abstract void iv();

   public abstract void method5157(int var1, int var2, float var3, int var4, int var5, float var6, int var7, int var8, float var9, int var10, int var11, int var12, int var13);

   public abstract void method5158(int var1, int var2, float var3, int var4, int var5, float var6, int var7, int var8, float var9, int var10, int var11, int var12, int var13);

   public abstract boolean method5159();

   public abstract void method5160(float var1, float var2, float var3, float[] var4);

   public abstract void method5161(float var1, float var2, float var3, float[] var4);

   public abstract void method5162(float var1, float var2, float var3, float[] var4);

   public final void I(Canvas var1, int var2, int var3, int var4) {
      try {
         if (!this.NZ.containsKey(var1)) {
            IG.I((Canvas)var1, (short)32072);
            this.I(var1, this.method5006(var1, var2, var3), (byte)109);
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ra.ai(" + ')');
      }
   }

   public abstract void method5164(float var1, float var2, float var3, float[] var4);

   public abstract XAI method5165(int var1, int var2);

   public abstract boolean method5166();

   public abstract void method5167(int var1, int var2, int var3, int var4, int var5, int var6);

   public abstract void method5168(int var1, int var2, int var3, int var4, int var5, int var6, int var7);

   public abstract void method5169(int var1);

   public abstract int method5170(int var1, int var2);

   public abstract void ez(float var1, float var2);

   public abstract LF method5171();

   public abstract YF method5172();

   public final void I(Canvas var1, int var2, int var3, byte var4) {
      try {
         OCI var5 = (OCI)this.NZ.get(var1);
         if (var5 == null) {
            throw new RuntimeException();
         } else {
            var5.method582(var2, var3);
         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ra.ap(" + ')');
      }
   }

   public abstract void method5174(int var1);

   public abstract void method5175();

   public abstract void method5176();

   public abstract int method5177();

   public abstract LF method5178();

   public abstract OBI method5179(OBI var1, OBI var2, float var3, OBI var4);

   GSI(FEI var1) {
      this.LZ = var1;
      int var2 = -1;

      for(int var3 = 0; var3 < 8; ++var3) {
         if (!keys[var3]) {
            keys[var3] = true;
            var2 = var3;
            break;
         }
      }

      if (var2 == -1) {
         throw new IllegalStateException("");
      } else {
         this.KZ = var2 * -1656079683;
      }
   }

   public abstract boolean method5180();

   public abstract int[] aq(int var1, int var2, int var3, int var4);

   public abstract OBI method5181(int var1, int var2, int var3, int var4, int var5, int var6);

   public abstract void hj(int var1, int var2, int var3);

   public abstract void method5182(YF var1);

   public abstract LF method5183();

   public abstract void method5184(boolean var1);

   public abstract OBI method5185(int var1, int var2, int var3, int var4, int var5, int var6);

   protected void finalize() {
      try {
         this.H(1104723109);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "ra.finalize(" + ')');
      }
   }

   public abstract XAI method5186(int var1, int var2);

   public abstract void method5187(int var1, int var2, int var3, int var4);

   abstract void method5188(float var1, float var2, float var3, float var4, float var5, float var6);

   public abstract void method5189(OBI var1);

   public abstract void fi(int var1, int var2, int var3, int var4, int var5, int var6, byte[] var7, int var8, int var9);

   public abstract void IA(float var1);

   public abstract IBI method5190(int[] var1, int var2, int var3, int var4, int var5, boolean var6);

   static void L(int var0) {
      try {
         if (EFI.C != null) {
            WA.B = new EF();
            WA.B.I(-4360787748556788915L * VF.I, EFI.C.R.I(WO.U, -875414210), 360399239 * EFI.C.U, EFI.C, 180676280);
            JY.D = new Thread(WA.B, "");
            JY.D.start();
         }

      } catch (RuntimeException var2) {
         throw DQ.I(var2, "ra.f(" + ')');
      }
   }

   static void I(int var0, int var1, int var2, int var3, int var4, int var5, int var6, YK var7, OS var8, LZI var9, int var10, int var11, int var12) {
      try {
         if (var0 > var2 && var0 < var2 + var4 && var1 > var6 - var9.B * 1110385787 - 1 && var1 < var6 + -1883958527 * var9.I && var7.P) {
            var10 = var11;
         }

         int[] var13 = LO.I(var7, (byte)-16);
         String var14 = GDI.I(var7, 1974058841);
         if (var13 != null) {
            var14 = var14 + JF.I((int[])var13, (byte)1);
         }

         var8.I(var14, 3 + var2, var6, var10, 0, XEI.iI, TR.C * 1401020893, FX.s, GW.F, 65280);
         if (var7.Q) {
            ESI.F.I(var2 + 5 + var9.I(var14, 1318090489), var6 - 1110385787 * var9.B);
         }

      } catch (RuntimeException var15) {
         throw DQ.I(var15, "ra.an(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)22);
         X var4 = IU.F[var2 >> 16];
         OX.I(var3, var4, var0, -2057554129);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ra.kw(" + ')');
      }
   }

   static long I(CharSequence var0, byte var1) {
      try {
         long var2 = 0L;
         int var4 = var0.length();

         for(int var5 = 0; var5 < var4; ++var5) {
            var2 *= 37L;
            char var6 = var0.charAt(var5);
            if (var6 >= 'A' && var6 <= 'Z') {
               var2 += (long)(1 + var6 - 65);
            } else if (var6 >= 'a' && var6 <= 'z') {
               var2 += (long)(1 + var6 - 97);
            } else if (var6 >= '0' && var6 <= '9') {
               var2 += (long)(var6 + 27 - 48);
            }

            if (var2 >= 177917621779460413L) {
               if (var1 == 0) {
                  throw new IllegalStateException();
               }
               break;
            }
         }

         while(var2 % 37L == 0L && var2 != 0L) {
            var2 /= 37L;
         }

         return var2;
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "ra.a(" + ')');
      }
   }

   static void I(GSI var0, HSI var1, int var2, int var3, byte var4) {
      try {
         V var5 = var1.I(var0, 1502538903);
         if (var5 != null) {
            QJI var6 = var5.D;
            var0.r(var2, var3, -2093041337 * var1.g + var2, 457937409 * var1.o + var3);
            if (-2093041337 * var1.g != var5.I * 1633695381 || -60174999 * var5.Z != 457937409 * var1.o) {
               throw new IllegalStateException("");
            }

            if (2 != -64305285 * JN.C && 5 != JN.C * -64305285 && QT.I != null) {
               XP var7 = XEI.mI.I(681479919);
               int var8;
               int var9;
               int var10;
               int var11;
               if (2 == EE.V * -863531439) {
                  var8 = XEI.RZ * -2080858977;
                  var9 = 1818837461 * XEI.UZ;
                  var10 = (int)(-XEI.qD) & 16383;
                  var11 = 4096;
               } else {
                  SF var12 = UA.F.I().I;
                  var8 = (int)var12.I;
                  var9 = (int)var12.Z;
                  var10 = XEI.GC * 1227356013 + (int)(-XEI.qD) & 16383;
                  var11 = 4096 - 1412674352 * XEI.NZ;
               }

               int var22 = var8 / 128 + 48;
               int var13 = 48 + XEI.mI.C(789210081) * 4 - var9 / 128;
               QT.I.I((float)var2 + (float)(var1.g * -2093041337) / 2.0F, (float)var3 + (float)(457937409 * var1.o) / 2.0F, (float)var22, (float)var13, var11, var10 << 2, var6, var2, var3);
               JE var14 = XEI.mI.B(-337725639);

               int var16;
               int var17;
               int var18;
               int var19;
               int var20;
               for(OK var15 = (OK)JN.S.Z(1766612795); var15 != null; var15 = (OK)JN.S.B(49146)) {
                  var16 = var15.J * -774922497;
                  var17 = (var14.I[var16] >> 14 & 16383) - -1760580017 * var7.I;
                  var18 = (var14.I[var16] & 16383) - 283514611 * var7.Z;
                  var19 = 2 + 4 * var17 - var8 / 128;
                  var20 = 2 + 4 * var18 - var9 / 128;
                  TJ.I(var0, var6, var1, var2, var3, var19, var20, var14.C[var16], (byte)0);
               }

               int var23;
               for(var23 = 0; var23 < 1659101557 * JN.K; ++var23) {
                  var16 = 2 + JN.D[var23] * 4 - var8 / 128;
                  var17 = 2 + 4 * JN.F[var23] - var9 / 128;
                  KEI var25 = XEI.mI.E(2011176396).C(JN.J[var23]);
                  if (var25.C != null) {
                     var25 = var25.I((FAI)MI.E, (int)1042930561);
                     if (var25 == null) {
                        continue;
                     }

                     if (-1 == var25.z * -1422593103) {
                        if (var4 >= 10) {
                           return;
                        }
                        continue;
                     }
                  }

                  TJ.I(var0, var6, var1, var2, var3, var16, var17, var25.z * -1422593103, (byte)0);
               }

               for(BG var24 = (BG)XEI.LI.C(1742338274); var24 != null; var24 = (BG)XEI.LI.Z((byte)24)) {
                  var16 = (int)(var24.Z * 7051297995265073167L >> 28 & 3L);
                  if (var16 == JN.B * -1694437021) {
                     var17 = (int)(var24.Z * 7051297995265073167L & 16383L) - -1760580017 * var7.I;
                     var18 = (int)(var24.Z * 7051297995265073167L >> 14 & 16383L) - var7.Z * 283514611;
                     var19 = 2 + var17 * 4 - var8 / 128;
                     var20 = 2 + var18 * 4 - var9 / 128;
                     OX.I(var1, var6, var2, var3, var19, var20, UEI.S[0], (byte)16);
                  }
               }

               NV.I(var0, var8, var9, var1, var6, var2, var3, 826111295);
               DQ.I(var8, var9, var1, var6, var2, var3, 1913514572);
               DDI.I(var8, var9, var1, var5, var2, var3, -1636621855);
               if (2 != EE.V * -863531439) {
                  if (JN.A * 2076926079 != 0) {
                     var23 = -282230276 * JN.A + 2 - var8 / 128 + (UA.F.S() - 1) * 2;
                     var16 = 2 + JN.I * -1505214580 - var9 / 128 + (UA.F.S() - 1) * 2;
                     OX.I(var1, var6, var2, var3, var23, var16, IJ.C[JN.E ? 1 : 0], (byte)23);
                  }

                  if (!UA.F.mI) {
                     var0.I(var2 + -2093041337 * var1.g / 2 - 1, 457937409 * var1.o / 2 + var3 - 1, 3, 3, -1, (byte)7);
                  }
               }
            } else {
               var0.DA(-16777216, var6, var2, var3);
            }
         }

      } catch (RuntimeException var21) {
         throw DQ.I(var21, "ra.r(" + ')');
      }
   }
}
