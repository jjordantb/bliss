public class K {
   static int append = 20074;
   static int toString = 5030;
   static int I = 503;
   static long Z = 64425238954L;
   static int C = 12010;
   static int B = 5033;
   static int D = 2018;
   static float F = 1.1F;
   static int J = 10033;
   static int S = 1003;
   static int A = 101;
   static long E = 60129613779L;
   public static boolean G = false;
   public static boolean H = false;
   public static boolean K = false;
   public static int L;

   K() throws Throwable {
      throw new Error();
   }

   static final void I(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-80);
         X var4 = IU.F[var2 >> 16];
         UZ.I(var3, var4, var0, -2017048321);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "al.fw(" + ')');
      }
   }

   static final void I(OU var0, short var1) {
      try {
         var0.J -= -783761378;
         int var2 = var0.H[681479919 * var0.J];
         int var3 = var0.H[1 + var0.J * 681479919];
         DZI var4 = WFI.C.I(var3, 831421944);
         if (var4.I(1883696427)) {
            var0.S[(var0.A += 969361751) * -203050393 - 1] = WQ.K.I(var2, -1801093114).I(var3, var4.Z, (byte)-38);
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = WQ.K.I(var2, -183647434).I(var3, -388931549 * var4.I, 1379930702);
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "al.amg(" + ')');
      }
   }

   static int I(byte[] var0, int var1, int var2, int var3) {
      try {
         int var4 = -1;

         for(int var5 = var1; var5 < var2; ++var5) {
            var4 = var4 >>> 8 ^ REI.E[(var4 ^ var0[var5]) & 255];
         }

         var4 = ~var4;
         return var4;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "al.a(" + ')');
      }
   }

   static void I(int var0) {
      try {
         EDI.I = 0;
         SV.I = null;
         NH.V = null;
         EDI.S = null;
         EDI.H = null;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "al.v(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = EN.I != null ? -947282109 * EN.I.M : -1;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "al.aea(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = (int)(QJ.M * -536549149186981023L / 60000L);
         var0.H[(var0.J += -391880689) * 681479919 - 1] = (int)((QJ.M * -536549149186981023L - CI.I((byte)1) - OK.S * -7323824110069770829L) / 60000L);
         var0.H[(var0.J += -391880689) * 681479919 - 1] = RZI.D ? 1 : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "al.amh(" + ')');
      }
   }
}
