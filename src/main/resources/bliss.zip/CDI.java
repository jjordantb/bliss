import jaggl.OpenGL;

public class CDI implements VAI {
   int glFramebufferTexture2DEXT;
   FO I;

   public void u() {
   }

   public int a() {
      return this.I.A;
   }

   public int f() {
      return this.I.E;
   }

   public void method3(int var1) {
      OpenGL.glFramebufferTexture2DEXT(36160, var1, this.I.I, this.I.Z, this.glFramebufferTexture2DEXT);
   }

   public void b() {
   }

   public int p() {
      return this.I.A;
   }

   public int i() {
      return this.I.A;
   }

   public int k() {
      return this.I.E;
   }

   public void d() {
   }

   public void x() {
   }

   public void method2(int var1) {
      OpenGL.glFramebufferTexture2DEXT(36160, var1, this.I.I, this.I.Z, this.glFramebufferTexture2DEXT);
   }

   public void method1(int var1) {
      OpenGL.glFramebufferTexture2DEXT(36160, var1, this.I.I, this.I.Z, this.glFramebufferTexture2DEXT);
   }

   CDI(FO var1, int var2) {
      this.glFramebufferTexture2DEXT = var2;
      this.I = var1;
   }

   public void method4(int var1) {
      OpenGL.glFramebufferTexture2DEXT(36160, var1, this.I.I, this.I.Z, this.glFramebufferTexture2DEXT);
   }
}
