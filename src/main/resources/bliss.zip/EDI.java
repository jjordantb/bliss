public class EDI {
   static int I = 0;
   static KJ Z;
   static KJ C;
   static XE B;
   static PA D;
   static int F;
   static int append = 1;
   static int get = 2;
   static int toString = 3;
   static int J = 0;
   static KJ S;
   static int A;
   static int E;
   static KJ G;
   static XE H;

   EDI() throws Throwable {
      throw new Error();
   }

   public static String I(long var0, int var2, int var3) {
      try {
         PW.I(var0);
         int var4 = WII.I.get(5);
         int var5 = WII.I.get(2);
         int var6 = WII.I.get(1);
         return 3 == var2 ? OQ.I(var0, var2, (short)-6140) : Integer.toString(var4 / 10) + var4 % 10 + "-" + WII.Z[var2][var5] + "-" + var6;
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "de.a(" + ')');
      }
   }

   static byte I(int var0, int var1, byte var2) {
      try {
         if (-1976050083 * RW.D.V != var0) {
            return 0;
         } else {
            return (byte)((var1 & 1) == 0 ? 1 : 2);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "de.by(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, int var3) {
      try {
         var0.BZ = var2.H[(var2.J -= -391880689) * 681479919] * -978869921;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "de.jm(" + ')');
      }
   }

   public static final void I(IR var0, int var1, byte var2) {
      try {
         BFI.I(var0, var1, true, 229741614);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "de.jj(" + ')');
      }
   }

   static final void Z(HSI var0, X var1, OU var2, int var3) {
      try {
         var2.J -= -1567522756;
         var0.tZ = 730470451 * var2.H[var2.J * 681479919];
         var0.jI = var2.H[1 + var2.J * 681479919] * 792598437;
         var0.sI = 1652793977 * var2.H[2 + 681479919 * var2.J];
         var0.YI = var2.H[681479919 * var2.J + 3] * 1502440771;
         VEI.I(var0, -540239013);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "de.ex(" + ')');
      }
   }
}
