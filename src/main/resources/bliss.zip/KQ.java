public class KQ {
   public String I;
   public int Z;

   static final void I(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-11);
         X var4 = IU.F[var2 >> 16];
         MI.I(var3, var4, var0, -61919931);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "os.ho(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = TQ.a * -576042023;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "os.aha(" + ')');
      }
   }

   static void I(OU var0, int var1) {
      try {
         var0.S[(var0.A += 969361751) * -203050393 - 1] = OO.I.I(var0.H[(var0.J -= -391880689) * 681479919], 245040087).N;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "os.a(" + ')');
      }
   }

   static int I(int var0, int var1) {
      try {
         byte var2;
         if (var0 > 12010) {
            U.Z(976671472);
            var2 = 4;
         } else if (var0 > 5033) {
            MN.I((short)16862);
            var2 = 3;
         } else if (var0 > 2018) {
            VO.I(-476807021);
            var2 = 2;
         } else {
            XBI.I(true, -930644451);
            var2 = 1;
         }

         if (FW.J.d.I(-1158457222) != 2) {
            FW.J.I(FW.J.b, 2, 1051550423);
            WR.I(2, false, 622850291);
         } else {
            FW.J.I(FW.J.d, true, -1871094786);
         }

         JN.I(656179282);
         return var2;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "os.i(" + ')');
      }
   }
}
