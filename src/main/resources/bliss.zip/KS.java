import jaggl.OpenGL;

public class KS extends HS implements BEI {
   int arraycopy;
   int b;

   public int method84() {
      return this.arraycopy;
   }

   KS(OJI var1, int var2, int var3, boolean var4, int[] var5, int var6, int var7) {
      super(var1, 3553, YCI.Z, SDI.C, var2 * var3, var4);
      this.b = var2;
      this.arraycopy = var3;
      this.D.I((IEI)this);
      if (var4 && var7 == 0 && var6 == 0) {
         this.I(this.I, var2, var3, var5);
      } else {
         OpenGL.glPixelStorei(3314, var7);
         OpenGL.glTexImage2Di(this.I, 0, 6408, this.b, this.arraycopy, 0, 32993, this.D.SZ, var5, var6 * 4);
         OpenGL.glPixelStorei(3314, 0);
      }

   }

   KS(OJI var1, YCI var2, int var3, int var4, boolean var5, byte[] var6, int var7, int var8) {
      super(var1, 3553, var2, SDI.C, var3 * var4, var5);
      this.b = var3;
      this.arraycopy = var4;
      this.D.I((IEI)this);
      OpenGL.glPixelStorei(3317, 1);
      if (var5 && var8 == 0 && var7 == 0) {
         this.I(this.I, var3, var4, var6);
      } else {
         OpenGL.glPixelStorei(3314, var8);
         YCI var9 = this.C;
         YCI var10000 = this.C;
         if (var9 == YCI.S) {
            OpenGL.glCompressedTexImage2Dub(this.I, 0, 33777, var3, var4, 0, var3 * var4 / 2, var6, var7);
         } else {
            YCI var10 = this.C;
            var10000 = this.C;
            if (var10 == YCI.C) {
               OpenGL.glCompressedTexImage2Dub(this.I, 0, 33779, var3, var4, 0, var3 * var4, var6, var7);
            } else {
               OpenGL.glTexImage2Dub(this.I, 0, OJI.I(this.C, this.B), var3, var4, 0, OJI.I(this.C), 5121, var6, var7);
            }
         }

         OpenGL.glPixelStorei(3314, 0);
      }

      OpenGL.glPixelStorei(3317, 4);
   }

   public void method122(EB var1) {
      super.method122(var1);
   }

   public void method126() {
      super.method128();
   }

   public int method76() {
      return this.arraycopy;
   }

   public boolean method110() {
      return true;
   }

   public float method78(float var1) {
      return var1 / (float)this.arraycopy;
   }

   public boolean method79() {
      return true;
   }

   public void method104(int var1, int var2, int var3, int var4, byte[] var5, YCI var6, int var7, int var8) {
      this.D.I((IEI)this);
      OpenGL.glPixelStorei(3317, 1);
      OpenGL.glPixelStorei(3314, var8);
      OpenGL.glTexSubImage2Dub(this.I, 0, var1, var2, var3, var4, OJI.I(var6), 5121, var5, var7);
      OpenGL.glPixelStorei(3314, 0);
      OpenGL.glPixelStorei(3317, 4);
   }

   public int method86() {
      return this.b;
   }

   public void method82(int var1, int var2, int var3, int var4, byte[] var5, YCI var6, int var7, int var8) {
      this.D.I((IEI)this);
      OpenGL.glPixelStorei(3317, 1);
      OpenGL.glPixelStorei(3314, var8);
      OpenGL.glTexSubImage2Dub(this.I, 0, var1, var2, var3, var4, OJI.I(var6), 5121, var5, var7);
      OpenGL.glPixelStorei(3314, 0);
      OpenGL.glPixelStorei(3317, 4);
   }

   public void method81(int var1, int var2, int var3, int var4, int[] var5, int var6, int var7) {
      this.D.I((IEI)this);
      OpenGL.glPixelStorei(3314, var7);
      OpenGL.glTexSubImage2Di(this.I, 0, var1, var2, var3, var4, 32993, this.D.SZ, var5, var6);
      OpenGL.glPixelStorei(3314, 0);
   }

   public void method83(int var1, int var2, int var3, int var4, int[] var5, int var6) {
      int[] var7 = new int[this.b * this.arraycopy];
      this.D.I((IEI)this);
      OpenGL.glGetTexImagei(this.I, 0, 32993, 5121, var7, 0);

      for(int var8 = 0; var8 < var4; ++var8) {
         System.arraycopy(var7, (var2 + (var4 - 1) - var8) * this.b, var5, var6 + var8 * var3, var3);
      }

   }

   public TAI method117(int var1) {
      return new MJ(this, var1);
   }

   public boolean method85() {
      return true;
   }

   public void method125() {
      super.method128();
   }

   public TAI method121(int var1) {
      return new MJ(this, var1);
   }

   public void b() {
      super.b();
   }

   public void method93(int var1, int var2, int var3, int var4, int[] var5, int var6) {
      int[] var7 = new int[this.b * this.arraycopy];
      this.D.I((IEI)this);
      OpenGL.glGetTexImagei(this.I, 0, 32993, 5121, var7, 0);

      for(int var8 = 0; var8 < var4; ++var8) {
         System.arraycopy(var7, (var2 + (var4 - 1) - var8) * this.b, var5, var6 + var8 * var3, var3);
      }

   }

   public void u() {
      super.b();
   }

   public void x() {
      super.b();
   }

   public float method109(float var1) {
      return var1 / (float)this.arraycopy;
   }

   public int method75() {
      return this.arraycopy;
   }

   public void method102(int var1, int var2, int var3, int var4, int[] var5, int var6, int var7) {
      this.D.I((IEI)this);
      OpenGL.glPixelStorei(3314, var7);
      OpenGL.glTexSubImage2Di(this.I, 0, var1, var2, var3, var4, 32993, this.D.SZ, var5, var6);
      OpenGL.glPixelStorei(3314, 0);
   }

   public int method88() {
      return this.arraycopy;
   }

   public float method89(float var1) {
      return var1 / (float)this.b;
   }

   public float method90(float var1) {
      return var1 / (float)this.b;
   }

   public float method91(float var1) {
      return var1 / (float)this.b;
   }

   public float method105(float var1) {
      return var1 / (float)this.arraycopy;
   }

   public float method77(float var1) {
      return var1 / (float)this.b;
   }

   public float method94(float var1) {
      return var1 / (float)this.arraycopy;
   }

   public void d() {
      super.b();
   }

   public void method96(boolean var1, boolean var2) {
      this.D.I((IEI)this);
      OpenGL.glTexParameteri(this.I, 10242, var1 ? 10497 : '脯');
      OpenGL.glTexParameteri(this.I, 10243, var2 ? 10497 : '脯');
   }

   public void method97(boolean var1, boolean var2) {
      this.D.I((IEI)this);
      OpenGL.glTexParameteri(this.I, 10242, var1 ? 10497 : '脯');
      OpenGL.glTexParameteri(this.I, 10243, var2 ? 10497 : '脯');
   }

   public void method98(boolean var1, boolean var2) {
      this.D.I((IEI)this);
      OpenGL.glTexParameteri(this.I, 10242, var1 ? 10497 : '脯');
      OpenGL.glTexParameteri(this.I, 10243, var2 ? 10497 : '脯');
   }

   public void method106(boolean var1, boolean var2) {
      this.D.I((IEI)this);
      OpenGL.glTexParameteri(this.I, 10242, var1 ? 10497 : '脯');
      OpenGL.glTexParameteri(this.I, 10243, var2 ? 10497 : '脯');
   }

   public void method99(boolean var1, boolean var2) {
      this.D.I((IEI)this);
      OpenGL.glTexParameteri(this.I, 10242, var1 ? 10497 : '脯');
      OpenGL.glTexParameteri(this.I, 10243, var2 ? 10497 : '脯');
   }

   public void method101(int var1, int var2, int var3, int var4, int[] var5, int var6, int var7) {
      this.D.I((IEI)this);
      OpenGL.glPixelStorei(3314, var7);
      OpenGL.glTexSubImage2Di(this.I, 0, var1, var2, var3, var4, 32993, this.D.SZ, var5, var6);
      OpenGL.glPixelStorei(3314, 0);
   }

   public void method129(EB var1) {
      super.method122(var1);
   }

   public void method127(EB var1) {
      super.method122(var1);
   }

   KS(OJI var1, YCI var2, SDI var3, int var4, int var5) {
      super(var1, 3553, var2, var3, var4 * var5, false);
      this.b = var4;
      this.arraycopy = var5;
      this.D.I((IEI)this);
      OpenGL.glTexImage2Dub(this.I, 0, OJI.I(this.C, this.B), var4, var5, 0, OJI.I(this.C), OJI.I(this.B), (byte[])null, 0);
   }

   public void method87(int var1, int var2, int var3, int var4, byte[] var5, YCI var6, int var7, int var8) {
      this.D.I((IEI)this);
      OpenGL.glPixelStorei(3317, 1);
      OpenGL.glPixelStorei(3314, var8);
      OpenGL.glTexSubImage2Dub(this.I, 0, var1, var2, var3, var4, OJI.I(var6), 5121, var5, var7);
      OpenGL.glPixelStorei(3314, 0);
      OpenGL.glPixelStorei(3317, 4);
   }

   public void method80(boolean var1, boolean var2) {
      this.D.I((IEI)this);
      OpenGL.glTexParameteri(this.I, 10242, var1 ? 10497 : '脯');
      OpenGL.glTexParameteri(this.I, 10243, var2 ? 10497 : '脯');
   }

   public void method107(int var1, int var2, int var3, int var4, int[] var5, int var6) {
      int[] var7 = new int[this.b * this.arraycopy];
      this.D.I((IEI)this);
      OpenGL.glGetTexImagei(this.I, 0, 32993, 5121, var7, 0);

      for(int var8 = 0; var8 < var4; ++var8) {
         System.arraycopy(var7, (var2 + (var4 - 1) - var8) * this.b, var5, var6 + var8 * var3, var3);
      }

   }

   public boolean method108() {
      return super.Z();
   }

   public boolean method111() {
      return super.Z();
   }

   public float method95(float var1) {
      return var1 / (float)this.arraycopy;
   }

   void I(int var1, int var2, int var3, int var4, float[] var5, YCI var6, int var7, int var8) {
      this.D.I((IEI)this);
      OpenGL.glPixelStorei(3314, var8);
      OpenGL.glTexSubImage2Df(this.I, 0, var1, var2, var3, var4, OJI.I(var6), 5121, var5, var7);
      OpenGL.glPixelStorei(3314, 0);
   }

   public void method123() {
      super.method128();
   }

   public void method128() {
      super.method128();
   }

   public void method124(EB var1) {
      super.method122(var1);
   }

   public void method100(int var1, int var2, int var3, int var4, byte[] var5, YCI var6, int var7, int var8) {
      this.D.I((IEI)this);
      OpenGL.glPixelStorei(3317, 1);
      OpenGL.glPixelStorei(3314, var8);
      OpenGL.glTexSubImage2Dub(this.I, 0, var1, var2, var3, var4, OJI.I(var6), 5121, var5, var7);
      OpenGL.glPixelStorei(3314, 0);
      OpenGL.glPixelStorei(3317, 4);
   }

   public TAI method120(int var1) {
      return new MJ(this, var1);
   }

   public TAI method119(int var1) {
      return new MJ(this, var1);
   }

   public TAI method118(int var1) {
      return new MJ(this, var1);
   }

   KS(OJI var1, YCI var2, int var3, int var4, boolean var5, float[] var6, int var7, int var8) {
      super(var1, 3553, var2, SDI.F, var3 * var4, var5);
      this.b = var3;
      this.arraycopy = var4;
      this.D.I((IEI)this);
      if (var5 && var8 == 0 && var7 == 0) {
         this.I(this.I, var3, var4, var6);
      } else {
         OpenGL.glPixelStorei(3314, var8);
         OpenGL.glTexImage2Df(this.I, 0, OJI.I(this.C, this.B), var3, var4, 0, OJI.I(this.C), 5126, var6, var7 * 4);
         OpenGL.glPixelStorei(3314, 0);
      }

   }

   public boolean Z() {
      return super.Z();
   }

   public int method92() {
      return this.b;
   }
}
