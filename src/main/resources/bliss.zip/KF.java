public class KF implements JAI {
   String append;
   boolean length;
   static int I;

   public int method256(int var1) {
      try {
         if (this.length) {
            return 100;
         } else {
            int var2 = MFI.D.I(this.append, 637615919);
            if (var2 >= 0 && var2 <= 100) {
               return var2;
            } else {
               this.length = true;
               return 100;
            }
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jh.a(" + ')');
      }
   }

   public HY method260(int var1) {
      try {
         return HY.Z;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jh.f(" + ')');
      }
   }

   public HY method261() {
      return HY.Z;
   }

   public int method258() {
      if (this.length) {
         return 100;
      } else {
         int var1 = MFI.D.I(this.append, 963304472);
         if (var1 >= 0 && var1 <= 100) {
            return var1;
         } else {
            this.length = true;
            return 100;
         }
      }
   }

   public HY method259() {
      return HY.Z;
   }

   public HY method257() {
      return HY.Z;
   }

   KF(String var1) {
      this.append = var1;
   }

   boolean I(int var1) {
      try {
         return this.length;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jh.d(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         String var2 = (String)var0.S[(var0.A -= 969361751) * -203050393];
         if (XEI.QC * 1806357379 != 0 || (!XEI.TC || XEI.UC) && !XEI.HC) {
            String var3 = var2.toLowerCase();
            byte var4 = 0;
            if (var3.startsWith(VEI.oZ.I(XW.I, -875414210))) {
               var4 = 0;
               var2 = var2.substring(VEI.oZ.I(XW.I, -875414210).length());
            } else if (var3.startsWith(VEI.ZZ.I(XW.I, -875414210))) {
               var4 = 1;
               var2 = var2.substring(VEI.ZZ.I(XW.I, -875414210).length());
            } else if (var3.startsWith(VEI.qZ.I(XW.I, -875414210))) {
               var4 = 2;
               var2 = var2.substring(VEI.qZ.I(XW.I, -875414210).length());
            } else if (var3.startsWith(VEI.LZ.I(XW.I, -875414210))) {
               var4 = 3;
               var2 = var2.substring(VEI.LZ.I(XW.I, -875414210).length());
            } else if (var3.startsWith(VEI.tZ.I(XW.I, -875414210))) {
               var4 = 4;
               var2 = var2.substring(VEI.tZ.I(XW.I, -875414210).length());
            } else if (var3.startsWith(VEI.G.I(XW.I, -875414210))) {
               var4 = 5;
               var2 = var2.substring(VEI.G.I(XW.I, -875414210).length());
            } else if (var3.startsWith(VEI.Y.I(XW.I, -875414210))) {
               var4 = 6;
               var2 = var2.substring(VEI.Y.I(XW.I, -875414210).length());
            } else if (var3.startsWith(VEI.JZ.I(XW.I, -875414210))) {
               var4 = 7;
               var2 = var2.substring(VEI.JZ.I(XW.I, -875414210).length());
            } else if (var3.startsWith(VEI.T.I(XW.I, -875414210))) {
               var4 = 8;
               var2 = var2.substring(VEI.T.I(XW.I, -875414210).length());
            } else if (var3.startsWith(VEI.yZ.I(XW.I, -875414210))) {
               var4 = 9;
               var2 = var2.substring(VEI.yZ.I(XW.I, -875414210).length());
            } else if (var3.startsWith(VEI.IC.I(XW.I, -875414210))) {
               var4 = 10;
               var2 = var2.substring(VEI.IC.I(XW.I, -875414210).length());
            } else if (var3.startsWith(VEI.ZC.I(XW.I, -875414210))) {
               var4 = 11;
               var2 = var2.substring(VEI.ZC.I(XW.I, -875414210).length());
            } else if (WO.U != XW.I) {
               if (var3.startsWith(VEI.oZ.I(WO.U, -875414210))) {
                  var4 = 0;
                  var2 = var2.substring(VEI.oZ.I(WO.U, -875414210).length());
               } else if (var3.startsWith(VEI.ZZ.I(WO.U, -875414210))) {
                  var4 = 1;
                  var2 = var2.substring(VEI.ZZ.I(WO.U, -875414210).length());
               } else if (var3.startsWith(VEI.qZ.I(WO.U, -875414210))) {
                  var4 = 2;
                  var2 = var2.substring(VEI.qZ.I(WO.U, -875414210).length());
               } else if (var3.startsWith(VEI.LZ.I(WO.U, -875414210))) {
                  var4 = 3;
                  var2 = var2.substring(VEI.LZ.I(WO.U, -875414210).length());
               } else if (var3.startsWith(VEI.tZ.I(WO.U, -875414210))) {
                  var4 = 4;
                  var2 = var2.substring(VEI.tZ.I(WO.U, -875414210).length());
               } else if (var3.startsWith(VEI.G.I(WO.U, -875414210))) {
                  var4 = 5;
                  var2 = var2.substring(VEI.G.I(WO.U, -875414210).length());
               } else if (var3.startsWith(VEI.Y.I(WO.U, -875414210))) {
                  var4 = 6;
                  var2 = var2.substring(VEI.Y.I(WO.U, -875414210).length());
               } else if (var3.startsWith(VEI.JZ.I(WO.U, -875414210))) {
                  var4 = 7;
                  var2 = var2.substring(VEI.JZ.I(WO.U, -875414210).length());
               } else if (var3.startsWith(VEI.T.I(WO.U, -875414210))) {
                  var4 = 8;
                  var2 = var2.substring(VEI.T.I(WO.U, -875414210).length());
               } else if (var3.startsWith(VEI.yZ.I(WO.U, -875414210))) {
                  var4 = 9;
                  var2 = var2.substring(VEI.yZ.I(WO.U, -875414210).length());
               } else if (var3.startsWith(VEI.IC.I(WO.U, -875414210))) {
                  var4 = 10;
                  var2 = var2.substring(VEI.IC.I(WO.U, -875414210).length());
               } else if (var3.startsWith(VEI.ZC.I(WO.U, -875414210))) {
                  var4 = 11;
                  var2 = var2.substring(VEI.ZC.I(WO.U, -875414210).length());
               }
            }

            var3 = var2.toLowerCase();
            byte var5 = 0;
            if (var3.startsWith(VEI.pI.I(XW.I, -875414210))) {
               var5 = 1;
               var2 = var2.substring(VEI.pI.I(XW.I, -875414210).length());
            } else if (var3.startsWith(VEI.RI.I(XW.I, -875414210))) {
               var5 = 2;
               var2 = var2.substring(VEI.RI.I(XW.I, -875414210).length());
            } else if (var3.startsWith(VEI.d.I(XW.I, -875414210))) {
               var5 = 3;
               var2 = var2.substring(VEI.d.I(XW.I, -875414210).length());
            } else if (var3.startsWith(VEI.FC.I(XW.I, -875414210))) {
               var5 = 4;
               var2 = var2.substring(VEI.FC.I(XW.I, -875414210).length());
            } else if (var3.startsWith(VEI.JC.I(XW.I, -875414210))) {
               var5 = 5;
               var2 = var2.substring(VEI.JC.I(XW.I, -875414210).length());
            } else if (XW.I != WO.U) {
               if (var3.startsWith(VEI.pI.I(WO.U, -875414210))) {
                  var5 = 1;
                  var2 = var2.substring(VEI.pI.I(WO.U, -875414210).length());
               } else if (var3.startsWith(VEI.RI.I(WO.U, -875414210))) {
                  var5 = 2;
                  var2 = var2.substring(VEI.RI.I(WO.U, -875414210).length());
               } else if (var3.startsWith(VEI.d.I(WO.U, -875414210))) {
                  var5 = 3;
                  var2 = var2.substring(VEI.d.I(WO.U, -875414210).length());
               } else if (var3.startsWith(VEI.FC.I(WO.U, -875414210))) {
                  var5 = 4;
                  var2 = var2.substring(VEI.FC.I(WO.U, -875414210).length());
               } else if (var3.startsWith(VEI.JC.I(WO.U, -875414210))) {
                  var5 = 5;
                  var2 = var2.substring(VEI.JC.I(WO.U, -875414210).length());
               }
            }

            VJ var6 = XW.I((short)512);
            PK var7 = GB.I(MEI.ZI, var6.Z, (byte)107);
            var7.J.F(0);
            int var8 = 385051775 * var7.J.A;
            var7.J.F(var4);
            var7.J.F(var5);
            UF.I(var7.J, var2, 1526854691);
            var7.J.A(var7.J.A * 385051775 - var8, (byte)-57);
            var6.I(var7, (byte)-12);
         }

      } catch (RuntimeException var9) {
         throw DQ.I(var9, "jh.abt(" + ')');
      }
   }

   public static QZ I(REI var0, int var1) {
      try {
         int var2 = var0.H((byte)-17);
         return new QZ(var2);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jh.a(" + ')');
      }
   }

   public static void Z(int var0) {
      try {
         if (XFI.I(-81173133)) {
            LX.I((DAI)(new PT()), (byte)0);
         }

      } catch (RuntimeException var2) {
         throw DQ.I(var2, "jh.a(" + ')');
      }
   }
}
