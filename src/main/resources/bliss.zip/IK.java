public class IK extends YG {
   int Q = 0;
   static int R = 0;
   static int T = 4096;
   int U = -1593028608;

   void Z(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.Q = var2.C() * 1298582163;
         break;
      case 1:
         this.U = var2.C() * 2091520197;
      }

   }

   int[] Z(int var1, int var2) {
      try {
         int[] var3 = this.P.I(var1, -15447091);
         if (this.P.D) {
            int[] var4 = this.I(0, var1, -1887337990);

            for(int var5 = 0; var5 < -1474554145 * WJ.C; ++var5) {
               int var6 = var4[var5];
               var3[var5] = var6 >= this.Q * 1295115163 && var6 <= 1628368397 * this.U ? 4096 : 0;
            }
         }

         return var3;
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "ahu.i(" + ')');
      }
   }

   public IK() {
      super(1, true);
   }

   int[] append(int var1) {
      int[] var2 = this.P.I(var1, 1989709916);
      if (this.P.D) {
         int[] var3 = this.I(0, var1, -1887337990);

         for(int var4 = 0; var4 < -1474554145 * WJ.C; ++var4) {
            int var5 = var3[var4];
            var2[var4] = var5 >= this.Q * 1295115163 && var5 <= 1628368397 * this.U ? 4096 : 0;
         }
      }

      return var2;
   }

   int[] toString(int var1) {
      int[] var2 = this.P.I(var1, 1976104707);
      if (this.P.D) {
         int[] var3 = this.I(0, var1, -1887337990);

         for(int var4 = 0; var4 < -1474554145 * WJ.C; ++var4) {
            int var5 = var3[var4];
            var2[var4] = var5 >= this.Q * 1295115163 && var5 <= 1628368397 * this.U ? 4096 : 0;
         }
      }

      return var2;
   }

   void I(int var1, REI var2, byte var3) {
      try {
         switch(var1) {
         case 0:
            this.Q = var2.C() * 1298582163;
            break;
         case 1:
            this.U = var2.C() * 2091520197;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ahu.r(" + ')');
      }
   }

   void append(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.Q = var2.C() * 1298582163;
         break;
      case 1:
         this.U = var2.C() * 2091520197;
      }

   }

   static final void Z(OU var0, byte var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = NW.S ? 1 : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ahu.us(" + ')');
      }
   }

   public static void I(String[] var0, int[] var1, int var2) {
      try {
         UQ.I(var0, var1, 0, var0.length - 1, 31286072);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ahu.b(" + ')');
      }
   }
}
