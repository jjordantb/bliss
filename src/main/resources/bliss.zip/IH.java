public class IH extends YG {
   int sqrt = -1384673280;
   static int Q = 4096;

   void I(int var1, REI var2, byte var3) {
      try {
         if (var1 == 0) {
            this.sqrt = var2.C() * 1334499193;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "agb.r(" + ')');
      }
   }

   int[] append(int var1) {
      int[] var2 = this.P.I(var1, 750969634);
      if (this.P.D) {
         int[] var3 = this.I(0, var1 - 1 & -289063255 * WJ.F, -1887337990);
         int[] var4 = this.I(0, var1, -1887337990);
         int[] var5 = this.I(0, var1 + 1 & WJ.F * -289063255, -1887337990);

         for(int var6 = 0; var6 < -1474554145 * WJ.C; ++var6) {
            int var7 = 585425609 * this.sqrt * (var5[var6] - var3[var6]);
            int var8 = 585425609 * this.sqrt * (var4[var6 + 1 & WJ.I * -901777799] - var4[var6 - 1 & -901777799 * WJ.I]);
            int var9 = var8 >> 12;
            int var10 = var7 >> 12;
            int var11 = var9 * var9 >> 12;
            int var12 = var10 * var10 >> 12;
            int var13 = (int)(Math.sqrt((double)((float)(var11 + var12 + 4096) / 4096.0F)) * 4096.0D);
            int var14 = var13 != 0 ? 16777216 / var13 : 0;
            var2[var6] = 4096 - var14;
         }
      }

      return var2;
   }

   public IH() {
      super(1, true);
   }

   int[] sqrt(int var1) {
      int[] var2 = this.P.I(var1, 287257269);
      if (this.P.D) {
         int[] var3 = this.I(0, var1 - 1 & -289063255 * WJ.F, -1887337990);
         int[] var4 = this.I(0, var1, -1887337990);
         int[] var5 = this.I(0, var1 + 1 & WJ.F * -289063255, -1887337990);

         for(int var6 = 0; var6 < -1474554145 * WJ.C; ++var6) {
            int var7 = 585425609 * this.sqrt * (var5[var6] - var3[var6]);
            int var8 = 585425609 * this.sqrt * (var4[var6 + 1 & WJ.I * -901777799] - var4[var6 - 1 & -901777799 * WJ.I]);
            int var9 = var8 >> 12;
            int var10 = var7 >> 12;
            int var11 = var9 * var9 >> 12;
            int var12 = var10 * var10 >> 12;
            int var13 = (int)(Math.sqrt((double)((float)(var11 + var12 + 4096) / 4096.0F)) * 4096.0D);
            int var14 = var13 != 0 ? 16777216 / var13 : 0;
            var2[var6] = 4096 - var14;
         }
      }

      return var2;
   }

   int[] Z(int var1, int var2) {
      try {
         int[] var3 = this.P.I(var1, 377633232);
         if (this.P.D) {
            int[] var4 = this.I(0, var1 - 1 & -289063255 * WJ.F, -1887337990);
            int[] var5 = this.I(0, var1, -1887337990);
            int[] var6 = this.I(0, var1 + 1 & WJ.F * -289063255, -1887337990);

            for(int var7 = 0; var7 < -1474554145 * WJ.C; ++var7) {
               int var8 = 585425609 * this.sqrt * (var6[var7] - var4[var7]);
               int var9 = 585425609 * this.sqrt * (var5[var7 + 1 & WJ.I * -901777799] - var5[var7 - 1 & -901777799 * WJ.I]);
               int var10 = var9 >> 12;
               int var11 = var8 >> 12;
               int var12 = var10 * var10 >> 12;
               int var13 = var11 * var11 >> 12;
               int var14 = (int)(Math.sqrt((double)((float)(var12 + var13 + 4096) / 4096.0F)) * 4096.0D);
               int var15 = var14 != 0 ? 16777216 / var14 : 0;
               var3[var7] = 4096 - var15;
            }
         }

         return var3;
      } catch (RuntimeException var16) {
         throw DQ.I(var16, "agb.i(" + ')');
      }
   }

   void toString(int var1, REI var2) {
      if (var1 == 0) {
         this.sqrt = var2.C() * 1334499193;
      }

   }

   void Z(int var1, REI var2) {
      if (var1 == 0) {
         this.sqrt = var2.C() * 1334499193;
      }

   }
}
