public class GEI extends SSI {
   int[] PA = new int[6];
   public int hI = -1312461425;
   public int kI = -2139727009;
   public FZI lI;
   public int mI = -230300471;
   public int nI = 55499771;
   public int oI = 312753929;
   int[] RA = new int[6];
   public String pI;
   public BDI qI = new BDI(32);
   int ia;
   public int rI;
   public HEI tI;
   int method4432;
   int method4739;
   int method4787;

   final void method4388(GSI var1, IR var2, int var3, int var4, int var5, boolean var6) {
      throw new IllegalStateException();
   }

   void EA(int var1) {
      try {
         this.ia = (32 + (int)(Math.random() * 4.0D)) * -1382184985;
         this.method4432 = (3 + (int)(Math.random() * 2.0D)) * -1827850421;
         this.method4739 = (16 + (int)(Math.random() * 3.0D)) * -1891288283;
         if (FW.J.P.C(2100839354) == 1) {
            this.method4787 = (int)(Math.random() * 6.0D) * 818502475;
         } else {
            this.method4787 = (int)(Math.random() * 12.0D) * 818502475;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ake.gf(" + ')');
      }
   }

   void method4373(GSI var1) {
      if (this.tI != null && (this.jI || this.F(var1, 0, 498700808))) {
         LF var2 = var1.method5178();
         var2.I(this.J());
         var2.C(0.0F, -5.0F, 0.0F);
         this.I(var1, this.l, var2, this.jI, 1604637699);

         for(int var3 = 0; var3 < this.l.length; ++var3) {
            this.l[var3] = null;
         }
      }

   }

   public HP method4358(GSI var1, byte var2) {
      return null;
   }

   KP method4394(GSI var1, int var2) {
      try {
         if (this.tI != null && this.F(var1, 526336, -1241441124)) {
            LF var3 = this.J();
            ZJ var4 = this.I();
            LF var5 = var1.method5178();
            int var6 = this.n.I((byte)0);
            BP var7 = this.H.E[this.K][(int)var4.I.I >> 9][(int)var4.I.Z >> 9];
            if (var7 != null && var7.J != null) {
               int var8 = this.iI * -661498661 - var7.J.O;
               this.iI = (int)((float)(-661498661 * this.iI) - (float)var8 / 10.0F) * 1394444115;
            } else {
               this.iI = (int)((float)(-661498661 * this.iI) - (float)(this.iI * -661498661) / 10.0F) * 1394444115;
            }

            var5.I(var3);
            var5.C(0.0F, (float)(-20 - this.iI * -661498661), 0.0F);
            EQ var15 = this.C(1744135386);
            HEI var9 = this.tI.ZI != null ? this.tI.I((FAI)MI.E, 1631739764) : this.tI;
            this.sI = false;
            KP var10 = null;
            if (FW.J.T.Z(-1104068428) == 1 && var9.d && var15.r) {
               SX var11 = this.e.I((byte)-29) && this.e.C(-65534) ? this.e : null;
               SX var12 = !this.a.I((byte)-63) || this.y && var11 != null ? null : this.a;
               UT var13 = OA.I(var1, var6, this.CI * -155466425, -197572281 * this.d, -104151209 * this.f, -2095128707 * this.tI.II, this.l[0], this.tI.DI & '\uffff', this.tI.U & '\uffff', this.tI.j & 255, this.tI.T & 255, var12 != null ? var12 : var11, 1812843484);
               if (var13 != null) {
                  if (this.N == null || this.N.length < this.l.length + 1) {
                     this.I(this.l.length + 1, 1538315389);
                  }

                  var10 = BDI.I(this.RA(1869849139), 1879615126);
                  this.sI = true;
                  var1.RA(false);
                  var13.method4739(var5, this.N[this.l.length], 0);
                  var1.RA(true);
               }
            }

            if (this.N == null || this.N.length < this.l.length) {
               this.I(this.l.length, -241324715);
            }

            if (var10 == null) {
               var10 = BDI.I(this.RA(1869849139), 1797748717);
            }

            this.I(var1, this.l, var5, false, 879327846);

            int var16;
            for(var16 = 0; var16 < this.l.length; ++var16) {
               if (this.l[var16] != null) {
                  if (this.tI.JI) {
                     this.l[var16].PA(this.ia * 1611045847, 1427249763 * this.method4432, this.method4739 * 376465581, this.method4787 * 332650083);
                  }

                  this.l[var16].method4739(var5, this.N[var16], 0);
               }
            }

            if (this.Y != null) {
               XBI var17 = this.Y.D();
               var1.method5042(var17);
            }

            for(var16 = 0; var16 < this.l.length; ++var16) {
               if (this.l[var16] != null) {
                  this.sI |= this.l[var16].i();
               }

               this.l[var16] = null;
            }

            this.X = XEI.nZ * -815465993;
            return var10;
         } else {
            return null;
         }
      } catch (RuntimeException var14) {
         throw DQ.I(var14, "ake.bo(" + ')');
      }
   }

   boolean F(GSI var1, int var2, int var3) {
      try {
         int var4 = var2;
         EQ var5 = this.C(979705538);
         SX var6 = this.e.I((byte)-97) && !this.e.C(-65534) ? this.e : null;
         SX var7 = !this.a.I((byte)-121) || this.y && var6 != null ? null : this.a;
         int var8 = 250567115 * var5.X;
         int var9 = 1110265995 * var5.Y;
         if (var8 != 0 || var9 != 0 || var5.h * 1185872679 != 0 || -330229359 * var5.m != 0) {
            var2 |= 7;
         }

         boolean var10 = this.aI != 0 && 443738891 * XEI.kB >= this.GI * 1920148979 && XEI.kB * 443738891 < this.HI * 1953154657;
         if (var10) {
            var2 |= 524288;
         }

         int var11 = this.n.I((byte)0);
         UT var12 = this.l[0] = this.tI.I(var1, var2, YFI.F, MI.E, var6, var7, this.OI, this.o, var11, this.lI, this.method4432(-1491129226), false, -679459424);
         if (var12 == null) {
            return false;
         } else {
            this.t = var12.YA() * -49760597;
            var12.n();
            this.I(var12, 839093609);
            if (var8 == 0 && var9 == 0) {
               this.I(var11, this.S() << 9, this.S() << 9, 0, 0, 1757570363);
            } else {
               this.I(var11, var8, var9, -947990311 * var5.W, 1869548445 * var5.b, 1232740545);
               if (this.CI * -155466425 != 0) {
                  this.l[0].t(this.CI * -155466425);
               }

               if (this.d * -197572281 != 0) {
                  this.l[0].EA(-197572281 * this.d);
               }

               if (this.f * -104151209 != 0) {
                  this.l[0].ia(0, this.f * -104151209, 0);
               }
            }

            if (var10) {
               var12.PA(this.UI, this.KI, this.LI, this.aI & 255);
            }

            this.I(var1, var5, var4, var8, var9, var11, 614564932);
            return true;
         }
      } catch (RuntimeException var13) {
         throw DQ.I(var13, "ake.gx(" + ')');
      }
   }

   void method4357(GSI var1, int var2) {
      try {
         if (this.tI != null && (this.jI || this.F(var1, 0, -1205291751))) {
            LF var3 = var1.method5178();
            var3.I(this.J());
            var3.C(0.0F, -5.0F, 0.0F);
            this.I(var1, this.l, var3, this.jI, 1317836884);

            for(int var4 = 0; var4 < this.l.length; ++var4) {
               this.l[var4] = null;
            }
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ake.bb(" + ')');
      }
   }

   public final void I(JA var1, int var2, short var3) {
      try {
         int var4 = this.YI[0];
         int var5 = this.v[0];
         switch(var1.D * 495490839) {
         case 0:
            ++var4;
            --var5;
            break;
         case 1:
            --var4;
            break;
         case 2:
            --var5;
            break;
         case 3:
            ++var4;
            ++var5;
            break;
         case 4:
            --var4;
            ++var5;
            break;
         case 5:
            --var4;
            --var5;
            break;
         case 6:
            ++var4;
            break;
         case 7:
            ++var5;
         }

         if (this.e.I((byte)-128) && this.e.I(1057375366).T * -882531177 == 1) {
            this.x = null;
            this.e.I(-1, (int)-1581174742);
         }

         int var6;
         for(var6 = 0; var6 < this.s.length; ++var6) {
            if (this.s[var6].C * -967533709 != -1) {
               GU var7 = GC.S.I(-967533709 * this.s[var6].C, -1708083255);
               if (var7.B && var7.Z * 1505778629 != -1 && GZI.C.I(var7.Z * 1505778629, (byte)-23).T * -882531177 == 1) {
                  this.s[var6].Z.I(-1, (int)-1871121711);
                  this.s[var6].C = -1313669563;
               }
            }
         }

         if (this.XI * 2050671733 < this.YI.length - 1) {
            this.XI += -1013322787;
         }

         for(var6 = 2050671733 * this.XI; var6 > 0; --var6) {
            this.YI[var6] = this.YI[var6 - 1];
            this.v[var6] = this.v[var6 - 1];
            this.MI[var6] = this.MI[var6 - 1];
         }

         this.YI[0] = var4;
         this.v[0] = var5;
         this.MI[0] = (byte)var2;
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "ake.gk(" + ')');
      }
   }

   public void I(int var1, int var2, int var3, boolean var4, int var5, byte var6) {
      try {
         this.K = this.L = (byte)var1;
         if (XEI.mI.M(1132456995).I(var2, var3, 1587070733)) {
            ++this.L;
         }

         if (this.e.I((byte)-33) && this.e.I(1592092831).T * -882531177 == 1) {
            this.x = null;
            this.e.I(-1, (int)-1899534119);
         }

         int var7;
         for(var7 = 0; var7 < this.s.length; ++var7) {
            if (-1 != this.s[var7].C * -967533709) {
               GU var8 = GC.S.I(-967533709 * this.s[var7].C, -1738473272);
               if (var8.B && -1 != 1505778629 * var8.Z && GZI.C.I(var8.Z * 1505778629, (byte)83).T * -882531177 == 1) {
                  this.s[var7].Z.I(-1, (int)-1950379754);
                  this.s[var7].C = -1313669563;
               }
            }
         }

         if (!var4) {
            var7 = var2 - this.YI[0];
            int var12 = var3 - this.v[0];
            if (var7 >= -8 && var7 <= 8 && var12 >= -8 && var12 <= 8) {
               if (2050671733 * this.XI < this.YI.length - 1) {
                  this.XI += -1013322787;
               }

               for(int var9 = this.XI * 2050671733; var9 > 0; --var9) {
                  this.YI[var9] = this.YI[var9 - 1];
                  this.v[var9] = this.v[var9 - 1];
                  this.MI[var9] = this.MI[var9 - 1];
               }

               this.YI[0] = var2;
               this.v[0] = var3;
               this.MI[0] = NA.I.C;
               return;
            }
         }

         this.XI = 0;
         this.bI = 0;
         this.cI = 0;
         this.YI[0] = var2;
         this.v[0] = var3;
         SF var11 = SF.I(this.I().I);
         var11.I = (float)((var5 << 8) + (this.YI[0] << 9));
         var11.Z = (float)((this.v[0] << 9) + (var5 << 8));
         this.I(var11);
         var11.I();
         if (this.Y != null) {
            this.Y.I();
         }

      } catch (RuntimeException var10) {
         throw DQ.I(var10, "ake.gr(" + ')');
      }
   }

   public final boolean D(int var1) {
      try {
         return this.tI != null;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ake.gy(" + ')');
      }
   }

   int method4432(int var1) {
      try {
         if (-1 != -1317338937 * this.oI) {
            return this.oI * -1317338937;
         } else {
            if (this.tI.ZI != null) {
               HEI var2 = this.tI.I((FAI)MI.E, 1794284929);
               if (var2 != null && 525312939 * var2.A != -1) {
                  return 525312939 * var2.A;
               }
            }

            return this.tI.A * 525312939;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ake.t(" + ')');
      }
   }

   public int method4427(byte var1) {
      try {
         if (this.tI.ZI != null) {
            HEI var2 = this.tI.I((FAI)MI.E, 1605369279);
            if (var2 != null && -1 != 363729791 * var2.p) {
               return 363729791 * var2.p;
            }
         }

         return 363729791 * this.tI.p;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ake.h(" + ')');
      }
   }

   int PA() {
      return this.tI == null ? 0 : this.tI.FI * -226722581;
   }

   boolean RA(int var1) {
      try {
         return this.tI.c;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ake.gu(" + ')');
      }
   }

   int I(byte var1) {
      try {
         return this.tI == null ? 0 : this.tI.FI * -226722581;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ake.dh(" + ')');
      }
   }

   boolean method4350(GSI var1, int var2, int var3, byte var4) {
      try {
         if (this.tI != null && this.F(var1, 131072, -1046532898)) {
            LF var5 = this.J();
            boolean var6 = false;

            int var7;
            for(var7 = 0; var7 < this.l.length; ++var7) {
               if (this.l[var7] != null) {
                  boolean var8;
                  label66: {
                     if (-226722581 * this.tI.FI <= 0) {
                        label65: {
                           if (286060383 * this.tI.CI == -1) {
                              if (1 == this.tI.II * -2095128707) {
                                 if (var4 != 1) {
                                    throw new IllegalStateException();
                                 }
                                 break label65;
                              }
                           } else if (1 == this.tI.CI * 286060383) {
                              break label65;
                           }

                           var8 = false;
                           break label66;
                        }
                     }

                     var8 = true;
                  }

                  boolean var10 = this.l[var7].method4787(var2, var3, var5, var8, this.tI.FI * -226722581);
                  if (var10) {
                     var6 = true;
                     break;
                  }
               }
            }

            for(var7 = 0; var7 < this.l.length; ++var7) {
               this.l[var7] = null;
            }

            return var6;
         } else {
            return false;
         }
      } catch (RuntimeException var11) {
         throw DQ.I(var11, "ake.bu(" + ')');
      }
   }

   final void method4398(byte var1) {
      try {
         throw new IllegalStateException();
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ake.bq(" + ')');
      }
   }

   public void I(int var1, int var2, int var3, int var4) {
      try {
         this.PA[var1] = var2;
         this.RA[var1] = var3;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ake.gz(" + ')');
      }
   }

   public boolean method4429(byte var1) {
      try {
         return JX.J.E;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ake.by(" + ')');
      }
   }

   public KBI method4437(int var1) {
      try {
         return this.VI != null && this.VI.Z == null ? null : this.VI;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ake.bl(" + ')');
      }
   }

   public void I(String var1, int var2, int var3, int var4) {
      try {
         int var5 = AFI.I((byte)6) * JX.J.F * -478874963;
         this.I(var1, var2, var3, var5, (byte)-1);
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ake.gd(" + ')');
      }
   }

   public HP method4367(GSI var1) {
      return null;
   }

   public HP method4368(GSI var1) {
      return null;
   }

   public int A() {
      if (this.tI.ZI != null) {
         HEI var1 = this.tI.I((FAI)MI.E, 1815832117);
         if (var1 != null && var1.K * -1575020259 != -1) {
            return var1.K * -1575020259;
         }
      }

      return -1575020259 * this.tI.K != -1 ? -1575020259 * this.tI.K : super.Z((byte)-104);
   }

   public int E() {
      if (this.tI.ZI != null) {
         HEI var1 = this.tI.I((FAI)MI.E, 1928445532);
         if (var1 != null && var1.K * -1575020259 != -1) {
            return var1.K * -1575020259;
         }
      }

      return -1575020259 * this.tI.K != -1 ? -1575020259 * this.tI.K : super.Z((byte)-11);
   }

   KP method4370(GSI var1) {
      if (this.tI != null && this.F(var1, 526336, -1153791486)) {
         LF var2 = this.J();
         ZJ var3 = this.I();
         LF var4 = var1.method5178();
         int var5 = this.n.I((byte)0);
         BP var6 = this.H.E[this.K][(int)var3.I.I >> 9][(int)var3.I.Z >> 9];
         if (var6 != null && var6.J != null) {
            int var7 = this.iI * -661498661 - var6.J.O;
            this.iI = (int)((float)(-661498661 * this.iI) - (float)var7 / 10.0F) * 1394444115;
         } else {
            this.iI = (int)((float)(-661498661 * this.iI) - (float)(this.iI * -661498661) / 10.0F) * 1394444115;
         }

         var4.I(var2);
         var4.C(0.0F, (float)(-20 - this.iI * -661498661), 0.0F);
         EQ var13 = this.C(1676580874);
         HEI var8 = this.tI.ZI != null ? this.tI.I((FAI)MI.E, 1779938932) : this.tI;
         this.sI = false;
         KP var9 = null;
         if (FW.J.T.Z(-1718454976) == 1 && var8.d && var13.r) {
            SX var10 = this.e.I((byte)-38) && this.e.C(-65534) ? this.e : null;
            SX var11 = !this.a.I((byte)-86) || this.y && var10 != null ? null : this.a;
            UT var12 = OA.I(var1, var5, this.CI * -155466425, -197572281 * this.d, -104151209 * this.f, -2095128707 * this.tI.II, this.l[0], this.tI.DI & '\uffff', this.tI.U & '\uffff', this.tI.j & 255, this.tI.T & 255, var11 != null ? var11 : var10, 1812843484);
            if (var12 != null) {
               if (this.N == null || this.N.length < this.l.length + 1) {
                  this.I(this.l.length + 1, -565315916);
               }

               var9 = BDI.I(this.RA(1869849139), 1346320693);
               this.sI = true;
               var1.RA(false);
               var12.method4739(var4, this.N[this.l.length], 0);
               var1.RA(true);
            }
         }

         if (this.N == null || this.N.length < this.l.length) {
            this.I(this.l.length, -1743332566);
         }

         if (var9 == null) {
            var9 = BDI.I(this.RA(1869849139), 1675644085);
         }

         this.I(var1, this.l, var4, false, 969483486);

         int var14;
         for(var14 = 0; var14 < this.l.length; ++var14) {
            if (this.l[var14] != null) {
               if (this.tI.JI) {
                  this.l[var14].PA(this.ia * 1611045847, 1427249763 * this.method4432, this.method4739 * 376465581, this.method4787 * 332650083);
               }

               this.l[var14].method4739(var4, this.N[var14], 0);
            }
         }

         if (this.Y != null) {
            XBI var15 = this.Y.D();
            var1.method5042(var15);
         }

         for(var14 = 0; var14 < this.l.length; ++var14) {
            if (this.l[var14] != null) {
               this.sI |= this.l[var14].i();
            }

            this.l[var14] = null;
         }

         this.X = XEI.nZ * -815465993;
         return var9;
      } else {
         return null;
      }
   }

   void method4371(GSI var1) {
      if (this.tI != null && (this.jI || this.F(var1, 0, -1590633829))) {
         LF var2 = var1.method5178();
         var2.I(this.J());
         var2.C(0.0F, -5.0F, 0.0F);
         this.I(var1, this.l, var2, this.jI, -935143388);

         for(int var3 = 0; var3 < this.l.length; ++var3) {
            this.l[var3] = null;
         }
      }

   }

   final boolean method4386() {
      return false;
   }

   boolean method4372(GSI var1, int var2, int var3) {
      if (this.tI != null && this.F(var1, 131072, 1720809223)) {
         LF var4 = this.J();
         boolean var5 = false;

         int var6;
         for(var6 = 0; var6 < this.l.length; ++var6) {
            if (this.l[var6] != null) {
               boolean var7;
               label57: {
                  if (-226722581 * this.tI.FI <= 0) {
                     label56: {
                        if (286060383 * this.tI.CI == -1) {
                           if (1 == this.tI.II * -2095128707) {
                              break label56;
                           }
                        } else if (1 == this.tI.CI * 286060383) {
                           break label56;
                        }

                        var7 = false;
                        break label57;
                     }
                  }

                  var7 = true;
               }

               boolean var9 = this.l[var6].method4787(var2, var3, var4, var7, this.tI.FI * -226722581);
               if (var9) {
                  var5 = true;
                  break;
               }
            }
         }

         for(var6 = 0; var6 < this.l.length; ++var6) {
            this.l[var6] = null;
         }

         return var5;
      } else {
         return false;
      }
   }

   boolean method4385(GSI var1, int var2, int var3) {
      if (this.tI != null && this.F(var1, 131072, -1030471484)) {
         LF var4 = this.J();
         boolean var5 = false;

         int var6;
         for(var6 = 0; var6 < this.l.length; ++var6) {
            if (this.l[var6] != null) {
               boolean var7;
               label57: {
                  if (-226722581 * this.tI.FI <= 0) {
                     label56: {
                        if (286060383 * this.tI.CI == -1) {
                           if (1 == this.tI.II * -2095128707) {
                              break label56;
                           }
                        } else if (1 == this.tI.CI * 286060383) {
                           break label56;
                        }

                        var7 = false;
                        break label57;
                     }
                  }

                  var7 = true;
               }

               boolean var9 = this.l[var6].method4787(var2, var3, var4, var7, this.tI.FI * -226722581);
               if (var9) {
                  var5 = true;
                  break;
               }
            }
         }

         for(var6 = 0; var6 < this.l.length; ++var6) {
            this.l[var6] = null;
         }

         return var5;
      } else {
         return false;
      }
   }

   public int B(int var1, int var2) {
      try {
         return this.PA[var1];
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ake.gh(" + ')');
      }
   }

   int method4447() {
      if (-1 != -1317338937 * this.oI) {
         return this.oI * -1317338937;
      } else {
         if (this.tI.ZI != null) {
            HEI var1 = this.tI.I((FAI)MI.E, 1618298715);
            if (var1 != null && 525312939 * var1.A != -1) {
               return 525312939 * var1.A;
            }
         }

         return this.tI.A * 525312939;
      }
   }

   final void method4377() {
      throw new IllegalStateException();
   }

   final void method4378() {
      throw new IllegalStateException();
   }

   int method4446() {
      if (-1 != -1317338937 * this.oI) {
         return this.oI * -1317338937;
      } else {
         if (this.tI.ZI != null) {
            HEI var1 = this.tI.I((FAI)MI.E, 1807692721);
            if (var1 != null && 525312939 * var1.A != -1) {
               return 525312939 * var1.A;
            }
         }

         return this.tI.A * 525312939;
      }
   }

   final boolean method4366(int var1) {
      return false;
   }

   int method4438() {
      if (-1 != -1317338937 * this.oI) {
         return this.oI * -1317338937;
      } else {
         if (this.tI.ZI != null) {
            HEI var1 = this.tI.I((FAI)MI.E, 1685758496);
            if (var1 != null && 525312939 * var1.A != -1) {
               return 525312939 * var1.A;
            }
         }

         return this.tI.A * 525312939;
      }
   }

   int method4448() {
      if (-1 != -1317338937 * this.oI) {
         return this.oI * -1317338937;
      } else {
         if (this.tI.ZI != null) {
            HEI var1 = this.tI.I((FAI)MI.E, 1859138308);
            if (var1 != null && 525312939 * var1.A != -1) {
               return 525312939 * var1.A;
            }
         }

         return this.tI.A * 525312939;
      }
   }

   public int method4449() {
      if (this.tI.ZI != null) {
         HEI var1 = this.tI.I((FAI)MI.E, 1923690826);
         if (var1 != null && -1 != 363729791 * var1.p) {
            return 363729791 * var1.p;
         }
      }

      return 363729791 * this.tI.p;
   }

   public KBI method4443() {
      return this.VI != null && this.VI.Z == null ? null : this.VI;
   }

   final boolean method4384() {
      return false;
   }

   final boolean method4400() {
      return false;
   }

   public GEI(AP var1, int var2) {
      super(var1, var2);
      this.EA(684373346);
   }

   final boolean method4387() {
      return false;
   }

   public int Z(byte var1) {
      try {
         if (this.tI.ZI != null) {
            HEI var2 = this.tI.I((FAI)MI.E, 1652651645);
            if (var2 != null && var2.K * -1575020259 != -1) {
               return var2.K * -1575020259;
            }
         }

         return -1575020259 * this.tI.K != -1 ? -1575020259 * this.tI.K : super.Z((byte)61);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ake.bx(" + ')');
      }
   }

   int append() {
      return this.tI == null ? 0 : this.tI.FI * -226722581;
   }

   public void I(HEI var1, int var2) {
      try {
         if (var1 != this.tI && FX.G && ICI.Z(this.W * 1888274983, 351851633)) {
            ID.I(2025307040);
         }

         this.tI = var1;
         if (this.tI != null) {
            this.pI = this.tI.B;
            this.rI = this.tI.Q * 1520279523;
         }

         if (this.Y != null) {
            this.Y.I();
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ake.gb(" + ')');
      }
   }

   public boolean method4452() {
      return JX.J.E;
   }

   final void method4355(GSI var1, IR var2, int var3, int var4, int var5, boolean var6, int var7) {
      try {
         throw new IllegalStateException();
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "ake.bk(" + ')');
      }
   }

   int i() {
      return this.tI == null ? 0 : this.tI.FI * -226722581;
   }

   public GEI(AP var1) {
      super(var1);
      this.EA(684373346);
   }

   public boolean method4440() {
      return JX.J.E;
   }

   final void method4375(GSI var1, IR var2, int var3, int var4, int var5, boolean var6) {
      throw new IllegalStateException();
   }

   public int Z(int var1, byte var2) {
      try {
         return this.RA[var1];
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ake.ga(" + ')');
      }
   }

   boolean method4352(GSI var1, int var2, int var3) {
      if (this.tI != null && this.F(var1, 131072, 76578294)) {
         LF var4 = this.J();
         boolean var5 = false;

         int var6;
         for(var6 = 0; var6 < this.l.length; ++var6) {
            if (this.l[var6] != null) {
               boolean var7;
               label57: {
                  if (-226722581 * this.tI.FI <= 0) {
                     label56: {
                        if (286060383 * this.tI.CI == -1) {
                           if (1 == this.tI.II * -2095128707) {
                              break label56;
                           }
                        } else if (1 == this.tI.CI * 286060383) {
                           break label56;
                        }

                        var7 = false;
                        break label57;
                     }
                  }

                  var7 = true;
               }

               boolean var9 = this.l[var6].method4787(var2, var3, var4, var7, this.tI.FI * -226722581);
               if (var9) {
                  var5 = true;
                  break;
               }
            }
         }

         for(var6 = 0; var6 < this.l.length; ++var6) {
            this.l[var6] = null;
         }

         return var5;
      } else {
         return false;
      }
   }
}
