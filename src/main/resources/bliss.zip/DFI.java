public class DFI extends LDI {
   int B;
   static int F = 1;
   int append;
   int toString;
   static int Z = 0;
   int C;
   int D;
   int J;
   int S;
   int A;
   int E;
   int G;
   int H;
   int K;
   int L;
   static int M;

   boolean B() {
      GU var1 = GC.S.I(1632084697 * this.D, -1743709088);
      boolean var2 = var1.I((byte)119);
      BU var3 = GZI.C.I(var1.Z * 1505778629, (byte)-66);
      var2 &= var3.I(1883883362);
      return var2;
   }

   DFI(REI var1, int var2, int var3) {
      super(var1);
      int var4;
      if (var2 == 0) {
         var4 = var1.H((byte)-14);
         this.B = (var4 >>> 16) * -46611099;
         this.C = 415557701 * (var4 & '\uffff');
         this.toString = 425099019;
      } else {
         this.B = 46611099;
         this.C = -415557701;
         this.toString = var1.C() * -425099019;
      }

      if (var3 == 0) {
         var4 = var1.H((byte)26);
         this.G = 1611083453 * (var4 >>> 16);
         this.A = (var4 & '\uffff') * -1666710765;
         this.J = -514357691;
      } else {
         this.G = -1611083453;
         this.A = 1666710765;
         this.J = var1.C() * 514357691;
      }

      if (var2 == 0 && var3 == 0) {
         this.S = var1.I() * -776341541;
      } else {
         this.S = 776341541;
      }

      this.D = var1.C() * 587513193;
      this.L = var1.I() * -479097679;
      this.E = var1.I() * -666257507;
      this.append = var1.B((byte)75) * 856962157;
      this.K = var1.C() * 1304794705;
      this.H = var1.I() * -757238655;
   }

   boolean Z(int var1) {
      try {
         GU var2 = GC.S.I(1632084697 * this.D, -1845152840);
         boolean var3 = var2.I((byte)118);
         BU var4 = GZI.C.I(var2.Z * 1505778629, (byte)-64);
         var3 &= var4.I(1376129821);
         return var3;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "yu.p(" + ')');
      }
   }

   public void method868() {
      int var1;
      int var2;
      int var3;
      if (227468397 * this.B >= 0) {
         var1 = 256 + this.B * 499702272;
         var2 = 256 + this.C * 869603840;
         var3 = this.S * -356438957;
      } else {
         SSI var4 = PFI.C[this.toString * -153670819].I(1193612238);
         SF var5 = var4.I().I;
         var1 = (int)var5.I;
         var2 = (int)var5.Z;
         var3 = var4.K;
      }

      int var8;
      int var9;
      if (916056717 * this.C >= 0) {
         var8 = this.G * -679925248 + 256;
         var9 = 1149122048 * this.A + 256;
      } else {
         SSI var6 = PFI.C[this.J * -1629854861].I(143521447);
         SF var7 = var6.I().I;
         var8 = (int)var7.I;
         var9 = (int)var7.Z;
         if (var3 < 0) {
            var3 = var6.K;
         }
      }

      int var10 = this.H * 1745275777 << 2;
      CR var11 = new CR(XEI.mI.T(-1611682495), this.D * 1632084697, var3, var3, var1, var2, this.L * 266943569 << 2, XEI.kB * 443738891, 929559909 * this.append + XEI.kB * 443738891, -1300008271 * this.K, var10, this.toString * -153670819 + 1, 1 + -1629854861 * this.J, this.E * 172590773 << 2, false, 0);
      var11.I(var8, var9, 172590773 * this.E << 2, XEI.kB * 443738891 + 929559909 * this.append, -414343918);
      XEI.sC.I((AE)(new JL(var11)), (int)1292621740);
   }

   public void method869() {
      int var1;
      int var2;
      int var3;
      if (227468397 * this.B >= 0) {
         var1 = 256 + this.B * 499702272;
         var2 = 256 + this.C * 869603840;
         var3 = this.S * -356438957;
      } else {
         SSI var4 = PFI.C[this.toString * -153670819].I(1656183484);
         SF var5 = var4.I().I;
         var1 = (int)var5.I;
         var2 = (int)var5.Z;
         var3 = var4.K;
      }

      int var8;
      int var9;
      if (916056717 * this.C >= 0) {
         var8 = this.G * -679925248 + 256;
         var9 = 1149122048 * this.A + 256;
      } else {
         SSI var6 = PFI.C[this.J * -1629854861].I(43837883);
         SF var7 = var6.I().I;
         var8 = (int)var7.I;
         var9 = (int)var7.Z;
         if (var3 < 0) {
            var3 = var6.K;
         }
      }

      int var10 = this.H * 1745275777 << 2;
      CR var11 = new CR(XEI.mI.T(-1611682495), this.D * 1632084697, var3, var3, var1, var2, this.L * 266943569 << 2, XEI.kB * 443738891, 929559909 * this.append + XEI.kB * 443738891, -1300008271 * this.K, var10, this.toString * -153670819 + 1, 1 + -1629854861 * this.J, this.E * 172590773 << 2, false, 0);
      var11.I(var8, var9, 172590773 * this.E << 2, XEI.kB * 443738891 + 929559909 * this.append, 1238518641);
      XEI.sC.I((AE)(new JL(var11)), (int)489461607);
   }

   public void method866(int var1) {
      try {
         int var2;
         int var3;
         int var4;
         if (227468397 * this.B >= 0) {
            var2 = 256 + this.B * 499702272;
            var3 = 256 + this.C * 869603840;
            var4 = this.S * -356438957;
         } else {
            SSI var5 = PFI.C[this.toString * -153670819].I(1024446891);
            SF var6 = var5.I().I;
            var2 = (int)var6.I;
            var3 = (int)var6.Z;
            var4 = var5.K;
         }

         int var10;
         int var11;
         if (916056717 * this.C >= 0) {
            var10 = this.G * -679925248 + 256;
            var11 = 1149122048 * this.A + 256;
         } else {
            SSI var7 = PFI.C[this.J * -1629854861].I(1821624579);
            SF var8 = var7.I().I;
            var10 = (int)var8.I;
            var11 = (int)var8.Z;
            if (var4 < 0) {
               var4 = var7.K;
            }
         }

         int var12 = this.H * 1745275777 << 2;
         CR var13 = new CR(XEI.mI.T(-1611682495), this.D * 1632084697, var4, var4, var2, var3, this.L * 266943569 << 2, XEI.kB * 443738891, 929559909 * this.append + XEI.kB * 443738891, -1300008271 * this.K, var12, this.toString * -153670819 + 1, 1 + -1629854861 * this.J, this.E * 172590773 << 2, false, 0);
         var13.I(var10, var11, 172590773 * this.E << 2, XEI.kB * 443738891 + 929559909 * this.append, 1057769456);
         XEI.sC.I((AE)(new JL(var13)), (int)-428713736);
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "yu.f(" + ')');
      }
   }

   static final void I(int[] var0, int var1, int var2, int var3, int var4) {
      try {
         --var1;
         --var2;

         for(int var5 = var2 - 7; var1 < var5; var0[var1] = var3) {
            ++var1;
            var0[var1] = var3;
            ++var1;
            var0[var1] = var3;
            ++var1;
            var0[var1] = var3;
            ++var1;
            var0[var1] = var3;
            ++var1;
            var0[var1] = var3;
            ++var1;
            var0[var1] = var3;
            ++var1;
            var0[var1] = var3;
            ++var1;
         }

         while(var1 <= var2) {
            ++var1;
            var0[var1] = var3;
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "yu.b(" + ')');
      }
   }
}
