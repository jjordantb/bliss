import java.io.IOException;
import java.net.Socket;

public abstract class LII {
   int I;
   String Z;
   static int C;

   Socket I(int var1) throws IOException {
      try {
         return new Socket(this.Z, 98195689 * this.I);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "tv.b(" + ')');
      }
   }

   public abstract Socket method6111(int var1) throws IOException;

   public abstract Socket method6112() throws IOException;

   static final void I(short var0) {
      try {
         QEI var1 = XEI.eI.C;

         for(int var2 = 0; var2 < XEI.PC * -976358333; ++var2) {
            int var3 = XEI.dI[var2];
            GEI var4 = (GEI)((QG)XEI.UI.I((long)var3)).J;
            int var5 = var1.I();
            if ((var5 & 2) != 0) {
               var5 += var1.I() << 8;
            }

            if ((var5 & '耀') != 0) {
               var5 += var1.I() << 16;
            }

            if ((var5 & 65536) != 0) {
               var5 += var1.I() << 24;
            }

            if ((var5 & 32) != 0) {
               var4.I(var1.E(68173648), 0, 0, 973412325);
            }

            if ((var5 & 16) != 0) {
               var4.u = var1.P(1478539457) * 283914955;
               if (65535 == var4.u * 1433412323) {
                  var4.u = -283914955;
               }
            }

            if ((var5 & 524288) != 0) {
               var4.UI = var1.M(507762157);
               var4.KI = var1.M(-666954662);
               var4.LI = var1.L(-154305803);
               var4.aI = (byte)var1.K(-1014855659);
               var4.GI = (XEI.kB * 443738891 + var1.P(1478539457)) * 1828453179;
               var4.HI = (XEI.kB * 443738891 + var1.P(1478539457)) * -473408095;
            }

            if ((var5 & 128) != 0) {
               var4.hI = var1.O(-1091754982) * 1312461425;
               var4.kI = var1.P(1478539457) * 2139727009;
            }

            int var7;
            if ((var5 & 8) != 0) {
               int[] var6 = new int[FCI.I((byte)-124).length];

               for(var7 = 0; var7 < FCI.I((byte)-5).length; ++var7) {
                  var6[var7] = var1.Y(1235052657);
               }

               var7 = var1.I();
               ZX.I(var4, var6, var7, true, (byte)108);
            }

            if ((var5 & 512) != 0) {
               var4.oI = var1.J((byte)-68) * -312753929;
               if (-1317338937 * var4.oI == 65535) {
                  var4.oI = 312753929;
               }
            }

            int[] var8;
            int var9;
            int var10;
            int var11;
            int var16;
            int[] var17;
            if ((var5 & 8192) != 0) {
               var16 = var1.K(-1014855659);
               var17 = new int[var16];
               var8 = new int[var16];

               for(var9 = 0; var9 < var16; ++var9) {
                  var10 = var1.C();
                  if ((var10 & '쀀') == 49152) {
                     var11 = var1.J((byte)11);
                     var17[var9] = var10 << 16 | var11;
                  } else {
                     var17[var9] = var10;
                  }

                  var8[var9] = var1.C();
               }

               var4.I(var17, var8, 2082086484);
            }

            int var12;
            int var13;
            int var18;
            if ((var5 & 4) != 0) {
               var16 = var1.C((short)-3904);
               if (var16 > 0) {
                  for(var7 = 0; var7 < var16; ++var7) {
                     var18 = -1;
                     var9 = -1;
                     var10 = -1;
                     var11 = var1.B(1723054621);
                     if (var11 == 32767) {
                        var11 = var1.B(1723054621);
                        var9 = var1.B(1723054621);
                        var18 = var1.B(1723054621);
                        var10 = var1.B(1723054621);
                     } else if (32766 != var11) {
                        var9 = var1.B(1723054621);
                     } else {
                        var11 = -1;
                     }

                     var12 = var1.B(1723054621);
                     var13 = var1.K(-1014855659);
                     var4.I(var11, var9, var18, var10, XEI.kB * 443738891, var12, var13, (byte)6);
                  }
               }
            }

            int[] var19;
            short[] var21;
            short[] var23;
            long var24;
            if ((var5 & 4096) != 0) {
               var16 = var4.tI.F.length;
               var7 = 0;
               if (var4.tI.E != null) {
                  var7 = var4.tI.E.length;
               }

               var18 = 0;
               if (var4.tI.V != null) {
                  var18 = var4.tI.V.length;
               }

               var9 = var1.I();
               if (1 == (var9 & 1)) {
                  var4.lI = null;
               } else {
                  var19 = null;
                  if ((var9 & 2) == 2) {
                     var19 = new int[var16];

                     for(var11 = 0; var11 < var16; ++var11) {
                        var19[var11] = var1.Y(1235052657);
                     }
                  }

                  var23 = null;
                  if (4 == (var9 & 4)) {
                     var23 = new short[var7];

                     for(var12 = 0; var12 < var7; ++var12) {
                        var23[var12] = (short)var1.C();
                     }
                  }

                  var21 = null;
                  if ((var9 & 8) == 8) {
                     var21 = new short[var18];

                     for(var13 = 0; var13 < var18; ++var13) {
                        var21[var13] = (short)var1.C();
                     }
                  }

                  var24 = (long)var3 | (long)((var4.mI += -230300471) * -156273287 - 1) << 32;
                  var4.lI = new FZI(var24, var19, var23, var21);
               }
            }

            boolean var25;
            if ((var5 & 33554432) != 0) {
               var16 = var1.O(1014024931);
               var7 = var1.H((byte)-18);
               if (var16 == 65535) {
                  var16 = -1;
               }

               var18 = var1.K(-1014855659);
               var9 = var18 & 7;
               var10 = var18 >> 3 & 15;
               if (var10 == 15) {
                  var10 = -1;
               }

               var25 = (var18 >> 7 & 1) == 1;
               var4.I(var16, var7, var9, var10, var25, 3, 1962048388);
            }

            if ((var5 & 64) != 0) {
               var16 = var1.P(1478539457);
               var7 = var1.U(-416273786);
               if (var16 == 65535) {
                  var16 = -1;
               }

               var18 = var1.F((byte)76);
               var9 = var18 & 7;
               var10 = var18 >> 3 & 15;
               if (15 == var10) {
                  var10 = -1;
               }

               var25 = 1 == (var18 >> 7 & 1);
               var4.I(var16, var7, var9, var10, var25, 0, 2031478624);
            }

            if ((var5 & 256) != 0) {
               var16 = var1.O(1324789017);
               var7 = var1.R(-2017462427);
               if (65535 == var16) {
                  var16 = -1;
               }

               var18 = var1.C((short)-19864);
               var9 = var18 & 7;
               var10 = var18 >> 3 & 15;
               if (var10 == 15) {
                  var10 = -1;
               }

               var25 = 1 == (var18 >> 7 & 1);
               var4.I(var16, var7, var9, var10, var25, 1, -774185979);
            }

            if ((var5 & 16384) != 0) {
               var16 = var1.C((short)-15927);
               var17 = new int[var16];
               var8 = new int[var16];
               int[] var20 = new int[var16];

               for(var10 = 0; var10 < var16; ++var10) {
                  var11 = var1.Y(1235052657);
                  var17[var10] = var11;
                  var8[var10] = var1.C((short)-8275);
                  var20[var10] = var1.J((byte)48);
               }

               HL.I(var4, var17, var8, var20, 1644064563);
            }

            if ((var5 & 1024) != 0) {
               var16 = var1.P(1478539457);
               var4.r = var1.I() * 918505277;
               var4.ZI = var1.F((byte)19) * -494980103;
               var4.WI = (var16 & '耀') != 0;
               var4.q = (var16 & 32767) * -257621575;
               var4.p = var4.r * 1195117671 + XEI.kB * 1208636921 + -1132907677 * var4.q;
            }

            if ((var5 & 1048576) != 0) {
               var4.qI.I((byte)-105);
               var16 = var1.S[(var1.A += 116413311) * 385051775 - 1] & 255;

               for(var7 = 0; var7 < var16; ++var7) {
                  var18 = var1.C();
                  var9 = var1.G((byte)67);
                  var4.qI.I(var18, var9, 304714746);
               }
            }

            if ((var5 & 2048) != 0) {
               var4.BI = var1.M(1984951178) * 1925713613;
               var4.FI = var1.S(-12558881) * 516351707;
               var4.DI = var1.L(736826018) * 1712047767;
               var4.JI = var1.L(1643626542) * 2089924823;
               var4.II = (var1.J((byte)-54) + 443738891 * XEI.kB) * 996079737;
               var4.AI = (var1.P(1478539457) + XEI.kB * 443738891) * 1000906529;
               var4.EI = var1.O(-1999232161) * 1386670945;
               var4.BI += var4.YI[0] * 1925713613;
               var4.FI += var4.v[0] * 516351707;
               var4.DI += var4.YI[0] * 1712047767;
               var4.JI += var4.v[0] * 2089924823;
               var4.XI = -1013322787;
               var4.bI = 0;
            }

            if ((var5 & 4194304) != 0) {
               var16 = var1.S[(var1.A += 116413311) * 385051775 - 1] & 255;

               for(var7 = 0; var7 < var16; ++var7) {
                  var18 = var1.C((short)-28984);
                  var9 = var1.H((byte)38);
                  var10 = var1.A((byte)8);
                  var4.I(var18, var9, var10, -783761378);
               }
            }

            if ((var5 & 16777216) != 0) {
               var16 = var1.P(1478539457);
               var7 = var1.H((byte)38);
               if (var16 == 65535) {
                  var16 = -1;
               }

               var18 = var1.F((byte)28);
               var9 = var18 & 7;
               var10 = var18 >> 3 & 15;
               if (15 == var10) {
                  var10 = -1;
               }

               var25 = 1 == (var18 >> 7 & 1);
               var4.I(var16, var7, var9, var10, var25, 2, -1163482569);
            }

            if ((var5 & 8388608) != 0) {
               var4.pI = var1.E(1858696307);
               if ("".equals(var4.pI) || var4.pI.equals(var4.tI.B)) {
                  var4.pI = var4.tI.B;
               }
            }

            if ((var5 & 131072) != 0) {
               var16 = var1.S[(var1.A += 116413311) * 385051775 - 1] & 255;

               for(var7 = 0; var7 < var16; ++var7) {
                  var18 = var1.O(1053667933);
                  var9 = var1.H((byte)-33);
                  var4.qI.I(var18, var9, 1573935280);
               }
            }

            if ((var5 & 2097152) != 0) {
               var16 = var4.tI.J.length;
               var7 = 0;
               if (var4.tI.E != null) {
                  var7 = var4.tI.E.length;
               }

               byte var22 = 0;
               if (var4.tI.V != null) {
                  var7 = var4.tI.V.length;
               }

               var9 = var1.I();
               if ((var9 & 1) != 1) {
                  var19 = null;
                  if ((var9 & 2) == 2) {
                     var19 = new int[var16];

                     for(var11 = 0; var11 < var16; ++var11) {
                        var19[var11] = var1.Y(1235052657);
                     }
                  }

                  var23 = null;
                  if ((var9 & 4) == 4) {
                     var23 = new short[var7];

                     for(var12 = 0; var12 < var7; ++var12) {
                        var23[var12] = (short)var1.P(1478539457);
                     }
                  }

                  var21 = null;
                  if (8 == (var9 & 8)) {
                     var21 = new short[var22];

                     for(var13 = 0; var13 < var22; ++var13) {
                        var21[var13] = (short)var1.J((byte)2);
                     }
                  }

                  var24 = (long)var3 | (long)((var4.nI += 55499771) * -1842219213 - 1) << 32;
                  new FZI(var24, var19, var23, var21);
               }
            }

            if ((var5 & 262144) != 0) {
               var4.rI = var1.J((byte)16) * 933118661;
               if (var4.rI * 1817570317 == 65535) {
                  var4.rI = var4.tI.Q * 1520279523;
               }
            }

            if ((var5 & 1) != 0) {
               if (var4.tI.I((byte)32)) {
                  LJ.I((GEI)var4, (byte)7);
               }

               var4.I(WZ.q.I(var1.Y(1235052657), 384117949), 1598792788);
               var4.Z(var4.tI.II * -2095128707, -2141370583);
               var4.RI = -1186616623 * (var4.tI.t * -1927065533 << 3);
               if (var4.tI.I((byte)23)) {
                  BU.I(var4.K, var4.YI[0], var4.v[0], 0, (KEI)null, var4, (PEI)null, (byte)68);
               }
            }
         }

      } catch (RuntimeException var15) {
         throw DQ.I(var15, "tv.kd(" + ')');
      }
   }
}
