import java.io.EOFException;
import java.io.IOException;

public final class FP {
   OII append = null;
   static byte[] length = new byte[520];
   OII pow = null;
   int random;
   int toString = -22135608;

   boolean append(int var1, byte[] var2, int var3, boolean var4, int var5) {
      try {
         OII var6 = this.append;
         synchronized(this.append) {
            boolean var9;
            try {
               int var8;
               boolean var10000;
               if (var4) {
                  if (this.pow.Z(-1460152461) < (long)(var1 * 6 + 6)) {
                     var9 = false;
                     var10000 = var9;
                     return var10000;
                  }

                  this.pow.I((long)(6 * var1));
                  this.pow.Z(length, 0, 6, -1945961108);
                  var8 = ((length[3] & 255) << 16) + ((length[4] & 255) << 8) + (length[5] & 255);
                  if (var8 <= 0 || (long)var8 > this.append.Z(-1513278544) / 520L) {
                     var9 = false;
                     var10000 = var9;
                     return var10000;
                  }
               } else {
                  var8 = (int)((this.append.Z(-1893675250) + 519L) / 520L);
                  if (var8 == 0) {
                     var8 = 1;
                  }
               }

               length[0] = (byte)(var3 >> 16);
               length[1] = (byte)(var3 >> 8);
               length[2] = (byte)var3;
               length[3] = (byte)(var8 >> 16);
               length[4] = (byte)(var8 >> 8);
               length[5] = (byte)var8;
               this.pow.I((long)(var1 * 6));
               this.pow.I(length, 0, 6, 1699083209);
               int var21 = 0;
               int var10 = 0;

               while(true) {
                  if (var21 < var3) {
                     label159: {
                        int var11 = 0;
                        int var12;
                        if (var4) {
                           this.append.I((long)(var8 * 520));
                           int var13;
                           int var14;
                           if (var1 > 65535) {
                              try {
                                 this.append.Z(length, 0, 10, -1753859317);
                              } catch (EOFException var17) {
                                 break label159;
                              }

                              var12 = ((length[2] & 255) << 8) + ((length[0] & 255) << 24) + ((length[1] & 255) << 16) + (length[3] & 255);
                              var13 = (length[5] & 255) + ((length[4] & 255) << 8);
                              var11 = ((length[7] & 255) << 8) + ((length[6] & 255) << 16) + (length[8] & 255);
                              var14 = length[9] & 255;
                           } else {
                              try {
                                 this.append.Z(length, 0, 8, -1374964621);
                              } catch (EOFException var16) {
                                 break label159;
                              }

                              var12 = (length[1] & 255) + ((length[0] & 255) << 8);
                              var13 = ((length[2] & 255) << 8) + (length[3] & 255);
                              var11 = (length[6] & 255) + ((length[5] & 255) << 8) + ((length[4] & 255) << 16);
                              var14 = length[7] & 255;
                           }

                           boolean var15;
                           if (var12 != var1 || var10 != var13 || var14 != -1194991041 * this.random) {
                              var15 = false;
                              var10000 = var15;
                              return var10000;
                           }

                           if (var11 < 0 || (long)var11 > this.append.Z(-1633796509) / 520L) {
                              var15 = false;
                              var10000 = var15;
                              return var10000;
                           }
                        }

                        if (var11 == 0) {
                           var4 = false;
                           var11 = (int)((this.append.Z(-1603705353) + 519L) / 520L);
                           if (var11 == 0) {
                              ++var11;
                           }

                           if (var11 == var8) {
                              ++var11;
                           }
                        }

                        if (var3 - var21 <= 512) {
                           var11 = 0;
                        }

                        if (var1 > 65535) {
                           length[0] = (byte)(var1 >> 24);
                           length[1] = (byte)(var1 >> 16);
                           length[2] = (byte)(var1 >> 8);
                           length[3] = (byte)var1;
                           length[4] = (byte)(var10 >> 8);
                           length[5] = (byte)var10;
                           length[6] = (byte)(var11 >> 16);
                           length[7] = (byte)(var11 >> 8);
                           length[8] = (byte)var11;
                           length[9] = (byte)(-1194991041 * this.random);
                           this.append.I((long)(var8 * 520));
                           this.append.I(length, 0, 10, 1531111935);
                           var12 = var3 - var21;
                           if (var12 > 510) {
                              var12 = 510;
                           }

                           this.append.I(var2, var21, var12, 1227506688);
                           var21 += var12;
                        } else {
                           length[0] = (byte)(var1 >> 8);
                           length[1] = (byte)var1;
                           length[2] = (byte)(var10 >> 8);
                           length[3] = (byte)var10;
                           length[4] = (byte)(var11 >> 16);
                           length[5] = (byte)(var11 >> 8);
                           length[6] = (byte)var11;
                           length[7] = (byte)(this.random * -1194991041);
                           this.append.I((long)(var8 * 520));
                           this.append.I(length, 0, 8, 1542282258);
                           var12 = var3 - var21;
                           if (var12 > 512) {
                              var12 = 512;
                           }

                           this.append.I(var2, var21, var12, 1907873622);
                           var21 += var12;
                        }

                        var8 = var11;
                        ++var10;
                        continue;
                     }
                  }

                  boolean var7 = true;
                  return var7;
               }
            } catch (IOException var18) {
               var9 = false;
               return var9;
            }
         }
      } catch (RuntimeException var20) {
         throw DQ.I(var20, "ns.b(" + ')');
      }
   }

   public byte[] I(int var1, int var2) {
      try {
         OII var3 = this.append;
         synchronized(this.append) {
            Object var10000;
            try {
               if (this.pow.Z(-1862419954) < (long)(6 * var1 + 6)) {
                  Object var21 = null;
                  var10000 = var21;
                  return (byte[])var10000;
               }

               this.pow.I((long)(6 * var1));
               this.pow.Z(length, 0, 6, -1665251619);
               int var5 = ((length[0] & 255) << 16) + ((length[1] & 255) << 8) + (length[2] & 255);
               int var22 = (length[5] & 255) + ((length[4] & 255) << 8) + ((length[3] & 255) << 16);
               Object var7;
               if (var5 < 0 || var5 > this.toString * -1289609275) {
                  var7 = null;
                  var10000 = var7;
                  return (byte[])var10000;
               }

               if (var22 > 0 && (long)var22 <= this.append.Z(-1393462746) / 520L) {
                  byte[] var23 = new byte[var5];
                  int var8 = 0;
                  int var9 = 0;

                  while(var8 < var5) {
                     if (var22 == 0) {
                        Object var24 = null;
                        var10000 = var24;
                        return (byte[])var10000;
                     }

                     this.append.I((long)(520 * var22));
                     int var10 = var5 - var8;
                     byte var11;
                     int var12;
                     int var13;
                     int var14;
                     int var15;
                     if (var1 > 65535) {
                        if (var10 > 510) {
                           var10 = 510;
                        }

                        var11 = 10;
                        this.append.Z(length, 0, var11 + var10, -2124921702);
                        var12 = ((length[2] & 255) << 8) + ((length[0] & 255) << 24) + ((length[1] & 255) << 16) + (length[3] & 255);
                        var13 = ((length[4] & 255) << 8) + (length[5] & 255);
                        var14 = ((length[6] & 255) << 16) + ((length[7] & 255) << 8) + (length[8] & 255);
                        var15 = length[9] & 255;
                     } else {
                        if (var10 > 512) {
                           var10 = 512;
                        }

                        var11 = 8;
                        this.append.Z(length, 0, var11 + var10, -1642020087);
                        var12 = ((length[0] & 255) << 8) + (length[1] & 255);
                        var13 = (length[3] & 255) + ((length[2] & 255) << 8);
                        var14 = ((length[5] & 255) << 8) + ((length[4] & 255) << 16) + (length[6] & 255);
                        var15 = length[7] & 255;
                     }

                     Object var16;
                     if (var12 == var1 && var13 == var9 && -1194991041 * this.random == var15) {
                        if (var14 >= 0 && (long)var14 <= this.append.Z(-1934019874) / 520L) {
                           int var25 = var10 + var11;

                           for(int var17 = var11; var17 < var25; ++var17) {
                              var23[var8++] = length[var17];
                           }

                           var22 = var14;
                           ++var9;
                           continue;
                        }

                        var16 = null;
                        var10000 = var16;
                        return (byte[])var10000;
                     }

                     var16 = null;
                     var10000 = var16;
                     return (byte[])var10000;
                  }

                  byte[] var4 = var23;
                  return var4;
               }

               var7 = null;
               var10000 = var7;
            } catch (IOException var18) {
               Object var6 = null;
               return (byte[])var6;
            }

            return (byte[])var10000;
         }
      } catch (RuntimeException var20) {
         throw DQ.I(var20, "ns.a(" + ')');
      }
   }

   public boolean I(int var1, byte[] var2, int var3, int var4) {
      try {
         OII var5 = this.append;
         synchronized(this.append) {
            if (var3 >= 0 && var3 <= -1289609275 * this.toString) {
               boolean var6 = this.append(var1, var2, var3, true, 1494361890);
               if (!var6) {
                  var6 = this.append(var1, var2, var3, false, 1552417971);
               }

               return var6;
            } else {
               throw new IllegalArgumentException();
            }
         }
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "ns.f(" + ')');
      }
   }

   public String toString() {
      try {
         return "" + this.random * -1194991041;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "ns.toString(" + ')');
      }
   }

   public FP(int var1, OII var2, OII var3, int var4) {
      this.random = var1 * 576785855;
      this.append = var2;
      this.pow = var3;
      this.toString = var4 * 1731069709;
   }

   static void I(byte var0) {
      try {
         if (DE.I == null) {
            DE.I = new int[65536];
            LT.B = new int[65536];
            double var1 = 0.7D + (Math.random() * 0.03D - 0.015D);

            for(int var3 = 0; var3 < 65536; ++var3) {
               double var4 = (double)(var3 >> 10 & 63) / 64.0D + 0.0078125D;
               double var6 = 0.0625D + (double)(var3 >> 7 & 7) / 8.0D;
               double var8 = (double)(var3 & 127) / 128.0D;
               double var10 = var8;
               double var12 = var8;
               double var14 = var8;
               if (0.0D != var6) {
                  double var16;
                  if (var8 < 0.5D) {
                     var16 = var8 * (1.0D + var6);
                  } else {
                     var16 = var8 + var6 - var8 * var6;
                  }

                  double var18 = var8 * 2.0D - var16;
                  double var20 = var4 + 0.3333333333333333D;
                  if (var20 > 1.0D) {
                     --var20;
                  }

                  double var24 = var4 - 0.3333333333333333D;
                  if (var24 < 0.0D) {
                     ++var24;
                  }

                  if (6.0D * var20 < 1.0D) {
                     var10 = (var16 - var18) * 6.0D * var20 + var18;
                  } else if (var20 * 2.0D < 1.0D) {
                     var10 = var16;
                  } else if (var20 * 3.0D < 2.0D) {
                     var10 = var18 + 6.0D * (var16 - var18) * (0.6666666666666666D - var20);
                  } else {
                     var10 = var18;
                  }

                  if (6.0D * var4 < 1.0D) {
                     var12 = var18 + (var16 - var18) * 6.0D * var4;
                  } else if (var4 * 2.0D < 1.0D) {
                     var12 = var16;
                  } else if (3.0D * var4 < 2.0D) {
                     var12 = 6.0D * (0.6666666666666666D - var4) * (var16 - var18) + var18;
                  } else {
                     var12 = var18;
                  }

                  if (var24 * 6.0D < 1.0D) {
                     var14 = var24 * (var16 - var18) * 6.0D + var18;
                  } else if (2.0D * var24 < 1.0D) {
                     var14 = var16;
                  } else if (3.0D * var24 < 2.0D) {
                     var14 = 6.0D * (0.6666666666666666D - var24) * (var16 - var18) + var18;
                  } else {
                     var14 = var18;
                  }
               }

               var10 = Math.pow(var10, var1);
               var12 = Math.pow(var12, var1);
               var14 = Math.pow(var14, var1);
               int var27 = (int)(256.0D * var10);
               int var17 = (int)(256.0D * var12);
               int var28 = (int)(256.0D * var14);
               int var19 = var28 + (var17 << 8) + (var27 << 16);
               DE.I[var3] = var19 & 16777215;
               int var29 = var27 + (var17 << 8) + (var28 << 16);
               LT.B[var3] = var29;
            }
         }

      } catch (RuntimeException var26) {
         throw DQ.I(var26, "ns.p(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         int var2 = var0.X[var0.i * 1883543357];
         String var3 = var0.R.I(-937307905 * XEI.mD.S << 16 | var2, -1713280768);
         String var4;
         if (var3 == null) {
            var4 = "";
         } else {
            var4 = var3;
         }

         var0.S[(var0.A += 969361751) * -203050393 - 1] = var4;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ns.bi(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-43);
         X var4 = IU.F[var2 >> 16];
         WF.I(var3, var4, var0, -2030984421);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ns.mi(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         String var2 = (String)var0.S[(var0.A -= 969361751) * -203050393];
         PK var3 = GB.I(MEI.cI, XEI.eI.Z, (byte)13);
         var3.J.F(var2.length() + 1);
         var3.J.I(var2, 2108270585);
         XEI.eI.I(var3, (byte)-64);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ns.sn(" + ')');
      }
   }
}
