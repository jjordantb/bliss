import jaclib.nanotime.QueryPerformanceCounter;

public class BO extends ZO {
   int append = 149830037;
   long nanoTime = 0L;
   int toString = 0;
   long[] I = new long[10];
   long Z = 0L;
   long C = 0L;

   long method3790() {
      return this.Z * 7092803054136495365L;
   }

   long method3794(int var1) {
      try {
         return this.Z * 7092803054136495365L;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aau.k(" + ')');
      }
   }

   long method3795() {
      this.Z += this.append(970605565) * 805490578470680525L;
      return this.nanoTime * 2528788777947664827L > this.Z * 7092803054136495365L ? (this.nanoTime * 2528788777947664827L - this.Z * 7092803054136495365L) / 1000000L : 0L;
   }

   void method3793() {
      this.C = 0L;
      if (2528788777947664827L * this.nanoTime > this.Z * 7092803054136495365L) {
         this.Z += this.nanoTime * -1445719683822198849L - 1L * this.Z;
      }

   }

   int method3791(long var1) {
      try {
         if (2528788777947664827L * this.nanoTime > 7092803054136495365L * this.Z) {
            this.C += -266790697308425433L * this.nanoTime - this.Z * -8298770624837138791L;
            this.Z += -1445719683822198849L * this.nanoTime - 1L * this.Z;
            this.nanoTime += var1 * -8587934381355922573L;
            return 1;
         } else {
            int var3 = 0;

            do {
               ++var3;
               this.nanoTime += -8587934381355922573L * var1;
            } while(var3 < 10 && this.nanoTime * 2528788777947664827L < 7092803054136495365L * this.Z);

            if (this.nanoTime * 2528788777947664827L < this.Z * 7092803054136495365L) {
               this.nanoTime = this.Z * -3947023160226410433L;
            }

            return var3;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aau.i(" + ')');
      }
   }

   void method3788(int var1) {
      try {
         this.C = 0L;
         if (2528788777947664827L * this.nanoTime > this.Z * 7092803054136495365L) {
            this.Z += this.nanoTime * -1445719683822198849L - 1L * this.Z;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aau.b(" + ')');
      }
   }

   void method3798() {
      this.C = 0L;
      if (2528788777947664827L * this.nanoTime > this.Z * 7092803054136495365L) {
         this.Z += this.nanoTime * -1445719683822198849L - 1L * this.Z;
      }

   }

   void method3792() {
      this.C = 0L;
      if (2528788777947664827L * this.nanoTime > this.Z * 7092803054136495365L) {
         this.Z += this.nanoTime * -1445719683822198849L - 1L * this.Z;
      }

   }

   long method3789(int var1) {
      try {
         this.Z += this.append(970605565) * 805490578470680525L;
         return this.nanoTime * 2528788777947664827L > this.Z * 7092803054136495365L ? (this.nanoTime * 2528788777947664827L - this.Z * 7092803054136495365L) / 1000000L : 0L;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aau.p(" + ')');
      }
   }

   long method3797() {
      this.Z += this.append(970605565) * 805490578470680525L;
      return this.nanoTime * 2528788777947664827L > this.Z * 7092803054136495365L ? (this.nanoTime * 2528788777947664827L - this.Z * 7092803054136495365L) / 1000000L : 0L;
   }

   long append(int var1) {
      try {
         long var2 = QueryPerformanceCounter.nanoTime();
         long var4 = var2 - this.C * -749596307049612979L;
         this.C = var2 * -809283569091942523L;
         if (var4 > -5000000000L && var4 < 5000000000L) {
            this.I[this.toString * -683538483] = var4;
            this.toString = 1094860037 * ((1 + this.toString * -683538483) % 10);
            if (this.append * 769935805 < 1) {
               this.append += 149830037;
            }
         }

         long var6 = 0L;

         for(int var8 = 1; var8 <= this.append * 769935805; ++var8) {
            var6 += this.I[(10 + (this.toString * -683538483 - var8)) % 10];
         }

         return var6 / (long)(this.append * 769935805);
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "aau.e(" + ')');
      }
   }

   long method3796() {
      this.Z += this.append(970605565) * 805490578470680525L;
      return this.nanoTime * 2528788777947664827L > this.Z * 7092803054136495365L ? (this.nanoTime * 2528788777947664827L - this.Z * 7092803054136495365L) / 1000000L : 0L;
   }

   int method3799(long var1) {
      if (2528788777947664827L * this.nanoTime > 7092803054136495365L * this.Z) {
         this.C += -266790697308425433L * this.nanoTime - this.Z * -8298770624837138791L;
         this.Z += -1445719683822198849L * this.nanoTime - 1L * this.Z;
         this.nanoTime += var1 * -8587934381355922573L;
         return 1;
      } else {
         int var3 = 0;

         do {
            ++var3;
            this.nanoTime += -8587934381355922573L * var1;
         } while(var3 < 10 && this.nanoTime * 2528788777947664827L < 7092803054136495365L * this.Z);

         if (this.nanoTime * 2528788777947664827L < this.Z * 7092803054136495365L) {
            this.nanoTime = this.Z * -3947023160226410433L;
         }

         return var3;
      }
   }

   BO() {
      this.nanoTime = (this.Z = QueryPerformanceCounter.nanoTime() * 805490578470680525L) * -3947023160226410433L;
      if (this.Z * 7092803054136495365L == 0L) {
         throw new RuntimeException();
      }
   }
}
