public class JJI extends DJI {
   int J;
   static int append = 0;
   int equalsIgnoreCase;
   int toString;
   int F;
   static RFI S;

   void method1051(int var1, int var2) {
   }

   void method1054(int var1, int var2, byte var3) {
      try {
         int var4 = var1 * this.toString * -737606811 >> 12;
         int var5 = var1 * this.equalsIgnoreCase * 627591597 >> 12;
         int var6 = var2 * 870171747 * this.J >> 12;
         int var7 = var2 * this.F * 1837883371 >> 12;
         PS.I(var4, var6, var5, var7, 1785836763 * this.Z, -479015291);
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "yh.a(" + ')');
      }
   }

   void method1047(int var1, int var2, byte var3) {
   }

   void method1046(int var1, int var2) {
   }

   void method1048(int var1, int var2, byte var3) {
   }

   void method1049(int var1, int var2) {
      int var3 = var1 * this.toString * -737606811 >> 12;
      int var4 = var1 * this.equalsIgnoreCase * 627591597 >> 12;
      int var5 = var2 * 870171747 * this.J >> 12;
      int var6 = var2 * this.F * 1837883371 >> 12;
      PS.I(var3, var5, var4, var6, 1785836763 * this.Z, -1924061875);
   }

   JJI(int var1, int var2, int var3, int var4, int var5, int var6) {
      super(-1, var5, var6);
      this.toString = 388331117 * var1;
      this.J = var2 * -1813324469;
      this.equalsIgnoreCase = var3 * -2080243163;
      this.F = 1437683907 * var4;
   }

   void method1052(int var1, int var2) {
   }

   void method1050(int var1, int var2) {
   }

   void method1053(int var1, int var2) {
   }

   static NK I(KJ var0, int var1, int var2) {
      try {
         byte[] var3 = var0.I(var1, (byte)120);
         return var3 == null ? null : new NK(var3);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "yh.a(" + ')');
      }
   }

   static void I(int var0) {
   }

   static final void Z(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         VJ var3 = XW.I((short)512);
         PK var4 = GB.I(MEI.fI, var3.Z, (byte)56);
         var4.J.F(var2);
         var3.I(var4, (byte)-69);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "yh.abr(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         String var2 = (String)var0.S[(var0.A -= 969361751) * -203050393];
         if (P.Z != null && P.Z.equalsIgnoreCase(var2)) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 1;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "yh.vu(" + ')');
      }
   }

   public static void I(HZI var0, int var1, int var2, MU var3, MR var4, int var5) {
      try {
         OU var6 = UD.Z(1868919888);
         var6.T = var4;
         UEI.I(var0, var1, var2, var6, 536465062);
         var6.T = null;
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "yh.x(" + ')');
      }
   }

   static void I(byte var0) {
      try {
         for(EL var1 = (EL)FX.M.Z(-431286975); var1 != null; var1 = (EL)FX.M.C(-2120194897)) {
            if (-628325139 * var1.G > 1) {
               var1.G = 0;
               FX.I.I(var1, 6619564980435866523L * ((YK)var1.H.I.S).R);
               var1.H.B(2132471610);
            }
         }

         FX.H = 0;
         FX.k = 0;
         FX.K.I((byte)1);
         FX.B.I((byte)-19);
         FX.M.B(-116656816);
         NA.I(FX.Z, 1921095656);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "yh.ax(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = 2119035647 * JF.B;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "yh.amq(" + ')');
      }
   }
}
