public class CO extends ZO {
   long append = 0L;
   long nanoTime = 0L;
   long[] toString = new long[10];
   int I = 0;
   long Z = 0L;
   int C = -1505940925;

   long method3790() {
      return this.nanoTime * 4255909063329169833L;
   }

   CO() {
      this.nanoTime = System.nanoTime() * -5945124749373967719L;
      this.Z = System.nanoTime() * 1084187842630379629L;
   }

   int method3791(long var1) {
      try {
         if (this.Z * 3383889029778923877L > this.nanoTime * 4255909063329169833L) {
            this.append += this.Z * -1779823502204740161L - this.nanoTime * 1974423410268347339L;
            this.nanoTime += -8946266981622927523L * this.Z - this.nanoTime * 1L;
            this.Z += 1084187842630379629L * var1;
            return 1;
         } else {
            int var3 = 0;

            do {
               ++var3;
               this.Z += 1084187842630379629L * var1;
            } while(var3 < 10 && 3383889029778923877L * this.Z < 4255909063329169833L * this.nanoTime);

            if (this.Z * 3383889029778923877L < this.nanoTime * 4255909063329169833L) {
               this.Z = this.nanoTime * 923002373878029557L;
            }

            return var3;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aaf.i(" + ')');
      }
   }

   long method3794(int var1) {
      try {
         return this.nanoTime * 4255909063329169833L;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aaf.k(" + ')');
      }
   }

   long method3796() {
      this.nanoTime += this.append(-1990505491) * -5945124749373967719L;
      return this.Z * 3383889029778923877L > this.nanoTime * 4255909063329169833L ? (3383889029778923877L * this.Z - 4255909063329169833L * this.nanoTime) / 1000000L : 0L;
   }

   void method3798() {
      this.append = 0L;
      if (this.Z * 3383889029778923877L > 4255909063329169833L * this.nanoTime) {
         this.nanoTime += -8946266981622927523L * this.Z - 1L * this.nanoTime;
      }

   }

   void method3792() {
      this.append = 0L;
      if (this.Z * 3383889029778923877L > 4255909063329169833L * this.nanoTime) {
         this.nanoTime += -8946266981622927523L * this.Z - 1L * this.nanoTime;
      }

   }

   void method3793() {
      this.append = 0L;
      if (this.Z * 3383889029778923877L > 4255909063329169833L * this.nanoTime) {
         this.nanoTime += -8946266981622927523L * this.Z - 1L * this.nanoTime;
      }

   }

   long method3797() {
      this.nanoTime += this.append(847126204) * -5945124749373967719L;
      return this.Z * 3383889029778923877L > this.nanoTime * 4255909063329169833L ? (3383889029778923877L * this.Z - 4255909063329169833L * this.nanoTime) / 1000000L : 0L;
   }

   int method3799(long var1) {
      if (this.Z * 3383889029778923877L > this.nanoTime * 4255909063329169833L) {
         this.append += this.Z * -1779823502204740161L - this.nanoTime * 1974423410268347339L;
         this.nanoTime += -8946266981622927523L * this.Z - this.nanoTime * 1L;
         this.Z += 1084187842630379629L * var1;
         return 1;
      } else {
         int var3 = 0;

         do {
            ++var3;
            this.Z += 1084187842630379629L * var1;
         } while(var3 < 10 && 3383889029778923877L * this.Z < 4255909063329169833L * this.nanoTime);

         if (this.Z * 3383889029778923877L < this.nanoTime * 4255909063329169833L) {
            this.Z = this.nanoTime * 923002373878029557L;
         }

         return var3;
      }
   }

   long method3795() {
      this.nanoTime += this.append(195670472) * -5945124749373967719L;
      return this.Z * 3383889029778923877L > this.nanoTime * 4255909063329169833L ? (3383889029778923877L * this.Z - 4255909063329169833L * this.nanoTime) / 1000000L : 0L;
   }

   long append(int var1) {
      try {
         long var2 = System.nanoTime();
         long var4 = var2 - -5561332595849817637L * this.append;
         this.append = -5853783290180697517L * var2;
         if (var4 > -5000000000L && var4 < 5000000000L) {
            this.toString[578168601 * this.I] = var4;
            this.I = 974800169 * ((1 + 578168601 * this.I) % 10);
            if (this.C * -774573461 < 1) {
               this.C += -1505940925;
            }
         }

         long var6 = 0L;

         for(int var8 = 1; var8 <= -774573461 * this.C; ++var8) {
            var6 += this.toString[(578168601 * this.I - var8 + 10) % 10];
         }

         return var6 / (long)(-774573461 * this.C);
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "aaf.e(" + ')');
      }
   }

   void method3788(int var1) {
      try {
         this.append = 0L;
         if (this.Z * 3383889029778923877L > 4255909063329169833L * this.nanoTime) {
            this.nanoTime += -8946266981622927523L * this.Z - 1L * this.nanoTime;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aaf.b(" + ')');
      }
   }

   long method3789(int var1) {
      try {
         this.nanoTime += this.append(-99997412) * -5945124749373967719L;
         return this.Z * 3383889029778923877L > this.nanoTime * 4255909063329169833L ? (3383889029778923877L * this.Z - 4255909063329169833L * this.nanoTime) / 1000000L : 0L;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aaf.p(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-30);
         X var4 = IU.F[var2 >> 16];
         Y.I(var3, var4, var0, (byte)24);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aaf.dm(" + ')');
      }
   }

   public static UEI[] I(byte var0) {
      try {
         return new UEI[]{UEI.F, UEI.Z, UEI.C, UEI.B, UEI.D, UEI.G, UEI.L, UEI.M, UEI.A, UEI.E, UEI.N, UEI.H, UEI.K, UEI.I, UEI.J};
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "aaf.a(" + ')');
      }
   }
}
