import java.util.Iterator;

public final class JX implements Iterable {
   AE[] I;
   AE append;
   long toString;
   int Z;
   AE C;
   int B = 0;
   static int D;
   public static HT F;
   public static XR J;

   public void I(byte var1) {
      try {
         for(int var2 = 0; var2 < 577108745 * this.Z; ++var2) {
            AE var3 = this.I[var2];

            while(true) {
               AE var4 = var3.I;
               if (var3 == var4) {
                  break;
               }

               var4.I(-1460969981);
            }
         }

         this.append = null;
         this.C = null;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "sa.i(" + ')');
      }
   }

   public AE I(long var1) {
      try {
         this.toString = var1 * -1039549200087996967L;
         AE var3 = this.I[(int)(var1 & (long)(577108745 * this.Z - 1))];

         for(this.append = var3.I; this.append != var3; this.append = this.append.I) {
            if (this.append.Z * 7051297995265073167L == var1) {
               AE var4 = this.append;
               this.append = this.append.I;
               return var4;
            }
         }

         this.append = null;
         return null;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "sa.a(" + ')');
      }
   }

   public AE I(int var1) {
      try {
         if (this.append == null) {
            return null;
         } else {
            for(AE var2 = this.I[(int)(this.toString * -6131383980927776151L & (long)(this.Z * 577108745 - 1))]; this.append != var2; this.append = this.append.I) {
               if (this.toString * -6131383980927776151L == this.append.Z * 7051297995265073167L) {
                  AE var3 = this.append;
                  this.append = this.append.I;
                  return var3;
               }
            }

            this.append = null;
            return null;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "sa.f(" + ')');
      }
   }

   public int Z(int var1) {
      try {
         int var2 = 0;

         for(int var3 = 0; var3 < this.Z * 577108745; ++var3) {
            AE var4 = this.I[var3];

            for(AE var5 = var4.I; var4 != var5; var5 = var5.I) {
               ++var2;
            }
         }

         return var2;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "sa.b(" + ')');
      }
   }

   public AE Z(byte var1) {
      try {
         AE var2;
         if (-1375920843 * this.B > 0 && this.C != this.I[this.B * -1375920843 - 1]) {
            var2 = this.C;
            this.C = var2.I;
            return var2;
         } else {
            while(this.B * -1375920843 < 577108745 * this.Z) {
               var2 = this.I[(this.B += -1552413411) * -1375920843 - 1].I;
               if (var2 != this.I[-1375920843 * this.B - 1]) {
                  this.C = var2.I;
                  return var2;
               }
            }

            return null;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sa.d(" + ')');
      }
   }

   public Iterator iterator() {
      try {
         return new AY(this);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "sa.iterator(" + ')');
      }
   }

   public AE C(int var1) {
      try {
         this.B = 0;
         return this.Z((byte)67);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sa.k(" + ')');
      }
   }

   public void I(AE var1, long var2) {
      try {
         if (var1.C != null) {
            var1.I(-1460969981);
         }

         AE var4 = this.I[(int)(var2 & (long)(this.Z * 577108745 - 1))];
         var1.C = var4.C;
         var1.I = var4;
         var1.C.I = var1;
         var1.I.C = var1;
         var1.Z = 4191220306876042991L * var2;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "sa.p(" + ')');
      }
   }

   public JX(int var1) {
      this.Z = 1594491705 * var1;
      this.I = new AE[var1];

      for(int var2 = 0; var2 < var1; ++var2) {
         AE var3 = this.I[var2] = new AE();
         var3.I = var3;
         var3.C = var3;
      }

   }

   static void I(int var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, int var11, int var12, int var13, boolean var14, int var15) {
      try {
         if (var1 != 0 && -1 != var3) {
            Object var16 = null;
            int var17;
            if (var1 < 0) {
               var17 = -var1 - 1;
               if (var17 == -442628795 * XEI.i) {
                  var16 = UA.F;
               } else {
                  var16 = XEI.MC[var17];
               }
            } else {
               var17 = var1 - 1;
               QG var18 = (QG)XEI.UI.I((long)var17);
               if (var18 != null) {
                  var16 = (SSI)var18.J;
               }
            }

            if (var16 != null) {
               EQ var21 = ((SSI)var16).C(95049522);
               if (var21.I != null && var21.I[var3] != null) {
                  var4 -= var21.I[var3][1];
               }

               if (var21.o != null && var21.o[var3] != null) {
                  var4 -= var21.o[var3][1];
               }
            }
         }

         CR var20 = new CR(XEI.mI.T(-1611682495), var0, ET.B * -191892109, ET.B * -191892109, var6, var7, var4, XEI.kB * 443738891 + var10, XEI.kB * 443738891 + var11, var12, var13, var1, var2, var5, var14, var3);
         var20.I(var8, var9, NQ.I(var8, var9, ET.B * -191892109, -968708982) - var5, 443738891 * XEI.kB + var10, 1068285759);
         XEI.sC.I((AE)(new JL(var20)), (int)520361177);
      } catch (RuntimeException var19) {
         throw DQ.I(var19, "sa.nu(" + ')');
      }
   }
}
