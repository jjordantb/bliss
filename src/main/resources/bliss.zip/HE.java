public class HE extends AE {
   int J;
   int S;
   NG A;
   int E;
   int G;
   int H;
   int K;
   int L;
   int M;
   int N;
   int O;
   int P;
   S Q;
   int R;
   int T;
   NK U;
   static int append = 1048576;
   int V;
   YE W;
   int X;
   int Y;
   int i;

   void I(byte var1) {
      try {
         this.U = null;
         this.A = null;
         this.Q = null;
         this.W = null;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aaq.a(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         E.I(var0, -807637826);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aaq.so(" + ')');
      }
   }
}
