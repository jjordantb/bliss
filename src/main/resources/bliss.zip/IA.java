public class IA {
   int I;
   int Z;
   int[] C;
   int[] B;

   IA() {
      SG.B(16);
      this.Z = SG.I() != 0 ? SG.B(4) + 1 : 1;
      if (SG.I() != 0) {
         SG.B(8);
      }

      SG.B(2);
      if (this.Z > 1) {
         this.I = SG.B(4);
      }

      this.C = new int[this.Z];
      this.B = new int[this.Z];

      for(int var1 = 0; var1 < this.Z; ++var1) {
         SG.B(8);
         this.C[var1] = SG.B(8);
         this.B[var1] = SG.B(8);
      }

   }
}
