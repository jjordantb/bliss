public class GC extends EC {
   public int J;
   public static IU S;

   public RZ method49(int var1) {
      try {
         return RZ.E;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "zk.f(" + ')');
      }
   }

   public RZ method50() {
      return RZ.E;
   }

   GC(int var1, HZ var2, IZ var3, int var4, int var5, int var6) {
      super(var1, var2, var3, var4, var5);
      this.J = -899365323 * var6;
   }

   public RZ method51() {
      return RZ.E;
   }

   static boolean I(int var0, int var1) {
      try {
         return 19 == var0 || 4 == var0 || 3 == var0 || 8 == var0 || var0 == 2 || var0 == 9;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "zk.fi(" + ')');
      }
   }
}
