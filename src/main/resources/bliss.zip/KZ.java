public class KZ {
   static int I;
   static RFI[] Z;
   static int C;
   static HZ B;
   static int D;
   static int F;
   static int J;
   static int S;
   static LZI A;
   static IZ E;

   KZ() throws Throwable {
      throw new Error();
   }

   public static void I(int var0, int[] var1, int var2) {
      try {
         if (var0 != -1 && KT.I(var0, var1, -2060750983)) {
            HSI[] var3 = IU.F[var0].Z;
            ESI.I(var3, -1178956884);
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ao.p(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         FW.J.I(FW.J.a, var0.H[(var0.J -= -391880689) * 681479919] != 0 ? 1 : 0, -261887884);
         JN.I(656179282);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ao.air(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-45);
         X var4 = IU.F[var2 >> 16];
         EDI.Z(var3, var4, var0, -1849275031);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ao.ek(" + ')');
      }
   }

   public static void I(int var0) {
      try {
         IP.I(-1, 255, 328240529);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "ao.o(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         if (var2 < 0 || var2 > 5) {
            var2 = 2;
         }

         WR.I(var2, false, 622850291);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ao.aic(" + ')');
      }
   }

   static final void I(byte var0) {
      try {
         for(JL var1 = (JL)XEI.sC.Z(1766612795); var1 != null; var1 = (JL)XEI.sC.B(49146)) {
            CR var2 = var1.G;
            if (443738891 * XEI.kB > var2.X * -1349988959) {
               var1.I(-1460969981);
               var2.C(686828159);
            } else if (XEI.kB * 443738891 >= var2.V * 1113390887) {
               var2.Z(-36689971);
               SF var5;
               if (1894383945 * var2.z > 0) {
                  if (1596783995 * XEI.uI == 0) {
                     SSI var3 = PFI.C[var2.z * 1894383945 - 1].I(1231902873);
                     if (var3 != null) {
                        SF var4 = var3.I().I;
                        if ((int)var4.I >= 0 && (int)var4.I < XEI.mI.Z(-1942094391) * 512 && (int)var4.Z >= 0 && (int)var4.Z < XEI.mI.C(-1804151587) * 512) {
                           var2.I((int)var4.I, (int)var4.Z, NQ.I((int)var4.I, (int)var4.Z, var3.K, -1503815167) - 2134079017 * var2.W, 443738891 * XEI.kB, 1121215352);
                        }
                     }
                  } else {
                     QG var7 = (QG)XEI.UI.I((long)(1894383945 * var2.z - 1));
                     if (var7 != null) {
                        GEI var9 = (GEI)var7.J;
                        var5 = var9.I().I;
                        if ((int)var5.I >= 0 && (int)var5.I < XEI.mI.Z(-1876273086) * 512 && (int)var5.Z >= 0 && (int)var5.Z < XEI.mI.C(-203309822) * 512) {
                           var2.I((int)var5.I, (int)var5.Z, NQ.I((int)var5.I, (int)var5.Z, var2.K, -1366613250) - var2.W * 2134079017, XEI.kB * 443738891, 2031199219);
                        }
                     }
                  }
               }

               if (1894383945 * var2.z < 0) {
                  int var8 = -(var2.z * 1894383945) - 1;
                  PEI var10;
                  if (var8 == -442628795 * XEI.i) {
                     var10 = UA.F;
                  } else {
                     var10 = XEI.MC[var8];
                  }

                  if (var10 != null) {
                     var5 = var10.I().I;
                     if ((int)var5.I >= 0 && (int)var5.I < XEI.mI.Z(-1981087344) * 512 && (int)var5.Z >= 0 && (int)var5.Z < XEI.mI.C(-1284142631) * 512) {
                        var2.I((int)var5.I, (int)var5.Z, NQ.I((int)var5.I, (int)var5.Z, var2.K, -1135065402) - var2.W * 2134079017, 443738891 * XEI.kB, 1831333850);
                     }
                  }
               }

               var2.I(XEI.BF * 614680345, (byte)63);
               XEI.mI.T(-1611682495).I(var2, true, (byte)0);
            }
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ao.ie(" + ')');
      }
   }
}
