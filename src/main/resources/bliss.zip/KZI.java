public class KZI {
   KJ I;
   JQ append = new JQ(64);
   public static ET Z;

   public void I(int var1) {
      try {
         JQ var2 = this.append;
         synchronized(this.append) {
            this.append.Z();
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "uv.p(" + ')');
      }
   }

   public KZI(ZV var1, XW var2, KJ var3) {
      this.I = var3;
      if (this.I != null) {
         this.I.F(II.A.y * -1006924897, 1020653544);
      }

   }

   public void I(int var1, byte var2) {
      try {
         JQ var3 = this.append;
         synchronized(this.append) {
            this.append.I(var1, -2004411058);
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "uv.b(" + ')');
      }
   }

   public void Z(int var1) {
      try {
         JQ var2 = this.append;
         synchronized(this.append) {
            this.append.I();
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "uv.f(" + ')');
      }
   }

   public DZI I(int var1, int var2) {
      try {
         JQ var4 = this.append;
         DZI var3;
         synchronized(this.append) {
            var3 = (DZI)this.append.I((long)var1);
         }

         if (var3 != null) {
            return var3;
         } else {
            KJ var5 = this.I;
            byte[] var10;
            synchronized(this.I) {
               var10 = this.I.I(-1006924897 * II.A.y, var1, (byte)-62);
            }

            var3 = new DZI();
            if (var10 != null) {
               var3.I(new REI(var10), -1070488617);
            }

            JQ var11 = this.append;
            synchronized(this.append) {
               this.append.I(var3, (long)var1);
            }

            return var3;
         }
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "uv.a(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         String var2 = (String)var0.S[(var0.A -= 969361751) * -203050393];
         boolean var3 = var0.H[(var0.J -= -391880689) * 681479919] == 1;
         HO.I(var2, var3, 729356820);
         var0.H[(var0.J += -391880689) * 681479919 - 1] = CQ.L * 367592105;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "uv.adv(" + ')');
      }
   }
}
