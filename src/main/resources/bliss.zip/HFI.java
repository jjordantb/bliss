public class HFI extends LDI {
   long Z;
   int append;
   public static IBI C;
   public static String B;

   public void method866(int var1) {
      try {
         OK var2 = (OK)PFI.Z.I(8017746467363524815L * this.Z);
         if (var2 != null) {
            var2.J = -1178949921 * this.append;
         } else {
            PFI.Z.I(new OK(825940513 * this.append), this.Z * 8017746467363524815L);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "xq.f(" + ')');
      }
   }

   public void method868() {
      OK var1 = (OK)PFI.Z.I(8017746467363524815L * this.Z);
      if (var1 != null) {
         var1.J = -1178949921 * this.append;
      } else {
         PFI.Z.I(new OK(825940513 * this.append), this.Z * 8017746467363524815L);
      }

   }

   HFI(REI var1, boolean var2) {
      super(var1);
      int var3 = var1.C();
      if (var2) {
         this.Z = (4294967296L | (long)var3) * -3845001125918771665L;
      } else {
         this.Z = (long)var3 * -3845001125918771665L;
      }

      this.append = var1.H((byte)-88) * -914937375;
   }

   public void method869() {
      OK var1 = (OK)PFI.Z.I(8017746467363524815L * this.Z);
      if (var1 != null) {
         var1.J = -1178949921 * this.append;
      } else {
         PFI.Z.I(new OK(825940513 * this.append), this.Z * 8017746467363524815L);
      }

   }

   static final void Z(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-30);
         FJ.I(var3, var0, (byte)24);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "xq.qw(" + ')');
      }
   }

   public static void I(int var0, int var1) {
      try {
         MX.S[var0] = false;
         LZ.C(var0, -175879726);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "xq.u(" + ')');
      }
   }

   static final void B(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.b.method5612(var2, 1352882135);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "xq.aoh(" + ')');
      }
   }

   static void I(int var0, int var1, int var2) {
      try {
         VK var3 = IV.I(6, (long)var0);
         var3.I((byte)15);
         var3.L = var1 * 1274450087;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "xq.as(" + ')');
      }
   }

   static void I(int var0, int var1, int var2, int var3, boolean var4, int var5) {
      boolean var13 = false;

      try {
         long var6 = (long)(var0 | (var4 ? Integer.MIN_VALUE : 0));
         DN var8 = (DN)DN.S.I(var6);
         if (var8 == null) {
            var8 = new DN();
            DN.S.I(var8, var6);
         }

         if (var8.E.length <= var1) {
            int[] var9 = new int[var1 + 1];
            int[] var10 = new int[var1 + 1];

            int var11;
            for(var11 = 0; var11 < var8.E.length; ++var11) {
               var9[var11] = var8.E[var11];
               var10[var11] = var8.G[var11];
            }

            for(var11 = var8.E.length; var11 < var1; ++var11) {
               var9[var11] = -1;
               var10[var11] = 0;
            }

            var8.E = var9;
            var8.G = var10;
         }

         var8.E[var1] = var2;
         var8.G[var1] = var3;
      } catch (RuntimeException var12) {
         throw DQ.I(var12, "xq.d(" + ')');
      }
   }

   static final void C(OU var0, byte var1) {
      try {
         if (-1233866115 * XEI.QZ == 14 && !NO.I((byte)9)) {
            if (VY.D) {
               var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
            } else if (CP.F * -247648477838985581L > CI.I((byte)1) - 1000L) {
               var0.H[(var0.J += -391880689) * 681479919 - 1] = 1;
            } else {
               VY.D = true;
               PK var2 = GB.I(MEI.iI, XEI.TI.Z, (byte)42);
               var2.J.B(-1351839083 * V.J, -933492277);
               XEI.TI.I(var2, (byte)-36);
               var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
            }
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 1;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "xq.alo(" + ')');
      }
   }
}
