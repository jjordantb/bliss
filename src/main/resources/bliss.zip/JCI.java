import java.awt.Canvas;
import java.awt.Dimension;

final class JCI implements XSI {
   public boolean method229(ZR var1, int var2) {
      try {
         return var1 instanceof HAI;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "x.a(" + ')');
      }
   }

   public boolean method228(ZR var1) {
      return var1 instanceof HAI;
   }

   public boolean method230(ZR var1) {
      return var1 instanceof HAI;
   }

   static final void I(HSI var0, OU var1, int var2) {
      try {
         int var3 = var1.H[(var1.J -= -391880689) * 681479919];
         int var4 = var1.H[(var1.J -= -391880689) * 681479919] - 1;
         if (2 != 1548853569 * var0.KI) {
            throw new RuntimeException("");
         } else {
            HEI var5 = WZ.q.I(var0.f * 572201537, -87546938);
            if (var0.VC == null) {
               var0.VC = new FZI(var5, false);
            }

            var0.VC.B = PT.I(-1683898407) * 3177550440302969639L;
            if (var4 >= 0 && var4 < var5.J.length) {
               var0.VC.Z[var4] = var3;
               VEI.I(var0, -339426215);
            } else {
               throw new RuntimeException("");
            }
         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "x.qp(" + ')');
      }
   }

   public static final void I(HSI var0, int var1, int var2, int var3) {
      try {
         if (XEI.SB == null && !FX.G && var0 != null && EV.I(var0, 1470456512)) {
            XEI.SB = var0;
            XEI.gI = AP.I(var0, (byte)-122);
            XEI.ZZ = -344812543 * var1;
            XEI.GB = var2 * -1376922141;
            DFI.M = 0;
            XEI.TB = false;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "x.ls(" + ')');
      }
   }

   public static final HSI I(X var0, HSI var1, int var2) {
      try {
         if (-1 != 1573706803 * var1.m) {
            return var0.I(var1.m * 1573706803, (short)8481);
         } else {
            if (!var0.I) {
               int var3 = var1.V * -440872681 >>> 16;
               AY var4 = new AY(XEI.yC);

               for(OSI var5 = (OSI)var4.I(-2012602178); var5 != null; var5 = (OSI)var4.next()) {
                  if (-1617025021 * var5.S == var3) {
                     return AZI.I((int)(7051297995265073167L * var5.Z), (byte)-3);
                  }
               }
            }

            return null;
         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "x.ku(" + ')');
      }
   }

   public static void I(int var0) {
      try {
         if (AN.A != null) {
            AN.A.I((byte)-66);
         }

         if (JN.L != null) {
            JN.L.I((byte)-1);
         }

      } catch (RuntimeException var2) {
         throw DQ.I(var2, "x.i(" + ')');
      }
   }

   static QM I(int var0, int var1, int var2, long var3, int var5, int var6) {
      try {
         QM[] var7 = QM.M;
         synchronized(QM.M) {
            QM var8;
            if (2017906303 * QM.K == 0) {
               var8 = new QM();
            } else {
               var8 = QM.M[(QM.K -= 1787228543) * 2017906303];
            }

            var8.N = -435781441 * var0;
            var8.O = var1 * -871010593;
            var8.P = var2 * -25797095;
            var8.Q = -8923914877553624531L * var3;
            var8.R = var5 * 1687973955;
            return var8;
         }
      } catch (RuntimeException var11) {
         throw DQ.I(var11, "x.av(" + ')');
      }
   }

   public static GSI I(int var0, Canvas var1, FEI var2, KJ var3, int var4, int var5) {
      try {
         int var6 = 0;
         int var7 = 0;
         if (var1 != null) {
            Dimension var8 = var1.getSize();
            var6 = var8.width;
            var7 = var8.height;
         }

         return FU.I(var0, var1, var2, var3, var4, var6, var7, 16777215);
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "x.a(" + ')');
      }
   }
}
