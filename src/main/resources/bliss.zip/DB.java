public class DB {
   public static DB I = new DB(1);
   public static DB Z = new DB(2);
   public static DB C = new DB(0);
   static DB B = new DB(3);
   public int D;

   DB(int var1) {
      this.D = var1;
   }
}
