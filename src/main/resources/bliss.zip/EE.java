public final class EE extends AE {
   int J;
   int S;
   public int A;
   int E;
   public static IY G = new IY();
   int H;
   int K;
   public int L;
   int M;
   int N;
   DX O;
   boolean P = true;
   boolean Q = false;
   int R;
   public static IY T = new IY();
   static long U = 2843605614692854059L;
   public static int V;

   public static int I(int var0, int var1, boolean var2, boolean var3, int var4) {
      try {
         DN var5 = CS.I(var0, var3, 1819104649);
         if (var5 == null) {
            return 0;
         } else {
            int var6 = 0;

            for(int var7 = 0; var7 < var5.E.length; ++var7) {
               if (var5.E[var7] >= 0 && var5.E[var7] < -888767613 * JH.R.I) {
                  SEI var8 = JH.R.I(var5.E[var7]);
                  int var9 = var8.I(var1, WFI.C.I(var1, 1149077752).I * -388931549, -2139054269);
                  if (var2) {
                     var6 += var5.G[var7] * var9;
                  } else {
                     var6 += var9;
                  }
               }
            }

            return var6;
         }
      } catch (RuntimeException var10) {
         throw DQ.I(var10, "aab.p(" + ')');
      }
   }

   static void I(int var0, int var1, byte var2) {
      try {
         VK var3 = IV.I(5, (long)var0);
         var3.I((byte)35);
         var3.L = var1 * 1274450087;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aab.az(" + ')');
      }
   }
}
