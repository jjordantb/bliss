public class AJ extends SJ {
   CX LA;
   static boolean length = false;
   static int[] method29 = new int[]{1, -1, -1, 1};
   static int[] method30 = new int[]{0, -1, 0, 1};
   static int method32 = 2;
   static int method33 = 3;
   static int[] method37 = new int[]{1, 0, -1, 0};
   static int method39 = 0;
   XQ method5048;
   static int[] substring = new int[]{-1, -1, 1, 1};
   int valueOf = 1175238381;
   static int WI = 1;
   static boolean XI = false;

   void I(GSI var1, int var2, int var3, int var4, int var5, XA var6, int var7) {
      try {
         HAI var8 = this.I(var2, var3, var4, var5, 1530247338);
         if (var8 != null) {
            KEI var9 = this.LA.C(var8.method32((byte)80));
            int var10 = var8.method29(726839210);
            int var11 = var8.method30((short)20316);
            if (var9.F(-1167401239)) {
               IY.I(var2, var4, var5, var9, 16515072);
            }

            if (var8.method39(-1865139931)) {
               var8.method37(var1, -959766431);
            }

            if (var3 == 0) {
               this.I.C(var2, var4, var5, -1330802605);
               this.I.I(var2, var4, var5, (byte)-1);
               if (var9.G * -2144543407 != 0) {
                  var6.C(var4, var5, var10, var11, var9.r, !var9.l, (byte)108);
               }

               if (-1508517619 * var9.E == 1) {
                  if (var11 == 0) {
                     this.I.D.I(1, var2, var4, var5);
                  } else if (1 == var11) {
                     this.I.D.I(2, var2, var4, 1 + var5);
                  } else if (2 == var11) {
                     this.I.D.I(1, var2, var4 + 1, var5);
                  } else if (var11 == 3) {
                     this.I.D.I(2, var2, var4, var5);
                  }
               }
            } else if (1 == var3) {
               this.I.C(var2, var4, var5, (byte)59);
               this.I.D(var2, var4, var5, -391880689);
            } else if (2 == var3) {
               this.I.I(var2, var4, var5, XEI.CF, (short)-414);
               if (var9.G * -2144543407 != 0 && -1125834887 * var9.N + var4 < this.S * -954368823 && -1125834887 * var9.N + var5 < this.A * 181474463 && -565161399 * var9.L + var4 < this.S * -954368823 && -565161399 * var9.L + var5 < 181474463 * this.A) {
                  var6.I(var4, var5, var9.N * -1125834887, -565161399 * var9.L, var11, var9.r, !var9.l, (byte)38);
               }

               if (RW.D.V * -1976050083 == var10) {
                  if ((var11 & 1) == 0) {
                     this.I.D.I(8, var2, var4, var5);
                  } else {
                     this.I.D.I(16, var2, var4, var5);
                  }
               }
            } else if (3 == var3) {
               this.I.I(var2, var4, var5, 2008906043);
               if (var9.G * -2144543407 == 1) {
                  var6.I(var4, var5, -1244104271);
               }
            }
         }

      } catch (RuntimeException var12) {
         throw DQ.I(var12, "aaa.cr(" + ')');
      }
   }

   public final void I(GSI var1, REI var2, int var3, int var4, byte var5) {
      try {
         if (!this.E) {
            boolean var6 = false;
            RT var7 = null;

            while(true) {
               int var8;
               int var9;
               int var11;
               int var12;
               int var18;
               while(var2.A * 385051775 < var2.S.length) {
                  var8 = var2.I();
                  if (var8 == 0) {
                     if (var7 == null) {
                        var7 = new RT(var2, this.method5048);
                     } else {
                        var7.I(var2, this.method5048, (short)1342);
                     }
                  } else {
                     int var13;
                     int var14;
                     int var15;
                     if (1 == var8) {
                        var9 = var2.I();
                        if (var9 > 0) {
                           for(var18 = 0; var18 < var9; ++var18) {
                              WO var20 = new WO(var1, -1688804109 * this.I.I, var2, 2);
                              if (589172669 * var20.N == 31) {
                                 IZI var21 = BJ.C.I(var2.C(), -1728729634);
                                 var20.I(var21.B * 1438741121, var21.C * -2095379959, 2096922993 * var21.I, 1418726113 * var21.Z, 320507599);
                              }

                              if (var1.method5048() > 0) {
                                 GE var22 = var20.I;
                                 var13 = var22.B(823958259) + (var3 << 9);
                                 var14 = var22.I((byte)113) + (var4 << 9);
                                 var15 = var13 >> 9;
                                 int var16 = var14 >> 9;
                                 if (var15 >= 0 && var16 >= 0 && var15 < -954368823 * this.S && var16 < 181474463 * this.A) {
                                    var22.I(var13, this.U[var20.E * -1565952249][var15][var16] - var22.C(1382635254), var14, (byte)37);
                                    this.I.I(var20, 763639750);
                                 }
                              }
                           }
                        }
                     } else if (var8 == 2) {
                        if (var7 == null) {
                           var7 = new RT();
                        }

                        var7.I(var2, -1319879858);
                     } else if (128 == var8) {
                        if (var7 == null) {
                           var7 = new RT();
                        }

                        var7.I(var2, this.method5048, (byte)11);
                     } else {
                        if (129 != var8) {
                           throw new IllegalStateException("");
                        }

                        if (this.G == null) {
                           this.G = new byte[4][][];
                        }

                        for(var9 = 0; var9 < 4; ++var9) {
                           byte var10 = var2.S(-12558881);
                           if (var10 == 0 && this.G[var9] != null) {
                              var11 = var3;
                              var12 = var3 + 64;
                              var13 = var4;
                              var14 = 64 + var4;
                              if (var3 < 0) {
                                 var11 = 0;
                              } else if (var3 >= -954368823 * this.S) {
                                 var11 = this.S * -954368823;
                              }

                              if (var12 < 0) {
                                 var12 = 0;
                              } else if (var12 >= -954368823 * this.S) {
                                 var12 = -954368823 * this.S;
                              }

                              if (var4 < 0) {
                                 var13 = 0;
                              } else if (var4 >= 181474463 * this.A) {
                                 var13 = this.A * 181474463;
                              }

                              if (var14 < 0) {
                                 var14 = 0;
                              } else if (var14 >= this.A * 181474463) {
                                 var14 = this.A * 181474463;
                              }

                              while(var11 < var12) {
                                 while(var13 < var14) {
                                    this.G[var9][var11][var13] = 0;
                                    ++var13;
                                 }

                                 ++var11;
                              }
                           } else if (var10 == 1) {
                              if (this.G[var9] == null) {
                                 this.G[var9] = new byte[this.S * -954368823 + 1][1 + this.A * 181474463];
                              }

                              for(var11 = 0; var11 < 64; var11 += 4) {
                                 for(var12 = 0; var12 < 64; var12 += 4) {
                                    byte var19 = var2.S(-12558881);

                                    for(var14 = var11 + var3; var14 < 4 + var11 + var3; ++var14) {
                                       for(var15 = var12 + var4; var15 < 4 + var4 + var12; ++var15) {
                                          if (var14 >= 0 && var14 < -954368823 * this.S && var15 >= 0 && var15 < 181474463 * this.A) {
                                             this.G[var9][var14][var15] = var19;
                                          }
                                       }
                                    }
                                 }
                              }
                           } else if (2 == var10) {
                              if (this.G[var9] == null) {
                                 this.G[var9] = new byte[this.S * -954368823 + 1][181474463 * this.A + 1];
                              }

                              if (var9 > 0) {
                                 var11 = var3;
                                 var12 = 64 + var3;
                                 var13 = var4;
                                 var14 = 64 + var4;
                                 if (var3 < 0) {
                                    var11 = 0;
                                 } else if (var3 >= this.S * -954368823) {
                                    var11 = this.S * -954368823;
                                 }

                                 if (var12 < 0) {
                                    var12 = 0;
                                 } else if (var12 >= this.S * -954368823) {
                                    var12 = -954368823 * this.S;
                                 }

                                 if (var4 < 0) {
                                    var13 = 0;
                                 } else if (var4 >= 181474463 * this.A) {
                                    var13 = 181474463 * this.A;
                                 }

                                 if (var14 < 0) {
                                    var14 = 0;
                                 } else if (var14 >= this.A * 181474463) {
                                    var14 = 181474463 * this.A;
                                 }

                                 while(var11 < var12) {
                                    while(var13 < var14) {
                                       this.G[var9][var11][var13] = this.G[var9 - 1][var11][var13];
                                       ++var13;
                                    }

                                    ++var11;
                                 }
                              }
                           }
                        }

                        var6 = true;
                     }
                  }
               }

               if (var7 != null) {
                  for(var8 = 0; var8 < 8; ++var8) {
                     for(var9 = 0; var9 < 8; ++var9) {
                        var18 = var8 + (var3 >> 3);
                        var11 = (var4 >> 3) + var9;
                        if (var18 >= 0 && var18 < this.S * -954368823 >> 3 && var11 >= 0 && var11 < this.A * 181474463 >> 3) {
                           this.method5048.I(var18, var11, var7, (byte)-2);
                        }
                     }
                  }
               }

               if (!var6 && this.G != null) {
                  for(var8 = 0; var8 < 4; ++var8) {
                     if (this.G[var8] != null) {
                        for(var9 = 0; var9 < 16; ++var9) {
                           for(var18 = 0; var18 < 16; ++var18) {
                              var11 = (var3 >> 2) + var9;
                              var12 = var18 + (var4 >> 2);
                              if (var11 >= 0 && var11 < 26 && var12 >= 0 && var12 < 26) {
                                 this.G[var8][var11][var12] = 0;
                              }
                           }
                        }
                     }
                  }
               }
               break;
            }
         }

      } catch (RuntimeException var17) {
         throw DQ.I(var17, "aaa.ck(" + ')');
      }
   }

   public final void I(GSI var1, REI var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10) {
      try {
         if (!this.E) {
            boolean var11 = false;
            RT var12 = null;
            int var13 = 8 * (var7 & 7);
            int var14 = (var8 & 7) * 8;

            while(true) {
               int var15;
               int var16;
               int var18;
               int var26;
               while(385051775 * var2.A < var2.S.length) {
                  var15 = var2.I();
                  if (var15 == 0) {
                     if (var12 == null) {
                        var12 = new RT(var2, this.method5048);
                     } else {
                        var12.I(var2, this.method5048, (short)1534);
                     }
                  } else {
                     int var21;
                     int var22;
                     int var23;
                     int var28;
                     if (1 == var15) {
                        var16 = var2.I();
                        if (var16 > 0) {
                           for(var26 = 0; var26 < var16; ++var26) {
                              WO var27 = new WO(var1, -1688804109 * this.I.I, var2, 2);
                              if (31 == 589172669 * var27.N) {
                                 IZI var29 = BJ.C.I(var2.C(), -1427443057);
                                 var27.I(var29.B * 1438741121, -2095379959 * var29.C, 2096922993 * var29.I, var29.Z * 1418726113, -1699648006);
                              }

                              if (var1.method5048() > 0) {
                                 GE var30 = var27.I;
                                 var28 = var30.B(823958259) >> 9;
                                 var21 = var30.I((byte)113) >> 9;
                                 if (var6 == var27.E * -1565952249 && var28 >= var13 && var28 < var13 + 8 && var21 >= var14 && var21 < var14 + 8) {
                                    var22 = (var4 << 9) + EF.I(var30.B(823958259) & 4095, var30.I((byte)107) & 4095, var9, (byte)91);
                                    var23 = (var5 << 9) + SJ.I(var30.B(823958259) & 4095, var30.I((byte)68) & 4095, var9, (short)27107);
                                    var28 = var22 >> 9;
                                    var21 = var23 >> 9;
                                    if (var28 >= 0 && var21 >= 0 && var28 < this.S * -954368823 && var21 < this.A * 181474463) {
                                       var30.I(var22, this.U[var6][var28][var21] - var30.C(-2061162182), var23, (byte)-72);
                                       this.I.I(var27, -1995203079);
                                    }
                                 }
                              }
                           }
                        }
                     } else if (2 == var15) {
                        if (var12 == null) {
                           var12 = new RT();
                        }

                        var12.I(var2, -1319879858);
                     } else if (var15 == 128) {
                        if (var12 == null) {
                           var12 = new RT();
                        }

                        var12.I(var2, this.method5048, (byte)53);
                     } else {
                        if (var15 != 129) {
                           throw new IllegalStateException("");
                        }

                        if (this.G == null) {
                           this.G = new byte[4][][];
                        }

                        for(var16 = 0; var16 < 4; ++var16) {
                           byte var17 = var2.S(-12558881);
                           int var19;
                           if (var17 == 0 && this.G[var3] != null) {
                              if (var16 <= var6) {
                                 var18 = var4;
                                 var19 = var4 + 7;
                                 var28 = var5;
                                 var21 = 7 + var5;
                                 if (var4 < 0) {
                                    var18 = 0;
                                 } else if (var4 >= -954368823 * this.S) {
                                    var18 = -954368823 * this.S;
                                 }

                                 if (var19 < 0) {
                                    var19 = 0;
                                 } else if (var19 >= -954368823 * this.S) {
                                    var19 = this.S * -954368823;
                                 }

                                 if (var5 < 0) {
                                    var28 = 0;
                                 } else if (var5 >= this.A * 181474463) {
                                    var28 = this.A * 181474463;
                                 }

                                 if (var21 < 0) {
                                    var21 = 0;
                                 } else if (var21 >= this.A * 181474463) {
                                    var21 = this.A * 181474463;
                                 }

                                 while(var18 < var19) {
                                    while(var28 < var21) {
                                       this.G[var3][var18][var28] = 0;
                                       ++var28;
                                    }

                                    ++var18;
                                 }
                              }
                           } else if (var17 != 1) {
                              if (2 == var17) {
                                 ;
                              }
                           } else {
                              if (this.G[var3] == null) {
                                 this.G[var3] = new byte[-954368823 * this.S + 1][1 + 181474463 * this.A];
                              }

                              for(var18 = 0; var18 < 64; var18 += 4) {
                                 for(var19 = 0; var19 < 64; var19 += 4) {
                                    byte var20 = var2.S(-12558881);
                                    if (var16 <= var6) {
                                       for(var21 = var18; var21 < 4 + var18; ++var21) {
                                          for(var22 = var19; var22 < var19 + 4; ++var22) {
                                             if (var21 >= var13 && var21 < 8 + var13 && var22 >= var14 && var22 < 8 + var14) {
                                                var23 = var4 + NU.I(var21 & 7, var22 & 7, var9, -1280307862);
                                                int var24 = var5 + TY.I(var21 & 7, var22 & 7, var9, (byte)-51);
                                                if (var23 >= 0 && var23 < -954368823 * this.S && var24 >= 0 && var24 < this.A * 181474463) {
                                                   this.G[var3][var23][var24] = var20;
                                                   var11 = true;
                                                }
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }

               if (var12 != null) {
                  this.method5048.I(var4 >> 3, var5 >> 3, var12, (byte)-31);
               }

               if (!var11 && this.G != null && this.G[var3] != null) {
                  var15 = var4 + 7;
                  var16 = var5 + 7;

                  for(var26 = var4; var26 < var15; ++var26) {
                     for(var18 = var5; var18 < var16; ++var18) {
                        this.G[var3][var26][var18] = 0;
                     }
                  }
               }
               break;
            }
         }

      } catch (RuntimeException var25) {
         throw DQ.I(var25, "aaa.cn(" + ')');
      }
   }

   public final void I(GSI var1, byte[] var2, int var3, int var4, XA[] var5, int var6) {
      try {
         REI var7 = new REI(var2);
         int var8 = -1;

         while(true) {
            int var9 = var7.Z((short)255);
            if (var9 == 0) {
               return;
            }

            var8 += var9;
            int var10 = 0;

            while(true) {
               int var11 = var7.B(1723054621);
               if (var11 == 0) {
                  break;
               }

               var10 += var11 - 1;
               int var12 = var10 & 63;
               int var13 = var10 >> 6 & 63;
               int var14 = var10 >> 12;
               int var15 = var7.I();
               int var16 = var15 >> 2;
               int var17 = var15 & 3;
               int var18 = var13 + var3;
               int var19 = var12 + var4;
               if (var18 > 0 && var19 > 0 && var18 < -954368823 * this.S - 1 && var19 < this.A * 181474463 - 1) {
                  XA var20 = null;
                  if (!this.E) {
                     int var21 = var14;
                     if (2 == (this.K.C[1][var18][var19] & 2)) {
                        var21 = var14 - 1;
                     }

                     if (var21 >= 0) {
                        var20 = var5[var21];
                     }
                  }

                  this.I(var1, var14, var14, var18, var19, var8, var17, var16, var20, -1, 1769761748);
               }
            }
         }
      } catch (RuntimeException var22) {
         throw DQ.I(var22, "aaa.cc(" + ')');
      }
   }

   public final void I(GSI var1, byte[] var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, XA[] var10, int var11) {
      try {
         REI var12 = new REI(var2);
         int var13 = -1;

         do {
            int var14 = var12.Z((short)255);
            if (var14 == 0) {
               if (var11 == -174685332) {
                  ;
               }

               return;
            }

            var13 += var14;
            int var15 = 0;

            while(true) {
               int var16 = var12.B(1723054621);
               if (var16 == 0) {
                  break;
               }

               var15 += var16 - 1;
               int var17 = var15 & 63;
               int var18 = var15 >> 6 & 63;
               int var19 = var15 >> 12;
               int var20 = var12.I();
               int var21 = var20 >> 2;
               int var22 = var20 & 3;
               if (var6 == var19 && var18 >= var7 && var18 < 8 + var7 && var17 >= var8 && var17 < 8 + var8) {
                  KEI var23 = this.LA.C(var13);
                  int var24 = var4 + FV.I(var18 & 7, var17 & 7, var9, -1125834887 * var23.N, var23.L * -565161399, var22, 181137699);
                  int var25 = var5 + NO.I(var18 & 7, var17 & 7, var9, var23.N * -1125834887, var23.L * -565161399, var22, 1981614763);
                  if (var24 > 0 && var25 > 0 && var24 < -954368823 * this.S - 1 && var25 < 181474463 * this.A - 1) {
                     XA var26 = null;
                     if (!this.E) {
                        int var27 = var3;
                        if (2 == (this.K.C[1][var24][var25] & 2)) {
                           var27 = var3 - 1;
                        }

                        if (var27 >= 0) {
                           var26 = var10[var27];
                        }
                     }

                     this.I(var1, var3, var3, var24, var25, var13, var9 + var22 & 3, var21, var26, -1, 2074281649);
                  }
               }
            }
         } while(var11 == -174685332);

         throw new IllegalStateException();
      } catch (RuntimeException var28) {
         throw DQ.I(var28, "aaa.ca(" + ')');
      }
   }

   boolean C(GSI var1, int var2, int var3, boolean var4, KEI var5, int var6, int var7, int var8, int var9, int var10, int var11, int var12, int var13, boolean var14, YJI var15, XA var16, int var17, int var18, byte var19) {
      try {
         int var27;
         Object var29;
         if (-1976050083 * RW.W.V == var2) {
            var27 = var5.E * -1508517619;
            if (length && -1 == -1508517619 * var5.E) {
               var27 = 1;
            }

            if (var4) {
               OR var30 = new OR(this.I, var1, this.LA, var5, var7, var8, var9, var10, var11, this.E, var2, var3, var14);
               if (var30.method39(-1364237139)) {
                  var30.method33(var1, -2008903061);
               }

               var29 = var30;
            } else {
               var29 = new PR(this.I, var1, this.LA, var5, var7, var8, var9, var10, var11, this.E, var2, var3, var6);
            }

            this.I.I(var7, var12, var13, (NR)var29, (NR)null, (byte)53);
            if (var3 == 0) {
               if (this.H && var5.e) {
                  var15.LA(var12, var13, 50);
                  var15.LA(var12, var13 + 1, 50);
               }

               if (var27 == 1 && !this.E) {
                  this.I.D.I(1, var7, var12, var13, 201968507 * var5.O, -1994960695 * var5.P);
               }
            } else if (var3 == 1) {
               if (this.H && var5.e) {
                  var15.LA(var12, 1 + var13, 50);
                  var15.LA(var12 + 1, var13 + 1, 50);
               }

               if (var27 == 1 && !this.E) {
                  this.I.D.I(2, var7, var12, 1 + var13, var5.O * 201968507, -(var5.P * -1994960695));
               }
            } else if (var3 == 2) {
               if (this.H && var5.e) {
                  var15.LA(var12 + 1, var13, 50);
                  var15.LA(1 + var12, 1 + var13, 50);
               }

               if (1 == var27 && !this.E) {
                  this.I.D.I(1, var7, 1 + var12, var13, var5.O * 201968507, -(var5.P * -1994960695));
               }
            } else if (var3 == 3) {
               if (this.H && var5.e) {
                  var15.LA(var12, var13, 50);
                  var15.LA(1 + var12, var13, 50);
               }

               if (1 == var27 && !this.E) {
                  this.I.D.I(2, var7, var12, var13, var5.O * 201968507, var5.P * -1994960695);
               }
            }

            if (-2144543407 * var5.G != 0 && var16 != null) {
               var16.I(var12, var13, var2, var3, var5.r, !var5.l, (byte)0);
            }

            if (-448694871 * var5.T != 64) {
               this.I.I(var7, var12, var13, var5.T * -448694871, (byte)-54);
            }

            return true;
         } else {
            Object var20;
            OR var28;
            if (var2 == -1976050083 * RW.Z.V) {
               if (var4) {
                  var28 = new OR(this.I, var1, this.LA, var5, var7, var8, var9, var10, var11, this.E, var2, var3, var14);
                  if (var28.method39(-1749970817)) {
                     var28.method33(var1, -2130877816);
                  }

                  var20 = var28;
               } else {
                  var20 = new PR(this.I, var1, this.LA, var5, var7, var8, var9, var10, var11, this.E, var2, var3, var6);
               }

               this.I.I(var7, var12, var13, (NR)var20, (NR)null, (byte)117);
               if (var5.e && this.H) {
                  if (var3 == 0) {
                     var15.LA(var12, var13 + 1, 50);
                  } else if (1 == var3) {
                     var15.LA(1 + var12, var13 + 1, 50);
                  } else if (2 == var3) {
                     var15.LA(var12 + 1, var13, 50);
                  } else if (3 == var3) {
                     var15.LA(var12, var13, 50);
                  }
               }

               if (-2144543407 * var5.G != 0 && var16 != null) {
                  var16.I(var12, var13, var2, var3, var5.r, !var5.l, (byte)0);
               }

               return true;
            } else if (var2 == -1976050083 * RW.C.V) {
               var27 = var3 + 1 & 3;
               Object var22;
               if (var4) {
                  OR var23 = new OR(this.I, var1, this.LA, var5, var7, var8, var9, var10, var11, this.E, var2, 4 + var3, var14);
                  OR var24 = new OR(this.I, var1, this.LA, var5, var7, var8, var9, var10, var11, this.E, var2, var27, var14);
                  if (var23.method39(-1679564366)) {
                     var23.method33(var1, -2079126659);
                  }

                  if (var24.method39(-1782980621)) {
                     var24.method33(var1, -2050070618);
                  }

                  var29 = var23;
                  var22 = var24;
               } else {
                  var29 = new PR(this.I, var1, this.LA, var5, var7, var8, var9, var10, var11, this.E, var2, 4 + var3, var6);
                  var22 = new PR(this.I, var1, this.LA, var5, var7, var8, var9, var10, var11, this.E, var2, var27, var6);
               }

               this.I.I(var7, var12, var13, (NR)var29, (NR)var22, (byte)48);
               if ((var5.E * -1508517619 == 1 || length && -1 == -1508517619 * var5.E) && !this.E) {
                  if (var3 == 0) {
                     this.I.D.I(1, var7, var12, var13, var5.O * 201968507, var5.P * -1994960695);
                     this.I.D.I(2, var7, var12, 1 + var13, var5.O * 201968507, var5.P * -1994960695);
                  } else if (var3 == 1) {
                     this.I.D.I(1, var7, var12 + 1, var13, var5.O * 201968507, var5.P * -1994960695);
                     this.I.D.I(2, var7, var12, 1 + var13, var5.O * 201968507, var5.P * -1994960695);
                  } else if (var3 == 2) {
                     this.I.D.I(1, var7, 1 + var12, var13, 201968507 * var5.O, -1994960695 * var5.P);
                     this.I.D.I(2, var7, var12, var13, 201968507 * var5.O, var5.P * -1994960695);
                  } else if (3 == var3) {
                     this.I.D.I(1, var7, var12, var13, var5.O * 201968507, var5.P * -1994960695);
                     this.I.D.I(2, var7, var12, var13, var5.O * 201968507, -1994960695 * var5.P);
                  }
               }

               if (-2144543407 * var5.G != 0 && var16 != null) {
                  var16.I(var12, var13, var2, var3, var5.r, !var5.l, (byte)0);
               }

               if (var5.T * -448694871 != 64) {
                  this.I.I(var7, var12, var13, -448694871 * var5.T, (byte)12);
               }

               return true;
            } else if (var2 == -1976050083 * RW.B.V) {
               if (var4) {
                  var28 = new OR(this.I, var1, this.LA, var5, var7, var8, var9, var10, var11, this.E, var2, var3, var14);
                  if (var28.method39(-1956737069)) {
                     var28.method33(var1, -2085613160);
                  }

                  var20 = var28;
               } else {
                  var20 = new PR(this.I, var1, this.LA, var5, var7, var8, var9, var10, var11, this.E, var2, var3, var6);
               }

               this.I.I(var7, var12, var13, (NR)var20, (NR)null, (byte)58);
               if (var5.e && this.H) {
                  if (var3 == 0) {
                     var15.LA(var12, 1 + var13, 50);
                  } else if (var3 == 1) {
                     var15.LA(var12 + 1, var13 + 1, 50);
                  } else if (2 == var3) {
                     var15.LA(var12 + 1, var13, 50);
                  } else if (3 == var3) {
                     var15.LA(var12, var13, 50);
                  }
               }

               if (var5.G * -2144543407 != 0 && var16 != null) {
                  var16.I(var12, var13, var2, var3, var5.r, !var5.l, (byte)0);
               }

               return true;
            } else if (var2 == -1976050083 * RW.D.V) {
               if (var4) {
                  JR var21 = new JR(this.I, var1, this.LA, var5, var7, var8, var9, var10, var11, this.E, var12, var12, var13, var13, var2, var3, var14);
                  if (var21.method39(-2055372332)) {
                     var21.method33(var1, -2053499485);
                  }

                  var20 = var21;
               } else {
                  var20 = new FR(this.I, var1, this.LA, var5, var7, var8, var9, var10, var11, this.E, var12, var17 + var12 - 1, var13, var13 + var18 - 1, var2, var3, var6);
               }

               this.I.I((ZR)var20, false, (byte)0);
               if (1 == var5.E * -1508517619 && !this.E) {
                  byte var26;
                  if ((var3 & 1) == 0) {
                     var26 = 8;
                  } else {
                     var26 = 16;
                  }

                  this.I.D.I(var26, var7, var12, var13, var5.O * 201968507, 0);
               }

               if (var5.G * -2144543407 != 0 && var16 != null) {
                  var16.Z(var12, var13, var17, var18, var5.r, !var5.l, (byte)2);
               }

               if (var5.T * -448694871 != 64) {
                  this.I.I(var7, var12, var13, var5.T * -448694871, (byte)23);
               }

               return true;
            } else {
               return false;
            }
         }
      } catch (RuntimeException var25) {
         throw DQ.I(var25, "aaa.ce(" + ')');
      }
   }

   boolean LA(GSI var1, int var2, int var3, boolean var4, KEI var5, int var6, int var7, int var8, int var9, int var10, int var11, int var12, int var13, int var14) {
      try {
         if (var2 == -1976050083 * RW.F.V) {
            Object var26;
            if (var4) {
               KR var28 = new KR(this.I, var1, this.LA, var5, var7, var8, var9, var10, var11, this.E, 0, 0, var2, var3);
               if (var28.method39(-1870688116)) {
                  var28.method33(var1, -2124402842);
               }

               var26 = var28;
            } else {
               var26 = new HR(this.I, var1, this.LA, var5, var7, var8, var9, var10, var11, this.E, 0, 0, var2, var3, var6);
            }

            this.I.I(var7, var12, var13, (GR)var26, (GR)null, (int)861548591);
            return true;
         } else {
            int var15;
            Object var25;
            HAI var27;
            KR var29;
            if (var2 == RW.G.V * -1976050083) {
               var15 = 65;
               var27 = (HAI)this.I.F(var7, var12, var13, 644917110);
               if (var27 != null) {
                  var15 = this.LA.C(var27.method32((byte)27)).T * -448694871 + 1;
               }

               if (var4) {
                  var29 = new KR(this.I, var1, this.LA, var5, var7, var8, var9, var10, var11, this.E, method37[var3] * var15, method30[var3] * var15, var2, var3);
                  if (var29.method39(-1591018559)) {
                     var29.method33(var1, -2011263790);
                  }

                  var25 = var29;
               } else {
                  var25 = new HR(this.I, var1, this.LA, var5, var7, var8, var9, var10, var11, this.E, var15 * method37[var3], var15 * method30[var3], var2, var3, var6);
               }

               this.I.I(var7, var12, var13, (GR)var25, (GR)null, (int)1859376340);
               return true;
            } else if (-1976050083 * RW.S.V == var2) {
               var15 = 33;
               var27 = (HAI)this.I.F(var7, var12, var13, 552550945);
               if (var27 != null) {
                  var15 = this.LA.C(var27.method32((byte)14)).T * -448694871 / 2 + 1;
               }

               if (var4) {
                  var29 = new KR(this.I, var1, this.LA, var5, var7, var8, var9, var10, var11, this.E, var15 * method37[var3], var15 * method30[var3], var2, var3 + 4);
                  if (var29.method39(-1847078642)) {
                     var29.method33(var1, -2043548826);
                  }

                  var25 = var29;
               } else {
                  var25 = new HR(this.I, var1, this.LA, var5, var7, var8, var9, var10, var11, this.E, var15 * method29[var3], substring[var3] * var15, var2, var3 + 4, var6);
               }

               this.I.I(var7, var12, var13, (GR)var25, (GR)null, (int)1431954302);
               return true;
            } else if (-1976050083 * RW.A.V == var2) {
               var15 = var3 + 2 & 3;
               Object var23;
               if (var4) {
                  KR var24 = new KR(this.I, var1, this.LA, var5, var7, var8, var9, var10, var11, this.E, 0, 0, var2, var15 + 4);
                  if (var24.method39(-1553150372)) {
                     var24.method33(var1, -2133567145);
                  }

                  var23 = var24;
               } else {
                  var23 = new HR(this.I, var1, this.LA, var5, var7, var8, var9, var10, var11, this.E, 0, 0, var2, var15 + 4, var6);
               }

               this.I.I(var7, var12, var13, (GR)var23, (GR)null, (int)1921538390);
               return true;
            } else if (RW.E.V * -1976050083 == var2) {
               var15 = var3 + 2 & 3;
               int var16 = 33;
               HAI var17 = (HAI)this.I.F(var7, var12, var13, 2110046759);
               if (var17 != null) {
                  var16 = this.LA.C(var17.method32((byte)14)).T * -448694871 / 2 + 1;
               }

               Object var18;
               Object var19;
               if (var4) {
                  KR var20 = new KR(this.I, var1, this.LA, var5, var7, var8, var9, var10, var11, this.E, var16 * method29[var3], substring[var3] * var16, var2, var3 + 4);
                  KR var21 = new KR(this.I, var1, this.LA, var5, var7, var8, var9, var10, var11, this.E, 0, 0, var2, var15 + 4);
                  if (var20.method39(-1237533744)) {
                     var20.method33(var1, -2074609967);
                  }

                  if (var21.method39(-1449189890)) {
                     var21.method33(var1, -2061447636);
                  }

                  var18 = var20;
                  var19 = var21;
               } else {
                  HR var30 = new HR(this.I, var1, this.LA, var5, var7, var8, var9, var10, var11, this.E, var16 * method29[var3], var16 * substring[var3], var2, var3 + 4, var6);
                  HR var31 = new HR(this.I, var1, this.LA, var5, var7, var8, var9, var10, var11, this.E, 0, 0, var2, 4 + var15, var6);
                  var18 = var30;
                  var19 = var31;
               }

               this.I.I(var7, var12, var13, (GR)var18, (GR)var19, (int)1357750473);
               return true;
            } else {
               return false;
            }
         }
      } catch (RuntimeException var22) {
         throw DQ.I(var22, "aaa.cb(" + ')');
      }
   }

   HAI I(int var1, int var2, int var3, int var4, int var5) {
      try {
         HAI var6 = null;
         if (var2 == 0) {
            var6 = (HAI)this.I.F(var1, var3, var4, 212388673);
         }

         if (1 == var2) {
            var6 = (HAI)this.I.J(var1, var3, var4, 1080081135);
         }

         if (var2 == 2) {
            var6 = (HAI)this.I.I(var1, var3, var4, XEI.CF, -1336288750);
         }

         if (var2 == 3) {
            var6 = (HAI)this.I.B(var1, var3, var4, (byte)50);
         }

         return var6;
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "aaa.cu(" + ')');
      }
   }

   public final void I(GSI var1, boolean var2, int var3) {
      try {
         this.I.I();
         if (!var2) {
            int var4;
            int var5;
            if (1551623871 * this.J > 1) {
               for(var4 = 0; var4 < this.S * -954368823; ++var4) {
                  for(var5 = 0; var5 < this.A * 181474463; ++var5) {
                     if ((this.K.C[1][var4][var5] & 2) == 2) {
                        this.I.I(var4, var5, -1135071672);
                     }
                  }
               }
            }

            for(var4 = 0; var4 < 1551623871 * this.J; ++var4) {
               for(var5 = 0; var5 <= this.A * 181474463; ++var5) {
                  for(int var6 = 0; var6 <= this.S * -954368823; ++var6) {
                     if ((this.L[var4][var6][var5] & 4) != 0) {
                        int var7 = var6;
                        int var8 = var6;
                        int var9 = var5;

                        int var10;
                        for(var10 = var5; var9 > 0 && (this.L[var4][var6][var9 - 1] & 4) != 0 && var10 - var9 < 10; --var9) {
                           ;
                        }

                        while(var10 < 181474463 * this.A && (this.L[var4][var6][var10 + 1] & 4) != 0 && var10 - var9 < 10) {
                           ++var10;
                        }

                        int var11;
                        label122:
                        while(var7 > 0 && var8 - var7 < 10) {
                           for(var11 = var9; var11 <= var10; ++var11) {
                              if ((this.L[var4][var7 - 1][var11] & 4) == 0) {
                                 if (var3 != 1773155741) {
                                    return;
                                 }
                                 break label122;
                              }
                           }

                           --var7;
                        }

                        label107:
                        while(var8 < this.S * -954368823 && var8 - var7 < 10) {
                           for(var11 = var9; var11 <= var10; ++var11) {
                              if ((this.L[var4][var8 + 1][var11] & 4) == 0) {
                                 break label107;
                              }
                           }

                           ++var8;
                        }

                        if ((1 + (var10 - var9)) * (var8 - var7 + 1) >= 4) {
                           var11 = this.U[var4][var7][var9];
                           this.I.D.I(4, var4, var7 << 9, (var8 << 9) + 512, var9 << 9, 512 + (var10 << 9), var11, var11);

                           for(int var12 = var7; var12 <= var8; ++var12) {
                              for(int var13 = var9; var13 <= var10; ++var13) {
                                 this.L[var4][var12][var13] &= -5;
                              }
                           }
                        }
                     }
                  }
               }
            }

            this.I.D.I();
         }

         this.L = null;
      } catch (RuntimeException var14) {
         throw DQ.I(var14, "aaa.cp(" + ')');
      }
   }

   final void I(GSI var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, XA var9, int var10, int var11) {
      try {
         if (var3 < -1281303921 * this.valueOf) {
            this.valueOf = 272172143 * var3;
         }

         KEI var12 = this.LA.C(var6);
         if (FW.J.P.C(1871358652) != 0 || !var12.ZI) {
            int var13;
            int var14;
            if (1 != var7 && var7 != 3) {
               var13 = var12.N * -1125834887;
               var14 = -565161399 * var12.L;
            } else {
               var13 = var12.L * -565161399;
               var14 = var12.N * -1125834887;
            }

            int var15;
            int var16;
            if (var13 + var4 <= -954368823 * this.S) {
               var15 = (var13 >> 1) + var4;
               var16 = (var13 + 1 >> 1) + var4;
            } else {
               var15 = var4;
               var16 = var4 + 1;
            }

            int var17;
            int var18;
            if (var14 + var5 <= 181474463 * this.A) {
               var17 = var5 + (var14 >> 1);
               var18 = var5 + (1 + var14 >> 1);
            } else {
               var17 = var5;
               var18 = 1 + var5;
            }

            YJI var19 = this.I.G[var2];
            int var20 = var19.I(var15, var17, (byte)-48) + var19.I(var16, var17, (byte)-81) + var19.I(var15, var18, (byte)-94) + var19.I(var16, var18, (byte)-87) >> 2;
            int var21 = (var13 << 8) + (var4 << 9);
            int var22 = (var14 << 8) + (var5 << 9);
            boolean var23 = this.H && !this.E && var12.M;
            if (var12.F(-1167401239)) {
               BU.I(var3, var4, var5, var7, var12, (GEI)null, (PEI)null, (byte)37);
            }

            boolean var24 = -1 == var10 && !var12.C(934270378) && var12.C == null && !var12.H && !var12.R;
            if (!XI || (!KFI.Z(var8, (byte)13) || var12.E * -1508517619 == 1) && (!O.I(var8, 1378507148) || -1508517619 * var12.E != 0)) {
               Object var25;
               if (var8 == -1976050083 * RW.R.V) {
                  if (FW.J.S.Z(-807116560) != 0 || var12.K * 1532834983 != 0 || -2144543407 * var12.G == 1 || var12.k) {
                     if (var24) {
                        ER var26 = new ER(this.I, var1, this.LA, var12, var3, var2, var21, var20, var22, this.E, var7, var23);
                        if (var26.method39(-1997643666)) {
                           var26.method33(var1, -2091324745);
                        }

                        var25 = var26;
                     } else {
                        var25 = new AR(this.I, var1, this.LA, var12, var3, var2, var21, var20, var22, this.E, var7, var10);
                     }

                     this.I.I(var3, var4, var5, (SR)var25, (int)1853221006);
                     if (1 == var12.G * -2144543407 && var9 != null) {
                        var9.Z(var4, var5, (byte)2);
                     }
                  }
               } else if (-1976050083 * RW.T.V != var8 && var8 != -1976050083 * RW.L.V) {
                  if (!O.I(var8, -865214392) && !OD.I(var8, (byte)-21)) {
                     if (!this.C(var1, var8, var7, var24, var12, var10, var3, var2, var21, var20, var22, var4, var5, var23, var19, var9, var13, var14, (byte)-37)) {
                        this.LA(var1, var8, var7, var24, var12, var10, var3, var2, var21, var20, var22, var4, var5, -1189422227);
                     }
                  } else {
                     if (var24) {
                        JR var33 = new JR(this.I, var1, this.LA, var12, var3, var2, var21, var20, var22, this.E, var4, var13 + var4 - 1, var5, var14 + var5 - 1, var8, var7, var23);
                        if (var33.method39(-1419053588)) {
                           var33.method33(var1, -2081421218);
                        }

                        var25 = var33;
                     } else {
                        var25 = new FR(this.I, var1, this.LA, var12, var3, var2, var21, var20, var22, this.E, var4, var4 + var13 - 1, var5, var5 + var14 - 1, var8, var7, var10);
                     }

                     this.I.I((ZR)var25, false, (byte)0);
                     if (this.H && !this.E && O.I(var8, 1932287279) && -1976050083 * RW.H.V != var8 && var3 > 0 && var12.E * -1508517619 != 0) {
                        this.L[var3][var4][var5] = (byte)(this.L[var3][var4][var5] | 4);
                     }

                     if (var12.G * -2144543407 != 0 && var9 != null) {
                        var9.Z(var4, var5, var13, var14, var12.r, !var12.l, (byte)4);
                     }
                  }
               } else {
                  JR var31 = null;
                  int var27;
                  Object var32;
                  if (var24) {
                     JR var28 = new JR(this.I, var1, this.LA, var12, var3, var2, var21, var20, var22, this.E, var4, var4 + var13 - 1, var5, var14 + var5 - 1, var8, var7, var23);
                     var27 = var28.I((short)230);
                     var32 = var28;
                     var31 = var28;
                  } else {
                     var32 = new FR(this.I, var1, this.LA, var12, var3, var2, var21, var20, var22, this.E, var4, var4 + var13 - 1, var5, var5 + var14 - 1, var8, var7, var10);
                     var27 = 15;
                  }

                  if (this.I.I((ZR)var32, false, (byte)0)) {
                     if (var31 != null && var31.method39(-2136957466)) {
                        var31.method33(var1, -2130479152);
                     }

                     if (var12.e && this.H) {
                        if (var27 > 30) {
                           var27 = 30;
                        }

                        for(int var34 = 0; var34 <= var13; ++var34) {
                           for(int var29 = 0; var29 <= var14; ++var29) {
                              var19.LA(var4 + var34, var29 + var5, var27);
                           }
                        }
                     }
                  }

                  if (var12.G * -2144543407 != 0 && var9 != null) {
                     var9.Z(var4, var5, var13, var14, var12.r, !var12.l, (byte)15);
                  }
               }
            }
         }

      } catch (RuntimeException var30) {
         throw DQ.I(var30, "aaa.ci(" + ')');
      }
   }

   public AJ(AP var1, CX var2, int var3, int var4, int var5, boolean var6, LJ var7, XQ var8) {
      super(var1, var3, var4, var5, var6, KZI.Z, IC.L, var7);
      this.LA = var2;
      this.method5048 = var8;
   }

   static final void I(HSI var0, X var1, OU var2, byte var3) {
      try {
         String var4 = (String)var2.S[(var2.A -= 969361751) * -203050393];
         int[] var5 = IN.I(var4, var2, -247465484);
         if (var5 != null) {
            var4 = var4.substring(0, var4.length() - 1);
         }

         var0.cI = OI.I(var4, var2, -2046058202);
         var0.iZ = var5;
         var0.JZ = true;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "aaa.oy(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.J -= -1959403445;
         int var2 = var0.H[var0.J * 681479919];
         int var3 = var0.H[681479919 * var0.J + 1];
         int var4 = var0.H[681479919 * var0.J + 2];
         int var5 = var0.H[3 + 681479919 * var0.J];
         int var6 = var0.H[4 + 681479919 * var0.J];
         if (-1 == var4) {
            throw new RuntimeException();
         } else {
            DSI var7 = QZI.C.I(var4, 1528209569);
            if (var3 != var7.Z) {
               throw new RuntimeException();
            } else if (var7.I != var2) {
               throw new RuntimeException();
            } else {
               int[] var8 = var7.I((Object)var5, (short)3608);
               if (var6 >= 0 && var8 != null && var8.length > var6) {
                  var0.H[(var0.J += -391880689) * 681479919 - 1] = var8[var6];
               } else {
                  throw new RuntimeException();
               }
            }
         }
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "aaa.vv(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         var0.H[(var0.J += -391880689) * 681479919 - 1] = 1548853569 * var3.KI == 1 ? var3.f * 572201537 : -1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aaa.pn(" + ')');
      }
   }
}
