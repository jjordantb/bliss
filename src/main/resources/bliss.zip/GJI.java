public abstract class GJI extends QK {
   public static XII G;

   public static YK B(int var0) {
      try {
         return QO.I;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "na.al(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-49);
         X var4 = IU.F[var2 >> 16];
         QZ.I(var3, var4, var0, -866344405);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "na.mr(" + ')');
      }
   }

   public static final void D(int var0) {
      try {
         for(int var1 = 0; var1 < 5; ++var1) {
            XEI.KI[var1] = false;
         }

         XEI.jZ = -1723181617;
         XEI.sZ = 2694169;
         NI.L = 0;
         VW.I = 0;
         EE.V = 621176181;
         AV.I = -1001372047;
         B.XZ = 178575833;
         XEI.QD = 727655629 * XEI.kB;
         GN.r = -1614496487 * RR.Q;
         VU.I = L.B * -418338293;
         ZFI.D = RZ.H * -459981543;
         RD.B = 905514481 * XEI.VZ;
         DN.H = CZ.I * 1437648991;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "na.hb(" + ')');
      }
   }

   public static final void I(boolean var0, int var1, byte var2) {
      try {
         LG var3 = var0 ? EQ.t : ET.D;
         if (var3 != null && var1 >= 0 && var1 < 649879491 * var3.S) {
            RC var4 = var3.E[var1];
            if (-1 == var4.C) {
               String var5 = var4.I;
               VJ var6 = XW.I((short)512);
               PK var7 = GB.I(MEI.o, var6.Z, (byte)56);
               var7.J.F(3 + SBI.I(var5, -175153344));
               var7.J.F(var0 ? 1 : 0);
               var7.J.Z(var1, 16711935);
               var7.J.I(var5, 2135659343);
               var6.I(var7, (byte)-99);
            }
         }

      } catch (RuntimeException var8) {
         throw DQ.I(var8, "na.mw(" + ')');
      }
   }

   static final void B(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = XEI.BB * -363202459;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "na.uf(" + ')');
      }
   }
}
