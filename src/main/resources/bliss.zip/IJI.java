public class IJI {
   LE Z;
   static int append = 1;
   XE method242;
   KJ toString;
   static int I = 0;
   static int C = 2;
   DA B = null;
   public int D;
   int F = 0;
   public static int J;
   public static int S;

   LE I(int var1) {
      try {
         return this.Z;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "dw.f(" + ')');
      }
   }

   XE Z(int var1) {
      try {
         return this.method242;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "dw.a(" + ')');
      }
   }

   public boolean I(byte var1) {
      try {
         return 1285026069 * this.F == 2;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "dw.p(" + ')');
      }
   }

   public boolean Z(byte var1) {
      try {
         K.I(-727077730);
         if (this.F * 1285026069 == 0) {
            this.Z = LE.I(this.toString, this.D * 1941368041, 0);
            if (this.Z == null) {
               return false;
            }

            this.B = new DA(EDI.C, EDI.Z);
            this.F = -1271605699;
         }

         if (1 == 1285026069 * this.F) {
            if (!this.method242.I(this.Z, EDI.G, this.B, 22050, -1303478218)) {
               return false;
            }

            this.F = 1751755898;
         }

         return true;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "dw.b(" + ')');
      }
   }

   public IJI(KJ var1, int var2) {
      this.toString = var1;
      this.D = -1830245543 * var2;
      this.method242 = new XE();
      this.method242.Z(9, 128, 346222187);
   }

   static final void I(OU var0, byte var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         var0.H[(var0.J += -391880689) * 681479919 - 1] = 840270937 * var3.UC;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "dw.pt(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = XQ.Z(2134288170).method242(694163818);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "dw.ahv(" + ')');
      }
   }

   static final void I(int var0, int var1, int var2, boolean var3, int var4) {
      try {
         if (KT.I(var0, (int[])null, -1346924535)) {
            YR.I(IU.F[var0].Z, -1, var1, var2, var3, (short)-10580);
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "dw.kv(" + ')');
      }
   }

   static void I(int var0, boolean var1, int var2) {
      try {
         VK var3 = IV.I(21, (long)var0);
         var3.I((byte)33);
         var3.L = 1274450087 * (var1 ? 1 : 0);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "dw.au(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         RD.I(var3, var4, true, 1, var0, 390526000);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "dw.ha(" + ')');
      }
   }
}
