public abstract class LEI {
   public int C;
   public int B;
   public int D;
   public int F;

   public abstract boolean method4089(int var1, int var2, int var3, XA var4);

   public abstract boolean method4090(int var1, int var2, int var3, XA var4, int var5);

   public abstract boolean method4091(int var1, int var2, int var3, XA var4);

   static final void C(OU var0, int var1) {
      try {
         var0.A -= 1938723502;
         String var2 = (String)var0.S[var0.A * -203050393];
         String var3 = (String)var0.S[-203050393 * var0.A + 1];
         if (var0.H[(var0.J -= -391880689) * 681479919] == 1) {
            var0.S[(var0.A += 969361751) * -203050393 - 1] = var2;
         } else {
            var0.S[(var0.A += 969361751) * -203050393 - 1] = var3;
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "nz.zj(" + ')');
      }
   }

   static void I(BP[][][] var0, int var1) {
      try {
         for(int var2 = 0; var2 < var0.length; ++var2) {
            BP[][] var3 = var0[var2];

            for(int var4 = 0; var4 < var3.length; ++var4) {
               for(int var5 = 0; var5 < var3[var4].length; ++var5) {
                  BP var6 = var3[var4][var5];
                  if (var6 == null) {
                     if (var1 >= 257433765) {
                        return;
                     }
                  } else {
                     if (var6.J instanceof HAI) {
                        ((HAI)var6.J).method31((byte)-5);
                     }

                     if (var6.D instanceof HAI) {
                        ((HAI)var6.D).method31((byte)-70);
                     }

                     if (var6.F instanceof HAI) {
                        ((HAI)var6.F).method31((byte)-47);
                     }

                     if (var6.C instanceof HAI) {
                        ((HAI)var6.C).method31((byte)-87);
                     }

                     if (var6.B instanceof HAI) {
                        ((HAI)var6.B).method31((byte)-107);
                     }

                     for(XO var7 = var6.Z; var7 != null; var7 = var7.C) {
                        ZR var8 = var7.Z;
                        if (var8 instanceof HAI) {
                           ((HAI)var8).method31((byte)-107);
                        }
                     }
                  }
               }
            }
         }

      } catch (RuntimeException var9) {
         throw DQ.I(var9, "nz.f(" + ')');
      }
   }

   static final void B(OU var0, byte var1) {
      try {
         int var2 = XEI.yC.Z(2031939050);
         if (-1 != -257444687 * XEI.xC) {
            ++var2;
         }

         var0.H[(var0.J += -391880689) * 681479919 - 1] = var2;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "nz.alp(" + ')');
      }
   }

   public static void I(int var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, byte var9) {
      try {
         if (var0 >= BT.D * -1424479739 && var0 <= BT.Z * 1135094847 && var2 >= BT.D * -1424479739 && var2 <= BT.Z * 1135094847 && var4 >= -1424479739 * BT.D && var4 <= BT.Z * 1135094847 && var6 >= -1424479739 * BT.D && var6 <= 1135094847 * BT.Z && var1 >= 1155384281 * BT.C && var1 <= -1062447355 * BT.B && var3 >= BT.C * 1155384281 && var3 <= BT.B * -1062447355 && var5 >= BT.C * 1155384281 && var5 <= BT.B * -1062447355 && var7 >= BT.C * 1155384281 && var7 <= BT.B * -1062447355) {
            BE.I(var0, var1, var2, var3, var4, var5, var6, var7, var8, (byte)-73);
         } else {
            HN.I(var0, var1, var2, var3, var4, var5, var6, var7, var8, 1173232309);
         }

      } catch (RuntimeException var11) {
         throw DQ.I(var11, "nz.l(" + ')');
      }
   }
}
