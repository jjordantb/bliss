import java.awt.Component;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public final class IP extends YO implements KeyListener, FocusListener {
   static int[] bI = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 85, 80, 84, 0, 91, 0, 0, 0, 81, 82, 86, 0, 0, 0, 0, 0, 0, 0, 0, 13, 0, 0, 0, 0, 83, 104, 105, 103, 102, 96, 98, 97, 99, 0, 0, 0, 0, 0, 0, 0, 25, 16, 17, 18, 19, 20, 21, 22, 23, 24, 0, 0, 0, 0, 0, 0, 0, 48, 68, 66, 50, 34, 51, 52, 53, 39, 54, 55, 56, 70, 69, 40, 41, 32, 35, 49, 36, 38, 67, 33, 65, 37, 64, 0, 0, 0, 0, 0, 228, 231, 227, 233, 224, 219, 225, 230, 226, 232, 89, 87, 0, 88, 229, 90, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 0, 0, 0, 101, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
   static int add = 128;
   IY addFocusListener = new IY();
   static int addKeyListener = 112;
   boolean[] consume = new boolean[112];
   Component getKeyChar;
   IY getKeyCode = new IY();

   void C(Component var1, byte var2) {
      try {
         this.J(-1697556244);
         this.getKeyChar = var1;
         this.getKeyChar.addKeyListener(this);
         this.getKeyChar.addFocusListener(this);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "acn.h(" + ')');
      }
   }

   void J(int var1) {
      try {
         if (this.getKeyChar != null) {
            this.getKeyChar.removeKeyListener(this);
            this.getKeyChar.removeFocusListener(this);
            this.getKeyChar = null;

            for(int var2 = 0; var2 < 112; ++var2) {
               this.consume[var2] = false;
            }

            this.addFocusListener.I((byte)1);
            this.getKeyCode.I((byte)1);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "acn.v(" + ')');
      }
   }

   void add(int var1, char var2, int var3, int var4) {
      try {
         EM var5 = new EM();
         var5.J = var1 * -492671955;
         var5.G = var2;
         var5.A = var3 * 666762723;
         var5.E = CI.I((byte)1) * -6780259989437506341L;
         this.getKeyCode.I((AE)var5, (int)-134660083);
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "acn.g(" + ')');
      }
   }

   public WSI method3937(byte var1) {
      try {
         return (WSI)this.addFocusListener.I(2081715499);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "acn.p(" + ')');
      }
   }

   public boolean method3936(int var1, int var2) {
      try {
         return var1 >= 0 && var1 < 112 ? this.consume[var1] : false;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "acn.b(" + ')');
      }
   }

   public void method3938(int var1) {
      try {
         this.J(-789412244);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "acn.i(" + ')');
      }
   }

   void addFocusListener(KeyEvent var1, int var2, int var3) {
      try {
         int var4 = var1.getKeyCode();
         if (var4 != 0) {
            if (var4 >= 0 && var4 < bI.length) {
               var4 = bI[var4];
               if (var2 == 0 && (var4 & 128) != 0) {
                  var4 = 0;
               } else {
                  var4 &= -129;
               }
            } else {
               var4 = 0;
            }
         } else {
            var4 = 0;
         }

         if (var4 != 0) {
            this.add(var2, '\uffff', var4, -2128667292);
            var1.consume();
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "acn.c(" + ')');
      }
   }

   public synchronized void method3942(int var1) {
      try {
         this.addFocusListener.I((byte)1);

         for(EM var2 = (EM)this.getKeyCode.I(2094124912); var2 != null; var2 = (EM)this.getKeyCode.I(2145579859)) {
            var2.S = this.addKeyListener(-2041069828) * -387842989;
            if (var2.J * 1490207653 == 0) {
               if (!this.consume[var2.A * 122236875]) {
                  EM var6 = new EM();
                  var6.J = 0;
                  var6.G = '\uffff';
                  var6.A = var2.A * 1;
                  var6.E = var2.E * 1L;
                  var6.S = 1 * var2.S;
                  this.addFocusListener.I((AE)var6, (int)1964794553);
                  this.consume[var2.A * 122236875] = true;
               }

               var2.J = -985343910;
               this.addFocusListener.I((AE)var2, (int)-407108127);
            } else if (1 == var2.J * 1490207653) {
               if (this.consume[var2.A * 122236875]) {
                  this.addFocusListener.I((AE)var2, (int)1996250465);
                  this.consume[var2.A * 122236875] = false;
               }
            } else if (1490207653 * var2.J == -1) {
               for(int var3 = 0; var3 < 112; ++var3) {
                  if (this.consume[var3]) {
                     EM var4 = new EM();
                     var4.J = -492671955;
                     var4.G = '\uffff';
                     var4.A = 666762723 * var3;
                     var4.E = 1L * var2.E;
                     var4.S = var2.S * 1;
                     this.addFocusListener.I((AE)var4, (int)98009925);
                     this.consume[var3] = false;
                  }
               }
            } else if (3 == var2.J * 1490207653) {
               this.addFocusListener.I((AE)var2, (int)1631613634);
            }
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "acn.f(" + ')');
      }
   }

   public synchronized void keyReleased(KeyEvent var1) {
      try {
         XEI.V.add((byte)var1.getKeyCode());
         this.addFocusListener(var1, 1, 1838328599);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "acn.keyReleased(" + ')');
      }
   }

   public synchronized void keyTyped(KeyEvent var1) {
      try {
         char var2 = var1.getKeyChar();
         if (var2 != '\uffff' && GU.I(var2, 503878234)) {
            this.add(3, var2, -1, -1849643187);
            var1.consume();
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "acn.keyTyped(" + ')');
      }
   }

   public void focusGained(FocusEvent var1) {
   }

   int addKeyListener(int var1) {
      try {
         int var2 = 0;
         if (this.consume[81]) {
            var2 |= 1;
         }

         if (this.consume[82]) {
            var2 |= 4;
         }

         if (this.consume[86]) {
            var2 |= 2;
         }

         return var2;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "acn.e(" + ')');
      }
   }

   public synchronized void focusLost(FocusEvent var1) {
      try {
         this.add(-1, '\u0000', 0, -1444007331);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "acn.focusLost(" + ')');
      }
   }

   public WSI method3939() {
      return (WSI)this.addFocusListener.I(2115276453);
   }

   public void method3943() {
      this.J(560458852);
   }

   public WSI method3940() {
      return (WSI)this.addFocusListener.I(2103688875);
   }

   IP(Component var1) {
      TDI.I((byte)-1);
      this.C(var1, (byte)0);
   }

   public void method3934() {
      this.J(1992664348);
   }

   public synchronized void keyPressed(KeyEvent var1) {
      try {
         this.addFocusListener(var1, 0, 1184410257);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "acn.keyPressed(" + ')');
      }
   }

   public void method3941() {
      this.J(-743392356);
   }

   public synchronized void method3935() {
      this.addFocusListener.I((byte)1);

      for(EM var1 = (EM)this.getKeyCode.I(2122541864); var1 != null; var1 = (EM)this.getKeyCode.I(2131772835)) {
         var1.S = this.addKeyListener(-1895745792) * -387842989;
         if (var1.J * 1490207653 == 0) {
            if (!this.consume[var1.A * 122236875]) {
               EM var4 = new EM();
               var4.J = 0;
               var4.G = '\uffff';
               var4.A = var1.A * 1;
               var4.E = var1.E * 1L;
               var4.S = 1 * var1.S;
               this.addFocusListener.I((AE)var4, (int)1485790720);
               this.consume[var1.A * 122236875] = true;
            }

            var1.J = -985343910;
            this.addFocusListener.I((AE)var1, (int)1477219467);
         } else if (1 == var1.J * 1490207653) {
            if (this.consume[var1.A * 122236875]) {
               this.addFocusListener.I((AE)var1, (int)1423768539);
               this.consume[var1.A * 122236875] = false;
            }
         } else if (1490207653 * var1.J == -1) {
            for(int var2 = 0; var2 < 112; ++var2) {
               if (this.consume[var2]) {
                  EM var3 = new EM();
                  var3.J = -492671955;
                  var3.G = '\uffff';
                  var3.A = 666762723 * var2;
                  var3.E = 1L * var1.E;
                  var3.S = var1.S * 1;
                  this.addFocusListener.I((AE)var3, (int)1448812234);
                  this.consume[var2] = false;
               }
            }
         } else if (3 == var1.J * 1490207653) {
            this.addFocusListener.I((AE)var1, (int)1538711449);
         }
      }

   }

   public synchronized void method3944() {
      this.addFocusListener.I((byte)1);

      for(EM var1 = (EM)this.getKeyCode.I(2115108568); var1 != null; var1 = (EM)this.getKeyCode.I(2096117527)) {
         var1.S = this.addKeyListener(-1945297664) * -387842989;
         if (var1.J * 1490207653 == 0) {
            if (!this.consume[var1.A * 122236875]) {
               EM var4 = new EM();
               var4.J = 0;
               var4.G = '\uffff';
               var4.A = var1.A * 1;
               var4.E = var1.E * 1L;
               var4.S = 1 * var1.S;
               this.addFocusListener.I((AE)var4, (int)957532762);
               this.consume[var1.A * 122236875] = true;
            }

            var1.J = -985343910;
            this.addFocusListener.I((AE)var1, (int)568318912);
         } else if (1 == var1.J * 1490207653) {
            if (this.consume[var1.A * 122236875]) {
               this.addFocusListener.I((AE)var1, (int)953828364);
               this.consume[var1.A * 122236875] = false;
            }
         } else if (1490207653 * var1.J == -1) {
            for(int var2 = 0; var2 < 112; ++var2) {
               if (this.consume[var2]) {
                  EM var3 = new EM();
                  var3.J = -492671955;
                  var3.G = '\uffff';
                  var3.A = 666762723 * var2;
                  var3.E = 1L * var1.E;
                  var3.S = var1.S * 1;
                  this.addFocusListener.I((AE)var3, (int)961213075);
                  this.consume[var2] = false;
               }
            }
         } else if (3 == var1.J * 1490207653) {
            this.addFocusListener.I((AE)var1, (int)287234432);
         }
      }

   }

   public boolean method3945(int var1) {
      return var1 >= 0 && var1 < 112 ? this.consume[var1] : false;
   }

   public static void I(int var0, int var1, int var2) {
      try {
         if (617004265 * EDI.I != 0) {
            if (var0 < 0) {
               for(int var3 = 0; var3 < 16; ++var3) {
                  GE.J[var3] = var1;
               }
            } else {
               GE.J[var0] = var1;
            }
         }

         EDI.B.I(var0, var1, 852255594);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "acn.u(" + ')');
      }
   }
}
