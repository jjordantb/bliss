public class EP {
   static int I = 2;
   int Z = 0;
   GP C;
   static int B = 38400;
   static int D = 1;
   static int F = 8;
   int J;
   static int S = 12;
   static int A = 2001;
   static int E = -2001;

   final boolean I(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9) {
      if (var1 <= 2001 && var2 <= 2001 && var3 <= 2001 && var4 <= 2001 && var5 <= 2001 && var6 <= 2001) {
         if (var1 >= -2001 && var2 >= -2001 && var3 >= -2001 && var4 >= -2001 && var5 >= -2001 && var6 >= -2001) {
            int var10;
            if (this.J == 2) {
               var10 = var4 + var1 * this.C.X;
               if (var10 >= 0 && var10 < this.C.T.length && (var7 << 8) - '阀' < this.C.T[var10]) {
                  return false;
               }

               var10 = var5 + var2 * this.C.X;
               if (var10 >= 0 && var10 < this.C.T.length && (var8 << 8) - '阀' < this.C.T[var10]) {
                  return false;
               }

               var10 = var6 + var3 * this.C.X;
               if (var10 >= 0 && var10 < this.C.T.length && (var9 << 8) - '阀' < this.C.T[var10]) {
                  return false;
               }
            }

            var10 = var5 - var4;
            int var11 = var2 - var1;
            int var12 = var6 - var4;
            int var13 = var3 - var1;
            int var14 = var8 - var7;
            int var15 = var9 - var7;
            if (var1 < var2 && var3 < var3) {
               --var1;
               if (var2 > var3) {
                  ++var2;
               } else {
                  ++var3;
               }
            } else if (var2 < var3) {
               --var2;
               if (var1 > var3) {
                  ++var1;
               } else {
                  ++var3;
               }
            } else {
               --var3;
               if (var1 > var2) {
                  ++var1;
               } else {
                  ++var2;
               }
            }

            int var16 = 0;
            if (var2 != var1) {
               var16 = (var5 - var4 << 12) / (var2 - var1);
            }

            int var17 = 0;
            if (var3 != var2) {
               var17 = (var6 - var5 << 12) / (var3 - var2);
            }

            int var18 = 0;
            if (var3 != var1) {
               var18 = (var4 - var6 << 12) / (var1 - var3);
            }

            int var19 = var10 * var13 - var12 * var11;
            if (var19 == 0) {
               return false;
            } else {
               int var20 = (var14 * var13 - var15 * var11 << 8) / var19;
               int var21 = (var15 * var10 - var14 * var12 << 8) / var19;
               if (var1 <= var2 && var1 <= var3) {
                  if (var1 >= this.C.Y) {
                     return true;
                  } else {
                     if (var2 > this.C.Y) {
                        var2 = this.C.Y;
                     }

                     if (var3 > this.C.Y) {
                        var3 = this.C.Y;
                     }

                     var7 = (var7 << 8) - var20 * var4 + var20;
                     if (var2 < var3) {
                        var6 = var4 <<= 12;
                        if (var1 < 0) {
                           var6 -= var18 * var1;
                           var4 -= var16 * var1;
                           var7 -= var21 * var1;
                           var1 = 0;
                        }

                        var5 <<= 12;
                        if (var2 < 0) {
                           var5 -= var17 * var2;
                           var2 = 0;
                        }

                        if (var1 != var2 && var18 < var16 || var1 == var2 && var18 > var17) {
                           var3 -= var2;
                           var2 -= var1;
                           var1 *= this.C.X;

                           while(true) {
                              --var2;
                              if (var2 < 0) {
                                 while(true) {
                                    --var3;
                                    if (var3 < 0) {
                                       return true;
                                    }

                                    if (!this.I(this.C.T, var1, 0, (var6 >> 12) - 1, (var5 >> 12) + 1, var7, var20, this.C.X)) {
                                       return false;
                                    }

                                    var6 += var18;
                                    var5 += var17;
                                    var7 += var21;
                                    var1 += this.C.X;
                                 }
                              }

                              if (!this.I(this.C.T, var1, 0, (var6 >> 12) - 1, (var4 >> 12) + 1, var7, var20, this.C.X)) {
                                 return false;
                              }

                              var6 += var18;
                              var4 += var16;
                              var7 += var21;
                              var1 += this.C.X;
                           }
                        } else {
                           var3 -= var2;
                           var2 -= var1;
                           var1 *= this.C.X;

                           while(true) {
                              --var2;
                              if (var2 < 0) {
                                 while(true) {
                                    --var3;
                                    if (var3 < 0) {
                                       return true;
                                    }

                                    if (!this.I(this.C.T, var1, 0, (var5 >> 12) - 1, (var6 >> 12) + 1, var7, var20, this.C.X)) {
                                       return false;
                                    }

                                    var6 += var18;
                                    var5 += var17;
                                    var7 += var21;
                                    var1 += this.C.X;
                                 }
                              }

                              if (!this.I(this.C.T, var1, 0, (var4 >> 12) - 1, (var6 >> 12) + 1, var7, var20, this.C.X)) {
                                 return false;
                              }

                              var6 += var18;
                              var4 += var16;
                              var7 += var21;
                              var1 += this.C.X;
                           }
                        }
                     } else {
                        var5 = var4 <<= 12;
                        if (var1 < 0) {
                           var5 -= var18 * var1;
                           var4 -= var16 * var1;
                           var7 -= var21 * var1;
                           var1 = 0;
                        }

                        var6 <<= 12;
                        if (var3 < 0) {
                           var6 -= var17 * var3;
                           var3 = 0;
                        }

                        if ((var1 == var3 || var18 >= var16) && (var1 != var3 || var17 <= var16)) {
                           var2 -= var3;
                           var3 -= var1;
                           var1 *= this.C.X;

                           while(true) {
                              --var3;
                              if (var3 < 0) {
                                 while(true) {
                                    --var2;
                                    if (var2 < 0) {
                                       return true;
                                    }

                                    if (!this.I(this.C.T, var1, 0, (var4 >> 12) - 1, (var6 >> 12) + 1, var7, var20, this.C.X)) {
                                       return false;
                                    }

                                    var6 += var17;
                                    var4 += var16;
                                    var7 += var21;
                                    var1 += this.C.X;
                                 }
                              }

                              if (!this.I(this.C.T, var1, 0, (var4 >> 12) - 1, (var5 >> 12) + 1, var7, var20, this.C.X)) {
                                 return false;
                              }

                              var5 += var18;
                              var4 += var16;
                              var7 += var21;
                              var1 += this.C.X;
                           }
                        } else {
                           var2 -= var3;
                           var3 -= var1;
                           var1 *= this.C.X;

                           while(true) {
                              --var3;
                              if (var3 < 0) {
                                 while(true) {
                                    --var2;
                                    if (var2 < 0) {
                                       return true;
                                    }

                                    if (!this.I(this.C.T, var1, 0, (var6 >> 12) - 1, (var4 >> 12) + 1, var7, var20, this.C.X)) {
                                       return false;
                                    }

                                    var6 += var17;
                                    var4 += var16;
                                    var7 += var21;
                                    var1 += this.C.X;
                                 }
                              }

                              if (!this.I(this.C.T, var1, 0, (var5 >> 12) - 1, (var4 >> 12) + 1, var7, var20, this.C.X)) {
                                 return false;
                              }

                              var5 += var18;
                              var4 += var16;
                              var7 += var21;
                              var1 += this.C.X;
                           }
                        }
                     }
                  }
               } else if (var2 <= var3) {
                  if (var2 >= this.C.Y) {
                     return true;
                  } else {
                     if (var3 > this.C.Y) {
                        var3 = this.C.Y;
                     }

                     if (var1 > this.C.Y) {
                        var1 = this.C.Y;
                     }

                     var8 = (var8 << 8) - var20 * var5 + var20;
                     if (var3 < var1) {
                        var4 = var5 <<= 12;
                        if (var2 < 0) {
                           var4 -= var16 * var2;
                           var5 -= var17 * var2;
                           var8 -= var21 * var2;
                           var2 = 0;
                        }

                        var6 <<= 12;
                        if (var3 < 0) {
                           var6 -= var18 * var3;
                           var3 = 0;
                        }

                        if (var2 != var3 && var16 < var17 || var2 == var3 && var16 > var18) {
                           var1 -= var3;
                           var3 -= var2;
                           var2 *= this.C.X;

                           while(true) {
                              --var3;
                              if (var3 < 0) {
                                 while(true) {
                                    --var1;
                                    if (var1 < 0) {
                                       return true;
                                    }

                                    if (!this.I(this.C.T, var2, 0, (var4 >> 12) - 1, (var6 >> 12) + 1, var8, var20, this.C.X)) {
                                       return false;
                                    }

                                    var4 += var16;
                                    var6 += var18;
                                    var8 += var21;
                                    var2 += this.C.X;
                                 }
                              }

                              if (!this.I(this.C.T, var2, 0, (var4 >> 12) - 1, (var5 >> 12) + 1, var8, var20, this.C.X)) {
                                 return false;
                              }

                              var4 += var16;
                              var5 += var17;
                              var8 += var21;
                              var2 += this.C.X;
                           }
                        } else {
                           var1 -= var3;
                           var3 -= var2;
                           var2 *= this.C.X;

                           while(true) {
                              --var3;
                              if (var3 < 0) {
                                 while(true) {
                                    --var1;
                                    if (var1 < 0) {
                                       return true;
                                    }

                                    if (!this.I(this.C.T, var2, 0, (var6 >> 12) - 1, (var4 >> 12) + 1, var8, var20, this.C.X)) {
                                       return false;
                                    }

                                    var4 += var16;
                                    var6 += var18;
                                    var8 += var21;
                                    var2 += this.C.X;
                                 }
                              }

                              if (!this.I(this.C.T, var2, 0, (var5 >> 12) - 1, (var4 >> 12) + 1, var8, var20, this.C.X)) {
                                 return false;
                              }

                              var4 += var16;
                              var5 += var17;
                              var8 += var21;
                              var2 += this.C.X;
                           }
                        }
                     } else {
                        var6 = var5 <<= 12;
                        if (var2 < 0) {
                           var6 -= var16 * var2;
                           var5 -= var17 * var2;
                           var8 -= var21 * var2;
                           var2 = 0;
                        }

                        var4 <<= 12;
                        if (var1 < 0) {
                           var4 -= var18 * var1;
                           var1 = 0;
                        }

                        if (var16 < var17) {
                           var3 -= var1;
                           var1 -= var2;
                           var2 *= this.C.X;

                           while(true) {
                              --var1;
                              if (var1 < 0) {
                                 while(true) {
                                    --var3;
                                    if (var3 < 0) {
                                       return true;
                                    }

                                    if (!this.I(this.C.T, var2, 0, (var4 >> 12) - 1, (var5 >> 12) + 1, var8, var20, this.C.X)) {
                                       return false;
                                    }

                                    var4 += var18;
                                    var5 += var17;
                                    var8 += var21;
                                    var2 += this.C.X;
                                 }
                              }

                              if (!this.I(this.C.T, var2, 0, (var6 >> 12) - 1, (var5 >> 12) + 1, var8, var20, this.C.X)) {
                                 return false;
                              }

                              var6 += var16;
                              var5 += var17;
                              var8 += var21;
                              var2 += this.C.X;
                           }
                        } else {
                           var3 -= var1;
                           var1 -= var2;
                           var2 *= this.C.X;

                           while(true) {
                              --var1;
                              if (var1 < 0) {
                                 while(true) {
                                    --var3;
                                    if (var3 < 0) {
                                       return true;
                                    }

                                    if (!this.I(this.C.T, var2, 0, (var5 >> 12) - 1, (var4 >> 12) + 1, var8, var20, this.C.X)) {
                                       return false;
                                    }

                                    var4 += var18;
                                    var5 += var17;
                                    var8 += var21;
                                    var2 += this.C.X;
                                 }
                              }

                              if (!this.I(this.C.T, var2, 0, (var5 >> 12) - 1, (var6 >> 12) + 1, var8, var20, this.C.X)) {
                                 return false;
                              }

                              var6 += var16;
                              var5 += var17;
                              var8 += var21;
                              var2 += this.C.X;
                           }
                        }
                     }
                  }
               } else if (var3 >= this.C.Y) {
                  return true;
               } else {
                  if (var1 > this.C.Y) {
                     var1 = this.C.Y;
                  }

                  if (var2 > this.C.Y) {
                     var2 = this.C.Y;
                  }

                  var9 = (var9 << 8) - var20 * var6 + var20;
                  if (var1 < var2) {
                     var5 = var6 <<= 12;
                     if (var3 < 0) {
                        var5 -= var17 * var3;
                        var6 -= var18 * var3;
                        var9 -= var21 * var3;
                        var3 = 0;
                     }

                     var4 <<= 12;
                     if (var1 < 0) {
                        var4 -= var16 * var1;
                        var1 = 0;
                     }

                     if (var17 < var18) {
                        var2 -= var1;
                        var1 -= var3;
                        var3 *= this.C.X;

                        while(true) {
                           --var1;
                           if (var1 < 0) {
                              while(true) {
                                 --var2;
                                 if (var2 < 0) {
                                    return true;
                                 }

                                 if (!this.I(this.C.T, var3, 0, (var5 >> 12) - 1, (var4 >> 12) + 1, var9, var20, this.C.X)) {
                                    return false;
                                 }

                                 var5 += var17;
                                 var4 += var16;
                                 var9 += var21;
                                 var3 += this.C.X;
                              }
                           }

                           if (!this.I(this.C.T, var3, 0, (var5 >> 12) - 1, (var6 >> 12) + 1, var9, var20, this.C.X)) {
                              return false;
                           }

                           var5 += var17;
                           var6 += var18;
                           var9 += var21;
                           var3 += this.C.X;
                        }
                     } else {
                        var2 -= var1;
                        var1 -= var3;
                        var3 *= this.C.X;

                        while(true) {
                           --var1;
                           if (var1 < 0) {
                              while(true) {
                                 --var2;
                                 if (var2 < 0) {
                                    return true;
                                 }

                                 if (!this.I(this.C.T, var3, 0, (var4 >> 12) - 1, (var5 >> 12) + 1, var9, var20, this.C.X)) {
                                    return false;
                                 }

                                 var5 += var17;
                                 var4 += var16;
                                 var9 += var21;
                                 var3 += this.C.X;
                              }
                           }

                           if (!this.I(this.C.T, var3, 0, (var6 >> 12) - 1, (var5 >> 12) + 1, var9, var20, this.C.X)) {
                              return false;
                           }

                           var5 += var17;
                           var6 += var18;
                           var9 += var21;
                           var3 += this.C.X;
                        }
                     }
                  } else {
                     var4 = var6 <<= 12;
                     if (var3 < 0) {
                        var4 -= var17 * var3;
                        var6 -= var18 * var3;
                        var9 -= var21 * var3;
                        var3 = 0;
                     }

                     var5 <<= 12;
                     if (var2 < 0) {
                        var5 -= var16 * var2;
                        var2 = 0;
                     }

                     if (var17 < var18) {
                        var1 -= var2;
                        var2 -= var3;
                        var3 *= this.C.X;

                        while(true) {
                           --var2;
                           if (var2 < 0) {
                              while(true) {
                                 --var1;
                                 if (var1 < 0) {
                                    return true;
                                 }

                                 if (!this.I(this.C.T, var3, 0, (var5 >> 12) - 1, (var6 >> 12) + 1, var9, var20, this.C.X)) {
                                    return false;
                                 }

                                 var5 += var16;
                                 var6 += var18;
                                 var9 += var21;
                                 var3 += this.C.X;
                              }
                           }

                           if (!this.I(this.C.T, var3, 0, (var4 >> 12) - 1, (var6 >> 12) + 1, var9, var20, this.C.X)) {
                              return false;
                           }

                           var4 += var17;
                           var6 += var18;
                           var9 += var21;
                           var3 += this.C.X;
                        }
                     } else {
                        var1 -= var2;
                        var2 -= var3;
                        var3 *= this.C.X;

                        while(true) {
                           --var2;
                           if (var2 < 0) {
                              while(true) {
                                 --var1;
                                 if (var1 < 0) {
                                    return true;
                                 }

                                 if (!this.I(this.C.T, var3, 0, (var6 >> 12) - 1, (var5 >> 12) + 1, var9, var20, this.C.X)) {
                                    return false;
                                 }

                                 var5 += var16;
                                 var6 += var18;
                                 var9 += var21;
                                 var3 += this.C.X;
                              }
                           }

                           if (!this.I(this.C.T, var3, 0, (var6 >> 12) - 1, (var4 >> 12) + 1, var9, var20, this.C.X)) {
                              return false;
                           }

                           var4 += var17;
                           var6 += var18;
                           var9 += var21;
                           var3 += this.C.X;
                        }
                     }
                  }
               }
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   EP(GP var1) {
      this.C = var1;
   }

   final boolean I(int[] var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      if (var5 > var8) {
         var5 = var8;
      }

      if (var4 < 0) {
         var4 = 0;
      }

      if (var4 >= var5) {
         return true;
      } else {
         var2 += var4 - 1;
         var3 = var5 - var4 >> 2;
         var6 += var7 * var4;
         if (this.J == 1) {
            this.Z += var3;

            while(true) {
               --var3;
               if (var3 < 0) {
                  var3 = var5 - var4 & 3;

                  while(true) {
                     --var3;
                     if (var3 < 0) {
                        return true;
                     }

                     ++var2;
                     if (var6 < var1[var2]) {
                        var1[var2] = var6;
                     }

                     var6 += var7;
                  }
               }

               ++var2;
               if (var6 < var1[var2]) {
                  var1[var2] = var6;
               }

               var6 += var7;
               ++var2;
               if (var6 < var1[var2]) {
                  var1[var2] = var6;
               }

               var6 += var7;
               ++var2;
               if (var6 < var1[var2]) {
                  var1[var2] = var6;
               }

               var6 += var7;
               ++var2;
               if (var6 < var1[var2]) {
                  var1[var2] = var6;
               }

               var6 += var7;
            }
         } else {
            var6 -= 38400;

            while(true) {
               --var3;
               if (var3 < 0) {
                  var3 = var5 - var4 & 3;

                  while(true) {
                     --var3;
                     if (var3 < 0) {
                        return true;
                     }

                     ++var2;
                     if (var6 < var1[var2]) {
                        return false;
                     }

                     var6 += var7;
                  }
               }

               ++var2;
               if (var6 < var1[var2]) {
                  return false;
               }

               var6 += var7;
               ++var2;
               if (var6 < var1[var2]) {
                  return false;
               }

               var6 += var7;
               ++var2;
               if (var6 < var1[var2]) {
                  return false;
               }

               var6 += var7;
               ++var2;
               if (var6 < var1[var2]) {
                  return false;
               }

               var6 += var7;
            }
         }
      }
   }
}
