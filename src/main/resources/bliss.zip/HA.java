public class HA {
   int I;
   int[] Z = new int[2];
   int[] C = new int[2];
   int B;
   int D;
   int F;
   int J;
   int S;
   int A;
   int E = 2;
   int G;

   final int I(int var1) {
      if (this.G >= this.J) {
         this.I = this.C[this.S++] << 15;
         if (this.S >= this.E) {
            this.S = this.E - 1;
         }

         this.J = (int)((double)this.Z[this.S] / 65536.0D * (double)var1);
         if (this.J > this.G) {
            this.A = ((this.C[this.S] << 15) - this.I) / (this.J - this.G);
         }
      }

      this.I += this.A;
      ++this.G;
      return this.I - this.A >> 15;
   }

   final void I(REI var1) {
      this.F = var1.I();
      this.B = var1.H((byte)10);
      this.D = var1.H((byte)-71);
      this.Z(var1);
   }

   final void Z(REI var1) {
      this.E = var1.I();
      this.Z = new int[this.E];
      this.C = new int[this.E];

      for(int var2 = 0; var2 < this.E; ++var2) {
         this.Z[var2] = var1.C();
         this.C[var2] = var1.C();
      }

   }

   final void I() {
      this.J = 0;
      this.S = 0;
      this.A = 0;
      this.I = 0;
      this.G = 0;
   }

   HA() {
      this.Z[0] = 0;
      this.Z[1] = 65535;
      this.C[0] = 0;
      this.C[1] = 65535;
   }
}
