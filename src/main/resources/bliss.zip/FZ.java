public abstract class FZ {
   protected float I;
   public int Z;
   public SF C = new SF();
   public float[] B = new float[16];
   public CEI D;
   public ZEI F;
   public YF J = new YF();
   protected NJI S;
   protected float A;
   public SF E = new SF();
   public XF G = new XF();
   public SF H = new SF();
   public XF K = new XF();
   public float[] L = new float[16];
   public SF M = new SF();
   public SF N = new SF();
   public SF O = new SF();
   public SF P = new SF();
   static int Q = 4;
   public int R;
   public int T;
   public int U;
   public YF V = new YF();

   public abstract void method1503(int var1);

   public abstract void method1504(boolean var1);

   public abstract void method1505(int var1);

   public abstract void method1506(YF var1);

   public abstract void method1507(int var1);

   public abstract void method1508(int var1);

   public void I(WCI var1) {
      switch(var1.K) {
      case 1:
         this.A = 32.0F;
         this.I = 0.5F;
         break;
      case 2:
         this.A = 4.0F;
         this.I = 0.65F;
         break;
      case 3:
         this.A = 2.0F;
         this.I = 0.8F;
      }

   }

   public abstract void method1510();

   public abstract void method1511(YF var1);

   public abstract void method1512(YF var1);

   public abstract void method1513(boolean var1);

   public abstract void method1514(boolean var1);

   public abstract void method1515(boolean var1);

   public abstract void method1516(int var1);

   public abstract void method1517(int var1);

   public abstract void method1518(int var1);

   public abstract void method1519();

   public abstract void method1520(int var1);

   public abstract void method1521(int var1);

   FZ(NJI var1) {
      this.S = var1;
   }
}
