public class AH extends YG {
   static boolean Q = false;
   static int R = 4;
   int T = -882583092;
   int U = 1743781396;

   int[][] append(int var1) {
      int[][] var2 = this.L.I(var1, (byte)75);
      if (this.L.I) {
         int var3 = -1474554145 * WJ.C / (-277601971 * this.U);
         int var4 = WJ.B * 461985445 / (1955421883 * this.T);
         int[][] var5;
         if (var4 > 0) {
            int var6 = var1 % var4;
            var5 = this.I(0, var6 * 461985445 * WJ.B / var4, (byte)8);
         } else {
            var5 = this.I(0, 0, (byte)8);
         }

         int[] var15 = var5[0];
         int[] var7 = var5[1];
         int[] var8 = var5[2];
         int[] var9 = var2[0];
         int[] var10 = var2[1];
         int[] var11 = var2[2];

         for(int var12 = 0; var12 < WJ.C * -1474554145; ++var12) {
            int var13;
            if (var3 > 0) {
               int var14 = var12 % var3;
               var13 = -1474554145 * WJ.C * var14 / var3;
            } else {
               var13 = 0;
            }

            var9[var12] = var15[var13];
            var10[var12] = var7[var13];
            var11[var12] = var8[var13];
         }
      }

      return var2;
   }

   public AH() {
      super(1, false);
   }

   void I(int var1, REI var2, byte var3) {
      try {
         switch(var1) {
         case 0:
            this.U = var2.I() * -637796475;
            break;
         case 1:
            this.T = var2.I() * 853096051;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ahe.r(" + ')');
      }
   }

   int[][] I(int var1, byte var2) {
      try {
         int[][] var3 = this.L.I(var1, (byte)34);
         if (this.L.I) {
            int var4 = -1474554145 * WJ.C / (-277601971 * this.U);
            int var5 = WJ.B * 461985445 / (1955421883 * this.T);
            int[][] var6;
            if (var5 > 0) {
               int var7 = var1 % var5;
               var6 = this.I(0, var7 * 461985445 * WJ.B / var5, (byte)8);
            } else {
               var6 = this.I(0, 0, (byte)8);
            }

            int[] var17 = var6[0];
            int[] var8 = var6[1];
            int[] var9 = var6[2];
            int[] var10 = var3[0];
            int[] var11 = var3[1];
            int[] var12 = var3[2];

            for(int var13 = 0; var13 < WJ.C * -1474554145; ++var13) {
               int var14;
               if (var4 > 0) {
                  int var15 = var13 % var4;
                  var14 = -1474554145 * WJ.C * var15 / var4;
               } else {
                  var14 = 0;
               }

               var10[var13] = var17[var14];
               var11[var13] = var8[var14];
               var12[var13] = var9[var14];
            }
         }

         return var3;
      } catch (RuntimeException var16) {
         throw DQ.I(var16, "ahe.k(" + ')');
      }
   }

   int[] toString(int var1) {
      int[] var2 = this.P.I(var1, 1514427827);
      if (this.P.D) {
         int var3 = WJ.C * -1474554145 / (-277601971 * this.U);
         int var4 = WJ.B * 461985445 / (1955421883 * this.T);
         int[] var5;
         int var6;
         if (var4 > 0) {
            var6 = var1 % var4;
            var5 = this.I(0, var6 * WJ.B * 461985445 / var4, -1887337990);
         } else {
            var5 = this.I(0, 0, -1887337990);
         }

         for(var6 = 0; var6 < WJ.C * -1474554145; ++var6) {
            if (var3 > 0) {
               int var7 = var6 % var3;
               var2[var6] = var5[var7 * -1474554145 * WJ.C / var3];
            } else {
               var2[var6] = var5[0];
            }
         }
      }

      return var2;
   }

   int[] Z(int var1, int var2) {
      try {
         int[] var3 = this.P.I(var1, 1438029248);
         if (this.P.D) {
            int var4 = WJ.C * -1474554145 / (-277601971 * this.U);
            int var5 = WJ.B * 461985445 / (1955421883 * this.T);
            int[] var6;
            int var7;
            if (var5 > 0) {
               var7 = var1 % var5;
               var6 = this.I(0, var7 * WJ.B * 461985445 / var5, -1887337990);
            } else {
               var6 = this.I(0, 0, -1887337990);
            }

            for(var7 = 0; var7 < WJ.C * -1474554145; ++var7) {
               if (var4 > 0) {
                  int var8 = var7 % var4;
                  var3[var7] = var6[var8 * -1474554145 * WJ.C / var4];
               } else {
                  var3[var7] = var6[0];
               }
            }
         }

         return var3;
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "ahe.i(" + ')');
      }
   }

   void append(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.U = var2.I() * -637796475;
         break;
      case 1:
         this.T = var2.I() * 853096051;
      }

   }

   void toString(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.U = var2.I() * -637796475;
         break;
      case 1:
         this.T = var2.I() * 853096051;
      }

   }

   int[] D(int var1) {
      int[] var2 = this.P.I(var1, 20761856);
      if (this.P.D) {
         int var3 = WJ.C * -1474554145 / (-277601971 * this.U);
         int var4 = WJ.B * 461985445 / (1955421883 * this.T);
         int[] var5;
         int var6;
         if (var4 > 0) {
            var6 = var1 % var4;
            var5 = this.I(0, var6 * WJ.B * 461985445 / var4, -1887337990);
         } else {
            var5 = this.I(0, 0, -1887337990);
         }

         for(var6 = 0; var6 < WJ.C * -1474554145; ++var6) {
            if (var3 > 0) {
               int var7 = var6 % var3;
               var2[var6] = var5[var7 * -1474554145 * WJ.C / var3];
            } else {
               var2[var6] = var5[0];
            }
         }
      }

      return var2;
   }

   int[][] F(int var1) {
      int[][] var2 = this.L.I(var1, (byte)53);
      if (this.L.I) {
         int var3 = -1474554145 * WJ.C / (-277601971 * this.U);
         int var4 = WJ.B * 461985445 / (1955421883 * this.T);
         int[][] var5;
         if (var4 > 0) {
            int var6 = var1 % var4;
            var5 = this.I(0, var6 * 461985445 * WJ.B / var4, (byte)8);
         } else {
            var5 = this.I(0, 0, (byte)8);
         }

         int[] var15 = var5[0];
         int[] var7 = var5[1];
         int[] var8 = var5[2];
         int[] var9 = var2[0];
         int[] var10 = var2[1];
         int[] var11 = var2[2];

         for(int var12 = 0; var12 < WJ.C * -1474554145; ++var12) {
            int var13;
            if (var3 > 0) {
               int var14 = var12 % var3;
               var13 = -1474554145 * WJ.C * var14 / var3;
            } else {
               var13 = 0;
            }

            var9[var12] = var15[var13];
            var10[var12] = var7[var13];
            var11[var12] = var8[var13];
         }
      }

      return var2;
   }
}
