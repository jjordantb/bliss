import java.math.BigInteger;

public class AZI {
   static BigInteger I = new BigInteger("10001", 16);
   public static BigInteger Z;
   public static BigInteger C;
   static String[] F = new String[]{"90338093857142919815298021898820722703064281662908805223664", "90088181005667406432658849985153228117526719275077030208801461379427558042560357151", "7030310374801460155709380237447132184049226481150590917170916139154583698227892805450136977038808082395", "796679761291594046331291081426834840830187693291343533346876893", "9246d9c7c5037426c7dd3e91f727ac10ca4e0c5c60760ff20201c9ff6d3f6a5e25c352b59e1336", "4497e01c182d5e2a2cfacd63871a52d56d0c9aa5e9916d31d87ba3cd88fa0b83b44fb26ce0fe5460c2f1b2b44d433d297047e643", "2c84864f89a8b83d43402cac854ec0436356d54c994d63306086159fa65b319e307aef815162443137f80c2876049a95549fdf7edb0c2ad75b39586c12c1b3abd06d9652addae6021c2fce", "9edd2db4fa6a2a6882931fba2817f1c9faebcf72701d917b105f5ff1708e3b5529279a20e54be7aad9faa3f8331ea3d5ee308c3882c35ecf0692", "09d75d32340eb2a2bc6919e315c003df93ae2288f52a2e68bd981fe32c7c7bcc305cf44fd00a52e6bcaaaf791875156e94a494bb5e3628106d64600ea", "5f423aa1859a136cb0b3fa05260b616681e57030e9fb8fc4e139df5369874eb5518bcd8325dc4df05730be59b5939d30464507567a5c8cdbe6d1607fc0907d781", "be51a694cdd56acdb7dc62e930842d42e7fb0aef1a9b0f937cb1c3f8c8b1ad433353eb907e0dddd6b6a3269da319ba8899fb3dcd390", "11c205fbb9bed2335915a98ef9bb656420fc0dc2c18f90adc427f6a66a1f920c275b8ea027db03b874ccff7ff955b75c999ac232fc7ccfef3df6f34", "b1213a07bdd72add252966d5906d93ad70272b4e3277b31ddaecf0d750a53e17dcfc1490133ee03107870d6bfd2e63cf99fb", "107144396184599817873812890799890829596177339832441421545320582402536316", "091228534387301402803358235312099581004262123197858262973099112304039738516", "1079524628864903668263741990170858822604363995889144574408165458662637075098659421700", "41392411172735509113532306933100803393437440393318482310611108445137632871551"};
   static BigInteger B;

   static {
      B = new BigInteger(F[0] + F[1] + F[2] + F[3]);
      C = new BigInteger("10001", 16);
      Z = Loader.usingRS ? new BigInteger(F[4] + F[5] + F[6] + F[7] + F[8] + F[9] + F[10] + F[11] + F[12], 16) : new BigInteger(F[13] + F[14] + F[15] + F[16]);
      new BigInteger("10001", 16);
      new BigInteger("bcbc4d92251300b3c4ade65fa1d315d66e370f300925dc949024628fa32b66d253fb8d2813c775c5c97d32a6bc8aeea94bbd3ae869330b2b4bcf7adc5aea89f5", 16);
   }

   AZI() throws Throwable {
      throw new Error();
   }

   public static HSI I(int var0, byte var1) {
      try {
         int var2 = var0 >> 16;
         if (IU.F[var2] == null || IU.F[var2].I(var0, (short)3713) == null) {
            boolean var3 = KT.I(var2, (int[])null, -957339129);
            if (!var3) {
               return null;
            }
         }

         return IU.F[var2].I(var0, (short)19883);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "c.f(" + ')');
      }
   }

   public static void I(int var0, int var1) {
      try {
         PK var2 = GB.I(MEI.H, XEI.eI.Z, (byte)24);
         var2.J.B(-1, -106491517);
         XEI.eI.I(var2, (byte)-71);
         TK.H = new IJI(ST.D, var0);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "c.ax(" + ')');
      }
   }

   static final void I(byte var0) {
      try {
         YT.S -= -1866863069;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "c.f(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = -1168328513 * XEI.uC;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "c.abh(" + ')');
      }
   }

   static void I(long[] var0, int[] var1, int var2, int var3, int var4) {
      try {
         if (var2 < var3) {
            int var5 = (var2 + var3) / 2;
            int var6 = var2;
            long var7 = var0[var5];
            var0[var5] = var0[var3];
            var0[var3] = var7;
            int var9 = var1[var5];
            var1[var5] = var1[var3];
            var1[var3] = var9;
            int var10 = Long.MAX_VALUE == var7 ? 0 : 1;

            for(int var11 = var2; var11 < var3; ++var11) {
               if (var0[var11] < (long)(var11 & var10) + var7) {
                  long var12 = var0[var11];
                  var0[var11] = var0[var6];
                  var0[var6] = var12;
                  int var14 = var1[var11];
                  var1[var11] = var1[var6];
                  var1[var6++] = var14;
               }
            }

            var0[var3] = var0[var6];
            var0[var6] = var7;
            var1[var3] = var1[var6];
            var1[var6] = var9;
            I(var0, var1, var2, var6 - 1, 569685338);
            I(var0, var1, 1 + var6, var3, 765910015);
         }

      } catch (RuntimeException var15) {
         throw DQ.I(var15, "c.d(" + ')');
      }
   }

   static void Z(byte var0) {
      try {
         ZI.I = KR.I(2048, 35, 8, 8, 4, 0.4F, true, 33985);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "c.i(" + ')');
      }
   }

   static final void Z(int var0, byte var1) {
      try {
         int var2 = XEI.kB * 443738891 - XEI.QD * -1656615113;
         if (var2 >= 100) {
            EE.V = 1355934404;
            AV.I = -1001372047;
            B.XZ = 178575833;
         } else {
            int var3 = (int)XEI.WZ;
            if (XEI.dZ * -523207831 >> 8 > var3) {
               var3 = -523207831 * XEI.dZ >> 8;
            }

            if (XEI.KI[4] && 128 + XEI.VD[4] > var3) {
               var3 = 128 + XEI.VD[4];
            }

            int var4 = (int)XEI.qD + -1419578297 * XEI.GZ & 16383;
            SF var5 = UA.F.I().I;
            NII.I(1103750049 * FDI.C, NQ.I((int)var5.I, (int)var5.Z, 1855729883 * EJI.Z, -1800819540) - 200, 1346160791 * A.Z, var3, var4, 600 + (var3 >> 3) * 3 << 2, var0, -1059521295);
            float var6 = 1.0F - (float)((100 - var2) * (100 - var2) * (100 - var2)) / 1000000.0F;
            RR.Q = (int)((float)(GN.r * -1806467999) + var6 * (float)(RR.Q * -1740717447 - -1806467999 * GN.r)) * 547882953;
            L.B = 1078403147 * (int)((float)(1449634147 * L.B - 2032233737 * VU.I) * var6 + (float)(VU.I * 2032233737));
            RZ.H = (int)(var6 * (float)(RZ.H * -299812095 - 1368015401 * ZFI.D) + (float)(1368015401 * ZFI.D)) * 309839105;
            XEI.VZ = (int)((float)(-104436553 * XEI.VZ - RD.B * 827399463) * var6 + (float)(RD.B * 827399463)) * -648269561;
            int var7 = CZ.I * -1847894591 - -883946017 * DN.H;
            if (var7 > 8192) {
               var7 -= 16384;
            } else if (var7 < -8192) {
               var7 += 16384;
            }

            CZ.I = (int)((float)var7 * var6 + (float)(DN.H * -883946017)) * -1587695039;
            CZ.I = -1587695039 * (-1847894591 * CZ.I & 16383);
         }

      } catch (RuntimeException var8) {
         throw DQ.I(var8, "c.hz(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         var0.J -= -1175642067;
         int var2 = var0.H[var0.J * 681479919];
         int var3 = var0.H[var0.J * 681479919 + 1];
         int var4 = var0.H[2 + 681479919 * var0.J];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var0.R.I(var2, var3, var4, 1489690746);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "c.xr(" + ')');
      }
   }

   static final void C(OU var0, byte var1) {
      try {
         int var2 = var0.X[var0.i * 1883543357] >> 16;
         int var3 = var0.X[1883543357 * var0.i] & '\uffff';
         int var4 = var0.H[(var0.J -= -391880689) * 681479919];
         if (var4 >= 0 && var4 <= 5000) {
            var0.B[var2] = var4;
            byte var5 = -1;
            if (105 == var3) {
               var5 = 0;
            }

            for(int var6 = 0; var6 < var4; ++var6) {
               var0.F[var2][var6] = var5;
            }

         } else {
            throw new RuntimeException();
         }
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "c.an(" + ')');
      }
   }

   static final void B(OU var0, byte var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         IR.I(var3, var4, var0, (byte)-16);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "c.ih(" + ')');
      }
   }
}
