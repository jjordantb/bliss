import java.util.LinkedList;
import java.util.Queue;

public class FSI {
   static int I = 0;
   static AT Z = new AT();
   static boolean C = true;
   static long B = 7881601697932874601L;
   static Queue D = new LinkedList();
   static ST F = new ST();
   public static String[] J;

   FSI() throws Throwable {
      throw new Error();
   }

   static void I(BSI var0, int var1, OU var2, int var3) {
      try {
         var2.J = 0;
         var2.A = 0;
         var2.i = -286750741;
         var2.z = var0;
         var2.Y = var2.z.K;
         var2.X = var2.z.L;
         JU var4 = null;
         var2.P = 0;

         try {
            try {
               YT.C = 0;

               while(true) {
                  YT.C += -138185287;
                  if (-560594807 * YT.C > var1) {
                     throw new RuntimeException("");
                  }

                  var4 = var2.Y[(var2.i += 286750741) * 1883543357];
                  if (YT.D && (YT.F == null || var2.z.G != null && var2.z.G.indexOf(YT.F) != -1)) {
                     System.out.println(var2.z.G + ": " + var4);
                  }

                  if (var2.X[1883543357 * var2.i] == 1) {
                     var2.c = true;
                  } else {
                     var2.c = false;
                  }

                  if (JU.L == var4 && var2.P * -932179775 == 0) {
                     AZI.I((byte)116);
                     break;
                  }

                  UJ.I(var4, var2, (byte)11);
               }
            } catch (Exception var8) {
               StringBuilder var6 = new StringBuilder(30);
               var6.append("").append(7051297995265073167L * var2.z.Z).append(" ");

               for(int var7 = var2.P * -932179775 - 1; var7 >= 0; --var7) {
                  var6.append("").append(7051297995265073167L * var2.O[var7].B.Z).append(" ");
               }

               var6.append("").append(-2008816077 * var4.JQ);
               KSI.I(var6.toString(), var8, (short)-1126);
               AZI.I((byte)46);
            }

         } catch (RuntimeException var9) {
            AZI.I((byte)2);
            throw var9;
         }
      } catch (RuntimeException var10) {
         throw DQ.I(var10, "px.s(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         var0.S[(var0.A += 969361751) * -203050393 - 1] = ((PEI)var0.E).I(true, -1660599936);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "px.aom(" + ')');
      }
   }

   static boolean I(CharSequence var0, int var1, boolean var2, int var3) {
      try {
         if (var1 >= 2 && var1 <= 36) {
            boolean var4 = false;
            boolean var5 = false;
            int var6 = 0;
            int var7 = var0.length();

            for(int var8 = 0; var8 < var7; ++var8) {
               char var9 = var0.charAt(var8);
               if (var8 == 0) {
                  if ('-' == var9) {
                     var4 = true;
                     continue;
                  }

                  if (var9 == '+' && var2) {
                     if (var3 != -1628070489) {
                        throw new IllegalStateException();
                     }
                     continue;
                  }
               }

               int var12;
               if (var9 >= '0' && var9 <= '9') {
                  var12 = var9 - 48;
               } else if (var9 >= 'A' && var9 <= 'Z') {
                  var12 = var9 - 55;
               } else {
                  if (var9 < 'a' || var9 > 'z') {
                     return false;
                  }

                  var12 = var9 - 87;
               }

               if (var12 >= var1) {
                  return false;
               }

               if (var4) {
                  var12 = -var12;
               }

               int var10 = var6 * var1 + var12;
               if (var10 / var1 != var6) {
                  return false;
               }

               var6 = var10;
               var5 = true;
            }

            return var5;
         } else {
            throw new IllegalArgumentException("" + var1);
         }
      } catch (RuntimeException var11) {
         throw DQ.I(var11, "px.p(" + ')');
      }
   }

   static void I(int var0) {
      try {
         if (IC.Z(XEI.QZ * -1233866115, -1337586273)) {
            if (XEI.TI.C(537308016) == null) {
               HX.I(4, 1378010016);
            } else {
               HX.I(14, 310060879);
            }
         } else if (-1233866115 * XEI.QZ != 4 && XEI.QZ * -1233866115 != 3) {
            if (XEI.QZ * -1233866115 == 6) {
               HX.I(19, 1046566062);
            }
         } else {
            HX.I(19, 1879261492);
         }

      } catch (RuntimeException var2) {
         throw DQ.I(var2, "px.o(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         if (XEI.LC != null && var2 < -1801543887 * UII.I) {
            var0.S[(var0.A += 969361751) * -203050393 - 1] = EFI.F[var2].I;
         } else {
            var0.S[(var0.A += 969361751) * -203050393 - 1] = "";
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "px.wp(" + ')');
      }
   }
}
