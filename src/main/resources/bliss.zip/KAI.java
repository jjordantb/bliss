public interface KAI {
   long method46(String var1);

   long method47(String var1, byte var2);

   long method48(String var1);
}
