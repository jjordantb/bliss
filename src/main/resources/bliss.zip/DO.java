import jaggl.OpenGL;

public class DO extends SN {
   static int A = 34074;
   static int E = 34069;
   static int G = 34071;
   static int H = 34072;
   static int K = 34073;
   static int L = 34070;
   int M;

   DO(MJI var1, YCI var2, SDI var3, int var4) {
      super(var1, 34067, var2, var3, var4 * var4 * 6, false);
      this.M = var4;
      this.J.I((SN)this);

      for(int var5 = 0; var5 < 6; ++var5) {
         OpenGL.glTexImage2Dub('蔕' + var5, 0, MJI.I(this.C, this.B), var4, var4, 0, MJI.I(this.C), 5121, (byte[])null, 0);
      }

      this.I(true);
   }

   DO(MJI var1, YCI var2, SDI var3, int var4, boolean var5, byte[][] var6, YCI var7) {
      super(var1, 34067, var2, var3, var4 * var4 * 6, var5);
      this.M = var4;
      this.J.I((SN)this);

      for(int var8 = 0; var8 < 6; ++var8) {
         OpenGL.glTexImage2Dub('蔕' + var8, 0, MJI.I(this.C, this.B), var4, var4, 0, MJI.I(var7), 5121, var6[var8], 0);
      }

      this.I(true);
   }

   TAI I(int var1, int var2) {
      return new JP(this, var1, var2);
   }

   DO(MJI var1, YCI var2, SDI var3, int var4, boolean var5, int[][] var6) {
      super(var1, 34067, var2, var3, var4 * var4 * 6, var5);
      this.M = var4;
      this.J.I((SN)this);
      int var7;
      if (var5) {
         for(var7 = 0; var7 < 6; ++var7) {
            I('蔕' + var7, MJI.I(this.C, this.B), var4, var4, 32993, this.J.NI, var6[var7]);
         }
      } else {
         for(var7 = 0; var7 < 6; ++var7) {
            OpenGL.glTexImage2Di('蔕' + var7, 0, MJI.I(this.C, this.B), var4, var4, 0, 32993, this.J.NI, var6[var7], 0);
         }
      }

      this.I(true);
   }
}
