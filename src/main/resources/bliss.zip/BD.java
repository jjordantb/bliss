import java.util.HashMap;
import java.util.Map;

public class BD {
   KJ Z;
   KJ append;
   JQ get = new JQ(20);
   Map method131 = null;
   int[] put;
   static int I;

   public int I(boolean var1, int var2) {
      try {
         if (this.put == null) {
            return 0;
         } else if (!var1 && this.method131 != null) {
            return this.put.length * 2;
         } else {
            int var3 = 0;

            for(int var4 = 0; var4 < this.put.length; ++var4) {
               int var5 = this.put[var4];
               if (this.Z.D(var5, -457216440)) {
                  ++var3;
               }

               if (this.append.D(var5, -457216440)) {
                  ++var3;
               }
            }

            return var3;
         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ii.p(" + ')');
      }
   }

   public void I(int var1) {
      try {
         this.method131 = null;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ii.f(" + ')');
      }
   }

   public int Z(int var1) {
      try {
         return this.I(false, -249350940);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ii.b(" + ')');
      }
   }

   public int C(int var1) {
      try {
         return this.put == null ? 0 : this.put.length * 2;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ii.i(" + ')');
      }
   }

   public LZI I(QSI var1, int var2, int var3) {
      try {
         ZY var4 = this.Z(var1, var2, true, true, -160012913);
         return var4 == null ? null : (LZI)var4.Z;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ii.d(" + ')');
      }
   }

   public void B(int var1) {
      try {
         this.get.I();
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ii.x(" + ')');
      }
   }

   public void I(int var1, int var2) {
      try {
         this.get.I(var1, -19915416);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ii.r(" + ')');
      }
   }

   public void I(QSI var1, byte var2) {
      try {
         this.method131 = new HashMap(this.put.length);

         for(int var3 = 0; var3 < this.put.length; ++var3) {
            int var4 = this.put[var3];
            LZI var5 = CS.I(this.append, var4, -227622319);
            byte[] var6 = this.Z.I(var4, (byte)82);
            Object var7 = var1.method131(var6, var5, true, -2012626904);
            this.method131.put(var3, new ZY(var7, var5));
         }

      } catch (RuntimeException var8) {
         throw DQ.I(var8, "ii.a(" + ')');
      }
   }

   public Object I(QSI var1, int var2, boolean var3, boolean var4, int var5) {
      try {
         ZY var6 = this.Z(var1, var2, var3, var4, 229227815);
         return var6 == null ? null : var6.I;
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "ii.k(" + ')');
      }
   }

   public void D(int var1) {
      try {
         this.get.Z();
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ii.q(" + ')');
      }
   }

   ZY Z(QSI var1, int var2, boolean var3, boolean var4, int var5) {
      try {
         if (-1 == var2) {
            return null;
         } else {
            if (this.put != null) {
               for(int var6 = 0; var6 < this.put.length; ++var6) {
                  if (var2 == this.put[var6]) {
                     return (ZY)this.method131.get(var6);
                  }
               }
            }

            ZY var10 = (ZY)this.get.I((long)(var2 << 1 | (var4 ? 1 : 0)));
            if (var10 != null) {
               if (var3 && var10.Z == null) {
                  LZI var11 = CS.I(this.append, var2, -221293891);
                  if (var11 == null) {
                     return null;
                  }

                  var10.Z = var11;
               }

               return var10;
            } else {
               byte[] var7 = this.Z.I(var2, (byte)54);
               if (var7 == null) {
                  return null;
               } else {
                  LZI var8 = CS.I(this.append, var2, 1718390038);
                  if (var8 == null) {
                     return null;
                  } else {
                     if (var3) {
                        var10 = new ZY(var1.method131(var7, var8, var4, -1761009560), var8);
                     } else {
                        var10 = new ZY(var1.method131(var7, var8, var4, -2090037397), (Object)null);
                     }

                     this.get.I(var10, (long)(var2 << 1 | (var4 ? 1 : 0)));
                     return var10;
                  }
               }
            }
         }
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "ii.u(" + ')');
      }
   }

   public BD(KJ var1, KJ var2, int[] var3) {
      this.Z = var1;
      this.append = var2;
      if (var3 != null) {
         this.put = var3;
      } else {
         this.put = null;
      }

   }

   static final void I(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         var0.H[(var0.J += -391880689) * 681479919 - 1] = -1086526073 * var3.dZ;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ii.px(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)71);
         X var4 = IU.F[var2 >> 16];
         YBI.I(var3, var4, var0, (byte)102);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ii.od(" + ')');
      }
   }

   static void I(int var0, boolean var1, int var2) {
      try {
         DN var3 = CS.I(var0, var1, 1277483186);
         if (var3 != null) {
            var3.I(-1460969981);
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ii.x(" + ')');
      }
   }
}
