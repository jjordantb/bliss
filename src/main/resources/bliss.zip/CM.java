public class CM extends RL {
   long append;
   int toString;
   String J;
   LC S;

   CM(LC var1) {
      this.S = var1;
      this.append = 2714659426994184815L;
      this.J = null;
      this.toString = 0;
   }

   void method3508(REI var1, int var2) {
      try {
         if (var1.I() != 255) {
            var1.A -= 116413311;
            this.append = var1.I((short)27016) * -2714659426994184815L;
         }

         this.J = var1.c(-517364695);
         this.toString = var1.C() * 70895925;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "agf.a(" + ')');
      }
   }

   void method3510(QC var1, byte var2) {
      try {
         var1.I(this.append * -1747233514558995599L, this.J, this.toString * 1029636381, -783761378);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "agf.f(" + ')');
      }
   }

   void method3511(QC var1) {
      var1.I(this.append * -1747233514558995599L, this.J, this.toString * 1029636381, -783761378);
   }

   void method3512(REI var1) {
      if (var1.I() != 255) {
         var1.A -= 116413311;
         this.append = var1.I((short)12554) * -2714659426994184815L;
      }

      this.J = var1.c(-517364695);
      this.toString = var1.C() * 70895925;
   }

   void method3509(REI var1) {
      if (var1.I() != 255) {
         var1.A -= 116413311;
         this.append = var1.I((short)5054) * -2714659426994184815L;
      }

      this.J = var1.c(-517364695);
      this.toString = var1.C() * 70895925;
   }
}
