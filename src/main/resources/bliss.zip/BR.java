public class BR extends ZR {
   int YA = 0;
   int append;
   SX f;
   GQ i;
   boolean method4728 = true;
   int method4739 = 0;

   boolean method4353() {
      return false;
   }

   void B(GSI var1, UT var2, LF var3, byte var4) {
      try {
         var2.method4786(var3);
         NFI[] var5 = var2.method4781();
         WBI[] var6 = var2.method4728();
         if ((this.i == null || this.i.S) && (var5 != null || var6 != null)) {
            this.i = GQ.I(XEI.kB * 443738891, true);
         }

         if (this.i != null) {
            this.i.I(var1, (long)(443738891 * XEI.kB), var5, var6, false);
            this.i.I(this.K, this.R, this.P, this.O, this.Q);
         }

      } catch (RuntimeException var7) {
         throw DQ.I(var7, "akr.i(" + ')');
      }
   }

   public void B(byte var1) {
      try {
         if (this.i != null) {
            this.i.Z();
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "akr.k(" + ')');
      }
   }

   final void method4377() {
      throw new IllegalStateException();
   }

   public HP method4358(GSI var1, byte var2) {
      return null;
   }

   public BR(AP var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, int var11, int var12, int var13, boolean var14) {
      super(var1, var4, var5, var6, var7, var8, var9, var10, var11, var12, false, (byte)0);
      this.append = 1921334459 * var2;
      this.method4739 = var13 * -1141067271;
      GU var15 = GC.S.I(this.append * -743331725, -2103306753);
      int var16 = 1505778629 * var15.Z;
      if (var16 != -1) {
         this.f = new EX(this, false);
         int var17 = var15.B ? 0 : 2;
         if (var14) {
            var17 = 1;
         }

         this.f.I(var16, var3, var17, false, (byte)0);
      }

      this.I(1, -656221662);
   }

   public final boolean D(byte var1) {
      try {
         return this.f != null && !this.f.C(-65534);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "akr.f(" + ')');
      }
   }

   final boolean method4386() {
      return false;
   }

   UT F(GSI var1, int var2, int var3, int var4) {
      try {
         GU var5 = GC.S.I(var3, -1949428738);
         YJI var6 = this.H.K[this.K];
         YJI var7 = this.L < 3 ? this.H.K[1 + this.L] : null;
         SF var8 = this.I().I;
         return this.f != null && !this.f.D(1032843646) ? var5.I(var1, var2, true, var6, var7, (int)var8.I, (int)var8.C, (int)var8.Z, this.f, (byte)2, 345220259) : var5.I(var1, var2, true, var6, var7, (int)var8.I, (int)var8.C, (int)var8.Z, (SX)null, (byte)2, -2126228993);
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "akr.p(" + ')');
      }
   }

   void method4357(GSI var1, int var2) {
      try {
         UT var3 = this.F(var1, 0, -743331725 * this.append, -1760774279);
         if (var3 != null) {
            this.B(var1, var3, this.J(), (byte)-58);
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "akr.bb(" + ')');
      }
   }

   final void method4355(GSI var1, IR var2, int var3, int var4, int var5, boolean var6, int var7) {
      try {
         throw new IllegalStateException();
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "akr.bk(" + ')');
      }
   }

   boolean method4350(GSI var1, int var2, int var3, byte var4) {
      return false;
   }

   boolean method4374() {
      return false;
   }

   final boolean method4366(int var1) {
      return false;
   }

   public final void Z(int var1, int var2) {
      try {
         if (this.f != null && !this.f.D(-891942946)) {
            this.f.Z(var1, 2083264997);
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "akr.a(" + ')');
      }
   }

   final void method4398(byte var1) {
      try {
         throw new IllegalStateException();
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "akr.bq(" + ')');
      }
   }

   public int method4361(int var1) {
      try {
         return 1112786493 * this.YA;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "akr.bm(" + ')');
      }
   }

   boolean method4365() {
      return false;
   }

   final boolean method4387() {
      return false;
   }

   public HP method4367(GSI var1) {
      return null;
   }

   public HP method4368(GSI var1) {
      return null;
   }

   KP method4370(GSI var1) {
      UT var2 = this.F(var1, 2048 | (this.method4739 * -657768375 != 0 ? 5 : 0), -743331725 * this.append, -1821357765);
      if (var2 == null) {
         return null;
      } else {
         if (-657768375 * this.method4739 != 0) {
            var2.f(1510098944 * this.method4739);
         }

         LF var3 = this.J();
         this.B(var1, var2, var3, (byte)-14);
         KP var4 = BDI.I(false, 1620653169);
         var2.method4739(var3, this.N[0], 0);
         if (this.i != null) {
            XBI var5 = this.i.D();
            var1.method5042(var5);
         }

         this.method4728 = var2.i();
         this.YA = var2.YA() * 2028765461;
         var2.n();
         return var4;
      }
   }

   void method4371(GSI var1) {
      UT var2 = this.F(var1, 0, -743331725 * this.append, -1484520412);
      if (var2 != null) {
         this.B(var1, var2, this.J(), (byte)-82);
      }

   }

   void method4373(GSI var1) {
      UT var2 = this.F(var1, 0, -743331725 * this.append, -1936222136);
      if (var2 != null) {
         this.B(var1, var2, this.J(), (byte)-12);
      }

   }

   boolean method4372(GSI var1, int var2, int var3) {
      return false;
   }

   boolean method4385(GSI var1, int var2, int var3) {
      return false;
   }

   boolean method4352(GSI var1, int var2, int var3) {
      return false;
   }

   final void method4375(GSI var1, IR var2, int var3, int var4, int var5, boolean var6) {
      throw new IllegalStateException();
   }

   KP method4394(GSI var1, int var2) {
      try {
         UT var3 = this.F(var1, 2048 | (this.method4739 * -657768375 != 0 ? 5 : 0), -743331725 * this.append, -1982313638);
         if (var3 == null) {
            return null;
         } else {
            if (-657768375 * this.method4739 != 0) {
               var3.f(1510098944 * this.method4739);
            }

            LF var4 = this.J();
            this.B(var1, var3, var4, (byte)-52);
            KP var5 = BDI.I(false, 1486074028);
            var3.method4739(var4, this.N[0], 0);
            if (this.i != null) {
               XBI var6 = this.i.D();
               var1.method5042(var6);
            }

            this.method4728 = var3.i();
            this.YA = var3.YA() * 2028765461;
            var3.n();
            return var5;
         }
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "akr.bo(" + ')');
      }
   }

   boolean method4369() {
      return this.method4728;
   }

   final void method4378() {
      throw new IllegalStateException();
   }

   boolean method4376(short var1) {
      try {
         return this.method4728;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "akr.be(" + ')');
      }
   }

   public int method4380() {
      return 1112786493 * this.YA;
   }

   public int method4381() {
      return 1112786493 * this.YA;
   }

   public int method4379() {
      return 1112786493 * this.YA;
   }

   boolean method4382() {
      return this.method4728;
   }

   boolean method4349() {
      return this.method4728;
   }

   boolean method4351() {
      return this.method4728;
   }

   final boolean method4384() {
      return false;
   }

   final boolean method4400() {
      return false;
   }

   final void method4388(GSI var1, IR var2, int var3, int var4, int var5, boolean var6) {
      throw new IllegalStateException();
   }

   boolean method4383() {
      return this.method4728;
   }

   public final boolean Z(int var1) {
      try {
         return this.f == null || this.f.D(1776258671);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "akr.b(" + ')');
      }
   }

   boolean method4399(byte var1) {
      return false;
   }
}
