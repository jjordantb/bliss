public class EF implements Runnable {
   volatile boolean EA;
   QF append;
   TSI ba = new NF();
   TSI f = null;
   long ia;
   int method149;
   long method151;
   String method153;
   int method160;
   boolean method4755;

   int I(int var1) {
      try {
         return -514341095 * this.method149;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jf.a(" + ')');
      }
   }

   public QF Z(int var1) {
      try {
         return this.append;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jf.r(" + ')');
      }
   }

   synchronized boolean C(int var1) {
      try {
         return this.ba.method153(this.ia * 6015775630087136145L);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jf.b(" + ')');
      }
   }

   synchronized void I(TSI var1, int var2) {
      try {
         this.f = this.ba;
         this.ba = var1;
         this.ia = CI.I((byte)1) * -5051392830202741391L;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "jf.p(" + ')');
      }
   }

   synchronized void I(byte var1) {
      try {
         this.method4755 = true;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jf.f(" + ')');
      }
   }

   public int B(int var1) {
      try {
         return -1457416349 * this.method160;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jf.d(" + ')');
      }
   }

   public String I(short var1) {
      try {
         return this.method153;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jf.u(" + ')');
      }
   }

   public long D(int var1) {
      try {
         return 3605481893406255809L * this.method151;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jf.x(" + ')');
      }
   }

   public int Z(byte var1) {
      try {
         if (this.append == null) {
            return 0;
         } else {
            int var2 = -861845079 * this.append.Q;
            if (this.append.T && -1457416349 * this.method160 < -1620354451 * this.append.V) {
               return 1 + this.method160 * -1457416349;
            } else if (var2 >= 0 && var2 < VF.Z.length - 1) {
               return this.method160 * -1457416349 == 360399239 * this.append.U ? -1620354451 * this.append.V : 360399239 * this.append.U;
            } else {
               return 100;
            }
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jf.k(" + ')');
      }
   }

   void C(byte var1) {
      try {
         this.EA = true;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jf.s(" + ')');
      }
   }

   public void run() {
      try {
         while(!this.EA) {
            long var1 = CI.I((byte)1);
            synchronized(this) {
               try {
                  this.method149 += -1941002967;
                  if (this.ba instanceof NF) {
                     this.ba.method160(this.method4755, 2139338781);
                  } else {
                     long var4 = CI.I((byte)1);
                     if (FT.P != null && this.f != null && this.f.method151(73548607) != 0 && 6015775630087136145L * this.ia >= var4 - (long)this.f.method151(-462627527)) {
                        int var6 = (int)((var4 - 6015775630087136145L * this.ia) * 255L / (long)this.f.method151(-362403732));
                        int var7 = 255 - var6;
                        var6 = var6 << 24 | 16777215;
                        var7 = var7 << 24 | 16777215;
                        UZ.I((byte)-69);
                        FT.P.ba(1, 0);
                        IBI var8 = FT.P.I(-2110394505 * GY.Z, -1111710645 * JM.J, true, -34894995);
                        ECI var9 = FT.P.method5094();
                        var9.method563(0, var8.method627());
                        FT.P.Z(var9, (byte)28);
                        this.f.method160(true, 2128455067);
                        FT.P.I((ECI)var9, (byte)8);
                        var8.method631(0, 0, 0, var7, 1);
                        FT.P.Z(var9, (byte)-59);
                        FT.P.ba(1, 0);
                        this.ba.method160(true, 2141475636);
                        FT.P.I(var9, (byte)-56);
                        var8.method631(0, 0, 0, var6, 1);
                     } else {
                        if (this.f != null) {
                           this.method4755 = true;
                           this.f.method149((short)371);
                           this.f = null;
                        }

                        if (this.method4755) {
                           UZ.I((byte)-56);
                           if (FT.P != null) {
                              FT.P.ba(1, 0);
                           }
                        }

                        this.ba.method160(this.method4755 || FT.P != null && FT.P.method5074(), 2145176958);
                     }

                     try {
                        if (FT.P != null && !(this.ba instanceof NF)) {
                           FT.P.I((byte)101);
                        }
                     } catch (Exception_Sub1 var10) {
                        KSI.I(var10.getMessage() + RT.K.I((byte)1), var10, (short)3171);
                        WR.I(0, true, 622850291);
                     }
                  }

                  this.method4755 = false;
                  if (FT.P != null && !(this.ba instanceof NF) && this.append.Q * -861845079 < -861845079 * QF.N.Q) {
                     TF.Z((byte)-100);
                  }
               } catch (Exception var11) {
                  continue;
               }
            }

            long var3 = CI.I((byte)1);
            int var5 = (int)(20L - (var3 - var1));
            if (var5 > 0) {
               KSI.I((long)var5);
            }
         }

      } catch (RuntimeException var13) {
         throw DQ.I(var13, "jf.run(" + ')');
      }
   }

   synchronized void I(long var1, String var3, int var4, QF var5, int var6) {
      try {
         this.method151 = 1707169404099388737L * var1;
         this.method153 = var3;
         this.method160 = var4 * -1376476597;
         this.append = var5;
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "jf.i(" + ')');
      }
   }

   public static UT I(GSI var0, int var1, int var2, int var3, int var4, int var5, int var6) {
      try {
         long var7 = (long)var5;
         UT var9 = (UT)UB.A.I(var7);
         short var10 = 2055;
         if (var9 == null) {
            MBI var11 = MBI.I((KJ)XP.B, var5, (int)0);
            if (var11 == null) {
               return null;
            }

            if (var11.P < 13) {
               var11.I(2);
            }

            var9 = var0.method5037(var11, var10, -203714349 * LII.C, 64, 768);
            UB.A.I(var9, var7);
         }

         var9 = var9.method4755((byte)6, var10, true);
         if (var1 != 0) {
            var9.f(var1);
         }

         if (var2 != 0) {
            var9.t(var2);
         }

         if (var3 != 0) {
            var9.EA(var3);
         }

         if (var4 != 0) {
            var9.ia(0, var4, 0);
         }

         return var9;
      } catch (RuntimeException var12) {
         throw DQ.I(var12, "jf.a(" + ')');
      }
   }

   public static int I(int var0, int var1, int var2, byte var3) {
      try {
         var2 &= 3;
         if (var2 == 0) {
            return var0;
         } else if (1 == var2) {
            return var1;
         } else {
            return 2 == var2 ? 4095 - var0 : 4095 - var1;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "jf.b(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         var0.H[(var0.J += -391880689) * 681479919 - 1] = 1508815983 * var3.eI;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "jf.pe(" + ')');
      }
   }

   public static final void F(int var0) {
      try {
         NH.X = null;
         RA.F = null;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "jf.at(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-71);
         var0.S[(var0.A += 969361751) * -203050393 - 1] = var3.hI;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "jf.rk(" + ')');
      }
   }
}
