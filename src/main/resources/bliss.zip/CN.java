public abstract class CN extends AE {
   boolean J;
   MJI S;

   abstract void method2867();

   abstract boolean method2868();

   abstract boolean method2869();

   abstract void method2870();

   abstract void method2871(int var1, int var2);

   abstract void method2872(int var1, FO var2, FO var3);

   abstract void method2873(int var1);

   int I() {
      return 1;
   }

   CN(MJI var1) {
      this.S = var1;
   }

   SDI Z() {
      return SDI.C;
   }

   abstract boolean method2876();

   abstract void method2877(int var1, FO var2, FO var3);

   abstract void method2878(int var1, FO var2, FO var3);

   abstract void method2879(int var1);

   abstract void method2880(int var1);

   boolean C() {
      return false;
   }

   abstract boolean method2882();

   abstract void method2883(int var1, int var2);

   abstract boolean method2884();

   abstract void method2885(int var1, int var2);

   boolean B() {
      return this.J;
   }
}
