public class EW extends LV {
   static int method5611 = 127;
   static int toString = 0;

   public EW(int var1, MM var2) {
      super(var1, var2);
   }

   public EW(MM var1) {
      super(var1);
   }

   int method5611(int var1) {
      return 127;
   }

   int method5612(int var1, int var2) {
      return 1;
   }

   void method5614(int var1, int var2) {
      try {
         this.C = 1886334997 * var1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aer.p(" + ')');
      }
   }

   public int I(int var1) {
      try {
         return -1598873795 * this.C;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aer.z(" + ')');
      }
   }

   int method5615() {
      return 127;
   }

   void method5610(int var1) {
      this.C = 1886334997 * var1;
   }

   public void Z(byte var1) {
      try {
         if (this.C * -1598873795 < 0 && this.C * -1598873795 > 127) {
            this.C = this.method5611(-1091362223) * 1886334997;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aer.s(" + ')');
      }
   }

   int method5616(int var1) {
      return 1;
   }

   static boolean I(HQ var0, int var1) {
      try {
         if (var0 == null) {
            return false;
         } else if (!var0.c) {
            return false;
         } else if (!var0.I(GN.D, 655699987)) {
            return false;
         } else if (GN.o.I((long)(-1262065485 * var0.A)) != null) {
            return false;
         } else {
            return GN.p.I((long)(var0.e * -804513353)) == null;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aer.bn(" + ')');
      }
   }

   public static boolean I(byte var0, short var1) {
      try {
         int var2 = var0 & 255;
         if (var2 == 0) {
            return false;
         } else {
            return var2 < 128 || var2 >= 160 || EV.I[var2 - 128] != 0;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aer.b(" + ')');
      }
   }
}
