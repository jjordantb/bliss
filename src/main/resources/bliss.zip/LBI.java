public class LBI {
   LBI() throws Throwable {
      throw new Error();
   }

   static final void I(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         OV.I(var3, var4, var0, 540861135);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "co.me(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         ME.I(var3, var4, var0, 39715579);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "co.oe(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.S[(var0.A += 969361751) * -203050393 - 1] = var0.R.P[var2];
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "co.xk(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         String var2;
         if (UA.F != null && UA.F.nI != null) {
            var2 = UA.F.I(true, -1868785236);
         } else {
            var2 = "";
         }

         var0.S[(var0.A += 969361751) * -203050393 - 1] = var2;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "co.aca(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = (int)(ZV.I(var2, 251900723) / 60000L);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "co.ake(" + ')');
      }
   }

   static void I(int var0, int var1, int var2) {
      try {
         if (-1909773881 * FX.A == 1) {
            AEI.I(ZV.A, var0, var1, (short)916);
         } else if (2 == FX.A * -1909773881) {
            L.I(var0, var1, (byte)20);
         }

         FX.A = 0;
         ZV.A = null;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "co.u(" + ')');
      }
   }

   public static void I(int var0) {
      try {
         if (TQ.U * -707576455 == 100) {
            TQ.U = 928688093;
         }

      } catch (RuntimeException var2) {
         throw DQ.I(var2, "co.d(" + ')');
      }
   }

   static boolean Z(int var0) {
      try {
         return FX.k * -278777595 > 0;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "co.o(" + ')');
      }
   }

   public static void I(String var0, String var1, int var2) {
      try {
         if (var0.length() <= 320 && MU.Z((byte)36)) {
            NFI.C(1405885355);
            TQ.W = var0;
            TQ.X = var1;
            HX.I(3, 907269288);
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "co.u(" + ')');
      }
   }

   public static void I(QK var0, QK var1, byte var2) {
      try {
         if (var0.J != null) {
            var0.C(-1977881593);
         }

         var0.J = var1.J;
         var0.S = var1;
         var0.J.S = var0;
         var0.S.J = var0;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "co.b(" + ')');
      }
   }
}
