public final class EZ extends AZ {
   L[] append = new L[3];
   static int method1331 = 0;
   static int method1340 = 0;
   static int method3119 = 2;
   static int method5297 = 3;
   static int method5335 = 4;
   static int method5383 = 5;
   static int method5398 = 6;
   static int method5455 = 7;
   BI method5612;
   static int toString = 1;
   XF E = new XF(0.0F, 0.0F, 0.0F, 0.0F);
   static int G = 3;
   static int H = 2;
   int[][] K = new int[3][7];
   int[] L;
   XF M = new XF(1.0F, 1.0F, 1.0F, 1.0F);
   static int N = 1;
   public static XI O;

   public void method1537() {
      this.method5612.method1331(this.append[1]);
      this.L = this.K[this.method5612.F(1490567798)];
      this.method5612.I(this.L[2], 1, this.I, 1647913438);
      this.method5612.I(this.L[4], this.J, -1599730439);
      this.append(-512231280);
   }

   boolean F(int var1) throws Exception_Sub2 {
      try {
         this.method5612 = this.B.method5297("Sprite");
         VG var2 = this.method5612.I("WVPMatrix", -1337554714);
         VG var3 = this.method5612.I("SpriteSampler", -347092125);
         VG var4 = this.method5612.I("MaskSampler", -1001377482);
         VG var5 = this.method5612.I("MulColour", 116022092);
         VG var6 = this.method5612.I("AddColour", -797757613);
         VG var7 = this.method5612.I("SpriteTexCoordMatrix", 271809133);
         VG var8 = this.method5612.I("MaskTexCoordMatrix", 1713273798);
         this.append[0] = this.method5612.I("Normal", (byte)-30);
         this.append[1] = this.method5612.I("Masked", (byte)-23);
         this.append[2] = this.method5612.I("AlphaTex", (byte)-96);

         for(int var9 = 0; var9 < 3; ++var9) {
            int var10 = this.method5612.I(this.append[var9], -180449856);
            this.K[var9][0] = var2.method3119(var10);
            this.K[var9][1] = var3.method3119(var10);
            this.K[var9][2] = var4.method3119(var10);
            this.K[var9][5] = var5.method3119(var10);
            this.K[var9][6] = var6.method3119(var10);
            this.K[var9][3] = var7.method3119(var10);
            this.K[var9][4] = var8.method3119(var10);
         }

         this.method5612.method1331(this.append[0]);
         return true;
      } catch (RuntimeException var11) {
         throw DQ.I(var11, "yi.y(" + ')');
      }
   }

   public void method1531() {
      this.method5612.method1331(this.append[0]);
      this.L = this.K[this.method5612.F(1620928863)];
      this.append(-512231280);
   }

   public void method1534() {
      this.method5612.method1331(this.append[1]);
      this.L = this.K[this.method5612.F(1799614751)];
      this.method5612.I(this.L[2], 1, this.I, -291659161);
      this.method5612.I(this.L[4], this.J, -1599730439);
      this.append(-512231280);
   }

   void append(int var1) {
      try {
         this.method5612.method1340();
         this.method5612.I(this.L[1], 0, this.Z, -1250819692);
         this.B.method5335(this.D);
         this.method5612.I(this.L[0], this.D, (byte)-62);
         this.method5612.I(this.L[3], this.F, -1599730439);
         this.method5612.I(this.L[5], this.M.B, this.M.C, this.M.I, this.M.Z, (byte)6);
         this.method5612.I(this.L[6], this.E.B, this.E.C, this.E.I, this.E.Z, (byte)29);
         this.B.method5383(0, this.C);
         this.B.method5455(this.A);
         this.B.method5398(QB.C, this.S, 2);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "yi.t(" + ')');
      }
   }

   public void method1528() {
      try {
         this.method5612.method1331(this.append[1]);
         this.L = this.K[this.method5612.F(983668425)];
         this.method5612.I(this.L[2], 1, this.I, 1449956625);
         this.method5612.I(this.L[4], this.J, -1599730439);
         this.append(-512231280);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "yi.b(" + ')');
      }
   }

   public void method1529(int var1, int var2) {
      switch(var1) {
      case 0:
         this.M.I(var2);
         this.E.I(0);
         break;
      case 1:
         this.M.I(-1);
         this.E.I(0);
         break;
      case 2:
         this.M.I(var2);
         this.E.I(0);
         break;
      case 3:
         this.M.I(16777215 | var2 & -16777216);
         this.E.I(var2 & 16777215);
         break;
      case 4:
         this.M.I(-1);
         this.E.I(var2);
         this.E.I();
      }

   }

   public void method1530(int var1, int var2) {
      switch(var1) {
      case 0:
         this.M.I(var2);
         this.E.I(0);
         break;
      case 1:
         this.M.I(-1);
         this.E.I(0);
         break;
      case 2:
         this.M.I(var2);
         this.E.I(0);
         break;
      case 3:
         this.M.I(16777215 | var2 & -16777216);
         this.E.I(var2 & 16777215);
         break;
      case 4:
         this.M.I(-1);
         this.E.I(var2);
         this.E.I();
      }

   }

   public void method1536() {
      this.method5612.method1331(this.append[1]);
      this.L = this.K[this.method5612.F(1377516236)];
      this.method5612.I(this.L[2], 1, this.I, -709585424);
      this.method5612.I(this.L[4], this.J, -1599730439);
      this.append(-512231280);
   }

   public void method1532() {
      this.method5612.method1331(this.append[0]);
      this.L = this.K[this.method5612.F(1548061224)];
      this.append(-512231280);
   }

   public void method1535() {
      this.method5612.method1331(this.append[0]);
      this.L = this.K[this.method5612.F(1025602377)];
      this.append(-512231280);
   }

   public void method1525() {
      this.method5612.method1331(this.append[0]);
      this.L = this.K[this.method5612.F(1272253028)];
      this.append(-512231280);
   }

   public EZ(NJI var1) throws Exception_Sub2 {
      super(var1);
      this.F(-964242582);
   }

   public void method1533() {
      this.method5612.method1331(this.append[1]);
      this.L = this.K[this.method5612.F(2074431922)];
      this.method5612.I(this.L[2], 1, this.I, -2013036939);
      this.method5612.I(this.L[4], this.J, -1599730439);
      this.append(-512231280);
   }

   public void method1527() {
      try {
         this.method5612.method1331(this.append[0]);
         this.L = this.K[this.method5612.F(1291749440)];
         this.append(-512231280);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "yi.f(" + ')');
      }
   }

   public void method1538() {
      this.method5612.method1331(this.append[1]);
      this.L = this.K[this.method5612.F(1159640978)];
      this.method5612.I(this.L[2], 1, this.I, -2044717945);
      this.method5612.I(this.L[4], this.J, -1599730439);
      this.append(-512231280);
   }

   public void method1526(int var1, int var2) {
      try {
         switch(var1) {
         case 0:
            this.M.I(var2);
            this.E.I(0);
            break;
         case 1:
            this.M.I(-1);
            this.E.I(0);
            break;
         case 2:
            this.M.I(var2);
            this.E.I(0);
            break;
         case 3:
            this.M.I(16777215 | var2 & -16777216);
            this.E.I(var2 & 16777215);
            break;
         case 4:
            this.M.I(-1);
            this.E.I(var2);
            this.E.I();
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "yi.a(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.j.method5612(var2, 1352882135);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "yi.aoz(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-15);
         X var4 = IU.F[var2 >> 16];
         JSI.I(var3, var4, var0, 1912101040);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "yi.lb(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         var0.J -= -1959403445;
         FJ.I(var0.H[var0.J * 681479919], var0.H[681479919 * var0.J + 1], var0.H[681479919 * var0.J + 2], var0.H[681479919 * var0.J + 3], var0.H[4 + 681479919 * var0.J], 1835382767);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "yi.tn(" + ')');
      }
   }
}
