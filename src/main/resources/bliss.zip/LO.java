public class LO {
   static int J = 63;
   static int Z = 7;
   public static int I;
   public static Object[] C;
   public static IBI B;
   static CJI D;

   LO() throws Throwable {
      throw new Error();
   }

   public static void I(int var0, int var1, boolean var2, int var3) {
      try {
         if (QW.C.I((long)var0) == null) {
            if (!XEI.NC) {
               SI.I(var0, var2, 1982223094);
            } else {
               NM var4 = new NM(var0, new IO(4096, YZI.C, var0), var1, var2);
               var4.E.I(WO.U.I(1748854882), (byte)104);
               QW.C.I(var4, (long)var0);
            }
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "n.a(" + ')');
      }
   }

   static int[] I(YK var0, byte var1) {
      try {
         int[] var2 = null;
         if (GU.I((int)(946432351 * var0.N), (short)300)) {
            var2 = JH.R.I((int)(var0.M * 2236412381003659263L)).CI;
         } else if (-1 != var0.L * -149710173) {
            var2 = JH.R.I(var0.L * -149710173).CI;
         } else if (HN.I(946432351 * var0.N, -838004269)) {
            QG var3 = (QG)XEI.UI.I((long)((int)(2236412381003659263L * var0.M)));
            if (var3 != null) {
               GEI var4 = (GEI)var3.J;
               HEI var5 = var4.tI;
               if (var5.ZI != null) {
                  var5 = var5.I((FAI)MI.E, 2033982126);
               }

               if (var5 != null) {
                  var2 = var5.S;
               }
            }
         } else if (SU.C(var0.N * 946432351, (byte)-114)) {
            KEI var7 = XEI.mI.E(150013546).C((int)(2236412381003659263L * var0.M >>> 32 & 2147483647L));
            if (var7.C != null) {
               var7 = var7.I((FAI)MI.E, (int)1956265286);
            }

            if (var7 != null) {
               var2 = var7.F;
            }
         }

         return var2;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "n.ag(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         JCI.I(var3, var0, -2024770880);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "n.qm(" + ')');
      }
   }
}
