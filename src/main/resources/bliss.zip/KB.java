public class KB {
   int I;
   long Z;

   KB(JC[] var1) {
      for(int var2 = 0; var2 < var1.length; ++var2) {
         this.I(var1[var2]);
      }

   }

   KB(JC var1) {
      this.Z = (long)var1.K;
      this.I = 1;
   }

   public final JC I(int var1) {
      return JC.I(this.Z(var1));
   }

   final void I(JC var1) {
      this.Z |= (long)(var1.K << JC.M * this.I++);
   }

   final int Z(int var1) {
      return (int)(this.Z >> JC.M * var1) & 15;
   }

   public final int I() {
      return this.I;
   }
}
