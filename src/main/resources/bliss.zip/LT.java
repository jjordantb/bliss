public class LT {
   static int I = 0;
   public static int[] Z;
   static int C = 0;
   public static int[] B;
   static int D;

   LT() throws Throwable {
      throw new Error();
   }

   static final void I(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         F var3 = XL.Z(var2, 1063164911);
         String var4 = "";
         if (var3 != null && var3.E != null) {
            var4 = var3.E;
         }

         var0.S[(var0.A += 969361751) * -203050393 - 1] = var4;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "pt.abe(" + ')');
      }
   }

   public static void I(KJ var0, int var1) {
      try {
         DDI.C = var0.B("hitbar_default", -1490079436) * 2112064137;
         DDI.D = var0.B("timerbar_default", -1467775420) * 1617597269;
         OZ.I = var0.B("headicons_pk", -1596188459) * 1432033185;
         MU.I = var0.B("headicons_prayer", -926614872) * -1214334111;
         DDI.B = var0.B("hint_headicons", -604307983) * 250641705;
         DDI.J = var0.B("hint_mapmarkers", -1518589898) * 1711228595;
         PK.A = var0.B("mapflag", -633755996) * 1542214111;
         EFI.Z = var0.B("cross", -929033367) * -626988461;
         ZZI.Z = var0.B("mapdots", -1089743906) * -1409898789;
         DDI.S = var0.B("name_icons", -946611786) * 1606490933;
         DS.I = var0.B("floorshadows", -2138341450) * -1276802557;
         BJ.I = var0.B("compass", -1033709469) * 1540144067;
         NI.M = var0.B("otherlevel", -1683756229) * -233695275;
         EG.E = var0.B("hint_mapedge", -769864981) * 902133497;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "pt.f(" + ')');
      }
   }

   static final void I(int var0) {
      try {
         int var1 = 0;
         AP var2 = XEI.mI.T(-1611682495);

         for(int var3 = 0; var3 < XEI.mI.Z(-2029823795); ++var3) {
            for(int var4 = 0; var4 < XEI.mI.C(-105400653); ++var4) {
               if (OZ.I(var2.E, var1, var3, var4, true, -777988087)) {
                  ++var1;
               }

               if (var1 >= 512) {
                  return;
               }
            }
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "pt.iu(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         var0.H[(var0.J += -391880689) * 681479919 - 1] = 2053897963 * var3.w;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "pt.pg(" + ')');
      }
   }
}
