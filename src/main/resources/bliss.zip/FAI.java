public interface FAI {
   int method249(int var1);

   int method250(int var1, byte var2);

   int method251(int var1);

   int method252(int var1, byte var2);

   int method253(int var1);

   int method254(int var1);

   int method255(int var1);
}
