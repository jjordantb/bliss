import jaclib.memory.Stream;
import java.nio.ByteBuffer;

public class ISI extends YJI {
   float S = -3.4028235E38F;
   static int clear = 74;
   OAI d;
   int f;
   int i;
   YC k;
   static int method1503;
   int method1506;
   int method1507;
   short[][] A;
   float method1508 = Float.MAX_VALUE;
   int[][][] E;
   OE[][][] method1510;
   int[][][] method1514;
   int[][][] method174;
   int[][][] G;
   int method5043;
   static int method5058 = 1;
   int[][][] method5182;
   float[][] method5382;
   NJI H;
   FY method5383 = new FY();
   byte[][] method5384;
   OAI method5404;
   static int[] method545 = new int[1];
   CC method5455;
   int method552;
   int method63;
   byte[][] method6335;
   float[][] method71;
   float[][] position;
   AE[] putShort;
   LX r;
   static int[] sqrt = new int[1];
   static int[] u = new int[1];
   int x;
   int[][][] K;

   public void h() {
      if (this.method552 > 0) {
         byte[][] var1 = new byte[this.Z * -506105871 + 1][this.I * -1148794921 + 1];

         int var3;
         for(int var2 = 1; var2 < this.Z * -506105871; ++var2) {
            for(var3 = 1; var3 < this.I * -1148794921; ++var3) {
               var1[var2][var3] = (byte)((this.method6335[var2 - 1][var3] >> 2) + (this.method6335[var2 + 1][var3] >> 3) + (this.method6335[var2][var3 - 1] >> 2) + (this.method6335[var2][var3 + 1] >> 3) + (this.method6335[var2][var3] >> 1));
            }
         }

         AE[] var67 = new AE[this.r.Z(1016688966)];
         this.r.I(var67, 2103539357);

         for(var3 = 0; var3 < var67.length; ++var3) {
            ((OE)var67[var3]).C(this.method552);
         }

         var3 = 20;
         if (this.method5182 != null) {
            var3 += 4;
         }

         if ((this.x & 7) != 0) {
            var3 += 12;
         }

         jaclib.memory.heap.I var4 = this.H.A.f(this.method552 * 4, false);
         jaclib.memory.heap.I var5 = this.H.A.f(this.method552 * var3, false);
         Stream var6 = new Stream(var5);
         Stream var7 = new Stream(var4);
         OE[] var8 = new OE[this.method552];
         int var9 = KW.C(this.method552 / 4, 1661685249);
         if (var9 < 1) {
            var9 = 1;
         }

         LX var10 = new LX(var9);
         OE[] var11 = new OE[this.method63];

         int var12;
         int var13;
         for(var12 = 0; var12 < this.Z * -506105871; ++var12) {
            for(var13 = 0; var13 < this.I * -1148794921; ++var13) {
               if (this.K[var12][var13] != null) {
                  OE[] var14 = this.method1510[var12][var13];
                  int[] var15 = this.G[var12][var13];
                  int[] var16 = this.E[var12][var13];
                  int[] var17 = this.method174[var12][var13];
                  int[] var18 = this.K[var12][var13];
                  int[] var19 = this.method1514 != null ? this.method1514[var12][var13] : null;
                  int[] var20 = this.method5182 != null ? this.method5182[var12][var13] : null;
                  if (var17 == null) {
                     var17 = var18;
                  }

                  float var21 = this.method71[var12][var13];
                  float var22 = this.position[var12][var13];
                  float var23 = this.method5382[var12][var13];
                  float var24 = this.method71[var12][var13 + 1];
                  float var25 = this.position[var12][var13 + 1];
                  float var26 = this.method5382[var12][var13 + 1];
                  float var27 = this.method71[var12 + 1][var13 + 1];
                  float var28 = this.position[var12 + 1][var13 + 1];
                  float var29 = this.method5382[var12 + 1][var13 + 1];
                  float var30 = this.method71[var12 + 1][var13];
                  float var31 = this.position[var12 + 1][var13];
                  float var32 = this.method5382[var12 + 1][var13];
                  int var33 = var1[var12][var13] & 255;
                  int var34 = var1[var12][var13 + 1] & 255;
                  int var35 = var1[var12 + 1][var13 + 1] & 255;
                  int var36 = var1[var12 + 1][var13] & 255;
                  int var37 = 0;

                  int var40;
                  label359:
                  for(int var38 = 0; var38 < var18.length; ++var38) {
                     OE var39 = var14[var38];

                     for(var40 = 0; var40 < var37; ++var40) {
                        if (var11[var40] == var39) {
                           continue label359;
                        }
                     }

                     var11[var37++] = var39;
                  }

                  short[] var83 = this.A[var13 * this.Z * -506105871 + var12] = new short[var18.length];

                  for(int var84 = 0; var84 < var18.length; ++var84) {
                     var40 = (var12 << this.B * -2137349879) + var15[var84];
                     int var41 = (var13 << this.B * -2137349879) + var16[var84];
                     int var42 = var40 >> this.f;
                     int var43 = var41 >> this.f;
                     int var44 = var18[var84];
                     int var45 = var17[var84];
                     int var46 = var19 != null ? var19[var84] : 0;
                     long var47 = (long)var45 << 48 | (long)var44 << 32 | (long)(var42 << 16) | (long)var43;
                     int var49 = var15[var84];
                     int var50 = var16[var84];
                     byte var51 = 74;
                     int var52 = 0;
                     float var53 = 1.0F;
                     float var54;
                     float var55;
                     float var56;
                     float var61;
                     int var85;
                     if (var49 == 0 && var50 == 0) {
                        var54 = var21;
                        var55 = var22;
                        var56 = var23;
                        var85 = var51 - var33;
                     } else if (var49 == 0 && var50 == this.C * -1212653763) {
                        var54 = var24;
                        var55 = var25;
                        var56 = var26;
                        var85 = var51 - var34;
                     } else if (var49 == this.C * -1212653763 && var50 == this.C * -1212653763) {
                        var54 = var27;
                        var55 = var28;
                        var56 = var29;
                        var85 = var51 - var35;
                     } else if (var49 == this.C * -1212653763 && var50 == 0) {
                        var54 = var30;
                        var55 = var31;
                        var56 = var32;
                        var85 = var51 - var36;
                     } else {
                        float var57 = (float)var49 / (float)(this.C * -1212653763);
                        float var58 = (float)var50 / (float)(this.C * -1212653763);
                        float var59 = var21 + (var30 - var21) * var57;
                        float var60 = var22 + (var31 - var22) * var57;
                        var61 = var23 + (var32 - var23) * var57;
                        float var62 = var24 + (var27 - var24) * var57;
                        float var63 = var25 + (var28 - var25) * var57;
                        float var64 = var26 + (var29 - var26) * var57;
                        var54 = var59 + (var62 - var59) * var58;
                        var55 = var60 + (var63 - var60) * var58;
                        var56 = var61 + (var64 - var61) * var58;
                        int var65 = var33 + ((var36 - var33) * var49 >> this.B * -2137349879);
                        int var66 = var34 + ((var35 - var34) * var49 >> this.B * -2137349879);
                        var85 = var51 - (var65 + ((var66 - var65) * var50 >> this.B * -2137349879));
                     }

                     if (var44 != -1) {
                        int var86 = (var44 & 127) * var85 >> 7;
                        if (var86 < 2) {
                           var86 = 2;
                        } else if (var86 > 126) {
                           var86 = 126;
                        }

                        var52 = DE.I[var44 & 'ﾀ' | var86];
                        if ((this.x & 7) == 0) {
                           var53 = this.H.BI[0] * var54 + this.H.BI[1] * var55 + this.H.BI[2] * var56;
                           var53 = this.H.AI + var53 * (var53 > 0.0F ? this.H.IZ : this.H.GI);
                        }
                     }

                     AE var88 = null;
                     if ((var40 & this.i - 1) == 0 && (var41 & this.i - 1) == 0) {
                        var88 = var10.I(var47);
                     }

                     int var87;
                     int var89;
                     if (var88 == null) {
                        if (var45 != var44) {
                           int var90 = (var45 & 127) * var85 >> 7;
                           if (var90 < 2) {
                              var90 = 2;
                           } else if (var90 > 126) {
                              var90 = 126;
                           }

                           var89 = DE.I[var45 & 'ﾀ' | var90];
                           if ((this.x & 7) == 0) {
                              float var10000 = this.H.BI[0] * var54 + this.H.BI[1] * var55 + this.H.BI[2] * var56;
                              var61 = this.H.AI + var53 * (var53 > 0.0F ? this.H.IZ : this.H.GI);
                              int var91 = var89 >> 16 & 255;
                              int var92 = var89 >> 8 & 255;
                              int var93 = var89 & 255;
                              var91 = (int)((float)var91 * var61);
                              if (var91 < 0) {
                                 var91 = 0;
                              } else if (var91 > 255) {
                                 var91 = 255;
                              }

                              var92 = (int)((float)var92 * var61);
                              if (var92 < 0) {
                                 var92 = 0;
                              } else if (var92 > 255) {
                                 var92 = 255;
                              }

                              var93 = (int)((float)var93 * var61);
                              if (var93 < 0) {
                                 var93 = 0;
                              } else if (var93 > 255) {
                                 var93 = 255;
                              }

                              var89 = var91 << 16 | var92 << 8 | var93;
                           }
                        } else {
                           var89 = var52;
                        }

                        if (Stream.r()) {
                           var6.d((float)var40);
                           var6.d((float)(this.I(var40, var41, -1715806278) + var46));
                           var6.d((float)var41);
                           var6.d((float)var40);
                           var6.d((float)var41);
                           if (this.method5182 != null) {
                              var6.d(var20 != null ? (float)(var20[var84] - 1) : 0.0F);
                           }

                           if ((this.x & 7) != 0) {
                              var6.d(var54);
                              var6.d(var55);
                              var6.d(var56);
                           }
                        } else {
                           var6.u((float)var40);
                           var6.u((float)(this.I(var40, var41, -2089316863) + var46));
                           var6.u((float)var41);
                           var6.u((float)var40);
                           var6.u((float)var41);
                           if (this.method5182 != null) {
                              var6.u(var20 != null ? (float)(var20[var84] - 1) : 0.0F);
                           }

                           if ((this.x & 7) != 0) {
                              var6.u(var54);
                              var6.u(var55);
                              var6.u(var56);
                           }
                        }

                        if (this.H.oI == 0) {
                           var7.i(-16777216 | var89);
                        } else {
                           var7.k(-16777216 | var89);
                        }

                        var87 = this.method1506++;
                        var83[var84] = (short)var87;
                        if (var44 != -1) {
                           var8[var87] = var14[var84];
                        }

                        var10.I(new DG(var83[var84]), var47);
                     } else {
                        var83[var84] = ((DG)var88).J;
                        var87 = var83[var84] & '\uffff';
                        if (var44 != -1 && var14[var84].Z * 7051297995265073167L < var8[var87].Z * 7051297995265073167L) {
                           var8[var87] = var14[var84];
                        }
                     }

                     for(var89 = 0; var89 < var37; ++var89) {
                        var11[var89].I(var87, var52, var85, var53);
                     }

                     ++this.method1507;
                  }
               }
            }
         }

         for(var12 = 0; var12 < this.method1506; ++var12) {
            OE var68 = var8[var12];
            if (var68 != null) {
               var68.B(var12);
            }
         }

         for(var12 = 0; var12 < this.Z * -506105871; ++var12) {
            for(var13 = 0; var13 < this.I * -1148794921; ++var13) {
               short[] var69 = this.A[var13 * this.Z * -506105871 + var12];
               if (var69 != null) {
                  int var72 = 0;

                  for(int var75 = 0; var75 < var69.length; ++var72) {
                     int var76 = var69[var75++] & '\uffff';
                     int var77 = var69[var75++] & '\uffff';
                     int var78 = var69[var75++] & '\uffff';
                     OE var79 = var8[var76];
                     OE var80 = var8[var77];
                     OE var81 = var8[var78];
                     OE var82 = null;
                     if (var79 != null) {
                        var79.I(var12, var13, var72);
                        var82 = var79;
                     }

                     if (var80 != null) {
                        var80.I(var12, var13, var72);
                        if (var82 == null || var80.Z * 7051297995265073167L < var82.Z * 7051297995265073167L) {
                           var82 = var80;
                        }
                     }

                     if (var81 != null) {
                        var81.I(var12, var13, var72);
                        if (var82 == null || var81.Z * 7051297995265073167L < var82.Z * 7051297995265073167L) {
                           var82 = var81;
                        }
                     }

                     if (var82 != null) {
                        if (var79 != null) {
                           var82.B(var76);
                        }

                        if (var80 != null) {
                           var82.B(var77);
                        }

                        if (var81 != null) {
                           var82.B(var78);
                        }

                        var82.I(var12, var13, var72);
                     }
                  }
               }
            }
         }

         var6.x();
         var7.x();
         this.d = this.H.method5382(false);
         this.d.method71(this.method1506 * 4, 4, var4);
         this.method5404 = this.H.method5382(false);
         this.method5404.method71(this.method1506 * var3, var3, var5);
         if ((this.x & 7) != 0) {
            if (this.method5182 != null) {
               this.method5455 = this.H.method5404(new KB[]{new KB(new JC[]{JC.N, JC.D, JC.J, JC.Z}), new KB(JC.C)});
            } else {
               this.method5455 = this.H.method5404(new KB[]{new KB(new JC[]{JC.N, JC.D, JC.Z}), new KB(JC.C)});
            }
         } else if (this.method5182 != null) {
            this.method5455 = this.H.method5404(new KB[]{new KB(new JC[]{JC.N, JC.D, JC.J}), new KB(JC.C)});
         } else {
            this.method5455 = this.H.method5404(new KB[]{new KB(new JC[]{JC.N, JC.D}), new KB(JC.C)});
         }

         var12 = 0;

         for(var13 = 0; var13 < var67.length; ++var13) {
            OE var70 = (OE)var67[var13];
            if (var70.G > 0) {
               var67[var12++] = var70;
            }
         }

         this.putShort = new AE[var12];
         long[] var73 = new long[var12];

         for(int var71 = 0; var71 < var12; ++var71) {
            OE var74 = (OE)var67[var71];
            var73[var71] = var74.Z * 7051297995265073167L;
            this.putShort[var71] = var74;
            var74.D(this.method1506);
         }

         HR.I(var73, this.putShort, (byte)-43);
         if (this.k != null) {
            this.k.I();
         }
      } else {
         this.k = null;
      }

      if ((this.method5043 & 2) == 0) {
         this.E = null;
         this.G = null;
         this.K = null;
      }

      this.method5182 = null;
      this.method174 = null;
      this.method1514 = null;
      this.method1510 = null;
      this.method6335 = null;
      this.r = null;
      this.method5382 = null;
      this.position = null;
      this.method71 = null;
   }

   public boolean method6355(GJI var1, int var2, int var3, int var4, int var5, boolean var6) {
      if (this.k != null && var1 != null) {
         int var7 = var2 - (var3 * this.H.NI >> 8) >> this.H.XI;
         int var8 = var4 - (var3 * this.H.iI >> 8) >> this.H.XI;
         return this.k.C(var1, var7, var8);
      } else {
         return false;
      }
   }

   public void method6335(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, ADI var11, boolean var12) {
      FEI var13 = this.H.LZ;
      if (var6 != null && this.method5182 == null) {
         this.method5182 = new int[this.Z * -506105871][this.I * -1148794921][];
      }

      if (var4 != null && this.method1514 == null) {
         this.method1514 = new int[this.Z * -506105871][this.I * -1148794921][];
      }

      this.G[var1][var2] = var3;
      this.E[var1][var2] = var5;
      this.K[var1][var2] = var7;
      this.method174[var1][var2] = var8;
      if (this.method5182 != null) {
         this.method5182[var1][var2] = var6;
      }

      if (this.method1514 != null) {
         this.method1514[var1][var2] = var4;
      }

      OE[] var14 = this.method1510[var1][var2] = new OE[var7.length];

      for(int var15 = 0; var15 < var7.length; ++var15) {
         int var16 = var9[var15];
         int var17 = var10[var15];
         if ((this.x & 32) != 0 && var16 != -1 && var13.method174(var16, 1147162095).B) {
            var17 = 128;
            var16 = -1;
         }

         long var18 = (long)(var11.C * -1475891183) << 48 | (long)(var11.I * 1996750669) << 42 | (long)(var11.Z * -1212608691) << 28 | (long)(var17 << 14) | (long)var16;

         AE var20;
         for(var20 = this.r.I(var18); var20 != null; var20 = this.r.I(-1979022775)) {
            OE var21 = (OE)var20;
            if (var21.S == var16 && var21.L == (float)var17 && var21.A.I((ADI)var11, (byte)61)) {
               break;
            }
         }

         if (var20 == null) {
            var14[var15] = new OE(this, var16, var17, var11);
            this.r.I(var14[var15], var18);
         } else {
            var14[var15] = (OE)var20;
         }
      }

      if (var12) {
         this.method5384[var1][var2] = (byte)(this.method5384[var1][var2] | 1);
      }

      if (var7.length > this.method63) {
         this.method63 = var7.length;
      }

      this.method552 += var7.length;
   }

   public GJI aa(int var1, int var2, GJI var3) {
      if ((this.method5384[var1][var2] & 1) == 0) {
         return null;
      } else {
         int var4 = this.C * -1212653763 >> this.H.XI;
         KJI var5 = (KJI)var3;
         KJI var6;
         if (var5 != null && var5.Z(var4, var4)) {
            var6 = var5;
            var5.I();
         } else {
            var6 = new KJI(this.H, var4, var4);
         }

         var6.I(0, 0, var4, var4);
         this.B(var6, var1, var2);
         return var6;
      }
   }

   ISI(NJI var1, int var2, int var3, int var4, int var5, int[][] var6, int[][] var7, int var8) {
      super(var4, var5, var8, var6);
      this.H = var1;
      this.f = this.B * -2137349879 - 2;
      this.i = 1 << this.f;
      this.method5043 = var2;
      this.x = var3;
      this.method1514 = new int[var4][var5][];
      this.method1510 = new OE[var4][var5][];
      this.G = new int[var4][var5][];
      this.E = new int[var4][var5][];
      this.K = new int[var4][var5][];
      this.method174 = new int[var4][var5][];
      this.A = new short[var4 * var5][];
      this.method5384 = new byte[var4][var5];
      this.method6335 = new byte[var4 + 1][var5 + 1];
      this.method71 = new float[this.Z * -506105871 + 1][this.I * -1148794921 + 1];
      this.position = new float[this.Z * -506105871 + 1][this.I * -1148794921 + 1];
      this.method5382 = new float[this.Z * -506105871 + 1][this.I * -1148794921 + 1];

      for(int var9 = 0; var9 <= this.I * -1148794921; ++var9) {
         for(int var10 = 0; var10 <= this.Z * -506105871; ++var10) {
            int var11 = this.D[var10][var9];
            if ((float)var11 < this.method1508) {
               this.method1508 = (float)var11;
            }

            if ((float)var11 > this.S) {
               this.S = (float)var11;
            }

            if (var10 > 0 && var9 > 0 && var10 < this.Z * -506105871 && var9 < this.I * -1148794921) {
               int var12 = var7[var10 + 1][var9] - var7[var10 - 1][var9];
               int var13 = var7[var10][var9 + 1] - var7[var10][var9 - 1];
               float var14 = (float)(1.0D / Math.sqrt((double)(var12 * var12 + 4 * var8 * var8 + var13 * var13)));
               this.method71[var10][var9] = (float)var12 * var14;
               this.position[var10][var9] = (float)(-var8 * 2) * var14;
               this.method5382[var10][var9] = (float)var13 * var14;
            }
         }
      }

      --this.method1508;
      ++this.S;
      this.r = new LX(128);
      if ((this.x & 16) != 0) {
         this.k = new YC(this.H, this);
      }

   }

   public void method6346(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, ADI var11, boolean var12) {
      FEI var13 = this.H.LZ;
      if (var6 != null && this.method5182 == null) {
         this.method5182 = new int[this.Z * -506105871][this.I * -1148794921][];
      }

      if (var4 != null && this.method1514 == null) {
         this.method1514 = new int[this.Z * -506105871][this.I * -1148794921][];
      }

      this.G[var1][var2] = var3;
      this.E[var1][var2] = var5;
      this.K[var1][var2] = var7;
      this.method174[var1][var2] = var8;
      if (this.method5182 != null) {
         this.method5182[var1][var2] = var6;
      }

      if (this.method1514 != null) {
         this.method1514[var1][var2] = var4;
      }

      OE[] var14 = this.method1510[var1][var2] = new OE[var7.length];

      for(int var15 = 0; var15 < var7.length; ++var15) {
         int var16 = var9[var15];
         int var17 = var10[var15];
         if ((this.x & 32) != 0 && var16 != -1 && var13.method174(var16, 469546768).B) {
            var17 = 128;
            var16 = -1;
         }

         long var18 = (long)(var11.C * -1475891183) << 48 | (long)(var11.I * 1996750669) << 42 | (long)(var11.Z * -1212608691) << 28 | (long)(var17 << 14) | (long)var16;

         AE var20;
         for(var20 = this.r.I(var18); var20 != null; var20 = this.r.I(-1981494486)) {
            OE var21 = (OE)var20;
            if (var21.S == var16 && var21.L == (float)var17 && var21.A.I(var11, (byte)-65)) {
               break;
            }
         }

         if (var20 == null) {
            var14[var15] = new OE(this, var16, var17, var11);
            this.r.I(var14[var15], var18);
         } else {
            var14[var15] = (OE)var20;
         }
      }

      if (var12) {
         this.method5384[var1][var2] = (byte)(this.method5384[var1][var2] | 1);
      }

      if (var7.length > this.method63) {
         this.method63 = var7.length;
      }

      this.method552 += var7.length;
   }

   public void method6339(int var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean[][] var8) {
      if (this.method552 > 0) {
         PAI var9 = this.H.Z(this.method1507);
         int var10 = 0;
         int var11 = 32767;
         int var12 = -32768;
         ByteBuffer var13 = this.H.F;
         var13.clear();

         for(int var14 = var5; var14 < var7; ++var14) {
            int var15 = var14 * this.Z * -506105871 + var4;

            for(int var16 = var4; var16 < var6; ++var16) {
               if (var8[var16 - var4][var14 - var5]) {
                  short[] var17 = this.A[var15];
                  if (var17 != null) {
                     for(int var18 = 0; var18 < var17.length; ++var18) {
                        int var19 = var17[var18] & '\uffff';
                        if (var19 > var12) {
                           var12 = var19;
                        }

                        if (var19 < var11) {
                           var11 = var19;
                        }

                        var13.putShort((short)var19);
                        ++var10;
                     }
                  }
               }

               ++var15;
            }
         }

         var9.method63(0, var13.position(), this.H.J);
         if (var10 > 0) {
            this.H.T();
            FZ var20 = this.H.YI;
            this.H.method5383(0, this.method5404);
            this.H.method5383(1, this.d);
            this.H.method5455(this.method5455);
            this.H.method5384(var9);
            this.H.method5043(LF.K);
            float var21 = (float)this.H.I((short)2045).method545();
            float var22 = (float)this.H.I((short)-2467).method552();
            LF var23 = new LF();
            LF var24 = new LF();
            var23.I(1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 1.0F, 0.0F);
            var24.B((float)var3 / (256.0F * (float)(this.C * -1212653763)), (float)(-var3) / (256.0F * (float)(this.C * -1212653763)), 1.0F / (this.S - this.method1508));
            var24.C((float)var1 - (float)(var4 * var3) / 256.0F, (float)var2 + (float)(var7 * var3) / 256.0F, -this.method1508 / (this.S - this.method1508));
            var24.I(2.0F / var21, 2.0F / var22, 1.0F);
            var24.C(-1.0F, -1.0F, 0.0F);
            this.H.P.I(var23, var24);
            this.H.Q.I(this.H.P);
            this.H.method5182(this.H.Q);
            var20.method1506(YF.Z);
            var20.K.I(0.0F, 0.0F, 0.0F, 0.0F);
            var20.E.Z(0.0F, 0.0F, 0.0F);
            var20.G.I(0.0F, 0.0F, 0.0F, 0.0F);
            var20.H.Z(0.0F, 0.0F, 0.0F);
            var20.D = this.H.VI;
            var20.J.J();
            var20.R = var11;
            var20.T = var12 - var11 + 1;
            var20.U = 0;
            var20.Z = var10 / 3;
            var20.method1514(false);
         }
      }

   }

   public void method6336(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, int[] var11, int[] var12, int[] var13, ADI var14, boolean var15) {
      int var16 = var10.length;
      int[] var17 = new int[var16 * 3];
      int[] var18 = new int[var16 * 3];
      int[] var19 = new int[var16 * 3];
      int[] var20 = new int[var16 * 3];
      int[] var21 = new int[var16 * 3];
      int[] var22 = new int[var16 * 3];
      int[] var23 = var4 != null ? new int[var16 * 3] : null;
      int[] var24 = var6 != null ? new int[var16 * 3] : null;
      int var25 = 0;

      for(int var26 = 0; var26 < var16; ++var26) {
         int var27 = var7[var26];
         int var28 = var8[var26];
         int var29 = var9[var26];
         var17[var25] = var3[var27];
         var18[var25] = var5[var27];
         var19[var25] = var10[var26];
         var21[var25] = var12[var26];
         var22[var25] = var13[var26];
         var20[var25] = var11 != null ? var11[var26] : var10[var26];
         if (var4 != null) {
            var23[var25] = var4[var27];
         }

         if (var6 != null) {
            var24[var25] = var6[var27];
         }

         ++var25;
         var17[var25] = var3[var28];
         var18[var25] = var5[var28];
         var19[var25] = var10[var26];
         var21[var25] = var12[var26];
         var22[var25] = var13[var26];
         var20[var25] = var11 != null ? var11[var26] : var10[var26];
         if (var4 != null) {
            var23[var25] = var4[var28];
         }

         if (var6 != null) {
            var24[var25] = var6[var28];
         }

         ++var25;
         var17[var25] = var3[var29];
         var18[var25] = var5[var29];
         var19[var25] = var10[var26];
         var21[var25] = var12[var26];
         var22[var25] = var13[var26];
         var20[var25] = var11 != null ? var11[var26] : var10[var26];
         if (var4 != null) {
            var23[var25] = var4[var29];
         }

         if (var6 != null) {
            var24[var25] = var6[var29];
         }

         ++var25;
      }

      this.method6335(var1, var2, var17, var23, var18, var24, var19, var20, var21, var22, var14, var15);
   }

   void B(KJI var1, int var2, int var3) {
      int[] var4 = this.G[var2][var3];
      int[] var5 = this.E[var2][var3];
      int var6 = var4.length;
      if (sqrt.length < var6) {
         sqrt = new int[var6];
         u = new int[var6];
      }

      int var7;
      for(var7 = 0; var7 < var6; ++var7) {
         sqrt[var7] = var4[var7] >> this.H.XI;
         u[var7] = var5[var7] >> this.H.XI;
      }

      var7 = 0;

      while(var7 < var6) {
         int var8 = sqrt[var7];
         int var9 = u[var7++];
         int var10 = sqrt[var7];
         int var11 = u[var7++];
         int var12 = sqrt[var7];
         int var13 = u[var7++];
         if ((var8 - var10) * (var11 - var13) - (var11 - var9) * (var12 - var10) > 0) {
            var1.I(var9, var11, var13, var8, var10, var12);
         }
      }

   }

   public boolean method6353(GJI var1, int var2, int var3, int var4, int var5, boolean var6) {
      if (this.k != null && var1 != null) {
         int var7 = var2 - (var3 * this.H.NI >> 8) >> this.H.XI;
         int var8 = var4 - (var3 * this.H.iI >> 8) >> this.H.XI;
         return this.k.C(var1, var7, var8);
      } else {
         return false;
      }
   }

   public void UA(GJI var1, int var2, int var3, int var4, int var5, boolean var6) {
      if (this.k != null && var1 != null) {
         int var7 = var2 - (var3 * this.H.NI >> 8) >> this.H.XI;
         int var8 = var4 - (var3 * this.H.iI >> 8) >> this.H.XI;
         this.k.Z(var1, var7, var8);
      }

   }

   public void NA(GJI var1, int var2, int var3, int var4, int var5, boolean var6) {
      if (this.k != null && var1 != null) {
         int var7 = var2 - (var3 * this.H.NI >> 8) >> this.H.XI;
         int var8 = var4 - (var3 * this.H.iI >> 8) >> this.H.XI;
         this.k.I(var1, var7, var8);
      }

   }

   public void method6345(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, ADI var11, boolean var12) {
      FEI var13 = this.H.LZ;
      if (var6 != null && this.method5182 == null) {
         this.method5182 = new int[this.Z * -506105871][this.I * -1148794921][];
      }

      if (var4 != null && this.method1514 == null) {
         this.method1514 = new int[this.Z * -506105871][this.I * -1148794921][];
      }

      this.G[var1][var2] = var3;
      this.E[var1][var2] = var5;
      this.K[var1][var2] = var7;
      this.method174[var1][var2] = var8;
      if (this.method5182 != null) {
         this.method5182[var1][var2] = var6;
      }

      if (this.method1514 != null) {
         this.method1514[var1][var2] = var4;
      }

      OE[] var14 = this.method1510[var1][var2] = new OE[var7.length];

      for(int var15 = 0; var15 < var7.length; ++var15) {
         int var16 = var9[var15];
         int var17 = var10[var15];
         if ((this.x & 32) != 0 && var16 != -1 && var13.method174(var16, 645709692).B) {
            var17 = 128;
            var16 = -1;
         }

         long var18 = (long)(var11.C * -1475891183) << 48 | (long)(var11.I * 1996750669) << 42 | (long)(var11.Z * -1212608691) << 28 | (long)(var17 << 14) | (long)var16;

         AE var20;
         for(var20 = this.r.I(var18); var20 != null; var20 = this.r.I(-2025134225)) {
            OE var21 = (OE)var20;
            if (var21.S == var16 && var21.L == (float)var17 && var21.A.I(var11, (byte)-112)) {
               break;
            }
         }

         if (var20 == null) {
            var14[var15] = new OE(this, var16, var17, var11);
            this.r.I(var14[var15], var18);
         } else {
            var14[var15] = (OE)var20;
         }
      }

      if (var12) {
         this.method5384[var1][var2] = (byte)(this.method5384[var1][var2] | 1);
      }

      if (var7.length > this.method63) {
         this.method63 = var7.length;
      }

      this.method552 += var7.length;
   }

   public void method6356(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, int[] var11, int[] var12, int[] var13, ADI var14, boolean var15) {
      int var16 = var10.length;
      int[] var17 = new int[var16 * 3];
      int[] var18 = new int[var16 * 3];
      int[] var19 = new int[var16 * 3];
      int[] var20 = new int[var16 * 3];
      int[] var21 = new int[var16 * 3];
      int[] var22 = new int[var16 * 3];
      int[] var23 = var4 != null ? new int[var16 * 3] : null;
      int[] var24 = var6 != null ? new int[var16 * 3] : null;
      int var25 = 0;

      for(int var26 = 0; var26 < var16; ++var26) {
         int var27 = var7[var26];
         int var28 = var8[var26];
         int var29 = var9[var26];
         var17[var25] = var3[var27];
         var18[var25] = var5[var27];
         var19[var25] = var10[var26];
         var21[var25] = var12[var26];
         var22[var25] = var13[var26];
         var20[var25] = var11 != null ? var11[var26] : var10[var26];
         if (var4 != null) {
            var23[var25] = var4[var27];
         }

         if (var6 != null) {
            var24[var25] = var6[var27];
         }

         ++var25;
         var17[var25] = var3[var28];
         var18[var25] = var5[var28];
         var19[var25] = var10[var26];
         var21[var25] = var12[var26];
         var22[var25] = var13[var26];
         var20[var25] = var11 != null ? var11[var26] : var10[var26];
         if (var4 != null) {
            var23[var25] = var4[var28];
         }

         if (var6 != null) {
            var24[var25] = var6[var28];
         }

         ++var25;
         var17[var25] = var3[var29];
         var18[var25] = var5[var29];
         var19[var25] = var10[var26];
         var21[var25] = var12[var26];
         var22[var25] = var13[var26];
         var20[var25] = var11 != null ? var11[var26] : var10[var26];
         if (var4 != null) {
            var23[var25] = var4[var29];
         }

         if (var6 != null) {
            var24[var25] = var6[var29];
         }

         ++var25;
      }

      this.method6335(var1, var2, var17, var23, var18, var24, var19, var20, var21, var22, var14, var15);
   }

   public void method6343(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, int[] var11, int[] var12, int[] var13, ADI var14, boolean var15) {
      int var16 = var10.length;
      int[] var17 = new int[var16 * 3];
      int[] var18 = new int[var16 * 3];
      int[] var19 = new int[var16 * 3];
      int[] var20 = new int[var16 * 3];
      int[] var21 = new int[var16 * 3];
      int[] var22 = new int[var16 * 3];
      int[] var23 = var4 != null ? new int[var16 * 3] : null;
      int[] var24 = var6 != null ? new int[var16 * 3] : null;
      int var25 = 0;

      for(int var26 = 0; var26 < var16; ++var26) {
         int var27 = var7[var26];
         int var28 = var8[var26];
         int var29 = var9[var26];
         var17[var25] = var3[var27];
         var18[var25] = var5[var27];
         var19[var25] = var10[var26];
         var21[var25] = var12[var26];
         var22[var25] = var13[var26];
         var20[var25] = var11 != null ? var11[var26] : var10[var26];
         if (var4 != null) {
            var23[var25] = var4[var27];
         }

         if (var6 != null) {
            var24[var25] = var6[var27];
         }

         ++var25;
         var17[var25] = var3[var28];
         var18[var25] = var5[var28];
         var19[var25] = var10[var26];
         var21[var25] = var12[var26];
         var22[var25] = var13[var26];
         var20[var25] = var11 != null ? var11[var26] : var10[var26];
         if (var4 != null) {
            var23[var25] = var4[var28];
         }

         if (var6 != null) {
            var24[var25] = var6[var28];
         }

         ++var25;
         var17[var25] = var3[var29];
         var18[var25] = var5[var29];
         var19[var25] = var10[var26];
         var21[var25] = var12[var26];
         var22[var25] = var13[var26];
         var20[var25] = var11 != null ? var11[var26] : var10[var26];
         if (var4 != null) {
            var23[var25] = var4[var29];
         }

         if (var6 != null) {
            var24[var25] = var6[var29];
         }

         ++var25;
      }

      this.method6335(var1, var2, var17, var23, var18, var24, var19, var20, var21, var22, var14, var15);
   }

   public void method6337(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, int[] var11, int[] var12, int[] var13, ADI var14, boolean var15) {
      int var16 = var10.length;
      int[] var17 = new int[var16 * 3];
      int[] var18 = new int[var16 * 3];
      int[] var19 = new int[var16 * 3];
      int[] var20 = new int[var16 * 3];
      int[] var21 = new int[var16 * 3];
      int[] var22 = new int[var16 * 3];
      int[] var23 = var4 != null ? new int[var16 * 3] : null;
      int[] var24 = var6 != null ? new int[var16 * 3] : null;
      int var25 = 0;

      for(int var26 = 0; var26 < var16; ++var26) {
         int var27 = var7[var26];
         int var28 = var8[var26];
         int var29 = var9[var26];
         var17[var25] = var3[var27];
         var18[var25] = var5[var27];
         var19[var25] = var10[var26];
         var21[var25] = var12[var26];
         var22[var25] = var13[var26];
         var20[var25] = var11 != null ? var11[var26] : var10[var26];
         if (var4 != null) {
            var23[var25] = var4[var27];
         }

         if (var6 != null) {
            var24[var25] = var6[var27];
         }

         ++var25;
         var17[var25] = var3[var28];
         var18[var25] = var5[var28];
         var19[var25] = var10[var26];
         var21[var25] = var12[var26];
         var22[var25] = var13[var26];
         var20[var25] = var11 != null ? var11[var26] : var10[var26];
         if (var4 != null) {
            var23[var25] = var4[var28];
         }

         if (var6 != null) {
            var24[var25] = var6[var28];
         }

         ++var25;
         var17[var25] = var3[var29];
         var18[var25] = var5[var29];
         var19[var25] = var10[var26];
         var21[var25] = var12[var26];
         var22[var25] = var13[var26];
         var20[var25] = var11 != null ? var11[var26] : var10[var26];
         if (var4 != null) {
            var23[var25] = var4[var29];
         }

         if (var6 != null) {
            var24[var25] = var6[var29];
         }

         ++var25;
      }

      this.method6335(var1, var2, var17, var23, var18, var24, var19, var20, var21, var22, var14, var15);
   }

   public GJI ax(int var1, int var2, GJI var3) {
      if ((this.method5384[var1][var2] & 1) == 0) {
         return null;
      } else {
         int var4 = this.C * -1212653763 >> this.H.XI;
         KJI var5 = (KJI)var3;
         KJI var6;
         if (var5 != null && var5.Z(var4, var4)) {
            var6 = var5;
            var5.I();
         } else {
            var6 = new KJI(this.H, var4, var4);
         }

         var6.I(0, 0, var4, var4);
         this.B(var6, var1, var2);
         return var6;
      }
   }

   public GJI w(int var1, int var2, GJI var3) {
      if ((this.method5384[var1][var2] & 1) == 0) {
         return null;
      } else {
         int var4 = this.C * -1212653763 >> this.H.XI;
         KJI var5 = (KJI)var3;
         KJI var6;
         if (var5 != null && var5.Z(var4, var4)) {
            var6 = var5;
            var5.I();
         } else {
            var6 = new KJI(this.H, var4, var4);
         }

         var6.I(0, 0, var4, var4);
         this.B(var6, var1, var2);
         return var6;
      }
   }

   public GJI l(int var1, int var2, GJI var3) {
      if ((this.method5384[var1][var2] & 1) == 0) {
         return null;
      } else {
         int var4 = this.C * -1212653763 >> this.H.XI;
         KJI var5 = (KJI)var3;
         KJI var6;
         if (var5 != null && var5.Z(var4, var4)) {
            var6 = var5;
            var5.I();
         } else {
            var6 = new KJI(this.H, var4, var4);
         }

         var6.I(0, 0, var4, var4);
         this.B(var6, var1, var2);
         return var6;
      }
   }

   public void SA() {
      if (this.method552 > 0) {
         byte[][] var1 = new byte[this.Z * -506105871 + 1][this.I * -1148794921 + 1];

         int var3;
         for(int var2 = 1; var2 < this.Z * -506105871; ++var2) {
            for(var3 = 1; var3 < this.I * -1148794921; ++var3) {
               var1[var2][var3] = (byte)((this.method6335[var2 - 1][var3] >> 2) + (this.method6335[var2 + 1][var3] >> 3) + (this.method6335[var2][var3 - 1] >> 2) + (this.method6335[var2][var3 + 1] >> 3) + (this.method6335[var2][var3] >> 1));
            }
         }

         AE[] var67 = new AE[this.r.Z(1332224628)];
         this.r.I(var67, 2094257346);

         for(var3 = 0; var3 < var67.length; ++var3) {
            ((OE)var67[var3]).C(this.method552);
         }

         var3 = 20;
         if (this.method5182 != null) {
            var3 += 4;
         }

         if ((this.x & 7) != 0) {
            var3 += 12;
         }

         jaclib.memory.heap.I var4 = this.H.A.f(this.method552 * 4, false);
         jaclib.memory.heap.I var5 = this.H.A.f(this.method552 * var3, false);
         Stream var6 = new Stream(var5);
         Stream var7 = new Stream(var4);
         OE[] var8 = new OE[this.method552];
         int var9 = KW.C(this.method552 / 4, 2098856769);
         if (var9 < 1) {
            var9 = 1;
         }

         LX var10 = new LX(var9);
         OE[] var11 = new OE[this.method63];

         int var12;
         int var13;
         for(var12 = 0; var12 < this.Z * -506105871; ++var12) {
            for(var13 = 0; var13 < this.I * -1148794921; ++var13) {
               if (this.K[var12][var13] != null) {
                  OE[] var14 = this.method1510[var12][var13];
                  int[] var15 = this.G[var12][var13];
                  int[] var16 = this.E[var12][var13];
                  int[] var17 = this.method174[var12][var13];
                  int[] var18 = this.K[var12][var13];
                  int[] var19 = this.method1514 != null ? this.method1514[var12][var13] : null;
                  int[] var20 = this.method5182 != null ? this.method5182[var12][var13] : null;
                  if (var17 == null) {
                     var17 = var18;
                  }

                  float var21 = this.method71[var12][var13];
                  float var22 = this.position[var12][var13];
                  float var23 = this.method5382[var12][var13];
                  float var24 = this.method71[var12][var13 + 1];
                  float var25 = this.position[var12][var13 + 1];
                  float var26 = this.method5382[var12][var13 + 1];
                  float var27 = this.method71[var12 + 1][var13 + 1];
                  float var28 = this.position[var12 + 1][var13 + 1];
                  float var29 = this.method5382[var12 + 1][var13 + 1];
                  float var30 = this.method71[var12 + 1][var13];
                  float var31 = this.position[var12 + 1][var13];
                  float var32 = this.method5382[var12 + 1][var13];
                  int var33 = var1[var12][var13] & 255;
                  int var34 = var1[var12][var13 + 1] & 255;
                  int var35 = var1[var12 + 1][var13 + 1] & 255;
                  int var36 = var1[var12 + 1][var13] & 255;
                  int var37 = 0;

                  int var40;
                  label359:
                  for(int var38 = 0; var38 < var18.length; ++var38) {
                     OE var39 = var14[var38];

                     for(var40 = 0; var40 < var37; ++var40) {
                        if (var11[var40] == var39) {
                           continue label359;
                        }
                     }

                     var11[var37++] = var39;
                  }

                  short[] var83 = this.A[var13 * this.Z * -506105871 + var12] = new short[var18.length];

                  for(int var84 = 0; var84 < var18.length; ++var84) {
                     var40 = (var12 << this.B * -2137349879) + var15[var84];
                     int var41 = (var13 << this.B * -2137349879) + var16[var84];
                     int var42 = var40 >> this.f;
                     int var43 = var41 >> this.f;
                     int var44 = var18[var84];
                     int var45 = var17[var84];
                     int var46 = var19 != null ? var19[var84] : 0;
                     long var47 = (long)var45 << 48 | (long)var44 << 32 | (long)(var42 << 16) | (long)var43;
                     int var49 = var15[var84];
                     int var50 = var16[var84];
                     byte var51 = 74;
                     int var52 = 0;
                     float var53 = 1.0F;
                     float var54;
                     float var55;
                     float var56;
                     float var61;
                     int var85;
                     if (var49 == 0 && var50 == 0) {
                        var54 = var21;
                        var55 = var22;
                        var56 = var23;
                        var85 = var51 - var33;
                     } else if (var49 == 0 && var50 == this.C * -1212653763) {
                        var54 = var24;
                        var55 = var25;
                        var56 = var26;
                        var85 = var51 - var34;
                     } else if (var49 == this.C * -1212653763 && var50 == this.C * -1212653763) {
                        var54 = var27;
                        var55 = var28;
                        var56 = var29;
                        var85 = var51 - var35;
                     } else if (var49 == this.C * -1212653763 && var50 == 0) {
                        var54 = var30;
                        var55 = var31;
                        var56 = var32;
                        var85 = var51 - var36;
                     } else {
                        float var57 = (float)var49 / (float)(this.C * -1212653763);
                        float var58 = (float)var50 / (float)(this.C * -1212653763);
                        float var59 = var21 + (var30 - var21) * var57;
                        float var60 = var22 + (var31 - var22) * var57;
                        var61 = var23 + (var32 - var23) * var57;
                        float var62 = var24 + (var27 - var24) * var57;
                        float var63 = var25 + (var28 - var25) * var57;
                        float var64 = var26 + (var29 - var26) * var57;
                        var54 = var59 + (var62 - var59) * var58;
                        var55 = var60 + (var63 - var60) * var58;
                        var56 = var61 + (var64 - var61) * var58;
                        int var65 = var33 + ((var36 - var33) * var49 >> this.B * -2137349879);
                        int var66 = var34 + ((var35 - var34) * var49 >> this.B * -2137349879);
                        var85 = var51 - (var65 + ((var66 - var65) * var50 >> this.B * -2137349879));
                     }

                     if (var44 != -1) {
                        int var86 = (var44 & 127) * var85 >> 7;
                        if (var86 < 2) {
                           var86 = 2;
                        } else if (var86 > 126) {
                           var86 = 126;
                        }

                        var52 = DE.I[var44 & 'ﾀ' | var86];
                        if ((this.x & 7) == 0) {
                           var53 = this.H.BI[0] * var54 + this.H.BI[1] * var55 + this.H.BI[2] * var56;
                           var53 = this.H.AI + var53 * (var53 > 0.0F ? this.H.IZ : this.H.GI);
                        }
                     }

                     AE var88 = null;
                     if ((var40 & this.i - 1) == 0 && (var41 & this.i - 1) == 0) {
                        var88 = var10.I(var47);
                     }

                     int var87;
                     int var89;
                     if (var88 == null) {
                        if (var45 != var44) {
                           int var90 = (var45 & 127) * var85 >> 7;
                           if (var90 < 2) {
                              var90 = 2;
                           } else if (var90 > 126) {
                              var90 = 126;
                           }

                           var89 = DE.I[var45 & 'ﾀ' | var90];
                           if ((this.x & 7) == 0) {
                              float var10000 = this.H.BI[0] * var54 + this.H.BI[1] * var55 + this.H.BI[2] * var56;
                              var61 = this.H.AI + var53 * (var53 > 0.0F ? this.H.IZ : this.H.GI);
                              int var91 = var89 >> 16 & 255;
                              int var92 = var89 >> 8 & 255;
                              int var93 = var89 & 255;
                              var91 = (int)((float)var91 * var61);
                              if (var91 < 0) {
                                 var91 = 0;
                              } else if (var91 > 255) {
                                 var91 = 255;
                              }

                              var92 = (int)((float)var92 * var61);
                              if (var92 < 0) {
                                 var92 = 0;
                              } else if (var92 > 255) {
                                 var92 = 255;
                              }

                              var93 = (int)((float)var93 * var61);
                              if (var93 < 0) {
                                 var93 = 0;
                              } else if (var93 > 255) {
                                 var93 = 255;
                              }

                              var89 = var91 << 16 | var92 << 8 | var93;
                           }
                        } else {
                           var89 = var52;
                        }

                        if (Stream.r()) {
                           var6.d((float)var40);
                           var6.d((float)(this.I(var40, var41, -1533098299) + var46));
                           var6.d((float)var41);
                           var6.d((float)var40);
                           var6.d((float)var41);
                           if (this.method5182 != null) {
                              var6.d(var20 != null ? (float)(var20[var84] - 1) : 0.0F);
                           }

                           if ((this.x & 7) != 0) {
                              var6.d(var54);
                              var6.d(var55);
                              var6.d(var56);
                           }
                        } else {
                           var6.u((float)var40);
                           var6.u((float)(this.I(var40, var41, -1562205139) + var46));
                           var6.u((float)var41);
                           var6.u((float)var40);
                           var6.u((float)var41);
                           if (this.method5182 != null) {
                              var6.u(var20 != null ? (float)(var20[var84] - 1) : 0.0F);
                           }

                           if ((this.x & 7) != 0) {
                              var6.u(var54);
                              var6.u(var55);
                              var6.u(var56);
                           }
                        }

                        if (this.H.oI == 0) {
                           var7.i(-16777216 | var89);
                        } else {
                           var7.k(-16777216 | var89);
                        }

                        var87 = this.method1506++;
                        var83[var84] = (short)var87;
                        if (var44 != -1) {
                           var8[var87] = var14[var84];
                        }

                        var10.I(new DG(var83[var84]), var47);
                     } else {
                        var83[var84] = ((DG)var88).J;
                        var87 = var83[var84] & '\uffff';
                        if (var44 != -1 && var14[var84].Z * 7051297995265073167L < var8[var87].Z * 7051297995265073167L) {
                           var8[var87] = var14[var84];
                        }
                     }

                     for(var89 = 0; var89 < var37; ++var89) {
                        var11[var89].I(var87, var52, var85, var53);
                     }

                     ++this.method1507;
                  }
               }
            }
         }

         for(var12 = 0; var12 < this.method1506; ++var12) {
            OE var68 = var8[var12];
            if (var68 != null) {
               var68.B(var12);
            }
         }

         for(var12 = 0; var12 < this.Z * -506105871; ++var12) {
            for(var13 = 0; var13 < this.I * -1148794921; ++var13) {
               short[] var69 = this.A[var13 * this.Z * -506105871 + var12];
               if (var69 != null) {
                  int var72 = 0;

                  for(int var75 = 0; var75 < var69.length; ++var72) {
                     int var76 = var69[var75++] & '\uffff';
                     int var77 = var69[var75++] & '\uffff';
                     int var78 = var69[var75++] & '\uffff';
                     OE var79 = var8[var76];
                     OE var80 = var8[var77];
                     OE var81 = var8[var78];
                     OE var82 = null;
                     if (var79 != null) {
                        var79.I(var12, var13, var72);
                        var82 = var79;
                     }

                     if (var80 != null) {
                        var80.I(var12, var13, var72);
                        if (var82 == null || var80.Z * 7051297995265073167L < var82.Z * 7051297995265073167L) {
                           var82 = var80;
                        }
                     }

                     if (var81 != null) {
                        var81.I(var12, var13, var72);
                        if (var82 == null || var81.Z * 7051297995265073167L < var82.Z * 7051297995265073167L) {
                           var82 = var81;
                        }
                     }

                     if (var82 != null) {
                        if (var79 != null) {
                           var82.B(var76);
                        }

                        if (var80 != null) {
                           var82.B(var77);
                        }

                        if (var81 != null) {
                           var82.B(var78);
                        }

                        var82.I(var12, var13, var72);
                     }
                  }
               }
            }
         }

         var6.x();
         var7.x();
         this.d = this.H.method5382(false);
         this.d.method71(this.method1506 * 4, 4, var4);
         this.method5404 = this.H.method5382(false);
         this.method5404.method71(this.method1506 * var3, var3, var5);
         if ((this.x & 7) != 0) {
            if (this.method5182 != null) {
               this.method5455 = this.H.method5404(new KB[]{new KB(new JC[]{JC.N, JC.D, JC.J, JC.Z}), new KB(JC.C)});
            } else {
               this.method5455 = this.H.method5404(new KB[]{new KB(new JC[]{JC.N, JC.D, JC.Z}), new KB(JC.C)});
            }
         } else if (this.method5182 != null) {
            this.method5455 = this.H.method5404(new KB[]{new KB(new JC[]{JC.N, JC.D, JC.J}), new KB(JC.C)});
         } else {
            this.method5455 = this.H.method5404(new KB[]{new KB(new JC[]{JC.N, JC.D}), new KB(JC.C)});
         }

         var12 = 0;

         for(var13 = 0; var13 < var67.length; ++var13) {
            OE var70 = (OE)var67[var13];
            if (var70.G > 0) {
               var67[var12++] = var70;
            }
         }

         this.putShort = new AE[var12];
         long[] var73 = new long[var12];

         for(int var71 = 0; var71 < var12; ++var71) {
            OE var74 = (OE)var67[var71];
            var73[var71] = var74.Z * 7051297995265073167L;
            this.putShort[var71] = var74;
            var74.D(this.method1506);
         }

         HR.I(var73, this.putShort, (byte)-13);
         if (this.k != null) {
            this.k.I();
         }
      } else {
         this.k = null;
      }

      if ((this.method5043 & 2) == 0) {
         this.E = null;
         this.G = null;
         this.K = null;
      }

      this.method5182 = null;
      this.method174 = null;
      this.method1514 = null;
      this.method1510 = null;
      this.method6335 = null;
      this.r = null;
      this.method5382 = null;
      this.position = null;
      this.method71 = null;
   }

   public void method6338(int var1, int var2, int var3, boolean[][] var4, boolean var5, int var6) {
      if (this.putShort != null) {
         int var7 = var3 + var3 + 1;
         var7 *= var7;
         if (method545.length < var7) {
            method545 = new int[var7];
         }

         int var8 = var1 - var3;
         int var9 = var8;
         if (var8 < 0) {
            var8 = 0;
         }

         int var10 = var2 - var3;
         int var11 = var10;
         if (var10 < 0) {
            var10 = 0;
         }

         int var12 = var1 + var3;
         if (var12 > this.Z * -506105871 - 1) {
            var12 = this.Z * -506105871 - 1;
         }

         int var13 = var2 + var3;
         if (var13 > this.I * -1148794921 - 1) {
            var13 = this.I * -1148794921 - 1;
         }

         method1503 = 0;

         for(int var14 = var8; var14 <= var12; ++var14) {
            boolean[] var15 = var4[var14 - var9];

            for(int var16 = var10; var16 <= var13; ++var16) {
               if (var15[var16 - var11]) {
                  method545[method1503++] = var16 * this.Z * -506105871 + var14;
               }
            }
         }

         ByteBuffer var24 = this.H.F;
         var24.clear();

         int var25;
         for(var25 = 0; var25 < this.putShort.length; ++var25) {
            OE var26 = (OE)this.putShort[var25];
            var26.I(method545, method1503);
         }

         var25 = var24.position();
         FZ var27 = this.H.YI;
         if (var25 != 0) {
            PAI var17 = this.H.Z(var25 / 2);
            var17.method63(0, var25, this.H.J);
            this.H.T();
            this.H.method5383(0, this.method5404);
            this.H.method5384(var17);
            var27.method1506(YF.Z);
            if (this.H.N > 0) {
               var27.K.I(0.0F, 0.0F, 1.0F, -this.H.EI);
               var27.E.Z((float)(this.H.aI >> 16 & 255) / 255.0F, (float)(this.H.aI >> 8 & 255) / 255.0F, (float)(this.H.aI >> 0 & 255) / 255.0F);
               this.H.Q.I(this.H.K);
               this.H.Q.D();
               var27.K.I(this.H.Q);
               var27.K.I(1.0F / (this.H.kI - this.H.EI));
            } else {
               var27.K.I(0.0F, 0.0F, 0.0F, 0.0F);
               var27.E.Z(0.0F, 0.0F, 0.0F);
            }

            int var18;
            int var19;
            OE var20;
            WCI var22;
            if ((this.x & 55) == 0) {
               var18 = 0;

               for(var19 = 0; var19 < this.putShort.length; ++var19) {
                  var20 = (OE)this.putShort[var19];
                  if (var20.J != 0) {
                     if (this.H.dI) {
                        this.H.method5058(0, var20.A);
                        var27.G.I(0.0F, 1.0F, 0.0F, (float)this.H.fI + (float)(var20.A.C * -1475891183) / 255.0F * (float)(var20.A.I * 1996750669));
                        var27.G.I(1.0F / (float)(var20.A.I * 1996750669));
                        var27.H.Z((float)(var20.A.Z * -1212608691 >> 16 & 255) / 255.0F, (float)(var20.A.Z * -1212608691 >> 8 & 255) / 255.0F, (float)(var20.A.Z * -1212608691 >> 0 & 255) / 255.0F);
                     } else {
                        var27.G.I(0.0F, 0.0F, 0.0F, 0.0F);
                        var27.H.Z(0.0F, 0.0F, 0.0F);
                     }

                     boolean var30 = false;
                     if (var20.S != -1) {
                        var27.D = this.H.uI.I(var20.S);
                        var22 = this.H.LZ.method174(var20.S, 377396513);
                        var30 = !YH.C(var22.J, -596124611);
                     } else {
                        var27.D = this.H.VI;
                     }

                     this.H.method5383(1, var20.E);
                     this.H.method5455(this.method5455);
                     var27.J.I(1.0F / var20.L, 1.0F / var20.L, 1.0F, 1.0F);
                     var27.R = var20.H;
                     var27.T = var20.K - var20.H + 1;
                     var27.U = var18;
                     var27.Z = var20.J / 3;
                     var27.method1514(var30);
                     var18 += var20.J;
                  }
               }
            } else {
               var27.M.Z(this.H.BI[0], this.H.BI[1], this.H.BI[2]);
               var27.N.Z(this.H.IZ * this.H.yI, this.H.IZ * this.H.JI, this.H.IZ * this.H.SI);
               var27.O.Z(-this.H.GI * this.H.yI, -this.H.GI * this.H.JI, -this.H.GI * this.H.SI);
               var27.C.Z(this.H.AI * this.H.yI, this.H.AI * this.H.JI, this.H.AI * this.H.SI);
               var18 = 0;

               for(var19 = 0; var19 < this.putShort.length; ++var19) {
                  var20 = (OE)this.putShort[var19];
                  if (var20.J > 0) {
                     if (this.H.dI) {
                        this.H.method5058(0, var20.A);
                        float var21 = 0.15F;
                        var27.G.I(0.0F, 1.0F / ((float)(var20.A.I * 1996750669) * var21), 0.0F, 256.0F / ((float)(var20.A.I * 1996750669) * var21));
                        var27.H.Z((float)(var20.A.Z * -1212608691 >> 16 & 255) / 255.0F, (float)(var20.A.Z * -1212608691 >> 8 & 255) / 255.0F, (float)(var20.A.Z * -1212608691 >> 0 & 255) / 255.0F);
                     } else {
                        var27.G.I(0.0F, 0.0F, 0.0F, 0.0F);
                        var27.H.Z(0.0F, 0.0F, 0.0F);
                     }

                     byte var29 = 11;
                     if (var20.S != -1) {
                        var22 = this.H.LZ.method174(var20.S, 515352996);
                        var29 = var22.J;
                        var27.D = this.H.uI.I(var20.S);
                        var27.I(var22);
                     } else {
                        var27.D = this.H.VI;
                     }

                     this.H.method5383(1, var20.E);
                     this.H.method5455(this.method5455);
                     var27.J.I(1.0F / var20.L, 1.0F / var20.L, 1.0F, 1.0F);
                     var27.R = var20.H;
                     var27.T = var20.K - var20.H + 1;
                     var27.U = var18;
                     var27.Z = var20.J / 3;
                     switch(var29) {
                     case 1:
                        var27.P.Z(this.H.M.I[12], this.H.M.I[13], this.H.M.I[14]);
                        var27.method1508(0);
                        break;
                     case 2:
                     case 4:
                     case 8:
                     case 9:
                        if (!this.H.B && (this.x & 8) != 0) {
                           PC var31 = this.H.cI;
                           var31.V.I(this.H.z);
                           var31.X.I(1.0F / (var20.L * (float)(var20.A.B * -28774789)), 1.0F / (var20.L * (float)(var20.A.B * -28774789)), 1.0F, 1.0F);
                           var31.i.Z(this.H.M.I[12], this.H.M.I[13], this.H.M.I[14]);
                           WCI var23 = this.H.LZ.method174(var20.S, 191676686);
                           var31.z = var23.K * -1021876967;
                           var31.o = var20.H * 1525453135;
                           var31.m = (var20.K - var20.H + 1) * 942867733;
                           var31.q = var18 * 771469949;
                           var31.r = var20.J / 3 * -745727859;
                           var31.e.I(var27.G);
                           var31.f.C(var27.H);
                           var31.l.I(var27.K);
                           var31.U.C(var27.E);
                           var31.C(-1712018251);
                        } else {
                           var27.method1507(0);
                        }
                        break;
                     case 3:
                     case 5:
                     default:
                        if (this.H.dI) {
                           var27.method1510();
                        } else {
                           var27.method1507(0);
                        }
                        break;
                     case 6:
                        var27.method1514(!YH.C(var29, -869988177));
                        break;
                     case 7:
                        var27.P.Z(this.H.M.I[12], this.H.M.I[13], this.H.M.I[14]);
                        var27.V.J();
                        var27.F = this.H.J();
                        var27.method1503(0);
                     }

                     var18 += var20.J;
                  }
               }
            }
         }

         if (this.k != null) {
            this.H.method5383(0, this.method5404);
            this.H.method5383(1, this.d);
            this.H.method5455(this.method5455);
            YF var28 = this.H.Q;
            var28.J();
            var28.I[13] = -1.0F;
            var27.method1506(var28);
            this.k.I(var27, var1, var2, var3, var4, var5);
         }
      }

   }

   public void method6348(int var1, int var2, int var3, boolean[][] var4, boolean var5, int var6) {
      if (this.putShort != null) {
         int var7 = var3 + var3 + 1;
         var7 *= var7;
         if (method545.length < var7) {
            method545 = new int[var7];
         }

         int var8 = var1 - var3;
         int var9 = var8;
         if (var8 < 0) {
            var8 = 0;
         }

         int var10 = var2 - var3;
         int var11 = var10;
         if (var10 < 0) {
            var10 = 0;
         }

         int var12 = var1 + var3;
         if (var12 > this.Z * -506105871 - 1) {
            var12 = this.Z * -506105871 - 1;
         }

         int var13 = var2 + var3;
         if (var13 > this.I * -1148794921 - 1) {
            var13 = this.I * -1148794921 - 1;
         }

         method1503 = 0;

         for(int var14 = var8; var14 <= var12; ++var14) {
            boolean[] var15 = var4[var14 - var9];

            for(int var16 = var10; var16 <= var13; ++var16) {
               if (var15[var16 - var11]) {
                  method545[method1503++] = var16 * this.Z * -506105871 + var14;
               }
            }
         }

         ByteBuffer var24 = this.H.F;
         var24.clear();

         int var25;
         for(var25 = 0; var25 < this.putShort.length; ++var25) {
            OE var26 = (OE)this.putShort[var25];
            var26.I(method545, method1503);
         }

         var25 = var24.position();
         FZ var27 = this.H.YI;
         if (var25 != 0) {
            PAI var17 = this.H.Z(var25 / 2);
            var17.method63(0, var25, this.H.J);
            this.H.T();
            this.H.method5383(0, this.method5404);
            this.H.method5384(var17);
            var27.method1506(YF.Z);
            if (this.H.N > 0) {
               var27.K.I(0.0F, 0.0F, 1.0F, -this.H.EI);
               var27.E.Z((float)(this.H.aI >> 16 & 255) / 255.0F, (float)(this.H.aI >> 8 & 255) / 255.0F, (float)(this.H.aI >> 0 & 255) / 255.0F);
               this.H.Q.I(this.H.K);
               this.H.Q.D();
               var27.K.I(this.H.Q);
               var27.K.I(1.0F / (this.H.kI - this.H.EI));
            } else {
               var27.K.I(0.0F, 0.0F, 0.0F, 0.0F);
               var27.E.Z(0.0F, 0.0F, 0.0F);
            }

            int var18;
            int var19;
            OE var20;
            WCI var22;
            if ((this.x & 55) == 0) {
               var18 = 0;

               for(var19 = 0; var19 < this.putShort.length; ++var19) {
                  var20 = (OE)this.putShort[var19];
                  if (var20.J != 0) {
                     if (this.H.dI) {
                        this.H.method5058(0, var20.A);
                        var27.G.I(0.0F, 1.0F, 0.0F, (float)this.H.fI + (float)(var20.A.C * -1475891183) / 255.0F * (float)(var20.A.I * 1996750669));
                        var27.G.I(1.0F / (float)(var20.A.I * 1996750669));
                        var27.H.Z((float)(var20.A.Z * -1212608691 >> 16 & 255) / 255.0F, (float)(var20.A.Z * -1212608691 >> 8 & 255) / 255.0F, (float)(var20.A.Z * -1212608691 >> 0 & 255) / 255.0F);
                     } else {
                        var27.G.I(0.0F, 0.0F, 0.0F, 0.0F);
                        var27.H.Z(0.0F, 0.0F, 0.0F);
                     }

                     boolean var30 = false;
                     if (var20.S != -1) {
                        var27.D = this.H.uI.I(var20.S);
                        var22 = this.H.LZ.method174(var20.S, 593985487);
                        var30 = !YH.C(var22.J, -1511846848);
                     } else {
                        var27.D = this.H.VI;
                     }

                     this.H.method5383(1, var20.E);
                     this.H.method5455(this.method5455);
                     var27.J.I(1.0F / var20.L, 1.0F / var20.L, 1.0F, 1.0F);
                     var27.R = var20.H;
                     var27.T = var20.K - var20.H + 1;
                     var27.U = var18;
                     var27.Z = var20.J / 3;
                     var27.method1514(var30);
                     var18 += var20.J;
                  }
               }
            } else {
               var27.M.Z(this.H.BI[0], this.H.BI[1], this.H.BI[2]);
               var27.N.Z(this.H.IZ * this.H.yI, this.H.IZ * this.H.JI, this.H.IZ * this.H.SI);
               var27.O.Z(-this.H.GI * this.H.yI, -this.H.GI * this.H.JI, -this.H.GI * this.H.SI);
               var27.C.Z(this.H.AI * this.H.yI, this.H.AI * this.H.JI, this.H.AI * this.H.SI);
               var18 = 0;

               for(var19 = 0; var19 < this.putShort.length; ++var19) {
                  var20 = (OE)this.putShort[var19];
                  if (var20.J > 0) {
                     if (this.H.dI) {
                        this.H.method5058(0, var20.A);
                        float var21 = 0.15F;
                        var27.G.I(0.0F, 1.0F / ((float)(var20.A.I * 1996750669) * var21), 0.0F, 256.0F / ((float)(var20.A.I * 1996750669) * var21));
                        var27.H.Z((float)(var20.A.Z * -1212608691 >> 16 & 255) / 255.0F, (float)(var20.A.Z * -1212608691 >> 8 & 255) / 255.0F, (float)(var20.A.Z * -1212608691 >> 0 & 255) / 255.0F);
                     } else {
                        var27.G.I(0.0F, 0.0F, 0.0F, 0.0F);
                        var27.H.Z(0.0F, 0.0F, 0.0F);
                     }

                     byte var29 = 11;
                     if (var20.S != -1) {
                        var22 = this.H.LZ.method174(var20.S, 1262090784);
                        var29 = var22.J;
                        var27.D = this.H.uI.I(var20.S);
                        var27.I(var22);
                     } else {
                        var27.D = this.H.VI;
                     }

                     this.H.method5383(1, var20.E);
                     this.H.method5455(this.method5455);
                     var27.J.I(1.0F / var20.L, 1.0F / var20.L, 1.0F, 1.0F);
                     var27.R = var20.H;
                     var27.T = var20.K - var20.H + 1;
                     var27.U = var18;
                     var27.Z = var20.J / 3;
                     switch(var29) {
                     case 1:
                        var27.P.Z(this.H.M.I[12], this.H.M.I[13], this.H.M.I[14]);
                        var27.method1508(0);
                        break;
                     case 2:
                     case 4:
                     case 8:
                     case 9:
                        if (!this.H.B && (this.x & 8) != 0) {
                           PC var31 = this.H.cI;
                           var31.V.I(this.H.z);
                           var31.X.I(1.0F / (var20.L * (float)(var20.A.B * -28774789)), 1.0F / (var20.L * (float)(var20.A.B * -28774789)), 1.0F, 1.0F);
                           var31.i.Z(this.H.M.I[12], this.H.M.I[13], this.H.M.I[14]);
                           WCI var23 = this.H.LZ.method174(var20.S, 1144477529);
                           var31.z = var23.K * -1021876967;
                           var31.o = var20.H * 1525453135;
                           var31.m = (var20.K - var20.H + 1) * 942867733;
                           var31.q = var18 * 771469949;
                           var31.r = var20.J / 3 * -745727859;
                           var31.e.I(var27.G);
                           var31.f.C(var27.H);
                           var31.l.I(var27.K);
                           var31.U.C(var27.E);
                           var31.C(961682393);
                        } else {
                           var27.method1507(0);
                        }
                        break;
                     case 3:
                     case 5:
                     default:
                        if (this.H.dI) {
                           var27.method1510();
                        } else {
                           var27.method1507(0);
                        }
                        break;
                     case 6:
                        var27.method1514(!YH.C(var29, -1822142623));
                        break;
                     case 7:
                        var27.P.Z(this.H.M.I[12], this.H.M.I[13], this.H.M.I[14]);
                        var27.V.J();
                        var27.F = this.H.J();
                        var27.method1503(0);
                     }

                     var18 += var20.J;
                  }
               }
            }
         }

         if (this.k != null) {
            this.H.method5383(0, this.method5404);
            this.H.method5383(1, this.d);
            this.H.method5455(this.method5455);
            YF var28 = this.H.Q;
            var28.J();
            var28.I[13] = -1.0F;
            var27.method1506(var28);
            this.k.I(var27, var1, var2, var3, var4, var5);
         }
      }

   }

   public void method6347(int var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean[][] var8) {
      if (this.method552 > 0) {
         PAI var9 = this.H.Z(this.method1507);
         int var10 = 0;
         int var11 = 32767;
         int var12 = -32768;
         ByteBuffer var13 = this.H.F;
         var13.clear();

         for(int var14 = var5; var14 < var7; ++var14) {
            int var15 = var14 * this.Z * -506105871 + var4;

            for(int var16 = var4; var16 < var6; ++var16) {
               if (var8[var16 - var4][var14 - var5]) {
                  short[] var17 = this.A[var15];
                  if (var17 != null) {
                     for(int var18 = 0; var18 < var17.length; ++var18) {
                        int var19 = var17[var18] & '\uffff';
                        if (var19 > var12) {
                           var12 = var19;
                        }

                        if (var19 < var11) {
                           var11 = var19;
                        }

                        var13.putShort((short)var19);
                        ++var10;
                     }
                  }
               }

               ++var15;
            }
         }

         var9.method63(0, var13.position(), this.H.J);
         if (var10 > 0) {
            this.H.T();
            FZ var20 = this.H.YI;
            this.H.method5383(0, this.method5404);
            this.H.method5383(1, this.d);
            this.H.method5455(this.method5455);
            this.H.method5384(var9);
            this.H.method5043(LF.K);
            float var21 = (float)this.H.I((short)2365).method545();
            float var22 = (float)this.H.I((short)-15012).method552();
            LF var23 = new LF();
            LF var24 = new LF();
            var23.I(1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 1.0F, 0.0F);
            var24.B((float)var3 / (256.0F * (float)(this.C * -1212653763)), (float)(-var3) / (256.0F * (float)(this.C * -1212653763)), 1.0F / (this.S - this.method1508));
            var24.C((float)var1 - (float)(var4 * var3) / 256.0F, (float)var2 + (float)(var7 * var3) / 256.0F, -this.method1508 / (this.S - this.method1508));
            var24.I(2.0F / var21, 2.0F / var22, 1.0F);
            var24.C(-1.0F, -1.0F, 0.0F);
            this.H.P.I(var23, var24);
            this.H.Q.I(this.H.P);
            this.H.method5182(this.H.Q);
            var20.method1506(YF.Z);
            var20.K.I(0.0F, 0.0F, 0.0F, 0.0F);
            var20.E.Z(0.0F, 0.0F, 0.0F);
            var20.G.I(0.0F, 0.0F, 0.0F, 0.0F);
            var20.H.Z(0.0F, 0.0F, 0.0F);
            var20.D = this.H.VI;
            var20.J.J();
            var20.R = var11;
            var20.T = var12 - var11 + 1;
            var20.U = 0;
            var20.Z = var10 / 3;
            var20.method1514(false);
         }
      }

   }

   public void method6351(int var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean[][] var8) {
      if (this.method552 > 0) {
         PAI var9 = this.H.Z(this.method1507);
         int var10 = 0;
         int var11 = 32767;
         int var12 = -32768;
         ByteBuffer var13 = this.H.F;
         var13.clear();

         for(int var14 = var5; var14 < var7; ++var14) {
            int var15 = var14 * this.Z * -506105871 + var4;

            for(int var16 = var4; var16 < var6; ++var16) {
               if (var8[var16 - var4][var14 - var5]) {
                  short[] var17 = this.A[var15];
                  if (var17 != null) {
                     for(int var18 = 0; var18 < var17.length; ++var18) {
                        int var19 = var17[var18] & '\uffff';
                        if (var19 > var12) {
                           var12 = var19;
                        }

                        if (var19 < var11) {
                           var11 = var19;
                        }

                        var13.putShort((short)var19);
                        ++var10;
                     }
                  }
               }

               ++var15;
            }
         }

         var9.method63(0, var13.position(), this.H.J);
         if (var10 > 0) {
            this.H.T();
            FZ var20 = this.H.YI;
            this.H.method5383(0, this.method5404);
            this.H.method5383(1, this.d);
            this.H.method5455(this.method5455);
            this.H.method5384(var9);
            this.H.method5043(LF.K);
            float var21 = (float)this.H.I((short)-18098).method545();
            float var22 = (float)this.H.I((short)2214).method552();
            LF var23 = new LF();
            LF var24 = new LF();
            var23.I(1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 1.0F, 0.0F);
            var24.B((float)var3 / (256.0F * (float)(this.C * -1212653763)), (float)(-var3) / (256.0F * (float)(this.C * -1212653763)), 1.0F / (this.S - this.method1508));
            var24.C((float)var1 - (float)(var4 * var3) / 256.0F, (float)var2 + (float)(var7 * var3) / 256.0F, -this.method1508 / (this.S - this.method1508));
            var24.I(2.0F / var21, 2.0F / var22, 1.0F);
            var24.C(-1.0F, -1.0F, 0.0F);
            this.H.P.I(var23, var24);
            this.H.Q.I(this.H.P);
            this.H.method5182(this.H.Q);
            var20.method1506(YF.Z);
            var20.K.I(0.0F, 0.0F, 0.0F, 0.0F);
            var20.E.Z(0.0F, 0.0F, 0.0F);
            var20.G.I(0.0F, 0.0F, 0.0F, 0.0F);
            var20.H.Z(0.0F, 0.0F, 0.0F);
            var20.D = this.H.VI;
            var20.J.J();
            var20.R = var11;
            var20.T = var12 - var11 + 1;
            var20.U = 0;
            var20.Z = var10 / 3;
            var20.method1514(false);
         }
      }

   }

   public void method6350(int var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean[][] var8) {
      if (this.method552 > 0) {
         PAI var9 = this.H.Z(this.method1507);
         int var10 = 0;
         int var11 = 32767;
         int var12 = -32768;
         ByteBuffer var13 = this.H.F;
         var13.clear();

         for(int var14 = var5; var14 < var7; ++var14) {
            int var15 = var14 * this.Z * -506105871 + var4;

            for(int var16 = var4; var16 < var6; ++var16) {
               if (var8[var16 - var4][var14 - var5]) {
                  short[] var17 = this.A[var15];
                  if (var17 != null) {
                     for(int var18 = 0; var18 < var17.length; ++var18) {
                        int var19 = var17[var18] & '\uffff';
                        if (var19 > var12) {
                           var12 = var19;
                        }

                        if (var19 < var11) {
                           var11 = var19;
                        }

                        var13.putShort((short)var19);
                        ++var10;
                     }
                  }
               }

               ++var15;
            }
         }

         var9.method63(0, var13.position(), this.H.J);
         if (var10 > 0) {
            this.H.T();
            FZ var20 = this.H.YI;
            this.H.method5383(0, this.method5404);
            this.H.method5383(1, this.d);
            this.H.method5455(this.method5455);
            this.H.method5384(var9);
            this.H.method5043(LF.K);
            float var21 = (float)this.H.I((short)-10639).method545();
            float var22 = (float)this.H.I((short)-13227).method552();
            LF var23 = new LF();
            LF var24 = new LF();
            var23.I(1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 1.0F, 0.0F);
            var24.B((float)var3 / (256.0F * (float)(this.C * -1212653763)), (float)(-var3) / (256.0F * (float)(this.C * -1212653763)), 1.0F / (this.S - this.method1508));
            var24.C((float)var1 - (float)(var4 * var3) / 256.0F, (float)var2 + (float)(var7 * var3) / 256.0F, -this.method1508 / (this.S - this.method1508));
            var24.I(2.0F / var21, 2.0F / var22, 1.0F);
            var24.C(-1.0F, -1.0F, 0.0F);
            this.H.P.I(var23, var24);
            this.H.Q.I(this.H.P);
            this.H.method5182(this.H.Q);
            var20.method1506(YF.Z);
            var20.K.I(0.0F, 0.0F, 0.0F, 0.0F);
            var20.E.Z(0.0F, 0.0F, 0.0F);
            var20.G.I(0.0F, 0.0F, 0.0F, 0.0F);
            var20.H.Z(0.0F, 0.0F, 0.0F);
            var20.D = this.H.VI;
            var20.J.J();
            var20.R = var11;
            var20.T = var12 - var11 + 1;
            var20.U = 0;
            var20.Z = var10 / 3;
            var20.method1514(false);
         }
      }

   }

   public void method6357(int var1, int var2, int var3, boolean[][] var4, boolean var5, int var6) {
      if (this.putShort != null) {
         int var7 = var3 + var3 + 1;
         var7 *= var7;
         if (method545.length < var7) {
            method545 = new int[var7];
         }

         int var8 = var1 - var3;
         int var9 = var8;
         if (var8 < 0) {
            var8 = 0;
         }

         int var10 = var2 - var3;
         int var11 = var10;
         if (var10 < 0) {
            var10 = 0;
         }

         int var12 = var1 + var3;
         if (var12 > this.Z * -506105871 - 1) {
            var12 = this.Z * -506105871 - 1;
         }

         int var13 = var2 + var3;
         if (var13 > this.I * -1148794921 - 1) {
            var13 = this.I * -1148794921 - 1;
         }

         method1503 = 0;

         for(int var14 = var8; var14 <= var12; ++var14) {
            boolean[] var15 = var4[var14 - var9];

            for(int var16 = var10; var16 <= var13; ++var16) {
               if (var15[var16 - var11]) {
                  method545[method1503++] = var16 * this.Z * -506105871 + var14;
               }
            }
         }

         ByteBuffer var24 = this.H.F;
         var24.clear();

         int var25;
         for(var25 = 0; var25 < this.putShort.length; ++var25) {
            OE var26 = (OE)this.putShort[var25];
            var26.I(method545, method1503);
         }

         var25 = var24.position();
         FZ var27 = this.H.YI;
         if (var25 != 0) {
            PAI var17 = this.H.Z(var25 / 2);
            var17.method63(0, var25, this.H.J);
            this.H.T();
            this.H.method5383(0, this.method5404);
            this.H.method5384(var17);
            var27.method1506(YF.Z);
            if (this.H.N > 0) {
               var27.K.I(0.0F, 0.0F, 1.0F, -this.H.EI);
               var27.E.Z((float)(this.H.aI >> 16 & 255) / 255.0F, (float)(this.H.aI >> 8 & 255) / 255.0F, (float)(this.H.aI >> 0 & 255) / 255.0F);
               this.H.Q.I(this.H.K);
               this.H.Q.D();
               var27.K.I(this.H.Q);
               var27.K.I(1.0F / (this.H.kI - this.H.EI));
            } else {
               var27.K.I(0.0F, 0.0F, 0.0F, 0.0F);
               var27.E.Z(0.0F, 0.0F, 0.0F);
            }

            int var18;
            int var19;
            OE var20;
            WCI var22;
            if ((this.x & 55) == 0) {
               var18 = 0;

               for(var19 = 0; var19 < this.putShort.length; ++var19) {
                  var20 = (OE)this.putShort[var19];
                  if (var20.J != 0) {
                     if (this.H.dI) {
                        this.H.method5058(0, var20.A);
                        var27.G.I(0.0F, 1.0F, 0.0F, (float)this.H.fI + (float)(var20.A.C * -1475891183) / 255.0F * (float)(var20.A.I * 1996750669));
                        var27.G.I(1.0F / (float)(var20.A.I * 1996750669));
                        var27.H.Z((float)(var20.A.Z * -1212608691 >> 16 & 255) / 255.0F, (float)(var20.A.Z * -1212608691 >> 8 & 255) / 255.0F, (float)(var20.A.Z * -1212608691 >> 0 & 255) / 255.0F);
                     } else {
                        var27.G.I(0.0F, 0.0F, 0.0F, 0.0F);
                        var27.H.Z(0.0F, 0.0F, 0.0F);
                     }

                     boolean var30 = false;
                     if (var20.S != -1) {
                        var27.D = this.H.uI.I(var20.S);
                        var22 = this.H.LZ.method174(var20.S, 444879772);
                        var30 = !YH.C(var22.J, -1276184366);
                     } else {
                        var27.D = this.H.VI;
                     }

                     this.H.method5383(1, var20.E);
                     this.H.method5455(this.method5455);
                     var27.J.I(1.0F / var20.L, 1.0F / var20.L, 1.0F, 1.0F);
                     var27.R = var20.H;
                     var27.T = var20.K - var20.H + 1;
                     var27.U = var18;
                     var27.Z = var20.J / 3;
                     var27.method1514(var30);
                     var18 += var20.J;
                  }
               }
            } else {
               var27.M.Z(this.H.BI[0], this.H.BI[1], this.H.BI[2]);
               var27.N.Z(this.H.IZ * this.H.yI, this.H.IZ * this.H.JI, this.H.IZ * this.H.SI);
               var27.O.Z(-this.H.GI * this.H.yI, -this.H.GI * this.H.JI, -this.H.GI * this.H.SI);
               var27.C.Z(this.H.AI * this.H.yI, this.H.AI * this.H.JI, this.H.AI * this.H.SI);
               var18 = 0;

               for(var19 = 0; var19 < this.putShort.length; ++var19) {
                  var20 = (OE)this.putShort[var19];
                  if (var20.J > 0) {
                     if (this.H.dI) {
                        this.H.method5058(0, var20.A);
                        float var21 = 0.15F;
                        var27.G.I(0.0F, 1.0F / ((float)(var20.A.I * 1996750669) * var21), 0.0F, 256.0F / ((float)(var20.A.I * 1996750669) * var21));
                        var27.H.Z((float)(var20.A.Z * -1212608691 >> 16 & 255) / 255.0F, (float)(var20.A.Z * -1212608691 >> 8 & 255) / 255.0F, (float)(var20.A.Z * -1212608691 >> 0 & 255) / 255.0F);
                     } else {
                        var27.G.I(0.0F, 0.0F, 0.0F, 0.0F);
                        var27.H.Z(0.0F, 0.0F, 0.0F);
                     }

                     byte var29 = 11;
                     if (var20.S != -1) {
                        var22 = this.H.LZ.method174(var20.S, 2135192368);
                        var29 = var22.J;
                        var27.D = this.H.uI.I(var20.S);
                        var27.I(var22);
                     } else {
                        var27.D = this.H.VI;
                     }

                     this.H.method5383(1, var20.E);
                     this.H.method5455(this.method5455);
                     var27.J.I(1.0F / var20.L, 1.0F / var20.L, 1.0F, 1.0F);
                     var27.R = var20.H;
                     var27.T = var20.K - var20.H + 1;
                     var27.U = var18;
                     var27.Z = var20.J / 3;
                     switch(var29) {
                     case 1:
                        var27.P.Z(this.H.M.I[12], this.H.M.I[13], this.H.M.I[14]);
                        var27.method1508(0);
                        break;
                     case 2:
                     case 4:
                     case 8:
                     case 9:
                        if (!this.H.B && (this.x & 8) != 0) {
                           PC var31 = this.H.cI;
                           var31.V.I(this.H.z);
                           var31.X.I(1.0F / (var20.L * (float)(var20.A.B * -28774789)), 1.0F / (var20.L * (float)(var20.A.B * -28774789)), 1.0F, 1.0F);
                           var31.i.Z(this.H.M.I[12], this.H.M.I[13], this.H.M.I[14]);
                           WCI var23 = this.H.LZ.method174(var20.S, 1719353613);
                           var31.z = var23.K * -1021876967;
                           var31.o = var20.H * 1525453135;
                           var31.m = (var20.K - var20.H + 1) * 942867733;
                           var31.q = var18 * 771469949;
                           var31.r = var20.J / 3 * -745727859;
                           var31.e.I(var27.G);
                           var31.f.C(var27.H);
                           var31.l.I(var27.K);
                           var31.U.C(var27.E);
                           var31.C(1844797050);
                        } else {
                           var27.method1507(0);
                        }
                        break;
                     case 3:
                     case 5:
                     default:
                        if (this.H.dI) {
                           var27.method1510();
                        } else {
                           var27.method1507(0);
                        }
                        break;
                     case 6:
                        var27.method1514(!YH.C(var29, -642644362));
                        break;
                     case 7:
                        var27.P.Z(this.H.M.I[12], this.H.M.I[13], this.H.M.I[14]);
                        var27.V.J();
                        var27.F = this.H.J();
                        var27.method1503(0);
                     }

                     var18 += var20.J;
                  }
               }
            }
         }

         if (this.k != null) {
            this.H.method5383(0, this.method5404);
            this.H.method5383(1, this.d);
            this.H.method5455(this.method5455);
            YF var28 = this.H.Q;
            var28.J();
            var28.I[13] = -1.0F;
            var27.method1506(var28);
            this.k.I(var27, var1, var2, var3, var4, var5);
         }
      }

   }

   public void method6352(int var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean[][] var8) {
      if (this.method552 > 0) {
         PAI var9 = this.H.Z(this.method1507);
         int var10 = 0;
         int var11 = 32767;
         int var12 = -32768;
         ByteBuffer var13 = this.H.F;
         var13.clear();

         for(int var14 = var5; var14 < var7; ++var14) {
            int var15 = var14 * this.Z * -506105871 + var4;

            for(int var16 = var4; var16 < var6; ++var16) {
               if (var8[var16 - var4][var14 - var5]) {
                  short[] var17 = this.A[var15];
                  if (var17 != null) {
                     for(int var18 = 0; var18 < var17.length; ++var18) {
                        int var19 = var17[var18] & '\uffff';
                        if (var19 > var12) {
                           var12 = var19;
                        }

                        if (var19 < var11) {
                           var11 = var19;
                        }

                        var13.putShort((short)var19);
                        ++var10;
                     }
                  }
               }

               ++var15;
            }
         }

         var9.method63(0, var13.position(), this.H.J);
         if (var10 > 0) {
            this.H.T();
            FZ var20 = this.H.YI;
            this.H.method5383(0, this.method5404);
            this.H.method5383(1, this.d);
            this.H.method5455(this.method5455);
            this.H.method5384(var9);
            this.H.method5043(LF.K);
            float var21 = (float)this.H.I((short)12709).method545();
            float var22 = (float)this.H.I((short)-19432).method552();
            LF var23 = new LF();
            LF var24 = new LF();
            var23.I(1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 1.0F, 0.0F);
            var24.B((float)var3 / (256.0F * (float)(this.C * -1212653763)), (float)(-var3) / (256.0F * (float)(this.C * -1212653763)), 1.0F / (this.S - this.method1508));
            var24.C((float)var1 - (float)(var4 * var3) / 256.0F, (float)var2 + (float)(var7 * var3) / 256.0F, -this.method1508 / (this.S - this.method1508));
            var24.I(2.0F / var21, 2.0F / var22, 1.0F);
            var24.C(-1.0F, -1.0F, 0.0F);
            this.H.P.I(var23, var24);
            this.H.Q.I(this.H.P);
            this.H.method5182(this.H.Q);
            var20.method1506(YF.Z);
            var20.K.I(0.0F, 0.0F, 0.0F, 0.0F);
            var20.E.Z(0.0F, 0.0F, 0.0F);
            var20.G.I(0.0F, 0.0F, 0.0F, 0.0F);
            var20.H.Z(0.0F, 0.0F, 0.0F);
            var20.D = this.H.VI;
            var20.J.J();
            var20.R = var11;
            var20.T = var12 - var11 + 1;
            var20.U = 0;
            var20.Z = var10 / 3;
            var20.method1514(false);
         }
      }

   }

   public void method6349(int var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean[][] var8) {
      if (this.method552 > 0) {
         PAI var9 = this.H.Z(this.method1507);
         int var10 = 0;
         int var11 = 32767;
         int var12 = -32768;
         ByteBuffer var13 = this.H.F;
         var13.clear();

         for(int var14 = var5; var14 < var7; ++var14) {
            int var15 = var14 * this.Z * -506105871 + var4;

            for(int var16 = var4; var16 < var6; ++var16) {
               if (var8[var16 - var4][var14 - var5]) {
                  short[] var17 = this.A[var15];
                  if (var17 != null) {
                     for(int var18 = 0; var18 < var17.length; ++var18) {
                        int var19 = var17[var18] & '\uffff';
                        if (var19 > var12) {
                           var12 = var19;
                        }

                        if (var19 < var11) {
                           var11 = var19;
                        }

                        var13.putShort((short)var19);
                        ++var10;
                     }
                  }
               }

               ++var15;
            }
         }

         var9.method63(0, var13.position(), this.H.J);
         if (var10 > 0) {
            this.H.T();
            FZ var20 = this.H.YI;
            this.H.method5383(0, this.method5404);
            this.H.method5383(1, this.d);
            this.H.method5455(this.method5455);
            this.H.method5384(var9);
            this.H.method5043(LF.K);
            float var21 = (float)this.H.I((short)-2056).method545();
            float var22 = (float)this.H.I((short)898).method552();
            LF var23 = new LF();
            LF var24 = new LF();
            var23.I(1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 1.0F, 0.0F);
            var24.B((float)var3 / (256.0F * (float)(this.C * -1212653763)), (float)(-var3) / (256.0F * (float)(this.C * -1212653763)), 1.0F / (this.S - this.method1508));
            var24.C((float)var1 - (float)(var4 * var3) / 256.0F, (float)var2 + (float)(var7 * var3) / 256.0F, -this.method1508 / (this.S - this.method1508));
            var24.I(2.0F / var21, 2.0F / var22, 1.0F);
            var24.C(-1.0F, -1.0F, 0.0F);
            this.H.P.I(var23, var24);
            this.H.Q.I(this.H.P);
            this.H.method5182(this.H.Q);
            var20.method1506(YF.Z);
            var20.K.I(0.0F, 0.0F, 0.0F, 0.0F);
            var20.E.Z(0.0F, 0.0F, 0.0F);
            var20.G.I(0.0F, 0.0F, 0.0F, 0.0F);
            var20.H.Z(0.0F, 0.0F, 0.0F);
            var20.D = this.H.VI;
            var20.J.J();
            var20.R = var11;
            var20.T = var12 - var11 + 1;
            var20.U = 0;
            var20.Z = var10 / 3;
            var20.method1514(false);
         }
      }

   }

   public void method6342(GE var1, int[] var2) {
      this.method5383.Z((AE)(new VE(this.H, this, var1, var2)), (int)847764960);
   }

   public void method6359(int var1, int var2, int[] var3, int[] var4, int[] var5, int[] var6, int[] var7, int[] var8, int[] var9, int[] var10, ADI var11, boolean var12) {
      FEI var13 = this.H.LZ;
      if (var6 != null && this.method5182 == null) {
         this.method5182 = new int[this.Z * -506105871][this.I * -1148794921][];
      }

      if (var4 != null && this.method1514 == null) {
         this.method1514 = new int[this.Z * -506105871][this.I * -1148794921][];
      }

      this.G[var1][var2] = var3;
      this.E[var1][var2] = var5;
      this.K[var1][var2] = var7;
      this.method174[var1][var2] = var8;
      if (this.method5182 != null) {
         this.method5182[var1][var2] = var6;
      }

      if (this.method1514 != null) {
         this.method1514[var1][var2] = var4;
      }

      OE[] var14 = this.method1510[var1][var2] = new OE[var7.length];

      for(int var15 = 0; var15 < var7.length; ++var15) {
         int var16 = var9[var15];
         int var17 = var10[var15];
         if ((this.x & 32) != 0 && var16 != -1 && var13.method174(var16, 831412301).B) {
            var17 = 128;
            var16 = -1;
         }

         long var18 = (long)(var11.C * -1475891183) << 48 | (long)(var11.I * 1996750669) << 42 | (long)(var11.Z * -1212608691) << 28 | (long)(var17 << 14) | (long)var16;

         AE var20;
         for(var20 = this.r.I(var18); var20 != null; var20 = this.r.I(-1980491334)) {
            OE var21 = (OE)var20;
            if (var21.S == var16 && var21.L == (float)var17 && var21.A.I(var11, (byte)-64)) {
               break;
            }
         }

         if (var20 == null) {
            var14[var15] = new OE(this, var16, var17, var11);
            this.r.I(var14[var15], var18);
         } else {
            var14[var15] = (OE)var20;
         }
      }

      if (var12) {
         this.method5384[var1][var2] = (byte)(this.method5384[var1][var2] | 1);
      }

      if (var7.length > this.method63) {
         this.method63 = var7.length;
      }

      this.method552 += var7.length;
   }

   public void ak(GJI var1, int var2, int var3, int var4, int var5, boolean var6) {
      if (this.k != null && var1 != null) {
         int var7 = var2 - (var3 * this.H.NI >> 8) >> this.H.XI;
         int var8 = var4 - (var3 * this.H.iI >> 8) >> this.H.XI;
         this.k.Z(var1, var7, var8);
      }

   }

   public boolean method6354(GJI var1, int var2, int var3, int var4, int var5, boolean var6) {
      if (this.k != null && var1 != null) {
         int var7 = var2 - (var3 * this.H.NI >> 8) >> this.H.XI;
         int var8 = var4 - (var3 * this.H.iI >> 8) >> this.H.XI;
         return this.k.C(var1, var7, var8);
      } else {
         return false;
      }
   }

   public void LA(int var1, int var2, int var3) {
      if ((this.method6335[var1][var2] & 255) < var3) {
         this.method6335[var1][var2] = (byte)var3;
      }

   }

   public void ad(GJI var1, int var2, int var3, int var4, int var5, boolean var6) {
      if (this.k != null && var1 != null) {
         int var7 = var2 - (var3 * this.H.NI >> 8) >> this.H.XI;
         int var8 = var4 - (var3 * this.H.iI >> 8) >> this.H.XI;
         this.k.I(var1, var7, var8);
      }

   }

   public void av(GJI var1, int var2, int var3, int var4, int var5, boolean var6) {
      if (this.k != null && var1 != null) {
         int var7 = var2 - (var3 * this.H.NI >> 8) >> this.H.XI;
         int var8 = var4 - (var3 * this.H.iI >> 8) >> this.H.XI;
         this.k.I(var1, var7, var8);
      }

   }

   public void at(int var1, int var2, int var3) {
      if ((this.method6335[var1][var2] & 255) < var3) {
         this.method6335[var1][var2] = (byte)var3;
      }

   }

   public void method6344(GE var1, int[] var2) {
      this.method5383.Z((AE)(new VE(this.H, this, var1, var2)), (int)1474142040);
   }

   public void method6358(GE var1, int[] var2) {
      this.method5383.Z((AE)(new VE(this.H, this, var1, var2)), (int)2119427070);
   }
}
