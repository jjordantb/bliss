public class EA {
   int B;
   int F;
   UT ah;
   AA append;
   static int arraycopy = 512;
   VO ba;
   int hashCode;
   int m;
   int method170;
   int method171;
   AA[] method172;
   IBI method174;
   int method242;
   int method4739;
   AA[] method4742;
   boolean method4996 = true;
   static FEI I;
   int method5037;
   int method5043;
   byte[] method5044;
   boolean method5045;
   EA method5182;
   int toString;
   int Z;
   int C = -697848799;
   static int D;
   public static KJ J;

   public void I(int var1, int var2, int var3) {
      try {
         boolean var10000 = this.method5045;
         this.toString = -1739514523 * (var1 * (var2 - -1519560585 * this.method170) / 255 + -1519560585 * this.method170);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "lm.b(" + ')');
      }
   }

   public void I(EA var1, int var2) {
      try {
         if (this.method5045) {
            this.method170 = 967778107 * this.toString;
         } else if (var1 != null && var1.method5045) {
            this.method170 = -910867015 - 967778107 * var1.toString;
         } else {
            this.method170 = 0;
         }

         this.method5045 = true;
         this.method5182 = var1;
         this.toString = 0;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "lm.p(" + ')');
      }
   }

   public void I(byte var1) {
      try {
         this.method5045 = false;
         this.method5182 = null;
         this.toString = 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "lm.i(" + ')');
      }
   }

   public boolean Z(byte var1) {
      try {
         return this.method5045;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "lm.k(" + ')');
      }
   }

   public EA I(int var1) {
      try {
         return this.method5182;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "lm.d(" + ')');
      }
   }

   public boolean I(GSI var1, int var2, int var3, int var4) {
      try {
         if (-51566561 * this.C != var2) {
            this.C = 697848799 * var2;
            int var5 = KW.C(var2, 1272872211);
            if (var5 > 512) {
               var5 = 512;
            }

            if (var5 <= 0) {
               var5 = 1;
            }

            if (var5 != this.m * -1994130525) {
               this.m = var5 * 285085707;
               this.method174 = null;
            }

            if (this.method172 != null) {
               this.hashCode = 0;
               int[] var6 = new int[this.method172.length];

               for(int var7 = 0; var7 < this.method172.length; ++var7) {
                  AA var8 = this.method172[var7];
                  if (var8.I(this.method5043 * 1173193129, 796478559 * this.method171, -226559159 * this.Z, this.C * -51566561)) {
                     var6[this.hashCode * 1858024591] = var8.I;
                     this.method4742[(this.hashCode += 400255599) * 1858024591 - 1] = var8;
                  }
               }

               EV.I(var6, this.method4742, 0, 1858024591 * this.hashCode - 1, -641027314);
            }

            this.method4996 = true;
         }

         boolean var11 = false;
         if (this.method4996) {
            this.method4996 = false;

            for(int var10 = this.hashCode * 1858024591 - 1; var10 >= 0; --var10) {
               boolean var12 = this.method4742[var10].I(var1, this.append);
               this.method4996 |= !var12;
               var11 |= var12;
            }
         }

         if (var3 != 0 && var1.method4996()) {
            if (this.ah == null && this.method5037 * -680590445 >= 0) {
               this.B(var1, -1803183146);
            }
         } else {
            this.ah = null;
         }

         if (this.method5182 != null && this.method5182 != this) {
            this.method5182.I((byte)-39);
            var11 |= this.method5182.I(var1, var2, var3, -136782694);
         }

         return var11;
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "lm.u(" + ')');
      }
   }

   void B(GSI var1, int var2) {
      try {
         try {
            boolean var3 = LY.S.I(-680590445 * this.method5037, 581664063);
            if (var3) {
               var1.m(16777215, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F);
               MBI var4 = MBI.I((KJ)LY.S, this.method5037 * -680590445, (int)0);
               this.ah = var1.method5037(var4, 1099776, 0, 255, 1);
               byte[] var5 = this.ah.ah();
               if (var5 == null) {
                  this.method5044 = null;
               } else {
                  this.method5044 = new byte[var5.length];
                  System.arraycopy(var5, 0, this.method5044, 0, var5.length);
               }
            }
         } catch (Exception var6) {
            ;
         }

      } catch (RuntimeException var7) {
         throw DQ.I(var7, "lm.x(" + ')');
      }
   }

   public void I(GSI var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, int var11) {
      try {
         this.I(var1, var2, var3, var4, var5, var6, var7, var8, 0, var10, true, false, (byte)-1);
      } catch (RuntimeException var13) {
         throw DQ.I(var13, "lm.r(" + ')');
      }
   }

   public void I(GSI var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, boolean var11, boolean var12, byte var13) {
      try {
         int var14 = 0;
         if (this.method5045) {
            var14 = this.toString * 1447218285;
         }

         if (this.method5182 != null) {
            EA var15 = this;
            EA var16 = this.method5182;
            if (this.hashCode() > var16.hashCode()) {
               var15 = this.method5182;
               var16 = this;
               var14 = 255 - var14;
            }

            var15.ah(var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var14, 2089062848);
            var16.ah(var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, false, var12, 255 - var14, 357729081);
         } else {
            this.ah(var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var14, 1191709910);
         }

      } catch (RuntimeException var17) {
         throw DQ.I(var17, "lm.q(" + ')');
      }
   }

   void F(GSI var1, int var2, int var3, int var4, int var5, int var6) {
      try {
         LF var7 = var1.method5044();
         LF var8 = new LF();
         var8.Z(0.0F, 0.0F, 0.0F);
         var8.Z(0.0F, -1.0F, 0.0F, HF.I(-var3 & 16383));
         var8.Z(-1.0F, 0.0F, 0.0F, HF.I(-var2 & 16383));
         var8.Z(0.0F, 0.0F, -1.0F, HF.I(-var4 & 16383));
         var1.method5043(var8);
         LF var9 = new LF();
         if (738421895 * this.method242 != var5) {
            this.ah.method4742((byte)var5, this.method5044);
            this.method242 = var5 * -299787977;
         }

         this.ah.method4739(var9, (KN)null, 0);
         var1.method5043(var7);
      } catch (RuntimeException var10) {
         throw DQ.I(var10, "lm.s(" + ')');
      }
   }

   void ah(GSI var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, boolean var11, boolean var12, int var13, int var14) {
      try {
         int var15 = 255 - var13;
         if (this.ah == null) {
            var1.ba(2, 0);
            var8 = var8 + var2 & 16383;
            if (this.F * 1461948177 != -1 && this.m * -1994130525 != 0) {
               WCI var16 = I.method174(this.F * 1461948177, 434799685);
               if (this.method174 == null && I.method170(this.F * 1461948177, (short)28045)) {
                  int[] var17 = 2 == -2138060883 * var16.F ? I.method172(this.F * 1461948177, 0.7F, -1994130525 * this.m, this.m * -1994130525, false, (byte)2) : I.method171(this.F * 1461948177, 0.7F, -1994130525 * this.m, -1994130525 * this.m, false, 833981844);
                  this.B = var17[0] * 1667694183;
                  this.method4739 = 918308719 * var17[var17.length - 1];
                  this.method174 = var1.I(var17, 0, this.m * -1994130525, this.m * -1994130525, this.m * -1994130525, 2072553439);
               }

               int var25 = var15 == 255 ? (var16.F * -2138060883 == 2 ? 1 : 0) : 1;
               if (1 == var25 && var11) {
                  var1.B(var3, var4, var5, var6, var10, 0);
               }

               if (this.method174 != null) {
                  int var18 = var7 * var6 / -4096;

                  int var19;
                  for(var19 = (var5 - var6) / 2 + var8 * var6 / 4096; var19 > var6; var19 -= var6) {
                     ;
                  }

                  while(var19 < 0) {
                     var19 += var6;
                  }

                  int var20;
                  if (this.ba != VO.I) {
                     while(var18 > var6) {
                        var18 -= var6;
                     }

                     while(var18 < 0) {
                        var18 += var6;
                     }

                     for(var20 = var19 - var6; var20 < var5; var20 += var6) {
                        for(int var21 = var18 - var6; var21 < var6; var21 += var6) {
                           this.method174.I(var3 + var20, var4 + var21, var6, var6, 0, var15 << 24 | 16777215, var25);
                        }
                     }
                  } else {
                     for(var20 = var19 - var6; var20 < var5; var20 += var6) {
                        this.method174.I(var3 + var20, var18 + var4, var6, var6, 0, var15 << 24 | 16777215, var25);
                     }

                     if ((150420823 * this.B & -16777216) != 0) {
                        var1.I(0, 0, var5, 1 + var4 + var18, 150420823 * this.B, (byte)7);
                     }

                     if ((this.method4739 * 1184429967 & -16777216) != 0) {
                        var1.I(0, var18 + var4 + var6, var5, var6 - (var6 + var18 + var4), this.method4739 * 1184429967, (byte)7);
                     }
                  }
               }
            } else {
               var1.B(var3, var4, var5, var6, var15 << 24 | var10, 1);
            }
         } else if (var12) {
            YF var23 = var1.method5045();
            YF var26 = var1.method5045();
            var23.I[2] = var23.I[3];
            var23.I[6] = var23.I[7];
            var23.I[10] = var23.I[11];
            var23.I[14] = var23.I[15];
            var1.method5182(var23);
            this.F(var1, var7, var8, var9, var13, -1456826082);
            var1.method5182(var26);
         } else {
            if (var11) {
               var1.ba(3, var10);
            }

            this.F(var1, var7, var8, var9, var13, -1935584987);
         }

         for(int var24 = this.hashCode * 1858024591 - 1; var24 >= 0; --var24) {
            this.method4742[var24].I(var1, var3, var4, var5, var6, var7, var8, 1173193129 * this.method5043, this.method171 * 796478559, this.Z * -226559159, var15);
         }

         var1.ba(2, 0);
      } catch (RuntimeException var22) {
         throw DQ.I(var22, "lm.n(" + ')');
      }
   }

   public EA(int var1, AA[] var2, int var3, int var4, int var5, int var6, VO var7, int var8) {
      this.method5043 = var4 * 91665049;
      this.method171 = var5 * -2049962081;
      this.Z = var6 * 2095769337;
      this.F = 318980593 * var1;
      this.method172 = var2;
      this.ba = var7;
      if (var2 != null) {
         this.method4742 = new AA[var2.length];
         this.append = var3 >= 0 ? var2[var3] : null;
      } else {
         this.method4742 = null;
         this.append = null;
      }

      this.method5037 = var8 * -2035969381;
   }

   static final void I(HSI var0, X var1, OU var2, int var3) {
      try {
         var0.UC = var2.H[(var2.J -= -391880689) * 681479919] * -216431639;
         VEI.I(var0, 2056943984);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "lm.dv(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         ESI.I(var3, var4, var0, 1469378212);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "lm.jw(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         SW.I(var3, var0, 1480483039);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "lm.qk(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = (int)XEI.qD >> 3;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "lm.agv(" + ')');
      }
   }

   public static void I(long[] var0, int[] var1, byte var2) {
      try {
         AZI.I(var0, var1, 0, var0.length - 1, -373410323);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "lm.k(" + ')');
      }
   }

   public static void I(LEI var0) {
      I(0, var0);
   }

   public static void I(int var0, LEI var1) {
      int var2 = QK.I(UA.F.YI[0], UA.F.v[0], UA.F.S(), var1, XEI.mI.A(UA.F.K), true, XEI.OZ, XEI.FZ);
      PK var3 = null;
      if (var0 == 0) {
         var3 = GB.I(MEI.dI, XEI.eI.Z, (byte)51);
      }

      if (var0 == 1) {
         var3 = GB.I(MEI.JI, XEI.eI.Z, (byte)28);
      }

      var3.J.F(5 + var2 * 2);
      XP var4 = XEI.mI.I(681479919);
      var3.J.W(var4.I * -1760580017);
      var3.J.J(IC.I(-545107710) ? 1 : 0, (byte)1);
      var3.J.W(var4.Z * 283514611);

      for(int var5 = var2 - 1; var5 >= 0; --var5) {
         var3.J.F(RA.C[var5]);
         var3.J.F(RA.I[var5]);
      }

      JN.E = false;
      if (var2 > 0) {
         JN.I = RA.I[var2 - 1] * -1835291189;
         JN.A = RA.C[var2 - 1] * -1129029761;
      }

      XEI.eI.I(var3, (byte)-115);
   }

   static PK Z(int var0, int var1, int var2) {
      try {
         PK var3 = null;
         if (var2 == 0) {
            var3 = GB.I(MEI.dI, XEI.eI.Z, (byte)51);
         }

         if (var2 == 1) {
            var3 = GB.I(MEI.JI, XEI.eI.Z, (byte)28);
         }

         XP var4 = XEI.mI.I(681479919);
         var3.J.W(var4.I * -1760580017 + var0);
         var3.J.J(IC.I(-545107710) ? 1 : 0, (byte)1);
         var3.J.W(var1 + var4.Z * 283514611);
         JN.A = var1 * -1129029761;
         JN.I = var0 * -1835291189;
         JN.E = false;
         TO.I(-1884278472);
         return var3;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "lm.bp(" + ')');
      }
   }

   static final void C(OU var0, byte var1) {
      try {
         var0.S[(var0.A += 969361751) * -203050393 - 1] = LY.I((long)var0.H[(var0.J -= -391880689) * 681479919] * 60000L, WO.U.method242(694163818), true, -1759893587) + " UTC";
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "lm.aam(" + ')');
      }
   }
}
