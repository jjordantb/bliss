public class JO extends FO {
   boolean G;
   int H;
   int K;
   float L;
   boolean M;
   float N;

   static JO I(MJI var0, int var1, int var2, boolean var3, int[] var4, int var5, int var6) {
      if (!var0.B && (!QII.I(var1, 1860235026) || !QII.I(var2, 2077876811))) {
         return var0.AI ? new JO(var0, 34037, var1, var2, var3, var4, var5, var6) : new JO(var0, var1, var2, JV.I(var1, (byte)16), JV.I(var2, (byte)16), var4);
      } else {
         return new JO(var0, 3553, var1, var2, var3, var4, var5, var6);
      }
   }

   static JO I(MJI var0, YCI var1, SDI var2, int var3, int var4) {
      if (!var0.B && (!QII.I(var3, 2054031633) || !QII.I(var4, 1814052546))) {
         return var0.AI ? new JO(var0, 34037, var1, var2, var3, var4) : new JO(var0, var1, var2, var3, var4, JV.I(var3, (byte)16), JV.I(var4, (byte)16));
      } else {
         return new JO(var0, 3553, var1, var2, var3, var4);
      }
   }

   static JO I(MJI var0, int var1, int var2, int var3, int var4) {
      if (!var0.B && (!QII.I(var3, 1814986255) || !QII.I(var4, 2130033438))) {
         return var0.AI ? new JO(var0, 34037, var1, var2, var3, var4, true) : new JO(var0, var1, var2, var3, var4, JV.I(var3, (byte)16), JV.I(var4, (byte)16), true);
      } else {
         return new JO(var0, 3553, var1, var2, var3, var4, true);
      }
   }

   JO(MJI var1, int var2, int var3, int var4, boolean var5, int[] var6, int var7, int var8) {
      super(var1, var2, var3, var4, var5, var6, var7, var8, true);
      this.K = var3;
      this.H = var4;
      if (this.I == 34037) {
         this.N = (float)var4;
         this.L = (float)var3;
         this.M = false;
      } else {
         this.N = 1.0F;
         this.L = 1.0F;
         this.M = true;
      }

      this.G = false;
   }

   JO(MJI var1, int var2, YCI var3, SDI var4, int var5, int var6, boolean var7, byte[] var8, YCI var9) {
      super(var1, var2, var3, var4, var5, var6, var7, var8, var9, true);
      this.K = var5;
      this.H = var6;
      if (this.I == 34037) {
         this.N = (float)var6;
         this.L = (float)var5;
         this.M = false;
      } else {
         this.N = 1.0F;
         this.L = 1.0F;
         this.M = true;
      }

      this.G = false;
   }

   JO(MJI var1, int var2, int var3, int var4, int var5, int var6, boolean var7) {
      super(var1, var2, var3, var4, var5, var6);
      this.K = var5;
      this.H = var6;
      if (this.I == 34037) {
         this.N = (float)var6;
         this.L = (float)var5;
         this.M = false;
      } else {
         this.N = 1.0F;
         this.L = 1.0F;
         this.M = true;
      }

      this.G = false;
   }

   JO(MJI var1, int var2, int var3, int var4, int var5, int[] var6) {
      super(var1, 3553, YCI.Z, SDI.C, var4, var5);
      this.K = var2;
      this.H = var3;
      this.I(0, var5 - var3, var2, var3, var6, 0, 0, true);
      this.N = (float)var3 / (float)var5;
      this.L = (float)var2 / (float)var4;
      this.M = false;
      this.G = true;
      this.I(false, false);
   }

   JO(MJI var1, YCI var2, SDI var3, int var4, int var5, int var6, int var7, byte[] var8, YCI var9) {
      super(var1, 3553, var2, var3, var6, var7);
      this.K = var4;
      this.H = var5;
      this.I(0, var7 - var5, var4, var5, var8, var9, 0, 0, true);
      this.N = (float)var5 / (float)var7;
      this.L = (float)var4 / (float)var6;
      this.M = false;
      this.G = true;
      this.I(false, false);
   }

   JO(MJI var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean var8) {
      super(var1, 3553, var2, var3, var6, var7);
      this.K = var4;
      this.H = var5;
      this.N = (float)var5 / (float)var7;
      this.L = (float)var4 / (float)var6;
      this.M = false;
      this.G = true;
      this.I(false, false);
   }

   void I(boolean var1) {
      super.I(var1 && !this.G);
   }

   JO(MJI var1, YCI var2, SDI var3, int var4, int var5, int var6, int var7) {
      super(var1, 3553, var2, var3, var6, var7);
      this.K = var4;
      this.H = var5;
      this.N = (float)var5 / (float)var7;
      this.L = (float)var4 / (float)var6;
      this.M = false;
      this.G = true;
      this.I(false, false);
   }

   static JO I(MJI var0, YCI var1, SDI var2, int var3, int var4, boolean var5, byte[] var6, YCI var7) {
      if (!var0.B && (!QII.I(var3, 2005734954) || !QII.I(var4, 1816892397))) {
         return var0.AI ? new JO(var0, 34037, var1, var2, var3, var4, var5, var6, var7) : new JO(var0, var1, var2, var3, var4, JV.I(var3, (byte)16), JV.I(var4, (byte)16), var6, var7);
      } else {
         return new JO(var0, 3553, var1, var2, var3, var4, var5, var6, var7);
      }
   }

   JO(MJI var1, int var2, YCI var3, SDI var4, int var5, int var6) {
      super(var1, var2, var3, var4, var5, var6);
      this.K = var5;
      this.H = var6;
      if (this.I == 34037) {
         this.N = (float)var6;
         this.L = (float)var5;
         this.M = false;
      } else {
         this.N = 1.0F;
         this.L = 1.0F;
         this.M = true;
      }

      this.G = false;
   }

   void C(boolean var1) {
      super.I(var1 && !this.G);
   }
}
