import jaclib.ping.IcmpService;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class LSI extends IcmpService {
   static volatile LSI I;
   List Z = new ArrayList();

   protected void notify(int var1, int var2, int var3) {
      try {
         Iterator var4 = this.Z.iterator();

         while(var4.hasNext()) {
            DAI var5 = (DAI)var4.next();
            var5.method245(var1, var2, var3, (short)1503);
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "adv.notify(" + ')');
      }
   }

   protected void notify(int var1) {
      try {
         Iterator var2 = this.Z.iterator();

         while(var2.hasNext()) {
            DAI var3 = (DAI)var2.next();
            var3.method247(var1 == 0, (byte)5);
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "adv.notify(" + ')');
      }
   }

   protected void b(int var1, int var2, int var3) {
      Iterator var4 = this.Z.iterator();

      while(var4.hasNext()) {
         DAI var5 = (DAI)var4.next();
         var5.method245(var1, var2, var3, (short)5654);
      }

   }

   protected void a(int var1) {
      Iterator var2 = this.Z.iterator();

      while(var2.hasNext()) {
         DAI var3 = (DAI)var2.next();
         var3.method247(var1 == 0, (byte)5);
      }

   }

   protected void f(int var1) {
      Iterator var2 = this.Z.iterator();

      while(var2.hasNext()) {
         DAI var3 = (DAI)var2.next();
         var3.method247(var1 == 0, (byte)5);
      }

   }

   protected void p(int var1, int var2, int var3) {
      Iterator var4 = this.Z.iterator();

      while(var4.hasNext()) {
         DAI var5 = (DAI)var4.next();
         var5.method245(var1, var2, var3, (short)26137);
      }

   }

   public static byte[][][] I(int var0, int var1) {
      try {
         byte[][][] var2 = new byte[8][4][];
         int var3 = var0;
         int var4 = var0;
         byte[] var5 = new byte[var0 * var0];
         int var6 = 0;

         int var7;
         int var8;
         for(var7 = 0; var7 < var4; ++var7) {
            for(var8 = 0; var8 < var3; ++var8) {
               if (var8 <= var7) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[0][0] = var5;
         var5 = new byte[var3 * var4];
         var6 = 0;

         for(var7 = var4 - 1; var7 >= 0; --var7) {
            for(var8 = 0; var8 < var4; ++var8) {
               if (var8 <= var7) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[0][1] = var5;
         var5 = new byte[var3 * var4];
         var6 = 0;

         for(var7 = 0; var7 < var4; ++var7) {
            for(var8 = 0; var8 < var3; ++var8) {
               if (var8 >= var7) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[0][2] = var5;
         var5 = new byte[var3 * var4];
         var6 = 0;

         for(var7 = var4 - 1; var7 >= 0; --var7) {
            for(var8 = 0; var8 < var3; ++var8) {
               if (var8 >= var7) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[0][3] = var5;
         var5 = new byte[var4 * var3];
         var6 = 0;

         for(var7 = var4 - 1; var7 >= 0; --var7) {
            for(var8 = 0; var8 < var3; ++var8) {
               if (var8 <= var7 >> 1) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[1][0] = var5;
         var5 = new byte[var3 * var4];
         var6 = 0;

         for(var7 = 0; var7 < var4; ++var7) {
            for(var8 = 0; var8 < var3; ++var8) {
               if (var6 >= 0 && var6 < var5.length) {
                  if (var8 >= var7 << 1) {
                     var5[var6] = -1;
                  }

                  ++var6;
               } else {
                  ++var6;
               }
            }
         }

         var2[1][1] = var5;
         var5 = new byte[var4 * var3];
         var6 = 0;

         for(var7 = 0; var7 < var4; ++var7) {
            for(var8 = var3 - 1; var8 >= 0; --var8) {
               if (var8 <= var7 >> 1) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[1][2] = var5;
         var5 = new byte[var4 * var3];
         var6 = 0;

         for(var7 = var4 - 1; var7 >= 0; --var7) {
            for(var8 = var3 - 1; var8 >= 0; --var8) {
               if (var8 >= var7 << 1) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[1][3] = var5;
         var5 = new byte[var4 * var3];
         var6 = 0;

         for(var7 = var4 - 1; var7 >= 0; --var7) {
            for(var8 = var3 - 1; var8 >= 0; --var8) {
               if (var8 <= var7 >> 1) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[2][0] = var5;
         var5 = new byte[var4 * var3];
         var6 = 0;

         for(var7 = var4 - 1; var7 >= 0; --var7) {
            for(var8 = 0; var8 < var3; ++var8) {
               if (var8 >= var7 << 1) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[2][1] = var5;
         var5 = new byte[var3 * var4];
         var6 = 0;

         for(var7 = 0; var7 < var4; ++var7) {
            for(var8 = 0; var8 < var3; ++var8) {
               if (var8 <= var7 >> 1) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[2][2] = var5;
         var5 = new byte[var3 * var4];
         var6 = 0;

         for(var7 = 0; var7 < var4; ++var7) {
            for(var8 = var3 - 1; var8 >= 0; --var8) {
               if (var8 >= var7 << 1) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[2][3] = var5;
         var5 = new byte[var3 * var4];
         var6 = 0;

         for(var7 = var4 - 1; var7 >= 0; --var7) {
            for(var8 = 0; var8 < var3; ++var8) {
               if (var8 >= var7 >> 1) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[3][0] = var5;
         var5 = new byte[var4 * var3];
         var6 = 0;

         for(var7 = 0; var7 < var4; ++var7) {
            for(var8 = 0; var8 < var3; ++var8) {
               if (var8 <= var7 << 1) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[3][1] = var5;
         var5 = new byte[var3 * var4];
         var6 = 0;

         for(var7 = 0; var7 < var4; ++var7) {
            for(var8 = var3 - 1; var8 >= 0; --var8) {
               if (var8 >= var7 >> 1) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[3][2] = var5;
         var5 = new byte[var3 * var4];
         var6 = 0;

         for(var7 = var4 - 1; var7 >= 0; --var7) {
            for(var8 = var3 - 1; var8 >= 0; --var8) {
               if (var8 <= var7 << 1) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[3][3] = var5;
         var5 = new byte[var3 * var4];
         var6 = 0;

         for(var7 = var4 - 1; var7 >= 0; --var7) {
            for(var8 = var3 - 1; var8 >= 0; --var8) {
               if (var8 >= var7 >> 1) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[4][0] = var5;
         var5 = new byte[var3 * var4];
         var6 = 0;

         for(var7 = var4 - 1; var7 >= 0; --var7) {
            for(var8 = 0; var8 < var3; ++var8) {
               if (var8 <= var7 << 1) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[4][1] = var5;
         var5 = new byte[var4 * var3];
         var6 = 0;

         for(var7 = 0; var7 < var4; ++var7) {
            for(var8 = 0; var8 < var3; ++var8) {
               if (var8 >= var7 >> 1) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[4][2] = var5;
         var5 = new byte[var3 * var4];
         var6 = 0;

         for(var7 = 0; var7 < var4; ++var7) {
            for(var8 = var3 - 1; var8 >= 0; --var8) {
               if (var8 <= var7 << 1) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[4][3] = var5;
         var5 = new byte[var4 * var3];
         var6 = 0;

         for(var7 = 0; var7 < var4; ++var7) {
            for(var8 = 0; var8 < var3; ++var8) {
               if (var8 <= var3 / 2) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[5][0] = var5;
         var5 = new byte[var4 * var3];
         var6 = 0;

         for(var7 = 0; var7 < var4; ++var7) {
            for(var8 = 0; var8 < var3; ++var8) {
               if (var7 <= var4 / 2) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[5][1] = var5;
         var5 = new byte[var4 * var3];
         var6 = 0;

         for(var7 = 0; var7 < var4; ++var7) {
            for(var8 = 0; var8 < var3; ++var8) {
               if (var8 >= var3 / 2) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[5][2] = var5;
         var5 = new byte[var4 * var3];
         var6 = 0;

         for(var7 = 0; var7 < var4; ++var7) {
            for(var8 = 0; var8 < var3; ++var8) {
               if (var7 >= var4 / 2) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[5][3] = var5;
         var5 = new byte[var4 * var3];
         var6 = 0;

         for(var7 = 0; var7 < var4; ++var7) {
            for(var8 = 0; var8 < var3; ++var8) {
               if (var8 <= var7 - var4 / 2) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[6][0] = var5;
         var5 = new byte[var3 * var4];
         var6 = 0;

         for(var7 = var4 - 1; var7 >= 0; --var7) {
            for(var8 = 0; var8 < var3; ++var8) {
               if (var8 <= var7 - var4 / 2) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[6][1] = var5;
         var5 = new byte[var4 * var3];
         var6 = 0;

         for(var7 = var4 - 1; var7 >= 0; --var7) {
            for(var8 = var3 - 1; var8 >= 0; --var8) {
               if (var8 <= var7 - var4 / 2) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[6][2] = var5;
         var5 = new byte[var3 * var4];
         var6 = 0;

         for(var7 = 0; var7 < var4; ++var7) {
            for(var8 = var3 - 1; var8 >= 0; --var8) {
               if (var8 <= var7 - var4 / 2) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[6][3] = var5;
         var5 = new byte[var4 * var3];
         var6 = 0;

         for(var7 = 0; var7 < var4; ++var7) {
            for(var8 = 0; var8 < var3; ++var8) {
               if (var8 >= var7 - var4 / 2) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[7][0] = var5;
         var5 = new byte[var3 * var4];
         var6 = 0;

         for(var7 = var4 - 1; var7 >= 0; --var7) {
            for(var8 = 0; var8 < var3; ++var8) {
               if (var8 >= var7 - var4 / 2) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[7][1] = var5;
         var5 = new byte[var4 * var3];
         var6 = 0;

         for(var7 = var4 - 1; var7 >= 0; --var7) {
            for(var8 = var3 - 1; var8 >= 0; --var8) {
               if (var8 >= var7 - var4 / 2) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[7][2] = var5;
         var5 = new byte[var4 * var3];
         var6 = 0;

         for(var7 = 0; var7 < var4; ++var7) {
            for(var8 = var3 - 1; var8 >= 0; --var8) {
               if (var8 >= var7 - var4 / 2) {
                  var5[var6] = -1;
               }

               ++var6;
            }
         }

         var2[7][3] = var5;
         return var2;
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "adv.f(" + ')');
      }
   }

   static void I(boolean var0, int var1) {
      try {
         if (var0) {
            if (-1 != -257444687 * XEI.xC) {
               HFI.I(-257444687 * XEI.xC, -2042512871);
            }

            for(OSI var2 = (OSI)XEI.yC.C(2118062141); var2 != null; var2 = (OSI)XEI.yC.Z((byte)56)) {
               if (!var2.Z(-629325116)) {
                  var2 = (OSI)XEI.yC.C(1715939754);
                  if (var2 == null) {
                     break;
                  }
               }

               BB.I(var2, true, false, -113822480);
            }

            XEI.xC = -1785861201;
            XEI.yC = new JX(8);
            EU.I((short)255);
            XEI.xC = -391544995 * JX.J.I;
            DS.I(false, (byte)8);
            TQ.Z(-1204145082);
            KZ.I(-257444687 * XEI.xC, (int[])null, 188692666);
         }

         TQ.h = true;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "adv.fr(" + ')');
      }
   }
}
