public class G {
   public String I;
   public String Z;
   public String C;
   public CI[] B;
   public CI[] D;
   public static int F;

   void I(D var1, byte var2) {
      try {
         this.Z = var1.I(1509343502);
         this.I = var1.I(1509343502);
         this.C = var1.I(1509343502);
         int var3 = var1.Z(823123769);
         int var4 = var1.Z(-1396708449);
         this.B = var3 == 0 ? null : new CI[var3];
         this.D = var4 == 0 ? null : new CI[var4];

         int var5;
         for(var5 = 0; var5 < var3; ++var5) {
            this.B[var5] = new CI();
            this.B[var5].I(var1, 1424483545);
         }

         for(var5 = 0; var5 < var4; ++var5) {
            this.D[var5] = new CI();
            this.D[var5].I(var1, 1424483545);
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ek.a(" + ')');
      }
   }

   public static void I(KJ var0, int var1) {
      try {
         UA.D = var0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ek.a(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = XEI.X ? 1 : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ek.abd(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)70);
         X var4 = IU.F[var2 >> 16];
         RD.I(var3, var4, false, 1, var0, 233594133);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ek.he(" + ')');
      }
   }

   static String I(int var0, XW var1, int var2) {
      try {
         if (var0 < 100000) {
            return "<col=ffff00>" + var0 + "</col>";
         } else {
            return var0 < 10000000 ? "<col=ffffff>" + var0 / 1000 + VEI.bZ.I(var1, -875414210) + "</col>" : "<col=00ff80>" + var0 / 1000000 + VEI.zZ.I(var1, -875414210) + "</col>";
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ek.n(" + ')');
      }
   }

   public static final void I(boolean var0, byte var1) {
      try {
         PK var2 = GB.I(MEI.CI, XEI.eI.Z, (byte)111);
         XEI.eI.I(var2, (byte)-21);

         for(OSI var3 = (OSI)XEI.yC.C(1892786919); var3 != null; var3 = (OSI)XEI.yC.Z((byte)-93)) {
            if (!var3.Z(-629325116)) {
               var3 = (OSI)XEI.yC.C(1676096674);
               if (var3 == null) {
                  break;
               }
            }

            if (var3.J * 27137839 == 0) {
               BB.I(var3, true, var0, -113822480);
            }
         }

         if (XEI.g != null) {
            VEI.I(XEI.g, -1209330591);
            XEI.g = null;
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ek.lr(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         if (WBI.S != null && GJ.Z * -316347407 < CQ.L * 367592105) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = WBI.S[(GJ.Z += 1578804497) * -316347407 - 1] & '\uffff';
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = -1;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ek.abw(" + ')');
      }
   }

   static void I(int var0, int var1, int var2) {
      try {
         VK var3 = IV.I(14, (long)var0);
         var3.I((byte)25);
         var3.L = 1274450087 * var1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ek.ag(" + ')');
      }
   }

   static void I(int var0, int var1, int var2, int var3, int var4, int var5) {
      try {
         int var6 = 0;
         int var7 = var3;
         int var8 = var2 * var2;
         int var9 = var3 * var3;
         int var10 = var9 << 1;
         int var11 = var8 << 1;
         int var12 = var3 << 1;
         int var13 = var10 + (1 - var12) * var8;
         int var14 = var9 - (var12 - 1) * var11;
         int var15 = var8 << 2;
         int var16 = var9 << 2;
         int var17 = var10 * (3 + (var6 << 1));
         int var18 = ((var3 << 1) - 3) * var11;
         int var19 = (1 + var6) * var16;
         int var20 = var15 * (var3 - 1);
         DFI.I(ZT.I[var1], var0 - var2, var2 + var0, var4, -2115360638);

         while(var7 > 0) {
            if (var13 < 0) {
               while(var13 < 0) {
                  var13 += var17;
                  var14 += var19;
                  var17 += var16;
                  var19 += var16;
                  ++var6;
               }
            }

            if (var14 < 0) {
               var13 += var17;
               var14 += var19;
               var17 += var16;
               var19 += var16;
               ++var6;
            }

            var13 += -var20;
            var14 += -var18;
            var18 -= var15;
            var20 -= var15;
            --var7;
            int var21 = var1 - var7;
            int var22 = var1 + var7;
            int var23 = var6 + var0;
            int var24 = var0 - var6;
            DFI.I(ZT.I[var21], var24, var23, var4, 756505397);
            DFI.I(ZT.I[var22], var24, var23, var4, 931363895);
         }

      } catch (RuntimeException var25) {
         throw DQ.I(var25, "ek.at(" + ')');
      }
   }
}
