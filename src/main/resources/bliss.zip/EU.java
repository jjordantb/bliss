public class EU {
   public static int F = 20;
   public static int Z = -6;
   public static int append = -5;
   public static int atan2 = -4;
   public static int cos = -1;

   EU() throws Throwable {
      throw new Error();
   }

   static final void I(OU var0, short var1) {
      try {
         HU.I(var0.H[(var0.J -= -391880689) * 681479919], -1104898137);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ql.agd(" + ')');
      }
   }

   public static void I(short var0) {
      try {
         IU.F = new X[CA.I.Z(949346193)];
         MX.S = new boolean[CA.I.Z(1513726492)];
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "ql.m(" + ')');
      }
   }

   public static final void I(byte var0) {
      try {
         if (-1 != -591434031 * XEI.jZ && XEI.sZ * -839811113 != -1) {
            int var1 = (XEI.MB * 892197957 * (XEI.kZ * 1714001937 - 1049339515 * XEI.EB) >> 16) + 1049339515 * XEI.EB;
            XEI.MB += 283956877 * var1;
            if (XEI.MB * 892197957 >= 65535) {
               XEI.MB = -979359373;
               if (!XEI.mZ) {
                  XEI.lZ = true;
               } else {
                  XEI.lZ = false;
               }

               XEI.mZ = true;
            } else {
               XEI.lZ = false;
               XEI.mZ = false;
            }

            float var2 = (float)(XEI.MB * 892197957) / 65535.0F;
            float[] var3 = new float[3];
            int var4 = XEI.aZ * 1872262310;

            int var7;
            int var8;
            int var9;
            int var10;
            int var11;
            int var12;
            for(int var5 = 0; var5 < 3; ++var5) {
               int var6 = 3 * XEI.fZ[XEI.jZ * -591434031][var4][var5];
               var7 = XEI.fZ[-591434031 * XEI.jZ][1 + var4][var5] * 3;
               var8 = (XEI.fZ[XEI.jZ * -591434031][2 + var4][var5] - (XEI.fZ[XEI.jZ * -591434031][3 + var4][var5] - XEI.fZ[-591434031 * XEI.jZ][var4 + 2][var5])) * 3;
               var9 = XEI.fZ[-591434031 * XEI.jZ][var4][var5];
               var10 = var7 - var6;
               var11 = var6 - 2 * var7 + var8;
               var12 = var7 + (XEI.fZ[XEI.jZ * -591434031][var4 + 2][var5] - var9) - var8;
               var3[var5] = var2 * ((float)var10 + ((float)var11 + (float)var12 * var2) * var2) + (float)var9;
            }

            XP var17 = XEI.mI.I(681479919);
            RR.Q = 547882953 * ((int)var3[0] - 526163456 * var17.I);
            L.B = (int)var3[1] * -1078403147;
            RZ.H = 309839105 * ((int)var3[2] - var17.Z * -869407232);
            float[] var18 = new float[3];
            var7 = XEI.eZ * 977380166;

            for(var8 = 0; var8 < 3; ++var8) {
               var9 = XEI.fZ[-839811113 * XEI.sZ][var7][var8] * 3;
               var10 = XEI.fZ[XEI.sZ * -839811113][1 + var7][var8] * 3;
               var11 = 3 * (XEI.fZ[XEI.sZ * -839811113][2 + var7][var8] - (XEI.fZ[-839811113 * XEI.sZ][3 + var7][var8] - XEI.fZ[-839811113 * XEI.sZ][2 + var7][var8]));
               var12 = XEI.fZ[-839811113 * XEI.sZ][var7][var8];
               int var13 = var10 - var9;
               int var14 = var11 + (var9 - var10 * 2);
               int var15 = var10 + (XEI.fZ[XEI.sZ * -839811113][2 + var7][var8] - var12) - var11;
               var18[var8] = ((float)var13 + (var2 * (float)var15 + (float)var14) * var2) * var2 + (float)var12;
            }

            float var19 = var18[0] - var3[0];
            float var20 = (var18[1] - var3[1]) * -1.0F;
            float var21 = var18[2] - var3[2];
            double var22 = Math.sqrt((double)(var21 * var21 + var19 * var19));
            XEI.VZ = ((int)(Math.atan2((double)var20, var22) * 2607.5945876176133D) & 16383) * -648269561;
            CZ.I = ((int)(-Math.atan2((double)var19, (double)var21) * 2607.5945876176133D) & 16383) * -1587695039;
            TF.C = (XEI.fZ[-591434031 * XEI.jZ][var4][3] + ((XEI.fZ[-591434031 * XEI.jZ][2 + var4][3] - XEI.fZ[XEI.jZ * -591434031][var4][3]) * 892197957 * XEI.MB >> 16)) * -851711283;
         }

      } catch (RuntimeException var16) {
         throw DQ.I(var16, "ql.hi(" + ')');
      }
   }

   static void I(HSI var0, V var1, int var2, int var3, int var4, int var5, int var6, long var7) {
      try {
         int var9 = var5 * var5 + var4 * var4;
         if ((long)var9 <= var7) {
            int var10;
            if (EE.V * -863531439 == 2) {
               var10 = (int)XEI.qD & 16383;
            } else {
               var10 = 1227356013 * XEI.GC + (int)XEI.qD & 16383;
            }

            int var11 = HF.S[var10];
            int var12 = HF.I[var10];
            if (EE.V * -863531439 != 2) {
               var11 = 256 * var11 / (256 + XEI.NZ * 356727603);
               var12 = var12 * 256 / (356727603 * XEI.NZ + 256);
            }

            int var13 = var12 * var4 + var5 * var11 >> 14;
            int var14 = var12 * var5 - var4 * var11 >> 14;
            IBI var15 = DDI.E[var6];
            int var16 = var15.method623();
            int var17 = var15.method625();
            int var18 = var13 + -2093041337 * var0.g / 2 - var16 / 2;
            int var19 = var18 + var16;
            int var20 = var0.o * 457937409 / 2 + -var14 - var17;
            int var21 = var17 + var20;
            if (var1.I(var18, var20, -1933314892) && var1.I(var19, var20, -1940258831) && var1.I(var18, var21, -1423315727) && var1.I(var19, var21, -1131709831)) {
               var15.method654(var18 + var2, var20 + var3, var1.D, var2, var3);
            } else {
               double var22 = Math.atan2((double)var13, (double)var14);
               int var24 = Math.min(var0.g * -2093041337 / 2, var0.o * 457937409 / 2);
               var24 -= 6;
               int var25 = (int)(Math.sin(var22) * (double)var24);
               int var26 = (int)(Math.cos(var22) * (double)var24);
               WJ.H[var6].I((float)(-2093041337 * var0.g) / 2.0F + (float)var2 + (float)var25, (float)var3 + (float)(var0.o * 457937409) / 2.0F - (float)var26, 4096, (int)(-var22 / 6.283185307179586D * 65535.0D));
            }
         }

      } catch (RuntimeException var27) {
         throw DQ.I(var27, "ql.y(" + ')');
      }
   }
}
