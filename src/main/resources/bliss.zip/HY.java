public class HY {
   public static HY I = new HY();
   public static HY Z = new HY();
   public static HY C = new HY();
   public static HY B = new HY();
   public static KJ D;
   public static CX F;

   static final void I(OU var0, byte var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         OF.I(var3, var4, var0, (short)-9329);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "tc.jk(" + ')');
      }
   }

   public static void I(int var0, int var1, int var2, int var3, int var4) {
      try {
         YR.D = var0 * 1418334925;
         YR.Z = 728613823 * var2;
         YR.C = var1 * 1131449449;
         YR.B = var3 * -879501875;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "tc.f(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-30);
         X var4 = IU.F[var2 >> 16];
         BDI.I(var3, var4, var0, (short)255);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "tc.ew(" + ')');
      }
   }

   static void Z(GSI var0, int var1) {
      try {
         if (!FX.c) {
            GO.I(var0, -1625873215);
         } else {
            ODI.I(var0, -618250178);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "tc.aj(" + ')');
      }
   }

   static final int I(int var0, int var1, int var2, int var3) {
      try {
         return var0 < var1 ? var1 : (var0 > var2 ? var2 : var0);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "tc.p(" + ')');
      }
   }

   static void I(GSI var0, byte var1) {
      try {
         if (FX.G) {
            Z(var0, -2009290337);
         } else {
            YBI.I(var0, 1272900210);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "tc.l(" + ')');
      }
   }

   static void Z(int var0, int var1, int var2, int var3) {
      try {
         if (1008 == var0) {
            AI.I(HZI.Z, var1, var2, 67564061);
         } else if (var0 == 1009) {
            AI.I(HZI.B, var1, var2, -679680198);
         } else if (var0 == 1010) {
            AI.I(HZI.I, var1, var2, -1335757742);
         } else if (1011 == var0) {
            AI.I(HZI.K, var1, var2, -1097682484);
         } else if (var0 == 1012) {
            AI.I(HZI.N, var1, var2, -1428410660);
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "tc.cm(" + ')');
      }
   }
}
