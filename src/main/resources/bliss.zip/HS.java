import jaggl.OpenGL;

public abstract class HS implements IEI {
   boolean glBindTexture;
   static int glDisable = 3553;
   static int glEnable = 34037;
   static int glGenTextures = 34067;
   int I;
   int glGenerateMipmapEXT;
   int Z;
   EB glTexImage2Df;
   YCI C;
   SDI B;
   static int glTexImage2Di = 0;
   OJI D;
   static int glTexImage2Dub = 32879;
   static int[] glTexParameteri = new int[1];

   public void method123() {
      int var1 = this.D.P();
      int var2 = this.D.FZ[var1];
      if (var2 != this.I) {
         if (var2 != 0) {
            OpenGL.glBindTexture(var2, 0);
            OpenGL.glDisable(var2);
         }

         OpenGL.glEnable(this.I);
         this.D.FZ[var1] = this.I;
      }

      OpenGL.glBindTexture(this.I, this.Z);
   }

   public void method128() {
      int var1 = this.D.P();
      int var2 = this.D.FZ[var1];
      if (var2 != this.I) {
         if (var2 != 0) {
            OpenGL.glBindTexture(var2, 0);
            OpenGL.glDisable(var2);
         }

         OpenGL.glEnable(this.I);
         this.D.FZ[var1] = this.I;
      }

      OpenGL.glBindTexture(this.I, this.Z);
   }

   public void method122(EB var1) {
      if (this.glTexImage2Df != var1) {
         this.glTexImage2Df = var1;
         this.glBindTexture();
      }

   }

   void glBindTexture() {
      this.D.I((IEI)this);
      if (this.glTexImage2Df == EB.Z) {
         OpenGL.glTexParameteri(this.I, 10241, this.glBindTexture ? 9987 : 9729);
         OpenGL.glTexParameteri(this.I, 10240, 9729);
      } else {
         OpenGL.glTexParameteri(this.I, 10241, this.glBindTexture ? 9984 : 9728);
         OpenGL.glTexParameteri(this.I, 10240, 9728);
      }

   }

   boolean Z() {
      int var1 = this.glEnable();
      this.D.I((IEI)this);
      OpenGL.glGenerateMipmapEXT(this.I);
      this.glBindTexture = true;
      this.glBindTexture();
      this.glDisable(var1);
      return true;
   }

   void I(int var1, int var2, int var3, int[] var4) {
      if (var2 > 0 && !QII.I(var2, 2042466148)) {
         throw new IllegalArgumentException("");
      } else if (var3 > 0 && !QII.I(var3, 1957388461)) {
         throw new IllegalArgumentException("");
      } else if (this.C != YCI.Z) {
         throw new IllegalArgumentException("");
      } else {
         int var5 = 0;
         int var6 = var2 < var3 ? var2 : var3;
         int var7 = var2 >> 1;
         int var8 = var3 >> 1;
         int[] var9 = var4;
         int[] var10 = new int[var7 * var8];

         while(true) {
            OpenGL.glTexImage2Di(var1, var5, OJI.I(this.C, this.B), var2, var3, 0, 32993, this.D.SZ, var9, 0);
            if (var6 <= 1) {
               return;
            }

            int var11 = 0;
            int var12 = 0;
            int var13 = var12 + var2;

            for(int var14 = 0; var14 < var8; ++var14) {
               for(int var15 = 0; var15 < var7; ++var15) {
                  int var16 = var9[var12++];
                  int var17 = var9[var12++];
                  int var18 = var9[var13++];
                  int var19 = var9[var13++];
                  int var20 = var16 >> 24 & 255;
                  int var21 = var16 >> 16 & 255;
                  int var22 = var16 >> 8 & 255;
                  int var23 = var16 & 255;
                  var20 += var17 >> 24 & 255;
                  var21 += var17 >> 16 & 255;
                  var22 += var17 >> 8 & 255;
                  var23 += var17 & 255;
                  var20 += var18 >> 24 & 255;
                  var21 += var18 >> 16 & 255;
                  var22 += var18 >> 8 & 255;
                  var23 += var18 & 255;
                  var20 += var19 >> 24 & 255;
                  var21 += var19 >> 16 & 255;
                  var22 += var19 >> 8 & 255;
                  var23 += var19 & 255;
                  var10[var11++] = (var20 & 1020) << 22 | (var21 & 1020) << 14 | (var22 & 1020) << 6 | (var23 & 1020) >> 2;
               }

               var12 += var2;
               var13 += var2;
            }

            int[] var24 = var10;
            var10 = var9;
            var9 = var24;
            var2 = var7;
            var3 = var8;
            var7 >>= 1;
            var8 >>= 1;
            var6 >>= 1;
            ++var5;
         }
      }
   }

   void I(int var1, int var2, int var3, float[] var4) {
      if (var2 > 0 && !QII.I(var2, 1815330854)) {
         throw new IllegalArgumentException("");
      } else if (var3 > 0 && !QII.I(var3, 1992937673)) {
         throw new IllegalArgumentException("");
      } else {
         int var5 = this.C.I * 845115459;
         int var6 = 0;
         int var7 = var2 < var3 ? var2 : var3;
         int var8 = var2 >> 1;
         int var9 = var3 >> 1;
         float[] var10 = var4;
         float[] var11 = new float[var8 * var9 * var5];

         while(true) {
            OpenGL.glTexImage2Df(var1, var6, OJI.I(this.C, this.B), var2, var3, 0, OJI.I(this.C), 5126, var10, 0);
            if (var7 <= 1) {
               return;
            }

            int var12 = var2 * var5;

            for(int var13 = 0; var13 < var5; ++var13) {
               int var14 = var13;
               int var15 = var13;
               int var16 = var13 + var12;

               for(int var17 = 0; var17 < var9; ++var17) {
                  for(int var18 = 0; var18 < var8; ++var18) {
                     float var19 = var10[var15];
                     var15 += var5;
                     var19 += var10[var15];
                     var15 += var5;
                     var19 += var10[var16];
                     var16 += var5;
                     var19 += var10[var16];
                     var16 += var5;
                     var11[var14] = var19 * 0.25F;
                     var14 += var5;
                  }

                  var15 += var12;
                  var16 += var12;
               }
            }

            float[] var20 = var11;
            var11 = var10;
            var10 = var20;
            var2 = var8;
            var3 = var9;
            var8 >>= 1;
            var9 >>= 1;
            var7 >>= 1;
            ++var6;
         }
      }
   }

   void glDisable(int var1) {
      this.D.E -= var1;
      this.D.E += this.glEnable();
   }

   int glEnable() {
      int var1 = this.C.I * 845115459 * this.B.S * 685647847 * this.glGenerateMipmapEXT;
      return this.glBindTexture ? var1 * 4 / 3 : var1;
   }

   public void method124(EB var1) {
      if (this.glTexImage2Df != var1) {
         this.glTexImage2Df = var1;
         this.glBindTexture();
      }

   }

   public void d() {
      if (this.Z > 0) {
         this.D.Z(this.Z, this.glEnable());
         this.Z = 0;
      }

   }

   public void u() {
      if (this.Z > 0) {
         this.D.Z(this.Z, this.glEnable());
         this.Z = 0;
      }

   }

   public void method125() {
      int var1 = this.D.P();
      int var2 = this.D.FZ[var1];
      if (var2 != this.I) {
         if (var2 != 0) {
            OpenGL.glBindTexture(var2, 0);
            OpenGL.glDisable(var2);
         }

         OpenGL.glEnable(this.I);
         this.D.FZ[var1] = this.I;
      }

      OpenGL.glBindTexture(this.I, this.Z);
   }

   public void method126() {
      int var1 = this.D.P();
      int var2 = this.D.FZ[var1];
      if (var2 != this.I) {
         if (var2 != 0) {
            OpenGL.glBindTexture(var2, 0);
            OpenGL.glDisable(var2);
         }

         OpenGL.glEnable(this.I);
         this.D.FZ[var1] = this.I;
      }

      OpenGL.glBindTexture(this.I, this.Z);
   }

   public void method127(EB var1) {
      if (this.glTexImage2Df != var1) {
         this.glTexImage2Df = var1;
         this.glBindTexture();
      }

   }

   public void x() {
      if (this.Z > 0) {
         this.D.Z(this.Z, this.glEnable());
         this.Z = 0;
      }

   }

   public void b() {
      if (this.Z > 0) {
         this.D.Z(this.Z, this.glEnable());
         this.Z = 0;
      }

   }

   void I(int var1, int var2, int var3, byte[] var4) {
      if (var2 > 0 && !QII.I(var2, 1815267823)) {
         throw new IllegalArgumentException("");
      } else if (var3 > 0 && !QII.I(var3, 1849521842)) {
         throw new IllegalArgumentException("");
      } else {
         int var5 = this.C.I * 845115459;
         int var6 = 0;
         int var7 = var2 < var3 ? var2 : var3;
         int var8 = var2 >> 1;
         int var9 = var3 >> 1;
         byte[] var10 = var4;
         byte[] var11 = new byte[var8 * var9 * var5];

         while(true) {
            OpenGL.glTexImage2Dub(var1, var6, OJI.I(this.C, this.B), var2, var3, 0, OJI.I(this.C), 5121, var10, 0);
            if (var7 <= 1) {
               return;
            }

            int var12 = var2 * var5;

            for(int var13 = 0; var13 < var5; ++var13) {
               int var14 = var13;
               int var15 = var13;
               int var16 = var13 + var12;

               for(int var17 = 0; var17 < var9; ++var17) {
                  for(int var18 = 0; var18 < var8; ++var18) {
                     byte var19 = var10[var15];
                     var15 += var5;
                     int var21 = var19 + var10[var15];
                     var15 += var5;
                     var21 += var10[var16];
                     var16 += var5;
                     var21 += var10[var16];
                     var16 += var5;
                     var11[var14] = (byte)(var21 >> 2);
                     var14 += var5;
                  }

                  var15 += var12;
                  var16 += var12;
               }
            }

            byte[] var20 = var11;
            var11 = var10;
            var10 = var20;
            var2 = var8;
            var3 = var9;
            var8 >>= 1;
            var9 >>= 1;
            var7 >>= 1;
            ++var6;
         }
      }
   }

   HS(OJI var1, int var2, YCI var3, SDI var4, int var5, boolean var6) {
      this.glTexImage2Df = EB.Z;
      this.D = var1;
      this.I = var2;
      this.C = var3;
      this.B = var4;
      this.glBindTexture = var6;
      this.glGenerateMipmapEXT = var5;
      OpenGL.glGenTextures(1, glTexParameteri, 0);
      this.Z = glTexParameteri[0];
      this.glBindTexture();
      this.glDisable(0);
   }

   public void method129(EB var1) {
      if (this.glTexImage2Df != var1) {
         this.glTexImage2Df = var1;
         this.glBindTexture();
      }

   }
}
