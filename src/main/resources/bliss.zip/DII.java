import jaggl.OpenGL;

public class DII extends RY {
   static float glDisable = 22.5F;
   static int glEnable = 12;
   static int glLoadIdentity = 36;
   DO[] glMatrixMode;
   static int glRotatef = 96;
   static char glTexGeni = 0;
   static char pow = '\u0001';
   KA sqrt;
   boolean Z;
   static int C = 64;
   boolean B = false;

   void method503(int var1, int var2) {
      if (this.B) {
         this.I.C(1);
         this.I.I((SN)this.glMatrixMode[var1 - 1]);
         this.I.C(0);
      }

   }

   void method519(SN var1, int var2) {
      this.I.I(var1);
      this.I.I(var2);
   }

   boolean method501() {
      return true;
   }

   void method505(boolean var1) {
      if (this.sqrt != null && var1) {
         if (!this.Z) {
            this.I.C(2);
            this.I.I((SN)this.I.r);
            this.I.C(0);
         }

         this.sqrt.I('\u0000');
         this.B = true;
      } else {
         this.I.C(0, 34168, 770);
      }

   }

   void method515(int var1, int var2) {
      if (this.B) {
         this.I.C(1);
         this.I.I((SN)this.glMatrixMode[var1 - 1]);
         this.I.C(0);
      }

   }

   void method504() {
      if (this.B) {
         if (!this.Z) {
            this.I.C(2);
            this.I.I((SN)null);
         }

         this.I.C(1);
         this.I.I((SN)null);
         this.I.C(0);
         this.sqrt.I('\u0001');
         this.B = false;
      } else {
         this.I.C(0, 5890, 770);
      }

      this.I.Z(8448, 8448);
   }

   void method506(boolean var1) {
      if (this.sqrt != null && var1) {
         if (!this.Z) {
            this.I.C(2);
            this.I.I((SN)this.I.r);
            this.I.C(0);
         }

         this.sqrt.I('\u0000');
         this.B = true;
      } else {
         this.I.C(0, 34168, 770);
      }

   }

   void method500(SN var1, int var2) {
      this.I.I(var1);
      this.I.I(var2);
   }

   void method514(SN var1, int var2) {
      this.I.I(var1);
      this.I.I(var2);
   }

   void method507(boolean var1) {
      if (this.sqrt != null && var1) {
         if (!this.Z) {
            this.I.C(2);
            this.I.I((SN)this.I.r);
            this.I.C(0);
         }

         this.sqrt.I('\u0000');
         this.B = true;
      } else {
         this.I.C(0, 34168, 770);
      }

   }

   void method508(boolean var1) {
      this.I.Z(8448, 7681);
   }

   void method509(boolean var1) {
      this.I.Z(8448, 7681);
   }

   void method510(boolean var1) {
      this.I.Z(8448, 7681);
   }

   void method511() {
      if (this.B) {
         if (!this.Z) {
            this.I.C(2);
            this.I.I((SN)null);
         }

         this.I.C(1);
         this.I.I((SN)null);
         this.I.C(0);
         this.sqrt.I('\u0001');
         this.B = false;
      } else {
         this.I.C(0, 5890, 770);
      }

      this.I.Z(8448, 8448);
   }

   void method512() {
      if (this.B) {
         if (!this.Z) {
            this.I.C(2);
            this.I.I((SN)null);
         }

         this.I.C(1);
         this.I.I((SN)null);
         this.I.C(0);
         this.sqrt.I('\u0001');
         this.B = false;
      } else {
         this.I.C(0, 5890, 770);
      }

      this.I.Z(8448, 8448);
   }

   DII(MJI var1) {
      super(var1);
      if (var1.SI) {
         this.Z = var1.II < 3;
         int var2 = this.Z ? 48 : 127;
         byte[][] var3 = new byte[6][4096];
         byte[][] var4 = new byte[6][4096];
         byte[][] var5 = new byte[6][4096];
         int var6 = 0;

         for(int var7 = 0; var7 < 64; ++var7) {
            for(int var8 = 0; var8 < 64; ++var8) {
               float var9 = 2.0F * (float)var8 / 64.0F - 1.0F;
               float var10 = 2.0F * (float)var7 / 64.0F - 1.0F;
               float var11 = (float)(1.0D / Math.sqrt((double)(var9 * var9 + 1.0F + var10 * var10)));
               var9 *= var11;
               var10 *= var11;

               for(int var12 = 0; var12 < 6; ++var12) {
                  float var13;
                  if (var12 == 0) {
                     var13 = -var9;
                  } else if (var12 == 1) {
                     var13 = var9;
                  } else if (var12 == 2) {
                     var13 = var10;
                  } else if (var12 == 3) {
                     var13 = -var10;
                  } else if (var12 == 4) {
                     var13 = -var11;
                  } else {
                     var13 = var11;
                  }

                  int var14;
                  int var15;
                  int var16;
                  if (var13 > 0.0F) {
                     var16 = (int)(Math.pow((double)var13, 96.0D) * (double)var2);
                     var15 = (int)(Math.pow((double)var13, 36.0D) * (double)var2);
                     var14 = (int)(Math.pow((double)var13, 12.0D) * (double)var2);
                  } else {
                     var14 = 0;
                     var15 = 0;
                     var16 = 0;
                  }

                  var4[var12][var6] = (byte)var16;
                  var5[var12][var6] = (byte)var15;
                  var3[var12][var6] = (byte)var14;
               }

               ++var6;
            }
         }

         this.glMatrixMode = new DO[3];
         this.glMatrixMode[0] = new DO(this.I, YCI.G, SDI.C, 64, false, var4, YCI.G);
         this.glMatrixMode[1] = new DO(this.I, YCI.G, SDI.C, 64, false, var5, YCI.G);
         this.glMatrixMode[2] = new DO(this.I, YCI.G, SDI.C, 64, false, var3, YCI.G);
         this.glDisable();
      }

   }

   void method513(int var1, int var2) {
      if (this.B) {
         this.I.C(1);
         this.I.I((SN)this.glMatrixMode[var1 - 1]);
         this.I.C(0);
      }

   }

   void method518(boolean var1) {
      this.I.Z(8448, 7681);
   }

   void glDisable() {
      this.sqrt = new KA(this.I, 2);
      this.sqrt.I((int)0);
      this.I.C(1);
      OpenGL.glTexGeni(8192, 9472, 34065);
      OpenGL.glTexGeni(8193, 9472, 34065);
      OpenGL.glTexGeni(8194, 9472, 34065);
      OpenGL.glEnable(3168);
      OpenGL.glEnable(3169);
      OpenGL.glEnable(3170);
      OpenGL.glMatrixMode(5890);
      OpenGL.glLoadIdentity();
      OpenGL.glRotatef(22.5F, 1.0F, 0.0F, 0.0F);
      OpenGL.glMatrixMode(5888);
      if (!this.Z) {
         this.I.Z(7681, 8448);
         this.I.I(0, 34168, 768);
         this.I.C(2);
         this.I.Z(260, 7681);
         this.I.I(0, 34168, 768);
         this.I.I(1, 34168, 770);
         this.I.C(0, 34167, 770);
      } else {
         this.I.Z(260, 7681);
         this.I.I(0, 5890, 770);
         this.I.C(0, 34167, 770);
      }

      this.I.C(0);
      this.sqrt.I();
      this.sqrt.I((int)1);
      this.I.C(1);
      OpenGL.glDisable(3168);
      OpenGL.glDisable(3169);
      OpenGL.glDisable(3170);
      OpenGL.glMatrixMode(5890);
      OpenGL.glLoadIdentity();
      OpenGL.glMatrixMode(5888);
      if (!this.Z) {
         this.I.Z(8448, 8448);
         this.I.I(0, 5890, 768);
         this.I.C(2);
         this.I.Z(8448, 8448);
         this.I.I(0, 5890, 768);
         this.I.I(1, 34168, 768);
         this.I.C(0, 5890, 770);
      } else {
         this.I.Z(8448, 8448);
         this.I.I(0, 5890, 768);
         this.I.C(0, 5890, 770);
      }

      this.I.C(0);
      this.sqrt.I();
   }

   void method517(int var1, int var2) {
      if (this.B) {
         this.I.C(1);
         this.I.I((SN)this.glMatrixMode[var1 - 1]);
         this.I.C(0);
      }

   }

   void method516(int var1, int var2) {
      if (this.B) {
         this.I.C(1);
         this.I.I((SN)this.glMatrixMode[var1 - 1]);
         this.I.C(0);
      }

   }

   void method502(int var1, int var2) {
      if (this.B) {
         this.I.C(1);
         this.I.I((SN)this.glMatrixMode[var1 - 1]);
         this.I.C(0);
      }

   }

   boolean method520() {
      return true;
   }
}
