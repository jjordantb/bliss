public class GL extends QK {
   static int[] G = new int[256];
   static double H = -1.0D;
   YG append;
   YG method170;
   YG toString;
   int[] K;
   YG[] L;
   int[] M;

   boolean I(KJ var1, FEI var2, byte var3) {
      try {
         int var4;
         if (-1132597157 * CH.R >= 0) {
            for(var4 = 0; var4 < this.M.length; ++var4) {
               if (!var1.I(-1132597157 * CH.R, this.M[var4], -416567288)) {
                  return false;
               }
            }
         } else {
            for(var4 = 0; var4 < this.M.length; ++var4) {
               if (!var1.D(this.M[var4], -457216440)) {
                  return false;
               }
            }
         }

         for(var4 = 0; var4 < this.K.length; ++var4) {
            if (!var2.method170(this.K[var4], (short)5558)) {
               return false;
            }
         }

         return true;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ail.a(" + ')');
      }
   }

   int[] I(KJ var1, FEI var2, double var3, int var5, int var6, boolean var7, int var8) {
      try {
         CH.Q = var1;
         DE.Z = var2;

         for(int var9 = 0; var9 < this.L.length; ++var9) {
            this.L[var9].Z(var5, var6, -1661668864);
         }

         BZI.I(var3);
         WJ.I(var5, var6, (byte)24);
         int[] var22 = new int[var5 * var6];
         int var10 = 0;

         int var11;
         for(var11 = 0; var11 < var6; ++var11) {
            int[] var12;
            int[] var13;
            int[] var14;
            int[] var15;
            if (this.method170.N) {
               var15 = this.method170.Z(var11, -1060810232);
               var12 = var15;
               var13 = var15;
               var14 = var15;
            } else {
               int[][] var23 = this.method170.I(var11, (byte)-23);
               var12 = var23[0];
               var13 = var23[1];
               var14 = var23[2];
            }

            if (this.append.N) {
               var15 = this.append.Z(var11, 991664315);
            } else {
               var15 = this.append.I(var11, (byte)-109)[0];
            }

            if (var7) {
               var10 = var11;
            }

            for(int var16 = var5 - 1; var16 >= 0; --var16) {
               int var17 = var12[var16] >> 4;
               if (var17 > 255) {
                  var17 = 255;
               }

               if (var17 < 0) {
                  var17 = 0;
               }

               int var18 = var13[var16] >> 4;
               if (var18 > 255) {
                  var18 = 255;
               }

               if (var18 < 0) {
                  var18 = 0;
               }

               int var19 = var14[var16] >> 4;
               if (var19 > 255) {
                  var19 = 255;
               }

               if (var19 < 0) {
                  var19 = 0;
               }

               var17 = G[var17];
               var18 = G[var18];
               var19 = G[var19];
               int var20;
               if (var17 == 0 && var18 == 0 && var19 == 0) {
                  var20 = 0;
               } else {
                  var20 = var15[var16] >> 4;
                  if (var20 > 255) {
                     var20 = 255;
                  }

                  if (var20 < 0) {
                     var20 = 0;
                  }
               }

               var22[var10++] = (var20 << 24) + (var17 << 16) + (var18 << 8) + var19;
               if (var7) {
                  var10 += var5 - 1;
               }
            }
         }

         for(var11 = 0; var11 < this.L.length; ++var11) {
            this.L[var11].C(1881168514);
         }

         return var22;
      } catch (RuntimeException var21) {
         throw DQ.I(var21, "ail.b(" + ')');
      }
   }

   float[] I(KJ var1, FEI var2, int var3, int var4, boolean var5, int var6) {
      try {
         CH.Q = var1;
         DE.Z = var2;

         for(int var7 = 0; var7 < this.L.length; ++var7) {
            this.L[var7].Z(var3, var4, -1661668864);
         }

         WJ.I(var3, var4, (byte)24);
         float[] var19 = new float[var3 * var4 * 4];
         int var8 = 0;

         int var9;
         for(var9 = 0; var9 < var4; ++var9) {
            int[] var10;
            int[] var11;
            int[] var12;
            int[] var13;
            if (this.method170.N) {
               var13 = this.method170.Z(var9, 376891989);
               var10 = var13;
               var11 = var13;
               var12 = var13;
            } else {
               int[][] var20 = this.method170.I(var9, (byte)-81);
               var10 = var20[0];
               var11 = var20[1];
               var12 = var20[2];
            }

            if (this.append.N) {
               var13 = this.append.Z(var9, 1373971312);
            } else {
               var13 = this.append.I(var9, (byte)-16)[0];
            }

            int[] var14;
            if (this.toString.N) {
               var14 = this.toString.Z(var9, -306931016);
            } else {
               var14 = this.toString.I(var9, (byte)-17)[0];
            }

            if (var5) {
               var8 = var9 << 2;
            }

            for(int var15 = var3 - 1; var15 >= 0; --var15) {
               float var16 = (float)var13[var15] / 4096.0F;
               float var17 = ((float)var14[var15] * 31.0F / 4096.0F + 1.0F) / 4096.0F;
               if (var16 < 0.0F) {
                  var16 = 0.0F;
               } else if (var16 > 1.0F) {
                  var16 = 1.0F;
               }

               var19[var8++] = var17 * (float)var10[var15];
               var19[var8++] = (float)var11[var15] * var17;
               var19[var8++] = var17 * (float)var12[var15];
               var19[var8++] = var16;
               if (var5) {
                  var8 += (var3 << 2) - 4;
               }
            }
         }

         for(var9 = 0; var9 < this.L.length; ++var9) {
            this.L[var9].C(1881168514);
         }

         return var19;
      } catch (RuntimeException var18) {
         throw DQ.I(var18, "ail.p(" + ')');
      }
   }

   GL(REI var1) {
      int var2 = var1.I();
      int var3 = 0;
      int var4 = 0;
      int[][] var5 = new int[var2][];
      this.L = new YG[var2];

      int var6;
      YG var7;
      int var8;
      int var9;
      for(var6 = 0; var6 < var2; ++var6) {
         var7 = JSI.Z(var1, -1133567452);
         if (var7.I((short)-979) >= 0) {
            ++var3;
         }

         if (var7.I((byte)13) >= 0) {
            ++var4;
         }

         var8 = var7.J.length;
         var5[var6] = new int[var8];

         for(var9 = 0; var9 < var8; ++var9) {
            var5[var6][var9] = var1.I();
         }

         this.L[var6] = var7;
      }

      this.M = new int[var3];
      var3 = 0;
      this.K = new int[var4];
      var4 = 0;

      for(var6 = 0; var6 < var2; ++var6) {
         var7 = this.L[var6];
         var8 = var7.J.length;

         for(var9 = 0; var9 < var8; ++var9) {
            var7.J[var9] = this.L[var5[var6][var9]];
         }

         var9 = var7.I((short)-3617);
         int var10 = var7.I((byte)1);
         if (var9 > 0) {
            this.M[var3++] = var9;
         }

         if (var10 > 0) {
            this.K[var4++] = var10;
         }

         var5[var6] = null;
      }

      this.method170 = this.L[var1.I()];
      this.append = this.L[var1.I()];
      this.toString = this.L[var1.I()];
      Object var11 = null;
   }

   int[] I(KJ var1, FEI var2, double var3, int var5, int var6, boolean var7, boolean var8, int var9) {
      try {
         CH.Q = var1;
         DE.Z = var2;

         for(int var10 = 0; var10 < this.L.length; ++var10) {
            this.L[var10].Z(var5, var6, -1661668864);
         }

         BZI.I(var3);
         WJ.I(var5, var6, (byte)24);
         int[] var25 = new int[var5 * var6];
         int var11;
         int var12;
         byte var13;
         if (var7) {
            var11 = var5 - 1;
            var12 = -1;
            var13 = -1;
         } else {
            var11 = 0;
            var12 = var5;
            var13 = 1;
         }

         int var14 = 0;

         int var15;
         for(var15 = 0; var15 < var6; ++var15) {
            int[] var16;
            int[] var17;
            int[] var18;
            if (this.method170.N) {
               int[] var19 = this.method170.Z(var15, 1662825531);
               var16 = var19;
               var17 = var19;
               var18 = var19;
            } else {
               int[][] var26 = this.method170.I(var15, (byte)-95);
               var16 = var26[0];
               var17 = var26[1];
               var18 = var26[2];
            }

            if (var8) {
               var14 = var15;
            }

            for(int var27 = var11; var12 != var27; var27 += var13) {
               int var20 = var16[var27] >> 4;
               if (var20 > 255) {
                  var20 = 255;
               }

               if (var20 < 0) {
                  var20 = 0;
               }

               int var21 = var17[var27] >> 4;
               if (var21 > 255) {
                  var21 = 255;
               }

               if (var21 < 0) {
                  var21 = 0;
               }

               int var22 = var18[var27] >> 4;
               if (var22 > 255) {
                  var22 = 255;
               }

               if (var22 < 0) {
                  var22 = 0;
               }

               var20 = G[var20];
               var21 = G[var21];
               var22 = G[var22];
               int var23 = var22 + (var20 << 16) + (var21 << 8);
               if (var23 != 0) {
                  var23 |= -16777216;
               }

               var25[var14++] = var23;
               if (var8) {
                  var14 += var5 - 1;
               }
            }
         }

         for(var15 = 0; var15 < this.L.length; ++var15) {
            this.L[var15].C(1881168514);
         }

         return var25;
      } catch (RuntimeException var24) {
         throw DQ.I(var24, "ail.f(" + ')');
      }
   }
}
