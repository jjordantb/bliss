import java.util.ArrayList;
import java.util.Iterator;

public class EN {
   public static WK I;
   static XX B;
   protected static CX Z;
   protected static int C;
   static byte[] G;
   protected static FAI D;
   static byte[] S;
   protected static RII F;
   static JX XA = new JX(16);
   protected static int J = (int)(Math.random() * 11.0D) - 5;
   protected static int A = (int)(Math.random() * 17.0D) - 8;
   protected static byte[][][] E;
   protected static int H;
   static int[] add = new int[1];
   static byte[] hasNext = new byte[1];
   public static float K;
   public static float L;
   protected static JE M;
   protected static IY N = new IY();
   static int[] intValue;
   public static int O;
   protected static int P;
   protected static int Q;
   protected static int R;
   protected static int T;
   static byte[] iterator;
   static short[] method174;
   public static int U;
   static byte[] method271;
   static Object[] method5039;
   protected static KJ V;
   static ArrayList[][][] method626;
   static byte[] next;
   protected static UP W;
   protected static int X;
   static ET random;
   protected static int Y;
   protected static int i;
   protected static int z;
   protected static int c;

   static void B(GSI var0, int var1, int var2, int var3, int var4) {
      int var5 = X - H;
      int var6 = R - T;
      if (X < P) {
         ++var5;
      }

      if (R < Q) {
         ++var6;
      }

      int var7;
      int var8;
      int var9;
      int var10;
      int var11;
      int var12;
      int var13;
      int var14;
      int var15;
      int var16;
      int var19;
      for(var7 = 0; var7 < var5; ++var7) {
         var8 = (var3 + var1 * var7 >> 16) + C;
         var9 = (var3 + var1 * (var7 + 1) >> 16) + C;
         var10 = var9 - var8;
         if (var10 > 0) {
            var11 = H + var7;
            if (var11 >= 0 && var11 < P) {
               for(var12 = 0; var12 < var6; ++var12) {
                  var13 = c - (var4 + var2 * (var12 + 1) >> 16);
                  var14 = c - (var4 + var2 * var12 >> 16);
                  var15 = var14 - var13;
                  if (var15 > 0) {
                     var16 = var12 + T;
                     int var17 = var11 + var16 * P;
                     int var18 = 0;
                     var19 = 0;
                     Object var20 = null;
                     if (var16 >= 0 && var16 < Q) {
                        var18 = (iterator[var17] & 255) << 16 | method174[var17] & '\uffff';
                        if (var18 != 0) {
                           var18 |= -16777216;
                        }

                        var19 = G[var17] & 255;
                        var20 = method5039[var17];
                     }

                     if (var18 == 0 && var19 == 0 && var20 == null) {
                        if (I.G * -717907215 != -1) {
                           var18 = -16777216 | I.G * -717907215;
                        } else if ((var7 + H & 4) != (var12 + R & 4)) {
                           var18 = -11840664;
                        } else {
                           var18 = intValue[random.I * 1086398247 + 1];
                        }

                        if (var18 == 0) {
                           var18 = -16777216;
                        }

                        var0.B(var8, var13, var10, var15, var18, 0);
                     } else if (var20 != null) {
                        if (var20 instanceof YM) {
                           YM var21 = (YM)var20;
                           if (var21 != null) {
                              Z(var0, var8, var13, var10, var15, var18, var19, method271[var17], var21.S, var21.J, true);
                           }
                        } else {
                           Integer var28 = (Integer)var20;
                           add[0] = var28.intValue();
                           hasNext[0] = next[var17];
                           Z(var0, var8, var13, var10, var15, var18, var19, method271[var17], add, hasNext, true);
                        }
                     } else {
                        Z(var0, var8, var13, var10, var15, var18, var19, method271[var17], (int[])null, (byte[])null, true);
                     }
                  }
               }
            } else {
               for(var12 = 0; var12 < var6; ++var12) {
                  var13 = c - (var4 + var2 * (var12 + 1) >> 16);
                  var14 = c - (var4 + var2 * var12 >> 16);
                  var15 = var14 - var13;
                  if (I.G * -717907215 != -1) {
                     var16 = -16777216 | I.G * -717907215;
                  } else if ((var7 + H & 4) != (var12 + R & 4)) {
                     var16 = -11840664;
                  } else {
                     var16 = intValue[random.I * 1086398247 + 1];
                  }

                  if (var16 == 0) {
                     var16 = -16777216;
                  }

                  var0.B(var8, var13, var10, var15, var16, 0);
               }
            }
         }
      }

      for(var7 = -16; var7 < var5 + 16; ++var7) {
         var8 = (var3 + var1 * var7 >> 16) + C;
         var9 = (var3 + var1 * (var7 + 1) >> 16) + C;
         var10 = var9 - var8;
         if (var10 > 0) {
            var11 = var7 + H;
            if (var11 >= 0 && var11 < P) {
               for(var12 = -16; var12 < var6 + 16; ++var12) {
                  var13 = c - (var4 + var2 * (var12 + 1) >> 16);
                  var14 = c - (var4 + var2 * var12 >> 16);
                  var15 = var14 - var13;
                  if (var15 > 0) {
                     var16 = var12 + T;
                     if (var16 >= 0 && var16 < Q) {
                        Object var26 = method5039[var11 + var16 * P];
                        if (var26 != null) {
                           if (var26 instanceof YM) {
                              YM var29 = (YM)var26;
                              if (var29 != null) {
                                 add(var0, var8, var13, var10, var15, var29.S, var29.J);
                              }
                           } else {
                              Integer var31 = (Integer)var26;
                              add[0] = var31.intValue();
                              hasNext[0] = next[var11 + var16 * P];
                              add(var0, var8, var13, var10, var15, add, hasNext);
                           }
                        } else {
                           add(var0, var8, var13, var10, var15, (int[])null, (byte[])null);
                        }
                     }
                  }
               }
            }
         }
      }

      var7 = H >> 6;
      var8 = T >> 6;
      if (var7 < 0) {
         var7 = 0;
      }

      if (var8 < 0) {
         var8 = 0;
      }

      var9 = X >> 6;
      var10 = R >> 6;
      if (var9 >= method626[0].length) {
         var9 = method626[0].length - 1;
      }

      if (var10 >= method626[0][0].length) {
         var10 = method626[0][0].length - 1;
      }

      for(var11 = 0; var11 < 3; ++var11) {
         int var22;
         int var23;
         int var24;
         ArrayList var25;
         Iterator var27;
         int var30;
         int var32;
         KO var33;
         for(var12 = var7; var12 <= var9; ++var12) {
            for(var13 = var8; var13 <= var10; ++var13) {
               var25 = method626[var11][var12][var13];
               if (var25 != null) {
                  var15 = (var12 + (U >> 6)) * 64;
                  var16 = (var13 + (O >> 6)) * 64;
                  var27 = var25.iterator();

                  while(var27.hasNext()) {
                     var33 = (KO)var27.next();
                     var19 = var15 + var33.D - U - H;
                     var30 = var16 + var33.F - O - T;
                     var32 = (var3 + var1 * var19 >> 16) + C;
                     var22 = (var3 + var1 * (var19 + 1) >> 16) + C;
                     var23 = c - (var4 + var2 * (var30 + 1) >> 16);
                     var24 = c - (var4 + var2 * var30 >> 16);
                     Z(var0, var32, var23, var22 - var32, var24 - var23, var33.C, var33.B & 255, var33.J, var33.I, var33.Z, false);
                  }
               }
            }
         }

         for(var12 = var7; var12 <= var9; ++var12) {
            for(var13 = var8; var13 <= var10; ++var13) {
               var25 = method626[var11][var12][var13];
               if (var25 != null) {
                  var15 = (var12 + (U >> 6)) * 64;
                  var16 = (var13 + (O >> 6)) * 64;
                  var27 = var25.iterator();

                  while(var27.hasNext()) {
                     var33 = (KO)var27.next();
                     var19 = var15 + var33.D - U - H;
                     var30 = var16 + var33.F - O - T;
                     var32 = (var3 + var1 * var19 >> 16) + C;
                     var22 = (var3 + var1 * (var19 + 1) >> 16) + C;
                     var23 = c - (var4 + var2 * (var30 + 1) >> 16);
                     var24 = c - (var4 + var2 * var30 >> 16);
                     add(var0, var32, var23, var22 - var32, var24 - var23, var33.I, var33.Z);
                  }
               }
            }
         }
      }

   }

   public static void I(KJ var0, ET var1, XX var2, CX var3, UP var4, RII var5, FAI var6) {
      V = var0;
      random = var1;
      B = var2;
      Z = var3;
      W = var4;
      F = var5;
      D = var6;
      XA.I((byte)-118);
      int var7 = V.B("details", -1750560538);
      int[] var8 = V.B(var7, -1923714721);
      if (var8 != null) {
         for(int var9 = 0; var9 < var8.length; ++var9) {
            WK var10 = OY.I(V, var7, var8[var9], 1783056581);
            XA.I(var10, (long)(var10.M * -947282109));
         }
      }

      ST.I(true, false, -162450455);
   }

   static void I() {
      S = null;
      iterator = null;
      method174 = null;
      G = null;
      method271 = null;
      method5039 = null;
      next = null;
      method626 = null;
      intValue = null;
   }

   static void I(int var0) {
      I = (WK)XA.I((long)var0);
   }

   public static EY I(int var0, int var1) {
      EY var2 = new EY();

      for(WK var3 = (WK)XA.C(1759050770); var3 != null; var3 = (WK)XA.Z((byte)-2)) {
         if (var3.R && var3.I(var0, var1, (byte)1)) {
            var2.I(var3, (byte)-123);
         }
      }

      return var2;
   }

   static int G(FEI var0, int var1, int var2, int var3) {
      FT var4 = random.I(var1, -165601895);
      if (var4 == null) {
         return 0;
      } else {
         int var5 = var4.D * 324071475;
         if (var5 >= 0 && var0.method174(var5, 1570476781).B) {
            var5 = -1;
         }

         int var6;
         int var7;
         int var8;
         int var9;
         if (var4.F * 1728947183 >= 0) {
            var7 = var4.F * 1728947183;
            var8 = (var7 & 127) + var3;
            if (var8 < 0) {
               var8 = 0;
            } else if (var8 > 127) {
               var8 = 127;
            }

            var9 = (var7 + var2 & 'ﰀ') + (var7 & 896) + var8;
            var6 = -16777216 | LT.Z[BB.I(IQ.I(var9, 96, (byte)86), (byte)0) & '\uffff'];
         } else if (var5 >= 0) {
            var6 = -16777216 | LT.Z[BB.I(IQ.I(var0.method174(var5, 201088475).A, 96, (byte)61), (byte)0) & '\uffff'];
         } else if (var4.B * -45966925 == -1) {
            var6 = 0;
         } else {
            var7 = var4.B * -45966925;
            var8 = (var7 & 127) + var3;
            if (var8 < 0) {
               var8 = 0;
            } else if (var8 > 127) {
               var8 = 127;
            }

            var9 = (var7 + var2 & 'ﰀ') + (var7 & 896) + var8;
            var6 = -16777216 | LT.Z[BB.I(IQ.I(var9, 96, (byte)22), (byte)0) & '\uffff'];
         }

         return var6;
      }
   }

   static void S(GSI var0, REI var1, int var2, int var3, int var4, int var5, int[] var6, int[] var7) {
      int var8 = var1.I();
      if ((var8 & 1) == 0) {
         boolean var9 = (var8 & 2) == 0;
         int var10 = var8 >> 2 & 63;
         if (var10 != 62) {
            if (var10 == 63) {
               var10 = var1.I();
            } else if (var9) {
               var10 = var6[var10];
            } else {
               var10 = var7[var10];
            }

            if (var9) {
               S[var4 + var5 * P] = (byte)var10;
               G[var4 + var5 * P] = 0;
            } else {
               G[var4 + var5 * P] = (byte)var10;
               method271[var4 + var5 * P] = 0;
               S[var4 + var5 * P] = var1.S(-12558881);
            }
         }
      } else {
         int var20 = (var8 >> 1 & 3) + 1;
         boolean var21 = (var8 & 8) != 0;
         boolean var11 = (var8 & 16) != 0;

         for(int var12 = 0; var12 < var20; ++var12) {
            int var13 = var1.I();
            int var14 = 0;
            int var15 = 0;
            if (var21) {
               var14 = var1.I();
               var15 = var1.I();
            }

            int var16 = 0;
            if (var11) {
               var16 = var1.I();
            }

            int[] var17;
            byte[] var18;
            int var19;
            if (var12 == 0) {
               S[var4 + var5 * P] = (byte)var13;
               G[var4 + var5 * P] = (byte)var14;
               method271[var4 + var5 * P] = (byte)var15;
               if (var16 == 1) {
                  method5039[var4 + var5 * P] = new Integer(var1.Y(1235052657));
                  next[var4 + var5 * P] = var1.S(-12558881);
               } else if (var16 > 1) {
                  var17 = new int[var16];
                  var18 = new byte[var16];

                  for(var19 = 0; var19 < var16; ++var19) {
                     var17[var19] = var1.Y(1235052657);
                     var18[var19] = var1.S(-12558881);
                  }

                  method5039[var4 + var5 * P] = new YM(var17, var18);
               }
            } else {
               var17 = null;
               var18 = null;
               if (var16 > 0) {
                  var17 = new int[var16];
                  var18 = new byte[var16];

                  for(var19 = 0; var19 < var16; ++var19) {
                     var17[var19] = var1.Y(1235052657);
                     var18[var19] = var1.S(-12558881);
                  }
               }

               if (method626[var12 - 1][var2 - (U >> 6)][var3 - (O >> 6)] == null) {
                  method626[var12 - 1][var2 - (U >> 6)][var3 - (O >> 6)] = new ArrayList();
               }

               KO var22 = new KO(var4 & 63, var5 & 63, var13, var14, var15, var17, var18);
               method626[var12 - 1][var2 - (U >> 6)][var3 - (O >> 6)].add(var22);
            }
         }
      }

   }

   EN() throws Throwable {
      throw new Error();
   }

   static void XA(byte[] var0, byte[] var1, short[] var2, int var3, int var4) {
      int[] var5 = new int[Q];
      int[] var6 = new int[Q];
      int[] var7 = new int[Q];
      int[] var8 = new int[Q];
      int[] var9 = new int[Q];

      for(int var10 = -5; var10 < P; ++var10) {
         int var11 = var10 + 5;
         int var12 = var10 - 5;

         int var13;
         int var14;
         for(var13 = 0; var13 < Q; ++var13) {
            OX var15;
            if (var11 < P) {
               var14 = var0[var11 + var13 * P] & 255;
               if (var14 > 0) {
                  var15 = B.I(var14 - 1, (byte)-1);
                  var5[var13] += var15.D * 838046775;
                  var6[var13] += var15.Z * -620399085;
                  var7[var13] += var15.S * 656695887;
                  var8[var13] += var15.A * -813159285;
                  ++var9[var13];
               }
            }

            if (var12 >= 0) {
               var14 = var0[var12 + var13 * P] & 255;
               if (var14 > 0) {
                  var15 = B.I(var14 - 1, (byte)-1);
                  var5[var13] -= var15.D * 838046775;
                  var6[var13] -= var15.Z * -620399085;
                  var7[var13] -= var15.S * 656695887;
                  var8[var13] -= var15.A * -813159285;
                  --var9[var13];
               }
            }
         }

         if (var10 >= 0) {
            var13 = 0;
            var14 = 0;
            int var26 = 0;
            int var16 = 0;
            int var17 = 0;

            for(int var18 = -5; var18 < Q; ++var18) {
               int var19 = var18 + 5;
               if (var19 < Q) {
                  var13 += var5[var19];
                  var14 += var6[var19];
                  var26 += var7[var19];
                  var16 += var8[var19];
                  var17 += var9[var19];
               }

               int var20 = var18 - 5;
               if (var20 >= 0) {
                  var13 -= var5[var20];
                  var14 -= var6[var20];
                  var26 -= var7[var20];
                  var16 -= var8[var20];
                  var17 -= var9[var20];
               }

               if (var18 >= 0 && var17 > 0) {
                  int var21;
                  if ((var0[var10 + var18 * P] & 255) == 0) {
                     var21 = var10 + var18 * P;
                     var1[var21] = 0;
                     var2[var21] = 0;
                  } else {
                     var21 = var16 == 0 ? 0 : AEI.I(var13 * 256 / var16, var14 / var17, var26 / var17, -235005806);
                     int var22 = (var21 & 127) + var4;
                     if (var22 < 0) {
                        var22 = 0;
                     } else if (var22 > 127) {
                        var22 = 127;
                     }

                     int var23 = (var21 + var3 & 'ﰀ') + (var21 & 896) + var22;
                     int var24 = var10 + var18 * P;
                     int var25 = LT.Z[BB.I(IE.I(var23, 96, 1291456097), (byte)0) & '\uffff'];
                     var1[var24] = (byte)(var25 >> 16 & 255);
                     var2[var24] = (short)(var25 & '\uffff');
                  }
               }
            }
         }
      }

   }

   static void Z() {
      int[] var0 = new int[3];

      for(int var1 = 0; var1 < M.Z * -1407078377; ++var1) {
         boolean var2 = I.I(M.I[var1] >> 28 & 3, M.I[var1] >> 14 & 16383, M.I[var1] & 16383, var0, 1112796822);
         if (var2) {
            XM var3 = new XM(M.C[var1]);
            var3.A = (var0[1] - U) * 898378357;
            var3.H = (var0[2] - O) * -1686044477;
            N.I((AE)var3, (int)1249081090);
         }
      }

   }

   static void I(GSI var0) {
      int var1 = X - H;
      int var2 = R - T;
      int var3 = (z - C << 16) / var1;
      int var4 = (c - i << 16) / var2;
      B(var0, var3, var4, 0, 0);
   }

   static void I(GSI var0, int var1, int var2) {
      REI var3 = new REI(V.I(I.H, "area", -1304297711));
      int var4 = var3.I();
      int[] var5 = new int[var4];

      int var6;
      for(var6 = 0; var6 < var4; ++var6) {
         var5[var6] = var3.I();
      }

      var6 = var3.I();
      int[] var7 = new int[var6];

      int var8;
      for(var8 = 0; var8 < var6; ++var8) {
         var7[var8] = var3.I();
      }

      while(true) {
         int var9;
         int var11;
         int var12;
         while(var3.A * 385051775 < var3.S.length) {
            int var10;
            int var13;
            if (var3.I() == 0) {
               var8 = var3.I();
               var9 = var3.I();

               for(var10 = 0; var10 < 64; ++var10) {
                  for(var11 = 0; var11 < 64; ++var11) {
                     var12 = var8 * 64 + var10 - U;
                     var13 = var9 * 64 + var11 - O;
                     S(var0, var3, var8, var9, var12, var13, var5, var7);
                  }
               }
            } else {
               var8 = var3.I();
               var9 = var3.I();
               var10 = var3.I();
               var11 = var3.I();

               for(var12 = 0; var12 < 8; ++var12) {
                  for(var13 = 0; var13 < 8; ++var13) {
                     int var14 = var8 * 64 + var10 * 8 + var12 - U;
                     int var15 = var9 * 64 + var11 * 8 + var13 - O;
                     S(var0, var3, var8, var9, var14, var15, var5, var7);
                  }
               }
            }
         }

         Object var17 = null;
         iterator = new byte[P * Q];
         method174 = new short[P * Q];

         for(var9 = 0; var9 < 3; ++var9) {
            byte[] var18 = new byte[P * Q];

            ArrayList var19;
            Iterator var20;
            KO var21;
            for(var11 = 0; var11 < method626[var9].length; ++var11) {
               for(var12 = 0; var12 < method626[var9][0].length; ++var12) {
                  var19 = method626[var9][var11][var12];
                  if (var19 != null) {
                     for(var20 = var19.iterator(); var20.hasNext(); var18[var11 * 64 + var21.D + (var12 * 64 + var21.F) * P] = (byte)var21.C) {
                        var21 = (KO)var20.next();
                     }
                  }
               }
            }

            XA(var18, iterator, method174, var1, var2);

            for(var11 = 0; var11 < method626[var9].length; ++var11) {
               for(var12 = 0; var12 < method626[var9][0].length; ++var12) {
                  var19 = method626[var9][var11][var12];
                  if (var19 != null) {
                     var20 = var19.iterator();

                     while(var20.hasNext()) {
                        var21 = (KO)var20.next();
                        int var16 = var11 * 64 + var21.D + (var12 * 64 + var21.F) * P;
                        var21.C = (iterator[var16] & 255) << 16 | method174[var16] & '\uffff';
                        if (var21.C != 0) {
                           var21.C |= -16777216;
                        }
                     }
                  }
               }
            }
         }

         XA(S, iterator, method174, var1, var2);
         S = null;
         iterator();
         return;
      }
   }

   static void Z(GSI var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7, int[] var8, byte[] var9, boolean var10) {
      int var11;
      int var12;
      if (var10 || var5 != 0 || var6 > 0) {
         if (var6 == 0) {
            var0.B(var1, var2, var3, var4, var5, 0);
         } else {
            var11 = var7 & 63;
            if (var11 != 0 && var3 > 1 && var4 > 1) {
               var12 = var10 ? 0 : 1;
               YJ.I(var0, E, Y, var1, var2, var5, intValue[var6], var3, var4, var11, var7 >> 6 & 3, var12, (byte)127);
            } else {
               var12 = intValue[var6];
               if (var10 || var12 != 0) {
                  var0.B(var1, var2, var3, var4, var12, 0);
               }
            }
         }
      }

      if (var8 != null) {
         if (var3 == 1) {
            var11 = var1;
         } else {
            var11 = var1 + var3 - 1;
         }

         if (var4 == 1) {
            var12 = var2;
         } else {
            var12 = var2 + var4 - 1;
         }

         for(int var13 = 0; var13 < var8.length; ++var13) {
            int var14 = var9[var13] & 63;
            if (var14 == RW.W.V * -1976050083 || var14 == RW.C.V * -1976050083 || var14 == RW.B.V * -1976050083 || var14 == RW.D.V * -1976050083) {
               KEI var15 = Z.C(var8[var13]);
               if (var15.b * -1204256389 == -1) {
                  int var16 = -3355444;
                  if (var15.K * 1532834983 == 1) {
                     var16 = -3407872;
                  }

                  int var17 = var9[var13] >> 6 & 3;
                  if (var14 == RW.W.V * -1976050083) {
                     if (var17 == 0) {
                        var0.G(var1, var2, var4, var16, 0);
                     } else if (var17 == 1) {
                        var0.XA(var1, var2, var3, var16, 0);
                     } else if (var17 == 2) {
                        var0.G(var11, var2, var4, var16, 0);
                     } else {
                        var0.XA(var1, var12, var3, var16, 0);
                     }
                  } else if (var14 == RW.C.V * -1976050083) {
                     if (var17 == 0) {
                        var0.G(var1, var2, var4, -1, 0);
                        var0.XA(var1, var2, var3, var16, 0);
                     } else if (var17 == 1) {
                        var0.G(var11, var2, var4, -1, 0);
                        var0.XA(var1, var2, var3, var16, 0);
                     } else if (var17 == 2) {
                        var0.G(var11, var2, var4, -1, 0);
                        var0.XA(var1, var12, var3, var16, 0);
                     } else {
                        var0.G(var1, var2, var4, -1, 0);
                        var0.XA(var1, var12, var3, var16, 0);
                     }
                  } else if (var14 == RW.B.V * -1976050083) {
                     if (var17 == 0) {
                        var0.XA(var1, var2, 1, var16, 0);
                     } else if (var17 == 1) {
                        var0.XA(var11, var2, 1, var16, 0);
                     } else if (var17 == 2) {
                        var0.XA(var11, var12, 1, var16, 0);
                     } else {
                        var0.XA(var1, var12, 1, var16, 0);
                     }
                  } else if (var14 == RW.D.V * -1976050083) {
                     int var18;
                     if (var17 != 0 && var17 != 2) {
                        for(var18 = 0; var18 < var4; ++var18) {
                           var0.XA(var1 + var18, var2 + var18, 1, var16, 0);
                        }
                     } else {
                        for(var18 = 0; var18 < var4; ++var18) {
                           var0.XA(var1 + var18, var12 - var18, 1, var16, 0);
                        }
                     }
                  }
               }
            }
         }
      }

   }

   static void add(GSI var0, int var1, int var2, int var3, int var4, int[] var5, byte[] var6) {
      if (var5 != null) {
         for(int var7 = 0; var7 < var5.length; ++var7) {
            KEI var8 = Z.C(var5[var7]);
            int var9 = var8.b * -1204256389;
            if (var9 != -1) {
               BZI var10 = F.I(var9, -2130050645);
               IBI var11 = var10.I(var0, var8.d ? var6[var7] >> 6 & 3 : 0, var8.EI ? var8.a : false, (byte)-47);
               if (var11 != null) {
                  int var12 = var3 * var11.method271() >> 2;
                  int var13 = var4 * var11.method626() >> 2;
                  if (var10.B) {
                     int var14 = var8.N * -1125834887;
                     int var15 = var8.L * -565161399;
                     if ((var6[var7] >> 6 & 1) == 1) {
                        int var16 = var14;
                        var14 = var15;
                        var15 = var16;
                     }

                     var12 = var14 * var3;
                     var13 = var15 * var4;
                  }

                  if (var12 != 0 && var13 != 0) {
                     if (var10.Z * -2012904123 != 0) {
                        var11.I(var1, var2 - var13 + var4, var12, var13, 0, -16777216 | var10.Z * -2012904123, 1);
                     } else {
                        var11.I(var1, var2 - var13 + var4, var12, var13);
                     }
                  }
               }
            }
         }
      }

   }

   static IY Z(GSI var0) {
      int var1 = X - H;
      int var2 = R - T;
      int var3 = (z - C << 16) / var1;
      int var4 = (c - i << 16) / var2;
      return hasNext(var0, var3, var4, 0, 0);
   }

   static IY hasNext(GSI var0, int var1, int var2, int var3, int var4) {
      for(XM var5 = (XM)N.Z(1766612795); var5 != null; var5 = (XM)N.B(49146)) {
         intValue(var0, var5, var1, var2, var3, var4);
      }

      return N;
   }

   static void intValue(GSI var0, XM var1, int var2, int var3, int var4, int var5) {
      var1.G = (C + (var4 + var2 * (var1.A * 2122110429 - H) >> 16)) * -1722635483;
      var1.S = (c - (var5 + var3 * (var1.H * -372920341 - T) >> 16)) * -283355805;
   }

   public static WK Z(int var0) {
      return (WK)XA.I((long)var0);
   }

   static void C() {
      S = new byte[P * Q];
      G = new byte[P * Q];
      method271 = new byte[P * Q];
      method5039 = new Object[P * Q];
      next = new byte[P * Q];
      method626 = new ArrayList[3][P >> 6][Q >> 6];
      intValue = new int[random.Z * 138682397 + 1];
   }

   static void I(FEI var0, int var1, int var2) {
      for(int var3 = 0; var3 < random.Z * 138682397; ++var3) {
         intValue[var3 + 1] = G(var0, var3, var1, var2);
      }

   }

   public static WK Z(int var0, int var1) {
      for(WK var2 = (WK)XA.C(1588897265); var2 != null; var2 = (WK)XA.Z((byte)-24)) {
         if (var2.R && var2.I(var0, var1, (byte)-105)) {
            return var2;
         }
      }

      return null;
   }

   static void I(int var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      H = var0 - U;
      R = var1 - O;
      X = var2 - U;
      T = var3 - O;
      C = var4;
      i = var5;
      z = var6;
      c = var7;
   }

   static void iterator() {
      int var0;
      int var1;
      int var16;
      for(var0 = 0; var0 < P; ++var0) {
         for(var1 = 0; var1 < Q; ++var1) {
            Object var2 = method5039[var0 + var1 * P];
            if (var2 != null) {
               if (var2 instanceof YM) {
                  YM var11 = (YM)var2;
                  if (var11 != null) {
                     for(int var13 = 0; var13 < var11.S.length; ++var13) {
                        KEI var15 = Z.C(var11.S[var13]);
                        var16 = var15.z * -1422593103;
                        if (var15.C != null) {
                           var15 = var15.I(D, 2117091255);
                           if (var15 != null) {
                              var16 = var15.z * -1422593103;
                           }
                        }

                        if (var16 != -1) {
                           XM var7 = new XM(var16);
                           var7.A = var0 * 898378357;
                           var7.H = var1 * -1686044477;
                           N.I((AE)var7, (int)2035193574);
                        }
                     }
                  }
               } else {
                  Integer var3 = (Integer)var2;
                  KEI var4 = Z.C(var3.intValue());
                  int var5 = var4.z * -1422593103;
                  if (var4.C != null) {
                     var4 = var4.I(D, 1079072044);
                     if (var4 != null) {
                        var5 = var4.z * -1422593103;
                     }
                  }

                  if (var5 != -1) {
                     XM var6 = new XM(var5);
                     var6.A = var0 * 898378357;
                     var6.H = var1 * -1686044477;
                     N.I((AE)var6, (int)1393789862);
                  }
               }
            }
         }
      }

      for(var0 = 0; var0 < 3; ++var0) {
         for(var1 = 0; var1 < method626[0].length; ++var1) {
            label88:
            for(int var10 = 0; var10 < method626[0][0].length; ++var10) {
               ArrayList var12 = method626[var0][var1][var10];
               if (var12 != null) {
                  Iterator var14 = var12.iterator();

                  while(true) {
                     KO var17;
                     do {
                        if (!var14.hasNext()) {
                           continue label88;
                        }

                        var17 = (KO)var14.next();
                     } while(var17.I == null);

                     for(var16 = 0; var16 < var17.I.length; ++var16) {
                        KEI var18 = Z.C(var17.I[var16]);
                        int var8 = var18.z * -1422593103;
                        if (var18.C != null) {
                           var18 = var18.I(D, 984911486);
                           if (var18 != null) {
                              var8 = var18.z * -1422593103;
                           }
                        }

                        if (var8 != -1) {
                           XM var9 = new XM(var8);
                           var9.A = ((var1 + (U >> 6)) * 64 + var17.D - U) * 898378357;
                           var9.H = ((var10 + (O >> 6)) * 64 + var17.F - O) * -1686044477;
                           N.I((AE)var9, (int)1574718042);
                        }
                     }
                  }
               }
            }
         }
      }

   }

   static void I(GSI var0, XM var1, HQ var2) {
      if (var2.U != null) {
         int[] var3 = new int[var2.U.length];

         int var4;
         int var5;
         int var6;
         for(var4 = 0; var4 < var3.length / 2; ++var4) {
            var5 = var2.U[var4 * 2] + var1.A * 2122110429;
            var6 = var2.U[var4 * 2 + 1] + var1.H * -372920341;
            var3[var4 * 2] = C + (z - C) * (var5 - H) / (X - H);
            var3[var4 * 2 + 1] = c - (c - i) * (var6 - T) / (R - T);
         }

         KDI.I(var0, var3, var2.i * -248291889);
         if (var2.X * -972644285 > 0) {
            int var7;
            int var8;
            int var9;
            for(var4 = 0; var4 < var3.length / 2 - 1; ++var4) {
               var5 = var3[var4 * 2];
               var6 = var3[var4 * 2 + 1];
               var7 = var3[(var4 + 1) * 2];
               var8 = var3[(var4 + 1) * 2 + 1];
               if (var7 < var5) {
                  var9 = var5;
                  int var10 = var6;
                  var5 = var7;
                  var6 = var8;
                  var7 = var9;
                  var8 = var10;
               } else if (var7 == var5 && var8 < var6) {
                  var9 = var6;
                  var6 = var8;
                  var8 = var9;
               }

               var0.method5039(var5, var6, var7, var8, var2.j[var2.Z[var4] & 255], 1, var2.X * -972644285, var2.P * 2123190239, var2.H * -176015499);
            }

            var4 = var3[var3.length - 2];
            var5 = var3[var3.length - 1];
            var6 = var3[0];
            var7 = var3[1];
            if (var6 < var4) {
               var8 = var4;
               var9 = var5;
               var4 = var6;
               var5 = var7;
               var6 = var8;
               var7 = var9;
            } else if (var6 == var4 && var7 < var5) {
               var8 = var5;
               var5 = var7;
               var7 = var8;
            }

            var0.method5039(var4, var5, var6, var7, var2.j[var2.Z[var2.Z.length - 1] & 255], 1, var2.X * -972644285, var2.P * 2123190239, var2.H * -176015499);
         } else {
            for(var4 = 0; var4 < var3.length / 2 - 1; ++var4) {
               var0.Z(var3[var4 * 2], var3[var4 * 2 + 1], var3[(var4 + 1) * 2], var3[(var4 + 1) * 2 + 1], var2.j[var2.Z[var4] & 255], -608729974);
            }

            var0.Z(var3[var3.length - 2], var3[var3.length - 1], var3[0], var3[1], var2.j[var2.Z[var2.Z.length - 1] & 255], -1529195318);
         }
      }

   }
}
