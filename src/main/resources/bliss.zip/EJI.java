public class EJI {
   public static YZI I;
   public static int Z;

   EJI() throws Throwable {
      throw new Error();
   }

   static final void I(OU var0, byte var1) {
      try {
         var0.S[(var0.A += 969361751) * -203050393 - 1] = var0.z.T[1883543357 * var0.i];
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "e.w(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.J -= -783761378;
         if (var0.H[var0.J * 681479919 + 1] == var0.H[var0.J * 681479919]) {
            var0.i += var0.X[1883543357 * var0.i] * 286750741;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "e.l(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         FW.J.I(FW.J.f, var0.H[(var0.J -= -391880689) * 681479919] == 1 ? 2 : 0, 993124256);
         XEI.mI.P(475179125);
         JN.I(656179282);
         XEI.w = false;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "e.aik(" + ')');
      }
   }
}
