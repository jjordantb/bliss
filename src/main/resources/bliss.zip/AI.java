import java.io.IOException;

public class AI implements MAI {
   KJ B;
   IC C;
   KJ DISABLE_USELESS_PACKETS;
   OS F;

   public boolean method52(int var1) {
      try {
         boolean var2 = true;
         if (!this.DISABLE_USELESS_PACKETS.D(this.C.G * 180759529, -457216440)) {
            var2 = false;
         }

         if (!this.B.D(this.C.G * 180759529, -457216440)) {
            var2 = false;
         }

         return var2;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "fc.b(" + ')');
      }
   }

   public void method55() {
      LZI var1 = CS.I(this.B, 180759529 * this.C.G, 1190428797);
      this.F = FT.P.method5092(var1, RFI.Z(this.DISABLE_USELESS_PACKETS, this.C.G * 180759529), true);
   }

   public void method58(boolean var1, byte var2) {
      try {
         if (var1) {
            int var3 = this.C.S.I(1296783199 * this.C.Z, XEI.BC * 775068819, -2104401433) + this.C.B * -591189315;
            int var4 = this.C.J.I(-1025867285 * this.C.C, XEI.KC * -791746413, -1504826584) + -842094713 * this.C.D;
            this.F.I(this.C.A, var3, var4, this.C.Z * 1296783199, this.C.C * -1025867285, 1046344713 * this.C.H, -122178497 * this.C.K, this.C.F * -434174461, this.C.I * -1329622453, 35264187 * this.C.E, (IBI[])null, (int[])null, (QJI)null, 0, 0, -45995166);
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "fc.f(" + ')');
      }
   }

   public boolean method57() {
      boolean var1 = true;
      if (!this.DISABLE_USELESS_PACKETS.D(this.C.G * 180759529, -457216440)) {
         var1 = false;
      }

      if (!this.B.D(this.C.G * 180759529, -457216440)) {
         var1 = false;
      }

      return var1;
   }

   public boolean method54() {
      boolean var1 = true;
      if (!this.DISABLE_USELESS_PACKETS.D(this.C.G * 180759529, -457216440)) {
         var1 = false;
      }

      if (!this.B.D(this.C.G * 180759529, -457216440)) {
         var1 = false;
      }

      return var1;
   }

   public void method56(boolean var1) {
      if (var1) {
         int var2 = this.C.S.I(1296783199 * this.C.Z, XEI.BC * 775068819, -1797975072) + this.C.B * -591189315;
         int var3 = this.C.J.I(-1025867285 * this.C.C, XEI.KC * -791746413, -792749412) + -842094713 * this.C.D;
         this.F.I(this.C.A, var2, var3, this.C.Z * 1296783199, this.C.C * -1025867285, 1046344713 * this.C.H, -122178497 * this.C.K, this.C.F * -434174461, this.C.I * -1329622453, 35264187 * this.C.E, (IBI[])null, (int[])null, (QJI)null, 0, 0, -45995166);
      }

   }

   public void method53(int var1) {
      try {
         LZI var2 = CS.I(this.B, 180759529 * this.C.G, 1240803660);
         this.F = FT.P.method5092(var2, RFI.Z(this.DISABLE_USELESS_PACKETS, this.C.G * 180759529), true);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "fc.a(" + ')');
      }
   }

   AI(KJ var1, KJ var2, IC var3) {
      this.C = var3;
      this.DISABLE_USELESS_PACKETS = var1;
      this.B = var2;
   }

   public boolean method59() {
      boolean var1 = true;
      if (!this.DISABLE_USELESS_PACKETS.D(this.C.G * 180759529, -457216440)) {
         var1 = false;
      }

      if (!this.B.D(this.C.G * 180759529, -457216440)) {
         var1 = false;
      }

      return var1;
   }

   static int I(int var0) {
      try {
         return (E.B += 1968838043) * -239712109 - 1;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "fc.a(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-105);
         X var4 = IU.F[var2 >> 16];
         JZI.I(var3, var4, var0, (byte)46);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "fc.lf(" + ')');
      }
   }

   public static void I(HZI var0, int var1, int var2, int var3) {
      try {
         OU var4 = UD.Z(-1745561895);
         UEI.I(var0, var1, var2, var4, 536465062);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "fc.r(" + ')');
      }
   }

   static char I(char var0, int var1) {
      try {
         switch(var0) {
         case ' ':
         case '-':
         case '_':
         case ' ':
            return '_';
         case '#':
         case '[':
         case ']':
            return var0;
         case 'À':
         case 'Á':
         case 'Â':
         case 'Ã':
         case 'Ä':
         case 'à':
         case 'á':
         case 'â':
         case 'ã':
         case 'ä':
            return 'a';
         case 'Ç':
         case 'ç':
            return 'c';
         case 'È':
         case 'É':
         case 'Ê':
         case 'Ë':
         case 'è':
         case 'é':
         case 'ê':
         case 'ë':
            return 'e';
         case 'Í':
         case 'Î':
         case 'Ï':
         case 'í':
         case 'î':
         case 'ï':
            return 'i';
         case 'Ñ':
         case 'ñ':
            return 'n';
         case 'Ò':
         case 'Ó':
         case 'Ô':
         case 'Õ':
         case 'Ö':
         case 'ò':
         case 'ó':
         case 'ô':
         case 'õ':
         case 'ö':
            return 'o';
         case 'Ù':
         case 'Ú':
         case 'Û':
         case 'Ü':
         case 'ù':
         case 'ú':
         case 'û':
         case 'ü':
            return 'u';
         case 'ß':
            return 'b';
         case 'ÿ':
         case 'Ÿ':
            return 'y';
         default:
            return Character.toLowerCase(var0);
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "fc.k(" + ')');
      }
   }

   static final void I(byte var0) {
      try {
         if (XEI.II >= 0) {
            XEI.nB = 1991119277 * XEI.dD;
         }

         if (XEI.eI.M) {
            XEI.eI.M = false;
            UEI.C(-1982513993);
         } else {
            if (!FX.G) {
               JJI.I((byte)60);
            }

            for(int var1 = 0; var1 < 100; ++var1) {
               if (!QJ.I(XEI.eI, 2136824168)) {
                  if (var0 <= 4) {
                     throw new IllegalStateException();
                  }
                  break;
               }
            }

            if (XEI.QZ * -1233866115 == 0) {
               int var2;
               PK var11;
               while(WR.Z((byte)35)) {
                  var11 = GB.I(MEI.K, XEI.eI.Z, (byte)105);
                  var11.J.F(0);
                  var2 = var11.J.A * 385051775;
                  IJ.I(var11.J, -1720754748);
                  var11.J.A(var11.J.A * 385051775 - var2, (byte)-105);
                  XEI.eI.I(var11, (byte)-102);
               }

               if (YJI.F != null) {
                  if (YJI.F.C * -747638219 != -1) {
                     var11 = GB.I(MEI.O, XEI.eI.Z, (byte)64);
                     var11.J.Z(-747638219 * YJI.F.C, 16711935);
                     XEI.eI.I(var11, (byte)-33);
                     YJI.F = null;
                     AR.Q = (CI.I((byte)1) + 30000L) * -5619030756491206545L;
                  }
               } else if (CI.I((byte)1) >= AR.Q * 416520701245947535L) {
                  YJI.F = XEI.lI.I((String)VY.E.I, (byte)25);
               }

               if (!Loader.DISABLE_USELESS_PACKETS) {
                  QJ.C((byte)82);
               }

               if (-1625219821 * XEI.NI > 0 || XEI.V.size() > 0) {
                  var11 = GB.I(MEI.Z, XEI.eI.Z, (byte)79);
                  var2 = 2089055308 * XEI.NI + 1 + (-1625219821 * XEI.NI <= 0 ? 1 : 0);
                  var11.J.Z(var2, 16711935);
                  byte var3 = -1;
                  if (XEI.V.size() > 0) {
                     var3 = ((Byte)XEI.V.remove(0)).byteValue();
                  }

                  if (var3 == 16) {
                     XEI.U = false;
                  }

                  var11.J.F(var3);
                  if (-1625219821 * XEI.NI <= 0) {
                     var11.J.F(-1);
                  } else {
                     for(int var4 = 0; var4 < XEI.NI * -1625219821; ++var4) {
                        WSI var5 = XEI.OI[var4];
                        long var6 = var5.method216(-1501300299) - -4339417020449565913L * FSI.B;
                        if (var6 > 16777215L) {
                           var6 = 16777215L;
                        }

                        FSI.B = var5.method216(-2043012774) * -7881601697932874601L;
                        int var8 = var5.method218((byte)-114);
                        if (var8 == 81) {
                           XEI.U = true;
                        }

                        var11.J.F(var8);
                        var11.J.F((int)var6, (byte)52);
                     }
                  }

                  XEI.eI.I(var11, (byte)-79);
               }

               PM var12 = (PM)XEI.gC.Z(1766612795);
               if (XEI.mI.T(-1611682495) != null) {
                  if (3 == EE.V * -863531439) {
                     PL.C(78506535);
                  } else if (1 == -863531439 * EE.V) {
                     EU.I((byte)94);
                  }
               }

               if (XEI.zZ) {
                  XEI.zZ = false;
               } else {
                  XEI.iZ /= 2.0F;
               }

               if (XEI.cZ) {
                  XEI.cZ = false;
               } else {
                  XEI.YZ /= 2.0F;
               }

               UEI.I((byte)111);
               if (-1233866115 * XEI.QZ == 0) {
                  XEI.mI.C((byte)2).I(XEI.mI, -2061035316);
                  BA.I(-2124691803);
                  ESI.I((short)-26190);
                  if (596487115 * XEI.tI > 10) {
                     XEI.eI.S += 157945923;
                  }

                  if (XEI.eI.S * 1237236843 > 2250) {
                     UEI.C(1705248535);
                  } else {
                     if (XEI.uI * 1596783995 == 3) {
                        QC.I(921260863);
                        IG.F(1729319705);
                     } else if (JX.F.I.method239(var12, XEI.OI, -1625219821 * XEI.NI, YR.F, -490402318)) {
                        E.I(false, (short)-10206);
                     } else {
                        if (XEI.uI * 1596783995 == 1 && HG.Z(577335585 * XEI.YB, -275734557)) {
                           XEI.mI.I(new XS(WS.Z, (QEI)null), -1991819579);
                           XEI.uI = -347773236;
                        }

                        if (4 == 1596783995 * XEI.uI && 17 != XEI.QZ * -1233866115) {
                           PFI.Z.I((byte)-51);
                           XEI.uI = 0;
                           XEI.wI = -96767293 * XEI.kB;
                           XEI.zD = 0;
                           OSI.I((byte)-114);
                        }

                        if (1596783995 * XEI.uI == 0) {
                           var2 = 443738891 * XEI.kB - XEI.wI * -1846472167;
                           if (1247173565 * XEI.zD < PFI.F.length) {
                              while(true) {
                                 LDI var15 = PFI.F[1247173565 * XEI.zD];
                                 if (var15.I * 1147432229 > var2) {
                                    break;
                                 }

                                 var15.method866(-2077694254);
                                 if (1596783995 * XEI.uI != 0) {
                                    break;
                                 }

                                 if ((XEI.zD += 1259550613) * 1247173565 >= PFI.F.length) {
                                    if (var0 > 4) {
                                       ;
                                    }
                                    break;
                                 }
                              }
                           }

                           if (XEI.uI * 1596783995 == 0) {
                              for(int var16 = 0; var16 < PFI.C.length; ++var16) {
                                 YFI var17 = PFI.C[var16];
                                 if (!var17.D) {
                                    if (var0 <= 4) {
                                       throw new IllegalStateException();
                                    }
                                 } else {
                                    SSI var20 = var17.I(21832379);
                                    CZ.I(var20, true, -1897267593);
                                 }
                              }
                           }
                        }
                     }

                     GW.Z(-1841664621);
                     if (!XEI.MD) {
                        HW.C(1446435433);
                        XEI.MD = true;
                     }

                     LW.B(-1345932063);
                     XEI.BF += 512435497;
                     if (-392325587 * XEI.MZ != 0) {
                        XEI.wZ += -421126628;
                        if (XEI.wZ * 1347929875 >= 400) {
                           XEI.MZ = 0;
                        }
                     }

                     if (CJ.C != null) {
                        XEI.yZ += 289473031;
                        if (XEI.yZ * -2018194505 >= 15) {
                           VEI.I(CJ.C, -1829287170);
                           CJ.C = null;
                        }
                     }

                     XEI.HB = null;
                     XEI.eD = false;
                     XEI.KB = false;
                     Q.I = null;
                     VDI.I((HSI)null, -1, -1, -6089367);
                     if (!XEI.rC) {
                        XEI.aD = 280458557;
                     }

                     KBI.B(-640926851);
                     XEI.dD += -908761385;
                     PK var13;
                     if (XEI.VB) {
                        var13 = GB.I(MEI.nI, XEI.eI.Z, (byte)91);
                        var13.J.B(924378211 * EJ.Z << 28 | DJI.D * -537916961 << 14 | KF.I * -605610561, -1116555169);
                        XEI.eI.I(var13, (byte)-83);
                        XEI.VB = false;
                     }

                     while(true) {
                        KM var14;
                        HSI var18;
                        HSI var19;
                        do {
                           var14 = (KM)XEI.p.I(2107909159);
                           if (var14 == null) {
                              while(true) {
                                 do {
                                    var14 = (KM)XEI.uB.I(2126788731);
                                    if (var14 == null) {
                                       while(true) {
                                          while(true) {
                                             var14 = (KM)XEI.rB.I(2113415758);
                                             if (var14 == null) {
                                                if (var0 <= 4) {
                                                   throw new IllegalStateException();
                                                }

                                                if (Q.I == null) {
                                                   XEI.UB = 0;
                                                }

                                                if (XEI.SB != null) {
                                                   WCI.I(-1193693208);
                                                }

                                                if (XEI.QC * 1806357379 > 0 && YR.F.method3936(82, -510265259) && YR.F.method3936(81, 1722713678) && XEI.HI * 1170859143 != 0) {
                                                   var2 = UA.F.K - XEI.HI * 1170859143;
                                                   if (var2 < 0) {
                                                      var2 = 0;
                                                   } else if (var2 > 3) {
                                                      var2 = 3;
                                                   }

                                                   XP var21 = XEI.mI.I(681479919);
                                                   XY.I(var2, UA.F.YI[0] + -1760580017 * var21.I, UA.F.v[0] + 283514611 * var21.Z, 1979698840);
                                                }

                                                ESI.I(187981678);

                                                for(var2 = 0; var2 < 5; ++var2) {
                                                   ++XEI.IC[var2];
                                                }

                                                if (XEI.BZ && XEI.qB * -4876927317316500383L < CI.I((byte)1) - 60000L) {
                                                   OCI.I(1315881016);
                                                }

                                                for(LN var22 = (LN)XEI.tD.I(-16777216); var22 != null; var22 = (LN)XEI.tD.C(-1081988620)) {
                                                   if ((long)(-1505693583 * var22.B) < CI.I((byte)1) / 1000L - 5L) {
                                                      if (var22.C > 0) {
                                                         HJ.I(5, 0, "", "", "", var22.D + VEI.GZ.I(WO.U, -875414210), 818502865);
                                                      }

                                                      if (var22.C == 0) {
                                                         HJ.I(5, 0, "", "", "", var22.D + VEI.HZ.I(WO.U, -875414210), -1731923786);
                                                      }

                                                      var22.I(180959790);
                                                   }
                                                }

                                                XEI.KZ += -447320539;
                                                if (-1380319827 * XEI.KZ > 506) {
                                                   XEI.KZ = 0;
                                                   var2 = (int)(Math.random() * 8.0D);
                                                   if ((var2 & 1) == 1) {
                                                      XEI.iC += XEI.SZ * -969022135;
                                                   }

                                                   if ((var2 & 2) == 2) {
                                                      XEI.AZ += XEI.eC * 200330303;
                                                   }

                                                   if (4 == (var2 & 4)) {
                                                      XEI.GZ += -284639445 * XEI.HZ;
                                                   }
                                                }

                                                if (1734240325 * XEI.iC < -51) {
                                                   XEI.SZ = -57270710;
                                                }

                                                if (XEI.iC * 1734240325 > 55) {
                                                   XEI.SZ = 57270710;
                                                }

                                                if (XEI.AZ * 1874511679 < -62) {
                                                   XEI.eC = -792852734;
                                                }

                                                if (XEI.AZ * 1874511679 > 64) {
                                                   XEI.eC = 792852734;
                                                }

                                                if (XEI.GZ * -1419578297 < -44) {
                                                   XEI.HZ = 901405925;
                                                }

                                                if (XEI.GZ * -1419578297 > 42) {
                                                   XEI.HZ = -901405925;
                                                }

                                                XEI.RC += -1075811357;
                                                if (1061958091 * XEI.RC > 505) {
                                                   XEI.RC = 0;
                                                   var2 = (int)(Math.random() * 8.0D);
                                                   if ((var2 & 1) == 1) {
                                                      XEI.GC += -996860861 * XEI.jB;
                                                   }

                                                   if (2 == (var2 & 2)) {
                                                      XEI.NZ += -2133918149 * XEI.SF;
                                                   }
                                                }

                                                if (1227356013 * XEI.GC < -67) {
                                                   XEI.jB = -640741266;
                                                }

                                                if (1227356013 * XEI.GC > 67) {
                                                   XEI.jB = 640741266;
                                                }

                                                if (356727603 * XEI.NZ < -21) {
                                                   XEI.SF = 999313729;
                                                }

                                                if (XEI.NZ * 356727603 > 10) {
                                                   XEI.SF = -999313729;
                                                }

                                                XEI.eI.A += 1797987493;
                                                if (2033675053 * XEI.eI.A > 50) {
                                                   var13 = GB.I(MEI.U, XEI.eI.Z, (byte)120);
                                                   XEI.eI.I(var13, (byte)-57);
                                                }

                                                if (XEI.kI) {
                                                   CFI.I((byte)-12);
                                                   XEI.kI = false;
                                                }

                                                try {
                                                   XEI.eI.Z(-1146717706);
                                                } catch (IOException var9) {
                                                   UEI.C(1323080201);
                                                }

                                                return;
                                             }

                                             var18 = var14.A;
                                             if (var18.a * -1309843523 >= 0) {
                                                var19 = AZI.I(var18.m * 1573706803, (byte)36);
                                                if (var19 == null || var19.SC == null || -1309843523 * var18.a >= var19.SC.length) {
                                                   continue;
                                                }

                                                if (var19.SC[var18.a * -1309843523] != var18) {
                                                   if (var0 <= 4) {
                                                      throw new IllegalStateException();
                                                   }
                                                   continue;
                                                }
                                             }

                                             PX.I(var14, (byte)-21);
                                          }
                                       }
                                    }

                                    var18 = var14.A;
                                    if (-1309843523 * var18.a < 0) {
                                       break;
                                    }

                                    var19 = AZI.I(var18.m * 1573706803, (byte)80);
                                 } while(var19 == null || var19.SC == null || var18.a * -1309843523 >= var19.SC.length || var19.SC[var18.a * -1309843523] != var18);

                                 PX.I(var14, (byte)64);
                              }
                           }

                           var18 = var14.A;
                           if (-1309843523 * var18.a < 0) {
                              break;
                           }

                           var19 = AZI.I(var18.m * 1573706803, (byte)54);
                        } while(var19 == null || var19.SC == null || var18.a * -1309843523 >= var19.SC.length || var19.SC[var18.a * -1309843523] != var18);

                        PX.I(var14, (byte)9);
                     }
                  }
               }
            }
         }

      } catch (RuntimeException var10) {
         throw DQ.I(var10, "fc.gu(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         int var2 = var0.X[1883543357 * var0.i];
         GT var3 = FN.Z.Z(var2, -1368678783);
         if (var3 == null) {
            throw new RuntimeException();
         } else {
            Integer var4 = var0.R.I(XEI.mD.S * -937307905 << 16 | var2, (byte)-31);
            int var5;
            if (var4 == null) {
               if (var3.I != 'i' && var3.I != '1') {
                  var5 = -1;
               } else {
                  var5 = 0;
               }
            } else {
               var5 = var4.intValue();
            }

            var0.H[(var0.J += -391880689) * 681479919 - 1] = var5;
         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "fc.bv(" + ')');
      }
   }
}
