public class AM extends AE {
   int J;
   int append;
   int toString;
   int S;
   int A;
   int E;
   int G;
   int H;
   int K;

   boolean I(int var1, int var2, int var3, int var4) {
      try {
         return this.H * -206354885 == var1 && var2 >= this.toString * -731405573 && var2 <= 480895455 * this.S && var3 >= -1728316981 * this.E && var3 <= -176293349 * this.append;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "aca.f(" + ')');
      }
   }

   boolean I(int var1, int var2, int var3) {
      try {
         return var1 >= this.toString * -731405573 && var1 <= 480895455 * this.S && var2 >= -1728316981 * this.E && var2 <= -176293349 * this.append;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aca.a(" + ')');
      }
   }

   boolean I(int var1, int var2, byte var3) {
      try {
         return var1 >= this.J * 1528024175 && var1 <= this.A * 37578241 && var2 >= 50981941 * this.G && var2 <= this.K * 1374138429;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aca.b(" + ')');
      }
   }

   void I(int var1, int var2, int[] var3, int var4) {
      try {
         var3[0] = -206354885 * this.H;
         var3[1] = -731405573 * this.toString - 1528024175 * this.J + var1;
         var3[2] = var2 + (this.E * -1728316981 - 50981941 * this.G);
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "aca.p(" + ')');
      }
   }

   AM(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9) {
      this.H = 301572851 * var1;
      this.toString = var2 * 868816947;
      this.E = -1243061277 * var3;
      this.S = var4 * 992156191;
      this.append = 878333971 * var5;
      this.J = var6 * -134278513;
      this.G = 1339754013 * var7;
      this.A = var8 * 1785108993;
      this.K = var9 * 734947093;
   }

   void Z(int var1, int var2, int[] var3, int var4) {
      try {
         var3[0] = 0;
         var3[1] = this.J * 1528024175 - this.toString * -731405573 + var1;
         var3[2] = 50981941 * this.G - -1728316981 * this.E + var2;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "aca.i(" + ')');
      }
   }
}
