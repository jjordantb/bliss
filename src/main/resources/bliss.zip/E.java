public class E {
   static int I;
   static int Z = 100;
   static F[] C = new F[100];
   static int B = 0;
   static String D;
   public static short[] F;

   E() throws Throwable {
      throw new Error();
   }

   static final void I(OU var0, int var1) {
      try {
         var0.J -= -783761378;
         int var2 = var0.H[681479919 * var0.J];
         int var3 = var0.H[1 + var0.J * 681479919];
         OSI var4 = (OSI)XEI.yC.I((long)var2);
         if (var4 != null && var4.S * -1617025021 == var3) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 1;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ej.sc(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         var0.A -= 1938723502;
         String var2 = (String)var0.S[-203050393 * var0.A];
         String var3 = (String)var0.S[1 + -203050393 * var0.A];
         var0.J -= -783761378;
         int var4 = var0.H[var0.J * 681479919];
         int var5 = var0.H[var0.J * 681479919 + 1];
         if (var3 == null) {
            var3 = "";
         }

         if (var3.length() > 80) {
            var3 = var3.substring(0, 80);
         }

         VJ var6 = XW.I((short)512);
         PK var7 = GB.I(MEI.mI, var6.Z, (byte)119);
         var7.J.F(SBI.I(var2, 824741758) + 2 + SBI.I(var3, 1825350693));
         var7.J.I(var2, 2106957480);
         var7.J.F(var4 - 1);
         var7.J.F(var5);
         var7.J.I(var3, 2102628417);
         var6.I(var7, (byte)-56);
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "ej.abn(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         FW.J.I(FW.J.c, var0.H[(var0.J -= -391880689) * 681479919], -2044130238);
         JN.I(656179282);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ej.aiu(" + ')');
      }
   }

   static final void I(OU var0, short var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)78);
         X var4 = IU.F[var2 >> 16];
         PA.I(var3, var4, var0, (short)909);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ej.gn(" + ')');
      }
   }

   static final void B(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var3.yZ * -261021353;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ej.pq(" + ')');
      }
   }

   static final void D(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var0.R.D[var2];
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ej.xa(" + ')');
      }
   }

   public static void I(boolean var0, short var1) {
      try {
         if (1596783995 * XEI.uI != 2 && 1596783995 * XEI.uI != 3) {
            if (!var0) {
               LDI[] var2 = PFI.F;

               for(int var3 = 0; var3 < var2.length; ++var3) {
                  LDI var4 = var2[var3];
                  var4.I(-2077321818);
               }
            }

            XEI.uI = 1973597030;
            QK.E = null;
            NI.K = null;
            XEI.vI = false;
            RF.I(1960223809);
            PK var6 = GB.I(MEI.Q, XEI.eI.Z, (byte)30);
            var6.J.F(var0 ? 1 : 0);
            XEI.eI.I(var6, (byte)-61);
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ej.i(" + ')');
      }
   }
}
