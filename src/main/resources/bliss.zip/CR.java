public class CR extends ZR {
   int YA;
   int append;
   int atan2;
   public int V;
   public int W;
   int i;
   SX method4728;
   int method4739;
   public int X;
   double method4781;
   boolean method4786;
   boolean method5042 = false;
   double n;
   int sqrt;
   double tan;
   double toString;
   double Y;
   public int z;
   int c = 0;
   boolean b = false;
   GQ d;

   final boolean method4400() {
      return false;
   }

   boolean method4353() {
      return false;
   }

   public int method4361(int var1) {
      try {
         return this.c * 1137666943;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aka.bm(" + ')');
      }
   }

   public int method4380() {
      return this.c * 1137666943;
   }

   public final void I(int var1, int var2, int var3, int var4, int var5) {
      try {
         SF var6 = SF.I(this.I().I);
         if (!this.method5042) {
            float var7 = (float)var1 - var6.I;
            float var8 = (float)var2 - var6.Z;
            float var9 = (float)Math.sqrt((double)(var8 * var8 + var7 * var7));
            if (0.0F != var9) {
               var6.I += (float)(732601943 * this.sqrt) * var7 / var9;
               var6.Z += (float)(732601943 * this.sqrt) * var8 / var9;
            }

            if (this.method4786) {
               var6.C = (float)(NQ.I((int)var6.I, (int)var6.Z, this.K, -1463922586) - this.append * 1403412253);
            }

            this.I(var6);
         }

         double var11 = (double)(this.X * -1349988959 + 1 - var4);
         this.n = (double)((float)var1 - var6.I) / var11;
         this.method4781 = (double)((float)var2 - var6.Z) / var11;
         this.tan = Math.sqrt(this.method4781 * this.method4781 + this.n * this.n);
         if (-1 != this.method4739 * 1575706083) {
            if (!this.method5042) {
               this.toString = -this.tan * Math.tan(0.02454369D * (double)(1575706083 * this.method4739));
            }

            this.Y = 2.0D * ((double)((float)var3 - var6.C) - var11 * this.toString) / (var11 * var11);
         } else {
            this.toString = (double)((float)var3 - var6.C) / var11;
         }

         var6.I();
      } catch (RuntimeException var10) {
         throw DQ.I(var10, "aka.a(" + ')');
      }
   }

   public void Z(int var1) {
      try {
         if (!this.method5042 && this.atan2 * 132125965 != 0) {
            Object var2 = null;
            if (XEI.uI * 1596783995 == 0) {
               var2 = PFI.C[this.atan2 * 132125965 - 1].I(1781553547);
            } else {
               int var3;
               if (this.atan2 * 132125965 < 0) {
                  var3 = -(this.atan2 * 132125965) - 1;
                  if (-442628795 * XEI.i == var3) {
                     var2 = UA.F;
                  } else {
                     var2 = XEI.MC[var3];
                  }
               } else {
                  var3 = 132125965 * this.atan2 - 1;
                  QG var4 = (QG)XEI.UI.I((long)var3);
                  if (var4 != null) {
                     var2 = (SSI)var4.J;
                  }
               }
            }

            if (var2 != null) {
               SF var15 = ((SSI)var2).I().I;
               this.I(var15.I, (float)(NQ.I((int)var15.I, (int)var15.Z, this.K, -1098231500) - 1403412253 * this.append), var15.Z);
               if (this.YA * -1955698847 >= 0) {
                  EQ var16 = ((SSI)var2).C(399670605);
                  int var5 = 0;
                  int var6 = 0;
                  if (var16.I != null && var16.I[this.YA * -1955698847] != null) {
                     var5 += var16.I[-1955698847 * this.YA][0];
                     var6 += var16.I[this.YA * -1955698847][2];
                  }

                  if (var16.o != null && var16.o[-1955698847 * this.YA] != null) {
                     var5 += var16.o[-1955698847 * this.YA][0];
                     var6 += var16.o[this.YA * -1955698847][2];
                  }

                  if (var5 != 0 || var6 != 0) {
                     int var7 = ((SSI)var2).n.I((byte)0);
                     int var8 = var7;
                     if (((SSI)var2).o != null && ((SSI)var2).o[this.YA * -1955698847] != -1) {
                        var8 = ((SSI)var2).o[-1955698847 * this.YA];
                     }

                     int var9 = var8 - var7 & 16383;
                     int var10 = HF.S[var9];
                     int var11 = HF.I[var9];
                     int var12 = var6 * var10 + var5 * var11 >> 14;
                     var6 = var6 * var11 - var10 * var5 >> 14;
                     SF var13 = SF.I(this.I().I);
                     var13.I += (float)var12;
                     var13.Z += (float)var6;
                     this.I(var13);
                     var13.I();
                  }
               }
            }
         }

      } catch (RuntimeException var14) {
         throw DQ.I(var14, "aka.f(" + ')');
      }
   }

   final void method4375(GSI var1, IR var2, int var3, int var4, int var5, boolean var6) {
      throw new IllegalStateException();
   }

   public final void I(int var1, byte var2) {
      try {
         this.method5042 = true;
         ZJ var3 = new ZJ(this.I());
         var3.I.I = (float)((double)var3.I.I + this.n * (double)var1);
         var3.I.Z = (float)((double)var3.I.Z + this.method4781 * (double)var1);
         if (this.method4786) {
            var3.I.C = (float)(NQ.I((int)var3.I.I, (int)var3.I.Z, this.K, -1903626222) - 1403412253 * this.append);
         } else if (this.method4739 * 1575706083 != -1) {
            var3.I.C = (float)((double)var3.I.C + (double)var1 * (double)var1 * 0.5D * this.Y + (double)var1 * this.toString);
            this.toString += (double)var1 * this.Y;
         } else {
            var3.I.C = (float)((double)var3.I.C + this.toString * (double)var1);
         }

         var3.Z.Z(1.0F, 0.0F, 0.0F, (float)Math.atan2(this.toString, this.tan));
         AF var4 = AF.I();
         var4.Z(0.0F, 1.0F, 0.0F, (float)Math.atan2(this.n, this.method4781) - 3.1415927F);
         var3.Z.C(var4);
         var4.C();
         this.I(var3);
         if (this.method4728.Z(1, 1832022530) && this.method4728.D(588331212)) {
            this.method4728.F(981301272);
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aka.b(" + ')');
      }
   }

   final boolean method4386() {
      return false;
   }

   void I(int var1) {
      try {
         SF var2 = this.I().I;
         this.R = this.P = (short)((int)(var2.I / 512.0F));
         this.O = this.Q = (short)((int)(var2.Z / 512.0F));
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aka.ew(" + ')');
      }
   }

   public HP method4358(GSI var1, byte var2) {
      return null;
   }

   boolean method4399(byte var1) {
      return false;
   }

   boolean method4350(GSI var1, int var2, int var3, byte var4) {
      return false;
   }

   final boolean method4366(int var1) {
      return false;
   }

   final void method4355(GSI var1, IR var2, int var3, int var4, int var5, boolean var6, int var7) {
      try {
         throw new IllegalStateException();
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "aka.bk(" + ')');
      }
   }

   final void method4398(byte var1) {
      try {
         throw new IllegalStateException();
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aka.bq(" + ')');
      }
   }

   KP method4394(GSI var1, int var2) {
      try {
         UT var3 = this.YA(var1, 2048, -1431142826);
         if (var3 == null) {
            return null;
         } else {
            LF var4 = this.J();
            this.B(var1, var3, var4, 752544216);
            KP var5 = BDI.I(false, 1890696440);
            var3.method4739(var4, this.N[0], 0);
            if (this.d != null) {
               XBI var6 = this.d.D();
               var1.method5042(var6);
            }

            this.b = var3.i();
            var3.n();
            this.c = var3.YA() * -1389603713;
            return var5;
         }
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "aka.bo(" + ')');
      }
   }

   void B(GSI var1, UT var2, LF var3, int var4) {
      try {
         var2.method4786(var3);
         NFI[] var5 = var2.method4781();
         WBI[] var6 = var2.method4728();
         if ((this.d == null || this.d.S) && (var5 != null || var6 != null)) {
            this.d = GQ.I(XEI.kB * 443738891, true);
         }

         if (this.d != null) {
            this.d.I(var1, (long)(443738891 * XEI.kB), var5, var6, false);
            this.d.I(this.K, this.R, this.P, this.O, this.Q);
         }

      } catch (RuntimeException var7) {
         throw DQ.I(var7, "aka.i(" + ')');
      }
   }

   boolean method4374() {
      return false;
   }

   public HP method4367(GSI var1) {
      return null;
   }

   public HP method4368(GSI var1) {
      return null;
   }

   KP method4370(GSI var1) {
      UT var2 = this.YA(var1, 2048, -1431142826);
      if (var2 == null) {
         return null;
      } else {
         LF var3 = this.J();
         this.B(var1, var2, var3, 250084815);
         KP var4 = BDI.I(false, 1436132074);
         var2.method4739(var3, this.N[0], 0);
         if (this.d != null) {
            XBI var5 = this.d.D();
            var1.method5042(var5);
         }

         this.b = var2.i();
         var2.n();
         this.c = var2.YA() * -1389603713;
         return var4;
      }
   }

   void method4371(GSI var1) {
      UT var2 = this.YA(var1, 0, -1431142826);
      if (var2 != null) {
         LF var3 = this.J();
         this.c = var2.YA() * -1389603713;
         var2.n();
         this.B(var1, var2, var3, 378749771);
      }

   }

   final void method4378() {
      throw new IllegalStateException();
   }

   boolean method4372(GSI var1, int var2, int var3) {
      return false;
   }

   boolean method4385(GSI var1, int var2, int var3) {
      return false;
   }

   boolean method4352(GSI var1, int var2, int var3) {
      return false;
   }

   public int method4381() {
      return this.c * 1137666943;
   }

   final void method4388(GSI var1, IR var2, int var3, int var4, int var5, boolean var6) {
      throw new IllegalStateException();
   }

   final void method4377() {
      throw new IllegalStateException();
   }

   boolean method4365() {
      return false;
   }

   public int method4379() {
      return this.c * 1137666943;
   }

   boolean method4376(short var1) {
      try {
         return this.b;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aka.be(" + ')');
      }
   }

   void S() {
      SF var1 = this.I().I;
      this.R = this.P = (short)((int)(var1.I / 512.0F));
      this.O = this.Q = (short)((int)(var1.Z / 512.0F));
   }

   UT YA(GSI var1, int var2, int var3) {
      try {
         GU var4 = GC.S.I(1528803725 * this.i, -1880515681);
         return var4.I(var1, var2, this.method4728, (byte)2, 2089191246);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aka.p(" + ')');
      }
   }

   void method4357(GSI var1, int var2) {
      try {
         UT var3 = this.YA(var1, 0, -1431142826);
         if (var3 != null) {
            LF var4 = this.J();
            this.c = var3.YA() * -1389603713;
            var3.n();
            this.B(var1, var3, var4, 1295394803);
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aka.bb(" + ')');
      }
   }

   boolean method4369() {
      return this.b;
   }

   boolean method4382() {
      return this.b;
   }

   boolean method4349() {
      return this.b;
   }

   public void C(int var1) {
      try {
         if (this.d != null) {
            this.d.Z();
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aka.k(" + ')');
      }
   }

   boolean method4351() {
      return this.b;
   }

   final boolean method4384() {
      return false;
   }

   public CR(AP var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, int var11, int var12, int var13, int var14, boolean var15, int var16) {
      super(var1, var3, var4, var5, NQ.I(var5, var6, var3, -1556375135) - var7, var6, var5 >> 9, var5 >> 9, var6 >> 9, var6 >> 9, false, (byte)0);
      this.i = var2 * -342886075;
      this.V = 52330647 * var8;
      this.X = -195668383 * var9;
      this.method4739 = -1889087541 * var10;
      this.sqrt = var11 * -1501352601;
      this.atan2 = -113917499 * var12;
      this.z = var13 * 1040105721;
      this.append = var7 * -1635034315;
      this.W = -954169831 * var14;
      this.method4786 = var15;
      this.method5042 = false;
      this.YA = 1279163553 * var16;
      int var17 = GC.S.I(this.i * 1528803725, -1811500435).Z * 1505778629;
      this.method4728 = new EX(this, false);
      this.method4728.I(var17, -1768064453);
      this.I(1, 291576769);
   }

   void append() {
      SF var1 = this.I().I;
      this.R = this.P = (short)((int)(var1.I / 512.0F));
      this.O = this.Q = (short)((int)(var1.Z / 512.0F));
   }

   final boolean method4387() {
      return false;
   }

   void method4373(GSI var1) {
      UT var2 = this.YA(var1, 0, -1431142826);
      if (var2 != null) {
         LF var3 = this.J();
         this.c = var2.YA() * -1389603713;
         var2.n();
         this.B(var1, var2, var3, 1024355071);
      }

   }

   boolean method4383() {
      return this.b;
   }
}
