public class EBI {
   int I;
   int Z;
   int C;
   short B;
   byte D;
   short F;
   short J;
   short S;
   int A;
   int E = 0;
   short G;
}
