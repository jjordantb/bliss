public class DN extends AE {
   static JQ J = new JQ(10);
   static JX S = new JX(32);
   static int A;
   int[] E = new int[]{-1};
   int[] G = new int[1];
   static int H;

   final UT I(GSI var1, int var2, SX var3, int var4, boolean var5, QR var6, byte var7) {
      try {
         UT var8 = null;
         int var9 = var2;
         EQ var10 = null;
         if (-1 != var4) {
            var10 = YFI.F.Z(var4, (byte)89);
         }

         int[] var11 = this.E;
         if (var10 != null && var10.U != null) {
            var11 = new int[var10.U.length];

            for(int var12 = 0; var12 < var10.U.length; ++var12) {
               int var13 = var10.U[var12];
               if (var13 >= 0 && var13 < this.E.length) {
                  var11[var12] = this.E[var13];
               } else {
                  var11[var12] = -1;
               }
            }
         }

         if (var3 != null) {
            var9 = var2 | var3.B(-1790708337);
         }

         long var25 = this.KA(var11, var4, var6 != null ? var6.Z : null, var5, 551500137);
         if (J != null) {
            var8 = (UT)J.I(var25);
         }

         if (var8 == null || var1.method5017(var8.m(), var9) != 0) {
            if (var8 != null) {
               var9 = var1.method5004(var9, var8.m());
            }

            int var14 = var9;
            boolean var15 = false;

            for(int var16 = 0; var16 < var11.length; ++var16) {
               if (var11[var16] != -1 && !JH.R.I(var11[var16]).I(var5, (KY)null, (byte)-79)) {
                  var15 = true;
               }
            }

            if (var15) {
               return null;
            }

            MBI[] var27 = new MBI[var11.length];

            int var17;
            for(var17 = 0; var17 < var11.length; ++var17) {
               if (var11[var17] == -1) {
                  if (var7 != 1) {
                     throw new IllegalStateException();
                  }
               } else {
                  var27[var17] = JH.R.I(var11[var17]).I(var5, (KY)null, (int)-1732273011);
               }
            }

            int var18;
            int var19;
            if (var10 != null && var10.I != null) {
               for(var17 = 0; var17 < var10.I.length; ++var17) {
                  if (var10.I[var17] != null) {
                     if (var27[var17] == null) {
                        if (var7 != 1) {
                           throw new IllegalStateException();
                        }
                     } else {
                        var18 = var10.I[var17][0];
                        var19 = var10.I[var17][1];
                        int var20 = var10.I[var17][2];
                        int var21 = var10.I[var17][3];
                        int var22 = var10.I[var17][4];
                        int var23 = var10.I[var17][5];
                        if (var21 != 0 || var22 != 0 || var23 != 0) {
                           var27[var17].C(var21, var22, var23);
                        }

                        if (var18 != 0 || var19 != 0 || var20 != 0) {
                           var27[var17].Z(var18, var19, var20);
                        }
                     }
                  }
               }
            }

            MBI var28 = new MBI(var27, var27.length);
            if (var6 != null) {
               var14 = var9 | 16384;
            }

            var8 = var1.method5037(var28, var14, A * 1310831989, 66, 850);
            if (var6 != null) {
               for(var18 = 0; var18 < 10; ++var18) {
                  for(var19 = 0; var19 < QR.I[var18].length; ++var19) {
                     if (var6.Z[var18] < GF.I[var18][var19].length) {
                        var8.X(QR.I[var18][var19], GF.I[var18][var19][var6.Z[var18]]);
                     }
                  }
               }
            }

            if (J != null) {
               var8.KA(var9);
               J.I(var8, var25);
            }
         }

         if (var3 == null) {
            return var8;
         } else {
            UT var26 = var8.method4755((byte)1, var9, true);
            var3.I((UT)var26, 0, (int)-1119502581);
            return var26;
         }
      } catch (RuntimeException var24) {
         throw DQ.I(var24, "aam.n(" + ')');
      }
   }

   long KA(int[] var1, int var2, int[] var3, boolean var4, int var5) {
      try {
         long[] var6 = REI.G;
         long var7 = -1L;
         var7 = var7 >>> 8 ^ var6[(int)((var7 ^ (long)(var2 >> 8)) & 255L)];
         var7 = var7 >>> 8 ^ var6[(int)((var7 ^ (long)var2) & 255L)];

         int var9;
         for(var9 = 0; var9 < var1.length; ++var9) {
            var7 = var7 >>> 8 ^ var6[(int)((var7 ^ (long)(var1[var9] >> 24)) & 255L)];
            var7 = var7 >>> 8 ^ var6[(int)((var7 ^ (long)(var1[var9] >> 16)) & 255L)];
            var7 = var7 >>> 8 ^ var6[(int)((var7 ^ (long)(var1[var9] >> 8)) & 255L)];
            var7 = var7 >>> 8 ^ var6[(int)((var7 ^ (long)var1[var9]) & 255L)];
         }

         if (var3 != null) {
            for(var9 = 0; var9 < 5; ++var9) {
               var7 = var7 >>> 8 ^ var6[(int)((var7 ^ (long)var3[var9]) & 255L)];
            }
         }

         var7 = var7 >>> 8 ^ var6[(int)((var7 ^ (long)(var4 ? 1 : 0)) & 255L)];
         return var7;
      } catch (RuntimeException var10) {
         throw DQ.I(var10, "aam.q(" + ')');
      }
   }

   static void I(REI var0, int var1) {
      try {
         for(int var2 = 0; var2 < 1017276543 * JJ.B; ++var2) {
            int var3 = var0.B(1723054621);
            int var4 = var0.C();
            if (var4 == 65535) {
               var4 = -1;
            }

            if (XI.Z[var3] != null) {
               XI.Z[var3].I = var4 * 2083476291;
            }
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aam.p(" + ')');
      }
   }
}
