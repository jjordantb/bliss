import java.io.File;

public class CZI {
   public static String I;
   public static String Z;

   static {
      String var0 = "Unknown";

      try {
         var0 = System.getProperty("java.vendor").toLowerCase();
      } catch (Exception var7) {
         ;
      }

      var0.toLowerCase();
      var0 = "Unknown";

      try {
         var0 = System.getProperty("java.version").toLowerCase();
      } catch (Exception var6) {
         ;
      }

      var0.toLowerCase();
      var0 = "Unknown";

      try {
         var0 = System.getProperty("os.name").toLowerCase();
      } catch (Exception var5) {
         ;
      }

      Z = var0.toLowerCase();
      var0 = "Unknown";

      try {
         var0 = System.getProperty("os.arch").toLowerCase();
      } catch (Exception var4) {
         ;
      }

      I = var0.toLowerCase();
      var0 = "Unknown";

      try {
         var0 = System.getProperty("os.version").toLowerCase();
      } catch (Exception var3) {
         ;
      }

      var0.toLowerCase();
      var0 = "~/";

      try {
         var0 = System.getProperty("user.home").toLowerCase();
      } catch (Exception var2) {
         ;
      }

      new File(var0);
   }

   CZI() throws Throwable {
      throw new Error();
   }

   public static final void I(String var0, int var1) {
      try {
         if (var0 != null) {
            String var2 = BB.I((CharSequence)var0, 2076308091);
            if (var2 != null) {
               for(int var3 = 0; var3 < XEI.kD * -1054937867; ++var3) {
                  String var4 = XEI.cI[var3];
                  String var5 = BB.I((CharSequence)var4, -1598414380);
                  if (AU.I(var0, var2, var4, var5, -1043868937)) {
                     XEI.kD -= 560029533;

                     for(int var6 = var3; var6 < -1054937867 * XEI.kD; ++var6) {
                        XEI.cI[var6] = XEI.cI[var6 + 1];
                        XEI.nD[var6] = XEI.nD[1 + var6];
                        XEI.oD[var6] = XEI.oD[var6 + 1];
                        XEI.pD[var6] = XEI.pD[var6 + 1];
                        XEI.bI[var6] = XEI.bI[1 + var6];
                        XEI.rI[var6] = XEI.rI[1 + var6];
                        XEI.rD[var6] = XEI.rD[1 + var6];
                     }

                     XEI.hB = XEI.dD * 754377557;
                     VJ var9 = XW.I((short)512);
                     PK var7 = GB.I(MEI.eI, var9.Z, (byte)9);
                     var7.J.F(SBI.I(var0, 2053997873));
                     var7.J.I(var0, 2123529676);
                     var9.I(var7, (byte)-90);
                     break;
                  }
               }
            }
         }

      } catch (RuntimeException var8) {
         throw DQ.I(var8, "uk.ms(" + ')');
      }
   }

   public static int I(byte var0) {
      try {
         return E.I * 1103086749;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "uk.d(" + ')');
      }
   }
}
