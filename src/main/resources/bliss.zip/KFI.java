public class KFI extends LDI {
   int S;
   int Z;

   KFI(REI var1) {
      super(var1);
      this.Z = var1.C() * 1855434323;
      this.S = var1.C() * -1535090649;
   }

   public void method866(int var1) {
      try {
         PFI.C[this.Z * -712456741].I(975748334).I(1246957463 * this.S, true, -2120305810);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "xt.f(" + ')');
      }
   }

   public void method868() {
      PFI.C[this.Z * -712456741].I(1870651680).I(1246957463 * this.S, true, -841249302);
   }

   public void method869() {
      PFI.C[this.Z * -712456741].I(1351902307).I(1246957463 * this.S, true, -384852587);
   }

   static final void B(OU var0, int var1) {
      try {
         var0.J -= -1175642067;
         FJ.I(var0.H[681479919 * var0.J], var0.H[var0.J * 681479919 + 1], var0.H[2 + var0.J * 681479919], 255, 256, 1698817492);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "xt.st(" + ')');
      }
   }

   public static boolean I(byte var0) {
      try {
         return EDI.I * 617004265 != 0;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "xt.z(" + ')');
      }
   }

   public static boolean Z(int var0, byte var1) {
      try {
         return var0 >= -1976050083 * RW.W.V && var0 <= RW.B.V * -1976050083 || RW.D.V * -1976050083 == var0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "xt.b(" + ')');
      }
   }

   static final int I(GSI var0, FT var1, byte var2) {
      try {
         if (1728947183 * var1.F != -1) {
            return 1728947183 * var1.F;
         } else {
            if (var1.D * 324071475 != -1) {
               WCI var3 = var0.LZ.method174(var1.D * 324071475, 1590345714);
               if (!var3.B) {
                  return var3.A;
               }
            }

            return -45966925 * var1.B;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "xt.e(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.a.I(1991711560) == 1 ? 1 : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "xt.ajc(" + ')');
      }
   }
}
