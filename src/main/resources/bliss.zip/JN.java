public class JN {
   public static int I = 1835291189;
   static boolean Z = false;
   static int C = 0;
   static int B = 955770805;
   static int[] D = new int[1003];
   static int[] F = new int[1004];
   static int[] J = new int[1005];
   static IY S = new IY();
   public static int A = 1129029761;
   static boolean E = true;
   static boolean G = false;
   static boolean H = false;
   static int append = 48;
   static int K = 0;
   static PA L;

   JN() throws Throwable {
      throw new Error();
   }

   public static void I(int var0) {
      try {
         XY var1 = null;

         try {
            var1 = OFI.I("", XEI.mD.Z, true, -1804643872);
            REI var2 = FW.J.C(-804179286);
            var1.I(var2.S, 0, var2.A * 385051775, (int)-1257925796);
         } catch (Exception var4) {
            ;
         }

         try {
            if (var1 != null) {
               var1.I(1091393691);
            }
         } catch (Exception var3) {
            ;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ad.f(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         FW.J.I(FW.J.P, var0.H[(var0.J -= -391880689) * 681479919] == 1 ? 1 : 0, -223155318);
         I(656179282);
         QQ.I(1660250591);
         XEI.w = false;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ad.aim(" + ')');
      }
   }

   static final int I(UZI var0, int var1) {
      try {
         if (var0 == null) {
            return 12;
         } else {
            switch(-1062992263 * var0.I) {
            case 3:
               return 20;
            default:
               return 12;
            }
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ad.a(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         String var2 = (String)var0.S[(var0.A -= 969361751) * -203050393];
         if (var2.startsWith(QJ.I((int)0, -278777595)) || var2.startsWith(QJ.I((int)1, -278777595))) {
            var2 = var2.substring(7);
         }

         var0.H[(var0.J += -391880689) * 681479919 - 1] = ZZI.I(var2, -1912416826) ? 1 : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ad.vj(" + ')');
      }
   }
}
