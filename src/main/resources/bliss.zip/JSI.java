import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.util.Iterator;

public class JSI {
   public int I;
   public int Z;
   public int C;
   static REI J;
   public static PO B;

   void I(REI var1, int var2) {
      try {
         while(true) {
            int var3 = var1.I();
            if (var3 == 0) {
               return;
            }

            this.J(var1, var3, 1156077382);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "nq.a(" + ')');
      }
   }

   void J(REI var1, int var2, int var3) {
      try {
         if (1 == var2) {
            this.Z = var1.C() * 2019336269;
            this.I = var1.I() * 2083582845;
            this.C = var1.I() * 627221103;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "nq.f(" + ')');
      }
   }

   public static void I(AP var0, GSI var1, int var2) {
      try {
         Iterator var3 = CQ.A.iterator();

         while(var3.hasNext()) {
            GQ var4 = (GQ)var3.next();
            if (var4.J) {
               var4.I(var0, var1);
            }
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "nq.b(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, int var3) {
      try {
         String var4 = (String)var2.S[(var2.A -= 969361751) * -203050393];
         if (IN.I(var4, var2, -68836416) != null) {
            var4 = var4.substring(0, var4.length() - 1);
         }

         var0.JC = OI.I(var4, var2, -2046058202);
         var0.JZ = true;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "nq.lt(" + ')');
      }
   }

   public static void I(boolean var0, byte[] var1, int var2) {
      try {
         if (J == null) {
            J = new REI(20000);
         }

         J.I((byte[])var1, 0, var1.length, (short)-3701);
         if (var0) {
            ZX.I(J.S, 325303236);
            VY.F = new ZQ[1017276543 * JJ.B];
            int var3 = 0;

            for(int var4 = -1648308965 * SU.I; var4 <= -499146007 * TP.I; ++var4) {
               ZQ var5 = PF.I(var4, (byte)40);
               if (var5 != null) {
                  VY.F[var3++] = var5;
               }
            }

            VY.D = false;
            CP.F = CI.I((byte)1) * -4824082235216898149L;
            J = null;
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "nq.p(" + ')');
      }
   }

   static final boolean I(char var0, int var1) {
      try {
         return var0 == ' ' || var0 == ' ' || var0 == '_' || '-' == var0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "nq.b(" + ')');
      }
   }

   static YG Z(REI var0, int var1) {
      try {
         var0.I();
         int var2 = var0.I();
         YG var3 = IJ.I(var2, (byte)11);
         var3.M = var0.I() * -2127296983;
         int var4 = var0.I();

         for(int var5 = 0; var5 < var4; ++var5) {
            int var6 = var0.I();
            var3.I(var6, var0, (byte)92);
         }

         var3.B(-245700254);
         return var3;
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "nq.u(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         String var2 = "";
         if (PR.c != null) {
            Transferable var3 = PR.c.getContents((Object)null);
            if (var3 != null) {
               try {
                  var2 = (String)var3.getTransferData(DataFlavor.stringFlavor);
                  if (var2 == null) {
                     var2 = "";
                  }
               } catch (Exception var5) {
                  ;
               }
            }
         }

         var0.S[(var0.A += 969361751) * -203050393 - 1] = var2;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "nq.afl(" + ')');
      }
   }

   static void I(int var0) {
      try {
         FX.Z = new YK(VEI.pZ.I(WO.U, -875414210), "", -1808468501 * XEI.aD, 1006, -1, 0L, 0, 0, true, false, 0L, true);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "nq.k(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         int var2 = XEI.fZ[var0.H[(var0.J -= -391880689) * 681479919]].length >> 1;
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var2;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "nq.afz(" + ')');
      }
   }
}
