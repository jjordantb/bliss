public class KEI {
   byte J = 0;
   public int I = -474865427;
   public int Z;
   public int[] C;
   public short[] B;
   public String D = "null";
   short[] KA;
   public int[] F;
   byte[] PA;
   short[] Q;
   public short[] S;
   public int[][] A;
   byte W;
   public int E = 325083707;
   byte X = 0;
   int[] append = null;
   int c = 0;
   public int G = -2019485854;
   public boolean H = false;
   public int K = -455422743;
   public int L = 44056569;
   int f = 242181565;
   public boolean M = false;
   public int N = -2144855351;
   public int O = 1675091776;
   public int P = 0;
   public boolean R = false;
   int[] ga = null;
   public int T = -83909056;
   int ia = 0;
   int m = 0;
   public String[] U;
   public boolean V = false;
   int method250 = 0;
   public int Y = -2064530465;
   public int i = -1406097311;
   public int z = 779127471;
   public int b = -475870643;
   public boolean d = false;
   public int j = 0;
   CX s;
   public boolean a = false;
   public boolean e = true;
   int method252 = -1280568448;
   int method4755 = -319692160;
   public int g = 0;
   public int h = -1763780945;
   public boolean k = false;
   int method5004 = 0;
   int method5017 = 0;
   int method5037 = 0;
   int oa = -1992239744;
   byte p;
   public boolean l = false;
   byte pa;
   public int n = 0;
   int random = 0;
   int toString = 1228374415;
   int wa = 2115564225;
   public int o = 349046175;
   public static short[] q = new short[256];
   public boolean r = true;
   public int t = 2118857365;
   public boolean u = false;
   public int v = 0;
   public int w = 0;
   public int[] x;
   public byte[] y;
   public boolean II = true;
   public boolean ZI = false;
   public boolean CI = true;
   public boolean BI = false;
   JX DI;
   public int FI = 1320066331;
   public int JI = 0;
   public int SI = 1861779200;
   public int AI = 1687920384;
   public boolean EI = false;
   public boolean GI = false;
   static int HI = 127007;

   void J(REI var1, int var2, int var3) {
      try {
         int var4;
         int var5;
         int var6;
         int var7;
         if (1 == var2) {
            var4 = var1.I();
            this.y = new byte[var4];
            this.A = new int[var4][];

            for(var5 = 0; var5 < var4; ++var5) {
               this.y[var5] = var1.S(-12558881);
               var6 = var1.I();
               this.A[var5] = new int[var6];

               for(var7 = 0; var7 < var6; ++var7) {
                  this.A[var5][var7] = var1.Y(1235052657);
               }
            }
         } else if (var2 == 2) {
            this.D = var1.E(-1849485656);
         } else if (14 == var2) {
            this.N = var1.I() * -2144855351;
         } else if (var2 == 15) {
            this.L = var1.I() * 44056569;
         } else if (var2 == 17) {
            this.G = 0;
            this.r = false;
         } else if (var2 == 18) {
            this.r = false;
         } else if (19 == var2) {
            this.K = var1.I() * 455422743;
         } else if (21 == var2) {
            this.J = 1;
         } else if (var2 == 22) {
            this.M = true;
         } else if (var2 == 23) {
            this.E = -325083707;
         } else if (24 == var2) {
            var4 = var1.Y(1235052657);
            if (var4 != -1) {
               this.append = new int[]{var4};
            }
         } else if (var2 == 27) {
            this.G = 1137740721;
         } else if (28 == var2) {
            this.T = (var1.I() << 2) * 803995289;
         } else if (var2 == 29) {
            this.ia = var1.S(-12558881) * -62240291;
         } else if (39 == var2) {
            this.m = var1.S(-12558881) * -1530589831;
         } else if (var2 >= 30 && var2 < 35) {
            this.U[var2 - 30] = var1.E(2140843487);
         } else if (var2 == 40) {
            var4 = var1.I();
            this.KA = new short[var4];
            this.B = new short[var4];

            for(var5 = 0; var5 < var4; ++var5) {
               this.KA[var5] = (short)var1.C();
               this.B[var5] = (short)var1.C();
            }
         } else if (var2 == 41) {
            var4 = var1.I();
            this.Q = new short[var4];
            this.S = new short[var4];

            for(var5 = 0; var5 < var4; ++var5) {
               this.Q[var5] = (short)var1.C();
               this.S[var5] = (short)var1.C();
            }
         } else if (var2 == 42) {
            var4 = var1.I();
            this.PA = new byte[var4];

            for(var5 = 0; var5 < var4; ++var5) {
               this.PA[var5] = var1.S(-12558881);
            }
         } else if (var2 == 62) {
            this.a = true;
         } else if (64 == var2) {
            this.e = false;
         } else if (65 == var2) {
            this.method252 = var1.C() * 929519655;
         } else if (66 == var2) {
            this.method4755 = var1.C() * -1076239419;
         } else if (var2 == 67) {
            this.oa = var1.C() * 1192395179;
         } else if (var2 == 69) {
            var1.I();
         } else if (var2 == 70) {
            this.c = (var1.J(1954619354) << 2) * 804752437;
         } else if (var2 == 71) {
            this.method250 = (var1.J(1981333343) << 2) * -830213317;
         } else if (var2 == 72) {
            this.method5004 = (var1.J(2079097901) << 2) * 1957563615;
         } else if (var2 == 73) {
            this.k = true;
         } else if (var2 == 74) {
            this.l = true;
         } else if (var2 == 75) {
            this.h = var1.I() * 1763780945;
         } else if (77 != var2 && 92 != var2) {
            if (var2 == 78) {
               this.o = var1.C() * -349046175;
               this.g = var1.I() * -634552289;
            } else if (var2 == 79) {
               this.v = var1.C() * 1882310759;
               this.w = var1.C() * 1376401661;
               this.g = var1.I() * -634552289;
               var4 = var1.I();
               this.x = new int[var4];

               for(var5 = 0; var5 < var4; ++var5) {
                  this.x[var5] = var1.C();
               }
            } else if (81 == var2) {
               this.J = 2;
               this.f = var1.I() * -1868938496;
            } else if (var2 == 82) {
               this.ZI = true;
            } else if (88 == var2) {
               this.CI = false;
            } else if (var2 == 89) {
               this.II = false;
            } else if (91 == var2) {
               this.BI = true;
            } else if (var2 == 93) {
               this.J = 3;
               this.f = var1.C() * -242181565;
            } else if (var2 == 94) {
               this.J = 4;
            } else if (95 == var2) {
               this.J = 5;
               this.f = var1.J(2013201622) * -242181565;
            } else if (97 == var2) {
               this.d = true;
            } else if (98 == var2) {
               this.H = true;
            } else if (99 == var2) {
               this.Y = var1.I() * 2064530465;
               this.FI = var1.C() * -1320066331;
            } else if (100 == var2) {
               this.i = var1.I() * 1406097311;
               this.I = var1.C() * 474865427;
            } else if (101 == var2) {
               this.j = var1.I() * 1747447869;
            } else if (var2 == 102) {
               this.b = var1.C() * 475870643;
            } else if (103 == var2) {
               this.E = 0;
            } else if (104 == var2) {
               this.t = var1.I() * 1861040235;
            } else if (var2 == 105) {
               this.EI = true;
            } else if (106 == var2) {
               var4 = var1.I();
               var5 = 0;
               this.append = new int[var4];
               this.ga = new int[var4];

               for(var6 = 0; var6 < var4; ++var6) {
                  this.append[var6] = var1.Y(1235052657);
                  var5 += this.ga[var6] = var1.I();
               }

               for(var6 = 0; var6 < var4; ++var6) {
                  this.ga[var6] = '\uffff' * this.ga[var6] / var5;
               }
            } else if (var2 == 107) {
               this.z = var1.C() * -779127471;
            } else if (var2 >= 150 && var2 < 155) {
               this.U[var2 - 150] = var1.E(67859332);
               if (!this.s.Z) {
                  this.U[var2 - 150] = null;
               }
            } else if (160 == var2) {
               var4 = var1.I();
               this.F = new int[var4];

               for(var5 = 0; var5 < var4; ++var5) {
                  this.F[var5] = var1.C();
               }
            } else if (var2 == 162) {
               this.J = 3;
               this.f = var1.H((byte)30) * -242181565;
            } else if (var2 == 163) {
               this.pa = var1.S(-12558881);
               this.W = var1.S(-12558881);
               this.p = var1.S(-12558881);
               this.X = var1.S(-12558881);
            } else if (var2 == 164) {
               this.method5017 = var1.J(2119621102) * -1121469985;
            } else if (165 == var2) {
               this.method5037 = var1.J(1762145274) * 1097094883;
            } else if (166 == var2) {
               this.random = var1.J(1892618723) * -870210675;
            } else if (var2 == 167) {
               this.n = var1.C() * 597954411;
            } else if (168 == var2) {
               this.u = true;
            } else if (169 == var2) {
               this.V = true;
            } else if (170 == var2) {
               this.O = var1.B(1723054621) * -1277797453;
            } else if (171 == var2) {
               this.P = var1.B(1723054621) * 883280249;
            } else if (var2 == 173) {
               this.SI = var1.C() * 1097791615;
               this.AI = var1.C() * -127624289;
            } else if (var2 == 177) {
               this.R = true;
            } else if (178 == var2) {
               this.JI = var1.I() * -1122029857;
            } else if (var2 == 189) {
               this.GI = true;
            } else if (var2 == 249) {
               var4 = var1.I();
               if (this.DI == null) {
                  var5 = JV.I(var4, (byte)16);
                  this.DI = new JX(var5);
               }

               for(var5 = 0; var5 < var4; ++var5) {
                  boolean var10 = var1.I() == 1;
                  var7 = var1.B((byte)44);
                  Object var8;
                  if (var10) {
                     var8 = new QG(var1.E(-2143557829));
                  } else {
                     var8 = new OK(var1.H((byte)-68));
                  }

                  this.DI.I((AE)var8, (long)var7);
               }
            }
         } else {
            this.toString = var1.C() * -1228374415;
            if (65535 == 1064010385 * this.toString) {
               this.toString = 1228374415;
            }

            this.wa = var1.C() * -2115564225;
            if (65535 == -1128963393 * this.wa) {
               this.wa = 2115564225;
            }

            var4 = -1;
            if (92 == var2) {
               var4 = var1.Y(1235052657);
            }

            var5 = var1.I();
            this.C = new int[2 + var5];

            for(var6 = 0; var6 <= var5; ++var6) {
               this.C[var6] = var1.Y(1235052657);
            }

            this.C[var5 + 1] = var4;
         }

      } catch (RuntimeException var9) {
         throw DQ.I(var9, "rw.f(" + ')');
      }
   }

   public String I(int var1, String var2, int var3) {
      try {
         if (this.DI == null) {
            return var2;
         } else {
            QG var4 = (QG)this.DI.I((long)var1);
            return var4 == null ? var2 : (String)var4.J;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "rw.q(" + ')');
      }
   }

   public final boolean I(int var1, byte var2) {
      try {
         if (this.A == null) {
            return true;
         } else {
            boolean var3 = true;
            KJ var4 = this.s.C;
            synchronized(this.s.C) {
               for(int var5 = 0; var5 < this.y.length; ++var5) {
                  if (this.y[var5] == var1) {
                     for(int var6 = 0; var6 < this.A[var5].length; ++var6) {
                        if (!this.s.C.I(this.A[var5][var6], 0, (int)-1404450418)) {
                           var3 = false;
                        }
                     }
                  }
               }

               return var3;
            }
         }
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "rw.p(" + ')');
      }
   }

   public final boolean I(int var1) {
      try {
         if (this.A == null) {
            return true;
         } else {
            boolean var2 = true;
            KJ var3 = this.s.C;
            synchronized(this.s.C) {
               for(int var4 = 0; var4 < this.A.length; ++var4) {
                  for(int var5 = 0; var5 < this.A[var4].length; ++var5) {
                     var2 &= this.s.C.I(this.A[var4][var5], 0, (int)-1427920512);
                  }
               }

               return var2;
            }
         }
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "rw.i(" + ')');
      }
   }

   public boolean I(int var1, int var2) {
      try {
         if (this.append != null && -1 != var1) {
            for(int var3 = 0; var3 < this.append.length; ++var3) {
               if (this.append[var3] == var1) {
                  return true;
               }
            }
         }

         return false;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "rw.h(" + ')');
      }
   }

   public final synchronized UT I(GSI var1, int var2, int var3, int var4, YJI var5, YJI var6, int var7, int var8, int var9, SX var10, DX var11, byte var12) {
      try {
         if (MQ.I(var3, 1883717056)) {
            var3 = RW.F.V * -1976050083;
         }

         long var13 = (long)(var4 + (var3 << 3) + (1181652947 * this.Z << 10));
         var13 |= (long)(var1.KZ * 580915349 << 29);
         if (var11 != null) {
            var13 |= var11.I * 2595045048596347611L << 32;
         }

         if (var10 != null) {
            var2 |= var10.B(-1790708337);
         }

         if (this.J == 3) {
            var2 |= 7;
         } else {
            if (this.J != 0 || 52797131 * this.method5037 != 0) {
               var2 |= 2;
            }

            if (945504799 * this.method5017 != 0) {
               var2 |= 1;
            }

            if (this.random * 1782732613 != 0) {
               var2 |= 4;
            }
         }

         if (RW.T.V * -1976050083 == var3 && var4 > 3) {
            var2 |= 5;
         }

         JQ var17 = this.s.F;
         UT var16;
         synchronized(this.s.F) {
            var16 = (UT)this.s.F.I(var13);
         }

         if (var16 == null || var1.method5017(var16.m(), var2) != 0) {
            if (var16 != null) {
               var2 = var1.method5004(var2, var16.m());
            }

            var16 = this.KA(var1, var2, var3, var4, var11, 1981902641);
            if (var16 == null) {
               return null;
            }

            var17 = this.s.F;
            synchronized(this.s.F) {
               this.s.F.I(var16, var13);
            }
         }

         boolean var21 = false;
         if (var10 != null) {
            var16 = var16.method4755((byte)1, var2, true);
            var21 = true;
            var10.I(var16, var4 & 3, 1865606525);
         }

         if (var3 == -1976050083 * RW.T.V && var4 > 3) {
            if (!var21) {
               var16 = var16.method4755((byte)3, var2, true);
               var21 = true;
            }

            var16.f(2048);
         }

         if (this.J != 0) {
            if (!var21) {
               var16 = var16.method4755((byte)3, var2, true);
               var21 = true;
            }

            var16.pa(this.J, 1762198123 * this.f, var5, var6, var7, var8, var9);
         }

         if (945504799 * this.method5017 != 0 || this.method5037 * 52797131 != 0 || 1782732613 * this.random != 0) {
            if (!var21) {
               var16 = var16.method4755((byte)3, var2, true);
               var21 = true;
            }

            var16.ia(945504799 * this.method5017, this.method5037 * 52797131, 1782732613 * this.random);
         }

         if (var21) {
            var16.KA(var2);
         }

         return var16;
      } catch (RuntimeException var20) {
         throw DQ.I(var20, "rw.d(" + ')');
      }
   }

   UT KA(GSI var1, int var2, int var3, int var4, DX var5, int var6) {
      try {
         int var7 = this.ia * -1536403851 + 64;
         int var8 = -2019557395 * this.m + 850;
         int var9 = var2;
         boolean var10 = this.a || var3 == RW.C.V * -1976050083 && var4 > 3;
         if (var10) {
            var2 |= 16;
         }

         if (var4 == 0) {
            if (-166422633 * this.method252 != 128 || this.c * -1514641891 != 0) {
               var2 |= 1;
            }

            if (128 != this.oa * -895192829 || 2145431327 * this.method5004 != 0) {
               var2 |= 4;
            }
         } else {
            var2 |= 13;
         }

         if (128 != 668312333 * this.method4755 || this.method250 * 1536191987 != 0) {
            var2 |= 2;
         }

         if (this.KA != null) {
            var2 |= 16384;
         }

         if (this.Q != null) {
            var2 |= 32768;
         }

         if (this.X != 0) {
            var2 |= 524288;
         }

         UT var11 = null;
         int var14;
         if (this.y != null) {
            int var12 = -1;

            for(int var13 = 0; var13 < this.y.length; ++var13) {
               if (var3 == this.y[var13]) {
                  var12 = var13;
                  break;
               }
            }

            if (var12 == -1) {
               return null;
            }

            int[] var28 = var5 != null && var5.B != null ? var5.B : this.A[var12];
            var14 = var28.length;
            if (var14 > 0) {
               long var15 = (long)(580915349 * var1.KZ);

               int var17;
               for(var17 = 0; var17 < var14; ++var17) {
                  var15 = (long)var28[var17] + 67783L * var15;
               }

               JQ var30 = this.s.D;
               synchronized(this.s.D) {
                  var11 = (UT)this.s.D.I(var15);
               }

               if (var11 != null) {
                  if (var7 != var11.c()) {
                     var2 |= 4096;
                  }

                  if (var8 != var11.Z()) {
                     var2 |= 8192;
                  }
               }

               if (var11 == null || var1.method5017(var11.m(), var2) != 0) {
                  var17 = var2 | 127007;
                  if (var11 != null) {
                     var17 = var1.method5004(var17, var11.m());
                  }

                  MBI var18 = null;
                  MBI[] var19 = this.s.I;
                  synchronized(this.s.I) {
                     int var20 = 0;

                     while(true) {
                        if (var20 >= var14) {
                           if (var14 > 1) {
                              var18 = new MBI(this.s.I, var14);
                           }
                           break;
                        }

                        KJ var21 = this.s.C;
                        synchronized(this.s.C) {
                           var18 = MBI.I((KJ)this.s.C, var28[var20], (int)0);
                        }

                        if (var18 == null) {
                           var21 = null;
                           return var21;
                        }

                        if (var18.P < 13) {
                           var18.I(2);
                        }

                        if (var14 > 1) {
                           this.s.I[var20] = var18;
                        }

                        ++var20;
                     }
                  }

                  var11 = var1.method5037(var18, var17, this.s.S * -914670477, var7, var8);
                  JQ var31 = this.s.D;
                  synchronized(this.s.D) {
                     this.s.D.I(var11, var15);
                  }
               }
            }
         }

         if (var11 == null) {
            return null;
         } else {
            UT var27 = var11.method4755((byte)0, var2, true);
            if (var7 != var11.c()) {
               var27.p(var7);
            }

            if (var8 != var11.Z()) {
               var27.Q(var8);
            }

            if (var10) {
               var27.wa();
            }

            if (var3 == RW.F.V * -1976050083 && var4 > 3) {
               var27.S(2048);
               var27.ia(180, 0, -180);
            }

            var4 &= 3;
            if (1 == var4) {
               var27.S(4096);
            } else if (2 == var4) {
               var27.S(8192);
            } else if (var4 == 3) {
               var27.S(12288);
            }

            short[] var29;
            if (this.KA != null) {
               if (var5 != null && var5.C != null) {
                  var29 = var5.C;
               } else {
                  var29 = this.B;
               }

               for(var14 = 0; var14 < this.KA.length; ++var14) {
                  if (this.PA != null && var14 < this.PA.length) {
                     var27.X(this.KA[var14], q[this.PA[var14] & 255]);
                  } else {
                     var27.X(this.KA[var14], var29[var14]);
                  }
               }
            }

            if (this.Q != null) {
               if (var5 != null && var5.Z != null) {
                  var29 = var5.Z;
               } else {
                  var29 = this.S;
               }

               for(var14 = 0; var14 < this.Q.length; ++var14) {
                  var27.W(this.Q[var14], var29[var14]);
               }
            }

            if (this.X != 0) {
               var27.PA(this.pa, this.W, this.p, this.X & 255);
            }

            if (-166422633 * this.method252 != 128 || 668312333 * this.method4755 != 128 || 128 != -895192829 * this.oa) {
               var27.oa(this.method252 * -166422633, this.method4755 * 668312333, this.oa * -895192829);
            }

            if (this.c * -1514641891 != 0 || 1536191987 * this.method250 != 0 || this.method5004 * 2145431327 != 0) {
               var27.ia(-1514641891 * this.c, this.method250 * 1536191987, this.method5004 * 2145431327);
            }

            var27.KA(var9);
            return var27;
         }
      } catch (RuntimeException var26) {
         throw DQ.I(var26, "rw.u(" + ')');
      }
   }

   public int I(int var1, int var2, byte var3) {
      try {
         if (this.DI == null) {
            return var2;
         } else {
            OK var4 = (OK)this.DI.I((long)var1);
            return var4 == null ? var2 : -774922497 * var4.J;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "rw.r(" + ')');
      }
   }

   public final KEI I(FAI var1, int var2) {
      try {
         int var3 = -1;
         if (this.toString * 1064010385 != -1) {
            var3 = var1.method250(this.toString * 1064010385, (byte)36);
         } else if (-1128963393 * this.wa != -1) {
            var3 = var1.method252(this.wa * -1128963393, (byte)99);
         }

         if (var3 >= 0 && var3 < this.C.length - 1 && -1 != this.C[var3]) {
            return this.s.C(this.C[var3]);
         } else {
            int var4 = this.C[this.C.length - 1];
            return -1 != var4 ? this.s.C(var4) : null;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "rw.x(" + ')');
      }
   }

   void Z(int var1) {
      try {
         if (1532834983 * this.K == -1) {
            this.K = 0;
            if (this.y != null && 1 == this.y.length && this.y[0] == RW.T.V * -1976050083) {
               this.K = 455422743;
            }

            for(int var2 = 0; var2 < 5; ++var2) {
               if (this.U[var2] != null) {
                  this.K = 455422743;
                  break;
               }
            }
         }

         if (512737201 * this.h == -1) {
            this.h = 1763780945 * (this.G * -2144543407 != 0 ? 1 : 0);
         }

         if (this.C(934270378) || this.H || this.C != null) {
            this.R = true;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "rw.b(" + ')');
      }
   }

   public boolean C(int var1) {
      try {
         return this.append != null;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "rw.s(" + ')');
      }
   }

   public boolean B(int var1) {
      try {
         return this.append != null && this.append.length > 1;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "rw.z(" + ')');
      }
   }

   public int I(byte var1) {
      try {
         if (this.append != null) {
            if (this.append.length <= 1) {
               return this.append[0];
            }

            int var2 = (int)(Math.random() * 65535.0D);

            for(int var3 = 0; var3 < this.append.length; ++var3) {
               if (var2 <= this.ga[var3]) {
                  return this.append[var3];
               }

               var2 -= this.ga[var3];
            }
         }

         return -1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "rw.y(" + ')');
      }
   }

   public int[] D(int var1) {
      try {
         return this.append;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "rw.t(" + ')');
      }
   }

   void I(REI var1, int var2) {
      try {
         while(true) {
            int var3 = var1.I();
            if (var3 == 0) {
               return;
            }

            this.J(var1, var3, -537941504);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "rw.a(" + ')');
      }
   }

   public boolean F(int var1) {
      try {
         if (this.C == null) {
            return this.o * 393750945 != -1 || this.x != null;
         } else {
            for(int var2 = 0; var2 < this.C.length; ++var2) {
               if (this.C[var2] != -1) {
                  KEI var3 = this.s.C(this.C[var2]);
                  if (-1 != 393750945 * var3.o || var3.x != null) {
                     return true;
                  }
               }
            }

            return false;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "rw.n(" + ')');
      }
   }

   public final synchronized ZY I(GSI var1, int var2, int var3, int var4, YJI var5, YJI var6, int var7, int var8, int var9, boolean var10, DX var11, int var12) {
      try {
         if (MQ.I(var3, -1998635010)) {
            var3 = RW.F.V * -1976050083;
         }

         long var13 = (long)((1181652947 * this.Z << 10) + (var3 << 3) + var4);
         var13 |= (long)(var1.KZ * 580915349 << 29);
         if (var11 != null) {
            var13 |= 2595045048596347611L * var11.I << 32;
         }

         int var15 = var2;
         if (3 == this.J) {
            var15 = var2 | 7;
         } else {
            if (this.J != 0 || 52797131 * this.method5037 != 0) {
               var15 = var2 | 2;
            }

            if (945504799 * this.method5017 != 0) {
               var15 |= 1;
            }

            if (1782732613 * this.random != 0) {
               var15 |= 4;
            }
         }

         if (var10) {
            var15 |= 262144;
         }

         JQ var17 = this.s.J;
         ZY var16;
         synchronized(this.s.J) {
            var16 = (ZY)this.s.J.I(var13);
         }

         UT var24 = (UT)(var16 != null ? var16.I : null);
         GJI var18 = null;
         if (var24 != null && var1.method5017(var24.m(), var15) == 0) {
            var18 = (GJI)var16.Z;
            if (var10 && var18 == null) {
               var18 = (GJI)(var16.Z = var24.ga((GJI)null));
            }
         } else {
            if (var24 != null) {
               var15 = var1.method5004(var15, var24.m());
            }

            int var19 = var15;
            if (var3 == RW.T.V * -1976050083 && var4 > 3) {
               var19 = var15 | 5;
            }

            var24 = this.KA(var1, var19, var3, var4, var11, 1553510063);
            if (var24 == null) {
               return null;
            }

            if (var3 == RW.T.V * -1976050083 && var4 > 3) {
               var24.f(2048);
            }

            if (var10) {
               var18 = var24.ga((GJI)null);
            }

            var24.KA(var15);
            var16 = new ZY(var24, var18);
            JQ var20 = this.s.J;
            synchronized(this.s.J) {
               this.s.J.I(var16, var13);
            }
         }

         boolean var25 = this.J != 0 && (var5 != null || var6 != null);
         boolean var26 = this.method5017 * 945504799 != 0 || this.method5037 * 52797131 != 0 || this.random * 1782732613 != 0;
         if (!var25 && !var26) {
            var24 = var24.method4755((byte)0, var2, true);
         } else {
            var24 = var24.method4755((byte)0, var15, true);
            if (var25) {
               var24.pa(this.J, 1762198123 * this.f, var5, var6, var7, var8, var9);
            }

            if (var26) {
               var24.ia(this.method5017 * 945504799, 52797131 * this.method5037, this.random * 1782732613);
            }

            var24.KA(var2);
         }

         this.s.G.I = var24;
         this.s.G.Z = var18;
         return this.s.G;
      } catch (RuntimeException var23) {
         throw DQ.I(var23, "rw.k(" + ')');
      }
   }

   public static IAI I(REI var0, byte var1) {
      try {
         RP var2 = ZE.I(var0.I(), (byte)-73);
         if (RP.B == var2) {
            return DJ.I(var0, -1749563274);
         } else if (var2 == RP.Z) {
            return BJ.I((REI)var0, (byte)1);
         } else {
            return var2 == RP.I ? NW.I(var0, (byte)-67) : null;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "rw.a(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         if (XEI.ZB != null) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 1;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "rw.ahp(" + ')');
      }
   }

   public static boolean I(char var0, short var1) {
      try {
         return var0 >= '0' && var0 <= '9' || var0 >= 'A' && var0 <= 'Z' || var0 >= 'a' && var0 <= 'z';
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "rw.y(" + ')');
      }
   }

   static void J(int var0) {
      try {
         UN.I((byte)127);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "rw.aa(" + ')');
      }
   }
}
