import java.awt.Dimension;
import java.util.Stack;

public class KP {
   public IR I;
   boolean Z;
   ZP C;
   static Stack B = new Stack();

   public boolean I(GSI var1, int var2, int var3, int var4) {
      try {
         int var5 = this.I.I((byte)34);
         if (this.I.N != null) {
            for(int var6 = 0; var6 < this.I.N.length; ++var6) {
               this.I.N[var6].S <<= var5;
               if (this.I.N[var6].Z(1152678761 * this.C.C + var2, 1804353071 * this.C.I + var3) && this.I.method4350(var1, var2, var3, (byte)1)) {
                  this.I.N[var6].S >>= var5;
                  return true;
               }

               this.I.N[var6].S >>= var5;
            }
         }

         return false;
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "ny.p(" + ')');
      }
   }

   static final void I(OU var0, short var1) {
      try {
         A.I(1451563513);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ny.agj(" + ')');
      }
   }

   static void I(int var0) {
      try {
         if (FT.P.method5051()) {
            FT.P.I(PCI.A, 1231237984);
            XS.I(600492820);
            Dimension var1 = PCI.A.getSize();
            FT.P.I(PCI.A, var1.width, var1.height, 900330778);
            FT.P.I(PCI.A, (byte)-92);
         } else {
            WR.I(FW.J.d.I(-644336063), false, 622850291);
         }

         TQ.Z(-103765582);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "ny.fx(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = Character.toUpperCase((char)var2);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ny.aan(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         KL var3 = GSI.OZ.I(var2, -1382788353);
         if (var3.M == null) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = var3.M.length;
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ny.acj(" + ')');
      }
   }
}
