public interface DEI extends IEI {
}
