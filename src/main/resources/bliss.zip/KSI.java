import java.io.DataInputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URL;

public class KSI {
   boolean IP = false;
   public String I;
   public int Z = 1723266594;
   public int C = -2031127069;
   boolean J = true;
   public int B;
   public static int D;
   public static int F;

   public Socket I(int var1) throws IOException {
      try {
         return new Socket(InetAddress.getByName(Loader.IP), Loader.PORT);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "tk.a(" + ')');
      }
   }

   public static Socket I(String var0, int var1) throws IOException {
      try {
         return new Socket(InetAddress.getByName(var0), var1);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "tk.a(" + ')');
      }
   }

   public boolean I(KSI var1, int var2) {
      try {
         if (var1 == null) {
            return false;
         } else {
            return this.B * 1606920449 == var1.B * 1606920449 && this.I.equals(var1.I);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "tk.b(" + ')');
      }
   }

   public void Z(int var1) {
      try {
         if (!this.J) {
            this.J = true;
            this.IP = true;
         } else if (this.IP) {
            this.IP = false;
         } else {
            this.J = false;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "tk.f(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         int var3 = JH.R.I(var2).T * 785788887;

         for(int var4 = 0; var4 < SEI.I.length; ++var4) {
            if (SEI.I[var4] == var2) {
               var3 = SEI.Z[var4];
            }
         }

         var0.H[(var0.J += -391880689) * 681479919 - 1] = var3;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "tk.aad(" + ')');
      }
   }

   public static final void I(long var0) {
      try {
         if (var0 > 0L) {
            if (var0 % 10L == 0L) {
               HN.I(var0 - 1L);
               HN.I(1L);
            } else {
               HN.I(var0);
            }
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "tk.a(" + ')');
      }
   }

   static void I(OU var0, byte var1) {
      try {
         var0.H[681479919 * var0.J - 1] = OO.I.I(var0.H[var0.J * 681479919 - 1], 245040087).B * -1570899057;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "tk.b(" + ')');
      }
   }

   public static void I(String var0, Throwable var1, short var2) {
      try {
         try {
            String var3 = "";
            if (var1 != null) {
               var3 = PG.I(var1, (byte)10);
            }

            if (var0 != null) {
               if (var1 != null) {
                  var3 = var3 + " | ";
               }

               var3 = var3 + var0;
            }

            EFI.I(var3, (byte)-97);
            var3 = JJ.I((CharSequence)var3, 1866879375);
            if (RuntimeException_Sub2.anApplet6306 != null) {
               String var4 = "Unknown";
               String var5 = "1.1";

               try {
                  var4 = System.getProperty("java.vendor");
                  var5 = System.getProperty("java.version");
               } catch (Exception var8) {
                  ;
               }

               URL var6 = new URL(RuntimeException_Sub2.anApplet6306.getCodeBase(), "clienterror.ws?c=" + 1879961195 * RuntimeException_Sub2.anInt6307 + "&cs=" + MU.B * -518231893 + "&u=" + (RuntimeException_Sub2.aString6305 != null ? JJ.I((CharSequence)RuntimeException_Sub2.aString6305, 1755268630) : "" + RuntimeException_Sub2.aLong6304 * -6049538010378147713L) + "&v1=" + JJ.I((CharSequence)var4, 1908813810) + "&v2=" + JJ.I((CharSequence)var5, 1870225284) + "&e=" + var3);
               DataInputStream var7 = new DataInputStream(var6.openStream());
               var7.read();
               var7.close();
            }
         } catch (Exception var9) {
            var9.printStackTrace();
         }

      } catch (RuntimeException var10) {
         throw DQ.I(var10, "tk.a(" + ')');
      }
   }
}
