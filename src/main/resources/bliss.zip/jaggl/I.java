package jaggl;

import jaclib.memory.NativeBuffer;

public class I extends NativeBuffer {
   private int b;

   public void b(byte[] var1, int var2, int var3, int var4) {
      if (this.b * -569274755 == 0) {
         throw new RuntimeException();
      } else {
         super.b(var1, var2, var3, var4);
      }
   }

   public void p(byte[] var1, int var2, int var3, int var4) {
      if (this.b * -569274755 == 0) {
         throw new RuntimeException();
      } else {
         super.b(var1, var2, var3, var4);
      }
   }

   public void i(byte[] var1, int var2, int var3, int var4) {
      if (this.b * -569274755 == 0) {
         throw new RuntimeException();
      } else {
         super.b(var1, var2, var3, var4);
      }
   }

   public void k(byte[] var1, int var2, int var3, int var4) {
      if (this.b * -569274755 == 0) {
         throw new RuntimeException();
      } else {
         super.b(var1, var2, var3, var4);
      }
   }
}
