public class LF {
   float I;
   float Z;
   float C;
   float B;
   float D;
   float F;
   float J;
   float S;
   float A;
   float E;
   float G;
   float H;
   public static LF K = new LF();

   public LF(LF var1) {
      this.I(var1);
   }

   public void I(ZJ var1) {
      this.cos(var1.Z);
      this.sin(var1.I);
   }

   public void I() {
      this.Z = 0.0F;
      this.H = 0.0F;
      this.I = 0.0F;
      this.A = 0.0F;
      this.S = 0.0F;
      this.J = 0.0F;
      this.D = 0.0F;
      this.B = 0.0F;
      this.G = 0.0F;
      this.E = 1.0F;
      this.F = 1.0F;
      this.C = 1.0F;
   }

   public void I(int var1, int var2, int var3, float var4, float var5, float var6) {
      if (var1 != 0) {
         float var7 = FF.Z[var1 & 16383];
         float var8 = FF.I[var1 & 16383];
         this.E = 1.0F;
         this.A = 0.0F;
         this.S = 0.0F;
         this.J = 0.0F;
         this.B = 0.0F;
         this.C = 2.0F * var7 * (float)var2;
         this.F = 2.0F * var7 * (float)var3;
         this.G = 2.0F * var8 * (float)var2;
         this.D = -2.0F * var8 * (float)var3;
         this.I = (float)(2 * var2) * (0.5F * var8 - 0.5F * var7) + var4;
         this.H = (float)(2 * var3) * (-0.5F * var8 - 0.5F * var7) + var5;
         this.Z = var6;
      } else {
         this.A = 0.0F;
         this.S = 0.0F;
         this.J = 0.0F;
         this.D = 0.0F;
         this.B = 0.0F;
         this.G = 0.0F;
         this.C = (float)(2 * var2);
         this.F = (float)(2 * var3);
         this.E = 1.0F;
         this.I = var4 - (float)var2;
         this.H = var5 - (float)var3;
         this.Z = var6;
      }

   }

   public void I(float var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, float var9) {
      this.C = var1;
      this.D = var4;
      this.S = var7;
      this.I = 0.0F;
      this.G = var2;
      this.F = var5;
      this.A = var8;
      this.H = 0.0F;
      this.B = var3;
      this.J = var6;
      this.E = var9;
      this.Z = 0.0F;
   }

   public void Z() {
      float var1 = this.I;
      float var2 = this.H;
      float var3 = this.D;
      this.D = this.G;
      this.G = var3;
      float var4 = this.S;
      this.S = this.B;
      this.B = var4;
      float var5 = this.A;
      this.A = this.J;
      this.J = var5;
      this.I = -(var1 * this.C + var2 * this.D + this.Z * this.S);
      this.H = -(var1 * this.G + var2 * this.F + this.Z * this.A);
      this.Z = -(var1 * this.B + var2 * this.J + this.Z * this.E);
   }

   public void I(float var1, float var2, float var3, float var4) {
      float var5 = (float)Math.cos((double)var4);
      float var6 = (float)Math.sin((double)var4);
      this.C = var5 + var1 * var1 * (1.0F - var5);
      this.G = var3 * var6 + var2 * var1 * (1.0F - var5);
      this.B = -var2 * var6 + var3 * var1 * (1.0F - var5);
      this.D = -var3 * var6 + var1 * var2 * (1.0F - var5);
      this.F = var5 + var2 * var2 * (1.0F - var5);
      this.J = var1 * var6 + var3 * var2 * (1.0F - var5);
      this.S = var2 * var6 + var1 * var3 * (1.0F - var5);
      this.A = -var1 * var6 + var2 * var3 * (1.0F - var5);
      this.E = var5 + var3 * var3 * (1.0F - var5);
      this.Z = 0.0F;
      this.H = 0.0F;
      this.I = 0.0F;
   }

   public LF() {
      this.I();
   }

   void cos(float var1, float var2, float var3, float var4) {
      float var5 = var1 * var1;
      float var6 = var1 * var2;
      float var7 = var1 * var3;
      float var8 = var1 * var4;
      float var9 = var2 * var2;
      float var10 = var2 * var3;
      float var11 = var2 * var4;
      float var12 = var3 * var3;
      float var13 = var3 * var4;
      this.C = 1.0F - 2.0F * (var9 + var12);
      this.D = 2.0F * (var6 - var13);
      this.S = 2.0F * (var7 + var11);
      this.G = 2.0F * (var6 + var13);
      this.F = 1.0F - 2.0F * (var5 + var12);
      this.A = 2.0F * (var10 - var8);
      this.B = 2.0F * (var7 - var11);
      this.J = 2.0F * (var10 + var8);
      this.E = 1.0F - 2.0F * (var5 + var9);
      this.Z = 0.0F;
      this.H = 0.0F;
      this.I = 0.0F;
   }

   public void I(float var1, float var2, float var3) {
      this.C *= var1;
      this.D *= var1;
      this.S *= var1;
      this.I *= var1;
      this.G *= var2;
      this.F *= var2;
      this.A *= var2;
      this.H *= var2;
      this.B *= var3;
      this.J *= var3;
      this.E *= var3;
      this.Z *= var3;
   }

   public void Z(float var1, float var2, float var3) {
      this.A = 0.0F;
      this.S = 0.0F;
      this.J = 0.0F;
      this.D = 0.0F;
      this.B = 0.0F;
      this.G = 0.0F;
      this.E = 1.0F;
      this.F = 1.0F;
      this.C = 1.0F;
      this.I = var1;
      this.H = var2;
      this.Z = var3;
   }

   void sin(SF var1) {
      this.C(var1.I, var1.C, var1.Z);
   }

   public void C(float var1, float var2, float var3) {
      this.I += var1;
      this.H += var2;
      this.Z += var3;
   }

   public void B(float var1, float var2, float var3) {
      this.C = var1;
      this.D = 0.0F;
      this.S = 0.0F;
      this.I = 0.0F;
      this.G = 0.0F;
      this.F = var2;
      this.A = 0.0F;
      this.H = 0.0F;
      this.B = 0.0F;
      this.J = 0.0F;
      this.E = var3;
      this.Z = 0.0F;
   }

   public void I(float var1, float var2, float var3, float[] var4) {
      var1 -= this.I;
      var2 -= this.H;
      var3 -= this.Z;
      var4[0] = (float)((int)(this.C * var1 + this.G * var2 + this.B * var3));
      var4[1] = (float)((int)(this.D * var1 + this.F * var2 + this.J * var3));
      var4[2] = (float)((int)(this.S * var1 + this.A * var2 + this.E * var3));
   }

   public float[] I(float[] var1) {
      var1[0] = this.I;
      var1[1] = this.H;
      var1[2] = this.Z;
      return var1;
   }

   public void I(LF var1, LF var2) {
      this.C = var1.C * var2.C + var1.G * var2.D + var1.B * var2.S;
      this.G = var1.C * var2.G + var1.G * var2.F + var1.B * var2.A;
      this.B = var1.C * var2.B + var1.G * var2.J + var1.B * var2.E;
      this.D = var1.D * var2.C + var1.F * var2.D + var1.J * var2.S;
      this.F = var1.D * var2.G + var1.F * var2.F + var1.J * var2.A;
      this.J = var1.D * var2.B + var1.F * var2.J + var1.J * var2.E;
      this.S = var1.S * var2.C + var1.A * var2.D + var1.E * var2.S;
      this.A = var1.S * var2.G + var1.A * var2.F + var1.E * var2.A;
      this.E = var1.S * var2.B + var1.A * var2.J + var1.E * var2.E;
      this.I = var1.I * var2.C + var1.H * var2.D + var1.Z * var2.S + var2.I;
      this.H = var1.I * var2.G + var1.H * var2.F + var1.Z * var2.A + var2.H;
      this.Z = var1.I * var2.B + var1.H * var2.J + var1.Z * var2.E + var2.Z;
   }

   public void Z(float[] var1) {
      float var2 = var1[0] - this.I;
      float var3 = var1[1] - this.H;
      float var4 = var1[2] - this.Z;
      var1[0] = (float)((int)(this.C * var2 + this.G * var3 + this.B * var4));
      var1[1] = (float)((int)(this.D * var2 + this.F * var3 + this.J * var4));
      var1[2] = (float)((int)(this.S * var2 + this.A * var3 + this.E * var4));
   }

   public void I(LF var1) {
      this.C = var1.C;
      this.D = var1.D;
      this.S = var1.S;
      this.I = var1.I;
      this.G = var1.G;
      this.F = var1.F;
      this.A = var1.A;
      this.H = var1.H;
      this.B = var1.B;
      this.J = var1.J;
      this.E = var1.E;
      this.Z = var1.Z;
   }

   public void Z(float var1, float var2, float var3, float var4) {
      float var5 = (float)Math.cos((double)var4);
      float var6 = (float)Math.sin((double)var4);
      float var7 = var5 + var1 * var1 * (1.0F - var5);
      float var8 = var3 * var6 + var2 * var1 * (1.0F - var5);
      float var9 = -var2 * var6 + var3 * var1 * (1.0F - var5);
      float var10 = -var3 * var6 + var1 * var2 * (1.0F - var5);
      float var11 = var5 + var2 * var2 * (1.0F - var5);
      float var12 = var1 * var6 + var3 * var2 * (1.0F - var5);
      float var13 = var2 * var6 + var1 * var3 * (1.0F - var5);
      float var14 = -var1 * var6 + var2 * var3 * (1.0F - var5);
      float var15 = var5 + var3 * var3 * (1.0F - var5);
      float var16 = this.C;
      float var17 = this.G;
      float var18 = this.D;
      float var19 = this.F;
      float var20 = this.S;
      float var21 = this.A;
      float var22 = this.I;
      float var23 = this.H;
      this.C = var16 * var7 + var17 * var10 + this.B * var13;
      this.G = var16 * var8 + var17 * var11 + this.B * var14;
      this.B = var16 * var9 + var17 * var12 + this.B * var15;
      this.D = var18 * var7 + var19 * var10 + this.J * var13;
      this.F = var18 * var8 + var19 * var11 + this.J * var14;
      this.J = var18 * var9 + var19 * var12 + this.J * var15;
      this.S = var20 * var7 + var21 * var10 + this.E * var13;
      this.A = var20 * var8 + var21 * var11 + this.E * var14;
      this.E = var20 * var9 + var21 * var12 + this.E * var15;
      this.I = var22 * var7 + var23 * var10 + this.Z * var13;
      this.H = var22 * var8 + var23 * var11 + this.Z * var14;
      this.Z = var22 * var9 + var23 * var12 + this.Z * var15;
   }

   void cos(AF var1) {
      this.cos(var1.Z, var1.I, var1.C, var1.B);
   }

   public void Z(LF var1) {
      float var2 = this.C;
      float var3 = this.G;
      float var4 = this.D;
      float var5 = this.F;
      float var6 = this.S;
      float var7 = this.A;
      float var8 = this.I;
      float var9 = this.H;
      float var10 = this.B;
      float var11 = this.J;
      float var12 = this.E;
      float var13 = this.Z;
      this.C = var2 * var1.C + var3 * var1.D + var10 * var1.S;
      this.G = var2 * var1.G + var3 * var1.F + var10 * var1.A;
      this.B = var2 * var1.B + var3 * var1.J + var10 * var1.E;
      this.D = var4 * var1.C + var5 * var1.D + var11 * var1.S;
      this.F = var4 * var1.G + var5 * var1.F + var11 * var1.A;
      this.J = var4 * var1.B + var5 * var1.J + var11 * var1.E;
      this.S = var6 * var1.C + var7 * var1.D + var12 * var1.S;
      this.A = var6 * var1.G + var7 * var1.F + var12 * var1.A;
      this.E = var6 * var1.B + var7 * var1.J + var12 * var1.E;
      this.I = var8 * var1.C + var9 * var1.D + var13 * var1.S + var1.I;
      this.H = var8 * var1.G + var9 * var1.F + var13 * var1.A + var1.H;
      this.Z = var8 * var1.B + var9 * var1.J + var13 * var1.E + var1.Z;
   }

   public void C(LF var1) {
      if (var1 == this) {
         this.Z();
      } else {
         this.C = var1.C;
         this.D = var1.G;
         this.S = var1.B;
         this.G = var1.D;
         this.F = var1.F;
         this.A = var1.J;
         this.B = var1.S;
         this.J = var1.A;
         this.E = var1.E;
         this.I = -(var1.I * this.C + var1.H * this.D + var1.Z * this.S);
         this.H = -(var1.I * this.G + var1.H * this.F + var1.Z * this.A);
         this.Z = -(var1.I * this.B + var1.H * this.J + var1.Z * this.E);
      }

   }

   public void C(float[] var1) {
      float var2 = var1[0];
      float var3 = var1[1];
      float var4 = var1[2];
      var1[0] = this.C * var2 + this.G * var3 + this.B * var4;
      var1[1] = this.D * var2 + this.F * var3 + this.J * var4;
      var1[2] = this.S * var2 + this.A * var3 + this.E * var4;
   }

   public void Z(ZJ var1) {
      float var2 = var1.Z.B * var1.Z.B;
      float var3 = var1.Z.B * var1.Z.Z;
      float var4 = var1.Z.B * var1.Z.I;
      float var5 = var1.Z.B * var1.Z.C;
      float var6 = var1.Z.Z * var1.Z.Z;
      float var7 = var1.Z.Z * var1.Z.I;
      float var8 = var1.Z.Z * var1.Z.C;
      float var9 = var1.Z.I * var1.Z.I;
      float var10 = var1.Z.I * var1.Z.C;
      float var11 = var1.Z.C * var1.Z.C;
      this.C = var6 + var2 - var11 - var9;
      this.G = var7 + var5 + var7 + var5;
      this.B = var8 - var4 - var4 + var8;
      this.D = var7 - var5 - var5 + var7;
      this.F = var9 + var2 - var6 - var11;
      this.J = var10 + var3 + var10 + var3;
      this.S = var8 + var4 + var8 + var4;
      this.A = var10 - var3 - var3 + var10;
      this.E = var11 + var2 - var9 - var6;
      this.I = var1.I.I;
      this.H = var1.I.C;
      this.Z = var1.I.Z;
   }

   public void Z(float var1, float var2, float var3, float[] var4) {
      var4[0] = this.C * var1 + this.D * var2 + this.S * var3 + this.I;
      var4[1] = this.G * var1 + this.F * var2 + this.A * var3 + this.H;
      var4[2] = this.B * var1 + this.J * var2 + this.E * var3 + this.Z;
   }
}
