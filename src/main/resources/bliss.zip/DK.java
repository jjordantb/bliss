public class DK extends YG {
   int Q = 923324416;
   int R = 1362825216;
   int T = 1367248896;
   static int U = 4096;

   int[][] append(int var1) {
      int[][] var2 = this.L.I(var1, (byte)40);
      if (this.L.I) {
         int[][] var3 = this.I(0, var1, (byte)8);
         int[] var4 = var3[0];
         int[] var5 = var3[1];
         int[] var6 = var3[2];
         int[] var7 = var2[0];
         int[] var8 = var2[1];
         int[] var9 = var2[2];

         for(int var10 = 0; var10 < -1474554145 * WJ.C; ++var10) {
            int var11 = var4[var10];
            int var12 = var6[var10];
            int var13 = var5[var10];
            if (var11 == var12 && var12 == var13) {
               var7[var10] = var11 * this.T * 2015834201 >> 12;
               var8[var10] = 1185665605 * this.Q * var12 >> 12;
               var9[var10] = this.R * -1640278703 * var13 >> 12;
            } else {
               var7[var10] = 2015834201 * this.T;
               var8[var10] = 1185665605 * this.Q;
               var9[var10] = -1640278703 * this.R;
            }
         }
      }

      return var2;
   }

   int[][] I(int var1, byte var2) {
      try {
         int[][] var3 = this.L.I(var1, (byte)20);
         if (this.L.I) {
            int[][] var4 = this.I(0, var1, (byte)8);
            int[] var5 = var4[0];
            int[] var6 = var4[1];
            int[] var7 = var4[2];
            int[] var8 = var3[0];
            int[] var9 = var3[1];
            int[] var10 = var3[2];

            for(int var11 = 0; var11 < -1474554145 * WJ.C; ++var11) {
               int var12 = var5[var11];
               int var13 = var7[var11];
               int var14 = var6[var11];
               if (var12 == var13 && var13 == var14) {
                  var8[var11] = var12 * this.T * 2015834201 >> 12;
                  var9[var11] = 1185665605 * this.Q * var13 >> 12;
                  var10[var11] = this.R * -1640278703 * var14 >> 12;
               } else {
                  var8[var11] = 2015834201 * this.T;
                  var9[var11] = 1185665605 * this.Q;
                  var10[var11] = -1640278703 * this.R;
               }
            }
         }

         return var3;
      } catch (RuntimeException var15) {
         throw DQ.I(var15, "ahy.k(" + ')');
      }
   }

   void I(int var1, REI var2, byte var3) {
      try {
         switch(var1) {
         case 0:
            this.T = var2.C() * -280684567;
            break;
         case 1:
            this.Q = var2.C() * -11308915;
            break;
         case 2:
            this.R = var2.C() * -1844112463;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ahy.r(" + ')');
      }
   }

   void toString(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.T = var2.C() * -280684567;
         break;
      case 1:
         this.Q = var2.C() * -11308915;
         break;
      case 2:
         this.R = var2.C() * -1844112463;
      }

   }

   public DK() {
      super(1, false);
   }

   void B(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.T = var2.C() * -280684567;
         break;
      case 1:
         this.Q = var2.C() * -11308915;
         break;
      case 2:
         this.R = var2.C() * -1844112463;
      }

   }

   int[][] toString(int var1) {
      int[][] var2 = this.L.I(var1, (byte)112);
      if (this.L.I) {
         int[][] var3 = this.I(0, var1, (byte)8);
         int[] var4 = var3[0];
         int[] var5 = var3[1];
         int[] var6 = var3[2];
         int[] var7 = var2[0];
         int[] var8 = var2[1];
         int[] var9 = var2[2];

         for(int var10 = 0; var10 < -1474554145 * WJ.C; ++var10) {
            int var11 = var4[var10];
            int var12 = var6[var10];
            int var13 = var5[var10];
            if (var11 == var12 && var12 == var13) {
               var7[var10] = var11 * this.T * 2015834201 >> 12;
               var8[var10] = 1185665605 * this.Q * var12 >> 12;
               var9[var10] = this.R * -1640278703 * var13 >> 12;
            } else {
               var7[var10] = 2015834201 * this.T;
               var8[var10] = 1185665605 * this.Q;
               var9[var10] = -1640278703 * this.R;
            }
         }
      }

      return var2;
   }

   static void I(SSI var0, int var1, int var2, int var3, int var4) {
      try {
         EQ var5 = var0.C(-1083725964);
         SX var6 = var0.a;
         int var7 = 2145248039 * var0.i - 259411823 * var0.n.I & 16383;
         if (var1 == NA.B.C) {
            if (var7 == 0 && -1766897795 * var0.QI <= 25) {
               if (!var0.y || !var5.I(var6.Z(2113533366), (byte)-97)) {
                  var6.I(var5.I(-2063556157), false, true, (byte)102);
                  var0.y = var6.I((byte)-64);
               }
            } else if (var3 < 0 && -1 != 844607405 * var5.D) {
               var6.I(var5.D * 844607405, false, true, (byte)-57);
               var0.y = false;
            } else if (var3 > 0 && 1061677153 * var5.V != -1) {
               var6.I(1061677153 * var5.V, false, true, (byte)72);
               var0.y = false;
            } else if (!var0.y || !var5.I(var6.Z(1935756712), (byte)-121)) {
               var6.I(var5.I(-2063556157), false, true, (byte)-2);
               var0.y = var0.a.I((byte)-119);
            }
         } else if (1433412323 * var0.u != -1 && (var7 >= 10240 || var7 <= 2048)) {
            int var8 = XEI.ND[var2] - var0.n.I * 259411823 & 16383;
            if (var1 == NA.Z.C && -1 != var5.G * 230243963) {
               if (var8 > 2048 && var8 <= 6144 && -783166629 * var5.L != -1) {
                  var6.I(-783166629 * var5.L, false, true, (byte)-2);
               } else if (var8 >= 10240 && var8 < 14336 && var5.e * -2054940183 != -1) {
                  var6.I(var5.e * -2054940183, false, true, (byte)-60);
               } else if (var8 > 6144 && var8 < 10240 && -1 != 491753731 * var5.k) {
                  var6.I(491753731 * var5.k, false, true, (byte)-111);
               } else {
                  var6.I(230243963 * var5.G, false, true, (byte)-65);
               }
            } else if (var1 == NA.D.C && var5.q * 328817727 != -1) {
               if (var8 > 2048 && var8 <= 6144 && -1 != var5.P * 124010991) {
                  var6.I(var5.P * 124010991, false, true, (byte)110);
               } else if (var8 >= 10240 && var8 < 14336 && var5.O * -907666203 != -1) {
                  var6.I(var5.O * -907666203, false, true, (byte)16);
               } else if (var8 > 6144 && var8 < 10240 && -1 != -1238642279 * var5.H) {
                  var6.I(var5.H * -1238642279, false, true, (byte)-13);
               } else {
                  var6.I(328817727 * var5.q, false, true, (byte)-50);
               }
            } else if (var8 > 2048 && var8 <= 6144 && -1 != var5.K * -1532631215) {
               var6.I(var5.K * -1532631215, false, true, (byte)-29);
            } else if (var8 >= 10240 && var8 < 14336 && -1 != 315374861 * var5.A) {
               var6.I(315374861 * var5.A, false, true, (byte)-38);
            } else if (var8 > 6144 && var8 < 10240 && var5.d * -277799803 != -1) {
               var6.I(-277799803 * var5.d, false, true, (byte)-37);
            } else {
               var6.I(var5.S * -129111857, false, true, (byte)9);
            }

            var0.y = false;
         } else if (var7 == 0 && var0.QI * -1766897795 <= 25) {
            if (var1 == NA.Z.C && 230243963 * var5.G != -1) {
               var6.I(230243963 * var5.G, false, true, (byte)42);
            } else if (NA.D.C == var1 && var5.q * 328817727 != -1) {
               var6.I(var5.q * 328817727, false, true, (byte)5);
            } else {
               var6.I(-129111857 * var5.S, false, true, (byte)-42);
            }

            var0.y = false;
         } else {
            if (var1 == NA.Z.C && -1 != 230243963 * var5.G) {
               if (var3 < 0 && -1 != 1885772191 * var5.T) {
                  var6.I(1885772191 * var5.T, false, true, (byte)69);
               } else if (var3 > 0 && var5.c * 914130409 != -1) {
                  var6.I(var5.c * 914130409, false, true, (byte)28);
               } else {
                  var6.I(230243963 * var5.G, false, true, (byte)95);
               }
            } else if (NA.D.C == var1 && 328817727 * var5.q != -1) {
               if (var3 < 0 && 371497673 * var5.Q != -1) {
                  var6.I(var5.Q * 371497673, false, true, (byte)-21);
               } else if (var3 > 0 && var5.j * -279532195 != -1) {
                  var6.I(-279532195 * var5.j, false, true, (byte)114);
               } else {
                  var6.I(328817727 * var5.q, false, true, (byte)-43);
               }
            } else if (var3 < 0 && -1 != var5.i * 250017959) {
               var6.I(var5.i * 250017959, false, true, (byte)28);
            } else if (var3 > 0 && -1 != var5.R * -119373935) {
               var6.I(var5.R * -119373935, false, true, (byte)72);
            } else {
               var6.I(-129111857 * var5.S, false, true, (byte)-16);
            }

            var0.y = false;
         }

      } catch (RuntimeException var9) {
         throw DQ.I(var9, "ahy.ir(" + ')');
      }
   }
}
