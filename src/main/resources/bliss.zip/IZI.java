import java.util.LinkedList;

public class IZI {
   public int I = 1895598080;
   public int Z = 0;
   public int C = 757188608;
   public int B = 0;

   void I(REI var1, int var2) {
      try {
         while(true) {
            int var3 = var1.I();
            if (var3 == 0) {
               return;
            }

            this.append(var1, var3, (byte)112);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ui.a(" + ')');
      }
   }

   void append(REI var1, int var2, byte var3) {
      try {
         if (var2 == 1) {
            this.B = var1.I() * 248827265;
         } else if (2 == var2) {
            this.C = var1.C() * 258319417;
         } else if (3 == var2) {
            this.I = var1.C() * -819060847;
         } else if (var2 == 4) {
            this.Z = var1.J(1649788845) * -1244481247;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ui.f(" + ')');
      }
   }

   public static void I(KJ var0, int var1) {
      try {
         CQ.B = 0;
         CQ.H = 0;
         CQ.A = new LinkedList();
         CQ.Z = new ON[1024];
         CQ.D = new GQ[1 + NBI.I[1197525581 * CQ.I]];
         CQ.F = 0;
         CQ.J = 0;
         P.I(var0, (byte)-107);
         G.I(var0, 679109105);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ui.a(" + ')');
      }
   }

   static boolean I(int var0, byte var1) {
      try {
         return 44 == var0 || var0 == 45 || 46 == var0 || 47 == var0 || 48 == var0 || 49 == var0 || 50 == var0 || var0 == 51 || 52 == var0 || 53 == var0 || var0 == 15;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ui.bl(" + ')');
      }
   }

   public static char I(byte var0, int var1) {
      try {
         int var2 = var0 & 255;
         if (var2 == 0) {
            throw new IllegalArgumentException("" + Integer.toString(var2, 16));
         } else {
            if (var2 >= 128 && var2 < 160) {
               char var3 = EV.I[var2 - 128];
               if (var3 == 0) {
                  var3 = '?';
               }

               var2 = var3;
            }

            return (char)var2;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ui.p(" + ')');
      }
   }
}
