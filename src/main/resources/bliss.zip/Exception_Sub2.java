public class Exception_Sub2 extends Exception {
   public Exception_Sub2(String var1) {
      super(var1);
   }

   public static int method274(byte var0) {
      try {
         return W.I * 332512427;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "aet.s(" + ')');
      }
   }
}
