public interface BAI {
   int method242(int var1);

   int method243();

   int method244();
}
