public final class HV {
   static char[] I = new char[]{'_', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
   static long[] Z = new long[12];
   static WZI C;
   static int B;

   static {
      for(int var0 = 0; var0 < Z.length; ++var0) {
         Z[var0] = (long)Math.pow(37.0D, (double)var0);
      }

   }

   HV() throws Throwable {
      throw new Error();
   }

   public static void I(int var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      try {
         EE var8 = null;

         for(EE var9 = (EE)EE.G.Z(1766612795); var9 != null; var9 = (EE)EE.G.B(49146)) {
            if (2108312995 * var9.E == var0 && 634196087 * var9.A == var1 && -2146829167 * var9.L == var2 && var3 == -431456739 * var9.N) {
               var8 = var9;
               break;
            }
         }

         if (var8 == null) {
            var8 = new EE();
            var8.E = var0 * -196260341;
            var8.N = var3 * 1088435253;
            var8.A = 656787783 * var1;
            var8.L = var2 * 284247153;
            if (var1 >= 0 && var2 >= 0 && var1 < XEI.mI.Z(-1908372692) && var2 < XEI.mI.C(629047644)) {
               V.I(var8, -162957807);
            }

            EE.G.I((AE)var8, (int)1633204361);
         }

         var8.M = 240885009 * var4;
         var8.H = var5 * 998055383;
         var8.S = 1034640391 * var6;
         var8.P = true;
         var8.Q = false;
      } catch (RuntimeException var10) {
         throw DQ.I(var10, "rk.a(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = XEI.PD[var2].C * 1383593425;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "rk.yf(" + ')');
      }
   }

   public static final void I(int var0) {
      try {
         EE var1;
         for(var1 = (EE)EE.G.Z(1766612795); var1 != null; var1 = (EE)EE.G.B(49146)) {
            if (!var1.Q) {
               var1.P = true;
               if (634196087 * var1.A >= 0 && var1.L * -2146829167 >= 0 && 634196087 * var1.A < XEI.mI.Z(-1871526843) && var1.L * -2146829167 < XEI.mI.C(-1895886966)) {
                  V.I(var1, 147943234);
               }
            } else {
               var1.I(-1460969981);
            }
         }

         for(var1 = (EE)EE.T.Z(1766612795); var1 != null; var1 = (EE)EE.T.B(49146)) {
            if (!var1.Q) {
               var1.P = true;
            } else {
               var1.I(-1460969981);
            }
         }

      } catch (RuntimeException var2) {
         throw DQ.I(var2, "rk.b(" + ')');
      }
   }
}
