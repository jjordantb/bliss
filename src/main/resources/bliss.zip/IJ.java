import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InvalidClassException;
import java.io.ObjectInputStream;
import java.io.OptionalDataException;
import java.io.StreamCorruptedException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class IJ {
   static int I = 0;
   static int Z = 0;
   static IBI[] C;

   IJ() throws Throwable {
      throw new Error();
   }

   static void I(String var0, String var1, int var2, int var3, int var4, long var5, int var7, int var8, boolean var9, boolean var10, long var11, boolean var13, int var14) {
      try {
         if (!FX.G && -278777595 * FX.k < 521) {
            var2 = var2 != -1 ? var2 : XEI.aD * -1808468501;
            YK var15 = new YK(var0, var1, var2, var3, var4, var5, var7, var8, var9, var10, var11, var13);
            NA.I(var15, 1640099092);
         }

      } catch (RuntimeException var16) {
         throw DQ.I(var16, "jw.y(" + ')');
      }
   }

   public static void I(int var0) {
      try {
         if (VF.C != null) {
            TSI[] var1 = VF.C;

            for(int var2 = 0; var2 < var1.length; ++var2) {
               TSI var3 = var1[var2];
               var3.method150(-1773131058);
            }
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "jw.i(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)60);
         X var4 = IU.F[var2 >> 16];
         WBI.I(var3, var4, var0, -1168214437);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "jw.nm(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = XEI.PD[var2].I * 535421071;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jw.ya(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         var0.J -= -783761378;
         int var2 = var0.H[var0.J * 681479919];
         int var3 = var0.H[1 + 681479919 * var0.J];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var2 % var3;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "jw.zu(" + ')');
      }
   }

   static final void I(OU var0, short var1) {
      try {
         DDI.I(var0.H[(var0.J -= -391880689) * 681479919], -1, -1, false, 752651181);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jw.adl(" + ')');
      }
   }

   static final void B(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.L.I(-2145285486);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jw.ajz(" + ')');
      }
   }

   public static void I(QEI var0, int var1) {
      try {
         LM var2 = (LM)III.I.Z(1766612795);
         if (var2 != null) {
            int var3 = 385051775 * var0.A;
            var0.B(-1886044647 * var2.L, -169937628);

            for(int var4 = 0; var4 < 719522345 * var2.E; ++var4) {
               if (var2.S[var4] != 0) {
                  var0.F(var2.S[var4]);
               } else {
                  try {
                     int var5 = var2.A[var4];
                     Field var6;
                     int var7;
                     if (var5 == 0) {
                        var6 = var2.G[var4];
                        var7 = var6.getInt((Object)null);
                        var0.F(0);
                        var0.B(var7, -1175769775);
                     } else if (var5 == 1) {
                        var6 = var2.G[var4];
                        var6.setInt((Object)null, var2.J[var4]);
                        var0.F(0);
                     } else if (var5 == 2) {
                        var6 = var2.G[var4];
                        var7 = var6.getModifiers();
                        var0.F(0);
                        var0.B(var7, -2147062003);
                     }

                     Method var24;
                     if (var5 != 3) {
                        if (var5 == 4) {
                           var24 = var2.K[var4];
                           var7 = var24.getModifiers();
                           var0.F(0);
                           var0.B(var7, -187993349);
                        }
                     } else {
                        var24 = var2.K[var4];
                        byte[][] var25 = var2.H[var4];
                        Object[] var8 = new Object[var25.length];

                        for(int var9 = 0; var9 < var25.length; ++var9) {
                           ObjectInputStream var10 = new ObjectInputStream(new ByteArrayInputStream(var25[var9]));
                           var8[var9] = var10.readObject();
                        }

                        Object var26 = var24.invoke((Object)null, var8);
                        if (var26 == null) {
                           var0.F(0);
                        } else if (var26 instanceof Number) {
                           var0.F(1);
                           var0.Z(((Number)var26).longValue());
                        } else if (var26 instanceof String) {
                           var0.F(2);
                           var0.I((String)var26, 2146946191);
                        } else {
                           var0.F(4);
                        }
                     }
                  } catch (ClassNotFoundException var11) {
                     var0.F(-10);
                  } catch (InvalidClassException var12) {
                     var0.F(-11);
                  } catch (StreamCorruptedException var13) {
                     var0.F(-12);
                  } catch (OptionalDataException var14) {
                     var0.F(-13);
                  } catch (IllegalAccessException var15) {
                     var0.F(-14);
                  } catch (IllegalArgumentException var16) {
                     var0.F(-15);
                  } catch (InvocationTargetException var17) {
                     var0.F(-16);
                  } catch (SecurityException var18) {
                     var0.F(-17);
                  } catch (IOException var19) {
                     var0.F(-18);
                  } catch (NullPointerException var20) {
                     var0.F(-19);
                  } catch (Exception var21) {
                     var0.F(-20);
                  } catch (Throwable var22) {
                     var0.F(-21);
                  }
               }
            }

            var0.S(var3, -184215611);
            var2.I(-1460969981);
         }

      } catch (RuntimeException var23) {
         throw DQ.I(var23, "jw.b(" + ')');
      }
   }

   static YG I(int var0, byte var1) {
      try {
         switch(var0) {
         case 0:
            return new TH();
         case 1:
            return new ZH();
         case 2:
            return new DH();
         case 3:
            return new XH();
         case 4:
            return new KK();
         case 5:
            return new UH();
         case 6:
            return new NH();
         case 7:
            return new RH();
         case 8:
            return new WH();
         case 9:
            return new LK();
         case 10:
            return new MH();
         case 11:
            return new DK();
         case 12:
            return new GH();
         case 13:
            return new FH();
         case 14:
            return new FK();
         case 15:
            return new EH();
         case 16:
            return new LH();
         case 17:
            return new AK();
         case 18:
            return new BH();
         case 19:
            return new HH();
         case 20:
            return new AH();
         case 21:
            return new PH();
         case 22:
            return new JH();
         case 23:
            return new QH();
         case 24:
            return new HK();
         case 25:
            return new GK();
         case 26:
            return new IK();
         case 27:
            return new SK();
         case 28:
            return new ZK();
         case 29:
            return new KH();
         case 30:
            return new SH();
         case 31:
            return new YH();
         case 32:
            return new OH();
         case 33:
            return new BK();
         case 34:
            return new CK();
         case 35:
            return new IH();
         case 36:
            return new VH();
         case 37:
            return new JK();
         case 38:
            return new EK();
         case 39:
            return new CH();
         default:
            return null;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jw.d(" + ')');
      }
   }

   public static void Z(int var0) {
      try {
         if (!RD.I) {
            LEI.I(XEI.mI.T(-1611682495).H, 234916861);
            if (XEI.mI.T(-1611682495).L != null) {
               LEI.I(XEI.mI.T(-1611682495).L, -1747837187);
            }

            RD.I = true;
         }

      } catch (RuntimeException var2) {
         throw DQ.I(var2, "jw.a(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, byte var3) {
      try {
         boolean var4 = var2.H[(var2.J -= -391880689) * 681479919] == 1;
         if (var0.n != var4) {
            var0.n = var4;
            VEI.I(var0, -1214371857);
         }

         if (-1 == -1309843523 * var0.a && !var1.I) {
            BV.I(-440872681 * var0.V, (short)945);
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "jw.ct(" + ')');
      }
   }
}
