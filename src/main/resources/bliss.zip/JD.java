public class JD {
   short I;
   byte Z;
   short C;
   short B;
   int D = -1;
   short F;
   short J;
}
