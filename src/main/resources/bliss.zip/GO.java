public class GO implements XSI {
   DR Z;
   static int I;

   public boolean method228(ZR var1) {
      return this.Z == var1;
   }

   GO(DR var1) {
      this.Z = var1;
   }

   public boolean method229(ZR var1, int var2) {
      try {
         return this.Z == var1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "mw.a(" + ')');
      }
   }

   public boolean method230(ZR var1) {
      return this.Z == var1;
   }

   static int I(ZQ var0, ZQ var1, int var2, boolean var3, int var4, boolean var5, int var6) {
      try {
         int var7 = OD.I(var0, var1, var2, var3, -1657159001);
         if (var7 != 0) {
            return var3 ? -var7 : var7;
         } else if (-1 == var4) {
            return 0;
         } else {
            int var8 = OD.I(var0, var1, var4, var5, -552551191);
            return var5 ? -var8 : var8;
         }
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "mw.r(" + ')');
      }
   }

   static void I(GSI var0, int var1) {
      try {
         int var2 = -10660793;
         YO.I(var0, -1347746885 * QFI.I, PN.E * 1089948687, ZZ.H * 608683427, UX.I * 1396607435, var2, -16777216, (byte)123);
         D.I.I(VEI.OZ.I(WO.U, -875414210), -1347746885 * QFI.I + 3, 1089948687 * PN.E + 14, var2, -1, (int)1583712486);
         int var3 = UC.Z.method3894((byte)-10);
         int var4 = UC.Z.method3883((byte)38);
         int var5;
         YK var6;
         int var7;
         if (!FX.D) {
            var5 = 0;

            for(var6 = (YK)FX.K.Z(1766612795); var6 != null; var6 = (YK)FX.K.B(49146)) {
               var7 = 31 + 1089948687 * PN.E + -411680299 * FX.C * (-278777595 * FX.k - 1 - var5);
               GSI.I(var3, var4, -1347746885 * QFI.I, 1089948687 * PN.E, 608683427 * ZZ.H, 1396607435 * UX.I, var7, var6, D.I, YDI.D, -1, -256, 247690373);
               ++var5;
            }
         } else {
            var5 = 0;

            for(EL var9 = (EL)FX.M.Z(198728515); var9 != null; var9 = (EL)FX.M.C(30142288)) {
               var7 = PN.E * 1089948687 + 31 + var5 * -411680299 * FX.C;
               if (1 == var9.G * -628325139) {
                  GSI.I(var3, var4, -1347746885 * QFI.I, PN.E * 1089948687, 608683427 * ZZ.H, UX.I * 1396607435, var7, (YK)var9.H.I.S, D.I, YDI.D, -1, -256, 1821923505);
               } else {
                  OBI.I(var3, var4, QFI.I * -1347746885, 1089948687 * PN.E, ZZ.H * 608683427, UX.I * 1396607435, var7, var9, D.I, YDI.D, -1, -256, (byte)-19);
               }

               ++var5;
            }

            if (FX.F != null) {
               YO.I(var0, EY.C * 805710735, -1370784315 * GZI.I, 2054409059 * HV.B, -1855216229 * IU.J, var2, -16777216, (byte)111);
               D.I.I(FX.F.K, 805710735 * EY.C + 3, -1370784315 * GZI.I + 14, var2, -1, (int)-2064340267);
               var5 = 0;

               for(var6 = (YK)FX.F.H.Z(-783790871); var6 != null; var6 = (YK)FX.F.H.C(505275870)) {
                  var7 = var5 * -411680299 * FX.C + GZI.I * -1370784315 + 31;
                  GSI.I(var3, var4, 805710735 * EY.C, -1370784315 * GZI.I, 2054409059 * HV.B, IU.J * -1855216229, var7, var6, D.I, YDI.D, -1, -256, 916241136);
                  ++var5;
               }
            }
         }

      } catch (RuntimeException var8) {
         throw DQ.I(var8, "mw.ar(" + ')');
      }
   }
}
