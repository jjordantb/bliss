public class HL extends QK {
   JX append;

   void Z(REI var1, int var2) {
      try {
         while(true) {
            int var3 = var1.I();
            if (var3 == 0) {
               return;
            }

            this.I(var1, var3, 1595820905);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aim.a(" + ')');
      }
   }

   public int I(int var1, int var2, short var3) {
      try {
         if (this.append == null) {
            return var2;
         } else {
            OK var4 = (OK)this.append.I((long)var1);
            return var4 == null ? var2 : var4.J * -774922497;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aim.b(" + ')');
      }
   }

   void I(REI var1, int var2, int var3) {
      try {
         if (var2 == 249) {
            int var4 = var1.I();
            int var5;
            if (this.append == null) {
               var5 = JV.I(var4, (byte)16);
               this.append = new JX(var5);
            }

            for(var5 = 0; var5 < var4; ++var5) {
               boolean var6 = var1.I() == 1;
               int var7 = var1.B((byte)-75);
               Object var8;
               if (var6) {
                  var8 = new QG(var1.E(281550837));
               } else {
                  var8 = new OK(var1.H((byte)-72));
               }

               this.append.I((AE)var8, (long)var7);
            }
         }

      } catch (RuntimeException var9) {
         throw DQ.I(var9, "aim.f(" + ')');
      }
   }

   public String I(int var1, String var2, byte var3) {
      try {
         if (this.append == null) {
            return var2;
         } else {
            QG var4 = (QG)this.append.I((long)var1);
            return var4 == null ? var2 : (String)var4.J;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aim.p(" + ')');
      }
   }

   public static void I(SSI var0, int[] var1, int[] var2, int[] var3, int var4) {
      try {
         for(int var5 = 0; var5 < var1.length; ++var5) {
            int var6 = var1[var5];
            int var7 = var3[var5];
            int var8 = var2[var5];

            for(int var9 = 0; var7 != 0 && var9 < var0.OI.length; var7 >>>= 1) {
               if ((var7 & 1) != 0) {
                  if (-1 == var6) {
                     var0.OI[var9] = null;
                  } else {
                     BU var10 = GZI.C.I(var6, (byte)-80);
                     int var11 = var10.N * -1117238071;
                     GX var12 = var0.OI[var9];
                     if (var12 != null && var12.I((byte)-110)) {
                        if (var6 == var12.Z(1502559146)) {
                           if (var11 == 0) {
                              var0.OI[var9] = null;
                              var12 = null;
                           } else if (var11 == 1) {
                              var12.F(83585082);
                              var12.K = -731066289 * var8;
                           } else if (2 == var11) {
                              var12.J(1476401100);
                           }
                        } else if (-1445588039 * var10.E >= var12.I(595695662).E * -1445588039) {
                           var0.OI[var9] = null;
                           var12 = null;
                        }
                     }

                     if (var12 == null || !var12.I((byte)-3)) {
                        var12 = var0.OI[var9] = new GX(var0);
                        var12.I(var6, -1608832147);
                        var12.K = -731066289 * var8;
                     }
                  }
               }

               ++var9;
            }
         }

      } catch (RuntimeException var13) {
         throw DQ.I(var13, "aim.ix(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         String var2 = (String)var0.S[(var0.A -= 969361751) * -203050393];
         int var3 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.S[(var0.A += 969361751) * -203050393 - 1] = var2 + NI.I(var3, true, (byte)8);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aim.zy(" + ')');
      }
   }
}
