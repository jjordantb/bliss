import jagdx.IDirect3DDevice;
import jagdx.IDirect3DIndexBuffer;
import jagdx.IUnknown;

public class CD implements PAI {
   PJI CreateIndexBuffer;
   int Lock;
   int Release;
   boolean Unlock;
   SDI Upload;
   long I = 0L;

   CD(PJI var1, SDI var2, boolean var3) {
      this.CreateIndexBuffer = var1;
      this.Upload = var2;
      this.Unlock = var3;
      this.CreateIndexBuffer.Z(this);
   }

   public void I(int var1) {
      this.Release = this.Upload.S * 685647847 * var1;
      if (this.Release > this.Lock) {
         if (this.I != 0L) {
            IUnknown.Release(this.I);
         }

         int var2 = 8;
         byte var3;
         if (this.Unlock) {
            var3 = 0;
            var2 |= 512;
         } else {
            var3 = 1;
         }

         this.I = IDirect3DDevice.CreateIndexBuffer(this.CreateIndexBuffer.FZ, this.Release, var2, this.Upload == SDI.B ? 101 : 102, var3);
         this.Lock = this.Release;
      }

   }

   public void method115(int var1) {
      this.Release = this.Upload.S * 685647847 * var1;
      if (this.Release > this.Lock) {
         if (this.I != 0L) {
            IUnknown.Release(this.I);
         }

         int var2 = 8;
         byte var3;
         if (this.Unlock) {
            var3 = 0;
            var2 |= 512;
         } else {
            var3 = 1;
         }

         this.I = IDirect3DDevice.CreateIndexBuffer(this.CreateIndexBuffer.FZ, this.Release, var2, this.Upload == SDI.B ? 101 : 102, var3);
         this.Lock = this.Release;
      }

   }

   public void method69() {
      IDirect3DIndexBuffer.Unlock(this.I);
   }

   public boolean method63(int var1, int var2, long var3) {
      return jagdx.S.f(IDirect3DIndexBuffer.Upload(this.I, var1, var2, this.Unlock ? 8192 : 0, var3));
   }

   public void b() {
      if (this.I != 0L) {
         IUnknown.Release(this.I);
         this.I = 0L;
      }

      this.Lock = 0;
      this.Release = 0;
      this.CreateIndexBuffer.I((QAI)this);
   }

   void CreateIndexBuffer() {
      if (this.I != 0L) {
         this.CreateIndexBuffer.Z(this.I);
         this.I = 0L;
      }

      this.Lock = 0;
      this.Release = 0;
   }

   public int method60() {
      return this.Release;
   }

   public void d() {
      if (this.I != 0L) {
         IUnknown.Release(this.I);
         this.I = 0L;
      }

      this.Lock = 0;
      this.Release = 0;
      this.CreateIndexBuffer.I((QAI)this);
   }

   public void x() {
      if (this.I != 0L) {
         IUnknown.Release(this.I);
         this.I = 0L;
      }

      this.Lock = 0;
      this.Release = 0;
      this.CreateIndexBuffer.I((QAI)this);
   }

   public long method62(int var1, int var2) {
      return IDirect3DIndexBuffer.Lock(this.I, var1, var2, this.Unlock ? 8192 : 0);
   }

   public int method65() {
      return this.Release;
   }

   public boolean method61(int var1, int var2, long var3) {
      return jagdx.S.f(IDirect3DIndexBuffer.Upload(this.I, var1, var2, this.Unlock ? 8192 : 0, var3));
   }

   public boolean method67(int var1, int var2, long var3) {
      return jagdx.S.f(IDirect3DIndexBuffer.Upload(this.I, var1, var2, this.Unlock ? 8192 : 0, var3));
   }

   public void u() {
      if (this.I != 0L) {
         IUnknown.Release(this.I);
         this.I = 0L;
      }

      this.Lock = 0;
      this.Release = 0;
      this.CreateIndexBuffer.I((QAI)this);
   }

   public long method68(int var1, int var2) {
      return IDirect3DIndexBuffer.Lock(this.I, var1, var2, this.Unlock ? 8192 : 0);
   }

   public void method112(int var1) {
      this.Release = this.Upload.S * 685647847 * var1;
      if (this.Release > this.Lock) {
         if (this.I != 0L) {
            IUnknown.Release(this.I);
         }

         int var2 = 8;
         byte var3;
         if (this.Unlock) {
            var3 = 0;
            var2 |= 512;
         } else {
            var3 = 1;
         }

         this.I = IDirect3DDevice.CreateIndexBuffer(this.CreateIndexBuffer.FZ, this.Release, var2, this.Upload == SDI.B ? 101 : 102, var3);
         this.Lock = this.Release;
      }

   }

   public void method114(int var1) {
      this.Release = this.Upload.S * 685647847 * var1;
      if (this.Release > this.Lock) {
         if (this.I != 0L) {
            IUnknown.Release(this.I);
         }

         int var2 = 8;
         byte var3;
         if (this.Unlock) {
            var3 = 0;
            var2 |= 512;
         } else {
            var3 = 1;
         }

         this.I = IDirect3DDevice.CreateIndexBuffer(this.CreateIndexBuffer.FZ, this.Release, var2, this.Upload == SDI.B ? 101 : 102, var3);
         this.Lock = this.Release;
      }

   }

   public int method64() {
      return this.Release;
   }

   public void method116(int var1) {
      this.Release = this.Upload.S * 685647847 * var1;
      if (this.Release > this.Lock) {
         if (this.I != 0L) {
            IUnknown.Release(this.I);
         }

         int var2 = 8;
         byte var3;
         if (this.Unlock) {
            var3 = 0;
            var2 |= 512;
         } else {
            var3 = 1;
         }

         this.I = IDirect3DDevice.CreateIndexBuffer(this.CreateIndexBuffer.FZ, this.Release, var2, this.Upload == SDI.B ? 101 : 102, var3);
         this.Lock = this.Release;
      }

   }

   public void method66() {
      IDirect3DIndexBuffer.Unlock(this.I);
   }
}
