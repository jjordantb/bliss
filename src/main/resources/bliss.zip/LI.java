public class LI extends EI {
   void method1414(boolean var1, int var2, int var3) {
      int var4 = this.I(-580739090) * -944287579 * this.C.D / 10000;
      FT.P.B(var2, 2 + var3, var4, this.C.A * -1387457793 - 2, ((OI)this.C).G * 457840037, 0);
      FT.P.B(var2 + var4, 2 + var3, this.C.D * -944287579 - var4, this.C.A * -1387457793 - 2, 0, 0);
   }

   void method1411(boolean var1, int var2, int var3, int var4) {
      try {
         int var5 = this.I(-191128334) * -944287579 * this.C.D / 10000;
         FT.P.B(var2, 2 + var3, var5, this.C.A * -1387457793 - 2, ((OI)this.C).G * 457840037, 0);
         FT.P.B(var2 + var5, 2 + var3, this.C.D * -944287579 - var5, this.C.A * -1387457793 - 2, 0, 0);
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "zu.r(" + ')');
      }
   }

   LI(KJ var1, KJ var2, OI var3) {
      super(var1, var2, var3);
   }

   void method1413(boolean var1, int var2, int var3) {
      int var4 = this.I(1604037601) * -944287579 * this.C.D / 10000;
      FT.P.B(var2, 2 + var3, var4, this.C.A * -1387457793 - 2, ((OI)this.C).G * 457840037, 0);
      FT.P.B(var2 + var4, 2 + var3, this.C.D * -944287579 - var4, this.C.A * -1387457793 - 2, 0, 0);
   }

   void method1415(boolean var1, int var2, int var3) {
      int var4 = this.I(1183027095) * -944287579 * this.C.D / 10000;
      FT.P.B(var2, 2 + var3, var4, this.C.A * -1387457793 - 2, ((OI)this.C).G * 457840037, 0);
      FT.P.B(var2 + var4, 2 + var3, this.C.D * -944287579 - var4, this.C.A * -1387457793 - 2, 0, 0);
   }

   void method1416(boolean var1, int var2, int var3) {
      int var4 = this.I(1484742879) * -944287579 * this.C.D / 10000;
      FT.P.B(var2, 2 + var3, var4, this.C.A * -1387457793 - 2, ((OI)this.C).G * 457840037, 0);
      FT.P.B(var2 + var4, 2 + var3, this.C.D * -944287579 - var4, this.C.A * -1387457793 - 2, 0, 0);
   }

   void method1412(boolean var1, int var2, int var3, int var4) {
      try {
         FT.P.method5019(var2 - 2, var3, this.C.D * -944287579 + 4, 2 + -1387457793 * this.C.A, -1393292711 * ((OI)this.C).H, 0);
         FT.P.method5019(var2 - 1, 1 + var3, this.C.D * -944287579 + 2, -1387457793 * this.C.A, 0, 0);
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "zu.x(" + ')');
      }
   }

   void method1410(boolean var1, int var2, int var3) {
      FT.P.method5019(var2 - 2, var3, this.C.D * -944287579 + 4, 2 + -1387457793 * this.C.A, -1393292711 * ((OI)this.C).H, 0);
      FT.P.method5019(var2 - 1, 1 + var3, this.C.D * -944287579 + 2, -1387457793 * this.C.A, 0, 0);
   }

   void method1409(boolean var1, int var2, int var3) {
      FT.P.method5019(var2 - 2, var3, this.C.D * -944287579 + 4, 2 + -1387457793 * this.C.A, -1393292711 * ((OI)this.C).H, 0);
      FT.P.method5019(var2 - 1, 1 + var3, this.C.D * -944287579 + 2, -1387457793 * this.C.A, 0, 0);
   }

   void method1417(boolean var1, int var2, int var3) {
      FT.P.method5019(var2 - 2, var3, this.C.D * -944287579 + 4, 2 + -1387457793 * this.C.A, -1393292711 * ((OI)this.C).H, 0);
      FT.P.method5019(var2 - 1, 1 + var3, this.C.D * -944287579 + 2, -1387457793 * this.C.A, 0, 0);
   }

   static int I(QEI var0, int var1) {
      try {
         int var2 = var0.C(2);
         int var3;
         if (var2 == 0) {
            var3 = 0;
         } else if (var2 == 1) {
            var3 = var0.C(5);
         } else if (var2 == 2) {
            var3 = var0.C(8);
         } else {
            var3 = var0.C(11);
         }

         return var3;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "zu.p(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         String var3 = (String)var0.S[(var0.A -= 969361751) * -203050393];
         if (-1 == var2) {
            throw new RuntimeException();
         } else {
            DSI var4 = QZI.C.I(var2, 1528209569);
            if (var4.I != 's') {
               throw new RuntimeException();
            } else {
               var0.H[(var0.J += -391880689) * 681479919 - 1] = var4.I((Object)var3, (byte)88) ? 1 : 0;
            }
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "zu.va(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         var0.K -= -1365138610;
         if (var0.Q[var0.K * 1685767703] >= var0.Q[1685767703 * var0.K + 1]) {
            var0.i += 286750741 * var0.X[var0.i * 1883543357];
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "zu.bu(" + ')');
      }
   }

   public static void Z(int var0) {
      try {
         AN.G = new SE[50];
         AN.E = 0;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "zu.u(" + ')');
      }
   }
}
