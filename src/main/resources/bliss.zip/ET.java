public class ET {
   JQ C = new JQ(64);
   public int I = 0;
   public int Z;
   KJ append;
   static int B;
   public static LG D;

   public FT I(int var1, int var2) {
      try {
         JQ var4 = this.C;
         FT var3;
         synchronized(this.C) {
            var3 = (FT)this.C.I((long)var1);
         }

         if (var3 != null) {
            return var3;
         } else {
            KJ var5 = this.append;
            byte[] var10;
            synchronized(this.append) {
               var10 = this.append.I(II.d.y * -1006924897, var1, (byte)-18);
            }

            var3 = new FT();
            var3.H = this;
            var3.I = 1723715693 * var1;
            if (var10 != null) {
               var3.I(new REI(var10), 690302848);
            }

            var3.I((byte)75);
            JQ var11 = this.C;
            synchronized(this.C) {
               this.C.I(var3, (long)var1);
            }

            return var3;
         }
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "pp.a(" + ')');
      }
   }

   public ET(ZV var1, XW var2, KJ var3) {
      this.append = var3;
      this.Z = this.append.F(-1006924897 * II.d.y, 774356441) * 1970250293;
   }

   public void I(byte var1) {
      try {
         JQ var2 = this.C;
         synchronized(this.C) {
            this.C.Z();
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "pp.p(" + ')');
      }
   }

   public void I(int var1, byte var2) {
      try {
         JQ var3 = this.C;
         synchronized(this.C) {
            this.C.I(var1, -1937713048);
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "pp.b(" + ')');
      }
   }

   public void Z(byte var1) {
      try {
         JQ var2 = this.C;
         synchronized(this.C) {
            this.C.I();
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "pp.f(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.J -= -1175642067;
         int var2 = var0.H[var0.J * 681479919];
         int var3 = var0.H[1 + var0.J * 681479919];
         int var4 = var0.H[681479919 * var0.J + 2];
         if (var3 == -1) {
            throw new RuntimeException();
         } else {
            DSI var5 = QZI.C.I(var3, 1528209569);
            if (var5.I != var2) {
               throw new RuntimeException();
            } else {
               int[] var6 = var5.I((Object)var4, (short)19520);
               int var7 = 0;
               if (var6 != null) {
                  var7 = var6.length;
               }

               var0.H[(var0.J += -391880689) * 681479919 - 1] = var7;
            }
         }
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "pp.vs(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         String var2 = (String)var0.S[(var0.A -= 969361751) * -203050393];
         YP.I((String)var2, (byte)62);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "pp.vl(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         if (YX.I && WF.O != null) {
            OQ.I(FW.J.J.Z((byte)70), -1, -1, false, -489329335);
         }

         if (IU.I((byte)35) == CE.I) {
            OCI.I(1556288352);
            System.exit(0);
         } else {
            V.I(-849889720);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "pp.afq(" + ')');
      }
   }

   static int I(PEI var0, int var1) {
      try {
         int var2 = 1899133595 * var0.IZ;
         EQ var3 = var0.C(657972326);
         int var4 = var0.a.Z(1741170329);
         if (-1 != var4 && !var0.y) {
            if (var3.G * 230243963 != var4 && var4 != var3.k * 491753731 && var3.L * -783166629 != var4 && var4 != var3.e * -2054940183) {
               if (var4 == var3.q * 328817727 || -1238642279 * var3.H == var4 || 124010991 * var3.P == var4 || -907666203 * var3.O == var4) {
                  var2 = var0.yI * -1304250511;
               }
            } else {
               var2 = var0.ZZ * -978842273;
            }
         } else {
            var2 = 1728220219 * var0.hI;
         }

         return var2;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "pp.r(" + ')');
      }
   }

   static void I(int var0) {
      try {
         if (JU.I(-185972710)) {
            if (GDI.A == null) {
               DT.C(-219758847);
            }

            GDI.E = true;
            GDI.I = 0;
         }

      } catch (RuntimeException var2) {
         throw DQ.I(var2, "pp.f(" + ')');
      }
   }

   static final void I(int var0, int var1, byte var2) {
      try {
         if (XEI.mD != ZV.I) {
            if (!BFI.I(var0, var1, false, NA.I(var0, var1, 1, 1, 1978833308), -1273389367)) {
               BFI.I(var0, var1, false, CP.I(var0, var1, 1, 1, 0, (byte)-5), 1260408128);
            }
         } else if (!BFI.I(var0, var1, false, CP.I(var0, var1, 1, 1, 0, (byte)-71), 301836586)) {
            BFI.I(var0, var1, false, NA.I(var0, var1, 1, 1, 1349485510), 605242163);
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "pp.jv(" + ')');
      }
   }
}
