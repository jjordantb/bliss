public class JJ implements TAI {
   int I;
   int Z;
   int[] C;
   public static int B;

   public void x() {
   }

   public int a() {
      try {
         return this.I * 215983317;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "ay.a(" + ')');
      }
   }

   public int f() {
      try {
         return 467687639 * this.Z;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "ay.f(" + ')');
      }
   }

   public void b() {
   }

   public int p() {
      return this.I * 215983317;
   }

   public int i() {
      return this.I * 215983317;
   }

   public int k() {
      return 467687639 * this.Z;
   }

   public void d() {
   }

   JJ(int var1, int var2, int[] var3) {
      this.I = -1649642371 * var1;
      this.Z = var2 * 159783655;
      this.C = var3;
   }

   public void u() {
   }

   static final void I(OU var0, int var1) {
      try {
         String var2 = (String)var0.S[(var0.A -= 969361751) * -203050393];
         BW.I(var2, (short)-2610);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ay.sk(" + ')');
      }
   }

   public static String I(CharSequence var0, int var1) {
      try {
         int var2 = var0.length();
         StringBuilder var3 = new StringBuilder(var2);

         for(int var4 = 0; var4 < var2; ++var4) {
            char var5 = var0.charAt(var4);
            if ((var5 < 'a' || var5 > 'z') && (var5 < 'A' || var5 > 'Z') && (var5 < '0' || var5 > '9') && var5 != '.' && '-' != var5 && var5 != '*' && var5 != '_') {
               if (' ' == var5) {
                  var3.append('+');
               } else {
                  byte var6 = JI.I(var5, 1088430238);
                  var3.append('%');
                  int var7 = var6 >> 4 & 15;
                  if (var7 >= 10) {
                     var3.append((char)(55 + var7));
                  } else {
                     var3.append((char)(48 + var7));
                  }

                  var7 = var6 & 15;
                  if (var7 >= 10) {
                     var3.append((char)(55 + var7));
                  } else {
                     var3.append((char)(48 + var7));
                  }
               }
            } else {
               var3.append(var5);
            }
         }

         return var3.toString();
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "ay.f(" + ')');
      }
   }

   public static MI I(REI var0, int var1) {
      try {
         PI var2 = (PI)WS.I(var0, (byte)-97);
         int var3 = var0.J(1551160069);
         return new QI(var2.I, var2.Z, var2.F * -39975161, 1886882435 * var2.B, var2.D * -944287579, var2.A * -1387457793, -684094775 * var2.J, 955568089 * var2.S, 782326281 * var2.C, -876812375 * var2.K, 1551490597 * var2.H, 578265259 * var2.N, 861652881 * var2.L, -1259370861 * var2.M, 356687159 * var2.G, var3);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ay.q(" + ')');
      }
   }
}
