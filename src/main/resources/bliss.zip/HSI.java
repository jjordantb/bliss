import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class HSI {
   short[] KA;
   public static int I = -100407581;
   public Object[] Z;
   public static int C = -1904191576;
   public Object[] B;
   public static int D = 196278887;
   public int F = 0;
   public static int J = -256176781;
   public static int S = -1056295064;
   public static int A = -569549655;
   public static int E = 1370710423;
   public static int G = 1219781210;
   public static int H = -8749061;
   public static int K = 1611206784;
   public static int L = -1933463779;
   public int M;
   public static int TRUE = 5;
   public static JQ N = new JQ(3000000, 200);
   static JQ O = new JQ(8);
   public Object[] P;
   public static JQ Q = new JQ(50);
   public static boolean R = false;
   public int T = -908204397;
   public int U;
   public int V = -533296807;
   public int W = 0;
   public int X;
   public int Y = 0;
   public byte i = 0;
   public byte z = 0;
   public byte c = 0;
   public byte b = 0;
   public Object[] d;
   public int f;
   public SX j;
   public int s = 0;
   public int a = 263105643;
   public int e = 0;
   public int g = 0;
   public Object[] h;
   public int k = 349940087;
   public int l = 0;
   public int m = 1171161349;
   public boolean n = false;
   public int o = 0;
   public int p = -1830595391;
   public Object[] q;
   public boolean r = false;
   public int t = 0;
   public int u = 0;
   public int v = 0;
   public int w = 0;
   public int x = 0;
   public boolean y = false;
   public Object[] II;
   public int ZI = -1041514725;
   public boolean CI = false;
   public int BI = -1986266571;
   public int DI;
   public Object[] FI;
   public int JI = 0;
   public int SI = -2021607495;
   public boolean AI;
   public boolean EI;
   public boolean GI = false;
   public boolean HI = true;
   public int KI = -1530138943;
   public byte[] LI;
   public boolean MI = false;
   public boolean NI;
   public int[] OI;
   public int[] PI;
   public int QI = 0;
   public int RI = 0;
   public int TI = 0;
   public int UI = 0;
   public int VI = 0;
   public String[] WI;
   public boolean XI = false;
   public int YI;
   public int iI = 0;
   public boolean zI = false;
   public Object[] cI;
   public int bI = -1251584190;
   public int dI;
   short[] TYPE;
   short[] aClass243_6310;
   public static int append = 5;
   public static int fI = 1654605574;
   public int jI;
   public int sI;
   public Object[] aI;
   public int eI = 2074006897;
   public boolean gI = true;
   public String hI = "";
   public boolean kI;
   public int lI = 0;
   public int mI;
   public boolean nI = false;
   public int oI = 0;
   public GQ pI;
   public OL qI;
   public boolean rI;
   public int tI = 0;
   public byte[] uI;
   public int vI = 0;
   public static int contains = 1;
   public static int equals = 2;
   public static int getDeclaredField = 4;
   public static int getDeclaredMethod = 8;
   public String wI;
   public Object[] xI;
   public String yI;
   public int[] IZ;
   public int ZZ;
   public HSI CZ;
   short[] invoke;
   public int BZ;
   public int DZ;
   public String FZ;
   public boolean JZ;
   public int SZ;
   public Object[] AZ;
   public int EZ;
   public int GZ = 153098785;
   public Object[] HZ;
   public Object[] KZ;
   public Object[] LZ;
   public boolean MZ = false;
   public Object[] NZ;
   public int OZ = 0;
   public Object[] PZ;
   public Object[] QZ;
   public int RZ = 0;
   public int TZ;
   public int UZ = 0;
   public int[] VZ;
   public Object[] WZ;
   public int[] XZ;
   public Object[] YZ;
   public int[] iZ;
   public String zZ;
   public int[] cZ;
   public Object[] bZ;
   public int dZ = 0;
   public Object[] fZ;
   public Object[] jZ;
   public static int sZ = 232770470;
   public static int aZ = 0;
   public Object[] eZ;
   public Object[] gZ;
   public static int hZ = -196322511;
   public Object[] kZ;
   public Object[] lZ;
   public int mZ = 1122372539;
   public Object[] nZ;
   public Object[] oZ;
   public Object[] pZ;
   public int[] qZ;
   public Object[] rZ;
   public int tZ;
   JX method4728;
   public int uZ;
   public int vZ;
   public int wZ = 0;
   public int xZ;
   public int yZ = 769085500;
   public Object[] IC;
   public int ZC = 0;
   public Object[] CC;
   public int BC;
   public int DC;
   public int FC;
   public Object[] JC;
   public HSI[] SC;
   public HSI[] AC;
   public boolean EC;
   public boolean GC;
   static JQ HC = new JQ(4);
   public int KC = 0;
   public int LC;
   public int MC;
   public int NC;
   public int OC;
   public int PC;
   public int QC;
   public int RC;
   public int[] TC;
   public int UC = 0;
   public FZI VC;

   static void KA(int var0) {
      try {
         Class var1 = ClassLoader.class;
         Field var2 = var1.getDeclaredField("nativeLibraries");
         Class var3 = AccessibleObject.class;
         Method var4 = var3.getDeclaredMethod("setAccessible", Boolean.TYPE);
         var4.invoke(var2, Boolean.TRUE);
      } catch (Throwable var5) {
         ;
      }

   }

   public String I(int var1, String var2, int var3) {
      try {
         if (this.method4728 == null) {
            return var2;
         } else {
            QG var4 = (QG)this.method4728.I((long)var1);
            return var4 == null ? var2 : (String)var4.J;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "eg.aa(" + ')');
      }
   }

   void I(REI var1, int var2) {
      try {
         int var3 = var1.I();
         if (var3 == 255) {
            var3 = -1;
         }

         this.X = var1.I() * -800405999;
         if ((-1215239439 * this.X & 128) != 0) {
            this.X = -800405999 * (this.X * -1215239439 & 127);
            this.zZ = var1.E(-53135184);
         }

         this.Y = var1.C() * -680446123;
         this.ZC = var1.J(1719356411) * 2145953887;
         this.l = var1.J(2010058143) * 1215865909;
         this.UZ = var1.C() * -478399925;
         this.s = var1.C() * -1661995333;
         this.c = var1.S(-12558881);
         this.b = var1.S(-12558881);
         this.i = var1.S(-12558881);
         this.z = var1.S(-12558881);
         this.m = var1.C() * -1171161349;
         if (65535 == this.m * 1573706803) {
            this.m = 1171161349;
         } else {
            this.m = (this.m * 1573706803 + (-440872681 * this.V & -65536)) * -1171161349;
         }

         int var4 = var1.I();
         this.n = (var4 & 1) != 0;
         if (var3 >= 0) {
            this.r = (var4 & 2) != 0;
         }

         if (this.X * -1215239439 == 0) {
            this.v = var1.C() * -1609060375;
            this.w = var1.C() * -1638942269;
            if (var3 < 0) {
               this.r = var1.I() == 1;
            }
         }

         int var5;
         if (-1215239439 * this.X == 5) {
            this.BI = var1.H((byte)91) * 1986266571;
            this.UC = var1.C() * -216431639;
            var5 = var1.I();
            this.XI = (var5 & 1) != 0;
            this.GI = (var5 & 2) != 0;
            this.vI = var1.I() * 728904583;
            this.JI = var1.I() * 1158843261;
            this.RZ = var1.H((byte)-62) * -1448553585;
            this.AI = var1.I() == 1;
            this.EI = var1.I() == 1;
            this.x = var1.H((byte)-1) * -695431873;
            if (var3 >= 3) {
               this.HI = var1.I() == 1;
            }
         }

         if (6 == -1215239439 * this.X) {
            this.KI = -1530138943;
            this.f = var1.Y(1235052657) * -1825442367;
            var5 = var1.I();
            boolean var6 = 1 == (var5 & 1);
            this.NI = (var5 & 2) == 2;
            this.zI = 4 == (var5 & 4);
            this.MI = 8 == (var5 & 8);
            if (var6) {
               this.UI = var1.J(1863144228) * 437213185;
               this.VI = var1.J(1761728846) * 1266800241;
               this.QI = var1.C() * -801721775;
               this.dZ = var1.C() * 1590511671;
               this.TI = var1.C() * -2064327287;
               this.yZ = var1.C() * -1066050969;
            } else if (this.NI) {
               this.UI = var1.J(1670425609) * 437213185;
               this.VI = var1.J(1566977554) * 1266800241;
               this.wZ = var1.J(1594666911) * -1324973519;
               this.QI = var1.C() * -801721775;
               this.dZ = var1.C() * 1590511671;
               this.TI = var1.C() * -2064327287;
               this.yZ = var1.J(1622637773) * -1066050969;
            }

            this.FC = var1.Y(1235052657) * 1587382585;
            if (this.c != 0) {
               this.tI = var1.C() * 1811727251;
            }

            if (this.b != 0) {
               this.iI = var1.C() * 1572578003;
            }
         }

         if (this.X * -1215239439 == 4) {
            this.eI = var1.Y(1235052657) * -2074006897;
            if (var3 >= 2) {
               this.gI = var1.I() == 1;
            }

            this.hI = var1.E(332948556);
            if (this.hI.toLowerCase().contains("runescape")) {
               this.hI = this.hI.replace("runescape", "BlissScape");
               this.hI = this.hI.replace("RuneScape", "BlissScape");
               this.hI = this.hI.replace("Runescape", "BlissScape");
            }

            if (this.hI.toLowerCase().contains("or log in with")) {
               this.hI = "<br>Enter a new username or password<br> to create an account";
            }

            if (this.hI.toLowerCase().contains("opens a popup window")) {
               this.hI = "";
            }

            if (this.hI.toLowerCase().contains("create account now")) {
               this.hI = "";
            }

            if (this.hI.toLowerCase().contains("recover your password")) {
               this.hI = this.hI.replace("Recover Your Password", "Forgot your Password?");
            }

            if (this.hI.toLowerCase().contains("login:")) {
               this.hI = "Login or Email:";
            }

            this.RI = var1.I() * 1629063197;
            this.lI = var1.I() * -1733811909;
            this.F = var1.I() * 210030285;
            this.nI = var1.I() == 1;
            this.x = var1.H((byte)30) * -695431873;
            this.vI = var1.I() * 728904583;
            if (var3 >= 0) {
               this.oI = var1.I() * -1455284437;
            }
         }

         if (3 == -1215239439 * this.X) {
            this.x = var1.H((byte)-80) * -695431873;
            this.y = var1.I() == 1;
            this.vI = var1.I() * 728904583;
         }

         if (9 == -1215239439 * this.X) {
            this.ZI = var1.I() * -1041514725;
            this.x = var1.H((byte)-33) * -695431873;
            this.CI = var1.I() == 1;
         }

         var5 = var1.B((byte)8);
         int var17 = var1.I();
         int var7;
         if (var17 != 0) {
            this.LI = new byte[11];
            this.uI = new byte[11];

            for(this.qZ = new int[11]; var17 != 0; var17 = var1.I()) {
               var7 = (var17 >> 4) - 1;
               var17 = var17 << 8 | var1.I();
               var17 &= 4095;
               if (var17 == 4095) {
                  var17 = -1;
               }

               byte var8 = var1.S(-12558881);
               if (var8 != 0) {
                  this.rI = true;
               }

               byte var9 = var1.S(-12558881);
               this.qZ[var7] = var17;
               this.LI[var7] = var8;
               this.uI[var7] = var9;
            }
         }

         this.wI = var1.E(506985626);
         var7 = var1.I();
         int var18 = var7 & 15;
         int var19 = var7 >> 4;
         int var10;
         if (var18 > 0) {
            this.WI = new String[var18];

            for(var10 = 0; var10 < var18; ++var10) {
               this.WI[var10] = var1.E(-1637502084);
            }
         }

         int var11;
         if (var19 > 0) {
            var10 = var1.I();
            this.IZ = new int[1 + var10];

            for(var11 = 0; var11 < this.IZ.length; ++var11) {
               this.IZ[var11] = -1;
            }

            this.IZ[var10] = var1.C();
         }

         if (var19 > 1) {
            var10 = var1.I();
            this.IZ[var10] = var1.C();
         }

         this.yI = var1.E(-1953229569);
         if (this.yI.equals("")) {
            this.yI = null;
         }

         this.SZ = var1.I() * 476443207;
         this.BZ = var1.I() * -978869921;
         this.DZ = var1.I() * 2138287179;
         this.FZ = var1.E(-1171596112);
         var10 = -1;
         if (WBI.Z(var5, (byte)111) != 0) {
            var10 = var1.C();
            if (var10 == 65535) {
               var10 = -1;
            }

            this.SI = var1.C() * 2021607495;
            if (-2051415689 * this.SI == 65535) {
               this.SI = -2021607495;
            }

            this.p = var1.C() * 1830595391;
            if (65535 == this.p * -1149188929) {
               this.p = -1830595391;
            }
         }

         if (var3 >= 0) {
            this.mZ = var1.C() * -1122372539;
            if (65535 == -1200030067 * this.mZ) {
               this.mZ = 1122372539;
            }
         }

         this.qI = new OL(var5, var10);
         if (var3 >= 0) {
            var11 = var1.I();

            int var12;
            int var13;
            int var14;
            for(var12 = 0; var12 < var11; ++var12) {
               var13 = var1.B((byte)10);
               var14 = var1.H((byte)29);
               this.method4728.I(new OK(var14), (long)var13);
            }

            var12 = var1.I();

            for(var13 = 0; var13 < var12; ++var13) {
               var14 = var1.B((byte)19);
               String var15 = var1.T(681479919);
               this.method4728.I(new QG(var15), (long)var14);
            }
         }

         this.YZ = this.TRUE(var1, 422796707);
         this.KZ = this.TRUE(var1, 1852122968);
         this.B = this.TRUE(var1, 747815110);
         this.Z = this.TRUE(var1, -1548123654);
         this.PZ = this.TRUE(var1, 1097191149);
         this.FI = this.TRUE(var1, 1634014672);
         this.II = this.TRUE(var1, -756661481);
         this.WZ = this.TRUE(var1, 1661043786);
         this.aI = this.TRUE(var1, 1194567641);
         this.jZ = this.TRUE(var1, 1382442228);
         if (var3 >= 0) {
            this.NZ = this.TRUE(var1, -699098198);
         }

         this.LZ = this.TRUE(var1, 1910073926);
         this.AZ = this.TRUE(var1, 1197869623);
         this.fZ = this.TRUE(var1, -894827658);
         this.d = this.TRUE(var1, 281193138);
         this.HZ = this.TRUE(var1, -2041361593);
         this.JC = this.TRUE(var1, 138548004);
         this.P = this.TRUE(var1, 756814807);
         this.xI = this.TRUE(var1, 22261945);
         this.cI = this.TRUE(var1, -354820234);
         this.h = this.TRUE(var1, 749663504);
         this.OI = this.TYPE(var1, 1930385253);
         this.VZ = this.TYPE(var1, 1885577185);
         this.XZ = this.TYPE(var1, 2036299454);
         this.iZ = this.TYPE(var1, 1866337228);
         this.cZ = this.TYPE(var1, 1808578494);
      } catch (RuntimeException var16) {
         throw DQ.I(var16, "eg.x(" + ')');
      }
   }

   Object[] TRUE(REI var1, int var2) {
      try {
         int var3 = var1.I();
         if (var3 == 0) {
            return null;
         } else {
            Object[] var4 = new Object[var3];

            for(int var5 = 0; var5 < var3; ++var5) {
               int var6 = var1.I();
               if (var6 == 0) {
                  var4[var5] = new Integer(var1.H((byte)52));
               } else if (var6 == 1) {
                  var4[var5] = var1.E(1069755759);
               }
            }

            this.JZ = true;
            return var4;
         }
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "eg.r(" + ')');
      }
   }

   public OS I(BD var1, QSI var2, int var3) {
      try {
         OS var4 = (OS)var1.I(var2, 1508815983 * this.eI, false, this.gI, -2063324548);
         R = var4 == null;
         return var4;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "eg.s(" + ')');
      }
   }

   public LZI I(BD var1, QSI var2, byte var3) {
      try {
         LZI var4 = var1.I(var2, this.eI * 1508815983, 522165232);
         R = var4 == null;
         return var4;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "eg.z(" + ')');
      }
   }

   public void I(GSI var1, UT var2, LF var3, int var4, int var5) {
      try {
         var2.method4786(var3);
         NFI[] var6 = var2.method4781();
         WBI[] var7 = var2.method4728();
         if ((this.pI == null || this.pI.S) && (var6 != null || var7 != null)) {
            this.pI = GQ.I(var4, false);
         }

         if (this.pI != null) {
            this.pI.I(var1, (long)var4, var6, var7, false);
         }

      } catch (RuntimeException var8) {
         throw DQ.I(var8, "eg.t(" + ')');
      }
   }

   public void Z(int var1, String var2, int var3) {
      try {
         if (this.WI == null || this.WI.length <= var1) {
            String[] var4 = new String[1 + var1];
            if (this.WI != null) {
               for(int var5 = 0; var5 < this.WI.length; ++var5) {
                  var4[var5] = this.WI[var5];
               }
            }

            this.WI = var4;
         }

         this.WI[var1] = var2;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "eg.j(" + ')');
      }
   }

   public V I(GSI var1, int var2) {
      try {
         long var3 = (long)(this.V * -440872681) << 32 | (long)(-1309843523 * this.a) & 4294967295L;
         V var5 = (V)O.I(var3);
         if (var5 != null) {
            if (this.BI * 1411971043 != var5.F * 1509093479) {
               O.Z(var3);
               var5 = null;
            }

            if (var5 != null) {
               return var5;
            }
         }

         RFI var6 = RFI.I(JI.Z, 1411971043 * this.BI, 0);
         if (var6 == null) {
            return null;
         } else {
            int var7 = var6.Z + var6.D + var6.B;
            int var8 = var6.I + var6.F + var6.C;
            int[] var9 = new int[var8];
            int[] var10 = new int[var8];

            for(int var11 = 0; var11 < var6.F; ++var11) {
               int var12 = 0;
               int var13 = var6.Z;

               int var14;
               for(var14 = 0; var14 < var6.Z; ++var14) {
                  if (var6.S[var6.Z * var11 + var14] != 0) {
                     var12 = var14;
                     break;
                  }
               }

               for(var14 = var6.Z - 1; var14 >= var12; --var14) {
                  if (var6.S[var6.Z * var11 + var14] != 0) {
                     var13 = 1 + var14;
                     break;
                  }
               }

               var9[var6.I + var11] = var6.D + var12;
               var10[var11 + var6.I] = var13 - var12;
            }

            QJI var16 = var1.method5034(var7, var8, var9, var10);
            if (var16 == null) {
               return null;
            } else {
               var5 = new V(var7, var8, var10, var9, var16, 1411971043 * this.BI);
               O.I(var5, var3);
               return var5;
            }
         }
      } catch (RuntimeException var15) {
         throw DQ.I(var15, "eg.l(" + ')');
      }
   }

   public int I(int var1, int var2, int var3) {
      try {
         if (this.method4728 == null) {
            return var2;
         } else {
            OK var4 = (OK)this.method4728.I((long)var1);
            return var4 == null ? var2 : var4.J * -774922497;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "eg.ax(" + ')');
      }
   }

   int[] TYPE(REI var1, int var2) {
      try {
         int var3 = var1.I();
         if (var3 == 0) {
            return null;
         } else {
            int[] var4 = new int[var3];

            for(int var5 = 0; var5 < var3; ++var5) {
               var4[var5] = var1.H((byte)-23);
            }

            return var4;
         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "eg.q(" + ')');
      }
   }

   public void I(int var1, String var2, byte var3) {
      try {
         if (this.method4728 == null) {
            this.method4728 = new JX(16);
            this.method4728.I(new QG(var2), (long)var1);
         } else {
            QG var4 = (QG)this.method4728.I((long)var1);
            if (var4 != null) {
               var4.I(-1460969981);
            }

            this.method4728.I(new QG(var2), (long)var1);
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "eg.ae(" + ')');
      }
   }

   public void I(int var1, short var2, short var3, int var4) {
      try {
         if (var1 < 5) {
            if (this.aClass243_6310 == null) {
               this.aClass243_6310 = new short[5];
               this.invoke = new short[5];
            }

            this.aClass243_6310[var1] = var2;
            this.invoke[var1] = var3;
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "eg.av(" + ')');
      }
   }

   public EA I(PO var1, XI var2, int var3) {
      try {
         if (-1 == this.xZ * 925824753) {
            return null;
         } else {
            long var4 = ((long)(1779368503 * this.RC) & 65535L) << 48 | ((long)(this.dI * -163313477) & 65535L) << 32 | ((long)(this.DI * -1234146137) & 65535L) << 16 | (long)(this.xZ * 925824753) & 65535L;
            EA var6 = (EA)HC.I(var4);
            if (var6 == null) {
               var6 = var1.I(this.xZ * 925824753, 1779368503 * this.RC, -163313477 * this.dI, this.DI * -1234146137, var2, (byte)89);
               HC.I(var6, var4);
            }

            return var6;
         }
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "eg.h(" + ')');
      }
   }

   public void I(int var1) {
      try {
         this.YZ = null;
         this.AZ = null;
         this.fZ = null;
         this.d = null;
         this.HZ = null;
         this.KZ = null;
         this.LZ = null;
         this.B = null;
         this.JC = null;
         this.P = null;
         this.PZ = null;
         this.Z = null;
         this.FI = null;
         this.OI = null;
         this.II = null;
         this.VZ = null;
         this.WZ = null;
         this.XZ = null;
         this.cI = null;
         this.iZ = null;
         this.h = null;
         this.cZ = null;
         this.aI = null;
         this.jZ = null;
         this.NZ = null;
         this.xI = null;
         this.eZ = null;
         this.gZ = null;
         this.IC = null;
         this.kZ = null;
         this.lZ = null;
         this.nZ = null;
         this.oZ = null;
         this.pZ = null;
         this.QZ = null;
         this.rZ = null;
         this.q = null;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "eg.w(" + ')');
      }
   }

   public void I(int var1, int var2) {
      try {
         if (this.method4728 != null) {
            AE var3 = this.method4728.I((long)var1);
            if (var3 != null) {
               var3.I(-1460969981);
            }
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "eg.ao(" + ')');
      }
   }

   public UT I(GSI var1, int var2, SQ var3, PZ var4, NZI var5, YY var6, SU var7, FAI var8, SX var9, QR var10, int var11) {
      try {
         R = false;
         if (1548853569 * this.KI == 0) {
            return null;
         } else if (1 == 1548853569 * this.KI && -1 == this.f * 572201537) {
            return null;
         } else if (1 == this.KI * 1548853569) {
            if (var9 != null) {
               var2 |= var9.B(-1790708337);
            }

            long var25 = -1L;
            long[] var26 = REI.G;
            int var16;
            if (this.KA != null) {
               for(var16 = 0; var16 < this.KA.length; ++var16) {
                  var25 = var25 >>> 8 ^ var26[(int)((var25 ^ (long)(this.KA[var16] >> 8)) & 255L)];
                  var25 = var25 >>> 8 ^ var26[(int)((var25 ^ (long)this.KA[var16]) & 255L)];
                  var25 = var25 >>> 8 ^ var26[(int)((var25 ^ (long)(this.TYPE[var16] >> 8)) & 255L)];
                  var25 = var25 >>> 8 ^ var26[(int)((var25 ^ (long)this.TYPE[var16]) & 255L)];
               }

               var2 |= 16384;
            }

            if (this.aClass243_6310 != null) {
               for(var16 = 0; var16 < this.aClass243_6310.length; ++var16) {
                  var25 = var25 >>> 8 ^ var26[(int)((var25 ^ (long)(this.aClass243_6310[var16] >> 8)) & 255L)];
                  var25 = var25 >>> 8 ^ var26[(int)((var25 ^ (long)this.aClass243_6310[var16]) & 255L)];
                  var25 = var25 >>> 8 ^ var26[(int)((var25 ^ (long)(this.invoke[var16] >> 8)) & 255L)];
                  var25 = var25 >>> 8 ^ var26[(int)((var25 ^ (long)this.invoke[var16]) & 255L)];
               }

               var2 |= 32768;
            }

            long var27 = (long)(var1.KZ * 580915349) << 59 | (long)(this.KI * 1548853569) << 54 | (long)(this.f * 572201537) << 38 | var25 & 274877906943L;
            UT var18 = (UT)Q.I(var27);
            if (var18 == null || var1.method5017(var18.m(), var2) != 0) {
               if (var18 != null) {
                  var2 = var1.method5004(var2, var18.m());
               }

               MBI var19 = MBI.I((KJ)RuntimeException_Sub3.aClass243_6310, 572201537 * this.f, (int)0);
               if (var19 == null) {
                  R = true;
                  return null;
               }

               if (var19.P < 13) {
                  var19.I(2);
               }

               var18 = var1.method5037(var19, var2, RD.Z * 951783317, 64, 768);
               int var20;
               if (this.KA != null) {
                  for(var20 = 0; var20 < this.KA.length; ++var20) {
                     var18.X(this.KA[var20], this.TYPE[var20]);
                  }
               }

               if (this.aClass243_6310 != null) {
                  for(var20 = 0; var20 < this.aClass243_6310.length; ++var20) {
                     var18.W(this.aClass243_6310[var20], this.invoke[var20]);
                  }
               }

               Q.I(var18, var27);
            }

            if (var9 != null) {
               var18 = var18.method4755((byte)1, var2, true);
               var9.I((UT)var18, 0, (int)-719593032);
            }

            var18.KA(var2);
            return var18;
         } else {
            UT var22;
            if (2 == 1548853569 * this.KI) {
               var22 = var5.I(572201537 * this.f, -1438978079).I(var1, var2, var8, var9, this.VC, 636300802);
               if (var22 == null) {
                  R = true;
                  return null;
               } else {
                  return var22;
               }
            } else if (this.KI * 1548853569 == 3) {
               if (var10 == null) {
                  return null;
               } else {
                  var22 = var10.I(var1, var2, var4, var5, var6, var7, var8, var9, -275612851);
                  if (var22 == null) {
                     R = true;
                     return null;
                  } else {
                     return var22;
                  }
               }
            } else if (this.KI * 1548853569 == 4) {
               SEI var23 = var6.I(this.f * 572201537);
               UT var24 = var23.I(var1, var2, 10, var10, var9, 0, 0, 0, 0, 2097526071);
               if (var24 == null) {
                  R = true;
                  return null;
               } else {
                  return var24;
               }
            } else if (6 == this.KI * 1548853569) {
               var22 = var5.I(this.f * 572201537, -2061874989).I(var1, var2, var3, var8, var9, (SX)null, (SX[])null, (int[])null, 0, this.VC, -884053309);
               if (var22 == null) {
                  R = true;
                  return null;
               } else {
                  return var22;
               }
            } else if (7 == 1548853569 * this.KI) {
               if (var10 == null) {
                  return null;
               } else {
                  int var12 = this.f * 572201537 >>> 16;
                  int var13 = this.f * 572201537 & '\uffff';
                  int var14 = 1148770405 * this.T;
                  UT var15 = var10.I(var1, var2, var4, var7, var9, var12, var13, var14, (byte)0);
                  if (var15 == null) {
                     R = true;
                     return null;
                  } else {
                     return var15;
                  }
               }
            } else {
               return null;
            }
         }
      } catch (RuntimeException var21) {
         throw DQ.I(var21, "eg.y(" + ')');
      }
   }

   public void Z(int var1, int var2, int var3) {
      try {
         if (this.method4728 == null) {
            this.method4728 = new JX(16);
            this.method4728.I(new OK(var2), (long)var1);
         } else {
            OK var4 = (OK)this.method4728.I((long)var1);
            if (var4 == null) {
               this.method4728.I(new OK(var2), (long)var1);
            } else {
               var4.J = -898670337 * var2;
            }
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "eg.ak(" + ')');
      }
   }

   public void Z(int var1, short var2, short var3, int var4) {
      try {
         if (var1 < 5) {
            if (this.KA == null) {
               this.KA = new short[5];
               this.TYPE = new short[5];
            }

            this.KA[var1] = var2;
            this.TYPE[var1] = var3;
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "eg.ad(" + ')');
      }
   }

   public void I(int var1, int var2, byte var3) {
      try {
         if (this.IZ == null || this.IZ.length <= var1) {
            int[] var4 = new int[var1 + 1];
            if (this.IZ != null) {
               int var5;
               for(var5 = 0; var5 < this.IZ.length; ++var5) {
                  var4[var5] = this.IZ[var5];
               }

               for(var5 = this.IZ.length; var5 < var1; ++var5) {
                  var4[var5] = -1;
               }
            }

            this.IZ = var4;
         }

         this.IZ[var1] = var2;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "eg.o(" + ')');
      }
   }

   public HSI() {
      this.qI = OL.H;
      this.rI = false;
      this.wI = "";
      this.ZZ = 7527659;
      this.CZ = null;
      this.SZ = 0;
      this.BZ = 0;
      this.DZ = aZ * 623805157;
      this.FZ = "";
      this.JZ = false;
      this.uZ = -643064669;
      this.vZ = 0;
      this.kI = false;
      this.xZ = 153142767;
      this.DC = -1025047959;
      this.FC = -1587382585;
      this.EC = false;
      this.GC = false;
      this.mI = -607532293;
      this.BC = 0;
      this.LC = 0;
      this.MC = 0;
      this.NC = 0;
      this.OC = 0;
      this.PC = 0;
      this.QC = -1339690151;
      this.M = 217934215;
   }

   public IBI Z(GSI var1, int var2) {
      try {
         R = false;
         long var3 = ((this.AI ? 1L : 0L) << 38) + ((this.GI ? 1L : 0L) << 35) + (long)(this.BI * 1411971043) + ((long)(this.JI * 547522005) << 36) + ((this.EI ? 1L : 0L) << 39) + ((long)(this.RZ * -2065110161) << 40);
         IBI var5 = (IBI)N.I(var3);
         if (var5 != null) {
            return var5;
         } else {
            RFI var6 = RFI.I(JI.Z, 1411971043 * this.BI, 0);
            if (var6 == null) {
               R = true;
               return null;
            } else {
               if (this.AI) {
                  var6.I();
               }

               if (this.EI) {
                  var6.F();
               }

               if (this.JI * 547522005 > 0) {
                  var6.I(547522005 * this.JI);
               } else if (-2065110161 * this.RZ != 0) {
                  var6.I(1);
               }

               if (547522005 * this.JI >= 1) {
                  var6.Z(1);
               }

               if (this.JI * 547522005 >= 2) {
                  var6.Z(16777215);
               }

               if (this.RZ * -2065110161 != 0) {
                  var6.C(-16777216 | -2065110161 * this.RZ);
               }

               var5 = var1.method5125(var6, true);
               N.I(var5, var3, var5.method623() * var5.method625() * 4, (byte)-114);
               return var5;
            }
         }
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "eg.n(" + ')');
      }
   }

   public static void I(int[] var0, Object[] var1, byte var2) {
      try {
         EV.I(var0, var1, 0, var0.length - 1, -641027314);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "eg.u(" + ')');
      }
   }

   static void I(OU var0, int var1) {
      try {
         var0.H[var0.J * 681479919 - 1] = OO.I.I(var0.H[var0.J * 681479919 - 1], 245040087).I(MI.E, XEI.hC, (byte)76) ? 1 : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "eg.m(" + ')');
      }
   }

   static final void I(OU var0, short var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         WO.I(var3, var4, var0, (byte)-72);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "eg.im(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         PK var3 = GB.I(MEI.KI, XEI.eI.Z, (byte)37);
         var3.J.Z(var2, 16711935);
         XEI.eI.I(var3, (byte)-67);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "eg.su(" + ')');
      }
   }

   static final void Z(OU var0, short var1) {
      try {
         if (EQ.t != null) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 1;
            var0.D = EQ.t;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "eg.xe(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         WK var3 = ZN.C(142245824);
         if (var3 != null) {
            boolean var4 = var3.I(var2 >> 14 & 16383, var2 & 16383, YT.J, -1054516511);
            if (var4) {
               var0.H[(var0.J += -391880689) * 681479919 - 1] = YT.J[1];
               var0.H[(var0.J += -391880689) * 681479919 - 1] = YT.J[2];
            } else {
               var0.H[(var0.J += -391880689) * 681479919 - 1] = -1;
               var0.H[(var0.J += -391880689) * 681479919 - 1] = -1;
            }
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = -1;
            var0.H[(var0.J += -391880689) * 681479919 - 1] = -1;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "eg.aee(" + ')');
      }
   }

   static final void I(IR var0, OU var1, int var2) {
      try {
         boolean var3 = false;
         int var4 = 0;
         int var5 = 0;
         int var6 = 0;
         int var7 = 0;
         if (var0.N != null) {
            for(int var8 = 0; var8 < var0.N.length; ++var8) {
               KN var9 = var0.N[var8];
               if (var9.J) {
                  int var10;
                  int var11;
                  if (var9.F < var9.B) {
                     var10 = var9.F - var9.S;
                     var11 = var9.B + var9.S;
                  } else {
                     var10 = var9.B - var9.S;
                     var11 = var9.S + var9.F;
                  }

                  int var12;
                  int var13;
                  if (var9.C < var9.D) {
                     var12 = var9.C - var9.S;
                     var13 = var9.S + var9.D;
                  } else {
                     var12 = var9.D - var9.S;
                     var13 = var9.S + var9.C;
                  }

                  if (!var3 || var10 < var4) {
                     var4 = var10;
                  }

                  if (!var3 || var12 < var5) {
                     var5 = var12;
                  }

                  if (!var3 || var11 > var6) {
                     var6 = var11;
                  }

                  if (!var3 || var13 > var7) {
                     var7 = var13;
                  }

                  var3 = true;
               }
            }
         }

         var1.H[(var1.J += -391880689) * 681479919 - 1] = var3 ? 1 : 0;
         var1.H[(var1.J += -391880689) * 681479919 - 1] = var4;
         var1.H[(var1.J += -391880689) * 681479919 - 1] = var5;
         var1.H[(var1.J += -391880689) * 681479919 - 1] = var6;
         var1.H[(var1.J += -391880689) * 681479919 - 1] = var7;
      } catch (RuntimeException var14) {
         throw DQ.I(var14, "eg.apj(" + ')');
      }
   }

   public static void Z(int var0, int var1) {
      try {
         EDI.B.C(var0 >> 8, 911461196);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "eg.d(" + ')');
      }
   }
}
