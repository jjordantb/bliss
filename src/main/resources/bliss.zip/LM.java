import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class LM extends AE {
   int[] J;
   int[] S;
   int[] A;
   int E;
   Field[] G;
   byte[][][] H;
   Method[] K;
   int L;

   static void I(PEI var0, boolean var1, int var2) {
      try {
         if (-278777595 * FX.k < 410) {
            if (var0 == UA.F) {
               if (XEI.rC && (AE.F * -112110875 & 16) != 0) {
                  IJ.I(XEI.vC, XEI.TZ + " " + SS.C + " " + RA.I(16777215, -1880818524) + VEI.fZ.I(WO.U, -875414210), SJ.VI * 697885143, 16, -1, 0L, 0, 0, true, false, (long)(1888274983 * var0.W), false, -1698066743);
               }
            } else {
               String var3;
               if (var0.tI == 0) {
                  boolean var4 = true;
                  if (-1 != UA.F.rI * 1792775047 && -1 != 1792775047 * var0.rI) {
                     int var5 = 1792775047 * UA.F.rI < var0.rI * 1792775047 ? 1792775047 * UA.F.rI : var0.rI * 1792775047;
                     int var6 = 696798311 * UA.F.uI - 696798311 * var0.uI;
                     if (var6 < 0) {
                        var6 = -var6;
                     }

                     if (var6 > var5) {
                        var4 = false;
                     }
                  }

                  String var9 = XEI.mD == ZV.I ? VEI.hZ.I(WO.U, -875414210) : VEI.TZ.I(WO.U, -875414210);
                  if (var0.uI * 696798311 >= var0.CZ * 1868645317) {
                     var3 = var0.I(true, -1760788524) + (var4 ? GB.I(var0.uI * 696798311, 696798311 * UA.F.uI, (byte)4) : RA.I(16777215, -1771684039)) + SS.I + var9 + var0.uI * 696798311 + SS.B;
                  } else {
                     var3 = var0.I(true, -2010483537) + (var4 ? GB.I(var0.uI * 696798311, 696798311 * UA.F.uI, (byte)4) : RA.I(16777215, -1929125845)) + SS.I + var9 + 696798311 * var0.uI + "+" + (1868645317 * var0.CZ - var0.uI * 696798311) + SS.B;
                  }
               } else if (-1 == var0.tI) {
                  var3 = var0.I(true, -1641888806);
               } else {
                  var3 = var0.I(true, -2028633086) + SS.I + VEI.UZ.I(WO.U, -875414210) + var0.tI * 242930343 + SS.B;
               }

               if (XEI.rC && !var1 && (-112110875 * AE.F & 8) != 0) {
                  IJ.I(XEI.vC, XEI.TZ + " " + SS.C + " " + RA.I(16777215, -1806308451) + var3, 697885143 * SJ.VI, 15, -1, (long)(1888274983 * var0.W), 0, 0, true, false, (long)(1888274983 * var0.W), false, -2028889244);
               }

               if (var1) {
                  IJ.I(RA.I(13421772, -1997294576) + var3, "", -1, -1, 0, 0L, 0, 0, false, true, (long)(var0.W * 1888274983), false, -1271989822);
               } else {
                  for(int var10 = 7; var10 >= 0; --var10) {
                     if (XEI.bC[var10] != null) {
                        short var11 = 0;
                        if (XEI.mD == ZV.D && XEI.bC[var10].equalsIgnoreCase(VEI.NZ.I(WO.U, -875414210))) {
                           if (XEI.XC && var0.uI * 696798311 > UA.F.uI * 696798311) {
                              var11 = 2000;
                           }

                           if (UA.F.wI * -1473655357 != 0 && -1473655357 * var0.wI != 0) {
                              if (var0.wI * -1473655357 == UA.F.wI * -1473655357) {
                                 var11 = 2000;
                              } else {
                                 var11 = 0;
                              }
                           } else if (var0.GZ) {
                              var11 = 2000;
                           }
                        } else if (XEI.dC[var10]) {
                           var11 = 2000;
                        }

                        short var13 = (short)(var11 + XEI.zC[var10]);
                        int var7 = -1 != XEI.BD[var10] ? XEI.BD[var10] : XEI.QI * 1395924385;
                        IJ.I(XEI.bC[var10], RA.I(16777215, -1822012281) + var3, var7, var13, -1, (long)(1888274983 * var0.W), 0, 0, true, false, (long)(var0.W * 1888274983), false, -1451194858);
                     }
                  }
               }

               if (!var1) {
                  for(YK var12 = (YK)FX.K.Z(1766612795); var12 != null; var12 = (YK)FX.K.B(49146)) {
                     if (23 == 946432351 * var12.N) {
                        var12.V = RA.I(16777215, -1702215598) + var3;
                        break;
                     }
                  }
               }
            }
         }

      } catch (RuntimeException var8) {
         throw DQ.I(var8, "acj.bk(" + ')');
      }
   }
}
