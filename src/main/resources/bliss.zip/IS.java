import java.util.HashMap;
import java.util.Map;

public final class IS {
   I append;
   int clear;
   I currentTimeMillis;
   long get;
   ZS peek;
   Map put;
   public static FEI I;

   public Object I(Object var1, Object var2, byte var3) {
      try {
         synchronized(this) {
            if (-7599200929196954985L * this.get != -1L) {
               this.currentTimeMillis(-1215407622);
            }

            ES var5 = (ES)this.put.get(var1);
            if (var5 != null) {
               Object var10 = var5.Z;
               var5.Z = var2;
               this.clear(var5, false, (byte)115);
               return var10;
            } else {
               ES var6;
               if (this.append((byte)3) && this.put.size() == 582284141 * this.clear) {
                  var6 = (ES)this.currentTimeMillis.remove();
                  this.put.remove(var6.B);
                  this.append.remove(var6);
               }

               var6 = new ES(var2, var1);
               this.put.put(var1, var6);
               this.clear(var6, true, (byte)18);
               Object var7 = null;
               return var7;
            }
         }
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "kp.b(" + ')');
      }
   }

   IS(long var1, int var3, ZS var4) {
      this.get = -611323927505636057L * var1;
      this.clear = var3 * -1292104091;
      this.peek = var4;
      if (this.clear * 582284141 == -1) {
         this.put = new HashMap(64);
         this.append = new I(64);
         this.currentTimeMillis = null;
      } else {
         if (this.peek == null) {
            throw new IllegalArgumentException("");
         }

         this.put = new HashMap(this.clear * 582284141);
         this.append = new I(582284141 * this.clear);
         this.currentTimeMillis = new I(582284141 * this.clear);
      }

   }

   boolean append(byte var1) {
      try {
         return this.clear * 582284141 != -1;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "kp.a(" + ')');
      }
   }

   public Object I(Object var1, byte var2) {
      try {
         synchronized(this) {
            if (-7599200929196954985L * this.get != -1L) {
               this.currentTimeMillis(-379360900);
            }

            ES var4 = (ES)this.put.get(var1);
            Object var5;
            if (var4 == null) {
               var5 = null;
               return var5;
            } else {
               this.clear(var4, false, (byte)110);
               var5 = var4.Z;
               return var5;
            }
         }
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "kp.f(" + ')');
      }
   }

   public IS(int var1, ZS var2) {
      this(-1L, var1, var2);
   }

   void clear(ES var1, boolean var2, byte var3) {
      try {
         if (!var2) {
            this.append.remove(var1);
            if (this.append((byte)3) && !this.currentTimeMillis.remove(var1)) {
               throw new IllegalStateException("");
            }
         }

         var1.C = System.currentTimeMillis() * 7489795633800790139L;
         if (this.append((byte)3)) {
            switch(this.peek.Z * -1142442207) {
            case 0:
               var1.I = var1.C * 9087373979742177181L;
               break;
            case 1:
               var1.I += 8711051982827645039L;
            }

            this.currentTimeMillis.add(var1);
         }

         this.append.add(var1);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "kp.i(" + ')');
      }
   }

   void currentTimeMillis(int var1) {
      try {
         if (this.get * -7599200929196954985L == -1L) {
            throw new IllegalStateException("");
         } else {
            long var2 = System.currentTimeMillis() - -7599200929196954985L * this.get;

            while(!this.append.isEmpty()) {
               ES var4 = (ES)this.append.peek();
               if (2922630875768299187L * var4.C >= var2) {
                  break;
               }

               this.put.remove(var4.B);
               this.append.remove(var4);
               if (this.append((byte)3)) {
                  this.currentTimeMillis.remove(var4);
               }
            }

         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "kp.k(" + ')');
      }
   }

   public void I(int var1) {
      try {
         synchronized(this) {
            this.put.clear();
            this.append.clear();
            if (this.append((byte)3)) {
               this.currentTimeMillis.clear();
            }

         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "kp.d(" + ')');
      }
   }

   public Object I(Object var1, int var2) {
      try {
         synchronized(this) {
            if (-1L != -7599200929196954985L * this.get) {
               this.currentTimeMillis(-583861644);
            }

            ES var4 = (ES)this.put.remove(var1);
            Object var5;
            if (var4 != null) {
               this.append.remove(var4);
               if (this.append((byte)3)) {
                  this.currentTimeMillis.remove(var4);
               }

               var5 = var4.Z;
               return var5;
            } else {
               var5 = null;
               return var5;
            }
         }
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "kp.p(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         var0.J -= -391880689;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "kp.ab(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         String var2 = (String)var0.S[(var0.A -= 969361751) * -203050393];
         if (var2.startsWith(QJ.I((int)0, -278777595)) || var2.startsWith(QJ.I((int)1, -278777595))) {
            var2 = var2.substring(7);
         }

         var0.H[(var0.J += -391880689) * 681479919 - 1] = III.I(var2, -1316013258);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "kp.wi(" + ')');
      }
   }

   static final void C(OU var0, byte var1) {
      try {
         ZQ var2 = FCI.Z((byte)29);
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var2 == null ? 0 : var2.C * -877023375;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "kp.alt(" + ')');
      }
   }

   static final void B(OU var0, byte var1) {
      try {
         int var2 = var0.X[var0.i * 1883543357];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = ((PEI)var0.E).HZ.Z(var2, -1034906382);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "kp.ae(" + ')');
      }
   }

   static void I(int var0, int var1, int var2, int var3, int var4) {
      try {
         VK var5 = IV.I(10, (long)var0);
         var5.I((byte)101);
         var5.L = var1 * 1274450087;
         var5.H = var2 * 293101103;
         var5.K = -80288087 * var3;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "kp.ab(" + ')');
      }
   }
}
