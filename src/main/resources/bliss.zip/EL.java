public class EL extends QK {
   int G;
   EY H;
   String K;

   boolean I(YK var1, int var2) {
      try {
         boolean var3 = true;
         var1.C(1827791950);

         for(YK var4 = (YK)this.H.Z(-1933327286); var4 != null; var3 = false) {
            if (UY.I(var1.N * 946432351, var4.N * 946432351, -537262415)) {
               LBI.I((QK)var1, (QK)var4, (byte)-70);
               this.G += -130647835;
               return !var3;
            }

            var4 = (YK)this.H.C(729407080);
         }

         this.H.I(var1, (byte)-34);
         this.G += -130647835;
         return var3;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aij.f(" + ')');
      }
   }

   EL(String var1) {
      this.K = var1;
      this.H = new EY();
   }

   int B(int var1) {
      try {
         return this.H.I != this.H.I.S ? ((YK)this.H.I.S).N * 946432351 : -1;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aij.a(" + ')');
      }
   }

   boolean Z(YK var1, int var2) {
      try {
         int var3 = this.B(-738020906);
         var1.C(-1148037047);
         this.G -= -130647835;
         if (-628325139 * this.G == 0) {
            this.I(-1460969981);
            this.C(-1345021644);
            FX.H -= -1658575779;
            FX.I.I(this, var1.R * 6619564980435866523L);
            return false;
         } else {
            return var3 != this.B(-912976938);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aij.b(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         if (-1 != -1232467723 * var3.uZ) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = -66163287 * var3.vZ;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aij.ps(" + ')');
      }
   }
}
