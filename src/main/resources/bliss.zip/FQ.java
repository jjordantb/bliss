public class FQ {
   KJ I;
   KJ Z;
   JQ C = new JQ(20);
   JQ append = new JQ(64);

   public PQ I(int var1, int var2) {
      try {
         JQ var4 = this.append;
         PQ var3;
         synchronized(this.append) {
            var3 = (PQ)this.append.I((long)var1);
         }

         if (var3 != null) {
            return var3;
         } else {
            KJ var5 = this.I;
            byte[] var10;
            synchronized(this.I) {
               var10 = this.I.I(-1006924897 * II.o.y, var1, (byte)-66);
            }

            var3 = new PQ();
            var3.B = this;
            if (var10 != null) {
               var3.I(new REI(var10), -1860141420);
            }

            JQ var11 = this.append;
            synchronized(this.append) {
               this.append.I(var3, (long)var1);
            }

            return var3;
         }
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "om.a(" + ')');
      }
   }

   public void I(short var1) {
      try {
         JQ var2 = this.append;
         synchronized(this.append) {
            this.append.I();
         }

         var2 = this.C;
         synchronized(this.C) {
            this.C.I();
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "om.f(" + ')');
      }
   }

   public void Z(int var1, int var2) {
      try {
         JQ var3 = this.append;
         synchronized(this.append) {
            this.append.I(var1, -1794430367);
         }

         var3 = this.C;
         synchronized(this.C) {
            this.C.I(var1, -1227911326);
         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "om.b(" + ')');
      }
   }

   public void I(int var1) {
      try {
         JQ var2 = this.append;
         synchronized(this.append) {
            this.append.Z();
         }

         var2 = this.C;
         synchronized(this.C) {
            this.C.Z();
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "om.p(" + ')');
      }
   }

   public FQ(ZV var1, XW var2, KJ var3, KJ var4) {
      this.Z = var4;
      this.I = var3;
      this.I.F(II.o.y * -1006924897, -790264977);
   }

   static final void I(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         QII.I(var3, var4, var0, (byte)55);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "om.fp(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-22);
         O.I(var3, var0, (byte)0);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "om.qu(" + ')');
      }
   }
}
