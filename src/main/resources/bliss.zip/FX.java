public class FX {
   static JQ I = new JQ(30);
   static int append = 410;
   static YK Z;
   static int C = -372312112;
   static int length = 0;
   static int substring = 31;
   static JX B = new JX(16);
   static boolean D = false;
   static EL F = null;
   static int toString = 0;
   static int J = 1;
   static float[] S = new float[4];
   static int A = 0;
   static YK E;
   public static boolean G = false;
   public static int H = 0;
   static IY K = new IY();
   static int L = 521;
   static EY M = new EY();
   static int N = 3;
   public static int O;
   static int P = 31;
   static HSI Q = null;
   static int R = 1021462033;
   static int T = 2;
   static int U = 305664667;
   static int V = -67681267;
   static int W = 0;
   static int X = 0;
   static YF Y = null;
   static YF i = new YF();
   static LF z = new LF();
   public static boolean c = false;
   static int b = 2;
   static int d = 0;
   public static int f = -985311877;
   static JQ j = new JQ(8);
   static IBI[] s;
   static int a = 1325119769;
   static int e = 8;
   static int g = 1;
   static IY h = new IY();
   public static int k = 0;
   static int l = 4;
   static int m = 5;
   static int n = 6;
   static int o = 7;
   static IY p = new IY();

   FX() throws Throwable {
      throw new Error();
   }

   static final void I(HSI var0, X var1, OU var2, int var3) {
      try {
         String var4 = (String)var2.S[(var2.A -= 969361751) * -203050393];
         if (IN.I(var4, var2, -1382665661) != null) {
            var4 = var4.substring(0, var4.length() - 1);
         }

         var0.PZ = OI.I(var4, var2, -2046058202);
         var0.JZ = true;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "s.mk(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var0.D.I((String)var0.S[(var0.A -= 969361751) * -203050393], (byte)-7);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "s.yv(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         if (var2 > 255 || var2 < 0) {
            var2 = 0;
         }

         if (var2 != FW.J.h.Z(-1514807660)) {
            FW.J.I(FW.J.h, var2, -1997480653);
            JN.I(656179282);
            XEI.w = false;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "s.ajv(" + ')');
      }
   }

   static String I(REI var0, int var1, int var2) {
      try {
         String var3;
         try {
            int var4 = var0.B(1723054621);
            if (var4 > var1) {
               var4 = var1;
            }

            byte[] var5 = new byte[var4];
            var0.A += A.I.I(var0.S, var0.A * 385051775, var5, 0, var4, 200493148) * 116413311;
            String var6 = CCI.I(var5, 0, var4, -295341968);
            var3 = var6;
         } catch (Exception var7) {
            return "Cabbage";
         }

         return var3;
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "s.p(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = XEI.OC ? 1 : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "s.uw(" + ')');
      }
   }

   public static int I(int var0) {
      try {
         return 1465562869 * TT.C;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "s.z(" + ')');
      }
   }
}
