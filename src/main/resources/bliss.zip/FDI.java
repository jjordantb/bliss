import java.awt.Component;

public class FDI {
   int[] Z;
   int[] append;
   int[] setDaemon;
   int[] setPriority;
   int[] start;
   int[] toString;
   int[] I;
   public static int C;

   void I(int var1, int var2) {
      try {
         int[][] var3 = new int[this.start.length << 1][4];

         for(int var4 = 0; var4 < this.start.length; ++var4) {
            var3[var4 * 2][0] = this.start[var4];
            var3[2 * var4][1] = this.append[var4];
            var3[2 * var4][2] = this.setDaemon[var4];
            var3[2 * var4][3] = this.I[var4];
            var3[1 + 2 * var4][0] = this.setPriority[var4];
            var3[1 + var4 * 2][1] = this.Z[var4];
            var3[1 + 2 * var4][2] = this.toString[var4];
            var3[2 * var4 + 1][3] = this.I[var4];
         }

         XEI.fZ[var1] = var3;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "da.a(" + ')');
      }
   }

   FDI(REI var1) {
      int var2 = var1.B(1723054621);
      this.start = new int[var2];
      this.append = new int[var2];
      this.setDaemon = new int[var2];
      this.I = new int[var2];
      this.setPriority = new int[var2];
      this.Z = new int[var2];
      this.toString = new int[var2];

      for(int var3 = 0; var3 < var2; ++var3) {
         this.start[var3] = var1.C() - 5120;
         this.setDaemon[var3] = var1.C() - 5120;
         this.append[var3] = var1.J(1563719109);
         this.setPriority[var3] = var1.C() - 5120;
         this.toString[var3] = var1.C() - 5120;
         this.Z[var3] = var1.J(2133929202);
         this.I[var3] = var1.J(1967809784);
      }

   }

   public static final PA I(Component var0, int var1, int var2, int var3) {
      try {
         if (PA.F * 1164070869 == 0) {
            throw new IllegalStateException();
         } else if (var1 >= 0 && var1 < 2) {
            if (var2 < 256) {
               var2 = 256;
            }

            QA var4;
            try {
               QA var5 = new QA();
               var5.B = new int[(PA.Z ? 2 : 1) * 256];
               var5.P = var2 * -949520941;
               var5.I(var0, (byte)127);
               var5.I = 2121848755 * ((var2 & -1024) + 1024);
               if (-1894797445 * var5.I > 16384) {
                  var5.I = 904708096;
               }

               var5.I(var5.I * -1894797445, 557897773);
               if (-1869204691 * PA.C > 0 && PA.D == null) {
                  PA.D = new WA();
                  Thread var6 = new Thread(PA.D);
                  var6.setDaemon(true);
                  var6.start();
                  var6.setPriority(PA.C * -1869204691);
               }

               if (PA.D != null) {
                  if (PA.D.C[var1] != null) {
                     throw new IllegalArgumentException();
                  }

                  PA.D.C[var1] = var5;
               }

               var4 = var5;
            } catch (Throwable var7) {
               return new PA();
            }

            return var4;
         } else {
            throw new IllegalArgumentException();
         }
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "da.f(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, byte var3) {
      try {
         var0.wI = (String)var2.S[(var2.A -= 969361751) * -203050393];
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "da.js(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         if (GN.p != null) {
            AE var3 = GN.p.I((long)var2);
            var0.H[(var0.J += -391880689) * 681479919 - 1] = var3 != null ? 1 : 0;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "da.aey(" + ')');
      }
   }

   static void I(EL var0, int var1) {
      try {
         boolean var2 = false;
         var0.C(-1845829409);

         for(EL var3 = (EL)FX.M.Z(-1268764084); var3 != null; var3 = (EL)FX.M.C(-1549897657)) {
            if (UY.I(var0.B(-610126190), var3.B(-1229609996), -537262415)) {
               FY.I(var0, var3, -1541675772);
               var2 = true;
               break;
            }
         }

         if (!var2) {
            FX.M.I(var0, (byte)-51);
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "da.h(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         XDI.I(var3, var4, var0, -535116520);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "da.fv(" + ')');
      }
   }
}
