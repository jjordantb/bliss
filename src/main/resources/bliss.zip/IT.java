public class IT extends YR {
   static int[] J;

   IT() throws Throwable {
      throw new Error();
   }

   static void I(int var0, int var1, int var2) {
      try {
         VK var3 = IV.I(15, 0L);
         var3.I((byte)19);
         var3.L = 1274450087 * var0;
         var3.H = var1 * 293101103;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "adb.ac(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, int var3) {
      try {
         String var4 = (String)var2.S[(var2.A -= 969361751) * -203050393];
         if (IN.I(var4, var2, -923339363) != null) {
            var4 = var4.substring(0, var4.length() - 1);
         }

         var0.gZ = OI.I(var4, var2, -2046058202);
         var0.JZ = true;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "adb.mn(" + ')');
      }
   }
}
