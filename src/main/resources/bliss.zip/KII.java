public class KII {
   public long I(int var1) {
      try {
         return System.nanoTime();
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "tu.a(" + ')');
      }
   }

   public KII() {
      System.nanoTime();
   }

   static final void I(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-112);
         JCI.I(var3, var0, -2096631087);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "tu.qc(" + ')');
      }
   }
}
