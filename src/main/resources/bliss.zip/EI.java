public abstract class EI implements MAI {
   int Z;
   KJ I;
   OS append;
   KJ method1411;
   MI C;
   long method1412;
   public static KJ B;

   abstract void method1409(boolean var1, int var2, int var3);

   abstract void method1410(boolean var1, int var2, int var3);

   public boolean method54() {
      boolean var1 = true;
      if (!this.I.D(this.C.S * 955568089, -457216440)) {
         var1 = false;
      }

      if (!this.method1411.D(955568089 * this.C.S, -457216440)) {
         var1 = false;
      }

      return var1;
   }

   public boolean method52(int var1) {
      try {
         boolean var2 = true;
         if (!this.I.D(this.C.S * 955568089, -457216440)) {
            var2 = false;
         }

         if (!this.method1411.D(955568089 * this.C.S, -457216440)) {
            var2 = false;
         }

         return var2;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "fd.b(" + ')');
      }
   }

   abstract void method1411(boolean var1, int var2, int var3, int var4);

   public void method58(boolean var1, byte var2) {
      try {
         int var3 = this.C.I.I(-944287579 * this.C.D, XEI.BC * 775068819, -2137791831) + this.C.F * -39975161;
         int var4 = this.C.Z.I(-1387457793 * this.C.A, -791746413 * XEI.KC, -1715218341) + this.C.B * 1886882435;
         this.method1412(var1, var3, var4, 589039750);
         this.method1411(var1, var3, var4, -2096633602);
         String var5 = WA.B.I((short)8868);
         if (CI.I((byte)1) - this.method1412 * 109366757865047727L > 10000L) {
            var5 = var5 + " (" + WA.B.Z(-1233866115).Q * -861845079 + ")";
         }

         this.append.Z(var5, -944287579 * this.C.D / 2 + var3, 4 + -1387457793 * this.C.A / 2 + var4 + this.C.J * -684094775, this.C.C * 782326281, -1, -370673990);
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "fd.f(" + ')');
      }
   }

   abstract void method1412(boolean var1, int var2, int var3, int var4);

   public void method56(boolean var1) {
      int var2 = this.C.I.I(-944287579 * this.C.D, XEI.BC * 775068819, -1925244247) + this.C.F * -39975161;
      int var3 = this.C.Z.I(-1387457793 * this.C.A, -791746413 * XEI.KC, -1769429058) + this.C.B * 1886882435;
      this.method1412(var1, var2, var3, -895632654);
      this.method1411(var1, var2, var3, -358621562);
      String var4 = WA.B.I((short)24747);
      if (CI.I((byte)1) - this.method1412 * 109366757865047727L > 10000L) {
         var4 = var4 + " (" + WA.B.Z(-1233866115).Q * -861845079 + ")";
      }

      this.append.Z(var4, -944287579 * this.C.D / 2 + var2, 4 + -1387457793 * this.C.A / 2 + var3 + this.C.J * -684094775, this.C.C * 782326281, -1, -1547657926);
   }

   public boolean method57() {
      boolean var1 = true;
      if (!this.I.D(this.C.S * 955568089, -457216440)) {
         var1 = false;
      }

      if (!this.method1411.D(955568089 * this.C.S, -457216440)) {
         var1 = false;
      }

      return var1;
   }

   public void method55() {
      LZI var1 = CS.I(this.method1411, 955568089 * this.C.S, 325683529);
      this.append = FT.P.method5092(var1, RFI.Z(this.I, 955568089 * this.C.S), true);
   }

   public boolean method59() {
      boolean var1 = true;
      if (!this.I.D(this.C.S * 955568089, -457216440)) {
         var1 = false;
      }

      if (!this.method1411.D(955568089 * this.C.S, -457216440)) {
         var1 = false;
      }

      return var1;
   }

   abstract void method1413(boolean var1, int var2, int var3);

   abstract void method1414(boolean var1, int var2, int var3);

   abstract void method1415(boolean var1, int var2, int var3);

   abstract void method1416(boolean var1, int var2, int var3);

   EI(KJ var1, KJ var2, MI var3) {
      this.I = var1;
      this.method1411 = var2;
      this.C = var3;
   }

   public void method53(int var1) {
      try {
         LZI var2 = CS.I(this.method1411, 955568089 * this.C.S, 1681337882);
         this.append = FT.P.method5092(var2, RFI.Z(this.I, 955568089 * this.C.S), true);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "fd.a(" + ')');
      }
   }

   abstract void method1417(boolean var1, int var2, int var3);

   int I(int var1) {
      try {
         int var2 = WA.B.B(-15916663);
         int var3 = var2 * 100;
         if (-1729871315 * this.Z == var2 && var2 != 0) {
            int var4 = WA.B.Z((byte)7);
            if (var4 > var2) {
               long var5 = 109366757865047727L * this.method1412 - WA.B.D(-2093041337);
               if (var5 > 0L) {
                  long var7 = var5 * 10000L / (long)var2 * (long)(var4 - var2);
                  long var9 = (CI.I((byte)1) - this.method1412 * 109366757865047727L) * 10000L;
                  if (var9 < var7) {
                     var3 = (int)(100L * var9 * (long)(var4 - var2) / var7 + (long)(100 * var2));
                  } else {
                     var3 = 100 * var4;
                  }
               }
            }
         } else {
            this.Z = 1301503397 * var2;
            this.method1412 = CI.I((byte)1) * -1063467934392987569L;
         }

         return var3;
      } catch (RuntimeException var11) {
         throw DQ.I(var11, "fd.q(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, int var3) {
      try {
         if (5 == -1215239439 * var0.X) {
            UC.I(var0, var1, var2, (short)-9019);
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "fd.gi(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.j.Z(1673845033) == 1 ? 1 : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "fd.ajr(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         var0.J -= -1175642067;
         int var2 = var0.H[var0.J * 681479919];
         int var3 = var0.H[1 + var0.J * 681479919];
         int var4 = var0.H[681479919 * var0.J + 2];
         GN.I(2, var2 << 16 | var3, var4, "", -474820428);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "fd.ali(" + ')');
      }
   }

   static final void I(OU var0, short var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.S[(var0.A += 969361751) * -203050393 - 1] = GSI.OZ.I(var2, 1350033014).H;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "fd.acc(" + ')');
      }
   }

   static final void I(HSI var0, int var1, int var2, int var3, OU var4, int var5) {
      try {
         if (var0.LI == null) {
            if (var2 == 0) {
               return;
            }

            var0.LI = new byte[11];
            var0.uI = new byte[11];
            var0.qZ = new int[11];
         }

         var0.LI[var1] = (byte)var2;
         if (var2 != 0) {
            var0.rI = true;
         } else {
            var0.rI = false;

            for(int var6 = 0; var6 < var0.LI.length; ++var6) {
               if (var0.LI[var6] != 0) {
                  var0.rI = true;
                  break;
               }
            }
         }

         var0.uI[var1] = (byte)var3;
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "fd.kd(" + ')');
      }
   }
}
