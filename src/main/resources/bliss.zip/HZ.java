public class HZ {
   static HZ I = new HZ();
   static HZ Z = new HZ();
   static HZ C = new HZ();
   static int B;

   public int I(int var1, int var2, int var3) {
      try {
         int var4 = GY.Z * -2110394505 > var2 ? -2110394505 * GY.Z : var2;
         if (C == this) {
            return 0;
         } else if (I == this) {
            return var4 - var1;
         } else {
            return Z == this ? (var4 - var1) / 2 : 0;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "fq.f(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         F var3 = XL.Z(var2, -1927807761);
         String var4 = "";
         if (var3 != null && var3.J != null) {
            var4 = var3.J;
         }

         var0.S[(var0.A += 969361751) * -203050393 - 1] = var4;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "fq.acs(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         WK var3 = EN.Z(var2 >> 14 & 16383, var2 & 16383);
         if (var3 == null) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = -1;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = var3.M * -947282109;
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "fq.adh(" + ')');
      }
   }

   public static void I(String var0, boolean var1, GSI var2, OS var3, LZI var4, byte var5) {
      try {
         boolean var6 = !DT.J || ZO.I(-2107815446);
         if (var6) {
            int var7;
            int var8;
            int var10;
            int var11;
            if (DT.J && var6) {
               var4 = KZ.A;
               var3 = var2.method5092(var4, KZ.Z, true);
               var7 = var4.I(var0, 250, (GAI[])null, (int)-2064618715);
               var8 = var4.I(var0, 250, -2028004825 * var4.C, (GAI[])null, -804719139);
               int var15 = HW.F.Z;
               var10 = 4 + var15;
               var7 += 2 * var10;
               var8 += var10 * 2;
               if (var7 < 646794549 * KZ.D) {
                  var7 = 646794549 * KZ.D;
               }

               if (var8 < KZ.S * 1004672961) {
                  var8 = 1004672961 * KZ.S;
               }

               var11 = KZ.B.I(var7, XEI.BC * 775068819, -1808907629) + -994816289 * KZ.C;
               int var12 = KZ.E.I(var8, XEI.KC * -791746413, -750031668) + -277668631 * KZ.F;
               var2.method5125(RT.L, false).method662(var11 + JJI.S.Z, JJI.S.F + var12, var7 - JJI.S.Z * 2, var8 - 2 * JJI.S.F, 1, 0, 0);
               var2.method5125(JJI.S, true).I(var11, var12);
               JJI.S.F();
               var2.method5125(JJI.S, true).I(var7 + var11 - var15, var12);
               JJI.S.I();
               var2.method5125(JJI.S, true).I(var7 + var11 - var15, var12 + var8 - var15);
               JJI.S.F();
               var2.method5125(JJI.S, true).I(var11, var8 + var12 - var15);
               JJI.S.I();
               var2.method5125(HW.F, true).Z(var11, var12 + JJI.S.F, var15, var8 - 2 * JJI.S.F);
               HW.F.B();
               var2.method5125(HW.F, true).Z(JJI.S.Z + var11, var12, var7 - 2 * JJI.S.Z, var15);
               HW.F.B();
               var2.method5125(HW.F, true).Z(var11 + var7 - var15, var12 + JJI.S.F, var15, var8 - 2 * JJI.S.F);
               HW.F.B();
               var2.method5125(HW.F, true).Z(var11 + JJI.S.Z, var12 + var8 - var15, var7 - 2 * JJI.S.Z, var15);
               HW.F.B();
               var3.I(var0, var10 + var11, var12 + var10, var7 - var10 * 2, var8 - 2 * var10, -617134757 * WW.J | -16777216, -1, 1, 1, 0, (IBI[])null, (int[])null, (QJI)null, 0, 0, -45995166);
               QF.I(var11, var12, var7, var8, (byte)2);
            } else {
               var7 = var4.I(var0, 250, (GAI[])null, (int)-570698918);
               var8 = var4.Z(var0, 250, (GAI[])null, 1328812176) * 13;
               byte var9 = 4;
               var10 = 6 + var9;
               var11 = 6 + var9;
               var2.B(var10 - var9, var11 - var9, var9 + var7 + var9, var8 + var9 + var9, -16777216, 0);
               var2.method5019(var10 - var9, var11 - var9, var9 + var7 + var9, var8 + var9 + var9, -1, 0);
               var3.I(var0, var10, var11, var7, var8, -1, -1, 1, 1, 0, (IBI[])null, (int[])null, (QJI)null, 0, 0, -45995166);
               QF.I(var10 - var9, var11 - var9, var9 + var7 + var9, var8 + var9 + var9, (byte)2);
            }

            if (var1) {
               try {
                  var2.I((byte)18);
               } catch (Exception_Sub1 var13) {
                  ;
               }
            }
         }

      } catch (RuntimeException var14) {
         throw DQ.I(var14, "fq.b(" + ')');
      }
   }

   static final void I(int var0, int var1, int var2, int var3, int var4) {
      try {
         SI.I(var0, var1, var2, 0, var3, false, 2074024195);
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "fq.jb(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)74);
         X var4 = IU.F[var2 >> 16];
         QJ.I(var3, var4, var0, 2008837273);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "fq.ff(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         PG.I((byte)32);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "fq.ahw(" + ')');
      }
   }
}
