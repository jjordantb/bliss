public class DM extends RL {
   LC append;
   int toString;

   void method3512(REI var1) {
      this.toString = var1.C() * -489279757;
   }

   void method3508(REI var1, int var2) {
      try {
         this.toString = var1.C() * -489279757;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "agm.a(" + ')');
      }
   }

   void method3510(QC var1, byte var2) {
      try {
         var1.Z(2034735675 * this.toString, (byte)-37);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "agm.f(" + ')');
      }
   }

   void method3511(QC var1) {
      var1.Z(2034735675 * this.toString, (byte)51);
   }

   DM(LC var1) {
      this.append = var1;
      this.toString = 489279757;
   }

   void method3509(REI var1) {
      this.toString = var1.C() * -489279757;
   }
}
