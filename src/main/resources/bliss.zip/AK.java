public class AK extends YG {
   int Q;
   static int R = 0;
   static int T = 0;
   int U = 0;
   int V = 0;
   int W = 0;
   static int X = 0;
   int Y;
   int i;
   int z;
   int c;
   int b;

   int[][] append(int var1) {
      int[][] var2 = this.L.I(var1, (byte)114);
      if (this.L.I) {
         int[][] var3 = this.I(0, var1, (byte)8);
         int[] var4 = var3[0];
         int[] var5 = var3[1];
         int[] var6 = var3[2];
         int[] var7 = var2[0];
         int[] var8 = var2[1];
         int[] var9 = var2[2];

         for(int var10 = 0; var10 < WJ.C * -1474554145; ++var10) {
            this.Z(var4[var10], var5[var10], var6[var10], -128256883);
            this.i += this.U * -480504993;
            this.Y += 1401525773 * this.V;

            for(this.Q += -1298028627 * this.W; this.i * 1081228573 < 0; this.i += 1188253696) {
               ;
            }

            while(1081228573 * this.i > 4096) {
               this.i -= 1188253696;
            }

            if (this.Y * -736197367 < 0) {
               this.Y = 0;
            }

            if (-736197367 * this.Y > 4096) {
               this.Y = 697536512;
            }

            if (-469731721 * this.Q < 0) {
               this.Q = 0;
            }

            if (-469731721 * this.Q > 4096) {
               this.Q = 607416320;
            }

            this.toString(1081228573 * this.i, -736197367 * this.Y, -469731721 * this.Q, 182018145);
            var7[var10] = -1916696729 * this.z;
            var8[var10] = this.c * 995837071;
            var9[var10] = 826309923 * this.b;
         }
      }

      return var2;
   }

   int[][] I(int var1, byte var2) {
      try {
         int[][] var3 = this.L.I(var1, (byte)87);
         if (this.L.I) {
            int[][] var4 = this.I(0, var1, (byte)8);
            int[] var5 = var4[0];
            int[] var6 = var4[1];
            int[] var7 = var4[2];
            int[] var8 = var3[0];
            int[] var9 = var3[1];
            int[] var10 = var3[2];

            for(int var11 = 0; var11 < WJ.C * -1474554145; ++var11) {
               this.Z(var5[var11], var6[var11], var7[var11], -128256883);
               this.i += this.U * -480504993;
               this.Y += 1401525773 * this.V;

               for(this.Q += -1298028627 * this.W; this.i * 1081228573 < 0; this.i += 1188253696) {
                  ;
               }

               while(1081228573 * this.i > 4096) {
                  this.i -= 1188253696;
               }

               if (this.Y * -736197367 < 0) {
                  this.Y = 0;
               }

               if (-736197367 * this.Y > 4096) {
                  this.Y = 697536512;
               }

               if (-469731721 * this.Q < 0) {
                  this.Q = 0;
               }

               if (-469731721 * this.Q > 4096) {
                  this.Q = 607416320;
               }

               this.toString(1081228573 * this.i, -736197367 * this.Y, -469731721 * this.Q, -1235292265);
               var8[var11] = -1916696729 * this.z;
               var9[var11] = this.c * 995837071;
               var10[var11] = 826309923 * this.b;
            }
         }

         return var3;
      } catch (RuntimeException var12) {
         throw DQ.I(var12, "agg.k(" + ')');
      }
   }

   void toString(int var1, int var2, int var3, int var4) {
      try {
         int var5 = var3 <= 2048 ? var3 * (4096 + var2) >> 12 : var3 + var2 - (var2 * var3 >> 12);
         if (var5 > 0) {
            var1 *= 6;
            int var6 = var3 + var3 - var5;
            int var7 = (var5 - var6 << 12) / var5;
            int var8 = var1 >> 12;
            int var9 = var1 - (var8 << 12);
            int var10 = var5 * var7 >> 12;
            var10 = var9 * var10 >> 12;
            int var11 = var6 + var10;
            int var12 = var5 - var10;
            switch(var8) {
            case 0:
               this.z = -1501846441 * var5;
               this.c = var11 * -721593745;
               this.b = var6 * 1447533195;
               break;
            case 1:
               this.z = var12 * -1501846441;
               this.c = -721593745 * var5;
               this.b = var6 * 1447533195;
               break;
            case 2:
               this.z = var6 * -1501846441;
               this.c = -721593745 * var5;
               this.b = var11 * 1447533195;
               break;
            case 3:
               this.z = -1501846441 * var6;
               this.c = var12 * -721593745;
               this.b = 1447533195 * var5;
               break;
            case 4:
               this.z = var11 * -1501846441;
               this.c = -721593745 * var6;
               this.b = var5 * 1447533195;
               break;
            case 5:
               this.z = -1501846441 * var5;
               this.c = var6 * -721593745;
               this.b = var12 * 1447533195;
            }
         } else {
            this.z = (this.c = (this.b = var3 * 1447533195) * -1366585299) * 1319430297;
         }

      } catch (RuntimeException var13) {
         throw DQ.I(var13, "agg.am(" + ')');
      }
   }

   void Z(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.U = var2.J(1756517638) * -479167509;
         break;
      case 1:
         this.V = (var2.S(-12558881) << 12) / 100 * 634933469;
         break;
      case 2:
         this.W = (var2.S(-12558881) << 12) / 100 * -91159229;
      }

   }

   void append(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.U = var2.J(1627728425) * -479167509;
         break;
      case 1:
         this.V = (var2.S(-12558881) << 12) / 100 * 634933469;
         break;
      case 2:
         this.W = (var2.S(-12558881) << 12) / 100 * -91159229;
      }

   }

   void Z(int var1, int var2, int var3, int var4) {
      try {
         int var5 = var1 > var2 ? var1 : var2;
         var5 = var3 > var5 ? var3 : var5;
         int var6 = var1 < var2 ? var1 : var2;
         var6 = var3 < var6 ? var3 : var6;
         int var7 = var5 - var6;
         this.Q = -745389241 * ((var5 + var6) / 2);
         if (this.Q * -469731721 > 0 && -469731721 * this.Q < 4096) {
            this.Y = -1734174407 * ((var7 << 12) / (this.Q * -469731721 <= 2048 ? this.Q * -939463442 : 8192 - this.Q * -939463442));
         } else {
            this.Y = 0;
         }

         if (var7 > 0) {
            int var8 = (var5 - var1 << 12) / var7;
            int var9 = (var5 - var2 << 12) / var7;
            int var10 = (var5 - var3 << 12) / var7;
            if (var1 == var5) {
               this.i = -1453036235 * (var2 == var6 ? var10 + 20480 : 4096 - var9);
            } else if (var2 == var5) {
               this.i = (var3 == var6 ? var8 + 4096 : 12288 - var10) * -1453036235;
            } else {
               this.i = -1453036235 * (var6 == var1 ? var9 + 12288 : 20480 - var8);
            }

            this.i = this.i * 1081228573 / 6 * -1453036235;
         } else {
            this.i = 0;
         }

      } catch (RuntimeException var11) {
         throw DQ.I(var11, "agg.ac(" + ')');
      }
   }

   int[][] toString(int var1) {
      int[][] var2 = this.L.I(var1, (byte)106);
      if (this.L.I) {
         int[][] var3 = this.I(0, var1, (byte)8);
         int[] var4 = var3[0];
         int[] var5 = var3[1];
         int[] var6 = var3[2];
         int[] var7 = var2[0];
         int[] var8 = var2[1];
         int[] var9 = var2[2];

         for(int var10 = 0; var10 < WJ.C * -1474554145; ++var10) {
            this.Z(var4[var10], var5[var10], var6[var10], -128256883);
            this.i += this.U * -480504993;
            this.Y += 1401525773 * this.V;

            for(this.Q += -1298028627 * this.W; this.i * 1081228573 < 0; this.i += 1188253696) {
               ;
            }

            while(1081228573 * this.i > 4096) {
               this.i -= 1188253696;
            }

            if (this.Y * -736197367 < 0) {
               this.Y = 0;
            }

            if (-736197367 * this.Y > 4096) {
               this.Y = 697536512;
            }

            if (-469731721 * this.Q < 0) {
               this.Q = 0;
            }

            if (-469731721 * this.Q > 4096) {
               this.Q = 607416320;
            }

            this.toString(1081228573 * this.i, -736197367 * this.Y, -469731721 * this.Q, -2007691649);
            var7[var10] = -1916696729 * this.z;
            var8[var10] = this.c * 995837071;
            var9[var10] = 826309923 * this.b;
         }
      }

      return var2;
   }

   public AK() {
      super(1, false);
   }

   void I(int var1, REI var2, byte var3) {
      try {
         switch(var1) {
         case 0:
            this.U = var2.J(1909722828) * -479167509;
            break;
         case 1:
            this.V = (var2.S(-12558881) << 12) / 100 * 634933469;
            break;
         case 2:
            this.W = (var2.S(-12558881) << 12) / 100 * -91159229;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "agg.r(" + ')');
      }
   }
}
