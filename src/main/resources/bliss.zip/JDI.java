public class JDI {
   public int[] I;
   public int[] Z;
   public float[][] C;
   UT B;
   public int[] D;

   JDI(UT var1, int[] var2, int[] var3, int[] var4, float[][] var5) {
      this.B = var1;
      this.D = var2;
      this.Z = var3;
      this.I = var4;
      this.C = var5;
   }
}
