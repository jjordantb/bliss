import jaggl.OpenGL;
import java.awt.Canvas;

public class JS {
   public static GSI init(Canvas var0, FEI var1, KJ var2, int var3) {
      try {
         boolean var5 = NJI.U();
         if (!var5) {
            throw new RuntimeException("");
         } else if (!NFI.Z(124070140).method265("jaggl", 1929575447)) {
            throw new RuntimeException("");
         } else {
            IG.I((Canvas)var0, (short)27333);
            OpenGL var6 = new OpenGL();
            long var7 = var6.init(var0, 8, 8, 8, 24, 0, var3);
            if (var7 == 0L) {
               throw new RuntimeException("");
            } else {
               OJI var9 = new OJI(var6, var0, var7, var1, var2, var3);
               var9.Z();
               return var9;
            }
         }
      } catch (RuntimeException var10) {
         throw var10;
      } catch (Throwable var11) {
         throw new RuntimeException("");
      }
   }

   public static GSI I(Canvas var0, FEI var1, KJ var2, int var3) {
      try {
         boolean var5 = NJI.U();
         if (!var5) {
            throw new RuntimeException("");
         } else if (!NFI.Z(-1548451136).method265("jaggl", 2093277458)) {
            throw new RuntimeException("");
         } else {
            IG.I((Canvas)var0, (short)29057);
            OpenGL var6 = new OpenGL();
            long var7 = var6.init(var0, 8, 8, 8, 24, 0, var3);
            if (var7 == 0L) {
               throw new RuntimeException("");
            } else {
               OJI var9 = new OJI(var6, var0, var7, var1, var2, var3);
               var9.Z();
               return var9;
            }
         }
      } catch (RuntimeException var10) {
         throw var10;
      } catch (Throwable var11) {
         throw new RuntimeException("");
      }
   }

   public static GSI method265(Canvas var0, FEI var1, KJ var2, int var3) {
      try {
         boolean var5 = NJI.U();
         if (!var5) {
            throw new RuntimeException("");
         } else if (!NFI.Z(-411038665).method265("jaggl", 997775077)) {
            throw new RuntimeException("");
         } else {
            IG.I((Canvas)var0, (short)12847);
            OpenGL var6 = new OpenGL();
            long var7 = var6.init(var0, 8, 8, 8, 24, 0, var3);
            if (var7 == 0L) {
               throw new RuntimeException("");
            } else {
               OJI var9 = new OJI(var6, var0, var7, var1, var2, var3);
               var9.Z();
               return var9;
            }
         }
      } catch (RuntimeException var10) {
         throw var10;
      } catch (Throwable var11) {
         throw new RuntimeException("");
      }
   }

   JS() throws Throwable {
      throw new Error();
   }
}
