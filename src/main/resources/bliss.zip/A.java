public class A {
   static Q I;
   public static int Z;

   A() throws Throwable {
      throw new Error();
   }

   public static final void I(int var0) {
      try {
         if (!XEI.zZ) {
            XEI.iZ += (12.0F - XEI.iZ) / 2.0F;
            XEI.bZ = true;
            XEI.zZ = true;
         }

      } catch (RuntimeException var2) {
         throw DQ.I(var2, "ei.hf(" + ')');
      }
   }
}
