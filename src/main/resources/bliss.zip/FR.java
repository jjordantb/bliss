public class FR extends ZR implements HAI {
   boolean append;
   boolean i = true;
   HP method4739;
   public GBI V;

   public int method45() {
      return 1686561661 * this.V.S;
   }

   public void method40(GSI var1) {
      this.V.Z(var1, -475225909);
   }

   boolean method4376(short var1) {
      try {
         return this.i;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wb.be(" + ')');
      }
   }

   public int S() {
      return this.V.I(2067905019);
   }

   public HP method4358(GSI var1, byte var2) {
      try {
         return this.method4739;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "wb.bc(" + ')');
      }
   }

   public int Z(byte var1) {
      try {
         return this.V.I(2130168413);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wb.bx(" + ')');
      }
   }

   KP method4394(GSI var1, int var2) {
      try {
         UT var3 = this.V.I(var1, 2048, false, true, (byte)-57);
         if (var3 == null) {
            return null;
         } else {
            LF var4 = this.J();
            KP var5 = BDI.I(this.append, 2063497884);
            this.V.I(var1, var3, var4, this.R, this.P, this.O, this.Q, true, -1012043162);
            var3.method4739(var4, this.N[0], 0);
            if (this.V.A != null) {
               XBI var6 = this.V.A.D();
               var1.method5042(var6);
            }

            this.i = var3.i() || this.V.A != null;
            ZJ var8 = this.I();
            if (this.method4739 == null) {
               this.method4739 = TY.I((int)var8.I.I, (int)var8.I.C, (int)var8.I.Z, var3, 2102300676);
            } else {
               QS.I(this.method4739, (int)var8.I.I, (int)var8.I.C, (int)var8.I.Z, var3, (byte)75);
            }

            return var5;
         }
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "wb.bo(" + ')');
      }
   }

   void method4357(GSI var1, int var2) {
      try {
         UT var3 = this.V.I(var1, 262144, true, true, (byte)67);
         if (var3 != null) {
            this.V.I(var1, var3, this.J(), this.R, this.P, this.O, this.Q, false, -2006037308);
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "wb.bb(" + ')');
      }
   }

   public void I(DX var1, int var2) {
      try {
         this.V.I(var1, -38768975);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "wb.bl(" + ')');
      }
   }

   boolean method4350(GSI var1, int var2, int var3, byte var4) {
      try {
         UT var5 = this.V.I(var1, 131072, false, false, (byte)7);
         return var5 == null ? false : var5.method4787(var2, var3, this.J(), false, 0);
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "wb.bu(" + ')');
      }
   }

   final boolean method4366(int var1) {
      return false;
   }

   public boolean method39(int var1) {
      try {
         return this.V.C(1788044006);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wb.i(" + ')');
      }
   }

   public int method32(byte var1) {
      try {
         return 1686561661 * this.V.S;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wb.a(" + ')');
      }
   }

   public int method29(int var1) {
      try {
         return -1598457753 * this.V.I;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wb.f(" + ')');
      }
   }

   public int method30(short var1) {
      try {
         return 748228569 * this.V.Z;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wb.b(" + ')');
      }
   }

   public void method31(byte var1) {
   }

   public int method4381() {
      return this.V.Z(-1265114071);
   }

   public void method33(GSI var1, int var2) {
      try {
         this.V.I(var1, -2138385554);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "wb.k(" + ')');
      }
   }

   public void method37(GSI var1, int var2) {
      try {
         this.V.Z(var1, -475225909);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "wb.d(" + ')');
      }
   }

   public HP method4368(GSI var1) {
      return this.method4739;
   }

   public int method36() {
      return -1598457753 * this.V.I;
   }

   public int append() {
      return this.V.I(2122295662);
   }

   public int method42() {
      return 748228569 * this.V.Z;
   }

   boolean method4399(byte var1) {
      return false;
   }

   public void method34() {
   }

   public boolean method41() {
      return this.V.C(1659146162);
   }

   boolean method4383() {
      return this.i;
   }

   public int method38() {
      return 748228569 * this.V.Z;
   }

   public void method44(GSI var1) {
      this.V.Z(var1, -475225909);
   }

   boolean method4372(GSI var1, int var2, int var3) {
      UT var4 = this.V.I(var1, 131072, false, false, (byte)40);
      return var4 == null ? false : var4.method4787(var2, var3, this.J(), false, 0);
   }

   boolean method4353() {
      return false;
   }

   boolean method4365() {
      return false;
   }

   boolean method4374() {
      return false;
   }

   final void method4377() {
      throw new IllegalStateException();
   }

   public int method35() {
      return -1598457753 * this.V.I;
   }

   boolean method4352(GSI var1, int var2, int var3) {
      UT var4 = this.V.I(var1, 131072, false, false, (byte)103);
      return var4 == null ? false : var4.method4787(var2, var3, this.J(), false, 0);
   }

   final boolean method4384() {
      return false;
   }

   KP method4370(GSI var1) {
      UT var2 = this.V.I(var1, 2048, false, true, (byte)16);
      if (var2 == null) {
         return null;
      } else {
         LF var3 = this.J();
         KP var4 = BDI.I(this.append, 1631876582);
         this.V.I(var1, var2, var3, this.R, this.P, this.O, this.Q, true, -1124309983);
         var2.method4739(var3, this.N[0], 0);
         if (this.V.A != null) {
            XBI var5 = this.V.A.D();
            var1.method5042(var5);
         }

         this.i = var2.i() || this.V.A != null;
         ZJ var6 = this.I();
         if (this.method4739 == null) {
            this.method4739 = TY.I((int)var6.I.I, (int)var6.I.C, (int)var6.I.Z, var2, 2091041559);
         } else {
            QS.I(this.method4739, (int)var6.I.I, (int)var6.I.C, (int)var6.I.Z, var2, (byte)35);
         }

         return var4;
      }
   }

   void method4371(GSI var1) {
      UT var2 = this.V.I(var1, 262144, true, true, (byte)-6);
      if (var2 != null) {
         this.V.I(var1, var2, this.J(), this.R, this.P, this.O, this.Q, false, 1373727999);
      }

   }

   void method4373(GSI var1) {
      UT var2 = this.V.I(var1, 262144, true, true, (byte)-61);
      if (var2 != null) {
         this.V.I(var1, var2, this.J(), this.R, this.P, this.O, this.Q, false, 1730822364);
      }

   }

   final boolean method4387() {
      return false;
   }

   public void method43(GSI var1) {
      this.V.Z(var1, -475225909);
   }

   boolean method4382() {
      return this.i;
   }

   boolean method4385(GSI var1, int var2, int var3) {
      UT var4 = this.V.I(var1, 131072, false, false, (byte)28);
      return var4 == null ? false : var4.method4787(var2, var3, this.J(), false, 0);
   }

   public HP method4367(GSI var1) {
      return this.method4739;
   }

   final void method4375(GSI var1, IR var2, int var3, int var4, int var5, boolean var6) {
      throw new IllegalStateException();
   }

   final void method4388(GSI var1, IR var2, int var3, int var4, int var5, boolean var6) {
      throw new IllegalStateException();
   }

   final boolean method4400() {
      return false;
   }

   public FR(AP var1, GSI var2, CX var3, KEI var4, int var5, int var6, int var7, int var8, int var9, boolean var10, int var11, int var12, int var13, int var14, int var15, int var16, int var17) {
      super(var1, var5, var6, var7, var8, var9, var11, var12, var13, var14, 512737201 * var4.h == 1, Q.I(var15, var16, -1836023814));
      this.V = new GBI(var2, var3, var4, var15, var16, this.K, var6, this, var10, var17);
      this.append = 1532834983 * var4.K != 0 && !var10;
      this.I(1, 823536706);
   }

   public int method4379() {
      return this.V.Z(-462285436);
   }

   public void method28(GSI var1) {
      this.V.I(var1, 700008268);
   }

   boolean method4369() {
      return this.i;
   }

   boolean method4349() {
      return this.i;
   }

   final void method4355(GSI var1, IR var2, int var3, int var4, int var5, boolean var6, int var7) {
      try {
         throw new IllegalStateException();
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "wb.bk(" + ')');
      }
   }

   final void method4398(byte var1) {
      try {
         throw new IllegalStateException();
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wb.bq(" + ')');
      }
   }

   boolean method4351() {
      return this.i;
   }

   final void method4378() {
      throw new IllegalStateException();
   }

   public int method4380() {
      return this.V.Z(674885315);
   }

   final boolean method4386() {
      return false;
   }

   public int method4361(int var1) {
      try {
         return this.V.Z(677575417);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wb.bm(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-18);
         X var4 = IU.F[var2 >> 16];
         GBI.I(var3, var4, var0, (byte)0);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "wb.gw(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         if (WBI.S != null && -316347407 * GJ.Z < CQ.L * 367592105) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = WBI.S[(GJ.Z += 1578804497) * -316347407 - 1] & '\uffff';
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = -1;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wb.ads(" + ')');
      }
   }

   public static void Z(int var0, int var1) {
      try {
         VK var2 = IV.I(5, (long)var0);
         var2.B(-1791340902);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wb.x(" + ')');
      }
   }
}
