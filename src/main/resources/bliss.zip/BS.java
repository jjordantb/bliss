public class BS {
   KJ Z;
   KJ append;
   JQ random = new JQ(64);
   static int toString = 0;
   static int I = 32768;
   public static int C;

   public KL I(int var1, int var2) {
      try {
         KL var3 = (KL)this.random.I((long)var1);
         if (var3 != null) {
            return var3;
         } else {
            byte[] var4;
            if (var1 >= 32768) {
               var4 = this.append.I(0, var1 & 32767, (byte)-102);
            } else {
               var4 = this.Z.I(0, var1, (byte)-91);
            }

            var3 = new KL();
            if (var4 != null) {
               var3.Z(new REI(var4), 754160666);
            }

            if (var1 >= 32768) {
               var3.B(-1787095576);
            }

            this.random.I(var3, (long)var1);
            return var3;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ks.a(" + ')');
      }
   }

   public BS(XW var1, KJ var2, KJ var3) {
      this.Z = var2;
      this.append = var3;
      if (this.Z != null) {
         this.Z.F(0, 1395155699);
      }

      if (this.append != null) {
         this.append.F(0, 393673779);
      }

   }

   static final void I(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         FU.I(var3, var4, var0, (byte)-101);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ks.hf(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)44);
         X var4 = IU.F[var2 >> 16];
         KBI.I(var3, var4, var0, (byte)59);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ks.jv(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-44);
         X var4 = IU.F[var2 >> 16];
         EC.I(var3, var4, var0, (byte)-112);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ks.lo(" + ')');
      }
   }

   static final void B(OU var0, int var1) {
      try {
         String var2 = (String)var0.S[(var0.A -= 969361751) * -203050393];
         var0.J -= -783761378;
         int var3 = var0.H[var0.J * 681479919];
         int var4 = var0.H[1 + var0.J * 681479919];
         LZI var5 = XO.I(BB.G, var4, 0, (byte)57);
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var5.Z(var2, var3, WI.D, 1970071925);
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ks.zf(" + ')');
      }
   }

   static int[] I(PK var0, int var1) {
      try {
         REI var2 = new REI(518);
         int[] var3 = new int[4];

         int var4;
         for(var4 = 0; var4 < 4; ++var4) {
            var3[var4] = (int)(Math.random() * 9.9999999E7D);
         }

         var2.F((int)10);
         var2.B(var3[0], 287776861);
         var2.B(var3[1], -691239943);
         var2.B(var3[2], 341776687);
         var2.B(var3[3], -551127202);

         for(var4 = 0; var4 < 10; ++var4) {
            var2.B((int)(Math.random() * 9.9999999E7D), -1703203090);
         }

         var2.Z((int)(Math.random() * 9.9999999E7D), 16711935);
         var2.I(AZI.I, AZI.B, 1970926718);
         var0.J.I(var2.S, 0, 385051775 * var2.A, (short)-19107);
         return var3;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ks.s(" + ')');
      }
   }
}
