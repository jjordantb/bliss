public interface JAI {
   int method256(int var1);

   HY method257();

   int method258();

   HY method259();

   HY method260(int var1);

   HY method261();
}
