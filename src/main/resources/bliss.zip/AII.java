import jaggl.OpenGL;

public class AII extends RY {
   static char glDisable = '\u0001';
   boolean glEnable = false;
   KA glLoadIdentity;
   static char glLoadMatrixf = 0;

   void method508(boolean var1) {
      this.I.Z(8448, 7681);
   }

   boolean method501() {
      return true;
   }

   void method505(boolean var1) {
      DO var2 = this.I.E();
      if (this.glLoadIdentity != null && var2 != null && var1) {
         this.glLoadIdentity.I('\u0000');
         this.I.C(1);
         this.I.I((SN)var2);
         OpenGL.glMatrixMode(5890);
         OpenGL.glLoadMatrixf(this.I.P.D(this.I.c), 0);
         OpenGL.glMatrixMode(5888);
         this.I.C(0);
         this.glEnable = true;
      } else {
         this.I.C(0, 34168, 770);
      }

   }

   void method518(boolean var1) {
      this.I.Z(8448, 7681);
   }

   void method509(boolean var1) {
      this.I.Z(8448, 7681);
   }

   void method503(int var1, int var2) {
   }

   void method500(SN var1, int var2) {
      this.I.I(var1);
      this.I.I(var2);
   }

   void method506(boolean var1) {
      DO var2 = this.I.E();
      if (this.glLoadIdentity != null && var2 != null && var1) {
         this.glLoadIdentity.I('\u0000');
         this.I.C(1);
         this.I.I((SN)var2);
         OpenGL.glMatrixMode(5890);
         OpenGL.glLoadMatrixf(this.I.P.D(this.I.c), 0);
         OpenGL.glMatrixMode(5888);
         this.I.C(0);
         this.glEnable = true;
      } else {
         this.I.C(0, 34168, 770);
      }

   }

   void method510(boolean var1) {
      this.I.Z(8448, 7681);
   }

   void method516(int var1, int var2) {
   }

   void method507(boolean var1) {
      DO var2 = this.I.E();
      if (this.glLoadIdentity != null && var2 != null && var1) {
         this.glLoadIdentity.I('\u0000');
         this.I.C(1);
         this.I.I((SN)var2);
         OpenGL.glMatrixMode(5890);
         OpenGL.glLoadMatrixf(this.I.P.D(this.I.c), 0);
         OpenGL.glMatrixMode(5888);
         this.I.C(0);
         this.glEnable = true;
      } else {
         this.I.C(0, 34168, 770);
      }

   }

   AII(MJI var1) {
      super(var1);
      if (var1.SI) {
         this.glLoadIdentity = new KA(var1, 2);
         this.glLoadIdentity.I((int)0);
         this.I.C(1);
         this.I.Z(34165, 7681);
         this.I.I(2, 34168, 770);
         this.I.C(0, 34167, 770);
         OpenGL.glTexGeni(8192, 9472, 34066);
         OpenGL.glTexGeni(8193, 9472, 34066);
         OpenGL.glTexGeni(8194, 9472, 34066);
         OpenGL.glEnable(3168);
         OpenGL.glEnable(3169);
         OpenGL.glEnable(3170);
         this.I.C(0);
         this.glLoadIdentity.I();
         this.glLoadIdentity.I((int)1);
         this.I.C(1);
         this.I.Z(8448, 8448);
         this.I.I(2, 34166, 770);
         this.I.C(0, 5890, 770);
         OpenGL.glDisable(3168);
         OpenGL.glDisable(3169);
         OpenGL.glDisable(3170);
         OpenGL.glMatrixMode(5890);
         OpenGL.glLoadIdentity();
         OpenGL.glMatrixMode(5888);
         this.I.C(0);
         this.glLoadIdentity.I();
      }

   }

   void method511() {
      if (this.glEnable) {
         this.glLoadIdentity.I('\u0001');
         this.I.C(1);
         this.I.I((SN)null);
         this.I.C(0);
      } else {
         this.I.C(0, 5890, 770);
      }

      this.I.Z(8448, 8448);
      this.glEnable = false;
   }

   void method512() {
      if (this.glEnable) {
         this.glLoadIdentity.I('\u0001');
         this.I.C(1);
         this.I.I((SN)null);
         this.I.C(0);
      } else {
         this.I.C(0, 5890, 770);
      }

      this.I.Z(8448, 8448);
      this.glEnable = false;
   }

   void method513(int var1, int var2) {
   }

   void method504() {
      if (this.glEnable) {
         this.glLoadIdentity.I('\u0001');
         this.I.C(1);
         this.I.I((SN)null);
         this.I.C(0);
      } else {
         this.I.C(0, 5890, 770);
      }

      this.I.Z(8448, 8448);
      this.glEnable = false;
   }

   void method515(int var1, int var2) {
   }

   void method502(int var1, int var2) {
   }

   void method517(int var1, int var2) {
   }

   void method514(SN var1, int var2) {
      this.I.I(var1);
      this.I.I(var2);
   }

   void method519(SN var1, int var2) {
      this.I.I(var1);
      this.I.I(var2);
   }

   boolean method520() {
      return true;
   }
}
