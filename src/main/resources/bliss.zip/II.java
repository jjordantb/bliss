public class II {
   public static II I = new II(14, 10);
   static II B = new II(22);
   static II J = new II(17);
   public static II Z = new II(12, 7);
   public static II C = new II(9, 7);
   public static II D = new II(24);
   static II append = new II(38);
   public static II F = new II(8, 8);
   public static II S = new II(54);
   static II length = new II(2);
   public static II A = new II(11);
   public static II E = new II(30);
   static II toString = new II(43);
   public static II G = new II(34);
   public static II H = new II(15);
   public static II K = new II(16);
   static II L = new II(44);
   static II M = new II(18);
   public static II N = new II(19);
   public static II O = new II(3);
   static II P = new II(21);
   public static II Q = new II(5);
   public static II R = new II(1);
   public static II T = new II(10, 8);
   public static II U = new II(25);
   public static II V = new II(26);
   static II W = new II(27);
   static II X = new II(28);
   public static II Y = new II(29);
   static II i = new II(20);
   public static II z = new II(31);
   public static II c = new II(32);
   public static II b = new II(33);
   public static II d = new II(4);
   public static II f = new II(35);
   public static II j = new II(36);
   static II s = new II(37);
   public static II a = new II(6, 8);
   static II e = new II(39);
   static II g = new II(40);
   static II h = new II(41);
   static II k = new II(42);
   static II l = new II(7);
   public static II m = new II(13, 8);
   static II n = new II(45);
   public static II o = new II(46);
   public static II p = new II(47);
   static II q = new II(48);
   static II r = new II(49);
   static II t = new II(50);
   static II u = new II(51);
   static II v = new II(53);
   static II w = new II(23);
   static II x = new II(70);
   public int y;
   int II;
   public static String ZI;
   public static RII CI;

   public int I(int var1, int var2) {
      try {
         return var1 & (1 << this.II * -82175751) - 1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ew.b(" + ')');
      }
   }

   II(int var1, int var2) {
      this.y = var1 * -1878339489;
      this.II = var2 * -1094244023;
   }

   public int I(short var1) {
      try {
         return 1 << -82175751 * this.II;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ew.a(" + ')');
      }
   }

   public int Z(int var1, int var2) {
      try {
         return var1 >>> -82175751 * this.II;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ew.f(" + ')');
      }
   }

   II(int var1) {
      this(var1, 0);
   }

   public static String I(int var0, byte var1) {
      try {
         NM var2 = (NM)QW.C.I((long)var0);
         if (var2 != null) {
            KG var3 = var2.E.C((byte)-78);
            if (var3 != null) {
               double var4 = var2.E.I((short)4615);
               if ((double)var3.Z((byte)8) <= var4 && (double)var3.C(-327557193) >= var4) {
                  return var3.B(-700699994);
               }
            }
         }

         return null;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ew.i(" + ')');
      }
   }

   static void I(byte var0) {
      try {
         DN.J.I();
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "ew.z(" + ')');
      }
   }

   public static int I(String var0, byte var1) {
      try {
         return var0.length() + 2;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ew.y(" + ')');
      }
   }

   static void I(int var0) {
      try {
         TQ.Z = -1058684408;
         TQ.d = XEI.TI;
         if (XEI.ZB != null) {
            REI var1 = new REI(XEI.ZB);
            TQ.F = var1.I((short)19840) * -2742373017286080113L;
            TQ.g = var1.I((short)15472) * 3207425516430892907L;
         }

         if (122690138525332847L * TQ.F < 0L) {
            ADI.I(35, 1176559477);
         } else {
            AY.I(false, true, "", "", TQ.F * 122690138525332847L);
         }

      } catch (RuntimeException var2) {
         throw DQ.I(var2, "ew.y(" + ')');
      }
   }

   static float I(float var0, float var1, float var2, float var3, float var4, float var5, int var6, int var7) {
      try {
         float var8 = 0.0F;
         float var9 = var3 - var0;
         float var10 = var4 - var1;
         float var11 = var5 - var2;
         float var12 = 0.0F;
         float var13 = 0.0F;
         float var14 = 0.0F;

         for(AP var15 = XEI.mI.T(-1611682495); var8 < 1.1F; var8 += 0.1F) {
            float var16 = var9 * var8 + var0;
            float var17 = var1 + var8 * var10;
            float var18 = var8 * var11 + var2;
            int var19 = (int)var16 >> 9;
            int var20 = (int)var18 >> 9;
            if (var19 > 0 && var20 > 0 && var19 < XEI.mI.Z(-1954958237) && var20 < XEI.mI.C(-1173220944)) {
               int var21 = UA.F.K;
               if (var21 < 3 && (XEI.mI.M(936952439).C[1][var19][var20] & 2) != 0) {
                  ++var21;
               }

               int var22 = var15.K[var21].I((int)var16, (int)var18, -1328298083);
               if ((float)var22 < var17) {
                  if (var6 >= 2) {
                     return var8 - 0.1F + I(var12, var13, var14, var16, var17, var18, var6 - 1, 1869450178) * 0.1F;
                  }

                  return var8;
               }
            }

            var12 = var16;
            var13 = var17;
            var14 = var18;
         }

         return -1.0F;
      } catch (RuntimeException var23) {
         throw DQ.I(var23, "ew.bn(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         FW.J.I(FW.J.N, var0.H[(var0.J -= -391880689) * 681479919] == 1 ? 1 : 0, -1686668837);
         JN.I(656179282);
         XEI.w = false;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ew.aio(" + ')');
      }
   }
}
