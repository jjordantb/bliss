public class FM extends RL {
   LC append;
   long toString;
   int J;

   void method3510(QC var1, byte var2) {
      try {
         var1.I(this.J * -994398103, 1342935022598277865L * this.toString);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "agn.f(" + ')');
      }
   }

   void method3509(REI var1) {
      this.J = var1.H((byte)64) * 1255006169;
      this.toString = var1.I((short)9128) * 3352878270957006169L;
   }

   void method3508(REI var1, int var2) {
      try {
         this.J = var1.H((byte)-40) * 1255006169;
         this.toString = var1.I((short)26335) * 3352878270957006169L;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "agn.a(" + ')');
      }
   }

   FM(LC var1) {
      this.append = var1;
   }

   void method3512(REI var1) {
      this.J = var1.H((byte)-113) * 1255006169;
      this.toString = var1.I((short)19522) * 3352878270957006169L;
   }

   void method3511(QC var1) {
      var1.I(this.J * -994398103, 1342935022598277865L * this.toString);
   }
}
