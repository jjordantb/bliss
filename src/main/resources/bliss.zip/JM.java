public class JM extends RL {
   byte append;
   LC toString;
   public static int J;
   int S;

   void method3509(REI var1) {
      this.S = var1.C() * 203579807;
      this.append = var1.S(-12558881);
   }

   void method3508(REI var1, int var2) {
      try {
         this.S = var1.C() * 203579807;
         this.append = var1.S(-12558881);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ago.a(" + ')');
      }
   }

   JM(LC var1) {
      this.toString = var1;
      this.S = -203579807;
   }

   void method3511(QC var1) {
      var1.I(1481144927 * this.S, this.append, (byte)-65);
   }

   void method3512(REI var1) {
      this.S = var1.C() * 203579807;
      this.append = var1.S(-12558881);
   }

   void method3510(QC var1, byte var2) {
      try {
         var1.I(1481144927 * this.S, this.append, (byte)-101);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ago.f(" + ')');
      }
   }
}
