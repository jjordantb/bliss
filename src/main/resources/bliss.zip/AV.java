public final class AV {
   public static int I;

   AV() throws Throwable {
      throw new Error();
   }

   static final void I(OU var0, byte var1) {
      try {
         HSI var2 = AZI.I(var0.H[(var0.J -= -391880689) * 681479919], (byte)-64);
         if (var2.SC == null) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
         } else {
            int var3 = var2.SC.length;

            for(int var4 = 0; var4 < var2.SC.length; ++var4) {
               if (var2.SC[var4] == null) {
                  var3 = var4;
                  break;
               }
            }

            var0.H[(var0.J += -391880689) * 681479919 - 1] = var3;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ri.ro(" + ')');
      }
   }

   static void Z(OU var0, byte var1) {
      try {
         UR var2 = OO.I.I(var0.H[(var0.J -= -391880689) * 681479919], 245040087);
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var2.S == null ? 0 : var2.S.length;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ri.n(" + ')');
      }
   }

   static void I(byte var0) {
      try {
         TQ.Z = 471358088;
         TQ.d = XEI.eI;
         if (XEI.ZB != null) {
            REI var1 = new REI(XEI.ZB);
            TQ.F = var1.I((short)16837) * -2742373017286080113L;
            TQ.g = var1.I((short)3310) * 3207425516430892907L;
         }

         if (TQ.F * 122690138525332847L < 0L) {
            ADI.I(35, 1368689895);
         } else {
            AY.I(false, true, "", "", TQ.F * 122690138525332847L);
         }

      } catch (RuntimeException var2) {
         throw DQ.I(var2, "ri.h(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)84);
         X var4 = IU.F[var2 >> 16];
         IT.I(var3, var4, var0, -750827082);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ri.ne(" + ')');
      }
   }

   static void I(int var0, int var1, int var2) {
      try {
         VK var3 = IV.I(17, (long)var0);
         var3.I((byte)28);
         var3.L = var1 * 1274450087;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ri.ar(" + ')');
      }
   }

   static void Z(byte var0) {
      try {
         DN.S.I((byte)-68);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "ri.r(" + ')');
      }
   }
}
