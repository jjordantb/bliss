public class CV implements BAI {
   public static CV I = new CV(-5);
   static CV Z = new CV(-4);
   public static CV C = new CV(-3);
   static CV B = new CV(3);
   static CV D = new CV(-1);
   public static CV F = new CV(-2);
   public static CV J = new CV(2);
   static CV S = new CV(7);
   static CV A = new CV(9);
   static CV E = new CV(37);
   int append;
   public static OZI G;

   public int method242(int var1) {
      try {
         return -1789529873 * this.append;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "rc.f(" + ')');
      }
   }

   public int method244() {
      return -1789529873 * this.append;
   }

   public int method243() {
      return -1789529873 * this.append;
   }

   CV(int var1) {
      this.append = -1875689969 * var1;
   }

   static final int I(int var0, int var1, byte var2) {
      try {
         int var3 = SCI.I('넵' + var0, 91923 + var1, 4, -715391467) - 128 + (SCI.I(10294 + var0, '鎽' + var1, 2, -715391467) - 128 >> 1) + (SCI.I(var0, var1, 1, -715391467) - 128 >> 2);
         var3 = (int)(0.3D * (double)var3) + 35;
         if (var3 < 10) {
            var3 = 10;
         } else if (var3 > 60) {
            var3 = 60;
         }

         return var3;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "rc.m(" + ')');
      }
   }
}
