import jaggl.OpenGL;

public class FO extends SN {
   int A;
   int E;

   FO(MJI var1, int var2, YCI var3, SDI var4, int var5, int var6, boolean var7, byte[] var8, YCI var9, boolean var10) {
      super(var1, var2, var3, var4, var5 * var6, var7);
      this.A = var5;
      this.E = var6;
      if (var10) {
         byte[] var11 = new byte[var8.length];

         for(int var12 = 0; var12 < var6; ++var12) {
            int var13 = var12 * var5;
            int var14 = (var6 - var12 - 1) * var5;

            for(int var15 = 0; var15 < var5; ++var15) {
               var11[var13++] = var8[var14++];
            }
         }

         var8 = var11;
      }

      this.J.I((SN)this);
      OpenGL.glPixelStorei(3317, 1);
      if (var7 && this.I != 34037) {
         I(var2, MJI.I(this.C, this.B), var5, var6, var9, var8);
         this.Z(true);
      } else {
         OpenGL.glTexImage2Dub(this.I, 0, MJI.I(this.C, this.B), this.A, this.E, 0, MJI.I(var9), 5121, var8, 0);
         this.Z(false);
      }

      OpenGL.glPixelStorei(3317, 4);
      this.I(true);
   }

   FO(MJI var1, int var2, int var3, int var4, boolean var5, int[] var6, int var7, int var8, boolean var9) {
      super(var1, var2, YCI.Z, SDI.C, var3 * var4, var5);
      this.A = var3;
      this.E = var4;
      if (var9) {
         int[] var10 = new int[var6.length];

         for(int var11 = 0; var11 < var4; ++var11) {
            int var12 = var11 * var3;
            int var13 = (var4 - var11 - 1) * var3;

            for(int var14 = 0; var14 < var3; ++var14) {
               var10[var12++] = var6[var13++];
            }
         }

         var6 = var10;
      }

      this.J.I((SN)this);
      if (this.I != 34037 && var5 && var7 == 0 && var8 == 0) {
         I(this.I, MJI.I(this.C, this.B), this.A, this.E, 32993, this.J.NI, var6);
         this.Z(true);
      } else {
         OpenGL.glPixelStorei(3314, var7);
         OpenGL.glTexImage2Di(this.I, 0, MJI.I(this.C, this.B), this.A, this.E, 0, 32993, this.J.NI, var6, var8 * 4);
         OpenGL.glPixelStorei(3314, 0);
         this.Z(false);
      }

      this.I(true);
   }

   void I(int var1, int var2, int var3, int var4, int var5, int var6) {
      CCI var7 = this.J.I((short)-5396);
      if (var7 != null) {
         int var8 = var7.method552() - (var6 + var4);
         this.J.I((SN)this);
         OpenGL.glCopyTexSubImage2D(this.I, 0, var1, this.E - (var2 + var4), var5, var8, var3, var4);
         OpenGL.glFlush();
      }

   }

   FO(MJI var1, int var2, YCI var3, SDI var4, int var5, int var6, boolean var7, float[] var8, YCI var9) {
      super(var1, var2, var3, var4, var5 * var6, var7);
      this.A = var5;
      this.E = var6;
      this.J.I((SN)this);
      if (var7 && this.I != 34037) {
         I(var2, MJI.I(this.C, this.B), var5, var6, var9, var8);
         this.Z(true);
      } else {
         OpenGL.glTexImage2Df(this.I, 0, MJI.I(this.C, this.B), this.A, this.E, 0, MJI.I(var9), 5126, var8, 0);
         this.Z(false);
      }

      this.I(true);
   }

   void I(boolean var1, boolean var2) {
      if (this.I == 3553) {
         this.J.I((SN)this);
         OpenGL.glTexParameteri(this.I, 10242, var1 ? 10497 : '脯');
         OpenGL.glTexParameteri(this.I, 10243, var2 ? 10497 : '脯');
      }

   }

   void I(int var1, int var2, int var3, int var4, byte[] var5, YCI var6, int var7, int var8, boolean var9) {
      if (var8 == 0) {
         var8 = var3;
      }

      if (var9) {
         int var10 = var6.I * 845115459;
         int var11 = var10 * var3;
         int var12 = var10 * var8;
         byte[] var13 = new byte[var11 * var4];

         for(int var14 = 0; var14 < var4; ++var14) {
            int var15 = var14 * var11;
            int var16 = (var4 - var14 - 1) * var12 + var7;

            for(int var17 = 0; var17 < var11; ++var17) {
               var13[var15++] = var5[var16++];
            }
         }

         var5 = var13;
      }

      this.J.I((SN)this);
      OpenGL.glPixelStorei(3317, 1);
      if (var8 != var3) {
         OpenGL.glPixelStorei(3314, var8);
      }

      OpenGL.glTexSubImage2Dub(this.I, 0, var1, this.E - var2 - var4, var3, var4, MJI.I(var6), 5121, var5, var7);
      if (var8 != var3) {
         OpenGL.glPixelStorei(3314, 0);
      }

      OpenGL.glPixelStorei(3317, 4);
   }

   void I(int var1, int var2, int var3, int var4, int[] var5, int var6, int var7, boolean var8) {
      if (var7 == 0) {
         var7 = var3;
      }

      if (var8) {
         int[] var9 = new int[var3 * var4];

         for(int var10 = 0; var10 < var4; ++var10) {
            int var11 = var10 * var3;
            int var12 = (var4 - var10 - 1) * var7 + var6;

            for(int var13 = 0; var13 < var3; ++var13) {
               var9[var11++] = var5[var12++];
            }
         }

         var5 = var9;
      }

      this.J.I((SN)this);
      if (var3 != var7) {
         OpenGL.glPixelStorei(3314, var7);
      }

      OpenGL.glTexSubImage2Di(this.I, 0, var1, this.E - var2 - var4, var3, var4, 32993, this.J.NI, var5, var6);
      if (var3 != var7) {
         OpenGL.glPixelStorei(3314, 0);
      }

   }

   FO(MJI var1, int var2, int var3, int var4, int var5, int var6) {
      super(var1, var2, YCI.D, SDI.C, var5 * var6, false);
      this.A = var5;
      this.E = var6;
      this.J.I((SN)this);
      CCI var7 = this.J.I((short)-8855);
      if (var7 != null) {
         int var8 = var7.method552() - (var4 + var6);
         int var9 = MJI.I(this.C, this.B);
         OpenGL.glCopyTexImage2D(this.I, 0, var9, var3, var8, var5, var6, 0);
      }

      this.I(true);
   }

   TAI I(int var1) {
      return new CDI(this, var1);
   }

   FO(MJI var1, int var2, YCI var3, SDI var4, int var5, int var6) {
      super(var1, var2, var3, var4, var5 * var6, false);
      this.A = var5;
      this.E = var6;
      this.J.I((SN)this);
      OpenGL.glTexImage2Dub(this.I, 0, MJI.I(this.C, this.B), var5, var6, 0, MJI.I(this.C), 5121, (byte[])null, 0);
      this.I(true);
   }

   XAI Z(int var1) {
      return new CDI(this, var1);
   }
}
