public class IC implements LAI {
   public int I;
   public int Z;
   public int C;
   public int B;
   public int D;
   public int F;
   public IZ J;
   public HZ S;
   public String A;
   public int E;
   public int G;
   public int H;
   public int K;
   public static XX L;

   public RZ method49(int var1) {
      try {
         return RZ.I;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "gc.f(" + ')');
      }
   }

   public RZ method50() {
      return RZ.I;
   }

   public RZ method51() {
      return RZ.I;
   }

   IC(String var1, HZ var2, IZ var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, int var11, int var12, int var13) {
      this.A = var1;
      this.S = var2;
      this.J = var3;
      this.B = 983212181 * var4;
      this.D = 703753783 * var5;
      this.F = -719694677 * var6;
      this.I = var7 * 1732454243;
      this.E = var8 * -1607745933;
      this.Z = -2102344545 * var9;
      this.C = -299852093 * var10;
      this.G = var11 * 299588697;
      this.H = -732046791 * var12;
      this.K = -1239794753 * var13;
   }

   public static LB I(int var0, int var1) {
      try {
         LB var2 = (LB)LB.I.I((long)var0);
         if (var2 != null) {
            return var2;
         } else {
            byte[] var3 = LB.D.I(0, var0, (byte)-125);
            var2 = new LB();
            if (var3 != null) {
               var2.I(new REI(var3), (byte)20);
            }

            var2.I(-721593745);
            LB.I.I(var2, (long)var0);
            return var2;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "gc.f(" + ')');
      }
   }

   static boolean I(int var0) {
      try {
         return YII.I(PZ.B.F, -1572506836);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "gc.a(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         var0.Q[(var0.K += -682569305) * 1685767703 - 1] = var0.z.M[1883543357 * var0.i];
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "gc.bf(" + ')');
      }
   }

   static boolean Z(int var0, int var1) {
      try {
         return var0 == 18 || var0 == 16;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "gc.fg(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         LJ.I(var3, var4, var0, 2046664396);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "gc.gt(" + ')');
      }
   }

   public static final void Z(int var0) {
      try {
         if (!XEI.zZ) {
            XEI.iZ += (-12.0F - XEI.iZ) / 2.0F;
            XEI.bZ = true;
            XEI.zZ = true;
         }

      } catch (RuntimeException var2) {
         throw DQ.I(var2, "gc.hq(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         AR.B((byte)-5);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "gc.aet(" + ')');
      }
   }
}
