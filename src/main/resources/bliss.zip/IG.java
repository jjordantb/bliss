import java.awt.Canvas;
import java.lang.reflect.Method;
import java.util.Random;

public class IG extends WE {
   boolean TRUE;
   int TYPE = 1573573376;
   static IS append;
   IY getMethod = new IY();
   int invoke = 0;
   int nextInt;
   int toString;
   int valueOf = 723600640;
   boolean G;
   static int H;

   static {
      append = new IS(64, ZS.I);
      H = 100;
   }

   synchronized void method2932(int[] var1, int var2, int var3) {
      if (!this.TRUE) {
         if (this.D(753213382) == null) {
            if (this.G) {
               this.I(-1460969981);
               append.I(-406924186);
            }
         } else {
            int var4 = var2 + var3;
            if (PA.Z) {
               var4 <<= 1;
            }

            byte var5 = 0;
            byte var6 = 0;
            if (1472501875 * this.toString == 2) {
               var6 = 1;
            }

            while(var2 < var4) {
               TG var7 = this.D(753213382);
               if (var7 == null) {
                  break;
               }

               short[][] var8;
               for(var8 = var7.S; var2 < var4 && 223474833 * this.nextInt < var8[0].length; this.nextInt += -491238287) {
                  if (PA.Z) {
                     var1[var2++] = var8[var5][223474833 * this.nextInt] * this.valueOf * -153466483;
                     var1[var2++] = var8[var6][this.nextInt * 223474833] * 691346779 * this.TYPE;
                  } else {
                     int var10001 = var2++;
                     var1[var10001] += var8[var6][223474833 * this.nextInt] * 691346779 * this.TYPE + var8[var5][223474833 * this.nextInt] * this.valueOf * -153466483;
                  }
               }

               if (223474833 * this.nextInt >= var8[0].length) {
                  this.TRUE((byte)1);
               }
            }
         }
      }

   }

   public void I(int var1, byte var2) {
      try {
         this.valueOf = var1 * 489365829;
         this.TYPE = 1113443027 * var1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aii.av(" + ')');
      }
   }

   synchronized void method2934(int[] var1, int var2, int var3) {
      try {
         if (!this.TRUE) {
            if (this.D(753213382) == null) {
               if (this.G) {
                  this.I(-1460969981);
                  append.I(-600702180);
               }
            } else {
               int var4 = var2 + var3;
               if (PA.Z) {
                  var4 <<= 1;
               }

               byte var5 = 0;
               byte var6 = 0;
               if (1472501875 * this.toString == 2) {
                  var6 = 1;
               }

               while(var2 < var4) {
                  TG var7 = this.D(753213382);
                  if (var7 == null) {
                     break;
                  }

                  short[][] var8;
                  for(var8 = var7.S; var2 < var4 && 223474833 * this.nextInt < var8[0].length; this.nextInt += -491238287) {
                     if (PA.Z) {
                        var1[var2++] = var8[var5][223474833 * this.nextInt] * this.valueOf * -153466483;
                        var1[var2++] = var8[var6][this.nextInt * 223474833] * 691346779 * this.TYPE;
                     } else {
                        int var10001 = var2++;
                        var1[var10001] += var8[var6][223474833 * this.nextInt] * 691346779 * this.TYPE + var8[var5][223474833 * this.nextInt] * this.valueOf * -153466483;
                     }
                  }

                  if (223474833 * this.nextInt >= var8[0].length) {
                     this.TRUE((byte)1);
                  }
               }
            }
         }

      } catch (RuntimeException var9) {
         throw DQ.I(var9, "aii.k(" + ')');
      }
   }

   synchronized void method2935(int var1) {
      try {
         if (!this.TRUE) {
            while(true) {
               TG var2 = this.D(753213382);
               if (var2 == null) {
                  if (this.G) {
                     this.I(-1460969981);
                     append.I(952112097);
                  }
                  break;
               }

               if (var2.S[0].length - this.nextInt * 223474833 > var1) {
                  this.nextInt += var1 * -491238287;
                  break;
               }

               var1 -= var2.S[0].length - this.nextInt * 223474833;
               this.TRUE((byte)1);
            }
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aii.d(" + ')');
      }
   }

   synchronized int C(int var1) {
      try {
         return this.invoke * 528037965;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aii.at(" + ')');
      }
   }

   TG I(int var1, double var2) {
      try {
         long var4 = (long)(this.toString * 1472501875 << 32 | var1);
         TG var6 = (TG)append.I((Object)var4, (byte)-35);
         if (var6 != null) {
            var6.J = var2;
            append.I((Object)var4, (int)1695283057);
         } else {
            var6 = new TG(new short[this.toString * 1472501875][var1], var2);
         }

         return var6;
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "aii.al(" + ')');
      }
   }

   synchronized TG D(int var1) {
      try {
         return (TG)this.getMethod.Z(1766612795);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aii.ah(" + ')');
      }
   }

   WE method2944() {
      return null;
   }

   synchronized void I(TG var1, int var2) {
      try {
         while(this.invoke * 528037965 >= 100) {
            this.getMethod.I(2084948407);
            this.invoke -= -1862483835;
         }

         this.getMethod.I((AE)var1, (int)-332995145);
         this.invoke += -1862483835;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aii.az(" + ')');
      }
   }

   synchronized void B(int var1) {
      try {
         this.G = true;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aii.ap(" + ')');
      }
   }

   synchronized void I(boolean var1, int var2) {
      try {
         this.TRUE = var1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aii.af(" + ')');
      }
   }

   int method2929() {
      return 1;
   }

   WE method2931() {
      return null;
   }

   WE method2930() {
      return null;
   }

   static final void F(int var0) {
      try {
         for(int var1 = 0; var1 < -1230451913 * XEI.zI; ++var1) {
            int var2 = XEI.WI[var1];
            QG var3 = (QG)XEI.UI.I((long)var2);
            if (var3 != null) {
               GEI var4 = (GEI)var3.J;
               CZ.I(var4, false, -2088974966);
            }
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aii.hj(" + ')');
      }
   }

   synchronized void method2948(int var1) {
      if (!this.TRUE) {
         while(true) {
            TG var2 = this.D(753213382);
            if (var2 == null) {
               if (this.G) {
                  this.I(-1460969981);
                  append.I(768907089);
               }
               break;
            }

            if (var2.S[0].length - this.nextInt * 223474833 > var1) {
               this.nextInt += var1 * -491238287;
               break;
            }

            var1 -= var2.S[0].length - this.nextInt * 223474833;
            this.TRUE((byte)1);
         }
      }

   }

   WE method2937() {
      return null;
   }

   WE method2938() {
      return null;
   }

   synchronized double J(int var1) {
      try {
         if (528037965 * this.invoke < 1) {
            return -1.0D;
         } else {
            TG var2 = (TG)this.getMethod.Z(1766612795);
            return var2 == null ? -1.0D : var2.J - (double)((float)var2.S[0].length / (float)(PA.F * 1164070869));
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aii.as(" + ')');
      }
   }

   WE method2940() {
      return null;
   }

   WE method2941() {
      return null;
   }

   WE method2939() {
      return null;
   }

   public static int I(Random var0, int var1, byte var2) {
      try {
         if (var1 <= 0) {
            throw new IllegalArgumentException();
         } else if (QII.I(var1, 1882495908)) {
            return (int)(((long)var0.nextInt() & 4294967295L) * (long)var1 >> 32);
         } else {
            int var3 = Integer.MIN_VALUE - (int)(4294967296L % (long)var1);

            int var4;
            do {
               var4 = var0.nextInt();
            } while(var4 >= var3);

            if (var2 == 0) {
               throw new IllegalStateException();
            } else {
               return DJI.I(var4, var1, 1573613656);
            }
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aii.q(" + ')');
      }
   }

   int method2943() {
      return 1;
   }

   synchronized void TRUE(byte var1) {
      try {
         TG var2 = this.D(753213382);
         if (var2 != null) {
            var2.I(-1460969981);
            this.nextInt = 0;
            this.invoke -= -1862483835;
            append.I(var2.C(-1380728898), var2, (byte)98);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aii.ai(" + ')');
      }
   }

   synchronized void method2949(int var1) {
      if (!this.TRUE) {
         while(true) {
            TG var2 = this.D(753213382);
            if (var2 == null) {
               if (this.G) {
                  this.I(-1460969981);
                  append.I(-1289624266);
               }
               break;
            }

            if (var2.S[0].length - this.nextInt * 223474833 > var1) {
               this.nextInt += var1 * -491238287;
               break;
            }

            var1 -= var2.S[0].length - this.nextInt * 223474833;
            this.TRUE((byte)1);
         }
      }

   }

   synchronized void method2947(int var1) {
      if (!this.TRUE) {
         while(true) {
            TG var2 = this.D(753213382);
            if (var2 == null) {
               if (this.G) {
                  this.I(-1460969981);
                  append.I(-1874609537);
               }
               break;
            }

            if (var2.S[0].length - this.nextInt * 223474833 > var1) {
               this.nextInt += var1 * -491238287;
               break;
            }

            var1 -= var2.S[0].length - this.nextInt * 223474833;
            this.TRUE((byte)1);
         }
      }

   }

   IG(int var1) {
      this.toString = -114045765 * var1;
   }

   synchronized void method2945(int[] var1, int var2, int var3) {
      if (!this.TRUE) {
         if (this.D(753213382) == null) {
            if (this.G) {
               this.I(-1460969981);
               append.I(-1691027577);
            }
         } else {
            int var4 = var2 + var3;
            if (PA.Z) {
               var4 <<= 1;
            }

            byte var5 = 0;
            byte var6 = 0;
            if (1472501875 * this.toString == 2) {
               var6 = 1;
            }

            while(var2 < var4) {
               TG var7 = this.D(753213382);
               if (var7 == null) {
                  break;
               }

               short[][] var8;
               for(var8 = var7.S; var2 < var4 && 223474833 * this.nextInt < var8[0].length; this.nextInt += -491238287) {
                  if (PA.Z) {
                     var1[var2++] = var8[var5][223474833 * this.nextInt] * this.valueOf * -153466483;
                     var1[var2++] = var8[var6][this.nextInt * 223474833] * 691346779 * this.TYPE;
                  } else {
                     int var10001 = var2++;
                     var1[var10001] += var8[var6][223474833 * this.nextInt] * 691346779 * this.TYPE + var8[var5][223474833 * this.nextInt] * this.valueOf * -153466483;
                  }
               }

               if (223474833 * this.nextInt >= var8[0].length) {
                  this.TRUE((byte)1);
               }
            }
         }
      }

   }

   WE method2946() {
      return null;
   }

   int method2936() {
      return 1;
   }

   synchronized void method2928(int[] var1, int var2, int var3) {
      if (!this.TRUE) {
         if (this.D(753213382) == null) {
            if (this.G) {
               this.I(-1460969981);
               append.I(-701511465);
            }
         } else {
            int var4 = var2 + var3;
            if (PA.Z) {
               var4 <<= 1;
            }

            byte var5 = 0;
            byte var6 = 0;
            if (1472501875 * this.toString == 2) {
               var6 = 1;
            }

            while(var2 < var4) {
               TG var7 = this.D(753213382);
               if (var7 == null) {
                  break;
               }

               short[][] var8;
               for(var8 = var7.S; var2 < var4 && 223474833 * this.nextInt < var8[0].length; this.nextInt += -491238287) {
                  if (PA.Z) {
                     var1[var2++] = var8[var5][223474833 * this.nextInt] * this.valueOf * -153466483;
                     var1[var2++] = var8[var6][this.nextInt * 223474833] * 691346779 * this.TYPE;
                  } else {
                     int var10001 = var2++;
                     var1[var10001] += var8[var6][223474833 * this.nextInt] * 691346779 * this.TYPE + var8[var5][223474833 * this.nextInt] * this.valueOf * -153466483;
                  }
               }

               if (223474833 * this.nextInt >= var8[0].length) {
                  this.TRUE((byte)1);
               }
            }
         }
      }

   }

   public static void I(Canvas var0, short var1) {
      try {
         try {
            Class var2 = Canvas.class;
            Method var3 = var2.getMethod("setIgnoreRepaint", Boolean.TYPE);
            var3.invoke(var0, Boolean.TRUE);
         } catch (Exception var4) {
            ;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aii.ad(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         if (var0.H[(var0.J -= -391880689) * 681479919] == 0) {
            var0.i += var0.X[var0.i * 1883543357] * 286750741;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aii.bk(" + ')');
      }
   }

   int method2942() {
      return 1;
   }
}
