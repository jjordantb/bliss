import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class ba extends VJI implements SAI {
   long nativeid;

   ba(ja var1, int var2) {
      this.sa(var1, var2);
   }

   native void sa(ja var1, int var2);

   protected void finalize() {
      try {
         if (this.nativeid != 0L) {
            ZDI.I(this, (short)-1633);
         }

         try {
            Class var1 = ClassLoader.class;
            Field var2 = var1.getDeclaredField("nativeLibraries");
            Class var3 = AccessibleObject.class;
            Method var4 = var3.getDeclaredMethod("setAccessible", Boolean.TYPE);
            var4.invoke(var2, Boolean.TRUE);
         } catch (Throwable var5) {
            ;
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ba.finalize(" + ')');
      }
   }

   public native void ma(boolean var1);

   native void ha();

   native void u();

   public native void z(boolean var1);

   native void a(ja var1, int var2);

   native void f();

   native void b();

   native void i();

   native void p();
}
