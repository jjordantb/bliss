public class HQ {
   UP I;
   public byte[] Z;
   public String[] C = new String[5];
   public int B = 1006024925;
   public boolean D = false;
   public int F;
   public int J = -1266787663;
   public int S = 0;
   public int A;
   public int E = 1126107561;
   public static int append = 2;
   public int G;
   public int H = 1952866083;
   public String K;
   int get = 1435131889;
   public boolean L = true;
   public String M;
   public int N = Integer.MIN_VALUE;
   int method250 = 1998808761;
   int method252;
   int method5125;
   int toString = -1896723045;
   int O = 1225014007;
   public int P = -234302495;
   int Q;
   int R = 1125434795;
   public int T;
   public int[] U;
   public int V = -459671533;
   public int W = -80646725;
   public int X = 799363989;
   public int Y = Integer.MIN_VALUE;
   public int i;
   public static int z = 0;
   public boolean c = true;
   JX b;
   public int d;
   public int f;
   public int[] j;
   int s;
   public boolean a = true;
   public int e = 1012984825;
   public static int g = 1;

   void I(REI var1, int var2) {
      try {
         while(true) {
            int var3 = var1.I();
            if (var3 == 0) {
               return;
            }

            this.append(var1, var3, (short)3170);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "or.a(" + ')');
      }
   }

   void append(REI var1, int var2, short var3) {
      try {
         if (1 == var2) {
            this.E = var1.Y(1235052657) * -1126107561;
         } else if (var2 == 2) {
            this.B = var1.Y(1235052657) * -1006024925;
         } else if (3 == var2) {
            this.M = var1.E(-730966089);
         } else if (4 == var2) {
            this.F = var1.B((byte)-65) * 1851662915;
         } else if (5 == var2) {
            this.J = var1.B((byte)-42) * 1266787663;
         } else if (var2 == 6) {
            this.S = var1.I() * -2108294259;
         } else {
            int var4;
            if (7 == var2) {
               var4 = var1.I();
               if ((var4 & 1) == 0) {
                  this.c = false;
               }

               if ((var4 & 2) == 2) {
                  this.D = true;
               }
            } else if (8 == var2) {
               this.L = var1.I() == 1;
            } else if (9 == var2) {
               this.toString = var1.C() * 1896723045;
               if (65535 == -539447443 * this.toString) {
                  this.toString = -1896723045;
               }

               this.O = var1.C() * -1225014007;
               if (-869705415 * this.O == 65535) {
                  this.O = 1225014007;
               }

               this.method252 = var1.H((byte)-62) * -166802393;
               this.method5125 = var1.H((byte)-20) * -1288246043;
            } else if (var2 >= 10 && var2 <= 14) {
               this.C[var2 - 10] = var1.E(-1381247713);
            } else {
               int var5;
               if (var2 == 15) {
                  var4 = var1.I();
                  this.U = new int[2 * var4];

                  for(var5 = 0; var5 < 2 * var4; ++var5) {
                     this.U[var5] = var1.J(1914193224);
                  }

                  this.i = var1.H((byte)-21) * 88246575;
                  var5 = var1.I();
                  this.j = new int[var5];

                  int var6;
                  for(var6 = 0; var6 < this.j.length; ++var6) {
                     this.j[var6] = var1.H((byte)10);
                  }

                  this.Z = new byte[var4];

                  for(var6 = 0; var6 < var4; ++var6) {
                     this.Z[var6] = var1.S(-12558881);
                  }
               } else if (var2 == 16) {
                  this.a = false;
               } else if (17 == var2) {
                  this.K = var1.E(-136783420);
               } else if (18 == var2) {
                  this.method250 = var1.Y(1235052657) * -1998808761;
               } else if (19 == var2) {
                  this.e = var1.C() * -1012984825;
               } else if (20 == var2) {
                  this.R = var1.C() * -1125434795;
                  if (this.R * 769127165 == 65535) {
                     this.R = 1125434795;
                  }

                  this.get = var1.C() * -1435131889;
                  if (-1461367057 * this.get == 65535) {
                     this.get = 1435131889;
                  }

                  this.s = var1.H((byte)28) * 1428832641;
                  this.Q = var1.H((byte)99) * 1701861307;
               } else if (var2 == 21) {
                  this.T = var1.H((byte)-43) * -264999113;
               } else if (22 == var2) {
                  this.G = var1.H((byte)-10) * 1977581169;
               } else if (var2 == 23) {
                  this.X = var1.I() * -799363989;
                  this.P = var1.I() * 234302495;
                  this.H = var1.I() * -1952866083;
               } else if (var2 == 24) {
                  this.d = var1.J(2027309656) * -1983273215;
                  this.f = var1.J(1532524522) * 1940877605;
               } else if (var2 == 249) {
                  var4 = var1.I();
                  if (this.b == null) {
                     var5 = JV.I(var4, (byte)16);
                     this.b = new JX(var5);
                  }

                  for(var5 = 0; var5 < var4; ++var5) {
                     boolean var10 = var1.I() == 1;
                     int var7 = var1.B((byte)-26);
                     Object var8;
                     if (var10) {
                        var8 = new QG(var1.E(-826702559));
                     } else {
                        var8 = new OK(var1.H((byte)97));
                     }

                     this.b.I((AE)var8, (long)var7);
                  }
               }
            }
         }

      } catch (RuntimeException var9) {
         throw DQ.I(var9, "or.f(" + ')');
      }
   }

   void I(int var1) {
      try {
         if (this.U != null) {
            for(int var2 = 0; var2 < this.U.length; var2 += 2) {
               if (this.U[var2] < this.V * 1281846757) {
                  this.V = this.U[var2] * -1687812115;
               } else if (this.U[var2] > 968926443 * this.N) {
                  this.N = this.U[var2] * -426581053;
               }

               if (this.U[var2 + 1] < this.W * -1901940595) {
                  this.W = -2066836923 * this.U[var2 + 1];
               } else if (this.U[1 + var2] > -1294057761 * this.Y) {
                  this.Y = -812843745 * this.U[1 + var2];
               }
            }
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "or.b(" + ')');
      }
   }

   public boolean I(FAI var1, int var2) {
      try {
         int var3;
         if (-1 != -869705415 * this.O) {
            var3 = var1.method252(-869705415 * this.O, (byte)44);
         } else {
            if (-1 == -539447443 * this.toString) {
               return true;
            }

            var3 = var1.method250(-539447443 * this.toString, (byte)24);
         }

         if (var3 >= 338289559 * this.method252 && var3 <= -959385363 * this.method5125) {
            boolean var4 = false;
            int var5;
            if (-1461367057 * this.get != -1) {
               var5 = var1.method252(this.get * -1461367057, (byte)17);
            } else {
               if (-1 == this.R * 769127165) {
                  return true;
               }

               var5 = var1.method250(this.R * 769127165, (byte)72);
            }

            return var5 >= this.s * 372768385 && var5 <= 520017267 * this.Q;
         } else {
            return false;
         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "or.p(" + ')');
      }
   }

   public IBI I(GSI var1, boolean var2, int var3) {
      try {
         int var4 = var2 ? this.B * -1413078901 : this.E * 715019623;
         int var5 = var4 | 580915349 * var1.KZ << 29;
         IBI var6 = (IBI)this.I.I.I((long)var5);
         if (var6 != null) {
            return var6;
         } else if (!this.I.C.D(var4, -457216440)) {
            return null;
         } else {
            RFI var7 = RFI.I(this.I.C, var4, 0);
            if (var7 != null) {
               var6 = var1.method5125(var7, true);
               this.I.I.I(var6, (long)var5);
            }

            return var6;
         }
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "or.i(" + ')');
      }
   }

   public String I(int var1, String var2, byte var3) {
      try {
         if (this.b == null) {
            return var2;
         } else {
            QG var4 = (QG)this.b.I((long)var1);
            return var4 == null ? var2 : (String)var4.J;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "or.u(" + ')');
      }
   }

   public IBI I(GSI var1, int var2) {
      try {
         IBI var3 = (IBI)this.I.I.I((long)(this.method250 * 1027948663 | 131072 | var1.KZ * 580915349 << 29));
         if (var3 != null) {
            return var3;
         } else {
            this.I.C.D(1027948663 * this.method250, -457216440);
            RFI var4 = RFI.I(this.I.C, this.method250 * 1027948663, 0);
            if (var4 != null) {
               var3 = var1.method5125(var4, true);
               this.I.I.I(var3, (long)(this.method250 * 1027948663 | 131072 | var1.KZ * 580915349 << 29));
            }

            return var3;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "or.k(" + ')');
      }
   }

   public int I(int var1, int var2, int var3) {
      try {
         if (this.b == null) {
            return var2;
         } else {
            OK var4 = (OK)this.b.I((long)var1);
            return var4 == null ? var2 : var4.J * -774922497;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "or.d(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         var0.J -= -1959403445;
         VO.I(var0.H[681479919 * var0.J], var0.H[var0.J * 681479919 + 1], var0.H[2 + var0.J * 681479919], var0.H[3 + 681479919 * var0.J], false, var0.H[var0.J * 681479919 + 4], 2026903657);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "or.to(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = AN.L.I(var2, 614874976).L * 1317156085;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "or.ta(" + ')');
      }
   }

   public static ZV I(int var0, byte var1) {
      try {
         ZV[] var2 = JZI.Z((byte)75);

         for(int var3 = 0; var3 < var2.length; ++var3) {
            ZV var4 = var2[var3];
            if (var4.S * -937307905 == var0) {
               return var4;
            }
         }

         return null;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "or.f(" + ')');
      }
   }

   public static int I(long var0) {
      try {
         PW.I(var0);
         return WII.I.get(1);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "or.q(" + ')');
      }
   }

   static void Z(int var0, byte var1) {
      try {
         GT.F = var0 * -435591305;
         GN.s = 789877945;
         GN.s = 789877945;
         OF.C(65536);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "or.co(" + ')');
      }
   }

   static final void C(OU var0, byte var1) {
      try {
         var0.J -= -783761378;
         E.F[var0.H[681479919 * var0.J]] = (short)OFI.I(var0.H[681479919 * var0.J + 1], (byte)-118);
         JH.R.I((byte)-85);
         JH.R.Z(-1524552538);
         WZ.q.I((byte)14);
         TQ.Z(658986741);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "or.afg(" + ')');
      }
   }

   static final void B(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.S[(var0.A += 969361751) * -203050393 - 1] = JH.R.I(var2).A;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "or.aaj(" + ')');
      }
   }
}
