public class GB {
   int I;
   float Z = 1.0F;
   int C;
   int B;
   float D = 1.0F;
   int F;
   float J;
   int S;
   int A;
   int E;
   int G;
   static int H;

   GB(int var1, float var2, float var3, int var4, int var5, int var6) {
      this.G = var1 * -564629049;
      this.Z = var2;
      this.D = var3;
      this.B = var4 * 1747422061;
      this.I = 1370325433 * var5;
      this.F = var6 * -839233607;
   }

   GB I(int var1) {
      try {
         return new GB(-1509687305 * this.G, this.Z, this.D, -1848560027 * this.B, this.I * -1070844791, this.F * -988477815);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "as.a(" + ')');
      }
   }

   void I(GB var1, int var2) {
      try {
         this.Z = var1.Z;
         this.D = var1.D;
         this.B = var1.B * 1;
         this.I = 1 * var1.I;
         this.G = 1 * var1.G;
         this.F = var1.F * 1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "as.f(" + ')');
      }
   }

   GB(int var1) {
      this.G = -564629049 * var1;
   }

   static final void I(OU var0, int var1) {
      try {
         var0.J -= -783761378;
         if (var0.H[var0.J * 681479919] <= var0.H[1 + var0.J * 681479919]) {
            var0.i += 286750741 * var0.X[var0.i * 1883543357];
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "as.ai(" + ')');
      }
   }

   static String I(int var0, int var1, byte var2) {
      try {
         int var3 = var1 - var0;
         if (var3 < -9) {
            return RA.I(16711680, -1412514938);
         } else if (var3 < -6) {
            return RA.I(16723968, -1450525850);
         } else if (var3 < -3) {
            return RA.I(16740352, -1831141729);
         } else if (var3 < 0) {
            return RA.I(16756736, -1637160945);
         } else if (var3 > 9) {
            return RA.I(65280, (int)-1407228246);
         } else if (var3 > 6) {
            return RA.I(4259584, -1287123002);
         } else if (var3 > 3) {
            return RA.I(8453888, -1329263745);
         } else {
            return var3 > 0 ? RA.I(12648192, -1738690779) : RA.I(16776960, -1985964349);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "as.bg(" + ')');
      }
   }

   public static PK I(MEI var0, JEI var1, byte var2) {
      try {
         PK var3 = EZI.I((byte)56);
         var3.H = var0;
         var3.S = var0.IZ * -1035235683;
         if (-1 == var3.S * 157188735) {
            var3.J = new QEI(260);
         } else if (var3.S * 157188735 == -2) {
            var3.J = new QEI(10000);
         } else if (157188735 * var3.S <= 18) {
            var3.J = new QEI(20);
         } else if (var3.S * 157188735 <= 98) {
            var3.J = new QEI(100);
         } else {
            var3.J = new QEI(260);
         }

         var3.J.I(var1, (byte)74);
         var3.J.Z(var3.H.gI * -1687656101, (byte)-23);
         var3.E = 0;
         return var3;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "as.f(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         EDI.Z(var3, var4, var0, -1849275031);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "as.em(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         var0.J -= -783761378;
         int var2 = var0.H[var0.J * 681479919];
         int var3 = var0.H[var0.J * 681479919 + 1];
         String var4 = (String)var0.S[(var0.A -= 969361751) * -203050393];
         if (99 == var2) {
            CS.I(var4, 1242487535);
         } else if (var2 == 98) {
            WV.I(var4, -1177455078);
         } else {
            HJ.I(var2, var3, "", "", "", var4, -541387718);
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "as.sy(" + ')');
      }
   }

   public static void I(String var0, String var1, int var2, boolean var3, int var4) {
      try {
         if (XEI.QZ * -1233866115 == 8) {
            PK var5 = I(MEI.zI, XEI.TI.Z, (byte)19);
            var5.J.Z(0, 16711935);
            int var6 = 385051775 * var5.J.A;
            var5.J.I(var0, 2138689470);
            var5.J.I(var1, 2115793947);
            var5.J.F(var2);
            var5.J.F(var3 ? 1 : 0);
            var5.J.A += 814893177;
            var5.J.I(UQ.I, var6, var5.J.A * 385051775, -1325657598);
            var5.J.F(385051775 * var5.J.A - var6, 1585504133);
            XEI.TI.I(var5, (byte)-20);
            if (var2 < 13) {
               XEI.EI = true;
               ECI.I((byte)12);
            }

            OQ.I = BV.Z;
         }

      } catch (RuntimeException var7) {
         throw DQ.I(var7, "as.i(" + ')');
      }
   }
}
