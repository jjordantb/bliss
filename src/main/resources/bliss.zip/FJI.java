public class FJI extends DJI {
   static int append = 3;
   int toString;
   int F;
   int J;
   int S;

   void method1048(int var1, int var2, byte var3) {
      try {
         int var4 = var1 * this.toString * 2134635939 >> 12;
         int var5 = var1 * this.J * -58577037 >> 12;
         int var6 = this.F * 1584246611 * var2 >> 12;
         int var7 = var2 * -2052936699 * this.S >> 12;
         CY.I(var4, var6, var5, var7, 699194661 * this.C, 1785836763 * this.Z, -759495821 * this.I, -566735652);
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "ye.b(" + ')');
      }
   }

   void method1054(int var1, int var2, byte var3) {
   }

   void method1047(int var1, int var2, byte var3) {
      try {
         int var4 = var1 * 2134635939 * this.toString >> 12;
         int var5 = var1 * this.J * -58577037 >> 12;
         int var6 = var2 * this.F * 1584246611 >> 12;
         int var7 = this.S * -2052936699 * var2 >> 12;
         MDI.I(var4, var6, var5, var7, this.C * 699194661, 811666091);
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "ye.f(" + ')');
      }
   }

   void method1052(int var1, int var2) {
      int var3 = var1 * 2134635939 * this.toString >> 12;
      int var4 = var1 * this.J * -58577037 >> 12;
      int var5 = var2 * this.F * 1584246611 >> 12;
      int var6 = this.S * -2052936699 * var2 >> 12;
      MDI.I(var3, var5, var4, var6, this.C * 699194661, 811666091);
   }

   void method1049(int var1, int var2) {
   }

   void method1050(int var1, int var2) {
      int var3 = var1 * this.toString * 2134635939 >> 12;
      int var4 = var1 * this.J * -58577037 >> 12;
      int var5 = this.F * 1584246611 * var2 >> 12;
      int var6 = var2 * -2052936699 * this.S >> 12;
      CY.I(var3, var5, var4, var6, 699194661 * this.C, 1785836763 * this.Z, -759495821 * this.I, -566735652);
   }

   void method1051(int var1, int var2) {
      int var3 = var1 * 2134635939 * this.toString >> 12;
      int var4 = var1 * this.J * -58577037 >> 12;
      int var5 = var2 * this.F * 1584246611 >> 12;
      int var6 = this.S * -2052936699 * var2 >> 12;
      MDI.I(var3, var5, var4, var6, this.C * 699194661, 811666091);
   }

   void method1046(int var1, int var2) {
      int var3 = var1 * this.toString * 2134635939 >> 12;
      int var4 = var1 * this.J * -58577037 >> 12;
      int var5 = this.F * 1584246611 * var2 >> 12;
      int var6 = var2 * -2052936699 * this.S >> 12;
      CY.I(var3, var5, var4, var6, 699194661 * this.C, 1785836763 * this.Z, -759495821 * this.I, -566735652);
   }

   FJI(int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      super(var5, var6, var7);
      this.toString = var1 * 857007627;
      this.F = 578579675 * var2;
      this.J = -655913541 * var3;
      this.S = 851394765 * var4;
   }

   void method1053(int var1, int var2) {
      int var3 = var1 * this.toString * 2134635939 >> 12;
      int var4 = var1 * this.J * -58577037 >> 12;
      int var5 = this.F * 1584246611 * var2 >> 12;
      int var6 = var2 * -2052936699 * this.S >> 12;
      CY.I(var3, var5, var4, var6, 699194661 * this.C, 1785836763 * this.Z, -759495821 * this.I, -566735652);
   }

   static final void I(OU var0, byte var1) {
      try {
         var0.N[var0.X[var0.i * 1883543357]] = var0.H[(var0.J -= -391880689) * 681479919];
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ye.as(" + ')');
      }
   }
}
