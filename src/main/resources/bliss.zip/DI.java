public final class DI extends BI {
   PJI J;
   M method1221;
   boolean Z;

   public boolean method1374() {
      return this.J.AZ == this.method1221;
   }

   L method1326(NJI var1, G var2) {
      return new M((PJI)var1, this, var2);
   }

   public boolean method1331(L var1) {
      if (this.method1221 == var1) {
         return true;
      } else if (!var1.method1221()) {
         return false;
      } else {
         this.method1221 = (M)var1;
         this.I = this.I(var1, -180449856) * -1776466383;
         if (this.I * -33664303 == -1) {
            throw new IllegalArgumentException();
         } else {
            if (this.Z) {
               this.J.I(this.method1221.J);
               this.J.C(this.method1221.F);
               this.J.AZ = this.method1221;
            }

            return true;
         }
      }
   }

   L method1361(NJI var1, G var2) {
      return new M((PJI)var1, this, var2);
   }

   public void method1340() {
      if (this.method1221 == null) {
         throw new RuntimeException_Sub1();
      } else {
         this.J.I(this.method1221.J);
         this.J.C(this.method1221.F);
         this.J.AZ = this.method1221;
         this.Z = true;
      }
   }

   public void method1372() {
      this.J.I(0L);
      this.J.C(0L);
      this.Z = false;
      this.J.AZ = null;
      this.J.C(1);
      this.J.I((IEI)null);
      this.J.C(0);
      this.J.I((IEI)null);
   }

   public boolean method1376(L var1) {
      if (this.method1221 == var1) {
         return true;
      } else if (!var1.method1221()) {
         return false;
      } else {
         this.method1221 = (M)var1;
         this.I = this.I(var1, -180449856) * -1776466383;
         if (this.I * -33664303 == -1) {
            throw new IllegalArgumentException();
         } else {
            if (this.Z) {
               this.J.I(this.method1221.J);
               this.J.C(this.method1221.F);
               this.J.AZ = this.method1221;
            }

            return true;
         }
      }
   }

   public void method1354() {
      if (this.method1221 == null) {
         throw new RuntimeException_Sub1();
      } else {
         this.J.I(this.method1221.J);
         this.J.C(this.method1221.F);
         this.J.AZ = this.method1221;
         this.Z = true;
      }
   }

   public void method1355() {
      if (this.method1221 == null) {
         throw new RuntimeException_Sub1();
      } else {
         this.J.I(this.method1221.J);
         this.J.C(this.method1221.F);
         this.J.AZ = this.method1221;
         this.Z = true;
      }
   }

   public boolean method1371() {
      return this.J.AZ == this.method1221;
   }

   public void method1356() {
      this.J.I(0L);
      this.J.C(0L);
      this.Z = false;
      this.J.AZ = null;
      this.J.C(1);
      this.J.I((IEI)null);
      this.J.C(0);
      this.J.I((IEI)null);
   }

   public void method1357() {
      this.J.I(0L);
      this.J.C(0L);
      this.Z = false;
      this.J.AZ = null;
      this.J.C(1);
      this.J.I((IEI)null);
      this.J.C(0);
      this.J.I((IEI)null);
   }

   public void method1358() {
      this.J.I(0L);
      this.J.C(0L);
      this.Z = false;
      this.J.AZ = null;
      this.J.C(1);
      this.J.I((IEI)null);
      this.J.C(0);
      this.J.I((IEI)null);
   }

   public boolean method1359() {
      return this.J.AZ == this.method1221;
   }

   VG method1364(R var1) {
      return new XG(this, var1);
   }

   DI(PJI var1, H var2) {
      super(var1, var2);
      this.J = var1;
      this.Z = false;
   }

   L method1362(NJI var1, G var2) {
      return new M((PJI)var1, this, var2);
   }

   public void method1373() {
      if (this.method1221 == null) {
         throw new RuntimeException_Sub1();
      } else {
         this.J.I(this.method1221.J);
         this.J.C(this.method1221.F);
         this.J.AZ = this.method1221;
         this.Z = true;
      }
   }

   public boolean method1349(L var1) {
      if (this.method1221 == var1) {
         return true;
      } else if (!var1.method1221()) {
         return false;
      } else {
         this.method1221 = (M)var1;
         this.I = this.I(var1, -180449856) * -1776466383;
         if (this.I * -33664303 == -1) {
            throw new IllegalArgumentException();
         } else {
            if (this.Z) {
               this.J.I(this.method1221.J);
               this.J.C(this.method1221.F);
               this.J.AZ = this.method1221;
            }

            return true;
         }
      }
   }

   public boolean method1375(L var1) {
      if (this.method1221 == var1) {
         return true;
      } else if (!var1.method1221()) {
         return false;
      } else {
         this.method1221 = (M)var1;
         this.I = this.I(var1, -180449856) * -1776466383;
         if (this.I * -33664303 == -1) {
            throw new IllegalArgumentException();
         } else {
            if (this.Z) {
               this.J.I(this.method1221.J);
               this.J.C(this.method1221.F);
               this.J.AZ = this.method1221;
            }

            return true;
         }
      }
   }

   VG method1367(R var1) {
      return new XG(this, var1);
   }
}
