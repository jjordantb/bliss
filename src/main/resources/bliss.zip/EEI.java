import java.awt.Component;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

public class EEI extends TO implements MouseListener, MouseMotionListener, MouseWheelListener {
   IY addMouseListener = new IY();
   static int addMouseMotionListener = 2;
   int addMouseWheelListener;
   int append;
   static int consume = 4;
   int getButton;
   IY getClickCount = new IY();
   int getWheelRotation;
   int getX;
   int getY;
   static int isMetaDown = 1;
   Component isPopupTrigger;
   boolean isShiftDown;

   public boolean method3878(int var1) {
      try {
         return (-31480187 * this.getButton & 1) != 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aci.p(" + ')');
      }
   }

   void addMouseListener(Component var1, int var2) {
      try {
         this.addMouseMotionListener(1230262531);
         this.isPopupTrigger = var1;
         this.isPopupTrigger.addMouseListener(this);
         this.isPopupTrigger.addMouseMotionListener(this);
         this.isPopupTrigger.addMouseWheelListener(this);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aci.at(" + ')');
      }
   }

   void addMouseMotionListener(int var1) {
      try {
         if (this.isPopupTrigger != null) {
            this.isPopupTrigger.removeMouseWheelListener(this);
            this.isPopupTrigger.removeMouseMotionListener(this);
            this.isPopupTrigger.removeMouseListener(this);
            this.isPopupTrigger = null;
            this.getButton = 0;
            this.getY = 0;
            this.append = 0;
            this.addMouseWheelListener = 0;
            this.getX = 0;
            this.getWheelRotation = 0;
            this.getClickCount = null;
            this.addMouseListener = null;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aci.ah(" + ')');
      }
   }

   public boolean method3890() {
      return (-31480187 * this.getButton & 1) != 0;
   }

   void addMouseWheelListener(int var1, int var2, int var3) {
      try {
         this.getWheelRotation = var1 * -213131387;
         this.getX = var2 * -968658837;
         if (this.isShiftDown) {
            this.append(-1, var1, var2, 0, 1553525097);
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aci.al(" + ')');
      }
   }

   public boolean method3887(int var1) {
      try {
         return (-31480187 * this.getButton & 2) != 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aci.i(" + ')');
      }
   }

   EEI(Component var1, boolean var2) {
      this.addMouseListener(var1, -1437014279);
      this.isShiftDown = var2;
   }

   void append(int var1, int var2, int var3, int var4, int var5) {
      try {
         QM var6 = JCI.I(var1, var2, var3, CI.I((byte)1), var4, -1798824718);
         this.addMouseListener.I((AE)var6, (int)534328737);
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "aci.ai(" + ')');
      }
   }

   public boolean method3880(byte var1) {
      try {
         return (this.getButton * -31480187 & 4) != 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aci.k(" + ')');
      }
   }

   public int method3899() {
      return this.getY * 28748355;
   }

   public int method3883(byte var1) {
      try {
         return this.getY * 28748355;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aci.x(" + ')');
      }
   }

   public void method3882(byte var1) {
      try {
         this.addMouseMotionListener(868673993);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aci.q(" + ')');
      }
   }

   public synchronized void mouseClicked(MouseEvent var1) {
      try {
         if (var1.isPopupTrigger()) {
            var1.consume();
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aci.mouseClicked(" + ')');
      }
   }

   public synchronized void mouseEntered(MouseEvent var1) {
      try {
         this.addMouseWheelListener(var1.getX(), var1.getY(), 459711214);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aci.mouseEntered(" + ')');
      }
   }

   public synchronized void mouseExited(MouseEvent var1) {
      try {
         this.addMouseWheelListener(var1.getX(), var1.getY(), 1366931071);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aci.mouseExited(" + ')');
      }
   }

   int consume(MouseEvent var1, int var2) {
      try {
         if (var1.getButton() == 1) {
            return var1.isMetaDown() ? 4 : 1;
         } else if (var1.getButton() == 2) {
            return 2;
         } else {
            return var1.getButton() == 3 ? 4 : 0;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aci.az(" + ')');
      }
   }

   public synchronized void mousePressed(MouseEvent var1) {
      try {
         int var2 = this.consume(var1, 1930435178);
         if (1 == var2) {
            this.append(0, var1.getX(), var1.getY(), var1.getClickCount(), 1989072538);
         } else if (var2 == 4) {
            this.append(2, var1.getX(), var1.getY(), var1.getClickCount(), 1922972976);
         } else if (2 == var2) {
            this.append(1, var1.getX(), var1.getY(), var1.getClickCount(), 2016030026);
         }

         this.addMouseWheelListener = (2114498315 * this.addMouseWheelListener | var2) * 1282483363;
         if (var1.isPopupTrigger()) {
            var1.consume();
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aci.mousePressed(" + ')');
      }
   }

   public synchronized void mouseReleased(MouseEvent var1) {
      try {
         int var2 = this.consume(var1, 1755922620);
         if ((2114498315 * this.addMouseWheelListener & var2) == 0) {
            var2 = this.addMouseWheelListener * 2114498315;
         }

         if ((var2 & 1) != 0) {
            this.append(3, var1.getX(), var1.getY(), var1.getClickCount(), 1931509920);
         }

         if ((var2 & 4) != 0) {
            this.append(5, var1.getX(), var1.getY(), var1.getClickCount(), 1062616351);
         }

         if ((var2 & 2) != 0) {
            this.append(4, var1.getX(), var1.getY(), var1.getClickCount(), 1204760399);
         }

         this.addMouseWheelListener = (this.addMouseWheelListener * 2114498315 & ~var2) * 1282483363;
         if (var1.isPopupTrigger()) {
            var1.consume();
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aci.mouseReleased(" + ')');
      }
   }

   public synchronized void mouseDragged(MouseEvent var1) {
      try {
         this.addMouseWheelListener(var1.getX(), var1.getY(), -2027156244);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aci.mouseDragged(" + ')');
      }
   }

   public synchronized void mouseMoved(MouseEvent var1) {
      try {
         this.addMouseWheelListener(var1.getX(), var1.getY(), -1257091860);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aci.mouseMoved(" + ')');
      }
   }

   public synchronized void mouseWheelMoved(MouseWheelEvent var1) {
      try {
         if (var1.isShiftDown()) {
            if (var1.getWheelRotation() == 1) {
               if (XEI.T < 100) {
                  return;
               }

               XEI.T -= XEI.T / 16;
               UN.I(184, XEI.T, 644551429);
            }

            if (var1.getWheelRotation() == -1) {
               if (XEI.T >= 600) {
                  return;
               }

               XEI.T += XEI.T / 16;
               UN.I(184, XEI.T, 644551429);
            }
         }

         int var2 = var1.getX();
         int var3 = var1.getY();
         int var4 = var1.getWheelRotation();
         this.append(6, var2, var3, var4, 1166829560);
         var1.consume();
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aci.mouseWheelMoved(" + ')');
      }
   }

   public synchronized void method3877() {
      this.append = this.getWheelRotation * -867321853;
      this.getY = this.getX * -1698396671;
      this.getButton = this.addMouseWheelListener * 866311247;
      IY var1 = this.getClickCount;
      this.getClickCount = this.addMouseListener;
      this.addMouseListener = var1;
      this.addMouseListener.I((byte)1);
   }

   public synchronized void method3884() {
      this.append = this.getWheelRotation * -867321853;
      this.getY = this.getX * -1698396671;
      this.getButton = this.addMouseWheelListener * 866311247;
      IY var1 = this.getClickCount;
      this.getClickCount = this.addMouseListener;
      this.addMouseListener = var1;
      this.addMouseListener.I((byte)1);
   }

   public boolean method3889() {
      return (-31480187 * this.getButton & 2) != 0;
   }

   public void method3898() {
      this.addMouseMotionListener(-1710561997);
   }

   public boolean method3888() {
      return (-31480187 * this.getButton & 1) != 0;
   }

   public boolean method3892() {
      return (-31480187 * this.getButton & 2) != 0;
   }

   public synchronized void method3886(int var1) {
      try {
         this.append = this.getWheelRotation * -867321853;
         this.getY = this.getX * -1698396671;
         this.getButton = this.addMouseWheelListener * 866311247;
         IY var2 = this.getClickCount;
         this.getClickCount = this.addMouseListener;
         this.addMouseListener = var2;
         this.addMouseListener.I((byte)1);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aci.b(" + ')');
      }
   }

   public boolean method3893() {
      return (this.getButton * -31480187 & 4) != 0;
   }

   public int method3895() {
      return this.append * 1215441007;
   }

   public PM method3896() {
      return (PM)this.getClickCount.I(2123266868);
   }

   public PM method3885() {
      return (PM)this.getClickCount.I(2127727655);
   }

   public int method3894(byte var1) {
      try {
         return this.append * 1215441007;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aci.u(" + ')');
      }
   }

   public PM method3879(int var1) {
      try {
         return (PM)this.getClickCount.I(2114584348);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aci.r(" + ')');
      }
   }

   public void method3897() {
      this.addMouseMotionListener(-1322459721);
   }

   public boolean method3891() {
      return (-31480187 * this.getButton & 1) != 0;
   }
}
