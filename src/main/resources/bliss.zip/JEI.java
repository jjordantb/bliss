import java.awt.Canvas;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

public final class JEI {
   int C;
   static int Z = 8;
   static int append = 1020;
   int close;
   static int exists = 256;
   int[] read = new int[256];
   int seek;
   int[] separatorChar = new int[256];
   int toString;

   public final int I(int var1) {
      try {
         if (815637839 * this.close == 0) {
            this.Z((byte)84);
            this.close = -1303269632;
         }

         return !Loader.useIsaac ? 0 : this.separatorChar[(this.close -= 1857180079) * 815637839];
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sn.a(" + ')');
      }
   }

   final void C(int var1) {
      try {
         int var2 = -1640531527;
         int var3 = -1640531527;
         int var4 = -1640531527;
         int var5 = -1640531527;
         int var6 = -1640531527;
         int var7 = -1640531527;
         int var8 = -1640531527;
         int var9 = -1640531527;

         int var10;
         for(var10 = 0; var10 < 4; ++var10) {
            var9 ^= var8 << 11;
            var6 += var9;
            var8 += var7;
            var8 ^= var7 >>> 2;
            var5 += var8;
            var7 += var6;
            var7 ^= var6 << 8;
            var4 += var7;
            var6 += var5;
            var6 ^= var5 >>> 16;
            var3 += var6;
            var5 += var4;
            var5 ^= var4 << 10;
            var2 += var5;
            var4 += var3;
            var4 ^= var3 >>> 4;
            var9 += var4;
            var3 += var2;
            var3 ^= var2 << 8;
            var8 += var3;
            var2 += var9;
            var2 ^= var9 >>> 9;
            var7 += var2;
            var9 += var8;
         }

         for(var10 = 0; var10 < 256; var10 += 8) {
            var9 += this.separatorChar[var10];
            var8 += this.separatorChar[var10 + 1];
            var7 += this.separatorChar[2 + var10];
            var6 += this.separatorChar[3 + var10];
            var5 += this.separatorChar[4 + var10];
            var4 += this.separatorChar[5 + var10];
            var3 += this.separatorChar[6 + var10];
            var2 += this.separatorChar[7 + var10];
            var9 ^= var8 << 11;
            var6 += var9;
            var8 += var7;
            var8 ^= var7 >>> 2;
            var5 += var8;
            var7 += var6;
            var7 ^= var6 << 8;
            var4 += var7;
            var6 += var5;
            var6 ^= var5 >>> 16;
            var3 += var6;
            var5 += var4;
            var5 ^= var4 << 10;
            var2 += var5;
            var4 += var3;
            var4 ^= var3 >>> 4;
            var9 += var4;
            var3 += var2;
            var3 ^= var2 << 8;
            var8 += var3;
            var2 += var9;
            var2 ^= var9 >>> 9;
            var7 += var2;
            var9 += var8;
            this.read[var10] = var9;
            this.read[1 + var10] = var8;
            this.read[var10 + 2] = var7;
            this.read[var10 + 3] = var6;
            this.read[var10 + 4] = var5;
            this.read[var10 + 5] = var4;
            this.read[var10 + 6] = var3;
            this.read[var10 + 7] = var2;
         }

         for(var10 = 0; var10 < 256; var10 += 8) {
            var9 += this.read[var10];
            var8 += this.read[var10 + 1];
            var7 += this.read[var10 + 2];
            var6 += this.read[var10 + 3];
            var5 += this.read[var10 + 4];
            var4 += this.read[5 + var10];
            var3 += this.read[var10 + 6];
            var2 += this.read[7 + var10];
            var9 ^= var8 << 11;
            var6 += var9;
            var8 += var7;
            var8 ^= var7 >>> 2;
            var5 += var8;
            var7 += var6;
            var7 ^= var6 << 8;
            var4 += var7;
            var6 += var5;
            var6 ^= var5 >>> 16;
            var3 += var6;
            var5 += var4;
            var5 ^= var4 << 10;
            var2 += var5;
            var4 += var3;
            var4 ^= var3 >>> 4;
            var9 += var4;
            var3 += var2;
            var3 ^= var2 << 8;
            var8 += var3;
            var2 += var9;
            var2 ^= var9 >>> 9;
            var7 += var2;
            var9 += var8;
            this.read[var10] = var9;
            this.read[var10 + 1] = var8;
            this.read[var10 + 2] = var7;
            this.read[var10 + 3] = var6;
            this.read[var10 + 4] = var5;
            this.read[5 + var10] = var4;
            this.read[6 + var10] = var3;
            this.read[var10 + 7] = var2;
         }

         this.Z((byte)-3);
         this.close = -1303269632;
      } catch (RuntimeException var11) {
         throw DQ.I(var11, "sn.p(" + ')');
      }
   }

   public final int I(byte var1) {
      try {
         if (815637839 * this.close == 0) {
            this.Z((byte)-13);
            this.close = -1303269632;
         }

         return !Loader.useIsaac ? 0 : this.separatorChar[815637839 * this.close - 1];
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sn.f(" + ')');
      }
   }

   final void Z(byte var1) {
      try {
         this.C += (this.toString += 1595041509) * 1987923423;

         for(int var2 = 0; var2 < 256; ++var2) {
            int var3 = this.read[var2];
            if ((var2 & 2) == 0) {
               if ((var2 & 1) == 0) {
                  this.seek = (-840519441 * this.seek ^ this.seek * -840519441 << 13) * 368737807;
               } else {
                  this.seek = 368737807 * (-840519441 * this.seek ^ -840519441 * this.seek >>> 6);
               }
            } else if ((var2 & 1) == 0) {
               this.seek = (-840519441 * this.seek ^ this.seek * -840519441 << 2) * 368737807;
            } else {
               this.seek = 368737807 * (this.seek * -840519441 ^ this.seek * -840519441 >>> 16);
            }

            this.seek += 368737807 * this.read[128 + var2 & 255];
            int var4;
            this.read[var2] = var4 = 149032115 * this.C + -840519441 * this.seek + this.read[(var3 & 1020) >> 2];
            this.separatorChar[var2] = (this.C = 634094203 * (this.read[(var4 >> 8 & 1020) >> 2] + var3)) * 149032115;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "sn.b(" + ')');
      }
   }

   public JEI(int[] var1) {
      for(int var2 = 0; var2 < var1.length; ++var2) {
         this.separatorChar[var2] = var1[var2];
      }

      this.C(-1926269976);
   }

   static final void I(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         EA.I(var3, var4, var0, 304191670);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "sn.df(" + ')');
      }
   }

   static PCI I(LJI var0, Canvas var1, int var2, int var3, int var4) {
      try {
         QCI var5 = new QCI(var0, var1, var2, var3);
         return var5;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "sn.n(" + ')');
      }
   }

   static void Z(int var0) {
      try {
         try {
            File var1 = new File(LFI.B, "random.dat");
            int var3;
            if (var1.exists()) {
               ZE.P = new OII(new XY(var1, "rw", 25L), 24, 0);
            } else {
               label37:
               for(int var2 = 0; var2 < WBI.A.length; ++var2) {
                  for(var3 = 0; var3 < JF.I.length; ++var3) {
                     File var4 = new File(JF.I[var3] + WBI.A[var2] + File.separatorChar + "random.dat");
                     if (var4.exists()) {
                        ZE.P = new OII(new XY(var4, "rw", 25L), 24, 0);
                        break label37;
                     }
                  }
               }
            }

            if (ZE.P == null) {
               RandomAccessFile var7 = new RandomAccessFile(var1, "rw");
               var3 = var7.read();
               var7.seek(0L);
               var7.write(var3);
               var7.seek(0L);
               var7.close();
               ZE.P = new OII(new XY(var1, "rw", 25L), 24, 0);
            }
         } catch (IOException var5) {
            ;
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "sn.x(" + ')');
      }
   }
}
