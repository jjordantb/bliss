import jagtheora.ogg.OggPacket;
import jagtheora.ogg.OggStreamState;

public class KG extends AG {
   String append;
   static int equals = 0;
   int getData;
   static int toString = 128;
   String A;
   String E;
   float G;
   float H;
   int K;

   void method3074(OggPacket var1, int var2) {
      try {
         if (this.S * -1312498565 <= 0 || "SUB".equals(this.E)) {
            REI var3 = new REI(var1.getData());
            int var4 = var3.I();
            if (-1312498565 * this.S <= 8) {
               if ((var4 | 128) == 0) {
                  throw new IllegalStateException();
               }

               if (-1312498565 * this.S == 0) {
                  var3.A += -1617461143;
                  this.getData = var3.A(1431459183) * 33758645;
                  this.K = var3.A(-150244186) * 1857578037;
                  if (this.getData * -180836195 == 0 || this.K * 2110967325 == 0) {
                     throw new IllegalStateException();
                  }

                  REI var13 = new REI(16);
                  var3.I((byte[])var13.S, 0, 16, (int)-953523806);
                  this.A = var13.E(-1838621769);
                  var13.A = 0;
                  var3.I((byte[])var13.S, 0, 16, (int)-953523806);
                  this.E = var13.E(1476138543);
               }
            } else {
               if (var4 == 0) {
                  long var5 = var3.V(1976358727);
                  long var7 = var3.V(1286401972);
                  long var9 = var3.V(1829097486);
                  if (var5 < 0L || var7 < 0L || var9 < 0L || var9 > var5) {
                     throw new IllegalStateException();
                  }

                  this.G = (float)(var5 * (long)(2110967325 * this.K)) / (float)(-180836195 * this.getData);
                  this.H = (float)((var5 + var7) * (long)(this.K * 2110967325)) / (float)(-180836195 * this.getData);
                  int var11 = var3.A(-941704037);
                  if (var11 < 0 || var11 > var3.S.length - 385051775 * var3.A) {
                     throw new IllegalStateException();
                  }

                  this.append = DF.I(var3.S, var3.A * 385051775, var11, -730069426);
               }

               if ((var4 | 128) != 0) {
                  return;
               }
            }
         }

      } catch (RuntimeException var12) {
         throw DQ.I(var12, "ajv.f(" + ')');
      }
   }

   String I(byte var1) {
      try {
         return this.A;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ajv.q(" + ')');
      }
   }

   public float Z(byte var1) {
      try {
         return this.G;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ajv.n(" + ')');
      }
   }

   public float C(int var1) {
      try {
         return this.H;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ajv.s(" + ')');
      }
   }

   public String B(int var1) {
      try {
         return this.append;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ajv.z(" + ')');
      }
   }

   void method3079() {
   }

   void method3077(OggPacket var1) {
      if (this.S * -1312498565 <= 0 || "SUB".equals(this.E)) {
         REI var2 = new REI(var1.getData());
         int var3 = var2.I();
         if (-1312498565 * this.S <= 8) {
            if ((var3 | 128) == 0) {
               throw new IllegalStateException();
            }

            if (-1312498565 * this.S == 0) {
               var2.A += -1617461143;
               this.getData = var2.A(-1960945614) * 33758645;
               this.K = var2.A(1105841706) * 1857578037;
               if (this.getData * -180836195 == 0 || this.K * 2110967325 == 0) {
                  throw new IllegalStateException();
               }

               REI var11 = new REI(16);
               var2.I((byte[])var11.S, 0, 16, (int)-953523806);
               this.A = var11.E(-2059271269);
               var11.A = 0;
               var2.I((byte[])var11.S, 0, 16, (int)-953523806);
               this.E = var11.E(254290400);
            }
         } else {
            if (var3 == 0) {
               long var4 = var2.V(1922871636);
               long var6 = var2.V(1312894396);
               long var8 = var2.V(718042704);
               if (var4 < 0L || var6 < 0L || var8 < 0L || var8 > var4) {
                  throw new IllegalStateException();
               }

               this.G = (float)(var4 * (long)(2110967325 * this.K)) / (float)(-180836195 * this.getData);
               this.H = (float)((var4 + var6) * (long)(this.K * 2110967325)) / (float)(-180836195 * this.getData);
               int var10 = var2.A(1321488370);
               if (var10 < 0 || var10 > var2.S.length - 385051775 * var2.A) {
                  throw new IllegalStateException();
               }

               this.append = DF.I(var2.S, var2.A * 385051775, var10, -932621904);
            }

            if ((var3 | 128) != 0) {
               return;
            }
         }
      }

   }

   void method3078(OggPacket var1) {
      if (this.S * -1312498565 <= 0 || "SUB".equals(this.E)) {
         REI var2 = new REI(var1.getData());
         int var3 = var2.I();
         if (-1312498565 * this.S <= 8) {
            if ((var3 | 128) == 0) {
               throw new IllegalStateException();
            }

            if (-1312498565 * this.S == 0) {
               var2.A += -1617461143;
               this.getData = var2.A(-1885777054) * 33758645;
               this.K = var2.A(-1908777764) * 1857578037;
               if (this.getData * -180836195 == 0 || this.K * 2110967325 == 0) {
                  throw new IllegalStateException();
               }

               REI var11 = new REI(16);
               var2.I((byte[])var11.S, 0, 16, (int)-953523806);
               this.A = var11.E(933165446);
               var11.A = 0;
               var2.I((byte[])var11.S, 0, 16, (int)-953523806);
               this.E = var11.E(-1680071522);
            }
         } else {
            if (var3 == 0) {
               long var4 = var2.V(1453589293);
               long var6 = var2.V(216828969);
               long var8 = var2.V(958666578);
               if (var4 < 0L || var6 < 0L || var8 < 0L || var8 > var4) {
                  throw new IllegalStateException();
               }

               this.G = (float)(var4 * (long)(2110967325 * this.K)) / (float)(-180836195 * this.getData);
               this.H = (float)((var4 + var6) * (long)(this.K * 2110967325)) / (float)(-180836195 * this.getData);
               int var10 = var2.A(-1427296069);
               if (var10 < 0 || var10 > var2.S.length - 385051775 * var2.A) {
                  throw new IllegalStateException();
               }

               this.append = DF.I(var2.S, var2.A * 385051775, var10, -854138275);
            }

            if ((var3 | 128) != 0) {
               return;
            }
         }
      }

   }

   void method3072() {
   }

   void method3076(OggPacket var1) {
      if (this.S * -1312498565 <= 0 || "SUB".equals(this.E)) {
         REI var2 = new REI(var1.getData());
         int var3 = var2.I();
         if (-1312498565 * this.S <= 8) {
            if ((var3 | 128) == 0) {
               throw new IllegalStateException();
            }

            if (-1312498565 * this.S == 0) {
               var2.A += -1617461143;
               this.getData = var2.A(-1909623846) * 33758645;
               this.K = var2.A(1996267542) * 1857578037;
               if (this.getData * -180836195 == 0 || this.K * 2110967325 == 0) {
                  throw new IllegalStateException();
               }

               REI var11 = new REI(16);
               var2.I((byte[])var11.S, 0, 16, (int)-953523806);
               this.A = var11.E(-1904784161);
               var11.A = 0;
               var2.I((byte[])var11.S, 0, 16, (int)-953523806);
               this.E = var11.E(333136246);
            }
         } else {
            if (var3 == 0) {
               long var4 = var2.V(1871449900);
               long var6 = var2.V(2001133775);
               long var8 = var2.V(1245800446);
               if (var4 < 0L || var6 < 0L || var8 < 0L || var8 > var4) {
                  throw new IllegalStateException();
               }

               this.G = (float)(var4 * (long)(2110967325 * this.K)) / (float)(-180836195 * this.getData);
               this.H = (float)((var4 + var6) * (long)(this.K * 2110967325)) / (float)(-180836195 * this.getData);
               int var10 = var2.A(1651625621);
               if (var10 < 0 || var10 > var2.S.length - 385051775 * var2.A) {
                  throw new IllegalStateException();
               }

               this.append = DF.I(var2.S, var2.A * 385051775, var10, 1348372434);
            }

            if ((var3 | 128) != 0) {
               return;
            }
         }
      }

   }

   void method3075(int var1) {
   }

   KG(OggStreamState var1) {
      super(var1);
   }
}
