public class EO {
   int method19;
   static int I = 7;
   int Z;
   MJI C;
   KX B;
   static int D = 128;
   boolean F = true;
   int J = -1;
   int S;
   ZAI A;
   PY E;
   FO G;

   void I() {
      this.method19(this.A, this.S);
   }

   void method19(ZAI var1, int var2) {
      if (var2 != 0) {
         this.Z();
         this.C.I((SN)this.G);
         this.C.I(var1, 4, 0, var2);
      }

   }

   void Z() {
      if (this.F) {
         this.F = false;
         byte[] var1 = this.B.C;
         byte[] var2 = this.C.dI;
         int var3 = 0;
         int var4 = this.B.I;
         int var5 = this.method19 + this.Z * this.B.I;

         int var6;
         int var7;
         for(var6 = -128; var6 < 0; ++var6) {
            var3 = (var3 << 8) - var3;

            for(var7 = -128; var7 < 0; ++var7) {
               if (var1[var5++] != 0) {
                  ++var3;
               }
            }

            var5 += var4 - 128;
         }

         if (this.G != null && this.J == var3) {
            this.F = false;
         } else {
            this.J = var3;
            var6 = 0;
            var5 = this.method19 + this.Z * var4;

            for(var7 = -128; var7 < 0; ++var7) {
               for(int var8 = -128; var8 < 0; ++var8) {
                  if (var1[var5] != 0) {
                     var2[var6++] = 68;
                  } else {
                     int var9 = 0;
                     if (var1[var5 - 1] != 0) {
                        ++var9;
                     }

                     if (var1[var5 + 1] != 0) {
                        ++var9;
                     }

                     if (var1[var5 - var4] != 0) {
                        ++var9;
                     }

                     if (var1[var5 + var4] != 0) {
                        ++var9;
                     }

                     var2[var6++] = (byte)(17 * var9);
                  }

                  ++var5;
               }

               var5 += this.B.I - 128;
            }

            if (this.G == null) {
               this.G = new FO(this.C, 3553, YCI.G, SDI.C, 128, 128, false, this.C.dI, YCI.G, false);
               this.G.I(false, false);
               this.G.I(true);
            } else {
               this.G.I(0, 0, 128, 128, this.C.dI, YCI.G, 0, 0, false);
            }
         }
      }

   }

   EO(MJI var1, KX var2, CSI var3, int var4, int var5, int var6, int var7, int var8) {
      this.C = var1;
      this.B = var2;
      this.method19 = var7;
      this.Z = var8;
      int var9 = 1 << var6;
      int var10 = 0;
      int var11 = var4 << var6;
      int var12 = var5 << var6;

      int var14;
      int var15;
      for(int var13 = 0; var13 < var9; ++var13) {
         var14 = (var12 + var13) * var3.Z * -506105871 + var11;

         for(var15 = 0; var15 < var9; ++var15) {
            short[] var16 = var3.X[var14++];
            if (var16 != null) {
               var10 += var16.length;
            }
         }
      }

      this.S = var10;
      if (var10 > 0) {
         REI var19 = new REI(var10 * 2);
         short[] var17;
         int var18;
         int var20;
         if (this.C.u) {
            for(var14 = 0; var14 < var9; ++var14) {
               var15 = (var12 + var14) * var3.Z * -506105871 + var11;

               for(var20 = 0; var20 < var9; ++var20) {
                  var17 = var3.X[var15++];
                  if (var17 != null) {
                     for(var18 = 0; var18 < var17.length; ++var18) {
                        var19.Z(var17[var18] & '\uffff', 16711935);
                     }
                  }
               }
            }
         } else {
            for(var14 = 0; var14 < var9; ++var14) {
               var15 = (var12 + var14) * var3.Z * -506105871 + var11;

               for(var20 = 0; var20 < var9; ++var20) {
                  var17 = var3.X[var15++];
                  if (var17 != null) {
                     for(var18 = 0; var18 < var17.length; ++var18) {
                        var19.C(var17[var18] & '\uffff', 1368367793);
                     }
                  }
               }
            }
         }

         this.A = this.C.Z(5123, var19.S, var19.A * 385051775, false);
         this.E = new PY(this.C, 5123, (byte[])null, 1);
      } else {
         this.G = null;
      }

   }

   void I(byte[] var1, int var2) {
      this.E.method19(5123, var1, var2 * 2);
      this.method19(this.E, var2);
   }
}
