public class DZ extends BZ {
   int append = 0;

   public void method56(boolean var1) {
      int var2 = this.Z.Z.I(this.I.method271(), XEI.BC * 775068819, -2069269081) + this.Z.B * -245579987;
      int var3 = this.Z.D.I(this.I.method626(), XEI.KC * -791746413, -936935431) + this.Z.I * -1426302101;
      this.I.I((float)(var2 + this.I.method271() / 2), (float)(var3 + this.I.method626() / 2), 4096, this.append * -157704951);
      this.append += 315105141 * ((GC)this.Z).J;
   }

   DZ(KJ var1, GC var2) {
      super(var1, var2);
   }

   public void method58(boolean var1, byte var2) {
      try {
         int var3 = this.Z.Z.I(this.I.method271(), XEI.BC * 775068819, -2041461531) + this.Z.B * -245579987;
         int var4 = this.Z.D.I(this.I.method626(), XEI.KC * -791746413, -2132177466) + this.Z.I * -1426302101;
         this.I.I((float)(var3 + this.I.method271() / 2), (float)(var4 + this.I.method626() / 2), 4096, this.append * -157704951);
         this.append += 315105141 * ((GC)this.Z).J;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "zh.f(" + ')');
      }
   }

   static final void I(int var0, byte var1) {
      try {
         XEI.CC = new int[var0];
         XEI.ZI = new int[var0];
         XEI.DC = new int[var0];
         XEI.Y = new int[var0];
         XEI.JC = new int[var0];
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "zh.iw(" + ')');
      }
   }
}
