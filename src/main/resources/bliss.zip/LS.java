import jaggl.OpenGL;

public class LS extends HS implements DEI {
   int b;
   int glPixelStorei;
   int glTexImage3Dub;

   LS(OJI var1, YCI var2, int var3, int var4, int var5, boolean var6, byte[] var7) {
      super(var1, 32879, var2, SDI.C, var3 * var4 * var5, var6);
      this.glPixelStorei = var3;
      this.glTexImage3Dub = var4;
      this.b = var5;
      this.D.I((IEI)this);
      OpenGL.glPixelStorei(3317, 1);
      OpenGL.glTexImage3Dub(this.I, 0, OJI.I(this.C, this.B), this.glPixelStorei, this.glTexImage3Dub, this.b, 0, OJI.I(this.C), 5121, var7, 0);
      OpenGL.glPixelStorei(3317, 4);
      if (var6) {
         this.Z();
      }

   }

   public void method128() {
      super.method128();
   }

   public void u() {
      super.b();
   }

   public void b() {
      super.b();
   }

   public void method129(EB var1) {
      super.method122(var1);
   }

   public void d() {
      super.b();
   }

   public void x() {
      super.b();
   }

   public void method125() {
      super.method128();
   }

   public void method126() {
      super.method128();
   }

   public void method122(EB var1) {
      super.method122(var1);
   }

   public void method127(EB var1) {
      super.method122(var1);
   }

   public void method124(EB var1) {
      super.method122(var1);
   }

   public void method123() {
      super.method128();
   }
}
