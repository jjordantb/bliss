public class GK extends YG {
   static int Q = 409;
   static int R = 4096;
   int T = -496736879;
   int U = 571002880;
   int V = -1106251776;
   static int W = 4096;
   int X = 1049899008;
   static int Y = 4096;
   int[] i = new int[3];

   void I(int var1, REI var2, byte var3) {
      try {
         switch(var1) {
         case 0:
            this.T = var2.C() * -2038436167;
            break;
         case 1:
            this.V = var2.C() * 1987830015;
            break;
         case 2:
            this.U = var2.C() * -1725816691;
            break;
         case 3:
            this.X = var2.C() * 2122574147;
            break;
         case 4:
            int var4 = var2.B((byte)109);
            this.i[0] = (var4 & 16711680) << 4;
            this.i[1] = (var4 & '\uff00') >> 4;
            this.i[2] = (var4 & 255) >> 12;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "agq.r(" + ')');
      }
   }

   int[][] I(int var1, byte var2) {
      try {
         int[][] var3 = this.L.I(var1, (byte)97);
         if (this.L.I) {
            int[][] var4 = this.I(0, var1, (byte)8);
            int[] var5 = var4[0];
            int[] var6 = var4[1];
            int[] var7 = var4[2];
            int[] var8 = var3[0];
            int[] var9 = var3[1];
            int[] var10 = var3[2];

            for(int var11 = 0; var11 < -1474554145 * WJ.C; ++var11) {
               int var12 = var5[var11];
               int var13 = var12 - this.i[0];
               if (var13 < 0) {
                  var13 = -var13;
               }

               if (var13 > this.T * 1467725705) {
                  var8[var11] = var12;
                  var9[var11] = var6[var11];
                  var10[var11] = var7[var11];
               } else {
                  int var14 = var6[var11];
                  var13 = var14 - this.i[1];
                  if (var13 < 0) {
                     var13 = -var13;
                  }

                  if (var13 > this.T * 1467725705) {
                     var8[var11] = var12;
                     var9[var11] = var14;
                     var10[var11] = var7[var11];
                  } else {
                     int var15 = var7[var11];
                     var13 = var15 - this.i[2];
                     if (var13 < 0) {
                        var13 = -var13;
                     }

                     if (var13 > 1467725705 * this.T) {
                        var8[var11] = var12;
                        var9[var11] = var14;
                        var10[var11] = var15;
                     } else {
                        var8[var11] = var12 * this.X * -1157633173 >> 12;
                        var9[var11] = var14 * this.U * -620453307 >> 12;
                        var10[var11] = var15 * -322756865 * this.V >> 12;
                     }
                  }
               }
            }
         }

         return var3;
      } catch (RuntimeException var16) {
         throw DQ.I(var16, "agq.k(" + ')');
      }
   }

   void Z(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.T = var2.C() * -2038436167;
         break;
      case 1:
         this.V = var2.C() * 1987830015;
         break;
      case 2:
         this.U = var2.C() * -1725816691;
         break;
      case 3:
         this.X = var2.C() * 2122574147;
         break;
      case 4:
         int var3 = var2.B((byte)-48);
         this.i[0] = (var3 & 16711680) << 4;
         this.i[1] = (var3 & '\uff00') >> 4;
         this.i[2] = (var3 & 255) >> 12;
      }

   }

   public GK() {
      super(1, false);
   }

   void append(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.T = var2.C() * -2038436167;
         break;
      case 1:
         this.V = var2.C() * 1987830015;
         break;
      case 2:
         this.U = var2.C() * -1725816691;
         break;
      case 3:
         this.X = var2.C() * 2122574147;
         break;
      case 4:
         int var3 = var2.B((byte)108);
         this.i[0] = (var3 & 16711680) << 4;
         this.i[1] = (var3 & '\uff00') >> 4;
         this.i[2] = (var3 & 255) >> 12;
      }

   }

   int[][] toString(int var1) {
      int[][] var2 = this.L.I(var1, (byte)81);
      if (this.L.I) {
         int[][] var3 = this.I(0, var1, (byte)8);
         int[] var4 = var3[0];
         int[] var5 = var3[1];
         int[] var6 = var3[2];
         int[] var7 = var2[0];
         int[] var8 = var2[1];
         int[] var9 = var2[2];

         for(int var10 = 0; var10 < -1474554145 * WJ.C; ++var10) {
            int var11 = var4[var10];
            int var12 = var11 - this.i[0];
            if (var12 < 0) {
               var12 = -var12;
            }

            if (var12 > this.T * 1467725705) {
               var7[var10] = var11;
               var8[var10] = var5[var10];
               var9[var10] = var6[var10];
            } else {
               int var13 = var5[var10];
               var12 = var13 - this.i[1];
               if (var12 < 0) {
                  var12 = -var12;
               }

               if (var12 > this.T * 1467725705) {
                  var7[var10] = var11;
                  var8[var10] = var13;
                  var9[var10] = var6[var10];
               } else {
                  int var14 = var6[var10];
                  var12 = var14 - this.i[2];
                  if (var12 < 0) {
                     var12 = -var12;
                  }

                  if (var12 > 1467725705 * this.T) {
                     var7[var10] = var11;
                     var8[var10] = var13;
                     var9[var10] = var14;
                  } else {
                     var7[var10] = var11 * this.X * -1157633173 >> 12;
                     var8[var10] = var13 * this.U * -620453307 >> 12;
                     var9[var10] = var14 * -322756865 * this.V >> 12;
                  }
               }
            }
         }
      }

      return var2;
   }

   int[][] append(int var1) {
      int[][] var2 = this.L.I(var1, (byte)19);
      if (this.L.I) {
         int[][] var3 = this.I(0, var1, (byte)8);
         int[] var4 = var3[0];
         int[] var5 = var3[1];
         int[] var6 = var3[2];
         int[] var7 = var2[0];
         int[] var8 = var2[1];
         int[] var9 = var2[2];

         for(int var10 = 0; var10 < -1474554145 * WJ.C; ++var10) {
            int var11 = var4[var10];
            int var12 = var11 - this.i[0];
            if (var12 < 0) {
               var12 = -var12;
            }

            if (var12 > this.T * 1467725705) {
               var7[var10] = var11;
               var8[var10] = var5[var10];
               var9[var10] = var6[var10];
            } else {
               int var13 = var5[var10];
               var12 = var13 - this.i[1];
               if (var12 < 0) {
                  var12 = -var12;
               }

               if (var12 > this.T * 1467725705) {
                  var7[var10] = var11;
                  var8[var10] = var13;
                  var9[var10] = var6[var10];
               } else {
                  int var14 = var6[var10];
                  var12 = var14 - this.i[2];
                  if (var12 < 0) {
                     var12 = -var12;
                  }

                  if (var12 > 1467725705 * this.T) {
                     var7[var10] = var11;
                     var8[var10] = var13;
                     var9[var10] = var14;
                  } else {
                     var7[var10] = var11 * this.X * -1157633173 >> 12;
                     var8[var10] = var13 * this.U * -620453307 >> 12;
                     var9[var10] = var14 * -322756865 * this.V >> 12;
                  }
               }
            }
         }
      }

      return var2;
   }
}
