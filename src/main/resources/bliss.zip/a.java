import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class a implements SAI {
   Runnable aRunnable6669;
   ja aJa6670;
   long nativeid;
   h[] aHArray6671 = new h[7];
   h[] aHArray6672 = new h[7];
   YF aClass233_6673;

   public void ma(boolean var1) {
      this.R(this.nativeid, var1);
   }

   static void method50123(int var0) {
      try {
         Class var1 = ClassLoader.class;
         Field var2 = var1.getDeclaredField("nativeLibraries");
         Class var3 = AccessibleObject.class;
         Method var4 = var3.getDeclaredMethod("setAccessible", Boolean.TYPE);
         var4.invoke(var2, Boolean.TRUE);
      } catch (Throwable var5) {
         ;
      }

   }

   native void i(long var1, long var3, int var5, int var6, int var7, int var8, int var9, int var10, int var11, boolean[][] var12);

   native void bv(long var1, long var3, int var5, int var6, int var7, int var8, int var9, int var10, int var11, boolean[][] var12);

   native void ha(long var1, GSI var3, int var4, int var5);

   UT method276(h var1, byte var2, int var3, boolean var4) {
      boolean var5 = false;
      h var6;
      h var7;
      if (var2 > 0 && var2 <= 7) {
         var7 = this.aHArray6672[var2 - 1];
         var6 = this.aHArray6671[var2 - 1];
         var5 = true;
      } else {
         var6 = var7 = new h(this.aJa6670);
      }

      var1.BA(var6, var7, var3, var5, var4);
      var6.aClass85Array6677 = var1.aClass85Array6677;
      var6.aClass68Array6676 = var1.aClass68Array6676;
      return var6;
   }

   void method277() {
      this.JA(this.nativeid);
   }

   void method278(GSI var1, int[] var2, int[] var3, int[] var4, short[] var5, int var6) {
      this.b(this.nativeid, var1, var2, var3, var4, var5, var6);
   }

   native void b(long var1, GSI var3, int[] var4, int[] var5, int[] var6, short[] var7, int var8);

   native void P(long var1, long var3, long var5, int var7, int var8, int var9, boolean var10);

   void method279(UT var1, LF var2, int[] var3, int var4) {
      this.aClass233_6673.I(var2);
      this.wa(this.nativeid, ((h)var1).nativeid, this.aClass233_6673.I, var3, var4);
   }

   native boolean ya(long var1, long var3, int var5, int var6, float[] var7, boolean var8);

   void method280(UT var1, int[] var2, LF var3) {
      this.aClass233_6673.I(var3);
      this.J(this.nativeid, ((h)var1).nativeid, var2, this.aClass233_6673.I);
   }

   native void JA(long var1);

   void method281(YJI var1, int var2, int var3) {
      this.v(this.nativeid, ((i)var1).nativeid, var2, var3);
   }

   native void v(long var1, long var3, int var5, int var6);

   void method282(YJI var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, boolean[][] var9) {
      this.i(this.nativeid, ((i)var1).nativeid, var2, var3, var4, var5, var6, var7, var8, var9);
   }

   native void K(long var1, GSI var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10);

   native void c(long var1, GSI var3, int var4, int var5);

   native void m(long var1, GSI var3, int var4, int var5);

   native void w(long var1, GSI var3, int var4, int var5);

   native void j(long var1, boolean var3);

   void method283() {
      this.aRunnable6669 = Thread.currentThread();
      this.method277();
   }

   native void ak(long var1);

   native void wa(long var1, long var3, float[] var5, int[] var6, int var7);

   native void ao(long var1, GSI var3, int[] var4, int[] var5, int[] var6, short[] var7, int var8);

   native void ad(long var1, GSI var3, int[] var4, int[] var5, int[] var6, short[] var7, int var8);

   native void av(long var1, GSI var3, int[] var4, int[] var5, int[] var6, short[] var7, int var8);

   native void at(long var1, GSI var3, int[] var4, int[] var5, int[] var6, short[] var7, int var8);

   native void ah(long var1, GSI var3, int[] var4, int[] var5, int[] var6, short[] var7, int var8);

   native void bp(long var1, long var3, int var5, int var6, int var7, int var8, int var9, int var10, int var11, boolean[][] var12);

   native void ap(long var1, GSI var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10);

   a(ja var1, int var2, int var3) {
      this.aJa6670 = var1;

      for(int var4 = 0; var4 < 7; ++var4) {
         this.aHArray6671[var4] = new h(this.aJa6670);
         this.aHArray6672[var4] = new h(this.aJa6670);
      }

      this.aClass233_6673 = new YF();
      this.ha(this.nativeid, var1, var2, var3);
   }

   native void ab(long var1, long var3, long var5, int var7, int var8, int var9, boolean var10);

   native void aj(long var1, long var3, long var5, int var7, int var8, int var9, boolean var10);

   boolean method284(UT var1, int var2, int var3, LF var4, boolean var5) {
      this.aClass233_6673.I(var4);
      return this.ya(this.nativeid, ((h)var1).nativeid, var2, var3, this.aClass233_6673.I, var5);
   }

   native void au(long var1, long var3, float[] var5, int[] var6, int var7);

   native void ar(long var1, long var3, float[] var5, int[] var6, int var7);

   native void ac(long var1, long var3, float[] var5, int[] var6, int var7);

   native void J(long var1, long var3, int[] var5, float[] var6);

   void method285(UT var1, UT var2, int var3, int var4, int var5, boolean var6) {
      this.P(this.nativeid, ((h)var1).nativeid, ((h)var2).nativeid, var3, var4, var5, var6);
   }

   native void as(long var1, GSI var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10);

   native void o(long var1, boolean var3);

   native void bo(long var1, long var3, int[] var5, float[] var6);

   native void bb(long var1, long var3, int[] var5, float[] var6);

   native boolean bf(long var1, long var3, int var5, int var6, float[] var7, boolean var8);

   native boolean bd(long var1, long var3, int var5, int var6, float[] var7, boolean var8);

   native void R(long var1, boolean var3);

   void method286(GSI var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      this.K(this.nativeid, var1, var2, var3, var4, var5, var6, var7, var8);
   }

   public void z(boolean var1) {
      this.R(this.nativeid, var1);
   }

   native void bh(long var1, long var3, int var5, int var6, int var7, int var8, int var9, int var10, int var11, boolean[][] var12);
}
