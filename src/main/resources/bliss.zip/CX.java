public class CX {
   MBI[] I = new MBI[4];
   XW append;
   boolean Z;
   KJ clone;
   KJ C;
   public static int toString = 256;
   JQ B = new JQ(256);
   JQ D = new JQ(500);
   JQ F = new JQ(50);
   JQ J = new JQ(30);
   int S;
   String[] A;
   ZV E;
   ZY G = new ZY((Object)null, (Object)null);

   public void I(boolean var1, int var2) {
      try {
         if (this.Z != var1) {
            this.Z = var1;
            this.I(1159892995);
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "rx.f(" + ')');
      }
   }

   public void I(int var1, int var2) {
      try {
         this.S = -570701637 * var1;
         JQ var3 = this.D;
         synchronized(this.D) {
            this.D.I();
         }

         var3 = this.J;
         synchronized(this.J) {
            this.J.I();
         }

         var3 = this.F;
         synchronized(this.F) {
            this.F.I();
         }
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "rx.b(" + ')');
      }
   }

   public void I(int var1, byte var2) {
      try {
         this.B = new JQ(var1);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "rx.p(" + ')');
      }
   }

   public void I(int var1) {
      try {
         JQ var2 = this.B;
         synchronized(this.B) {
            this.B.I();
         }

         var2 = this.D;
         synchronized(this.D) {
            this.D.I();
         }

         var2 = this.J;
         synchronized(this.J) {
            this.J.I();
         }

         var2 = this.F;
         synchronized(this.F) {
            this.F.I();
         }

         this.I = new MBI[4];
         this.G = new ZY((Object)null, (Object)null);
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "rx.i(" + ')');
      }
   }

   public void Z(int var1, byte var2) {
      try {
         JQ var3 = this.B;
         synchronized(this.B) {
            this.B.I(var1, -798729587);
         }

         var3 = this.D;
         synchronized(this.D) {
            this.D.I(var1, -1754602717);
         }

         var3 = this.J;
         synchronized(this.J) {
            this.J.I(var1, 466618917);
         }

         var3 = this.F;
         synchronized(this.F) {
            this.F.I(var1, -855180536);
         }
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "rx.k(" + ')');
      }
   }

   public void Z(int var1) {
      try {
         JQ var2 = this.B;
         synchronized(this.B) {
            this.B.Z();
         }

         var2 = this.D;
         synchronized(this.D) {
            this.D.Z();
         }

         var2 = this.J;
         synchronized(this.J) {
            this.J.Z();
         }

         var2 = this.F;
         synchronized(this.F) {
            this.F.Z();
         }
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "rx.d(" + ')');
      }
   }

   public CX(ZV var1, XW var2, boolean var3, KJ var4, KJ var5) {
      this.E = var1;
      this.append = var2;
      this.Z = var3;
      this.clone = var4;
      this.C = var5;
      if (this.clone != null) {
         int var6 = this.clone.Z(1680210708) - 1;
         II.a.I((short)23751);
         this.clone.F(var6, -1017296855);
      }

      if (this.E == ZV.D) {
         this.A = new String[]{null, null, null, null, null, VEI.MZ.I(this.append, -875414210)};
      } else {
         this.A = new String[6];
      }

   }

   public KEI C(int var1) {
      try {
         JQ var3 = this.B;
         KEI var2;
         synchronized(this.B) {
            var2 = (KEI)this.B.I((long)var1);
         }

         if (var2 != null) {
            return var2;
         } else {
            KJ var4 = this.clone;
            byte[] var9;
            synchronized(this.clone) {
               var9 = this.clone.I(II.a.Z(var1, -1875026798), II.a.I(var1, -1955117131), (byte)-69);
            }

            var2 = new KEI();
            var2.Z = var1 * -950871973;
            var2.s = this;
            var2.U = (String[])this.A.clone();
            if (var9 != null) {
               var2.I(new REI(var9), -1780393822);
            }

            var2.Z(-231037911);
            if (var2.l) {
               var2.G = 0;
               var2.r = false;
            }

            if (!this.Z && var2.BI) {
               var2.U = null;
               var2.F = null;
            }

            JQ var10 = this.B;
            synchronized(this.B) {
               this.B.I(var2, (long)var1);
            }

            return var2;
         }
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "rx.a(" + ')');
      }
   }

   static final void I(int var0, int var1, int var2, int var3, int var4) {
      try {
         int var5 = 0;
         int var6 = var2;
         int var7 = -var2;
         int var8 = -1;
         DFI.I(IT.I[var1], var0 - var2, var0 + var2, var3, 198591816);

         while(var6 > var5) {
            var8 += 2;
            var7 += var8;
            ++var5;
            if (var7 >= 0) {
               --var6;
               var7 -= var6 << 1;
               int[] var9 = IT.I[var6 + var1];
               int[] var10 = IT.I[var1 - var6];
               int var11 = var5 + var0;
               int var12 = var0 - var5;
               DFI.I(var9, var12, var11, var3, 1681024850);
               DFI.I(var10, var12, var11, var3, -1116732446);
            }

            int var14 = var6 + var0;
            int var15 = var0 - var6;
            int[] var16 = IT.I[var1 + var5];
            int[] var17 = IT.I[var1 - var5];
            DFI.I(var16, var15, var14, var3, -143852292);
            DFI.I(var17, var15, var14, var3, 358013733);
         }

      } catch (RuntimeException var13) {
         throw DQ.I(var13, "rx.s(" + ')');
      }
   }

   static final void I(OU var0, short var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-1);
         X var4 = IU.F[var2 >> 16];
         HM.I(var3, var4, var0, (byte)-45);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "rx.dc(" + ')');
      }
   }

   static B[] B(int var0) {
      try {
         return new B[]{B.V, B.Z, B.RZ, B.B, B.D, B.F, B.J, B.cI, B.A, B.hI, B.WI, B.H, B.KZ, B.L, B.f, B.N, B.O, B.P, B.Q, B.n, B.ZZ, B.M, B.OZ, B.W, B.X, B.qI, B.o, B.v, B.T, B.S, B.d, B.iI, B.j, B.s, B.a, B.e, B.g, B.h, B.k, B.l, B.tI, B.G, B.UZ, B.p, B.q, B.r, B.t, B.u, B.K, B.w, B.x, B.y, B.II, B.rI, B.CI, B.BI, B.DI, B.FI, B.eI, B.SI, B.AI, B.EI, B.GI, B.c, B.LI, B.TI, B.MI, B.NI, B.OI, B.PI, B.QI, B.RI, B.gI, B.UI, B.VI, B.Y, B.XI, B.I, B.QZ, B.zI, B.z, B.bI, B.aI, B.fI, B.jI, B.YI, B.SZ, B.dI, B.DZ, B.ZI, B.kI, B.lI, B.sI, B.nI, B.C, B.pI, B.TZ, B.U, B.E, B.uI, B.m, B.wI, B.HI, B.yI, B.IZ, B.R, B.CZ, B.BZ, B.oI, B.FZ, B.JZ, B.mI, B.AZ, B.EZ, B.GZ, B.HZ, B.xI, B.LZ, B.MZ, B.b, B.vI, B.PZ, B.i, B.KI, B.JI};
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "rx.a(" + ')');
      }
   }
}
