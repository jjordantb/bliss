import jagdx.IDirect3DDevice;
import jagdx.IUnknown;
import java.nio.ByteBuffer;

public class DC extends CC {
   long Z = 0L;
   PJI CreateVertexDeclaration;

   void CreateVertexDeclaration(ByteBuffer var1, short var2, short var3, byte var4, byte var5, byte var6, byte var7) {
      var1.putShort(var2);
      var1.putShort(var3);
      var1.put(var4);
      var1.put(var5);
      var1.put(var6);
      var1.put(var7);
   }

   public void b() {
      if (this.Z != 0L) {
         IUnknown.Release(this.Z);
         this.Z = 0L;
      }

      this.CreateVertexDeclaration.I((QAI)this);
   }

   void I() {
      if (this.Z != 0L) {
         this.CreateVertexDeclaration.Z(this.Z);
         this.Z = 0L;
      }

   }

   public void u() {
      if (this.Z != 0L) {
         IUnknown.Release(this.Z);
         this.Z = 0L;
      }

      this.CreateVertexDeclaration.I((QAI)this);
   }

   public void d() {
      if (this.Z != 0L) {
         IUnknown.Release(this.Z);
         this.Z = 0L;
      }

      this.CreateVertexDeclaration.I((QAI)this);
   }

   public void x() {
      if (this.Z != 0L) {
         IUnknown.Release(this.Z);
         this.Z = 0L;
      }

      this.CreateVertexDeclaration.I((QAI)this);
   }

   DC(PJI var1, KB[] var2) {
      super(var2);
      this.CreateVertexDeclaration = var1;
      byte var3 = 0;
      ByteBuffer var4 = this.CreateVertexDeclaration.F;
      var4.clear();

      for(short var5 = 0; var5 < this.I.length; ++var5) {
         short var6 = 0;
         KB var7 = this.I[var5];

         for(int var8 = 0; var8 < var7.I(); ++var8) {
            JC var9 = var7.I(var8);
            if (var9 == JC.N) {
               this.CreateVertexDeclaration(var4, var5, var6, (byte)2, (byte)0, (byte)0, (byte)0);
            } else if (var9 == JC.Z) {
               this.CreateVertexDeclaration(var4, var5, var6, (byte)2, (byte)0, (byte)3, (byte)0);
            } else if (var9 == JC.C) {
               this.CreateVertexDeclaration(var4, var5, var6, (byte)4, (byte)0, (byte)10, (byte)0);
            } else {
               byte var14;
               byte var15;
               byte var16;
               byte var17;
               if (var9 == JC.J) {
                  var14 = 0;
                  var15 = 0;
                  var16 = 5;
                  var17 = var3++;
                  this.CreateVertexDeclaration(var4, var5, var6, var14, var15, var16, var17);
               } else if (var9 == JC.D) {
                  var14 = 1;
                  var15 = 0;
                  var16 = 5;
                  var17 = var3++;
                  this.CreateVertexDeclaration(var4, var5, var6, var14, var15, var16, var17);
               } else if (var9 == JC.F) {
                  var14 = 2;
                  var15 = 0;
                  var16 = 5;
                  var17 = var3++;
                  this.CreateVertexDeclaration(var4, var5, var6, var14, var15, var16, var17);
               } else if (var9 == JC.B) {
                  var14 = 3;
                  var15 = 0;
                  var16 = 5;
                  var17 = var3++;
                  this.CreateVertexDeclaration(var4, var5, var6, var14, var15, var16, var17);
               }
            }

            var6 = (short)(var6 + var9.O);
         }
      }

      this.CreateVertexDeclaration(var4, (short)255, (short)0, (byte)17, (byte)0, (byte)0, (byte)0);
      this.Z = IDirect3DDevice.CreateVertexDeclaration(this.CreateVertexDeclaration.FZ, this.CreateVertexDeclaration.J);
      this.CreateVertexDeclaration.Z(this);
   }
}
