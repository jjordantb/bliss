public interface CAI {
   String method240(RR var1, int[] var2, long var3);

   String method241(RR var1, int[] var2, long var3);
}
