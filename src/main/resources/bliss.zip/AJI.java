public class AJI extends DJI {
   int append;
   int toString;
   int F;
   static int J = 1;
   int S;
   int A;
   int E;
   int G;
   int H;

   void method1050(int var1, int var2) {
   }

   void method1054(int var1, int var2, byte var3) {
      try {
         int var4 = var1 * -499535773 * this.toString >> 12;
         int var5 = this.F * -1676834815 * var2 >> 12;
         int var6 = this.H * 1286877931 * var1 >> 12;
         int var7 = 1208078209 * this.S * var2 >> 12;
         int var8 = 1616079851 * this.A * var1 >> 12;
         int var9 = 1348897509 * this.E * var2 >> 12;
         int var10 = 1800257793 * this.append * var1 >> 12;
         int var11 = 1776133377 * this.G * var2 >> 12;
         LEI.I(var4, var5, var6, var7, var8, var9, var10, var11, this.Z * 1785836763, (byte)-73);
      } catch (RuntimeException var12) {
         throw DQ.I(var12, "yy.a(" + ')');
      }
   }

   AJI(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10) {
      super(-1, var9, var10);
      this.toString = var1 * -1481748149;
      this.F = var2 * 2083682305;
      this.H = var3 * -581704253;
      this.S = var4 * 860778625;
      this.A = -324574013 * var5;
      this.E = -1154276627 * var6;
      this.append = -13418751 * var7;
      this.G = -2055513343 * var8;
   }

   void method1048(int var1, int var2, byte var3) {
   }

   void method1049(int var1, int var2) {
      int var3 = var1 * -499535773 * this.toString >> 12;
      int var4 = this.F * -1676834815 * var2 >> 12;
      int var5 = this.H * 1286877931 * var1 >> 12;
      int var6 = 1208078209 * this.S * var2 >> 12;
      int var7 = 1616079851 * this.A * var1 >> 12;
      int var8 = 1348897509 * this.E * var2 >> 12;
      int var9 = 1800257793 * this.append * var1 >> 12;
      int var10 = 1776133377 * this.G * var2 >> 12;
      LEI.I(var3, var4, var5, var6, var7, var8, var9, var10, this.Z * 1785836763, (byte)-33);
   }

   void method1052(int var1, int var2) {
   }

   void method1053(int var1, int var2) {
   }

   void method1046(int var1, int var2) {
   }

   void method1051(int var1, int var2) {
   }

   void method1047(int var1, int var2, byte var3) {
   }

   static final void I(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-58);
         var0.H[(var0.J += -391880689) * 681479919 - 1] = 2053897963 * var3.w;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "yy.rq(" + ')');
      }
   }

   static final int I(int var0, int var1, int var2, int var3) {
      try {
         if (var1 == var0) {
            return var0;
         } else {
            int var4 = 128 - var2;
            int var5 = var2 * (var1 & 127) + var4 * (var0 & 127) >> 7;
            int var6 = var4 * (var0 & 896) + (var1 & 896) * var2 >> 7;
            int var7 = (var0 & 'ﰀ') * var4 + var2 * (var1 & 'ﰀ') >> 7;
            return var7 & 'ﰀ' | var6 & 896 | var5 & 127;
         }
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "yy.c(" + ')');
      }
   }
}
