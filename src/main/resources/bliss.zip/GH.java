public class GH extends YG {
   int sqrt = 0;
   static int Q = 0;
   static int R = 0;
   static int T = 2;
   static int U = 0;
   static int V = 1;
   static int W = 0;
   int X = 0;
   int Y = -190415455;

   void Z(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.sqrt = var2.I() * 56159889;
         break;
      case 1:
         this.X = var2.I() * -518479681;
      case 2:
      default:
         break;
      case 3:
         this.Y = var2.I() * -190415455;
      }

   }

   void I(int var1, REI var2, byte var3) {
      try {
         switch(var1) {
         case 0:
            this.sqrt = var2.I() * 56159889;
            break;
         case 1:
            this.X = var2.I() * -518479681;
         case 2:
         default:
            break;
         case 3:
            this.Y = var2.I() * -190415455;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ahg.r(" + ')');
      }
   }

   void B(int var1) {
      try {
         WJ.I((byte)40);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ahg.x(" + ')');
      }
   }

   void append(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.sqrt = var2.I() * 56159889;
         break;
      case 1:
         this.X = var2.I() * -518479681;
      case 2:
      default:
         break;
      case 3:
         this.Y = var2.I() * -190415455;
      }

   }

   int[] sqrt(int var1) {
      int[] var2 = this.P.I(var1, 1479110455);
      if (this.P.D) {
         int var3 = WJ.J[var1];
         int var4 = var3 - 2048 >> 1;

         for(int var5 = 0; var5 < WJ.C * -1474554145; ++var5) {
            int var6 = WJ.A[var5];
            int var7 = var6 - 2048 >> 1;
            int var8;
            if (716214897 * this.sqrt == 0) {
               var8 = (var6 - var3) * 1525982817 * this.Y;
            } else {
               int var9 = var4 * var4 + var7 * var7 >> 12;
               var8 = (int)(Math.sqrt((double)((float)var9 / 4096.0F)) * 4096.0D);
               var8 = (int)((double)(var8 * this.Y * 1525982817) * 3.141592653589793D);
            }

            var8 -= var8 & -4096;
            if (this.X * 1988808511 == 0) {
               var8 = WJ.S[var8 >> 4 & 255] + 4096 >> 1;
            } else if (this.X * 1988808511 == 2) {
               var8 -= 2048;
               if (var8 < 0) {
                  var8 = -var8;
               }

               var8 = 2048 - var8 << 1;
            }

            var2[var5] = var8;
         }
      }

      return var2;
   }

   void Z() {
      WJ.I((byte)-8);
   }

   void append() {
      WJ.I((byte)54);
   }

   void sqrt() {
      WJ.I((byte)-24);
   }

   int[] Z(int var1, int var2) {
      try {
         int[] var3 = this.P.I(var1, -59827140);
         if (this.P.D) {
            int var4 = WJ.J[var1];
            int var5 = var4 - 2048 >> 1;

            for(int var6 = 0; var6 < WJ.C * -1474554145; ++var6) {
               int var7 = WJ.A[var6];
               int var8 = var7 - 2048 >> 1;
               int var9;
               if (716214897 * this.sqrt == 0) {
                  var9 = (var7 - var4) * 1525982817 * this.Y;
               } else {
                  int var10 = var5 * var5 + var8 * var8 >> 12;
                  var9 = (int)(Math.sqrt((double)((float)var10 / 4096.0F)) * 4096.0D);
                  var9 = (int)((double)(var9 * this.Y * 1525982817) * 3.141592653589793D);
               }

               var9 -= var9 & -4096;
               if (this.X * 1988808511 == 0) {
                  var9 = WJ.S[var9 >> 4 & 255] + 4096 >> 1;
               } else if (this.X * 1988808511 == 2) {
                  var9 -= 2048;
                  if (var9 < 0) {
                     var9 = -var9;
                  }

                  var9 = 2048 - var9 << 1;
               }

               var3[var6] = var9;
            }
         }

         return var3;
      } catch (RuntimeException var11) {
         throw DQ.I(var11, "ahg.i(" + ')');
      }
   }

   public GH() {
      super(0, true);
   }

   int[] toString(int var1) {
      int[] var2 = this.P.I(var1, 2057352597);
      if (this.P.D) {
         int var3 = WJ.J[var1];
         int var4 = var3 - 2048 >> 1;

         for(int var5 = 0; var5 < WJ.C * -1474554145; ++var5) {
            int var6 = WJ.A[var5];
            int var7 = var6 - 2048 >> 1;
            int var8;
            if (716214897 * this.sqrt == 0) {
               var8 = (var6 - var3) * 1525982817 * this.Y;
            } else {
               int var9 = var4 * var4 + var7 * var7 >> 12;
               var8 = (int)(Math.sqrt((double)((float)var9 / 4096.0F)) * 4096.0D);
               var8 = (int)((double)(var8 * this.Y * 1525982817) * 3.141592653589793D);
            }

            var8 -= var8 & -4096;
            if (this.X * 1988808511 == 0) {
               var8 = WJ.S[var8 >> 4 & 255] + 4096 >> 1;
            } else if (this.X * 1988808511 == 2) {
               var8 -= 2048;
               if (var8 < 0) {
                  var8 = -var8;
               }

               var8 = 2048 - var8 << 1;
            }

            var2[var5] = var8;
         }
      }

      return var2;
   }
}
