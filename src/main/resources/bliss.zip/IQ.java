public abstract class IQ {
   public int I;
   static int Z = 2;
   static int append = 4;
   static int method250 = 8;
   public int C;
   static int toString = 1;
   int B;
   public static OS D;
   public static int F;

   public boolean I(byte var1) {
      try {
         return (-877023375 * this.C & 2) != 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "oh.f(" + ')');
      }
   }

   public boolean I(int var1) {
      try {
         return (this.C * -877023375 & 4) != 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "oh.b(" + ')');
      }
   }

   public boolean Z(int var1) {
      try {
         return (-877023375 * this.C & 8) != 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "oh.p(" + ')');
      }
   }

   public boolean C(int var1) {
      try {
         return (-877023375 * this.C & 1) != 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "oh.a(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.X[1883543357 * var0.i];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = MI.E.method250(var2, (byte)38);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "oh.at(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.n.I(-2143352335);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "oh.ajf(" + ')');
      }
   }

   public static final int I(int var0, int var1, byte var2) {
      try {
         if (var0 == -2) {
            return 12345678;
         } else if (var0 == -1) {
            if (var1 < 2) {
               var1 = 2;
            } else if (var1 > 126) {
               var1 = 126;
            }

            return var1;
         } else {
            var1 = (var0 & 127) * var1 >> 7;
            if (var1 < 2) {
               var1 = 2;
            } else if (var1 > 126) {
               var1 = 126;
            }

            return (var0 & 'ﾀ') + var1;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "oh.n(" + ')');
      }
   }

   static boolean B(int var0) {
      try {
         XEI.hI += -75983735;
         XEI.kI = true;
         return true;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "oh.ne(" + ')');
      }
   }
}
