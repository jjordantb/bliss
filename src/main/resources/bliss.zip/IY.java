import java.util.Collection;
import java.util.Iterator;

public class IY implements Iterable, Collection {
   public AE I = new AE();
   AE Z;

   public void I(AE var1, int var2) {
      try {
         if (var1.C != null) {
            var1.I(-1460969981);
         }

         var1.C = this.I.C;
         var1.I = this.I;
         var1.C.I = var1;
         var1.I.C = var1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "sr.f(" + ')');
      }
   }

   public AE I(int var1) {
      try {
         AE var2 = this.I.I;
         if (var2 == this.I) {
            return null;
         } else {
            var2.I(-1460969981);
            return var2;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sr.p(" + ')');
      }
   }

   void Z(IY var1, AE var2, byte var3) {
      try {
         AE var4 = this.I.C;
         this.I.C = var2.C;
         var2.C.I = this.I;
         if (this.I != var2) {
            var2.C = var1.I.C;
            var2.C.I = var2;
            var4.I = var1.I;
            var1.I.C = var4;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "sr.i(" + ')');
      }
   }

   public void I(IY var1, int var2) {
      try {
         if (this.I != this.I.I) {
            this.Z(var1, this.I.I, (byte)-5);
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "sr.k(" + ')');
      }
   }

   public AE Z(int var1) {
      try {
         return this.hashCode((AE)null, 65280);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sr.d(" + ')');
      }
   }

   AE append(AE var1, byte var2) {
      try {
         AE var3;
         if (var1 == null) {
            var3 = this.I.C;
         } else {
            var3 = var1;
         }

         if (this.I == var3) {
            this.Z = null;
            return null;
         } else {
            this.Z = var3.C;
            return var3;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "sr.r(" + ')');
      }
   }

   AE[] equals(byte var1) {
      try {
         AE[] var2 = new AE[this.J(1828905535)];
         int var3 = 0;

         for(AE var4 = this.I.I; var4 != this.I; var4 = var4.I) {
            var2[var3++] = var4;
         }

         return var2;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "sr.y(" + ')');
      }
   }

   public Iterator iterator() {
      try {
         return new RX(this);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "sr.iterator(" + ')');
      }
   }

   public boolean isEmpty() {
      try {
         return this.D(1085448128);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "sr.isEmpty(" + ')');
      }
   }

   public boolean contains(Object var1) {
      try {
         throw new RuntimeException();
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sr.contains(" + ')');
      }
   }

   public Object[] toArray() {
      try {
         return this.equals((byte)7);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "sr.toArray(" + ')');
      }
   }

   public AE C(int var1) {
      try {
         return this.append((AE)null, (byte)4);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sr.x(" + ')');
      }
   }

   public boolean remove(Object var1) {
      try {
         throw new RuntimeException();
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sr.remove(" + ')');
      }
   }

   public boolean containsAll(Collection var1) {
      try {
         throw new RuntimeException();
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sr.containsAll(" + ')');
      }
   }

   public boolean addAll(Collection var1) {
      try {
         throw new RuntimeException();
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sr.addAll(" + ')');
      }
   }

   public boolean removeAll(Collection var1) {
      try {
         throw new RuntimeException();
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sr.removeAll(" + ')');
      }
   }

   public boolean retainAll(Collection var1) {
      try {
         throw new RuntimeException();
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sr.retainAll(" + ')');
      }
   }

   public void clear() {
      try {
         this.I((byte)1);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "sr.clear(" + ')');
      }
   }

   public boolean add(Object var1) {
      try {
         return this.toString((AE)var1, (byte)-121);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sr.add(" + ')');
      }
   }

   public boolean equals(Object var1) {
      try {
         return super.equals(var1);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sr.equals(" + ')');
      }
   }

   public int hashCode() {
      try {
         return super.hashCode();
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "sr.hashCode(" + ')');
      }
   }

   public void I(byte var1) {
      try {
         while(this.I.I != this.I) {
            this.I.I.I(-1460969981);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sr.a(" + ')');
      }
   }

   public Object[] toArray(Object[] var1) {
      try {
         int var2 = 0;

         for(AE var3 = this.I.I; this.I != var3; var3 = var3.I) {
            var1[var2++] = var3;
         }

         return var1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "sr.toArray(" + ')');
      }
   }

   public AE B(int var1) {
      try {
         AE var2 = this.Z;
         if (this.I == var2) {
            this.Z = null;
            return null;
         } else {
            this.Z = var2.I;
            return var2;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sr.q(" + ')');
      }
   }

   AE hashCode(AE var1, int var2) {
      try {
         AE var3;
         if (var1 == null) {
            var3 = this.I.I;
         } else {
            var3 = var1;
         }

         if (this.I == var3) {
            this.Z = null;
            return null;
         } else {
            this.Z = var3.I;
            return var3;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "sr.u(" + ')');
      }
   }

   public IY() {
      this.I.I = this.I;
      this.I.C = this.I;
   }

   public int size() {
      try {
         return this.J(1828905535);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "sr.size(" + ')');
      }
   }

   public boolean D(int var1) {
      try {
         return this.I == this.I.I;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sr.z(" + ')');
      }
   }

   public AE F(int var1) {
      try {
         AE var2 = this.Z;
         if (var2 == this.I) {
            this.Z = null;
            return null;
         } else {
            this.Z = var2.C;
            return var2;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sr.n(" + ')');
      }
   }

   public int J(int var1) {
      try {
         int var2 = 0;

         for(AE var3 = this.I.I; this.I != var3; var3 = var3.I) {
            ++var2;
         }

         return var2;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "sr.s(" + ')');
      }
   }

   boolean toString(AE var1, byte var2) {
      try {
         this.I(var1, 289942482);
         return true;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "sr.t(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         if (XEI.bD * -1333485389 >= 5 && -1333485389 * XEI.bD <= 9) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 1;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sr.ur(" + ')');
      }
   }

   public static void I(int var0, int var1, int var2, KEI var3, int var4) {
      try {
         for(SM var5 = (SM)SM.S.Z(1766612795); var5 != null; var5 = (SM)SM.S.B(49146)) {
            if (var0 == -1926928785 * var5.G && var5.H * -1808325887 == var1 << 9 && var5.E * 757346071 == var2 << 9 && var3.Z * 1181652947 == var5.T.Z * 1181652947) {
               if (var5.f != null) {
                  RA.S.Z(var5.f);
                  var5.f = null;
               }

               if (var5.K != null) {
                  RA.S.Z(var5.K);
                  var5.K = null;
               }

               var5.I(-1460969981);
               break;
            }
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "sr.i(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         XR.I(var3, var4, var0, -638652080);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "sr.lc(" + ')');
      }
   }
}
