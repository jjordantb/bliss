public class BY {
   int I;
   public int Z;
   public int C;
   public int B;

   static final void I(OU var0, int var1) {
      try {
         int var2 = FW.J.W.Z(-2013953489);
         FW.J.I(FW.J.X, var0.H[(var0.J -= -391880689) * 681479919] == 1 ? 0 : var2, -1763382439);
         WY.I((short)-2481);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "su.aij(" + ')');
      }
   }
}
