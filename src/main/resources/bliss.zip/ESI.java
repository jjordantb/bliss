import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class ESI {
   public int I;
   public SX Z;
   public int C = -1313669563;
   public int B;
   public int D;
   static IBI F;

   ESI(SSI var1) {
      this.Z = new EX(var1, false);
   }

   static void B(int var0) {
      try {
         Class var1 = ClassLoader.class;
         Field var2 = var1.getDeclaredField("nativeLibraries");
         Class var3 = AccessibleObject.class;
         Method var4 = var3.getDeclaredMethod("setAccessible", Boolean.TYPE);
         var4.invoke(var2, Boolean.TRUE);
      } catch (Throwable var5) {
         ;
      }

   }

   static MI I(REI var0, int var1) {
      try {
         HZ var2 = XII.Z((byte)-18)[var0.I()];
         IZ var3 = Q.Z(2131483758)[var0.I()];
         int var4 = var0.J(1574617841);
         int var5 = var0.J(1869006107);
         int var6 = var0.C();
         int var7 = var0.C();
         int var8 = var0.J(1992026897);
         int var9 = var0.Y(1235052657);
         int var10 = var0.H((byte)14);
         return new MI(var2, var3, var4, var5, var6, var7, var8, var9, var10);
      } catch (RuntimeException var11) {
         throw DQ.I(var11, "cg.a(" + ')');
      }
   }

   public static final void I(short var0) {
      try {
         PD.I(1548853569);

         for(int var1 = 0; var1 < AN.E * -991384187; ++var1) {
            SE var2 = AN.G[var1];
            boolean var3 = false;
            int var4;
            if (var2.H == null) {
               var2.D -= -1463623301;
               if (-99363405 * var2.D >= (var2.I((byte)-38) ? -1500 : -10)) {
                  if (var2.B == 1 && var2.A == null) {
                     var2.A = GA.I(CCI.I, -320389285 * var2.C, 0);
                     if (var2.A == null) {
                        if (var0 >= 16385) {
                           throw new IllegalStateException();
                        }
                        continue;
                     }

                     var2.D += var2.A.Z() * -1463623301;
                  } else if (var2.I((byte)-25) && (var2.L == null || var2.G == null)) {
                     if (var2.L == null) {
                        var2.L = SG.I(HX.a, var2.C * -320389285);
                     }

                     if (var2.L == null) {
                        if (var0 >= 16385) {
                           throw new IllegalStateException();
                        }
                        continue;
                     }

                     if (var2.G == null) {
                        var2.G = var2.L.I(new int[]{22050});
                        if (var2.G == null) {
                           continue;
                        }
                     }
                  }

                  if (-99363405 * var2.D < 0) {
                     var4 = 8192;
                     int var5;
                     if (var2.F * 758600991 != 0) {
                        int var6 = var2.F * 758600991 >> 24 & 3;
                        if (var6 == UA.F.K) {
                           int var7 = (var2.F * 758600991 & 255) << 9;
                           int var8 = UA.F.S() << 8;
                           SF var9 = UA.F.I().I;
                           int var10 = var2.F * 758600991 >> 16 & 255;
                           int var11 = var8 + (256 + (var10 << 9) - (int)var9.I);
                           int var12 = 758600991 * var2.F >> 8 & 255;
                           int var13 = (var12 << 9) + 256 - (int)var9.Z + var8;
                           int var14 = Math.abs(var11) + Math.abs(var13) - 512;
                           if (var14 > var7) {
                              var2.D = 1265930907;
                              continue;
                           }

                           if (var14 < 0) {
                              var14 = 0;
                           }

                           var5 = (var7 - var14) * FW.J.n.I(-2145949986) * var2.E * -1716484165 / var7 >> 2;
                           if (-1 != var2.K * -1271617995) {
                              var10 = var2.K * -1271617995;
                              var12 = var2.Z * -1577764425;
                           }

                           if (var11 != 0 || var13 != 0) {
                              int var15 = -(-1847894591 * CZ.I) - (int)(Math.atan2((double)var11, (double)var13) * 2607.5945876176133D) - 4096 & 16383;
                              if (var15 > 8192) {
                                 var15 = 16384 - var15;
                              }

                              int var16;
                              if (var14 <= 0) {
                                 var16 = 8192;
                              } else if (var14 >= 4096) {
                                 var16 = 16384;
                              } else {
                                 var16 = 8192 + (8192 - var14) / 4096;
                              }

                              var4 = var15 * var16 / 8192 + (16384 - var16 >> 1);
                           }
                        } else {
                           var5 = 0;
                        }
                     } else {
                        var5 = var2.E * -1716484165 * (3 == var2.B ? FW.J.o.I(-2143768151) : FW.J.L.I(-2142178675)) >> 2;
                     }

                     if (var5 > 0) {
                        NG var19 = null;
                        if (1 == var2.B) {
                           var19 = var2.A.I().I(NA.F);
                        } else if (var2.I((byte)-17)) {
                           var19 = var2.G;
                        }

                        YE var20 = var2.H = YE.I(var19, var2.J * -447448059, var5, var4);
                        var20.B(var2.I * -581110023 - 1);
                        RA.S.I(var20);
                     }
                  }
               } else {
                  var3 = true;
               }
            } else if (!var2.H.Z(-629325116)) {
               var3 = true;
            }

            if (var3) {
               AN.E -= -598588595;

               for(var4 = var1; var4 < -991384187 * AN.E; ++var4) {
                  AN.G[var4] = AN.G[var4 + 1];
               }

               --var1;
            }
         }

         if (AN.D && !WBI.I(1966738730)) {
            if (FW.J.p.I(-2143085623) != 0 && AN.B * -1256171511 != -1) {
               if (BG.A != null) {
                  RD.I(ST.D, -1256171511 * AN.B, 0, FW.J.p.I(-2142931520), false, BG.A, 1987085103);
               } else {
                  YY.I(ST.D, AN.B * -1256171511, 0, FW.J.p.I(-2147082244), false, -2064254563);
               }
            }

            AN.D = false;
            BG.A = null;
         } else if (FW.J.p.I(-2142436770) != 0 && -1 != -1256171511 * AN.B && !WBI.I(1908541019)) {
            PK var18 = GB.I(MEI.l, XEI.eI.Z, (byte)26);
            var18.J.B(-1256171511 * AN.B, -1115837876);
            XEI.eI.I(var18, (byte)-48);
            AN.B = 184109511;
         }

      } catch (RuntimeException var17) {
         throw DQ.I(var17, "cg.x(" + ')');
      }
   }

   static void I(int var0) {
      try {
         if (XEI.YB * 577335585 < 0) {
            LZI var1 = NZ.I(-2096843583);
            if (!FX.G) {
               FX.D = FX.f * -1914913203 != -1 && FX.k * -278777595 >= -1914913203 * FX.f || (FX.c ? 26 : 22) + -278777595 * FX.k * FX.C * -411680299 > -1111710645 * JM.J;
            }

            FX.p.I((byte)1);
            FX.h.I((byte)1);

            int var3;
            for(YK var2 = (YK)FX.K.Z(1766612795); var2 != null; var2 = (YK)FX.K.B(49146)) {
               var3 = 946432351 * var2.N;
               if (var3 < 1000) {
                  var2.I(-1460969981);
                  if (59 != var3 && var3 != 2 && 8 != var3 && var3 != 17 && var3 != 15 && 16 != var3 && var3 != 58) {
                     FX.p.I((AE)var2, (int)281584970);
                  } else {
                     FX.h.I((AE)var2, (int)892677220);
                  }
               }
            }

            FX.p.I(FX.K, -72544370);
            FX.h.I(FX.K, -72544370);
            if (FX.k * -278777595 <= 1) {
               HM.L = null;
               FX.E = null;
               QO.I = null;
            } else {
               if (V.I((byte)41) && -278777595 * FX.k > 2) {
                  HM.L = (YK)FX.K.I.C.C;
               } else {
                  HM.L = (YK)FX.K.I.C;
               }

               FX.E = (YK)FX.K.I.C;
               if (-278777595 * FX.k > 2) {
                  QO.I = (YK)FX.E.C;
               } else {
                  QO.I = null;
               }
            }

            PM var12 = (PM)XEI.gC.Z(1766612795);
            int var4;
            if (var12 != null) {
               var3 = var12.method3547((byte)7);
               var4 = var12.method3560(-2068489909);
            } else {
               var3 = UC.Z.method3894((byte)-80);
               var4 = UC.Z.method3883((byte)-10);
            }

            boolean var14;
            if (FX.G) {
               int var6;
               int var7;
               if (ZB.I(PZ.B.B, var12, (byte)-119)) {
                  int var5;
                  YK var8;
                  TX var15;
                  if (FX.F != null && var3 >= EY.C * 805710735 && var3 <= 805710735 * EY.C + 2054409059 * HV.B && var4 >= GZI.I * -1370784315 && var4 <= GZI.I * -1370784315 + IU.J * -1855216229) {
                     var5 = -1;

                     for(var6 = 0; var6 < -628325139 * FX.F.G; ++var6) {
                        if (FX.c) {
                           var7 = var1.B * 1110385787 + -1370784315 * GZI.I + 20 + 1 + var6 * FX.C * -411680299;
                           if (var4 > var7 - var1.B * 1110385787 - 1 && var4 < -1883958527 * var1.I + var7) {
                              var5 = var6;
                           }
                        } else {
                           var7 = -1370784315 * GZI.I + 31 + -411680299 * FX.C * var6;
                           if (var4 > var7 - 13 && var4 < var7 + 3) {
                              var5 = var6;
                           }
                        }
                     }

                     if (-1 != var5) {
                        var6 = 0;
                        var15 = new TX(FX.F.H);

                        for(var8 = (YK)var15.I((short)15399); var8 != null; var8 = (YK)var15.next()) {
                           if (var5 == var6) {
                              AEI.I(var8, var3, var4, (short)916);
                              break;
                           }

                           ++var6;
                        }
                     }

                     ID.I(2025307040);
                  } else if (var3 >= QFI.I * -1347746885 && var3 <= 608683427 * ZZ.H + QFI.I * -1347746885 && var4 >= PN.E * 1089948687 && var4 <= UX.I * 1396607435 + PN.E * 1089948687) {
                     if (!FX.D) {
                        var5 = -1;

                        for(var6 = 0; var6 < -278777595 * FX.k; ++var6) {
                           if (FX.c) {
                              var7 = FX.C * -411680299 * (-278777595 * FX.k - 1 - var6) + 1 + var1.B * 1110385787 + 20 + PN.E * 1089948687;
                              if (var4 > var7 - var1.B * 1110385787 - 1 && var4 < -1883958527 * var1.I + var7) {
                                 var5 = var6;
                              }
                           } else {
                              var7 = -411680299 * FX.C * (FX.k * -278777595 - 1 - var6) + PN.E * 1089948687 + 31;
                              if (var4 > var7 - 13 && var4 < var7 + 3) {
                                 var5 = var6;
                              }
                           }
                        }

                        if (-1 != var5) {
                           var6 = 0;
                           RX var13 = new RX(FX.K);

                           for(var8 = (YK)var13.I(1073452729); var8 != null; var8 = (YK)var13.next()) {
                              if (var6 == var5) {
                                 AEI.I(var8, var3, var4, (short)916);
                                 break;
                              }

                              ++var6;
                           }
                        }

                        ID.I(2025307040);
                     } else {
                        var5 = -1;

                        for(var6 = 0; var6 < 1592446965 * FX.H; ++var6) {
                           if (FX.c) {
                              var7 = FX.C * -411680299 * var6 + 1 + 20 + PN.E * 1089948687 + var1.B * 1110385787;
                              if (var4 > var7 - 1110385787 * var1.B - 1 && var4 < var1.I * -1883958527 + var7) {
                                 var5 = var6;
                                 break;
                              }
                           } else {
                              var7 = FX.C * -411680299 * var6 + 1089948687 * PN.E + 31;
                              if (var4 > var7 - 13 && var4 < var7 + 3) {
                                 var5 = var6;
                                 break;
                              }
                           }
                        }

                        if (-1 != var5) {
                           var6 = 0;
                           var15 = new TX(FX.M);

                           for(EL var16 = (EL)var15.I((short)6300); var16 != null; var16 = (EL)var15.next()) {
                              if (var6 == var5) {
                                 AEI.I((YK)var16.H.I.S, var3, var4, (short)916);
                                 ID.I(2025307040);
                                 break;
                              }

                              ++var6;
                           }
                        }
                     }
                  }
               } else {
                  var14 = false;
                  if (FX.F != null) {
                     if (var3 >= EY.C * 805710735 - 10 && var3 <= 10 + HV.B * 2054409059 + EY.C * 805710735 && var4 >= -1370784315 * GZI.I - 10 && var4 <= 10 + IU.J * -1855216229 + GZI.I * -1370784315) {
                        var14 = true;
                     } else {
                        ZB.I(1952497590);
                     }
                  }

                  if (!var14) {
                     if (var3 >= -1347746885 * QFI.I - 10 && var3 <= 10 + QFI.I * -1347746885 + ZZ.H * 608683427 && var4 >= PN.E * 1089948687 - 10 && var4 <= 1396607435 * UX.I + 1089948687 * PN.E + 10) {
                        if (FX.D) {
                           var6 = -1;
                           var7 = -1;

                           int var18;
                           for(var18 = 0; var18 < 1592446965 * FX.H; ++var18) {
                              int var9;
                              if (FX.c) {
                                 var9 = 20 + PN.E * 1089948687 + 1110385787 * var1.B + 1 + var18 * -411680299 * FX.C;
                                 if (var4 > var9 - 1110385787 * var1.B - 1 && var4 < var1.I * -1883958527 + var9) {
                                    var6 = var18;
                                    var7 = var9 - var1.B * 1110385787 - 1;
                                    break;
                                 }
                              } else {
                                 var9 = 31 + PN.E * 1089948687 + FX.C * -411680299 * var18;
                                 if (var4 > var9 - 13 && var4 < var9 + 3) {
                                    var6 = var18;
                                    var7 = var9 - 13;
                                    break;
                                 }
                              }
                           }

                           if (var6 != -1) {
                              var18 = 0;
                              TX var17 = new TX(FX.M);

                              for(EL var10 = (EL)var17.I((short)26353); var10 != null; var10 = (EL)var17.next()) {
                                 if (var6 == var18) {
                                    if (var10.G * -628325139 > 1) {
                                       PL.I(var10, var7, 967296483);
                                    }
                                    break;
                                 }

                                 ++var18;
                              }
                           }
                        }
                     } else {
                        ID.I(2025307040);
                     }
                  }
               }
            } else {
               var14 = ZB.I(PZ.B.D, var12, (byte)-110);
               boolean var19 = ZB.I(PZ.B.I, var12, (byte)-117);
               boolean var20 = ZB.I(PZ.B.C, var12, (byte)-48);
               if ((var14 || var19) && (1 == 2089115297 * XEI.mC && -278777595 * FX.k > 2 || SBI.I(-1173724343))) {
                  var20 = true;
               }

               if (var20 && -278777595 * FX.k > 0) {
                  if (XEI.SB == null && XEI.UB * -651858367 == 0) {
                     L.I(var3, var4, (byte)28);
                  } else {
                     FX.A = -1808822290;
                  }
               } else if (var19) {
                  if (QO.I != null) {
                     AEI.I(QO.I, var3, var4, (short)916);
                  }
               } else if (var14) {
                  if (HM.L == null) {
                     if (XEI.rC) {
                        PZ.Z((byte)4);
                     }
                  } else {
                     boolean var21 = XEI.SB != null || XEI.UB * -651858367 > 0;
                     if (var21) {
                        FX.A = 1243072503;
                        ZV.A = HM.L;
                     } else {
                        AEI.I(HM.L, var3, var4, (short)916);
                     }
                  }
               }

               if (XEI.SB == null && XEI.UB * -651858367 == 0) {
                  FX.A = 0;
                  ZV.A = null;
               }
            }
         }

      } catch (RuntimeException var11) {
         throw DQ.I(var11, "cg.d(" + ')');
      }
   }

   public static void I(HSI[] var0, int var1) {
      try {
         for(int var2 = 0; var2 < var0.length; ++var2) {
            HSI var3 = var0[var2];
            if (var3.YZ != null) {
               KM var4 = new KM();
               var4.A = var3;
               var4.L = var3.YZ;
               LD.I(var4, 2000000, (short)3156);
            }
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "cg.i(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         int var2 = var0.X[1883543357 * var0.i];
         var0.J -= -783761378;
         int var3 = var0.H[var0.J * 681479919];
         if (var3 >= 0 && var3 < var0.B[var2]) {
            var0.F[var2][var3] = var0.H[681479919 * var0.J + 1];
         } else {
            throw new RuntimeException();
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "cg.ar(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, int var3) {
      try {
         int var4 = var2.H[(var2.J -= -391880689) * 681479919];
         int var5 = var2.H[(var2.J -= -391880689) * 681479919];
         if (var5 >= 1 && var5 <= 10) {
            var0.I(var5 - 1, var4, (byte)17);
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "cg.jl(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         var0.H[(var0.J += -391880689) * 681479919 - 1] = 457937409 * var3.o;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "cg.ow(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var3.m * 1573706803;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "cg.oi(" + ')');
      }
   }

   public static boolean I(int var0, int var1) {
      try {
         return var0 == 0 || 2 == var0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "cg.p(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         SEI var3 = JH.R.I(var2);
         int var4;
         if (var3.JI) {
            var4 = var3.x * 292187293;
         } else if (var3.b) {
            var4 = PZ.B.Z * 1295181471;
         } else {
            var4 = 363537303 * PZ.B.A;
         }

         var0.H[(var0.J += -391880689) * 681479919 - 1] = var4;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "cg.abc(" + ')');
      }
   }

   static final void B(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         LY.I(var3, var4, var0, -735997058);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "cg.lp(" + ')');
      }
   }

   static final void D(OU var0, int var1) {
      try {
         String var2 = (String)var0.S[(var0.A -= 969361751) * -203050393];
         CJI.I(var2, -1578243547);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "cg.agu(" + ')');
      }
   }
}
