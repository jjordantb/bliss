import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.URL;
import java.util.Iterator;

public class AY implements Iterator {
   JX B;
   AE J;
   int LOBBY_IP;
   AE VERSION = null;

   public boolean hasNext() {
      try {
         if (this.B.I[1772241843 * this.LOBBY_IP - 1] != this.J) {
            return true;
         } else {
            while(this.LOBBY_IP * 1772241843 < 577108745 * this.B.Z) {
               if (this.B.I[(this.LOBBY_IP += -317185157) * 1772241843 - 1].I != this.B.I[this.LOBBY_IP * 1772241843 - 1]) {
                  this.J = this.B.I[this.LOBBY_IP * 1772241843 - 1].I;
                  return true;
               }

               this.J = this.B.I[1772241843 * this.LOBBY_IP - 1];
            }

            return false;
         }
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "sy.hasNext(" + ')');
      }
   }

   void B(int var1) {
      try {
         this.J = this.B.I[0].I;
         this.LOBBY_IP = -317185157;
         this.VERSION = null;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sy.d(" + ')');
      }
   }

   public AY(JX var1) {
      this.B = var1;
      this.B(-751580615);
   }

   public void remove() {
      try {
         if (this.VERSION == null) {
            throw new IllegalStateException();
         } else {
            this.VERSION.I(-1460969981);
            this.VERSION = null;
         }
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "sy.remove(" + ')');
      }
   }

   public Object next() {
      try {
         AE var1;
         if (this.B.I[this.LOBBY_IP * 1772241843 - 1] != this.J) {
            var1 = this.J;
            this.J = var1.I;
            this.VERSION = var1;
            return var1;
         } else {
            while(this.LOBBY_IP * 1772241843 < 577108745 * this.B.Z) {
               var1 = this.B.I[(this.LOBBY_IP += -317185157) * 1772241843 - 1].I;
               if (var1 != this.B.I[this.LOBBY_IP * 1772241843 - 1]) {
                  this.J = var1.I;
                  this.VERSION = var1;
                  return var1;
               }
            }

            return null;
         }
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "sy.next(" + ')');
      }
   }

   public AE I(int var1) {
      try {
         this.B(-751580615);
         return (AE)this.next();
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "sy.u(" + ')');
      }
   }

   static final void I(byte var0) {
      try {
         if (1 != TQ.U * -707576455 && 100 != TQ.U * -707576455) {
            try {
               short var1;
               if (1820934059 * TQ.b == 0) {
                  var1 = 250;
               } else {
                  var1 = 2000;
               }

               if (TQ.H && TQ.U * -707576455 >= 62) {
                  var1 = 6000;
               }

               if (-122629167 * TQ.Z != 264 || 203 != TQ.U * -707576455 && 42 != -1372893999 * TQ.B) {
                  TQ.Y += -975705897;
               }

               if (-1937798425 * TQ.Y > var1) {
                  TQ.d.I((byte)57);
                  if (TQ.b * 1820934059 >= 3) {
                     TQ.U = -395862839;
                     ADI.I(-5, 1141860334);
                     return;
                  }

                  if (264 == TQ.Z * -122629167) {
                     VY.E.Z(-281677177);
                  } else {
                     EJ.I.Z(-213625938);
                  }

                  TQ.Y = 0;
                  TQ.b += -72367357;
                  TQ.U = -455386772;
               }

               PK var2;
               int var3;
               int var5;
               if (12 == TQ.U * -707576455) {
                  if (264 == -122629167 * TQ.Z) {
                     TQ.d.I(TS.I(VY.E.I(295506052), 15000, -649048480), VY.E.I, (byte)0);
                  } else {
                     TQ.d.I(TS.I(KSI.I((String)Loader.LOBBY_IP, (int)43594), 15000, -649048480), EJ.I.I, (byte)0);
                  }

                  TQ.d.I((short)8191);
                  var2 = EFI.C(-1825045529);
                  if (TQ.H) {
                     var2.J.F(UD.F.G * -1813470547);
                     var2.J.Z(0, 16711935);
                     var3 = 385051775 * var2.J.A;
                     var2.J.B(718, -1354427278);
                     if (Loader.VERSION != -1) {
                        var2.J.B(Loader.VERSION, 376398822);
                     }

                     if (-122629167 * TQ.Z == 264) {
                        var2.J.F(5 == XEI.QZ * -1233866115 ? 1 : 0);
                     }

                     REI var4 = XO.I(-1454924768);
                     var4.F(2084404473 * TQ.D);
                     var4.Z((int)(Math.random() * 9.9999999E7D), 16711935);
                     var4.F(WO.U.method242(694163818));
                     var4.B(XEI.v * -1154804873, -1393012818);

                     for(var5 = 0; var5 < 6; ++var5) {
                        var4.B((int)(Math.random() * 9.9999999E7D), 499420945);
                     }

                     var4.Z(XEI.FI * -8380697455384249973L);
                     var4.F(-937307905 * XEI.mD.S);
                     var4.F((int)(Math.random() * 9.9999999E7D));
                     var4.I(AZI.I, AZI.B, 1533826109);
                     var2.J.I(var4.S, 0, 385051775 * var4.A, (short)-29754);
                     var2.J.F(385051775 * var2.J.A - var3, 1585504133);
                  } else {
                     var2.J.F(-1813470547 * UD.A.G);
                  }

                  TQ.d.I(var2, (byte)-57);
                  TQ.d.Z(-1781606732);
                  TQ.U = 1009016718;
               }

               int var18;
               if (TQ.U * -707576455 == 30) {
                  if (!TQ.d.C(537308016).isAvailable(1, (byte)-19)) {
                     return;
                  }

                  TQ.d.C(537308016).readBytes(TQ.d.C.S, 0, 1, (byte)75);
                  var18 = TQ.d.C.S[0] & 255;
                  if (var18 != 0) {
                     TQ.U = -395862839;
                     ADI.I(var18, 352942199);
                     TQ.d.I((byte)110);
                     FSI.I(1976641602);
                     return;
                  }

                  if (TQ.H) {
                     TQ.U = -238095732;
                  } else {
                     TQ.U = 1898985570;
                  }
               }

               if (-707576455 * TQ.U == 44) {
                  if (!TQ.d.C(537308016).isAvailable(2, (byte)-17)) {
                     return;
                  }

                  TQ.d.C(537308016).readBytes(TQ.d.C.S, 0, 2, (byte)-39);
                  TQ.d.C.A = 0;
                  TQ.d.C.A = TQ.d.C.C() * 116413311;
                  TQ.U = -1485208182;
               }

               if (TQ.U * -707576455 == 58) {
                  if (!TQ.d.C(537308016).isAvailable(385051775 * TQ.d.C.A, (byte)6)) {
                     return;
                  }

                  TQ.d.C(537308016).readBytes(TQ.d.C.S, 0, 385051775 * TQ.d.C.A, (byte)33);
                  TQ.d.C.I(TQ.M, 642509947);
                  TQ.d.C.A = 0;
                  String var19 = TQ.d.C.T(681479919);
                  TQ.d.C.A = 0;
                  String var20 = VD.A.I(-1670386026);
                  if (!XEI.R || !NBI.I(var19, 1, var20, -2049749087)) {
                     FA.I(var19, true, FW.J.d.I(-671601354) == 5, var20, XEI.WB, XEI.e, -1487322449);
                  }

                  TQ.U = 1226307758;
               }

               if (TQ.U * -707576455 == 62) {
                  if (!TQ.d.C(537308016).isAvailable(1, (byte)73)) {
                     return;
                  }

                  TQ.d.C(537308016).readBytes(TQ.d.C.S, 0, 1, (byte)68);
                  if ((TQ.d.C.S[0] & 255) == 1) {
                     TQ.U = 1562646664;
                  }
               }

               if (TQ.U * -707576455 == 72) {
                  if (!TQ.d.C(537308016).isAvailable(16, (byte)-100)) {
                     return;
                  }

                  TQ.d.C(537308016).readBytes(TQ.d.C.S, 0, 16, (byte)59);
                  TQ.d.C.A = 1862612976;
                  TQ.d.C.I(TQ.M, 642509947);
                  TQ.d.C.A = 0;
                  TQ.F = TQ.d.C.I((short)27770) * -2742373017286080113L;
                  TQ.g = TQ.d.C.I((short)10381) * 3207425516430892907L;
                  TQ.U = 1898985570;
               }

               QEI var21;
               if (-707576455 * TQ.U == 82) {
                  TQ.d.C.A = 0;
                  TQ.d.I((short)8191);
                  var2 = EFI.C(-1133801446);
                  var21 = var2.J;
                  int var6;
                  REI var7;
                  UD var22;
                  if (264 == -122629167 * TQ.Z) {
                     if (TQ.H) {
                        var22 = UD.E;
                     } else {
                        var22 = UD.C;
                     }

                     var21.F(-1813470547 * var22.G);
                     var21.Z(0, 16711935);
                     var5 = 385051775 * var21.A;
                     var6 = 385051775 * var21.A;
                     if (!TQ.H) {
                        var21.B(718, 711122101);
                        if (Loader.VERSION != -1) {
                           var21.B(Loader.VERSION, 98092954);
                        }

                        var21.F(XEI.QZ * -1233866115 == 5 ? 1 : 0);
                        var6 = 385051775 * var21.A;
                        var7 = TJI.Z(-2133378997);
                        var21.I(var7.S, 0, var7.A * 385051775, (short)-31677);
                        var6 = var21.A * 385051775;
                        var21.F(TQ.F * 122690138525332847L == -1L ? 1 : 0);
                        if (TQ.F * 122690138525332847L == -1L) {
                           var21.I(TQ.W, 2140422151);
                        } else {
                           var21.Z(122690138525332847L * TQ.F);
                        }
                     }

                     var21.F(VB.I((byte)-90));
                     var21.Z(-2110394505 * GY.Z, 16711935);
                     var21.Z(JM.J * -1111710645, 16711935);
                     var21.F(FW.J.G.Z(-217929740));
                     C.I((REI)var21, (byte)1);
                     String[] var26 = WCI.Z();
                     var21.B(var26.length, -1);
                     String[] var11 = var26;
                     int var10 = var26.length;

                     for(int var9 = 0; var9 < var10; ++var9) {
                        String var8 = var11[var9];
                        var21.I(var8, -1);
                     }

                     String[] var27 = WCI.I();
                     var21.B(var27.length, -1);
                     String[] var12 = var27;
                     int var33 = var27.length;

                     for(var10 = 0; var10 < var33; ++var10) {
                        String var29 = var12[var10];
                        var21.I(var29, -1);
                     }

                     var21.I(XEI.XD, 2114152304);
                     var21.B(-1154804873 * XEI.v, -1572632938);
                     REI var30 = FW.J.C(-611972750);
                     var21.F(385051775 * var30.A);
                     var21.I(var30.S, 0, var30.A * 385051775, (short)-20549);
                     XEI.w = true;
                     if (Loader.usingRS) {
                        REI var32 = new REI(Y.B.C(-1431420237));
                        Y.B.I(var32, 652337983);
                        var21.I(var32.S, 0, var32.S.length, (short)-1355);
                     }

                     var21.B(XEI.hI * -2059460167, -1287558190);
                     var21.Z(XEI.b * -5648129435911399733L);
                     var21.F(XEI.j == null ? 0 : 1);
                     if (XEI.j != null) {
                        var21.I(XEI.j, 2119355084);
                     }

                     var21.F(MFI.D.Z("jagtheora", 1302159774) ? 1 : 0);
                     var21.F(XEI.R ? 1 : 0);
                     var21.F(XEI.IF ? 1 : 0);
                     var21.F(EQ.u * -180909151);
                     var21.B(1886068421 * XEI.h, 576248494);
                     var21.I(XEI.k, 2141094155);
                     var21.F(TT.B != null && 1606920449 * VY.E.B == TT.B.B * 1606920449 ? 0 : 1);
                     QII.I(var21, -956052447);
                     var21.I(TQ.M, var6, 385051775 * var21.A, 1729780581);
                     var21.F(385051775 * var21.A - var5, 1585504133);
                  } else {
                     if (TQ.H) {
                        var22 = UD.E;
                     } else {
                        var22 = UD.B;
                     }

                     var21.F(-1813470547 * var22.G);
                     var21.Z(0, 16711935);
                     var5 = 385051775 * var21.A;
                     var6 = 385051775 * var21.A;
                     if (!TQ.H) {
                        var21.B(718, -452164382);
                        if (Loader.VERSION != -1) {
                           var21.B(Loader.VERSION, 317411115);
                        }

                        var7 = TJI.Z(-1358767373);
                        var21.I(var7.S, 0, var7.A * 385051775, (short)-22572);
                        var6 = var21.A * 385051775;
                        var21.F(122690138525332847L * TQ.F == -1L ? 1 : 0);
                        if (-1L == 122690138525332847L * TQ.F) {
                           var21.I(TQ.W, 2126472832);
                        } else {
                           var21.Z(122690138525332847L * TQ.F);
                        }
                     }

                     var21.F(-937307905 * XEI.mD.S);
                     var21.F(WO.U.method242(694163818));
                     C.I((REI)var21, (byte)1);
                     var21.I(XEI.XD, 2107324025);
                     var7 = FW.J.C(-1517637513);
                     var21.F(var7.A * 385051775);
                     var21.I(var7.S, 0, var7.A * 385051775, (short)-4570);
                     REI var28 = new REI(Y.B.C(-1431420237));
                     Y.B.I(var28, 1834978848);
                     var21.I(var28.S, 0, var28.S.length, (short)-14969);
                     var21.B(-1154804873 * XEI.v, 142980326);
                     var21.B(XEI.h * 1886068421, -840792899);
                     var21.I(XEI.k, 2126130218);
                     QII.I(var21, -535015918);
                     byte[] var31 = NetworkInterface.getByInetAddress(InetAddress.getLocalHost()).getHardwareAddress();
                     var21.F(var31.length);
                     var21.I(var31, 0, var31.length, (short)-20549);
                     var21.I(TQ.M, var6, 385051775 * var21.A, -1390268287);
                     var21.F(385051775 * var21.A - var5, 1585504133);
                  }

                  TQ.d.I(var2, (byte)-65);
                  TQ.d.Z(-1062695636);
                  TQ.d.Z = new JEI(TQ.M);

                  for(int var24 = 0; var24 < 4; ++var24) {
                     TQ.M[var24] += 50;
                  }

                  TQ.d.B = new JEI(TQ.M);
                  new JEI(TQ.M);
                  TQ.d.C.I(TQ.d.B, (byte)80);
                  TQ.M = null;
                  TQ.U = 1443598798;
               }

               if (94 == -707576455 * TQ.U) {
                  if (!TQ.d.C(537308016).isAvailable(1, (byte)-69)) {
                     return;
                  }

                  TQ.d.C(537308016).readBytes(TQ.d.C.S, 0, 1, (byte)-72);
                  var18 = TQ.d.C.S[0] & 255;
                  if (21 == var18) {
                     TQ.U = 2056752677;
                  } else if (29 != var18 && 45 != var18) {
                     if (var18 == 1) {
                        TQ.U = -931578236;
                        ADI.I(var18, 1486771183);
                        return;
                     }

                     if (var18 == 2) {
                        TQ.U = 1601365905;
                     } else {
                        if (15 != var18) {
                           if (var18 == 23 && 1820934059 * TQ.b < 3) {
                              TQ.Y = 0;
                              TQ.b += -72367357;
                              TQ.U = -455386772;
                              TQ.d.I((byte)93);
                              return;
                           } else if (var18 == 42) {
                              TQ.U = 1244222307;
                              ADI.I(var18, 1924139793);
                              return;
                           } else {
                              if (TQ.C && !TQ.H && -1 != 2084404473 * TQ.D && 35 == var18) {
                                 TQ.H = true;
                                 TQ.Y = 0;
                                 TQ.U = -455386772;
                                 TQ.d.I((byte)93);
                              } else {
                                 TQ.U = -395862839;
                                 ADI.I(var18, 1778518954);
                                 TQ.d.I((byte)124);
                                 FSI.I(1976641602);
                              }

                              return;
                           }
                        }

                        TQ.d.F = -1763582762;
                        TQ.U = 907883401;
                     }
                  } else {
                     BD.I = 974522705 * var18;
                     TQ.U = -616044022;
                  }
               }

               if (TQ.U * -707576455 == 117) {
                  TQ.d.I((short)8191);
                  var2 = EFI.C(-1106381844);
                  var21 = var2.J;
                  var21.I(TQ.d.Z, (byte)41);
                  var21.Z(-1813470547 * UD.H.G, (byte)1);
                  TQ.d.I(var2, (byte)-122);
                  TQ.d.Z(-1208418920);
                  TQ.U = 1443598798;
               } else if (125 == TQ.U * -707576455) {
                  if (TQ.d.C(537308016).isAvailable(1, (byte)48)) {
                     TQ.d.C(537308016).readBytes(TQ.d.C.S, 0, 1, (byte)-14);
                     var18 = TQ.d.C.S[0] & 255;
                     TQ.s = var18 * -1954130922;
                     TQ.U = -395862839;
                     ADI.I(21, 779029063);
                     TQ.d.I((byte)10);
                     FSI.I(1976641602);
                  }
               } else if (-707576455 * TQ.U == 203) {
                  if (TQ.d.C(537308016).isAvailable(2, (byte)92)) {
                     TQ.d.C(537308016).readBytes(TQ.d.C.S, 0, 2, (byte)31);
                     TQ.I = (((TQ.d.C.S[0] & 255) << 8) + (TQ.d.C.S[1] & 255)) * -1156978587;
                     TQ.U = 1443598798;
                  }
               } else if (-707576455 * TQ.U == 186) {
                  if (29 == BD.I * 1892081585) {
                     if (!TQ.d.C(537308016).isAvailable(1, (byte)78)) {
                        return;
                     }

                     TQ.d.C(537308016).readBytes(TQ.d.C.S, 0, 1, (byte)-63);
                     TQ.e = 1200969765 * (TQ.d.C.S[0] & 255);
                  } else {
                     if (BD.I * 1892081585 != 45) {
                        throw new IllegalStateException();
                     }

                     if (!TQ.d.C(537308016).isAvailable(3, (byte)-85)) {
                        return;
                     }

                     TQ.d.C(537308016).readBytes(TQ.d.C.S, 0, 3, (byte)-63);
                     TQ.e = 1200969765 * (TQ.d.C.S[0] & 255);
                     TQ.a = 1719895145 * ((TQ.d.C.S[2] & 255) + ((TQ.d.C.S[1] & 255) << 8));
                  }

                  TQ.U = -395862839;
                  ADI.I(1892081585 * BD.I, -28417078);
                  TQ.d.I((byte)7);
                  FSI.I(1976641602);
               } else if (137 == TQ.U * -707576455) {
                  if (TQ.d.C(537308016).isAvailable(1, (byte)-1)) {
                     TQ.d.C(537308016).readBytes(TQ.d.C.S, 0, 1, (byte)-34);
                     TQ.z = 1962471985 * (TQ.d.C.S[0] & 255);
                     TQ.U = 1541841972;
                  }
               } else {
                  QEI var23;
                  if (-707576455 * TQ.U == 148) {
                     var23 = TQ.d.C;
                     if (264 == TQ.Z * -122629167) {
                        if (!TQ.d.C(537308016).isAvailable(-1359010095 * TQ.z, (byte)68)) {
                           return;
                        }

                        TQ.d.C(537308016).readBytes(var23.S, 0, TQ.z * -1359010095, (byte)13);
                        var23.A = 0;
                        XEI.QC = var23.I() * 1835619115;
                        XEI.bD = var23.I() * -418443653;
                        XEI.TC = var23.I() == 1;
                        XEI.UC = var23.I() == 1;
                        XEI.VC = var23.I() == 1;
                        XEI.HC = var23.I() == 1;
                        XEI.i = var23.C() * 1448461709;
                        XEI.OC = var23.I() == 1;
                        SM.m = var23.S((byte)-39) * 777394511;
                        XEI.oZ = var23.I() == 1;
                        P.Z = var23.E(-796084606);
                        XEI.mI.E(-1352577967).I(XEI.oZ, 915103443);
                        KBI.F.I((short)206).E(-884206015).I(XEI.oZ, 915103443);
                        JH.R.I(XEI.oZ, 798055588);
                        WZ.q.I(XEI.oZ, (byte)-2);
                     } else {
                        if (!TQ.d.C(537308016).isAvailable(TQ.z * -1359010095, (byte)-27)) {
                           return;
                        }

                        TQ.d.C(537308016).readBytes(var23.S, 0, TQ.z * -1359010095, (byte)29);
                        var23.A = 0;
                        XEI.QC = var23.I() * 1835619115;
                        XEI.bD = var23.I() * -418443653;
                        XEI.TC = var23.I() == 1;
                        SM.m = var23.S((byte)-98) * 777394511;
                        UA.F.AZ = (byte)var23.I();
                        XEI.UC = var23.I() == 1;
                        XEI.VC = var23.I() == 1;
                        QJ.M = var23.I((short)9875) * 9182695496232067233L;
                        OK.S = (-536549149186981023L * QJ.M - CI.I((byte)1) - var23.C((byte)74)) * -7894334964002250373L;
                        var3 = var23.I();
                        XEI.OC = (var3 & 1) != 0;
                        RZI.D = (var3 & 2) != 0;
                        QT.Z = var23.H((byte)99) * -1704395451;
                        ACI.D = var23.I() == 1;
                        B.VZ = var23.H((byte)-9) * -442700441;
                        OBI.I = var23.C() * -1652734029;
                        MEI.CZ = var23.C() * 808373911;
                        AE.B = var23.C() * -591256495;
                        AE.D = var23.H((byte)39) * -1316190437;
                        XJ.J = new SCI(AE.D * 2071493395);
                        (new Thread(XJ.J)).start();
                        IJI.J = var23.I() * 1240622393;
                        PII.Z = var23.C() * 556974909;
                        OCI.C = var23.C() * 580840459;
                        RU.I = var23.I() == 1;
                        UA.F.kI = UA.F.nI = RuntimeException_Sub2.aString6305 = var23.T(681479919);
                        IJI.S = var23.I() * 821936487;
                        JF.B = var23.H((byte)-28) * 2029589759;
                        XEI.X = var23.I() == 1;
                        TT.B = new KSI();
                        TT.B.B = var23.C() * 348739329;
                        if (65535 == 1606920449 * TT.B.B) {
                           TT.B.B = -348739329;
                        }

                        TT.B.I = var23.T(681479919);
                        if (AEI.J != GJ.I) {
                           TT.B.Z = TT.B.B * -1670427267 + 815680320;
                           TT.B.C = -52655920 + TT.B.B * 925746937;
                        }

                        if (GJ.I != AEI.I && (GJ.I != AEI.C || 1806357379 * XEI.QC < 2) && VY.E.I(VY.J, 2123928060)) {
                           NT.I(-1667448332);
                        }
                     }

                     if ((!XEI.TC || XEI.VC) && !XEI.OC) {
                        try {
                           MY.I(DSI.C, "unzap", (short)10429);
                        } catch (Throwable var13) {
                           ;
                        }
                     } else {
                        try {
                           MY.I(DSI.C, "zap", (short)11786);
                        } catch (Throwable var15) {
                           if (XEI.W) {
                              try {
                                 DSI.C.getAppletContext().showDocument(new URL(DSI.C.getCodeBase(), "blank.ws"), "tbi");
                              } catch (Exception var14) {
                                 ;
                              }
                           }
                        }
                     }

                     if (AEI.J == GJ.I) {
                        VD.Z.Z(-1392768715);
                     }

                     if (264 != TQ.Z * -122629167) {
                        TQ.U = -395862839;
                        ADI.I(2, 1533583535);
                        KEI.J(-954161588);
                        HX.I(14, 1153867870);
                        TQ.d.D = null;
                        return;
                     }

                     TQ.U = -101133317;
                  }

                  if (-707576455 * TQ.U == 163) {
                     if (!TQ.d.C(537308016).isAvailable(3, (byte)75)) {
                        return;
                     }

                     TQ.d.C(537308016).readBytes(TQ.d.C.S, 0, 3, (byte)-16);
                     TQ.U = -952382928;
                  }

                  if (-707576455 * TQ.U == 176) {
                     var23 = TQ.d.C;
                     var23.A = 0;
                     if (var23.I((byte)-27)) {
                        if (!TQ.d.C(537308016).isAvailable(1, (byte)-10)) {
                           return;
                        }

                        TQ.d.C(537308016).readBytes(var23.S, 3, 1, (byte)-25);
                     }

                     TQ.d.D = RZI.C(-1456212765)[var23.B(250607366)];
                     TQ.d.F = var23.C() * -1265692267;
                     TQ.U = 1878180878;
                  }

                  if (158 == -707576455 * TQ.U) {
                     if (TQ.d.C(537308016).isAvailable(-866602563 * TQ.d.F, (byte)-22)) {
                        TQ.d.C(537308016).readBytes(TQ.d.C.S, 0, -866602563 * TQ.d.F, (byte)29);
                        TQ.d.C.A = 0;
                        var18 = TQ.d.F * -866602563;
                        TQ.U = -395862839;
                        ADI.I(2, 1250429131);
                        ZV.I(-2092028687);
                        QZI.I(TQ.d.C, 837096225);
                        var3 = var18 - TQ.d.C.A * 385051775;
                        QEI var25 = new QEI(var3);
                        System.arraycopy(TQ.d.C.S, TQ.d.C.A * 385051775, var25.S, 0, var3);
                        TQ.d.C.A += var3 * 116413311;
                        if (TQ.d.D == MSI.nZ) {
                           XEI.mI.I(new XS(WS.S, var25), -1991819579);
                        } else {
                           XEI.mI.I(new XS(WS.C, var25), -1991819579);
                        }

                        if (var18 != TQ.d.C.A * 385051775) {
                           throw new RuntimeException(385051775 * TQ.d.C.A + " " + var18);
                        }

                        TQ.d.D = null;
                     }
                  } else if (193 == TQ.U * -707576455) {
                     if (-2 == -866602563 * TQ.d.F) {
                        if (!TQ.d.C(537308016).isAvailable(2, (byte)39)) {
                           return;
                        }

                        TQ.d.C(537308016).readBytes(TQ.d.C.S, 0, 2, (byte)9);
                        TQ.d.C.A = 0;
                        TQ.d.F = TQ.d.C.C() * -1265692267;
                     }

                     if (TQ.d.C(537308016).isAvailable(-866602563 * TQ.d.F, (byte)77)) {
                        TQ.d.C(537308016).readBytes(TQ.d.C.S, 0, TQ.d.F * -866602563, (byte)-73);
                        TQ.d.C.A = 0;
                        var18 = TQ.d.F * -866602563;
                        TQ.U = -395862839;
                        ADI.I(15, 380191322);
                        ZX.I(144926411);
                        QZI.I(TQ.d.C, 822397380);
                        if (385051775 * TQ.d.C.A != var18) {
                           throw new RuntimeException(TQ.d.C.A * 385051775 + " " + var18);
                        }

                        TQ.d.D = null;
                     }
                  }
               }
            } catch (IOException var16) {
               TQ.d.I((byte)40);
               if (1820934059 * TQ.b < 3) {
                  if (264 == -122629167 * TQ.Z) {
                     VY.E.Z(-1442409390);
                  } else {
                     EJ.I.Z(-734598763);
                  }

                  TQ.Y = 0;
                  TQ.b += -72367357;
                  TQ.U = -455386772;
               } else {
                  TQ.U = -395862839;
                  ADI.I(-4, 500556519);
                  FSI.I(1976641602);
               }
            }
         }

      } catch (RuntimeException var17) {
         throw DQ.I(var17, "sy.c(" + ')');
      }
   }

   static void I(boolean var0, boolean var1, String var2, String var3, long var4) {
      try {
         TQ.H = var0;
         if (!var1) {
            TQ.D = -2035975497;
         }

         TQ.C = var1;
         TQ.W = var2;
         TQ.X = var3;
         TQ.F = var4 * -2742373017286080113L;
         if (!TQ.C && (TQ.W.equals("") || TQ.X.equals(""))) {
            ADI.I(3, 418769263);
         } else {
            if (TQ.Z * -122629167 != 136) {
               TQ.s = 0;
               TQ.e = -1200969765;
               TQ.a = -1719895145;
            }

            TQ.d.M = false;
            ADI.I(-3, 1492625242);
            TQ.U = -455386772;
            TQ.Y = 0;
            TQ.b = 0;
         }

      } catch (RuntimeException var7) {
         throw DQ.I(var7, "sy.e(" + ')');
      }
   }
}
