public class DS {
   static int I;
   int append;
   int length;
   int[][] substring;
   static PL toString = new PL(0, 0);
   int Z = -2063162553;
   int C = 0;
   FY B = new FY();
   public boolean D = false;
   PL[] F;

   final void I(int var1) {
      try {
         for(int var2 = 0; var2 < this.length * -1845310689; ++var2) {
            this.substring[var2] = null;
         }

         this.F = null;
         this.substring = null;
         this.B.B(-1936025325);
         this.B = null;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "kt.a(" + ')');
      }
   }

   public final int[] I(int var1, int var2) {
      try {
         if (this.length * -1845310689 != this.append * 1036538653) {
            if (this.length * -1845310689 != 1) {
               PL var3 = this.F[var1];
               if (var3 == null) {
                  this.D = true;
                  if (this.C * 851327335 >= -1845310689 * this.length) {
                     PL var4 = (PL)this.B.I(975410288);
                     var3 = new PL(var1, var4.S * -1113693749);
                     this.F[1544880463 * var4.J] = null;
                     var4.I(-1460969981);
                  } else {
                     var3 = new PL(var1, this.C * 851327335);
                     this.C += -1189293481;
                  }

                  this.F[var1] = var3;
               } else {
                  this.D = false;
               }

               this.B.I((AE)var3, (int)943102582);
               return this.substring[-1113693749 * var3.S];
            } else {
               this.D = var1 != this.Z * -101586551;
               this.Z = var1 * 2063162553;
               return this.substring[0];
            }
         } else {
            this.D = this.F[var1] == null;
            this.F[var1] = toString;
            return this.substring[var1];
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "kt.f(" + ')');
      }
   }

   public final int[][] Z(int var1) {
      try {
         if (1036538653 * this.append != -1845310689 * this.length) {
            throw new RuntimeException();
         } else {
            for(int var2 = 0; var2 < -1845310689 * this.length; ++var2) {
               this.F[var2] = toString;
            }

            return this.substring;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "kt.b(" + ')');
      }
   }

   DS(int var1, int var2, int var3) {
      this.append = var2 * -1955264715;
      this.length = var1 * -1906511649;
      this.substring = new int[-1845310689 * this.length][var3];
      this.F = new PL[this.append * 1036538653];
   }

   static void I(OU var0, short var1) {
      try {
         var0.S[(var0.A += 969361751) * -203050393 - 1] = OO.I.I(var0.H[var0.J * 681479919 - 2], 245040087).O[var0.H[681479919 * var0.J - 1]];
         var0.J -= -783761378;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "kt.e(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, int var3) {
      try {
         String var4 = (String)var2.S[(var2.A -= 969361751) * -203050393];
         if (IN.I(var4, var2, -1163069607) != null) {
            var4 = var4.substring(0, var4.length() - 1);
         }

         var0.lZ = OI.I(var4, var2, -2046058202);
         var0.JZ = true;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "kt.ob(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         switch(var2) {
         case 1391:
            var2 = 13978;
            break;
         case 3420:
            var2 = 1101;
            break;
         case 8784:
            var2 = 29897;
            break;
         case 8786:
            var2 = 29898;
            break;
         case 8788:
            var2 = 29896;
            break;
         case 12183:
            var2 = 1607;
            break;
         case 15262:
            var2 = 11694;
            break;
         case 19709:
            var2 = 4091;
            break;
         case 20767:
            var2 = 29895;
         }

         SEI var3 = JH.R.I(var2);
         if (-1673957995 * var3.r >= 0 && 809765849 * var3.E >= 0) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = var3.E * 809765849;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = var2;
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "kt.aag(" + ')');
      }
   }

   static final void I(boolean var0, byte var1) {
      try {
         IJI.I(XEI.xC * -257444687, -2110394505 * GY.Z, JM.J * -1111710645, var0, 1828905535);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "kt.kg(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         WK var3 = ZN.C(-1164141102);
         if (var3 != null) {
            boolean var4 = var3.I(var2 >> 28 & 3, var2 >> 14 & 16383, var2 & 16383, YT.J, 1911692873);
            if (var4) {
               var0.H[(var0.J += -391880689) * 681479919 - 1] = YT.J[1];
               var0.H[(var0.J += -391880689) * 681479919 - 1] = YT.J[2];
            } else {
               var0.H[(var0.J += -391880689) * 681479919 - 1] = -1;
               var0.H[(var0.J += -391880689) * 681479919 - 1] = -1;
            }
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = -1;
            var0.H[(var0.J += -391880689) * 681479919 - 1] = -1;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "kt.aep(" + ')');
      }
   }
}
