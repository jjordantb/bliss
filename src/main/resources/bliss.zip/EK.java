import java.util.Random;

public class EK extends YG {
   int length = -692113744;
   static int substring = 0;
   int Q = -1263482416;
   static int R = 2000;
   static int T = 4096;
   int U = 0;
   int V = 0;
   static int W = 16;
   int X = 1324134400;
   static int Y = 0;

   void Z() {
      WJ.I((byte)-44);
   }

   int[] append(int var1) {
      int[] var2 = this.P.I(var1, 574201304);
      if (this.P.D) {
         int var3 = 1698072291 * this.X >> 1;
         int[][] var4 = this.P.Z(432902408);
         Random var5 = new Random((long)(this.U * -1552351361));

         for(int var6 = 0; var6 < -1197969353 * this.length; ++var6) {
            int var7 = this.X * 1698072291 > 0 ? -114289409 * this.V + (IG.I(var5, 1698072291 * this.X, (byte)-39) - var3) : -114289409 * this.V;
            var7 = var7 >> 4 & 255;
            int var8 = IG.I(var5, -1474554145 * WJ.C, (byte)18);
            int var9 = IG.I(var5, 461985445 * WJ.B, (byte)-39);
            int var10 = var8 + (this.Q * -1584670283 * WJ.E[var7] >> 12);
            int var11 = (-1584670283 * this.Q * WJ.S[var7] >> 12) + var9;
            int var12 = var11 - var9;
            int var13 = var10 - var8;
            if (var13 != 0 || var12 != 0) {
               if (var12 < 0) {
                  var12 = -var12;
               }

               if (var13 < 0) {
                  var13 = -var13;
               }

               boolean var14 = var12 > var13;
               int var15;
               int var16;
               if (var14) {
                  var15 = var8;
                  var16 = var10;
                  var8 = var9;
                  var9 = var15;
                  var10 = var11;
                  var11 = var16;
               }

               if (var8 > var10) {
                  var15 = var8;
                  var16 = var9;
                  var8 = var10;
                  var10 = var15;
                  var9 = var11;
                  var11 = var16;
               }

               var15 = var9;
               var16 = var10 - var8;
               int var17 = var11 - var9;
               int var18 = -var16 / 2;
               int var19 = 2048 / var16;
               int var20 = 1024 - (IG.I(var5, 4096, (byte)29) >> 2);
               int var21 = var9 < var11 ? 1 : -1;
               if (var17 < 0) {
                  var17 = -var17;
               }

               for(int var22 = var8; var22 < var10; ++var22) {
                  int var23 = 1024 + var20 + var19 * (var22 - var8);
                  int var24 = var22 & WJ.I * -901777799;
                  int var25 = var15 & -289063255 * WJ.F;
                  if (var14) {
                     var4[var25][var24] = var23;
                  } else {
                     var4[var24][var25] = var23;
                  }

                  var18 += var17;
                  if (var18 > 0) {
                     var18 -= var16;
                     var15 += var21;
                  }
               }
            }
         }
      }

      return var2;
   }

   void B(int var1) {
      try {
         WJ.I((byte)42);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "agl.x(" + ')');
      }
   }

   void length(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.U = var2.I() * 94814335;
         break;
      case 1:
         this.length = var2.C() * -23968377;
         break;
      case 2:
         this.Q = var2.I() * -1689580387;
         break;
      case 3:
         this.V = var2.C() * -132715777;
         break;
      case 4:
         this.X = var2.C() * 1425338059;
      }

   }

   int[] substring(int var1) {
      int[] var2 = this.P.I(var1, 1014530517);
      if (this.P.D) {
         int var3 = 1698072291 * this.X >> 1;
         int[][] var4 = this.P.Z(-125478280);
         Random var5 = new Random((long)(this.U * -1552351361));

         for(int var6 = 0; var6 < -1197969353 * this.length; ++var6) {
            int var7 = this.X * 1698072291 > 0 ? -114289409 * this.V + (IG.I(var5, 1698072291 * this.X, (byte)21) - var3) : -114289409 * this.V;
            var7 = var7 >> 4 & 255;
            int var8 = IG.I(var5, -1474554145 * WJ.C, (byte)-30);
            int var9 = IG.I(var5, 461985445 * WJ.B, (byte)-9);
            int var10 = var8 + (this.Q * -1584670283 * WJ.E[var7] >> 12);
            int var11 = (-1584670283 * this.Q * WJ.S[var7] >> 12) + var9;
            int var12 = var11 - var9;
            int var13 = var10 - var8;
            if (var13 != 0 || var12 != 0) {
               if (var12 < 0) {
                  var12 = -var12;
               }

               if (var13 < 0) {
                  var13 = -var13;
               }

               boolean var14 = var12 > var13;
               int var15;
               int var16;
               if (var14) {
                  var15 = var8;
                  var16 = var10;
                  var8 = var9;
                  var9 = var15;
                  var10 = var11;
                  var11 = var16;
               }

               if (var8 > var10) {
                  var15 = var8;
                  var16 = var9;
                  var8 = var10;
                  var10 = var15;
                  var9 = var11;
                  var11 = var16;
               }

               var15 = var9;
               var16 = var10 - var8;
               int var17 = var11 - var9;
               int var18 = -var16 / 2;
               int var19 = 2048 / var16;
               int var20 = 1024 - (IG.I(var5, 4096, (byte)-15) >> 2);
               int var21 = var9 < var11 ? 1 : -1;
               if (var17 < 0) {
                  var17 = -var17;
               }

               for(int var22 = var8; var22 < var10; ++var22) {
                  int var23 = 1024 + var20 + var19 * (var22 - var8);
                  int var24 = var22 & WJ.I * -901777799;
                  int var25 = var15 & -289063255 * WJ.F;
                  if (var14) {
                     var4[var25][var24] = var23;
                  } else {
                     var4[var24][var25] = var23;
                  }

                  var18 += var17;
                  if (var18 > 0) {
                     var18 -= var16;
                     var15 += var21;
                  }
               }
            }
         }
      }

      return var2;
   }

   void I(int var1, REI var2, byte var3) {
      try {
         switch(var1) {
         case 0:
            this.U = var2.I() * 94814335;
            break;
         case 1:
            this.length = var2.C() * -23968377;
            break;
         case 2:
            this.Q = var2.I() * -1689580387;
            break;
         case 3:
            this.V = var2.C() * -132715777;
            break;
         case 4:
            this.X = var2.C() * 1425338059;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "agl.r(" + ')');
      }
   }

   void append() {
      WJ.I((byte)41);
   }

   int[] Z(int var1, int var2) {
      try {
         int[] var3 = this.P.I(var1, 236039494);
         if (this.P.D) {
            int var4 = 1698072291 * this.X >> 1;
            int[][] var5 = this.P.Z(-1416653577);
            Random var6 = new Random((long)(this.U * -1552351361));

            for(int var7 = 0; var7 < -1197969353 * this.length; ++var7) {
               int var8 = this.X * 1698072291 > 0 ? -114289409 * this.V + (IG.I(var6, 1698072291 * this.X, (byte)24) - var4) : -114289409 * this.V;
               var8 = var8 >> 4 & 255;
               int var9 = IG.I(var6, -1474554145 * WJ.C, (byte)15);
               int var10 = IG.I(var6, 461985445 * WJ.B, (byte)76);
               int var11 = var9 + (this.Q * -1584670283 * WJ.E[var8] >> 12);
               int var12 = (-1584670283 * this.Q * WJ.S[var8] >> 12) + var10;
               int var13 = var12 - var10;
               int var14 = var11 - var9;
               if (var14 != 0 || var13 != 0) {
                  if (var13 < 0) {
                     var13 = -var13;
                  }

                  if (var14 < 0) {
                     var14 = -var14;
                  }

                  boolean var15 = var13 > var14;
                  int var16;
                  int var17;
                  if (var15) {
                     var16 = var9;
                     var17 = var11;
                     var9 = var10;
                     var10 = var16;
                     var11 = var12;
                     var12 = var17;
                  }

                  if (var9 > var11) {
                     var16 = var9;
                     var17 = var10;
                     var9 = var11;
                     var11 = var16;
                     var10 = var12;
                     var12 = var17;
                  }

                  var16 = var10;
                  var17 = var11 - var9;
                  int var18 = var12 - var10;
                  int var19 = -var17 / 2;
                  int var20 = 2048 / var17;
                  int var21 = 1024 - (IG.I(var6, 4096, (byte)-25) >> 2);
                  int var22 = var10 < var12 ? 1 : -1;
                  if (var18 < 0) {
                     var18 = -var18;
                  }

                  for(int var23 = var9; var23 < var11; ++var23) {
                     int var24 = 1024 + var21 + var20 * (var23 - var9);
                     int var25 = var23 & WJ.I * -901777799;
                     int var26 = var16 & -289063255 * WJ.F;
                     if (var15) {
                        var5[var26][var25] = var24;
                     } else {
                        var5[var25][var26] = var24;
                     }

                     var19 += var18;
                     if (var19 > 0) {
                        var19 -= var17;
                        var16 += var22;
                     }
                  }
               }
            }
         }

         return var3;
      } catch (RuntimeException var27) {
         throw DQ.I(var27, "agl.i(" + ')');
      }
   }

   void length() {
      WJ.I((byte)-70);
   }

   void substring(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.U = var2.I() * 94814335;
         break;
      case 1:
         this.length = var2.C() * -23968377;
         break;
      case 2:
         this.Q = var2.I() * -1689580387;
         break;
      case 3:
         this.V = var2.C() * -132715777;
         break;
      case 4:
         this.X = var2.C() * 1425338059;
      }

   }

   public EK() {
      super(0, true);
   }

   static final void I(HSI var0, X var1, OU var2, int var3) {
      try {
         String var4 = (String)var2.S[(var2.A -= 969361751) * -203050393];
         if (IN.I(var4, var2, -1433949674) != null) {
            var4 = var4.substring(0, var4.length() - 1);
         }

         var0.oZ = OI.I(var4, var2, -2046058202);
         var0.JZ = true;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "agl.nw(" + ')');
      }
   }
}
