public class D {
   byte[] append;
   int toString;
   public static OS I;

   D(byte[] var1) {
      this.append = var1;
      this.toString = 0;
   }

   String I(int var1) {
      try {
         int var2 = this.Z(1088012278);
         if (var2 == -1) {
            return null;
         } else if (var2 > 256) {
            throw new RuntimeException_Sub3();
         } else {
            String var3 = new String(this.append, this.toString * -999234057, var2);
            this.toString += var2 * -786863161;
            return var3;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ec.f(" + ')');
      }
   }

   int Z(int var1) {
      try {
         short var2 = 0;

         for(int var3 = 0; var3 < 2; ++var3) {
            var2 = (short)(var2 | (this.append[(this.toString += -786863161) * -999234057 - 1] & 255) << var3 * 8);
         }

         return var2;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ec.a(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         VD.C.Z(-1969463170);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ec.afe(" + ')');
      }
   }
}
