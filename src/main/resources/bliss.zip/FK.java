public class FK extends YG {
   int Q = 1210221109;

   int[] append(int var1) {
      int[] var2 = this.P.I(var1, -122231988);
      if (this.P.D) {
         int var3 = WJ.J[var1];

         for(int var4 = 0; var4 < WJ.C * -1474554145; ++var4) {
            int var5 = WJ.A[var4];
            int var6;
            if (var5 > -121339323 * this.Q && var5 < 4096 - -121339323 * this.Q && var3 > 2048 - this.Q * -121339323 && var3 < 2048 + this.Q * -121339323) {
               var6 = 2048 - var5;
               var6 = var6 < 0 ? -var6 : var6;
               var6 <<= 12;
               var6 /= 2048 - -121339323 * this.Q;
               var2[var4] = 4096 - var6;
            } else if (var5 > 2048 - -121339323 * this.Q && var5 < 2048 + this.Q * -121339323) {
               var6 = var3 - 2048;
               var6 = var6 < 0 ? -var6 : var6;
               var6 -= -121339323 * this.Q;
               var6 <<= 12;
               var2[var4] = var6 / (2048 - -121339323 * this.Q);
            } else if (var3 >= this.Q * -121339323 && var3 <= 4096 - this.Q * -121339323) {
               if (var5 >= this.Q * -121339323 && var5 <= 4096 - this.Q * -121339323) {
                  var2[var4] = 0;
               } else {
                  var6 = 2048 - var3;
                  var6 = var6 < 0 ? -var6 : var6;
                  var6 <<= 12;
                  var6 /= 2048 - this.Q * -121339323;
                  var2[var4] = 4096 - var6;
               }
            } else {
               var6 = var5 - 2048;
               var6 = var6 < 0 ? -var6 : var6;
               var6 -= this.Q * -121339323;
               var6 <<= 12;
               var2[var4] = var6 / (2048 - this.Q * -121339323);
            }
         }
      }

      return var2;
   }

   public FK() {
      super(0, true);
   }

   void I(int var1, REI var2, byte var3) {
      try {
         switch(var1) {
         case 0:
            this.Q = var2.C() * 2065121421;
         default:
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ahz.r(" + ')');
      }
   }

   int[] toString(int var1) {
      int[] var2 = this.P.I(var1, 1278925238);
      if (this.P.D) {
         int var3 = WJ.J[var1];

         for(int var4 = 0; var4 < WJ.C * -1474554145; ++var4) {
            int var5 = WJ.A[var4];
            int var6;
            if (var5 > -121339323 * this.Q && var5 < 4096 - -121339323 * this.Q && var3 > 2048 - this.Q * -121339323 && var3 < 2048 + this.Q * -121339323) {
               var6 = 2048 - var5;
               var6 = var6 < 0 ? -var6 : var6;
               var6 <<= 12;
               var6 /= 2048 - -121339323 * this.Q;
               var2[var4] = 4096 - var6;
            } else if (var5 > 2048 - -121339323 * this.Q && var5 < 2048 + this.Q * -121339323) {
               var6 = var3 - 2048;
               var6 = var6 < 0 ? -var6 : var6;
               var6 -= -121339323 * this.Q;
               var6 <<= 12;
               var2[var4] = var6 / (2048 - -121339323 * this.Q);
            } else if (var3 >= this.Q * -121339323 && var3 <= 4096 - this.Q * -121339323) {
               if (var5 >= this.Q * -121339323 && var5 <= 4096 - this.Q * -121339323) {
                  var2[var4] = 0;
               } else {
                  var6 = 2048 - var3;
                  var6 = var6 < 0 ? -var6 : var6;
                  var6 <<= 12;
                  var6 /= 2048 - this.Q * -121339323;
                  var2[var4] = 4096 - var6;
               }
            } else {
               var6 = var5 - 2048;
               var6 = var6 < 0 ? -var6 : var6;
               var6 -= this.Q * -121339323;
               var6 <<= 12;
               var2[var4] = var6 / (2048 - this.Q * -121339323);
            }
         }
      }

      return var2;
   }

   int[] Z(int var1, int var2) {
      try {
         int[] var3 = this.P.I(var1, 1728216367);
         if (this.P.D) {
            int var4 = WJ.J[var1];

            for(int var5 = 0; var5 < WJ.C * -1474554145; ++var5) {
               int var6 = WJ.A[var5];
               int var7;
               if (var6 > -121339323 * this.Q && var6 < 4096 - -121339323 * this.Q && var4 > 2048 - this.Q * -121339323 && var4 < 2048 + this.Q * -121339323) {
                  var7 = 2048 - var6;
                  var7 = var7 < 0 ? -var7 : var7;
                  var7 <<= 12;
                  var7 /= 2048 - -121339323 * this.Q;
                  var3[var5] = 4096 - var7;
               } else if (var6 > 2048 - -121339323 * this.Q && var6 < 2048 + this.Q * -121339323) {
                  var7 = var4 - 2048;
                  var7 = var7 < 0 ? -var7 : var7;
                  var7 -= -121339323 * this.Q;
                  var7 <<= 12;
                  var3[var5] = var7 / (2048 - -121339323 * this.Q);
               } else if (var4 >= this.Q * -121339323 && var4 <= 4096 - this.Q * -121339323) {
                  if (var6 >= this.Q * -121339323 && var6 <= 4096 - this.Q * -121339323) {
                     var3[var5] = 0;
                  } else {
                     var7 = 2048 - var4;
                     var7 = var7 < 0 ? -var7 : var7;
                     var7 <<= 12;
                     var7 /= 2048 - this.Q * -121339323;
                     var3[var5] = 4096 - var7;
                  }
               } else {
                  var7 = var6 - 2048;
                  var7 = var7 < 0 ? -var7 : var7;
                  var7 -= this.Q * -121339323;
                  var7 <<= 12;
                  var3[var5] = var7 / (2048 - this.Q * -121339323);
               }
            }
         }

         return var3;
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "ahz.i(" + ')');
      }
   }

   void Z(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.Q = var2.C() * 2065121421;
      default:
      }
   }

   void append(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.Q = var2.C() * 2065121421;
      default:
      }
   }
}
