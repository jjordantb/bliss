import jagtheora.ogg.OggPacket;
import jagtheora.ogg.OggStreamState;

public class GG extends AG {
   void method3078(OggPacket var1) {
   }

   void method3075(int var1) {
   }

   void method3074(OggPacket var1, int var2) {
   }

   void method3076(OggPacket var1) {
   }

   void method3077(OggPacket var1) {
   }

   GG(OggStreamState var1) {
      super(var1);
   }

   void method3072() {
   }

   void method3079() {
   }
}
