package jagdx;

public class S {
   private static int a = 2166;
   public static int f = 0;
   public static int b = -2005530520;
   public static int p = -2005530519;
   public static int i = 1;

   private S() throws Throwable {
      throw new Error();
   }

   public static final boolean a(int var0) {
      return var0 < 0;
   }

   public static final boolean f(int var0) {
      return var0 >= 0;
   }
}
