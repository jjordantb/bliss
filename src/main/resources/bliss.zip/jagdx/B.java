package jagdx;

import java.awt.Component;

public class B {
   public static int a = Integer.MIN_VALUE;
   public int I = 0;
   public int Z = 0;
   public int C = 0;
   public int B = 0;
   public int D = 0;
   public int F = 0;
   public int J = 1;
   public Component S;
   public boolean A;
   public boolean E;
   public int G = 0;
   public int H;
   public int K;
   public int L = Integer.MIN_VALUE;

   public B(Component var1) {
      this.S = var1;
   }
}
