package jagdx;

public class u extends RuntimeException {
   private u() throws Throwable {
      throw new Error();
   }
}
