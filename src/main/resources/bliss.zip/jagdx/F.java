package jagdx;

public class F {
   public int I;
   public int Z;
   public int C;
   public int B;
}
