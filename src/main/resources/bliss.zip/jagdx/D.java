package jagdx;

public class D {
   public int I;
   public int Z;
   public int C;
   public int B;
   public int D;
}
