package jagdx;

public class I {
   public String I;
   public String Z;
   public String C;
   public long B;
   public int D;
   public int F;
   public int J;
   public int S;
   public int A;
}
