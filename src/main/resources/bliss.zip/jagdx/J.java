package jagdx;

public class J extends IUnknown {
   J() throws Throwable {
      throw new Error();
   }
}
