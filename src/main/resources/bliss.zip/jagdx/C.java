package jagdx;

public class C {
   public int I;
   public int Z;
   public int C;
   public int B;
}
