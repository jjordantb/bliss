import java.util.zip.CRC32;

public class HJ extends GJ {
   JX append = new JX(16);
   QJ equals;
   byte[] getValue;
   int method2250;
   FP method2359;
   IL method3465;
   CS method3468;
   int reset = 0;
   FP toString;
   PF update;
   static byte B = 0;
   static byte D = 1;
   static byte F = -1;
   byte[] J;
   static int S = 1000;
   IY A;
   int E = 0;
   boolean G;
   int H;
   static int K = 0;
   IY L = new IY();
   boolean M;
   long N = 0L;
   int O;
   static int P = 250;
   static CRC32 Q = new CRC32();
   boolean R;
   static int T = 1;
   static int U = 2;

   public int I(int var1) {
      try {
         if (this.method2250(2127930788) == null) {
            return this.method3465 == null ? 0 : this.method3465.method3468(-2104540777);
         } else {
            return 100;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aaz.v(" + ')');
      }
   }

   void method2260(int var1) {
      if (this.toString != null) {
         AE var2;
         for(var2 = this.L.Z(1766612795); var2 != null; var2 = this.L.B(49146)) {
            if (7051297995265073167L * var2.Z == (long)var1) {
               return;
            }
         }

         var2 = new AE();
         var2.Z = (long)var1 * 4191220306876042991L;
         this.L.I(var2, 1807588241);
      }

   }

   void method2256(int var1, short var2) {
      try {
         if (this.toString != null) {
            AE var3;
            for(var3 = this.L.Z(1766612795); var3 != null; var3 = this.L.B(49146)) {
               if (7051297995265073167L * var3.Z == (long)var1) {
                  return;
               }
            }

            var3 = new AE();
            var3.Z = (long)var1 * 4191220306876042991L;
            this.L.I(var3, -68518310);
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aaz.b(" + ')');
      }
   }

   IL append(int var1, int var2, byte var3) {
      try {
         Object var4 = (IL)this.append.I((long)var1);
         if (var4 != null && var2 == 0 && !((IL)var4).K && ((IL)var4).G) {
            ((IL)var4).I(-1460969981);
            var4 = null;
         }

         if (var4 == null) {
            if (var2 == 0) {
               if (this.toString != null && this.J[var1] != -1) {
                  var4 = this.method3468.I(var1, this.toString, -1787098666);
               } else {
                  if (this.equals.I((byte)14)) {
                     return null;
                  }

                  var4 = this.equals.I(-553176479 * this.method2250, var1, (byte)2, true, -393413622);
               }
            } else if (var2 == 1) {
               if (this.toString == null) {
                  throw new RuntimeException();
               }

               var4 = this.method3468.I(var1, this.toString, (byte)-18);
            } else {
               if (2 != var2) {
                  throw new RuntimeException();
               }

               if (this.toString == null) {
                  throw new RuntimeException();
               }

               if (-1 != this.J[var1]) {
                  throw new RuntimeException();
               }

               if (this.equals.Z((byte)-70)) {
                  return null;
               }

               var4 = this.equals.I(this.method2250 * -553176479, var1, (byte)2, false, 67458398);
            }

            this.append.I((AE)var4, (long)var1);
         }

         if (((IL)var4).G) {
            return null;
         } else {
            byte[] var5 = ((IL)var4).method3465((short)657);
            byte[] var8;
            if (var4 instanceof CL) {
               Object var14;
               try {
                  if (var5 == null || var5.length <= 2) {
                     throw new RuntimeException();
                  }

                  Q.reset();
                  Q.update(var5, 0, var5.length - 2);
                  int var16 = (int)Q.getValue();
                  if (this.update.A[var1] != var16) {
                     throw new RuntimeException();
                  }

                  if (this.update.C != null && this.update.C[var1] != null) {
                     var8 = this.update.C[var1];
                     byte[] var19 = ZC.I(var5, 0, var5.length - 2, (byte)21);

                     for(int var10 = 0; var10 < 64; ++var10) {
                        if (var8[var10] != var19[var10]) {
                           throw new RuntimeException();
                        }
                     }
                  }

                  int var18 = (var5[var5.length - 1] & 255) + ((var5[var5.length - 2] & 255) << 8);
                  if (var18 != (this.update.Z[var1] & '\uffff')) {
                     throw new RuntimeException();
                  }

                  if (this.J[var1] != 1) {
                     byte var10000 = this.J[var1];
                     this.reset += 13538129;
                     this.J[var1] = 1;
                  }

                  if (!((IL)var4).K) {
                     ((IL)var4).I(-1460969981);
                  }

                  var14 = var4;
               } catch (Exception var11) {
                  this.J[var1] = -1;
                  ((IL)var4).I(-1460969981);
                  if (((IL)var4).K && !this.equals.I((byte)14)) {
                     ZL var17 = this.equals.I(-553176479 * this.method2250, var1, (byte)2, true, 61291917);
                     this.append.I(var17, (long)var1);
                  }

                  return null;
               }

               return (IL)var14;
            } else {
               try {
                  label174: {
                     if (var5 != null && var5.length > 2) {
                        Q.reset();
                        Q.update(var5, 0, var5.length - 2);
                        int var6 = (int)Q.getValue();
                        if (var6 != this.update.A[var1]) {
                           throw new RuntimeException();
                        }

                        if (this.update.C == null || this.update.C[var1] == null) {
                           break label174;
                        }

                        byte[] var15 = this.update.C[var1];
                        var8 = ZC.I(var5, 0, var5.length - 2, (byte)-6);
                        int var9 = 0;

                        while(true) {
                           if (var9 >= 64) {
                              break label174;
                           }

                           if (var15[var9] != var8[var9]) {
                              throw new RuntimeException();
                           }

                           ++var9;
                        }
                     }

                     throw new RuntimeException();
                  }

                  this.equals.C = 0;
                  this.equals.K = 0;
               } catch (RuntimeException var12) {
                  this.equals.method2359(-1195501767);
                  ((IL)var4).I(-1460969981);
                  if (((IL)var4).K && !this.equals.I((byte)14)) {
                     ZL var7 = this.equals.I(-553176479 * this.method2250, var1, (byte)2, true, -791962540);
                     this.append.I(var7, (long)var1);
                  }

                  return null;
               }

               var5[var5.length - 2] = (byte)(this.update.Z[var1] >>> 8);
               var5[var5.length - 1] = (byte)this.update.Z[var1];
               if (this.toString != null) {
                  this.method3468.I(var1, var5, this.toString, -645332532);
                  if (this.J[var1] != 1) {
                     this.reset += 13538129;
                     this.J[var1] = 1;
                  }
               }

               if (!((IL)var4).K) {
                  ((IL)var4).I(-1460969981);
               }

               return (IL)var4;
            }
         }
      } catch (RuntimeException var13) {
         throw DQ.I(var13, "aaz.g(" + ')');
      }
   }

   void I(byte var1) {
      try {
         if (this.A != null && this.method2250(2079218396) != null) {
            for(AE var2 = this.L.Z(1766612795); var2 != null; var2 = this.L.B(49146)) {
               int var3 = (int)(7051297995265073167L * var2.Z);
               if (var3 >= 0 && var3 < -1583970959 * this.update.S && this.update.G[var3] != 0) {
                  if (this.J[var3] == 0) {
                     this.append(var3, 1, (byte)96);
                  }

                  if (-1 == this.J[var3]) {
                     this.append(var3, 2, (byte)26);
                  }

                  if (1 == this.J[var3]) {
                     var2.I(-1460969981);
                  }
               } else {
                  var2.I(-1460969981);
               }
            }
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aaz.e(" + ')');
      }
   }

   void Z(int var1) {
      try {
         if (this.A != null) {
            if (this.method2250(2060715797) == null) {
               return;
            }

            boolean var2;
            AE var3;
            int var4;
            if (this.G) {
               var2 = true;

               for(var3 = this.A.Z(1766612795); var3 != null; var3 = this.A.B(49146)) {
                  var4 = (int)(var3.Z * 7051297995265073167L);
                  if (this.J[var4] == 0) {
                     this.append(var4, 1, (byte)113);
                  }

                  if (this.J[var4] != 0) {
                     var3.I(-1460969981);
                  } else {
                     var2 = false;
                  }
               }

               while(this.E * 2044090087 < this.update.G.length) {
                  if (this.update.G[2044090087 * this.E] == 0) {
                     this.E += -303145769;
                  } else {
                     if (-2031048721 * this.method3468.I >= 250) {
                        var2 = false;
                        break;
                     }

                     if (this.J[2044090087 * this.E] == 0) {
                        this.append(2044090087 * this.E, 1, (byte)122);
                     }

                     if (this.J[this.E * 2044090087] == 0) {
                        var3 = new AE();
                        var3.Z = (long)this.E * -1525375729483922519L;
                        this.A.I(var3, 2047339116);
                        var2 = false;
                     }

                     this.E += -303145769;
                  }
               }

               if (var2) {
                  this.G = false;
                  this.E = 0;
               }
            } else if (this.R) {
               var2 = true;

               for(var3 = this.A.Z(1766612795); var3 != null; var3 = this.A.B(49146)) {
                  var4 = (int)(7051297995265073167L * var3.Z);
                  if (this.J[var4] != 1) {
                     this.append(var4, 2, (byte)80);
                  }

                  if (1 == this.J[var4]) {
                     var3.I(-1460969981);
                  } else {
                     var2 = false;
                  }
               }

               while(2044090087 * this.E < this.update.G.length) {
                  if (this.update.G[2044090087 * this.E] == 0) {
                     this.E += -303145769;
                  } else {
                     if (this.equals.Z((byte)57)) {
                        var2 = false;
                        break;
                     }

                     if (1 != this.J[2044090087 * this.E]) {
                        this.append(this.E * 2044090087, 2, (byte)99);
                     }

                     if (1 != this.J[this.E * 2044090087]) {
                        var3 = new AE();
                        var3.Z = -1525375729483922519L * (long)this.E;
                        this.A.I(var3, 120115319);
                        var2 = false;
                     }

                     this.E += -303145769;
                  }
               }

               if (var2) {
                  this.R = false;
                  this.E = 0;
               }
            } else {
               this.A = null;
            }
         }

         if (this.M && CI.I((byte)1) >= this.N * 2822951764100643313L) {
            for(IL var6 = (IL)this.append.C(1614241493); var6 != null; var6 = (IL)this.append.Z((byte)-12)) {
               if (var6.G) {
                  if (var1 == -1065641321) {
                     return;
                  }
               } else if (var6.H) {
                  if (!var6.K) {
                     throw new RuntimeException();
                  }

                  var6.I(-1460969981);
               } else {
                  var6.H = true;
               }
            }

            this.N = (CI.I((byte)1) + 1000L) * -7842795960219478255L;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aaz.c(" + ')');
      }
   }

   HJ(int var1, FP var2, FP var3, QJ var4, CS var5, int var6, byte[] var7, int var8, boolean var9) {
      this.method2250 = var1 * 160231841;
      this.toString = var2;
      if (this.toString == null) {
         this.G = false;
      } else {
         this.G = true;
         this.A = new IY();
      }

      this.method2359 = var3;
      this.equals = var4;
      this.method3468 = var5;
      this.O = var6 * 235523743;
      this.getValue = var7;
      this.H = 1761064455 * var8;
      this.M = var9;
      if (this.method2359 != null) {
         this.method3465 = this.method3468.I(this.method2250 * -553176479, this.method2359, -1787098666);
      }

   }

   public int Z(byte var1) {
      try {
         return this.reset * -150039119;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aaz.w(" + ')');
      }
   }

   public int C(int var1) {
      try {
         if (this.update == null) {
            return 0;
         } else if (!this.G) {
            return -2145352941 * this.update.K;
         } else {
            AE var2 = this.A.Z(1766612795);
            return var2 == null ? 0 : (int)(7051297995265073167L * var2.Z);
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aaz.j(" + ')');
      }
   }

   byte[] method2252(int var1) {
      IL var2 = this.append(var1, 0, (byte)95);
      if (var2 == null) {
         return null;
      } else {
         byte[] var3 = var2.method3465((short)9305);
         var2.I(-1460969981);
         return var3;
      }
   }

   PF method2264() {
      if (this.update != null) {
         return this.update;
      } else {
         if (this.method3465 == null) {
            if (this.equals.I((byte)14)) {
               return null;
            }

            this.method3465 = this.equals.I(255, -553176479 * this.method2250, (byte)0, true, 1341135400);
         }

         if (this.method3465.G) {
            return null;
         } else {
            byte[] var1 = this.method3465.method3465((short)-18101);
            if (this.method3465 instanceof CL) {
               try {
                  if (var1 == null) {
                     throw new RuntimeException();
                  }

                  this.update = new PF(var1, 28953951 * this.O, this.getValue);
                  if (1598805943 * this.H != 201380083 * this.update.M) {
                     throw new RuntimeException();
                  }
               } catch (RuntimeException var3) {
                  this.update = null;
                  if (this.equals.I((byte)14)) {
                     this.method3465 = null;
                  } else {
                     this.method3465 = this.equals.I(255, -553176479 * this.method2250, (byte)0, true, 694224083);
                  }

                  return null;
               }
            } else {
               try {
                  if (var1 == null) {
                     throw new RuntimeException();
                  }

                  this.update = new PF(var1, 28953951 * this.O, this.getValue);
               } catch (RuntimeException var4) {
                  this.equals.method2359(-1690580411);
                  this.update = null;
                  if (this.equals.I((byte)14)) {
                     this.method3465 = null;
                  } else {
                     this.method3465 = this.equals.I(255, this.method2250 * -553176479, (byte)0, true, -1212933335);
                  }

                  return null;
               }

               if (this.method2359 != null) {
                  this.method3468.I(-553176479 * this.method2250, var1, this.method2359, 628603077);
               }
            }

            this.method3465 = null;
            if (this.toString != null) {
               this.J = new byte[this.update.S * -1583970959];
               this.reset = 0;
            }

            return this.update;
         }
      }
   }

   int method2253(int var1, int var2) {
      try {
         IL var3 = (IL)this.append.I((long)var1);
         return var3 != null ? var3.method3468(-2048847327) : 0;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aaz.p(" + ')');
      }
   }

   PF method2254() {
      if (this.update != null) {
         return this.update;
      } else {
         if (this.method3465 == null) {
            if (this.equals.I((byte)14)) {
               return null;
            }

            this.method3465 = this.equals.I(255, -553176479 * this.method2250, (byte)0, true, -1923437147);
         }

         if (this.method3465.G) {
            return null;
         } else {
            byte[] var1 = this.method3465.method3465((short)17552);
            if (this.method3465 instanceof CL) {
               try {
                  if (var1 == null) {
                     throw new RuntimeException();
                  }

                  this.update = new PF(var1, 28953951 * this.O, this.getValue);
                  if (1598805943 * this.H != 201380083 * this.update.M) {
                     throw new RuntimeException();
                  }
               } catch (RuntimeException var3) {
                  this.update = null;
                  if (this.equals.I((byte)14)) {
                     this.method3465 = null;
                  } else {
                     this.method3465 = this.equals.I(255, -553176479 * this.method2250, (byte)0, true, -313120105);
                  }

                  return null;
               }
            } else {
               try {
                  if (var1 == null) {
                     throw new RuntimeException();
                  }

                  this.update = new PF(var1, 28953951 * this.O, this.getValue);
               } catch (RuntimeException var4) {
                  this.equals.method2359(-1420399817);
                  this.update = null;
                  if (this.equals.I((byte)14)) {
                     this.method3465 = null;
                  } else {
                     this.method3465 = this.equals.I(255, this.method2250 * -553176479, (byte)0, true, 76396423);
                  }

                  return null;
               }

               if (this.method2359 != null) {
                  this.method3468.I(-553176479 * this.method2250, var1, this.method2359, -1430287423);
               }
            }

            this.method3465 = null;
            if (this.toString != null) {
               this.J = new byte[this.update.S * -1583970959];
               this.reset = 0;
            }

            return this.update;
         }
      }
   }

   byte[] method2251(int var1, byte var2) {
      try {
         IL var3 = this.append(var1, 0, (byte)38);
         if (var3 == null) {
            return null;
         } else {
            byte[] var4 = var3.method3465((short)6593);
            var3.I(-1460969981);
            return var4;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aaz.f(" + ')');
      }
   }

   byte[] method2258(int var1) {
      IL var2 = this.append(var1, 0, (byte)21);
      if (var2 == null) {
         return null;
      } else {
         byte[] var3 = var2.method3465((short)-8951);
         var2.I(-1460969981);
         return var3;
      }
   }

   IL equals(int var1, int var2) {
      Object var3 = (IL)this.append.I((long)var1);
      if (var3 != null && var2 == 0 && !((IL)var3).K && ((IL)var3).G) {
         ((IL)var3).I(-1460969981);
         var3 = null;
      }

      if (var3 == null) {
         if (var2 == 0) {
            if (this.toString != null && this.J[var1] != -1) {
               var3 = this.method3468.I(var1, this.toString, -1787098666);
            } else {
               if (this.equals.I((byte)14)) {
                  return null;
               }

               var3 = this.equals.I(-553176479 * this.method2250, var1, (byte)2, true, -418226880);
            }
         } else if (var2 == 1) {
            if (this.toString == null) {
               throw new RuntimeException();
            }

            var3 = this.method3468.I(var1, this.toString, (byte)-52);
         } else {
            if (2 != var2) {
               throw new RuntimeException();
            }

            if (this.toString == null) {
               throw new RuntimeException();
            }

            if (-1 != this.J[var1]) {
               throw new RuntimeException();
            }

            if (this.equals.Z((byte)-63)) {
               return null;
            }

            var3 = this.equals.I(this.method2250 * -553176479, var1, (byte)2, false, -620070396);
         }

         this.append.I((AE)var3, (long)var1);
      }

      if (((IL)var3).G) {
         return null;
      } else {
         byte[] var4 = ((IL)var3).method3465((short)369);
         byte[] var7;
         if (var3 instanceof CL) {
            try {
               if (var4 != null && var4.length > 2) {
                  Q.reset();
                  Q.update(var4, 0, var4.length - 2);
                  int var13 = (int)Q.getValue();
                  if (this.update.A[var1] != var13) {
                     throw new RuntimeException();
                  } else {
                     if (this.update.C != null && this.update.C[var1] != null) {
                        var7 = this.update.C[var1];
                        byte[] var16 = ZC.I(var4, 0, var4.length - 2, (byte)3);

                        for(int var9 = 0; var9 < 64; ++var9) {
                           if (var7[var9] != var16[var9]) {
                              throw new RuntimeException();
                           }
                        }
                     }

                     int var15 = (var4[var4.length - 1] & 255) + ((var4[var4.length - 2] & 255) << 8);
                     if (var15 != (this.update.Z[var1] & '\uffff')) {
                        throw new RuntimeException();
                     } else {
                        if (this.J[var1] != 1) {
                           byte var10000 = this.J[var1];
                           this.reset += 13538129;
                           this.J[var1] = 1;
                        }

                        if (!((IL)var3).K) {
                           ((IL)var3).I(-1460969981);
                        }

                        return (IL)var3;
                     }
                  }
               } else {
                  throw new RuntimeException();
               }
            } catch (Exception var10) {
               this.J[var1] = -1;
               ((IL)var3).I(-1460969981);
               if (((IL)var3).K && !this.equals.I((byte)14)) {
                  ZL var14 = this.equals.I(-553176479 * this.method2250, var1, (byte)2, true, 65779920);
                  this.append.I(var14, (long)var1);
               }

               return null;
            }
         } else {
            try {
               label159: {
                  if (var4 != null && var4.length > 2) {
                     Q.reset();
                     Q.update(var4, 0, var4.length - 2);
                     int var5 = (int)Q.getValue();
                     if (var5 != this.update.A[var1]) {
                        throw new RuntimeException();
                     }

                     if (this.update.C == null || this.update.C[var1] == null) {
                        break label159;
                     }

                     byte[] var12 = this.update.C[var1];
                     var7 = ZC.I(var4, 0, var4.length - 2, (byte)-72);
                     int var8 = 0;

                     while(true) {
                        if (var8 >= 64) {
                           break label159;
                        }

                        if (var12[var8] != var7[var8]) {
                           throw new RuntimeException();
                        }

                        ++var8;
                     }
                  }

                  throw new RuntimeException();
               }

               this.equals.C = 0;
               this.equals.K = 0;
            } catch (RuntimeException var11) {
               this.equals.method2359(106727223);
               ((IL)var3).I(-1460969981);
               if (((IL)var3).K && !this.equals.I((byte)14)) {
                  ZL var6 = this.equals.I(-553176479 * this.method2250, var1, (byte)2, true, 1559389901);
                  this.append.I(var6, (long)var1);
               }

               return null;
            }

            var4[var4.length - 2] = (byte)(this.update.Z[var1] >>> 8);
            var4[var4.length - 1] = (byte)this.update.Z[var1];
            if (this.toString != null) {
               this.method3468.I(var1, var4, this.toString, 408687877);
               if (this.J[var1] != 1) {
                  this.reset += 13538129;
                  this.J[var1] = 1;
               }
            }

            if (!((IL)var3).K) {
               ((IL)var3).I(-1460969981);
            }

            return (IL)var3;
         }
      }
   }

   byte[] method2259(int var1) {
      IL var2 = this.append(var1, 0, (byte)38);
      if (var2 == null) {
         return null;
      } else {
         byte[] var3 = var2.method3465((short)-19395);
         var2.I(-1460969981);
         return var3;
      }
   }

   int method2257(int var1) {
      IL var2 = (IL)this.append.I((long)var1);
      return var2 != null ? var2.method3468(-2007766703) : 0;
   }

   int method2261(int var1) {
      IL var2 = (IL)this.append.I((long)var1);
      return var2 != null ? var2.method3468(-2126560995) : 0;
   }

   IL getValue(int var1, int var2) {
      Object var3 = (IL)this.append.I((long)var1);
      if (var3 != null && var2 == 0 && !((IL)var3).K && ((IL)var3).G) {
         ((IL)var3).I(-1460969981);
         var3 = null;
      }

      if (var3 == null) {
         if (var2 == 0) {
            if (this.toString != null && this.J[var1] != -1) {
               var3 = this.method3468.I(var1, this.toString, -1787098666);
            } else {
               if (this.equals.I((byte)14)) {
                  return null;
               }

               var3 = this.equals.I(-553176479 * this.method2250, var1, (byte)2, true, 1037407823);
            }
         } else if (var2 == 1) {
            if (this.toString == null) {
               throw new RuntimeException();
            }

            var3 = this.method3468.I(var1, this.toString, (byte)-21);
         } else {
            if (2 != var2) {
               throw new RuntimeException();
            }

            if (this.toString == null) {
               throw new RuntimeException();
            }

            if (-1 != this.J[var1]) {
               throw new RuntimeException();
            }

            if (this.equals.Z((byte)-55)) {
               return null;
            }

            var3 = this.equals.I(this.method2250 * -553176479, var1, (byte)2, false, -835440234);
         }

         this.append.I((AE)var3, (long)var1);
      }

      if (((IL)var3).G) {
         return null;
      } else {
         byte[] var4 = ((IL)var3).method3465((short)-10519);
         byte[] var7;
         if (var3 instanceof CL) {
            try {
               if (var4 != null && var4.length > 2) {
                  Q.reset();
                  Q.update(var4, 0, var4.length - 2);
                  int var13 = (int)Q.getValue();
                  if (this.update.A[var1] != var13) {
                     throw new RuntimeException();
                  } else {
                     if (this.update.C != null && this.update.C[var1] != null) {
                        var7 = this.update.C[var1];
                        byte[] var16 = ZC.I(var4, 0, var4.length - 2, (byte)67);

                        for(int var9 = 0; var9 < 64; ++var9) {
                           if (var7[var9] != var16[var9]) {
                              throw new RuntimeException();
                           }
                        }
                     }

                     int var15 = (var4[var4.length - 1] & 255) + ((var4[var4.length - 2] & 255) << 8);
                     if (var15 != (this.update.Z[var1] & '\uffff')) {
                        throw new RuntimeException();
                     } else {
                        if (this.J[var1] != 1) {
                           byte var10000 = this.J[var1];
                           this.reset += 13538129;
                           this.J[var1] = 1;
                        }

                        if (!((IL)var3).K) {
                           ((IL)var3).I(-1460969981);
                        }

                        return (IL)var3;
                     }
                  }
               } else {
                  throw new RuntimeException();
               }
            } catch (Exception var10) {
               this.J[var1] = -1;
               ((IL)var3).I(-1460969981);
               if (((IL)var3).K && !this.equals.I((byte)14)) {
                  ZL var14 = this.equals.I(-553176479 * this.method2250, var1, (byte)2, true, -155086608);
                  this.append.I(var14, (long)var1);
               }

               return null;
            }
         } else {
            try {
               label159: {
                  if (var4 != null && var4.length > 2) {
                     Q.reset();
                     Q.update(var4, 0, var4.length - 2);
                     int var5 = (int)Q.getValue();
                     if (var5 != this.update.A[var1]) {
                        throw new RuntimeException();
                     }

                     if (this.update.C == null || this.update.C[var1] == null) {
                        break label159;
                     }

                     byte[] var12 = this.update.C[var1];
                     var7 = ZC.I(var4, 0, var4.length - 2, (byte)-11);
                     int var8 = 0;

                     while(true) {
                        if (var8 >= 64) {
                           break label159;
                        }

                        if (var12[var8] != var7[var8]) {
                           throw new RuntimeException();
                        }

                        ++var8;
                     }
                  }

                  throw new RuntimeException();
               }

               this.equals.C = 0;
               this.equals.K = 0;
            } catch (RuntimeException var11) {
               this.equals.method2359(556604655);
               ((IL)var3).I(-1460969981);
               if (((IL)var3).K && !this.equals.I((byte)14)) {
                  ZL var6 = this.equals.I(-553176479 * this.method2250, var1, (byte)2, true, -1299366949);
                  this.append.I(var6, (long)var1);
               }

               return null;
            }

            var4[var4.length - 2] = (byte)(this.update.Z[var1] >>> 8);
            var4[var4.length - 1] = (byte)this.update.Z[var1];
            if (this.toString != null) {
               this.method3468.I(var1, var4, this.toString, 1120335343);
               if (this.J[var1] != 1) {
                  this.reset += 13538129;
                  this.J[var1] = 1;
               }
            }

            if (!((IL)var3).K) {
               ((IL)var3).I(-1460969981);
            }

            return (IL)var3;
         }
      }
   }

   PF method2255() {
      if (this.update != null) {
         return this.update;
      } else {
         if (this.method3465 == null) {
            if (this.equals.I((byte)14)) {
               return null;
            }

            this.method3465 = this.equals.I(255, -553176479 * this.method2250, (byte)0, true, -1646455310);
         }

         if (this.method3465.G) {
            return null;
         } else {
            byte[] var1 = this.method3465.method3465((short)15445);
            if (this.method3465 instanceof CL) {
               try {
                  if (var1 == null) {
                     throw new RuntimeException();
                  }

                  this.update = new PF(var1, 28953951 * this.O, this.getValue);
                  if (1598805943 * this.H != 201380083 * this.update.M) {
                     throw new RuntimeException();
                  }
               } catch (RuntimeException var3) {
                  this.update = null;
                  if (this.equals.I((byte)14)) {
                     this.method3465 = null;
                  } else {
                     this.method3465 = this.equals.I(255, -553176479 * this.method2250, (byte)0, true, -1760474693);
                  }

                  return null;
               }
            } else {
               try {
                  if (var1 == null) {
                     throw new RuntimeException();
                  }

                  this.update = new PF(var1, 28953951 * this.O, this.getValue);
               } catch (RuntimeException var4) {
                  this.equals.method2359(-1856562324);
                  this.update = null;
                  if (this.equals.I((byte)14)) {
                     this.method3465 = null;
                  } else {
                     this.method3465 = this.equals.I(255, this.method2250 * -553176479, (byte)0, true, 1078557293);
                  }

                  return null;
               }

               if (this.method2359 != null) {
                  this.method3468.I(-553176479 * this.method2250, var1, this.method2359, -1078065022);
               }
            }

            this.method3465 = null;
            if (this.toString != null) {
               this.J = new byte[this.update.S * -1583970959];
               this.reset = 0;
            }

            return this.update;
         }
      }
   }

   public void C(byte var1) {
      try {
         if (this.toString != null) {
            this.R = true;
            if (this.A == null) {
               this.A = new IY();
            }
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aaz.o(" + ')');
      }
   }

   PF method2250(int var1) {
      try {
         if (this.update != null) {
            return this.update;
         } else {
            if (this.method3465 == null) {
               if (this.equals.I((byte)14)) {
                  return null;
               }

               this.method3465 = this.equals.I(255, -553176479 * this.method2250, (byte)0, true, -1469164318);
            }

            if (this.method3465.G) {
               return null;
            } else {
               byte[] var2 = this.method3465.method3465((short)-4612);
               if (this.method3465 instanceof CL) {
                  try {
                     if (var2 == null) {
                        throw new RuntimeException();
                     }

                     this.update = new PF(var2, 28953951 * this.O, this.getValue);
                     if (1598805943 * this.H != 201380083 * this.update.M) {
                        throw new RuntimeException();
                     }
                  } catch (RuntimeException var4) {
                     this.update = null;
                     if (this.equals.I((byte)14)) {
                        this.method3465 = null;
                     } else {
                        this.method3465 = this.equals.I(255, -553176479 * this.method2250, (byte)0, true, -165290458);
                     }

                     return null;
                  }
               } else {
                  try {
                     if (var2 == null) {
                        throw new RuntimeException();
                     }

                     this.update = new PF(var2, 28953951 * this.O, this.getValue);
                  } catch (RuntimeException var5) {
                     this.equals.method2359(674708053);
                     this.update = null;
                     if (this.equals.I((byte)14)) {
                        this.method3465 = null;
                     } else {
                        this.method3465 = this.equals.I(255, this.method2250 * -553176479, (byte)0, true, 1947550865);
                     }

                     return null;
                  }

                  if (this.method2359 != null) {
                     this.method3468.I(-553176479 * this.method2250, var2, this.method2359, -586951023);
                  }
               }

               this.method3465 = null;
               if (this.toString != null) {
                  this.J = new byte[this.update.S * -1583970959];
                  this.reset = 0;
               }

               return this.update;
            }
         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "aaz.a(" + ')');
      }
   }

   byte[] method2262(int var1) {
      IL var2 = this.append(var1, 0, (byte)124);
      if (var2 == null) {
         return null;
      } else {
         byte[] var3 = var2.method3465((short)20083);
         var2.I(-1460969981);
         return var3;
      }
   }

   void method2263(int var1) {
      if (this.toString != null) {
         AE var2;
         for(var2 = this.L.Z(1766612795); var2 != null; var2 = this.L.B(49146)) {
            if (7051297995265073167L * var2.Z == (long)var1) {
               return;
            }
         }

         var2 = new AE();
         var2.Z = (long)var1 * 4191220306876042991L;
         this.L.I(var2, 1192203281);
      }

   }

   public int B(int var1) {
      try {
         return this.update == null ? 0 : this.update.K * -2145352941;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aaz.m(" + ')');
      }
   }

   void method2249(int var1) {
      if (this.toString != null) {
         AE var2;
         for(var2 = this.L.Z(1766612795); var2 != null; var2 = this.L.B(49146)) {
            if (7051297995265073167L * var2.Z == (long)var1) {
               return;
            }
         }

         var2 = new AE();
         var2.Z = (long)var1 * 4191220306876042991L;
         this.L.I(var2, 429546119);
      }

   }

   void method2265(int var1) {
      if (this.toString != null) {
         AE var2;
         for(var2 = this.L.Z(1766612795); var2 != null; var2 = this.L.B(49146)) {
            if (7051297995265073167L * var2.Z == (long)var1) {
               return;
            }
         }

         var2 = new AE();
         var2.Z = (long)var1 * 4191220306876042991L;
         this.L.I(var2, 1262906259);
      }

   }

   static void I(int var0, byte var1) {
      try {
         for(AE var2 = XEI.vB.C(2109381941); var2 != null; var2 = XEI.vB.Z((byte)-58)) {
            if ((long)var0 == (7051297995265073167L * var2.Z >> 48 & 65535L)) {
               var2.I(-1460969981);
            }
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aaz.mu(" + ')');
      }
   }

   static final void I(OU var0, short var1) {
      try {
         if (YX.I && WF.O != null) {
            OQ.I(FW.J.J.Z((byte)4), -1, -1, false, 1414482658);
         }

         String var2 = (String)var0.S[(var0.A -= 969361751) * -203050393];
         boolean var3 = var0.H[(var0.J -= -391880689) * 681479919] == 1;
         String var4 = DSI.Z((byte)-59) + var2;
         if (var4.equals("http://www.BlissScape.com/l=en/a=0/p=wwGlrZHF5gKN6D3mDdihco3oPeYN2KFybL9hUUFqOvk/loginapplet/loginapplet.ws?ssl=1&expired=0&mod=accountappeal&dest=passwordchoice.ws")) {
            var4 = "http://www.blissscape.com/forums/m/33734747/viewforum/6249200";
         } else if (var4.equals("http://www.BlissScape.com/l=en/a=0/p=wwGlrZHF5gKN6D3mDdihco3oPeYN2KFybL9hUUFqOvk/loginapplet/loginapplet.ws?ssl=1&expired=0&mod=www&dest=account_settings.ws?mod=messages")) {
            var4 = "http://www.blissscape.com/forums/m/33734747/viewforum/6249197";
         }

         DQ.I(var4, var3, FW.J.d.I(-1851684401) == 5, XEI.WB, XEI.e, (byte)49);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aaz.afo(" + ')');
      }
   }

   public static void I(int var0, int var1, String var2, String var3, String var4, String var5, int var6) {
      try {
         VJ.I(var0, var1, var2, var3, var4, var5, (String)null, -1, 1446000206);
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "aaz.p(" + ')');
      }
   }

   static void B(byte var0) {
      try {
         int var1 = 0;
         if (FW.J != null) {
            var1 = FW.J.Y.Z(-1747444886);
         }

         int var2;
         int var3;
         if (var1 == 2) {
            var2 = -639974669 * ADI.S > 800 ? 800 : ADI.S * -639974669;
            var3 = XEI.F * 1282634425 > 600 ? 600 : 1282634425 * XEI.F;
            GY.Z = -2010408377 * var2;
            XEI.J = -753018213 * ((ADI.S * -639974669 - var2) / 2);
            JM.J = 1445266787 * var3;
            XEI.S = 0;
         } else if (var1 == 1) {
            var2 = -639974669 * ADI.S > 1024 ? 1024 : ADI.S * -639974669;
            var3 = XEI.F * 1282634425 > 768 ? 768 : XEI.F * 1282634425;
            GY.Z = var2 * -2010408377;
            XEI.J = -753018213 * ((-639974669 * ADI.S - var2) / 2);
            JM.J = 1445266787 * var3;
            XEI.S = 0;
         } else {
            GY.Z = ADI.S * -607961243;
            XEI.J = 0;
            JM.J = XEI.F * -1935672693;
            XEI.S = 0;
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aaz.gm(" + ')');
      }
   }
}
