public class KD {
   public static int append = 1;
   public static int toString = 131072;
   public static int I = 131072;
   public static int Z = 32;
   public static int C = 64;
   public static int B = 262144;
   public static int D = 512;
   public static int F = 2;
   public static int J = 4096;
   public static int S = 16;
   public static int A = 65536;
   public static int E = 512;
   public static int G = 2048;
   public static int H = 16384;
   public static int K = 128;
   public static int L = 1024;
   public static int M = 2097152;
   public static int N = 4194304;
   public static int O = 1048576;
   public static int P = 1048576;
   public static int Q = 8;
   public static int R = 65536;
   public static int T = 524288;
   public static int U = 32768;
   public static int V = 128;
   public static int W = 4;
   public static int X = 16;
   public static int Y = 32;
   public static int i = 4;
   public static int z = 1;
   public static int c = 2097152;
   public static int b = 2;
   public static int d = 16384;
   public static int f = 1024;
   public static int j = 256;
   public static int s = 33554432;
   public static int a = 8;
   public static int e = 4096;
   public static int g = 8192;
   public static int h = 32768;
   public static int k = 8388608;
   public static int l = 8388608;
   public static int m = 262144;
   public static int n = 8192;
   public static int o = 256;
   public static int p = 4194304;
   public static int q = 524288;
   public static int r = 2048;
   public static int t = 16777216;
   public static int u = 64;

   KD() throws Throwable {
      throw new Error();
   }

   public static synchronized void I(byte[] var0, int var1) {
      try {
         if (100 == var0.length && 355907107 * JV.B < 1000) {
            JV.F[(JV.B += -996497013) * 355907107 - 1] = var0;
         } else if (5000 == var0.length && JV.Z * 1904890379 < 250) {
            JV.I[(JV.Z += -1583470173) * 1904890379 - 1] = var0;
         } else if (30000 == var0.length && -1426745913 * JV.C < 50) {
            JV.J[(JV.C += 1975229431) * -1426745913 - 1] = var0;
         } else if (NL.H != null) {
            for(int var2 = 0; var2 < BZ.C.length; ++var2) {
               if (var0.length == BZ.C[var2] && JV.D[var2] < NL.H[var2].length) {
                  NL.H[var2][JV.D[var2]++] = var0;
                  break;
               }
            }
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "im.f(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var2 & 16383;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "im.te(" + ')');
      }
   }

   public static int I(byte var0) {
      try {
         return 1197525581 * CQ.I;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "im.k(" + ')');
      }
   }
}
