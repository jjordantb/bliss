import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.AbstractQueue;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class I extends AbstractQueue {
   Map TRUE;
   ZB[] I;
   int Z;
   Comparator TYPE;
   int C;

   static void TRUE(int var0) {
      try {
         Class var1 = ClassLoader.class;
         Field var2 = var1.getDeclaredField("nativeLibraries");
         Class var3 = AccessibleObject.class;
         Method var4 = var3.getDeclaredMethod("setAccessible", Boolean.TYPE);
         var4.invoke(var2, Boolean.TRUE);
      } catch (Throwable var5) {
         ;
      }

   }

   void TYPE(int var1, int var2) {
      try {
         ZB var3 = this.I[var1];

         int var4;
         for(int var5 = this.Z * -400292665 >>> 1; var1 < var5; var1 = var4) {
            int var6 = 1 + (var1 << 1);
            ZB var7 = this.I[var6];
            int var8 = 2 + (var1 << 1);
            ZB var9 = this.I[var8];
            if (this.TYPE != null) {
               if (var8 < this.Z * -400292665 && this.TYPE.compare(var7.Z, var9.Z) > 0) {
                  var4 = var8;
               } else {
                  var4 = var6;
               }
            } else if (var8 < this.Z * -400292665 && ((Comparable)var7.Z).compareTo(var9.Z) > 0) {
               var4 = var8;
            } else {
               var4 = var6;
            }

            if (this.TYPE != null) {
               if (this.TYPE.compare(var3.Z, this.I[var4].Z) <= 0) {
                  if (var2 <= -2010017327) {
                     throw new IllegalStateException();
                  }
                  break;
               }
            } else if (((Comparable)var3.Z).compareTo(this.I[var4].Z) <= 0) {
               if (var2 <= -2010017327) {
                  throw new IllegalStateException();
               }
               break;
            }

            this.I[var1] = this.I[var4];
            this.I[var1].I = var1 * 533229453;
         }

         this.I[var1] = var3;
         this.I[var1].I = var1 * 533229453;
      } catch (RuntimeException var10) {
         throw DQ.I(var10, "ajy.b(" + ')');
      }
   }

   I(int var1, Comparator var2) {
      this.C = 0;
      this.I = new ZB[var1];
      this.TRUE = new HashMap();
      this.TYPE = var2;
   }

   void append(int var1) {
      try {
         int var2 = 1 + (this.I.length << 1);
         this.I = (ZB[])Arrays.copyOf(this.I, var2);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ajy.a(" + ')');
      }
   }

   public int size() {
      try {
         return -400292665 * this.Z;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "ajy.size(" + ')');
      }
   }

   public boolean contains(Object var1) {
      try {
         return this.TRUE.containsKey(var1);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ajy.contains(" + ')');
      }
   }

   public Object poll() {
      try {
         if (-400292665 * this.Z == 0) {
            return null;
         } else {
            this.C += 1445240763;
            Object var1 = this.I[0].Z;
            this.TRUE.remove(var1);
            this.Z -= -2003206921;
            if (-400292665 * this.Z == 0) {
               this.I[-400292665 * this.Z] = null;
            } else {
               this.I[0] = this.I[this.Z * -400292665];
               this.I[0].I = 0;
               this.I[this.Z * -400292665] = null;
               this.TYPE(0, 280830604);
            }

            return var1;
         }
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "ajy.poll(" + ')');
      }
   }

   void compare(int var1, int var2) {
      try {
         ZB var3;
         int var4;
         for(var3 = this.I[var1]; var1 > 0; var1 = var4) {
            var4 = var1 - 1 >>> 1;
            ZB var5 = this.I[var4];
            if (this.TYPE != null) {
               if (this.TYPE.compare(var3.Z, var5.Z) >= 0) {
                  if (var2 >= 802255489) {
                     return;
                  }
                  break;
               }
            } else if (((Comparable)var3.Z).compareTo(var5.Z) >= 0) {
               if (var2 >= 802255489) {
                  throw new IllegalStateException();
               }
               break;
            }

            this.I[var1] = var5;
            this.I[var1].I = 533229453 * var1;
         }

         this.I[var1] = var3;
         this.I[var1].I = 533229453 * var1;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ajy.f(" + ')');
      }
   }

   public Object[] toArray() {
      try {
         Object[] var1 = super.toArray();
         if (this.TYPE != null) {
            Arrays.sort(var1, this.TYPE);
         } else {
            Arrays.sort(var1);
         }

         return var1;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "ajy.toArray(" + ')');
      }
   }

   public Iterator iterator() {
      try {
         return new RB(this);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "ajy.iterator(" + ')');
      }
   }

   public Object peek() {
      try {
         return this.Z * -400292665 == 0 ? null : this.I[0].Z;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "ajy.peek(" + ')');
      }
   }

   public I(int var1) {
      this(var1, (Comparator)null);
   }

   public boolean offer(Object var1) {
      try {
         if (this.TRUE.containsKey(var1)) {
            throw new IllegalArgumentException("");
         } else {
            this.C += 1445240763;
            int var2 = -400292665 * this.Z;
            if (var2 >= this.I.length) {
               this.append(-1001796105);
            }

            this.Z += -2003206921;
            if (var2 == 0) {
               this.I[0] = new ZB(var1, 0);
               this.TRUE.put(var1, this.I[0]);
            } else {
               this.I[var2] = new ZB(var1, var2);
               this.TRUE.put(var1, this.I[var2]);
               this.compare(var2, -2059212806);
            }

            return true;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ajy.offer(" + ')');
      }
   }

   public boolean remove(Object var1) {
      try {
         ZB var2 = (ZB)this.TRUE.remove(var1);
         if (var2 == null) {
            return false;
         } else {
            this.C += 1445240763;
            this.Z -= -2003206921;
            if (-29201595 * var2.I == -400292665 * this.Z) {
               this.I[this.Z * -400292665] = null;
               return true;
            } else {
               ZB var3 = this.I[this.Z * -400292665];
               this.I[-400292665 * this.Z] = null;
               this.I[var2.I * -29201595] = var3;
               this.I[-29201595 * var2.I].I = var2.I * 1;
               this.TYPE(-29201595 * var2.I, 1851130853);
               if (this.I[-29201595 * var2.I] == var3) {
                  this.compare(-29201595 * var2.I, -1459206324);
               }

               return true;
            }
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ajy.remove(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         EV.I((String)var0.S[(var0.A -= 969361751) * -203050393], false, false, 945299991);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ajy.afx(" + ')');
      }
   }
}
