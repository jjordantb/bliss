public class CI {
   public String I;
   public String Z;
   static KJ C;
   public static KJ B;

   void I(D var1, int var2) {
      try {
         this.Z = var1.I(1509343502);
         this.I = var1.I(1509343502);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ey.a(" + ')');
      }
   }

   public static IC I(REI var0, byte var1) {
      try {
         String var2 = var0.E(-564007296);
         HZ var3 = XII.Z((byte)112)[var0.I()];
         IZ var4 = Q.Z(722680550)[var0.I()];
         int var5 = var0.J(1872216088);
         int var6 = var0.J(2093452439);
         int var7 = var0.I();
         int var8 = var0.I();
         int var9 = var0.I();
         int var10 = var0.C();
         int var11 = var0.C();
         int var12 = var0.Y(1235052657);
         int var13 = var0.H((byte)69);
         int var14 = var0.H((byte)57);
         return new IC(var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14);
      } catch (RuntimeException var15) {
         throw DQ.I(var15, "ey.a(" + ')');
      }
   }

   public static final synchronized long I(byte var0) {
      try {
         long var1 = System.currentTimeMillis();
         if (var1 < -1072184856876656313L * LFI.Z) {
            LFI.I += -7920182256634826327L * (-1072184856876656313L * LFI.Z - var1);
         }

         LFI.Z = -8643661642579214217L * var1;
         return LFI.I * 8643379242525344409L + var1;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ey.a(" + ')');
      }
   }

   static final void I(SSI var0, SSI var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9) {
      try {
         int var10 = var1.method4427((byte)1);
         if (var10 != -1) {
            Object var11 = null;
            IBI var12 = (IBI)XEI.VI.I((long)var10);
            if (var12 == null) {
               RFI[] var13 = RFI.Z(EC.F, var10, 0);
               if (var13 == null) {
                  return;
               }

               var12 = FT.P.method5125(var13[0], true);
               XEI.VI.I(var12, (long)var10);
            }

            SF var18 = var0.I().I;
            SI.I(var0.K, (int)var18.I, (int)var18.Z, var0.S() * 256, 0, false, 2131920659);
            int var14 = (int)((float)var3 + XEI.pB[0] - 18.0F);
            int var15 = (int)((float)var4 + XEI.pB[1] - 16.0F - 54.0F);
            var14 += var2 / 4 * 18;
            var15 += 18 * (var2 % 4);
            var12.I(var14, var15);
            if (var0 == var1) {
               FT.P.I(var14 - 1, var15 - 1, 18, 18, -256, (int)-769094548);
            }

            QN var16 = TF.I((byte)60);
            var16.B = var1;
            var16.C = var14 * 514092373;
            var16.J = var15 * -783084201;
            var16.S = 1997526347 * (var14 + 16);
            var16.A = 1675098759 * (var15 + 16);
            XEI.rZ.I((HN)var16, (int)-69122600);
         }

      } catch (RuntimeException var17) {
         throw DQ.I(var17, "ey.jp(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.A.Z((byte)92);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ey.akg(" + ')');
      }
   }

   static final void I(OU var0, short var1) {
      try {
         var0.J -= -783761378;
         int var2 = var0.H[681479919 * var0.J];
         int var3 = var0.H[var0.J * 681479919 + 1];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var2 < var3 ? var2 : var3;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ey.or(" + ')');
      }
   }
}
