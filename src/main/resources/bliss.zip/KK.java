import java.util.Random;

public class KK extends YG {
   static int Q = 8;
   int[][] R;
   static int T = 1024;
   static int U = 204;
   static int V = 1024;
   int W;
   static int X = 4;
   static int Y = 81;
   int i = 1711388372;
   int z;
   int c = 0;
   static int b = 409;
   int d = 590017536;
   int f = -481147336;
   int j = 1124904956;
   int s = -1398133837;
   int a = 393787217;
   int[] e;
   int[][] g;
   int h;
   int k = -694340608;
   static int l = 0;

   void Z(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.i = var2.I() * 427847093;
         break;
      case 1:
         this.f = var2.I() * 2087340231;
         break;
      case 2:
         this.s = var2.C() * 1949794091;
         break;
      case 3:
         this.j = var2.C() * -984012539;
         break;
      case 4:
         this.k = var2.C() * 414558029;
         break;
      case 5:
         this.c = var2.C() * -83830103;
         break;
      case 6:
         this.a = var2.C() * 216958721;
         break;
      case 7:
         this.d = var2.C() * 1258867389;
      }

   }

   int[] Z(int var1, int var2) {
      try {
         int[] var3 = this.P.I(var1, -72959134);
         if (this.P.D) {
            int var4 = 0;

            int var5;
            for(var5 = this.c * -887199335 + WJ.J[var1]; var5 < 0; var5 += 4096) {
               ;
            }

            while(var5 > 4096) {
               var5 -= 4096;
            }

            while(var4 < this.f * 1685453047) {
               if (var5 < this.e[var4]) {
                  if (var2 == -484575331) {
                     throw new IllegalStateException();
                  }
                  break;
               }

               ++var4;
            }

            int var6 = var4 - 1;
            boolean var7 = (var4 & 1) == 0;
            int var8 = this.e[var4];
            int var9 = this.e[var4 - 1];
            if (var5 > var9 + this.h * -387493705 && var5 < var8 - -387493705 * this.h) {
               for(int var10 = 0; var10 < WJ.C * -1474554145; ++var10) {
                  int var11 = 0;
                  int var12 = var7 ? this.k * 642247045 : -(642247045 * this.k);

                  int var13;
                  for(var13 = WJ.A[var10] + (var12 * this.W * -934471691 >> 12); var13 < 0; var13 += 4096) {
                     ;
                  }

                  while(var13 > 4096) {
                     var13 -= 4096;
                  }

                  while(var11 < this.i * -327362403) {
                     if (var13 < this.g[var6][var11]) {
                        if (var2 == -484575331) {
                           throw new IllegalStateException();
                        }
                        break;
                     }

                     ++var11;
                  }

                  int var14 = var11 - 1;
                  int var15 = this.g[var6][var14];
                  int var16 = this.g[var6][var11];
                  if (var13 > -387493705 * this.h + var15 && var13 < var16 - -387493705 * this.h) {
                     var3[var10] = this.R[var6][var14];
                  } else {
                     var3[var10] = 0;
                  }
               }
            } else {
               TW.I(var3, 0, WJ.C * -1474554145, 0);
            }
         }

         return var3;
      } catch (RuntimeException var17) {
         throw DQ.I(var17, "agu.i(" + ')');
      }
   }

   public KK() {
      super(0, true);
   }

   void B(int var1) {
      try {
         this.toString((short)917);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "agu.x(" + ')');
      }
   }

   void I(int var1, REI var2, byte var3) {
      try {
         switch(var1) {
         case 0:
            this.i = var2.I() * 427847093;
            break;
         case 1:
            this.f = var2.I() * 2087340231;
            break;
         case 2:
            this.s = var2.C() * 1949794091;
            break;
         case 3:
            this.j = var2.C() * -984012539;
            break;
         case 4:
            this.k = var2.C() * 414558029;
            break;
         case 5:
            this.c = var2.C() * -83830103;
            break;
         case 6:
            this.a = var2.C() * 216958721;
            break;
         case 7:
            this.d = var2.C() * 1258867389;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "agu.r(" + ')');
      }
   }

   int[] append(int var1) {
      int[] var2 = this.P.I(var1, 1139485503);
      if (this.P.D) {
         int var3 = 0;

         int var4;
         for(var4 = this.c * -887199335 + WJ.J[var1]; var4 < 0; var4 += 4096) {
            ;
         }

         while(var4 > 4096) {
            var4 -= 4096;
         }

         while(var3 < this.f * 1685453047 && var4 >= this.e[var3]) {
            ++var3;
         }

         int var5 = var3 - 1;
         boolean var6 = (var3 & 1) == 0;
         int var7 = this.e[var3];
         int var8 = this.e[var3 - 1];
         if (var4 > var8 + this.h * -387493705 && var4 < var7 - -387493705 * this.h) {
            for(int var9 = 0; var9 < WJ.C * -1474554145; ++var9) {
               int var10 = 0;
               int var11 = var6 ? this.k * 642247045 : -(642247045 * this.k);

               int var12;
               for(var12 = WJ.A[var9] + (var11 * this.W * -934471691 >> 12); var12 < 0; var12 += 4096) {
                  ;
               }

               while(var12 > 4096) {
                  var12 -= 4096;
               }

               while(var10 < this.i * -327362403 && var12 >= this.g[var5][var10]) {
                  ++var10;
               }

               int var13 = var10 - 1;
               int var14 = this.g[var5][var13];
               int var15 = this.g[var5][var10];
               if (var12 > -387493705 * this.h + var14 && var12 < var15 - -387493705 * this.h) {
                  var2[var9] = this.R[var5][var13];
               } else {
                  var2[var9] = 0;
               }
            }
         } else {
            TW.I(var2, 0, WJ.C * -1474554145, 0);
         }
      }

      return var2;
   }

   void toString(short var1) {
      try {
         Random var2 = new Random((long)(1685453047 * this.f));
         this.h = 1871219975 * (1732409601 * this.a / 2);
         this.W = 4096 / (-327362403 * this.i) * 1303485533;
         this.z = 4096 / (1685453047 * this.f) * -1986852725;
         int var3 = -934471691 * this.W / 2;
         int var4 = this.z * 1194794787 / 2;
         this.e = new int[1 + 1685453047 * this.f];
         this.g = new int[this.f * 1685453047][1 + this.i * -327362403];
         this.R = new int[1685453047 * this.f][this.i * -327362403];
         this.e[0] = 0;

         for(int var5 = 0; var5 < 1685453047 * this.f; ++var5) {
            int var6;
            int var7;
            if (var5 > 0) {
               var6 = this.z * 1194794787;
               var7 = (IG.I(var2, 4096, (byte)-30) - 2048) * this.j * -1888601139 >> 12;
               var6 += var7 * var4 >> 12;
               this.e[var5] = var6 + this.e[var5 - 1];
            }

            this.g[var5][0] = 0;

            for(var6 = 0; var6 < this.i * -327362403; ++var6) {
               if (var6 > 0) {
                  var7 = -934471691 * this.W;
                  int var8 = (IG.I(var2, 4096, (byte)-82) - 2048) * this.s * -1484830845 >> 12;
                  var7 += var8 * var3 >> 12;
                  this.g[var5][var6] = var7 + this.g[var5][var6 - 1];
               }

               this.R[var5][var6] = this.d * -762707819 > 0 ? 4096 - IG.I(var2, this.d * -762707819, (byte)23) : 4096;
            }

            this.g[var5][-327362403 * this.i] = 4096;
         }

         this.e[1685453047 * this.f] = 4096;
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "agu.ac(" + ')');
      }
   }

   void Z() {
      this.toString((short)917);
   }

   void append() {
      this.toString((short)917);
   }

   void I() {
      this.toString((short)917);
   }

   void I(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.i = var2.I() * 427847093;
         break;
      case 1:
         this.f = var2.I() * 2087340231;
         break;
      case 2:
         this.s = var2.C() * 1949794091;
         break;
      case 3:
         this.j = var2.C() * -984012539;
         break;
      case 4:
         this.k = var2.C() * 414558029;
         break;
      case 5:
         this.c = var2.C() * -83830103;
         break;
      case 6:
         this.a = var2.C() * 216958721;
         break;
      case 7:
         this.d = var2.C() * 1258867389;
      }

   }

   int[] D(int var1) {
      int[] var2 = this.P.I(var1, 1509909054);
      if (this.P.D) {
         int var3 = 0;

         int var4;
         for(var4 = this.c * -887199335 + WJ.J[var1]; var4 < 0; var4 += 4096) {
            ;
         }

         while(var4 > 4096) {
            var4 -= 4096;
         }

         while(var3 < this.f * 1685453047 && var4 >= this.e[var3]) {
            ++var3;
         }

         int var5 = var3 - 1;
         boolean var6 = (var3 & 1) == 0;
         int var7 = this.e[var3];
         int var8 = this.e[var3 - 1];
         if (var4 > var8 + this.h * -387493705 && var4 < var7 - -387493705 * this.h) {
            for(int var9 = 0; var9 < WJ.C * -1474554145; ++var9) {
               int var10 = 0;
               int var11 = var6 ? this.k * 642247045 : -(642247045 * this.k);

               int var12;
               for(var12 = WJ.A[var9] + (var11 * this.W * -934471691 >> 12); var12 < 0; var12 += 4096) {
                  ;
               }

               while(var12 > 4096) {
                  var12 -= 4096;
               }

               while(var10 < this.i * -327362403 && var12 >= this.g[var5][var10]) {
                  ++var10;
               }

               int var13 = var10 - 1;
               int var14 = this.g[var5][var13];
               int var15 = this.g[var5][var10];
               if (var12 > -387493705 * this.h + var14 && var12 < var15 - -387493705 * this.h) {
                  var2[var9] = this.R[var5][var13];
               } else {
                  var2[var9] = 0;
               }
            }
         } else {
            TW.I(var2, 0, WJ.C * -1474554145, 0);
         }
      }

      return var2;
   }
}
