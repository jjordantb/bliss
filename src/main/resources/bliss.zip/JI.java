import jaclib.ping.Ping;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class JI implements Runnable {
   volatile long F = -887263504067647559L;
   InetAddress I;
   String a;
   volatile boolean append = true;
   static KJ Z;

   void I(String var1, int var2) {
      try {
         this.a = var1;
         this.I = null;
         this.F = -887263504067647559L;
         if (this.a != null) {
            try {
               this.I = InetAddress.getByName(this.a);
            } catch (UnknownHostException var4) {
               ;
            }
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "f.a(" + ')');
      }
   }

   void I(int var1) {
      try {
         this.append = false;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "f.b(" + ')');
      }
   }

   public void run() {
      try {
         while(this.append) {
            this.F((byte)52);
         }

      } catch (RuntimeException var2) {
         throw DQ.I(var2, "f.run(" + ')');
      }
   }

   void F(byte var1) {
      try {
         if (this.I != null) {
            try {
               byte[] var2 = this.I.getAddress();
               this.F = (long)Ping.a(var2[0], var2[1], var2[2], var2[3], 10000L) * 887263504067647559L;
            } catch (Throwable var3) {
               ;
            }
         }

         KSI.I(1000L);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "f.p(" + ')');
      }
   }

   long Z(int var1) {
      try {
         return this.F * -8472299103493205641L;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "f.f(" + ')');
      }
   }

   public static void I(int var0, byte var1) {
      try {
         if (MU.Z((byte)71)) {
            if (2084404473 * TQ.D != var0) {
               TQ.F = 2742373017286080113L;
            }

            TQ.D = var0 * 2035975497;
            HX.I(3, 1633403726);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "f.x(" + ')');
      }
   }

   static void I(byte var0) {
      try {
         TQ.Z = -1058684408;
         TQ.d = XEI.TI;
         AY.I(-1L == 122690138525332847L * TQ.F, true, "", "", TQ.F * 122690138525332847L);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "f.g(" + ')');
      }
   }

   public static byte I(char var0, int var1) {
      try {
         byte var2;
         if ((var0 <= 0 || var0 >= '\u0080') && (var0 < ' ' || var0 > 'ÿ')) {
            if (var0 == '€') {
               var2 = -128;
            } else if ('‚' == var0) {
               var2 = -126;
            } else if ('ƒ' == var0) {
               var2 = -125;
            } else if (var0 == '„') {
               var2 = -124;
            } else if (var0 == '…') {
               var2 = -123;
            } else if ('†' == var0) {
               var2 = -122;
            } else if ('‡' == var0) {
               var2 = -121;
            } else if ('ˆ' == var0) {
               var2 = -120;
            } else if (var0 == '‰') {
               var2 = -119;
            } else if (var0 == 'Š') {
               var2 = -118;
            } else if ('‹' == var0) {
               var2 = -117;
            } else if ('Œ' == var0) {
               var2 = -116;
            } else if ('Ž' == var0) {
               var2 = -114;
            } else if (var0 == '‘') {
               var2 = -111;
            } else if ('’' == var0) {
               var2 = -110;
            } else if ('“' == var0) {
               var2 = -109;
            } else if (var0 == '”') {
               var2 = -108;
            } else if ('•' == var0) {
               var2 = -107;
            } else if ('–' == var0) {
               var2 = -106;
            } else if ('—' == var0) {
               var2 = -105;
            } else if (var0 == '˜') {
               var2 = -104;
            } else if (var0 == '™') {
               var2 = -103;
            } else if ('š' == var0) {
               var2 = -102;
            } else if ('›' == var0) {
               var2 = -101;
            } else if ('œ' == var0) {
               var2 = -100;
            } else if (var0 == 'ž') {
               var2 = -98;
            } else if (var0 == 'Ÿ') {
               var2 = -97;
            } else {
               var2 = 63;
            }
         } else {
            var2 = (byte)var0;
         }

         return var2;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "f.a(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.J -= -1175642067;
         int var2 = var0.H[var0.J * 681479919];
         int var3 = var0.H[var0.J * 681479919 + 1];
         int var4 = var0.H[var0.J * 681479919 + 2];
         GN.I(6, var2 << 16 | var3, var4, "", -759655050);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "f.alw(" + ')');
      }
   }

   static final void I(SSI var0, int var1) {
      try {
         int var2 = var0.II * -412225079 - XEI.kB * 443738891;
         int var3 = var0.BI * -719582720 + var0.S() * 256;
         int var4 = var0.FI * 1363846656 + var0.S() * 256;
         SF var5 = var0.I().I;
         var0.I((float)((var3 - (int)var5.I) / var2 + (int)var5.I), (float)((int)var5.C), (float)((int)var5.Z + (var4 - (int)var5.Z) / var2));
         var0.cI = 0;
         var0.I(var0.EI * -251594591, (byte)1);
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "f.he(" + ')');
      }
   }
}
