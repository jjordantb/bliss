public class AFI extends LDI {
   String J;
   int append;
   int toString;
   int Z;

   public void method868() {
      PFI.C[796511923 * this.toString].I(1745967363).I(this.J, 1847855163 * this.append, 0, -1158638155 * this.Z, (byte)-93);
   }

   public void method866(int var1) {
      try {
         PFI.C[796511923 * this.toString].I(1923584032).I(this.J, 1847855163 * this.append, 0, -1158638155 * this.Z, (byte)-32);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "xj.f(" + ')');
      }
   }

   AFI(REI var1) {
      super(var1);
      this.toString = var1.C() * -1921544069;
      this.J = var1.E(-1733451894);
      this.append = var1.H((byte)92) * -170815245;
      this.Z = var1.C() * 2118217885;
   }

   public void method869() {
      PFI.C[796511923 * this.toString].I(946944575).I(this.J, 1847855163 * this.append, 0, -1158638155 * this.Z, (byte)-33);
   }

   public static int I(int var0, boolean var1, byte var2) {
      try {
         if (var1) {
            return 0;
         } else {
            DN var3 = CS.I(var0, var1, 547680225);
            if (var3 == null) {
               return AN.L.I(var0, 211542342).L * 1317156085;
            } else {
               int var4 = 0;

               for(int var5 = 0; var5 < var3.E.length; ++var5) {
                  if (-1 == var3.E[var5]) {
                     ++var4;
                  }
               }

               var4 += AN.L.I(var0, 138660103).L * 1317156085 - var3.E.length;
               return var4;
            }
         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "xj.i(" + ')');
      }
   }

   public static final int I(byte var0) {
      try {
         return (int)(1000000000L / (ZE.K * -4639622049358970979L));
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "xj.l(" + ')');
      }
   }
}
