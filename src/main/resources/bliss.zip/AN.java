import java.util.Date;

public class AN {
   static int append = 50;
   static int reverse = 8192;
   static RN I = null;
   static int setTime = 8192;
   static int toString = 0;
   static int Z = 4096;
   static int C = 4096;
   public static int B = 184109511;
   public static boolean D = false;
   public static int F = 2;
   public static int J = -154813479;
   static int S = 16384;
   public static PA A;
   static int E = 0;
   static SE[] G = new SE[50];
   static RN H = null;
   static int K = 16384;
   public static ICI L;

   AN() throws Throwable {
      throw new Error();
   }

   static final void I(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         PO.I(var3, var4, var0, -883658200);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "mm.io(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-33);
         X var4 = IU.F[var2 >> 16];
         NV.I(var3, var4, var0, -617787103);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "mm.nr(" + ')');
      }
   }

   public static String I(long var0, int var2, boolean var3, XW var4, short var5) {
      try {
         char var6 = ',';
         char var7 = '.';
         if (var4 == XW.I) {
            var6 = '.';
            var7 = ',';
         }

         if (var4 == XW.C) {
            var7 = ' ';
         }

         boolean var8 = false;
         if (var0 < 0L) {
            var8 = true;
            var0 = -var0;
         }

         StringBuilder var9 = new StringBuilder(26);
         int var10;
         int var11;
         if (var2 > 0) {
            for(var10 = 0; var10 < var2; ++var10) {
               var11 = (int)var0;
               var0 /= 10L;
               var9.append((char)(var11 + 48 - 10 * (int)var0));
            }

            var9.append(var6);
         }

         var10 = 0;

         while(true) {
            var11 = (int)var0;
            var0 /= 10L;
            var9.append((char)(48 + var11 - (int)var0 * 10));
            if (var0 == 0L) {
               if (var8) {
                  var9.append('-');
               }

               return var9.reverse().toString();
            }

            if (var3) {
               ++var10;
               if (var10 % 3 == 0) {
                  var9.append(var7);
               }
            }
         }
      } catch (RuntimeException var12) {
         throw DQ.I(var12, "mm.i(" + ')');
      }
   }

   static void I(long var0) {
      try {
         WII.C.setTime(new Date(var0));
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "mm.k(" + ')');
      }
   }

   public static void I(int var0, int var1, int var2, int var3, int var4, int var5, String var6, int var7) {
      try {
         PN var8 = new PN();
         var8.D = var0 * 1025727709;
         var8.B = 862924059 * var1;
         var8.S = var2 * -1389157181;
         var8.J = (var4 + XEI.kB * 443738891) * -1019659005;
         var8.F = var3 * 274200991;
         var8.A = var6;
         var8.C = var5 * 334332979;
         XEI.a.I((HN)var8, (int)1639821588);
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "mm.nv(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         int var2 = var0.X[var0.i * 1883543357];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = MI.E.C[var2];
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "mm.c(" + ')');
      }
   }
}
