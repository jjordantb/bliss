public final class IDI {
   int C;
   JX append;

   public void I(byte var1) {
      try {
         if (this.append != null) {
            this.append.I((byte)-68);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "cv.a(" + ')');
      }
   }

   public int I(int var1, int var2) {
      try {
         OK var3 = (OK)this.append.I((long)var1);
         if (var3 != null) {
            return var3.J * -774922497;
         } else {
            OD var4 = LX.B.I(var1, 976929284);
            return 'i' != var4.I ? -1 : 0;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "cv.b(" + ')');
      }
   }

   public int Z(int var1, int var2) {
      try {
         JSI var3 = TY.D.I(var1, -781710328);
         int var4 = -50358139 * var3.Z;
         int var5 = 31 == var3.C * 1394539663 ? -1 : (1 << 1 + var3.C * 1394539663) - 1;
         return (this.I(var4, 1116679673) & var5) >>> -1528472107 * var3.I;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "cv.p(" + ')');
      }
   }

   IDI(int var1) {
      this.C = -1382335519 * var1;
   }

   public void I(int var1, int var2, byte var3) {
      try {
         if (this.append == null) {
            this.append = new JX(1793476641 * this.C);
         }

         OK var4 = (OK)this.append.I((long)var1);
         if (var4 != null) {
            var4.J = var2 * -898670337;
         } else {
            var4 = new OK(var2);
            this.append.I(var4, (long)var1);
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "cv.f(" + ')');
      }
   }

   public static void C(int var0, int var1) {
      try {
         if (617004265 * EDI.I != 0) {
            EDI.F = var0 * -2102749749;
         } else {
            EDI.B.Z(var0, 1891579233);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "cv.k(" + ')');
      }
   }

   static void I(GSI var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      try {
         AP var9 = XEI.mI.T(-1611682495);
         HAI var10 = (HAI)var9.F(var1, var2, var3, 987531084);
         KEI var11;
         int var12;
         int var13;
         int var14;
         if (var10 != null) {
            var11 = XEI.mI.E(-1178105216).C(var10.method32((byte)20));
            var12 = var10.method30((short)12592) & 3;
            var13 = var10.method29(726839210);
            if (-1 != -1204256389 * var11.b) {
               LDI.I(var0, var11, var12, var4, var5, (byte)112);
            } else {
               var14 = var6;
               if (1532834983 * var11.K > 0) {
                  var14 = var7;
               }

               if (var13 == -1976050083 * RW.W.V || -1976050083 * RW.C.V == var13) {
                  if (var12 == 0) {
                     var0.I(var4, var5, 4, var14, (short)23432);
                  } else if (1 == var12) {
                     var0.I(var4, var5, 4, var14, (int)-1904897279);
                  } else if (2 == var12) {
                     var0.I(var4 + 3, var5, 4, var14, (short)29834);
                  } else if (var12 == 3) {
                     var0.I(var4, 3 + var5, 4, var14, (int)-1141905509);
                  }
               }

               if (var13 == -1976050083 * RW.B.V) {
                  if (var12 == 0) {
                     var0.I(var4, var5, 1, 1, var14, (byte)7);
                  } else if (1 == var12) {
                     var0.I(var4 + 3, var5, 1, 1, var14, (byte)7);
                  } else if (var12 == 2) {
                     var0.I(var4 + 3, var5 + 3, 1, 1, var14, (byte)7);
                  } else if (3 == var12) {
                     var0.I(var4, 3 + var5, 1, 1, var14, (byte)7);
                  }
               }

               if (RW.C.V * -1976050083 == var13) {
                  if (var12 == 0) {
                     var0.I(var4, var5, 4, var14, (int)-1677742445);
                  } else if (var12 == 1) {
                     var0.I(3 + var4, var5, 4, var14, (short)29201);
                  } else if (var12 == 2) {
                     var0.I(var4, var5 + 3, 4, var14, (int)-1634037143);
                  } else if (var12 == 3) {
                     var0.I(var4, var5, 4, var14, (short)30949);
                  }
               }
            }
         }

         var10 = (HAI)var9.I(var1, var2, var3, XEI.CF, -1880419927);
         if (var10 != null) {
            var11 = XEI.mI.E(-258471564).C(var10.method32((byte)-26));
            var12 = var10.method30((short)29260) & 3;
            var13 = var10.method29(726839210);
            if (-1204256389 * var11.b != -1) {
               LDI.I(var0, var11, var12, var4, var5, (byte)7);
            } else if (RW.D.V * -1976050083 == var13) {
               var14 = -1118482;
               if (1532834983 * var11.K > 0) {
                  var14 = -1179648;
               }

               if (var12 != 0 && var12 != 2) {
                  var0.Z(var4, var5, 3 + var4, 3 + var5, var14, 1577612026);
               } else {
                  var0.Z(var4, 3 + var5, var4 + 3, var5, var14, 1835700999);
               }
            }
         }

         var10 = (HAI)var9.B(var1, var2, var3, (byte)125);
         if (var10 != null) {
            var11 = XEI.mI.E(541526744).C(var10.method32((byte)49));
            var12 = var10.method30((short)12476) & 3;
            if (-1 != -1204256389 * var11.b) {
               LDI.I(var0, var11, var12, var4, var5, (byte)79);
            }
         }

      } catch (RuntimeException var15) {
         throw DQ.I(var15, "cv.u(" + ')');
      }
   }

   public static void I(int var0, String var1, int var2, int var3) {
      try {
         BSI var4 = OFI.I(HZI.G, var0, -1, -1048089766);
         if (var4 != null) {
            OU var5 = UD.Z(1034965053);
            var5.N = new int[var4.O * -1516159487];
            var5.Z = new String[var4.P * 1787035509];
            var5.Z[0] = var1;
            var5.N[0] = var2;
            FSI.I(var4, 200000, var5, -1502517885);
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "cv.n(" + ')');
      }
   }

   public static int I(int var0, int var1, short var2) {
      try {
         int var3;
         for(var3 = 1; var1 > 1; var1 >>= 1) {
            if ((var1 & 1) != 0) {
               var3 *= var0;
            }

            var0 *= var0;
         }

         if (1 == var1) {
            return var3 * var0;
         } else {
            return var3;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "cv.a(" + ')');
      }
   }

   static void Z(byte var0) {
      try {
         ACI.C = QII.I;
         ACI.B = CV.C;
         OQ.I = BV.E;
         KT.I = WW.C;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "cv.f(" + ')');
      }
   }

   public static void I(KJ var0, byte var1) {
      try {
         DDI.Z = var0.B("p11_full", -1951605663) * 1133798363;
         DDI.I = var0.B("p12_full", -2095742316) * 399685195;
         DDI.A = var0.B("b12_full", -1180441399) * 1666679073;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "cv.a(" + ')');
      }
   }

   public static final int I(int var0, int var1, int var2, int var3, int var4, byte var5) {
      try {
         if (XEI.mI.T(-1611682495) == null) {
            return 0;
         } else {
            if (var4 < 3) {
               LJ var6 = XEI.mI.M(1767942332);
               int var7 = var0 >> 9;
               int var8 = var1 >> 9;
               if (var2 < 0 || var3 < 0 || var2 > XEI.mI.Z(-1972690353) - 1 || var3 > XEI.mI.C(-61619148) - 1) {
                  return 0;
               }

               if (var7 < 1 || var8 < 1 || var7 > XEI.mI.Z(-1988640932) - 1 || var8 > XEI.mI.C(-694658273) - 1) {
                  return 0;
               }

               boolean var9 = (var6.C[1][var0 >> 9][var1 >> 9] & 2) != 0;
               boolean var10;
               boolean var11;
               if ((var0 & 511) == 0) {
                  var10 = (var6.C[1][var7 - 1][var1 >> 9] & 2) != 0;
                  var11 = (var6.C[1][var7][var1 >> 9] & 2) != 0;
                  if (var11 != var10) {
                     var9 = (var6.C[1][var2][var3] & 2) != 0;
                  }
               }

               if ((var1 & 511) == 0) {
                  var10 = (var6.C[1][var0 >> 9][var8 - 1] & 2) != 0;
                  var11 = (var6.C[1][var0 >> 9][var8] & 2) != 0;
                  if (var11 != var10) {
                     var9 = (var6.C[1][var2][var3] & 2) != 0;
                  }
               }

               if (var9) {
                  ++var4;
               }
            }

            return XEI.mI.T(-1611682495).G[var4].I(var0, var1, -1371980258);
         }
      } catch (RuntimeException var12) {
         throw DQ.I(var12, "cv.ja(" + ')');
      }
   }

   public static void B(int var0, int var1) {
      try {
         VK var2 = IV.I(10, (long)var0);
         var2.B(-1412217447);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "cv.z(" + ')');
      }
   }
}
