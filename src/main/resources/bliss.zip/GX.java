public class GX extends EX {
   public int K;

   public GX(IR var1) {
      super(var1, false);
   }
}
