import java.io.IOException;
import java.util.Date;

public class CS implements Runnable {
   boolean J = false;
   Thread append = new Thread(this);
   int I = 0;
   EY get = new EY();
   static KU Z;

   CL I(int var1, FP var2, byte var3) {
      try {
         CL var4 = new CL();
         var4.L = -745165359;
         var4.A = (long)var1 * 1476940603538232441L;
         var4.N = var2;
         var4.K = false;
         this.J(var4, (byte)103);
         return var4;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "kr.b(" + ')');
      }
   }

   CL I(int var1, FP var2, int var3) {
      try {
         CL var4 = new CL();
         var4.L = -248388453;
         EY var5 = this.get;
         synchronized(this.get) {
            for(CL var6 = (CL)this.get.Z(686363137); var6 != null; var6 = (CL)this.get.C(-852978429)) {
               if ((long)var1 == -5533549728640346679L * var6.A && var2 == var6.N && -1906220653 * var6.L == 2) {
                  var4.O = var6.O;
                  var4.G = false;
                  return var4;
               }
            }
         }

         var4.O = var2.I(var1, -250604251);
         var4.G = false;
         var4.K = true;
         return var4;
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "kr.a(" + ')');
      }
   }

   CL I(int var1, byte[] var2, FP var3, int var4) {
      try {
         CL var5 = new CL();
         var5.L = -496776906;
         var5.A = 1476940603538232441L * (long)var1;
         var5.O = var2;
         var5.N = var3;
         var5.K = false;
         this.J(var5, (byte)39);
         return var5;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "kr.f(" + ')');
      }
   }

   void J(CL var1, byte var2) {
      try {
         EY var3 = this.get;
         synchronized(this.get) {
            this.get.I(var1, (byte)-98);
            this.I += 872113935;
            this.get.notifyAll();
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "kr.p(" + ')');
      }
   }

   public void run() {
      try {
         while(!this.J) {
            EY var2 = this.get;
            CL var1;
            synchronized(this.get) {
               var1 = (CL)this.get.I(-2118324639);
               if (var1 == null) {
                  try {
                     this.get.wait();
                  } catch (InterruptedException var5) {
                     ;
                  }
                  continue;
               }

               this.I -= 872113935;
            }

            try {
               if (-1906220653 * var1.L == 2) {
                  var1.N.I((int)(var1.A * -5533549728640346679L), var1.O, var1.O.length, 267663991);
               } else if (3 == var1.L * -1906220653) {
                  var1.O = var1.N.I((int)(-5533549728640346679L * var1.A), -250604251);
               }
            } catch (Exception var4) {
               KSI.I((String)null, var4, (short)666);
            }

            var1.G = false;
         }

      } catch (RuntimeException var7) {
         throw DQ.I(var7, "kr.run(" + ')');
      }
   }

   public CS() {
      this.append.setDaemon(true);
      this.append.start();
      this.append.setPriority(1);
   }

   public void I(int var1) {
      try {
         this.J = true;
         EY var2 = this.get;
         synchronized(this.get) {
            this.get.notifyAll();
         }

         try {
            this.append.join();
         } catch (InterruptedException var3) {
            ;
         }

         this.append = null;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "kr.i(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.j.Z((byte)12) ? 1 : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "kr.anz(" + ')');
      }
   }

   public static void I(String var0, int var1) {
      try {
         if (GDI.A == null) {
            DT.C(-219758847);
         }

         XEI.XZ.setTime(new Date(CI.I((byte)1)));
         int var2 = XEI.XZ.get(11);
         int var3 = XEI.XZ.get(12);
         int var4 = XEI.XZ.get(13);
         String var5 = Integer.toString(var2 / 10) + var2 % 10 + ":" + var3 / 10 + var3 % 10 + ":" + var4 / 10 + var4 % 10;
         String[] var6 = HR.I(var0, '\n', 1593698305);

         for(int var7 = 0; var7 < var6.length; ++var7) {
            for(int var8 = -2035787443 * GDI.B; var8 > 0; --var8) {
               GDI.A[var8] = GDI.A[var8 - 1];
            }

            GDI.A[0] = var5 + ": " + var6[var7];
            if (ADI.F != null) {
               try {
                  ADI.F.write(SDI.I((CharSequence)(GDI.A[0] + "\n"), 6758905));
               } catch (IOException var9) {
                  ;
               }
            }

            if (GDI.B * -2035787443 < GDI.A.length - 1) {
               GDI.B += 674924421;
               if (GDI.D * -1731316011 > 0) {
                  GDI.D += 205738621;
               }
            }
         }

      } catch (RuntimeException var10) {
         throw DQ.I(var10, "kr.n(" + ')');
      }
   }

   public static XZI I(int var0, int var1) {
      try {
         XZI[] var2 = VO.I((byte)-107);
         XZI[] var3 = var2;

         for(int var4 = 0; var4 < var3.length; ++var4) {
            XZI var5 = var3[var4];
            if (-509770143 * var5.Z == var0) {
               return var5;
            }
         }

         return null;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "kr.f(" + ')');
      }
   }

   static DN I(int var0, boolean var1, int var2) {
      try {
         long var3 = (long)(var0 | (var1 ? Integer.MIN_VALUE : 0));
         return (DN)DN.S.I(var3);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "kr.k(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         JZI.I(var3, var4, var0, (byte)20);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "kr.le(" + ')');
      }
   }

   public static LZI I(KJ var0, int var1, int var2) {
      try {
         byte[] var3 = var0.I(var1, (byte)105);
         return var3 == null ? null : new LZI(var3);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "kr.f(" + ')');
      }
   }

   static final void I(IR var0, int var1, int var2) {
      try {
         BFI.I(var0, var1, false, -630739459);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "kr.ju(" + ')');
      }
   }
}
