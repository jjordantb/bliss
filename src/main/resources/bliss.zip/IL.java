public abstract class IL extends QK {
   volatile boolean G = true;
   boolean H;
   boolean K;

   abstract byte[] method3465(short var1);

   abstract byte[] method3466();

   abstract byte[] method3467();

   abstract int method3468(int var1);

   abstract byte[] method3469();

   abstract int method3470();

   abstract int method3471();

   abstract int method3472();
}
