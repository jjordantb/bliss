public class Exception_Sub2_Sub1 extends Exception_Sub2 {
   Exception_Sub2_Sub1(String var1, boolean var2) {
      super(var1);
   }

   Exception_Sub2_Sub1(String var1) {
      this(var1, false);
   }
}
