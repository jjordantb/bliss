public class GA {
   int I;
   static int Z = 22050;
   int C;
   YS[] B = new YS[10];

   GA(REI var1) {
      for(int var2 = 0; var2 < 10; ++var2) {
         int var3 = var1.I();
         if (var3 != 0) {
            var1.A -= 116413311;
            this.B[var2] = new YS();
            this.B[var2].I(var1);
         }
      }

      this.C = var1.C();
      this.I = var1.C();
   }

   public NG I() {
      byte[] var1 = this.C();
      return new NG(22050, var1, 22050 * this.C / 1000, 22050 * this.I / 1000);
   }

   public final int Z() {
      int var1 = 9999999;

      int var2;
      for(var2 = 0; var2 < 10; ++var2) {
         if (this.B[var2] != null && this.B[var2].L / 20 < var1) {
            var1 = this.B[var2].L / 20;
         }
      }

      if (this.C < this.I && this.C / 20 < var1) {
         var1 = this.C / 20;
      }

      if (var1 != 9999999 && var1 != 0) {
         for(var2 = 0; var2 < 10; ++var2) {
            if (this.B[var2] != null) {
               this.B[var2].L -= var1 * 20;
            }
         }

         if (this.C < this.I) {
            this.C -= var1 * 20;
            this.I -= var1 * 20;
         }

         return var1;
      } else {
         return 0;
      }
   }

   final byte[] C() {
      int var1 = 0;

      int var2;
      for(var2 = 0; var2 < 10; ++var2) {
         if (this.B[var2] != null && this.B[var2].K + this.B[var2].L > var1) {
            var1 = this.B[var2].K + this.B[var2].L;
         }
      }

      if (var1 == 0) {
         return new byte[0];
      } else {
         var2 = 22050 * var1 / 1000;
         byte[] var3 = new byte[var2];

         for(int var4 = 0; var4 < 10; ++var4) {
            if (this.B[var4] != null) {
               int var5 = this.B[var4].K * 22050 / 1000;
               int var6 = this.B[var4].L * 22050 / 1000;
               int[] var7 = this.B[var4].I(var5, this.B[var4].K);

               for(int var8 = 0; var8 < var5; ++var8) {
                  int var9 = var3[var8 + var6] + (var7[var8] >> 8);
                  if ((var9 + 128 & -256) != 0) {
                     var9 = var9 >> 31 ^ 127;
                  }

                  var3[var8 + var6] = (byte)var9;
               }
            }
         }

         return var3;
      }
   }

   public static GA I(KJ var0, int var1, int var2) {
      byte[] var3 = var0.I(var1, var2, (byte)-90);
      return var3 == null ? null : new GA(new REI(var3));
   }
}
