public class KDI {
   static int XA;
   static int qa;
   static int I;
   static int[] Z;
   static int C;
   static int B;
   static int D;
   static int F;

   public static void I(GSI var0, int[] var1, int var2) {
      XA(var0, var1, 0, var1.length, var2, (int[])null, (int[])null);
   }

   public static void I(GSI var0, int[] var1, int var2, int[] var3, int[] var4) {
      XA(var0, var1, 0, var1.length, var2, var3, var4);
   }

   static void XA(GSI var0, int[] var1, int var2, int var3, int var4, int[] var5, int[] var6) {
      int[] var7 = new int[4];
      var0.qa(var7);
      if (var5 != null && var7[3] - var7[1] != var5.length) {
         throw new IllegalStateException();
      } else {
         qa();
         qa(var1, var2, var3);
         XA(var7[1]);

         while(true) {
            int var8;
            int var9;
            int var10;
            do {
               if (!qa(var7[3])) {
                  return;
               }

               var8 = qa;
               var9 = I;
               var10 = C;
               if (var5 == null) {
                  break;
               }

               int var11 = var10 - var7[1];
               if (var8 < var5[var11] + var7[0]) {
                  var8 = var5[var11] + var7[0];
               }

               if (var9 > var5[var11] + var6[var11] + var7[0]) {
                  var9 = var5[var11] + var6[var11] + var7[0];
               }
            } while(var9 - var8 <= 0);

            var0.XA(var8, var10, var9 - var8, var4, 1);
         }
      }
   }

   static void qa(int[] var0, int var1, int var2) {
      int var3 = XA + (var2 << 1);
      int var5;
      if (Z == null || Z.length < var3) {
         int[] var4 = new int[var3];

         for(var5 = 0; var5 < XA; ++var5) {
            var4[var5] = Z[var5];
         }

         Z = var4;
      }

      var2 += var1;
      int var8 = var2 - 2;

      for(var5 = var1; var5 < var2; var5 += 2) {
         int var6 = var0[var8 + 1];
         int var7 = var0[var5 + 1];
         if (var6 < var7) {
            Z[XA++] = var0[var8];
            Z[XA++] = var6;
            Z[XA++] = var0[var5];
            Z[XA++] = var7;
         } else if (var7 < var6) {
            Z[XA++] = var0[var5];
            Z[XA++] = var7;
            Z[XA++] = var0[var8];
            Z[XA++] = var6;
         }

         var8 = var5;
      }

   }

   static void XA(int var0) {
      if (XA < 0) {
         F = 0;
         D = 0;
         B = 0;
         C = 2147483646;
      } else {
         XA(0, XA);
         int var1 = Z[1];
         if (var1 < var0) {
            var1 = var0;
         }

         byte var2 = 0;

         int var3;
         for(var3 = 0; var3 < XA; var3 += 4) {
            int var4 = Z[var3 + 1];
            if (var1 < var4) {
               break;
            }

            int var5 = Z[var3];
            int var6 = Z[var3 + 2];
            int var7 = Z[var3 + 3];
            int var8 = (var6 - var5 << 16) / (var7 - var4);
            int var9 = (var5 << 16) + '耀';
            Z[var3] = var9 + (var1 - var4) * var8;
            Z[var3 + 2] = var8;
         }

         B = var2;
         D = var3;
         F = var3;
         C = var1 - 1;
      }

   }

   static boolean qa(int var0) {
      int var1 = D;
      int var2 = F;

      int var4;
      for(int var3 = C; var2 >= var1; var2 = var4) {
         ++var3;
         C = var3;
         if (var3 >= var0) {
            return false;
         }

         int var5;
         int var6;
         for(var4 = B; var1 < XA; var1 += 4) {
            var5 = Z[var1 + 1];
            if (var3 < var5) {
               break;
            }

            var6 = Z[var1];
            int var7 = Z[var1 + 2];
            int var8 = Z[var1 + 3];
            int var9 = (var7 - var6 << 16) / (var8 - var5);
            int var10 = (var6 << 16) + '耀';
            Z[var1] = var10;
            Z[var1 + 2] = var9;
         }

         for(var5 = var4; var5 < var1; var5 += 4) {
            var6 = Z[var5 + 3];
            if (var3 >= var6) {
               Z[var5] = Z[var4];
               Z[var5 + 1] = Z[var4 + 1];
               Z[var5 + 2] = Z[var4 + 2];
               Z[var5 + 3] = Z[var4 + 3];
               var4 += 4;
            }
         }

         if (var4 == XA) {
            XA = 0;
            return false;
         }

         qa(var4, var1);
         B = var4;
         D = var1;
      }

      qa = Z[var2] >> 16;
      I = Z[var2 + 4] >> 16;
      Z[var2] += Z[var2 + 2];
      Z[var2 + 4] += Z[var2 + 6];
      var2 += 8;
      F = var2;
      return true;
   }

   static void XA(int var0, int var1) {
      if (var1 > var0 + 4) {
         int var2 = var0;
         int var3 = Z[var0];
         int var4 = Z[var0 + 1];
         int var5 = Z[var0 + 2];
         int var6 = Z[var0 + 3];

         for(int var7 = var0 + 4; var7 < var1; var7 += 4) {
            int var8 = Z[var7 + 1];
            if (var8 < var4) {
               Z[var2] = Z[var7];
               Z[var2 + 1] = var8;
               Z[var2 + 2] = Z[var7 + 2];
               Z[var2 + 3] = Z[var7 + 3];
               var2 += 4;
               Z[var7] = Z[var2];
               Z[var7 + 1] = Z[var2 + 1];
               Z[var7 + 2] = Z[var2 + 2];
               Z[var7 + 3] = Z[var2 + 3];
            }
         }

         Z[var2] = var3;
         Z[var2 + 1] = var4;
         Z[var2 + 2] = var5;
         Z[var2 + 3] = var6;
         XA(var0, var2);
         XA(var2 + 4, var1);
      }

   }

   static void qa() {
      XA = 0;
   }

   KDI() throws Throwable {
      throw new Error();
   }

   static void qa(int var0, int var1) {
      while(true) {
         if (var1 >= var0 + 8) {
            boolean var2 = true;

            for(int var3 = var0 + 4; var3 < var1; var3 += 4) {
               int var4 = Z[var3 - 4];
               int var5 = Z[var3];
               if (var4 > var5) {
                  var2 = false;
                  Z[var3 - 4] = var5;
                  Z[var3] = var4;
                  var4 = Z[var3 - 2];
                  Z[var3 - 2] = Z[var3 + 2];
                  Z[var3 + 2] = var4;
                  var4 = Z[var3 - 1];
                  Z[var3 - 1] = Z[var3 + 3];
                  Z[var3 + 3] = var4;
               }
            }

            if (!var2) {
               var1 -= 4;
               continue;
            }
         }

         return;
      }
   }
}
