import jaggl.OpenGL;

public class GII extends RY {
   static String F = "varying vec3 wvVertex;\nvarying float waterDepth;\nuniform vec3 sunDir;\nuniform vec4 sunColour;\nuniform float sunExponent;\nuniform float breakWaterDepth;\nuniform float breakWaterOffset;\nuniform sampler3D normalSampler;\nuniform samplerCube envMapSampler;\nvoid main() {\nvec4 wnNormal = texture3D(normalSampler, gl_TexCoord[0].xyz).rbga;\nwnNormal.xyz = 2.0*wnNormal.xyz-1.0;\nvec3 wnVector = normalize(wvVertex);\nvec3 wnReflection = reflect(wnVector, wnNormal.xyz);\nvec3 envColour = textureCube(envMapSampler, wnReflection).rgb;\nvec4 specularColour = sunColour*pow(clamp(-dot(sunDir, wnReflection), 0.0, 1.0), sunExponent);\nfloat shoreFactor = clamp(waterDepth/breakWaterDepth-breakWaterOffset*wnNormal.w, 0.0, 1.0);\nfloat ndote = dot(wnVector, wnNormal.xyz);\nfloat fresnel = pow(1.0-abs(ndote), 2.0);\nvec4 surfaceColour = vec4(envColour, fresnel*shoreFactor)+specularColour*shoreFactor;\ngl_FragColor = vec4(mix(surfaceColour.rgb, gl_Fog.color.rgb, gl_FogFragCoord), surfaceColour.a);\n}\n";
   boolean abs = false;
   static String glGetUniformLocation = "uniform float time;\nuniform float scale;\nvarying vec3 wvVertex;\nvarying float waterDepth;\nvoid main() {\nwaterDepth = gl_MultiTexCoord0.z;\nvec4 ecVertex = gl_ModelViewMatrix*gl_Vertex;\nwvVertex.x = dot(gl_NormalMatrix[0], ecVertex.xyz);\nwvVertex.y = dot(gl_NormalMatrix[1], ecVertex.xyz);\nwvVertex.z = dot(gl_NormalMatrix[2], ecVertex.xyz);\ngl_TexCoord[0].x = dot(gl_TextureMatrix[0][0], gl_MultiTexCoord0)*scale;\ngl_TexCoord[0].y = dot(gl_TextureMatrix[0][1], gl_MultiTexCoord0)*scale;\ngl_TexCoord[0].z = time;\ngl_TexCoord[0].w = 1.0;\ngl_FogFragCoord = clamp((ecVertex.z-gl_Fog.start)*gl_Fog.scale, 0.0, 1.0);\ngl_Position = ftransform();\n}\n";
   boolean glUniform1f = false;
   YA glUniform1i;
   VX glUniform3f;

   void method509(boolean var1) {
   }

   void method511() {
      if (this.glUniform1f) {
         this.I.C(1);
         this.I.I((SN)null);
         this.I.C(0);
         this.I.I((SN)null);
         OpenGL.glUseProgram(0);
         this.glUniform1f = false;
      }

   }

   void method505(boolean var1) {
      DO var2 = this.I.E();
      if (this.abs && var2 != null) {
         this.I.C(1);
         this.I.I((SN)var2);
         this.I.C(0);
         this.I.I((SN)this.glUniform3f.E);
         int var3 = this.glUniform1i.I;
         OpenGL.glUseProgram(var3);
         OpenGL.glUniform1i(OpenGL.glGetUniformLocation(var3, "normalSampler"), 0);
         OpenGL.glUniform1i(OpenGL.glGetUniformLocation(var3, "envMapSampler"), 1);
         OpenGL.glUniform3f(OpenGL.glGetUniformLocation(var3, "sunDir"), -this.I.e[0], -this.I.e[1], -this.I.e[2]);
         OpenGL.glUniform4f(OpenGL.glGetUniformLocation(var3, "sunColour"), this.I.g, this.I.h, this.I.TI, 1.0F);
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var3, "sunExponent"), 96.0F + Math.abs(this.I.e[1]) * 928.0F);
         this.glUniform1f = true;
      }

   }

   void method518(boolean var1) {
   }

   void method504() {
      if (this.glUniform1f) {
         this.I.C(1);
         this.I.I((SN)null);
         this.I.C(0);
         this.I.I((SN)null);
         OpenGL.glUseProgram(0);
         this.glUniform1f = false;
      }

   }

   void method503(int var1, int var2) {
      if (this.glUniform1f) {
         int var3 = 1 << (var1 & 3);
         float var4 = (float)(1 << (var1 >> 3 & 7)) / 32.0F;
         int var5 = var2 & '\uffff';
         float var6 = (float)(var2 >> 16 & 3) / 8.0F;
         int var7 = this.glUniform1i.I;
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var7, "time"), (float)(var3 * this.I.E % '鱀') / 40000.0F);
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var7, "scale"), var4);
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var7, "breakWaterDepth"), (float)var5);
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var7, "breakWaterOffset"), var6);
      }

   }

   void method500(SN var1, int var2) {
      if (!this.glUniform1f) {
         this.I.I(var1);
         this.I.I(var2);
      }

   }

   void method506(boolean var1) {
      DO var2 = this.I.E();
      if (this.abs && var2 != null) {
         this.I.C(1);
         this.I.I((SN)var2);
         this.I.C(0);
         this.I.I((SN)this.glUniform3f.E);
         int var3 = this.glUniform1i.I;
         OpenGL.glUseProgram(var3);
         OpenGL.glUniform1i(OpenGL.glGetUniformLocation(var3, "normalSampler"), 0);
         OpenGL.glUniform1i(OpenGL.glGetUniformLocation(var3, "envMapSampler"), 1);
         OpenGL.glUniform3f(OpenGL.glGetUniformLocation(var3, "sunDir"), -this.I.e[0], -this.I.e[1], -this.I.e[2]);
         OpenGL.glUniform4f(OpenGL.glGetUniformLocation(var3, "sunColour"), this.I.g, this.I.h, this.I.TI, 1.0F);
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var3, "sunExponent"), 96.0F + Math.abs(this.I.e[1]) * 928.0F);
         this.glUniform1f = true;
      }

   }

   void method507(boolean var1) {
      DO var2 = this.I.E();
      if (this.abs && var2 != null) {
         this.I.C(1);
         this.I.I((SN)var2);
         this.I.C(0);
         this.I.I((SN)this.glUniform3f.E);
         int var3 = this.glUniform1i.I;
         OpenGL.glUseProgram(var3);
         OpenGL.glUniform1i(OpenGL.glGetUniformLocation(var3, "normalSampler"), 0);
         OpenGL.glUniform1i(OpenGL.glGetUniformLocation(var3, "envMapSampler"), 1);
         OpenGL.glUniform3f(OpenGL.glGetUniformLocation(var3, "sunDir"), -this.I.e[0], -this.I.e[1], -this.I.e[2]);
         OpenGL.glUniform4f(OpenGL.glGetUniformLocation(var3, "sunColour"), this.I.g, this.I.h, this.I.TI, 1.0F);
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var3, "sunExponent"), 96.0F + Math.abs(this.I.e[1]) * 928.0F);
         this.glUniform1f = true;
      }

   }

   void method508(boolean var1) {
   }

   void method519(SN var1, int var2) {
      if (!this.glUniform1f) {
         this.I.I(var1);
         this.I.I(var2);
      }

   }

   void method510(boolean var1) {
   }

   void method513(int var1, int var2) {
      if (this.glUniform1f) {
         int var3 = 1 << (var1 & 3);
         float var4 = (float)(1 << (var1 >> 3 & 7)) / 32.0F;
         int var5 = var2 & '\uffff';
         float var6 = (float)(var2 >> 16 & 3) / 8.0F;
         int var7 = this.glUniform1i.I;
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var7, "time"), (float)(var3 * this.I.E % '鱀') / 40000.0F);
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var7, "scale"), var4);
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var7, "breakWaterDepth"), (float)var5);
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var7, "breakWaterOffset"), var6);
      }

   }

   void method512() {
      if (this.glUniform1f) {
         this.I.C(1);
         this.I.I((SN)null);
         this.I.C(0);
         this.I.I((SN)null);
         OpenGL.glUseProgram(0);
         this.glUniform1f = false;
      }

   }

   boolean method501() {
      return this.abs;
   }

   void method502(int var1, int var2) {
      if (this.glUniform1f) {
         int var3 = 1 << (var1 & 3);
         float var4 = (float)(1 << (var1 >> 3 & 7)) / 32.0F;
         int var5 = var2 & '\uffff';
         float var6 = (float)(var2 >> 16 & 3) / 8.0F;
         int var7 = this.glUniform1i.I;
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var7, "time"), (float)(var3 * this.I.E % '鱀') / 40000.0F);
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var7, "scale"), var4);
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var7, "breakWaterDepth"), (float)var5);
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var7, "breakWaterOffset"), var6);
      }

   }

   void method516(int var1, int var2) {
      if (this.glUniform1f) {
         int var3 = 1 << (var1 & 3);
         float var4 = (float)(1 << (var1 >> 3 & 7)) / 32.0F;
         int var5 = var2 & '\uffff';
         float var6 = (float)(var2 >> 16 & 3) / 8.0F;
         int var7 = this.glUniform1i.I;
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var7, "time"), (float)(var3 * this.I.E % '鱀') / 40000.0F);
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var7, "scale"), var4);
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var7, "breakWaterDepth"), (float)var5);
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var7, "breakWaterOffset"), var6);
      }

   }

   GII(MJI var1, VX var2) {
      super(var1);
      this.glUniform3f = var2;
      if (this.glUniform3f.E != null && this.I.KI && this.I.R) {
         HII var3 = HII.I(this.I, 35633, "uniform float time;\nuniform float scale;\nvarying vec3 wvVertex;\nvarying float waterDepth;\nvoid main() {\nwaterDepth = gl_MultiTexCoord0.z;\nvec4 ecVertex = gl_ModelViewMatrix*gl_Vertex;\nwvVertex.x = dot(gl_NormalMatrix[0], ecVertex.xyz);\nwvVertex.y = dot(gl_NormalMatrix[1], ecVertex.xyz);\nwvVertex.z = dot(gl_NormalMatrix[2], ecVertex.xyz);\ngl_TexCoord[0].x = dot(gl_TextureMatrix[0][0], gl_MultiTexCoord0)*scale;\ngl_TexCoord[0].y = dot(gl_TextureMatrix[0][1], gl_MultiTexCoord0)*scale;\ngl_TexCoord[0].z = time;\ngl_TexCoord[0].w = 1.0;\ngl_FogFragCoord = clamp((ecVertex.z-gl_Fog.start)*gl_Fog.scale, 0.0, 1.0);\ngl_Position = ftransform();\n}\n");
         HII var4 = HII.I(this.I, 35632, "varying vec3 wvVertex;\nvarying float waterDepth;\nuniform vec3 sunDir;\nuniform vec4 sunColour;\nuniform float sunExponent;\nuniform float breakWaterDepth;\nuniform float breakWaterOffset;\nuniform sampler3D normalSampler;\nuniform samplerCube envMapSampler;\nvoid main() {\nvec4 wnNormal = texture3D(normalSampler, gl_TexCoord[0].xyz).rbga;\nwnNormal.xyz = 2.0*wnNormal.xyz-1.0;\nvec3 wnVector = normalize(wvVertex);\nvec3 wnReflection = reflect(wnVector, wnNormal.xyz);\nvec3 envColour = textureCube(envMapSampler, wnReflection).rgb;\nvec4 specularColour = sunColour*pow(clamp(-dot(sunDir, wnReflection), 0.0, 1.0), sunExponent);\nfloat shoreFactor = clamp(waterDepth/breakWaterDepth-breakWaterOffset*wnNormal.w, 0.0, 1.0);\nfloat ndote = dot(wnVector, wnNormal.xyz);\nfloat fresnel = pow(1.0-abs(ndote), 2.0);\nvec4 surfaceColour = vec4(envColour, fresnel*shoreFactor)+specularColour*shoreFactor;\ngl_FragColor = vec4(mix(surfaceColour.rgb, gl_Fog.color.rgb, gl_FogFragCoord), surfaceColour.a);\n}\n");
         this.glUniform1i = YA.I(this.I, new HII[]{var3, var4});
         this.abs = this.glUniform1i != null;
      }

   }

   void method517(int var1, int var2) {
      if (this.glUniform1f) {
         int var3 = 1 << (var1 & 3);
         float var4 = (float)(1 << (var1 >> 3 & 7)) / 32.0F;
         int var5 = var2 & '\uffff';
         float var6 = (float)(var2 >> 16 & 3) / 8.0F;
         int var7 = this.glUniform1i.I;
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var7, "time"), (float)(var3 * this.I.E % '鱀') / 40000.0F);
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var7, "scale"), var4);
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var7, "breakWaterDepth"), (float)var5);
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var7, "breakWaterOffset"), var6);
      }

   }

   void method514(SN var1, int var2) {
      if (!this.glUniform1f) {
         this.I.I(var1);
         this.I.I(var2);
      }

   }

   void method515(int var1, int var2) {
      if (this.glUniform1f) {
         int var3 = 1 << (var1 & 3);
         float var4 = (float)(1 << (var1 >> 3 & 7)) / 32.0F;
         int var5 = var2 & '\uffff';
         float var6 = (float)(var2 >> 16 & 3) / 8.0F;
         int var7 = this.glUniform1i.I;
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var7, "time"), (float)(var3 * this.I.E % '鱀') / 40000.0F);
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var7, "scale"), var4);
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var7, "breakWaterDepth"), (float)var5);
         OpenGL.glUniform1f(OpenGL.glGetUniformLocation(var7, "breakWaterOffset"), var6);
      }

   }

   boolean method520() {
      return this.abs;
   }
}
