import java.util.Stack;

public final class BDI {
   JX C;
   int Z;
   public static int I;

   BDI(int var1) {
      this.Z = 547036117 * var1;
   }

   public void I(int var1, int var2, int var3) {
      try {
         if (this.C == null) {
            this.C = new JX(-1623767683 * this.Z);
         }

         OK var4 = (OK)this.C.I((long)var1);
         if (var4 != null) {
            var4.J = -898670337 * var2;
         } else {
            var4 = new OK(var2);
            this.C.I(var4, (long)var1);
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "cz.f(" + ')');
      }
   }

   public int I(int var1, byte var2) {
      try {
         BX var3 = UDI.D.Z(var1, -1438180456);
         int var4 = var3.Z * -1979044991;
         int var5 = 31 == var3.I * -1638834999 ? -1 : (1 << var3.I * -1638834999 + 1) - 1;
         return (this.I(var4, -1967259188) & var5) >>> -2127213381 * var3.C;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "cz.p(" + ')');
      }
   }

   public void I(byte var1) {
      try {
         if (this.C != null) {
            this.C.I((byte)-14);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "cz.a(" + ')');
      }
   }

   public int I(int var1, int var2) {
      try {
         OK var3 = (OK)this.C.I((long)var1);
         if (var3 != null) {
            return var3.J * -774922497;
         } else {
            PII var4 = NW.J.I(var1, 1792178977);
            return 'i' != var4.I ? -1 : 0;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "cz.b(" + ')');
      }
   }

   public static KP I(boolean var0, int var1) {
      try {
         Stack var2 = KP.B;
         synchronized(KP.B) {
            KP var3;
            if (KP.B.isEmpty()) {
               var3 = new KP();
            } else {
               var3 = (KP)KP.B.pop();
            }

            var3.Z = var0;
            return var3;
         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "cz.a(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)73);
         X var4 = IU.F[var2 >> 16];
         QO.I(var3, var4, var0, -1870622749);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "cz.cn(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         BU.I(var3, var4, var0, (byte)-38);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "cz.dd(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, short var3) {
      try {
         int var4 = var2.H[(var2.J -= -391880689) * 681479919];
         if (var4 != var0.FC * 1347982601) {
            if (-1 != var4) {
               if (var0.j == null) {
                  var0.j = new AX();
               }

               var0.j.I(var4, -1614086942);
            } else {
               var0.j = null;
            }

            var0.FC = 1587382585 * var4;
            VEI.I(var0, -1503687245);
         }

         if (-1 == -1309843523 * var0.a && !var1.I) {
            FR.Z(-440872681 * var0.V, -1349352488);
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "cz.eu(" + ')');
      }
   }

   public static String I(YK var0, int var1) {
      try {
         return !FX.G && var0 != null ? var0.T : "";
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "cz.az(" + ')');
      }
   }
}
