public class JK extends YG {
   int Q = 0;
   int R = -1452716032;
   int T = 0;
   int U = 2092275712;
   int V = -2143252480;
   int W = 113614848;
   int X = -1105127424;

   void Z() {
      WJ.I((byte)41);
   }

   int[] Z(int var1, int var2) {
      try {
         int[] var3 = this.P.I(var1, 1326097186);
         if (this.P.D) {
            int var4 = WJ.J[var1] - 2048;

            for(int var5 = 0; var5 < WJ.C * -1474554145; ++var5) {
               int var6 = WJ.A[var5] - 2048;
               int var7 = this.U * -1801516933 + var6;
               var7 = var7 < -2048 ? var7 + 4096 : var7;
               var7 = var7 > 2048 ? var7 - 4096 : var7;
               int var8 = var4 + 351466605 * this.Q;
               var8 = var8 < -2048 ? 4096 + var8 : var8;
               var8 = var8 > 2048 ? var8 - 4096 : var8;
               int var9 = -670406741 * this.T + var6;
               var9 = var9 < -2048 ? 4096 + var9 : var9;
               var9 = var9 > 2048 ? var9 - 4096 : var9;
               int var10 = var4 + this.X * 939068299;
               var10 = var10 < -2048 ? 4096 + var10 : var10;
               var10 = var10 > 2048 ? var10 - 4096 : var10;
               var3[var5] = !this.toString(var7, var8, 1631373907) && !this.append(var9, var10, 689077390) ? 0 : 4096;
            }
         }

         return var3;
      } catch (RuntimeException var11) {
         throw DQ.I(var11, "aie.i(" + ')');
      }
   }

   void B(int var1) {
      try {
         WJ.I((byte)-3);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aie.x(" + ')');
      }
   }

   boolean append(int var1, int var2, int var3) {
      try {
         int var4 = -1052090709 * this.V * (var1 + var2) >> 12;
         int var5 = WJ.E[255 * var4 >> 12 & 255];
         var5 = (var5 << 12) / (this.V * -1052090709);
         var5 = (var5 << 12) / (454265253 * this.W);
         var5 = var5 * 679642301 * this.R >> 12;
         return var2 - var1 < var5 && var2 - var1 > -var5;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "aie.am(" + ')');
      }
   }

   boolean toString(int var1, int var2, int var3) {
      try {
         int var4 = (var2 - var1) * -1052090709 * this.V >> 12;
         int var5 = WJ.E[255 * var4 >> 12 & 255];
         var5 = (var5 << 12) / (-1052090709 * this.V);
         var5 = (var5 << 12) / (454265253 * this.W);
         var5 = var5 * this.R * 679642301 >> 12;
         return var1 + var2 < var5 && var1 + var2 > -var5;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "aie.ac(" + ')');
      }
   }

   int[] append(int var1) {
      int[] var2 = this.P.I(var1, 682412629);
      if (this.P.D) {
         int var3 = WJ.J[var1] - 2048;

         for(int var4 = 0; var4 < WJ.C * -1474554145; ++var4) {
            int var5 = WJ.A[var4] - 2048;
            int var6 = this.U * -1801516933 + var5;
            var6 = var6 < -2048 ? var6 + 4096 : var6;
            var6 = var6 > 2048 ? var6 - 4096 : var6;
            int var7 = var3 + 351466605 * this.Q;
            var7 = var7 < -2048 ? 4096 + var7 : var7;
            var7 = var7 > 2048 ? var7 - 4096 : var7;
            int var8 = -670406741 * this.T + var5;
            var8 = var8 < -2048 ? 4096 + var8 : var8;
            var8 = var8 > 2048 ? var8 - 4096 : var8;
            int var9 = var3 + this.X * 939068299;
            var9 = var9 < -2048 ? 4096 + var9 : var9;
            var9 = var9 > 2048 ? var9 - 4096 : var9;
            var2[var4] = !this.toString(var6, var7, 838244364) && !this.append(var8, var9, 424769104) ? 0 : 4096;
         }
      }

      return var2;
   }

   void append() {
      WJ.I((byte)-73);
   }

   void I() {
      WJ.I((byte)-116);
   }

   void I(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.U = var2.C() * -2115004749;
         break;
      case 1:
         this.Q = var2.C() * -925420187;
         break;
      case 2:
         this.T = var2.C() * -871015677;
         break;
      case 3:
         this.X = var2.C() * -1141390301;
         break;
      case 4:
         this.V = var2.C() * 1435675651;
         break;
      case 5:
         this.R = var2.C() * -1402300779;
         break;
      case 6:
         this.W = var2.C() * 233322029;
      }

   }

   void I(int var1, REI var2, byte var3) {
      try {
         switch(var1) {
         case 0:
            this.U = var2.C() * -2115004749;
            break;
         case 1:
            this.Q = var2.C() * -925420187;
            break;
         case 2:
            this.T = var2.C() * -871015677;
            break;
         case 3:
            this.X = var2.C() * -1141390301;
            break;
         case 4:
            this.V = var2.C() * 1435675651;
            break;
         case 5:
            this.R = var2.C() * -1402300779;
            break;
         case 6:
            this.W = var2.C() * 233322029;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aie.r(" + ')');
      }
   }

   void Z(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.U = var2.C() * -2115004749;
         break;
      case 1:
         this.Q = var2.C() * -925420187;
         break;
      case 2:
         this.T = var2.C() * -871015677;
         break;
      case 3:
         this.X = var2.C() * -1141390301;
         break;
      case 4:
         this.V = var2.C() * 1435675651;
         break;
      case 5:
         this.R = var2.C() * -1402300779;
         break;
      case 6:
         this.W = var2.C() * 233322029;
      }

   }

   int[] D(int var1) {
      int[] var2 = this.P.I(var1, 1324106333);
      if (this.P.D) {
         int var3 = WJ.J[var1] - 2048;

         for(int var4 = 0; var4 < WJ.C * -1474554145; ++var4) {
            int var5 = WJ.A[var4] - 2048;
            int var6 = this.U * -1801516933 + var5;
            var6 = var6 < -2048 ? var6 + 4096 : var6;
            var6 = var6 > 2048 ? var6 - 4096 : var6;
            int var7 = var3 + 351466605 * this.Q;
            var7 = var7 < -2048 ? 4096 + var7 : var7;
            var7 = var7 > 2048 ? var7 - 4096 : var7;
            int var8 = -670406741 * this.T + var5;
            var8 = var8 < -2048 ? 4096 + var8 : var8;
            var8 = var8 > 2048 ? var8 - 4096 : var8;
            int var9 = var3 + this.X * 939068299;
            var9 = var9 < -2048 ? 4096 + var9 : var9;
            var9 = var9 > 2048 ? var9 - 4096 : var9;
            var2[var4] = !this.toString(var6, var7, -630514594) && !this.append(var8, var9, -716173681) ? 0 : 4096;
         }
      }

      return var2;
   }

   public JK() {
      super(0, true);
   }

   public static int I(int var0, int var1, int var2, int var3) {
      try {
         int var4 = 255 - var2;
         var1 = (var2 * (var1 & 16711935) & -16711936 | var2 * (var1 & '\uff00') & 16711680) >>> 8;
         return var1 + (((var0 & 16711935) * var4 & -16711936 | (var0 & '\uff00') * var4 & 16711680) >>> 8);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aie.u(" + ')');
      }
   }
}
