public class CA {
   int Z;
   static int append = 7;
   static int ceil = 6;
   static int cos = 14;
   int floor;
   int[][] method5612;
   static KJ I;

   byte[] I(byte[] var1, int var2) {
      try {
         if (this.method5612 != null) {
            int var3 = (int)((long)var1.length * (long)(this.floor * 278980631) / (long)(this.Z * -931883257)) + 14;
            int[] var4 = new int[var3];
            int var5 = 0;
            int var6 = 0;

            int var7;
            for(var7 = 0; var7 < var1.length; ++var7) {
               byte var8 = var1[var7];
               int[] var9 = this.method5612[var6];

               int var10;
               for(var10 = 0; var10 < 14; ++var10) {
                  var4[var5 + var10] += var9[var10] * var8;
               }

               var6 += this.floor * 278980631;
               var10 = var6 / (-931883257 * this.Z);
               var5 += var10;
               var6 -= var10 * -931883257 * this.Z;
            }

            var1 = new byte[var3];

            for(var7 = 0; var7 < var3; ++var7) {
               int var12 = var4[var7] + '耀' >> 16;
               if (var12 < -128) {
                  var1[var7] = -128;
               } else if (var12 > 127) {
                  var1[var7] = 127;
               } else {
                  var1[var7] = (byte)var12;
               }
            }
         }

         return var1;
      } catch (RuntimeException var11) {
         throw DQ.I(var11, "lf.a(" + ')');
      }
   }

   public short[] I(short[] var1, byte var2) {
      try {
         if (this.method5612 != null) {
            int var3 = (int)((long)(this.floor * 278980631) * (long)var1.length / (long)(this.Z * -931883257)) + 14;
            int[] var4 = new int[var3];
            int var5 = 0;
            int var6 = 0;

            int var7;
            for(var7 = 0; var7 < var1.length; ++var7) {
               short var8 = var1[var7];
               int[] var9 = this.method5612[var6];

               int var10;
               for(var10 = 0; var10 < 14; ++var10) {
                  var4[var10 + var5] += var9[var10] * var8 >> 2;
               }

               var6 += this.floor * 278980631;
               var10 = var6 / (-931883257 * this.Z);
               var5 += var10;
               var6 -= var10 * this.Z * -931883257;
            }

            var1 = new short[var3];

            for(var7 = 0; var7 < var3; ++var7) {
               int var12 = 8192 + var4[var7] >> 14;
               if (var12 < -32768) {
                  var1[var7] = -32768;
               } else if (var12 > 32767) {
                  var1[var7] = 32767;
               } else {
                  var1[var7] = (short)var12;
               }
            }
         }

         return var1;
      } catch (RuntimeException var11) {
         throw DQ.I(var11, "lf.f(" + ')');
      }
   }

   int I(int var1, int var2) {
      try {
         if (this.method5612 != null) {
            var1 = (int)((long)(278980631 * this.floor) * (long)var1 / (long)(-931883257 * this.Z));
         }

         return var1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "lf.b(" + ')');
      }
   }

   int Z(int var1, int var2) {
      try {
         if (this.method5612 != null) {
            var1 = (int)((long)(278980631 * this.floor) * (long)var1 / (long)(-931883257 * this.Z)) + 6;
         }

         return var1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "lf.p(" + ')');
      }
   }

   public CA(int var1, int var2) {
      if (var2 != var1) {
         int var3 = RA.I(var1, var2, -2115860934);
         var1 /= var3;
         var2 /= var3;
         this.Z = var1 * 597370551;
         this.floor = 1817366439 * var2;
         this.method5612 = new int[var1][14];

         for(int var4 = 0; var4 < var1; ++var4) {
            int[] var5 = this.method5612[var4];
            double var6 = 6.0D + (double)var4 / (double)var1;
            int var8 = (int)Math.floor(var6 - 7.0D + 1.0D);
            if (var8 < 0) {
               var8 = 0;
            }

            int var9 = (int)Math.ceil(var6 + 7.0D);
            if (var9 > 14) {
               var9 = 14;
            }

            for(double var10 = (double)var2 / (double)var1; var8 < var9; ++var8) {
               double var12 = ((double)var8 - var6) * 3.141592653589793D;
               double var14 = var10;
               if (var12 < -1.0E-4D || var12 > 1.0E-4D) {
                  var14 = var10 * (Math.sin(var12) / var12);
               }

               var14 *= 0.54D + 0.46D * Math.cos(((double)var8 - var6) * 0.2243994752564138D);
               var5[var8] = (int)Math.floor(65536.0D * var14 + 0.5D);
            }
         }
      }

   }

   static final void I(HSI var0, X var1, OU var2, int var3) {
      try {
         var2.J -= -783761378;
         var0.t = -970389233 * var2.H[681479919 * var2.J];
         if (var0.t * 684246511 > 1867913305 * var0.v - var0.g * -2093041337) {
            var0.t = 1227329079 * var0.v - var0.g * 2072992297;
         }

         if (684246511 * var0.t < 0) {
            var0.t = 0;
         }

         var0.u = -1915192419 * var2.H[1 + 681479919 * var2.J];
         if (-1424956747 * var0.u > var0.w * 2053897963 - 457937409 * var0.o) {
            var0.u = 2097037087 * var0.w - -900266595 * var0.o;
         }

         if (var0.u * -1424956747 < 0) {
            var0.u = 0;
         }

         VEI.I(var0, -830371764);
         if (-1 == var0.a * -1309843523 && !var1.I) {
            RV.C(var0.V * -440872681, -754597349);
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "lf.cq(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         if (XEI.bD * -1333485389 >= 5 && -1333485389 * XEI.bD <= 9) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = -1333485389 * XEI.bD;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "lf.uo(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         var0.J -= -783761378;
         int var2 = var0.H[var0.J * 681479919];
         int var3 = var0.H[681479919 * var0.J + 1];
         int var4 = var3 >> 14 & 16383;
         int var5 = var3 & 16383;
         int var6 = TS.I(var2, var4, var5, (short)-30782);
         if (var6 < 0) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = -1;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = var6;
         }

      } catch (RuntimeException var7) {
         throw DQ.I(var7, "lf.aev(" + ')');
      }
   }

   public static final void I(int var0, int var1, int var2, int var3, int var4, int var5) {
      try {
         if (var0 >= DT.D * -1424479739 && var1 <= 1135094847 * DT.Z && var2 >= DT.C * 1155384281 && var3 <= -1062447355 * DT.B) {
            CU.I(var0, var1, var2, var3, var4, -1435817713);
         } else {
            DG.I(var0, var1, var2, var3, var4, 1926849708);
         }

      } catch (RuntimeException var7) {
         throw DQ.I(var7, "lf.x(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.Y.method5612(var2, 1352882135);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "lf.aox(" + ')');
      }
   }

   static final void B(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.V.Z((byte)78) ? 1 : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "lf.ann(" + ')');
      }
   }
}
