public interface HAI {
   void method28(GSI var1);

   int method29(int var1);

   int method30(short var1);

   void method31(byte var1);

   int method32(byte var1);

   void method33(GSI var1, int var2);

   void method34();

   int method35();

   int method36();

   void method37(GSI var1, int var2);

   int method38();

   boolean method39(int var1);

   void method40(GSI var1);

   boolean method41();

   int method42();

   void method43(GSI var1);

   void method44(GSI var1);

   int method45();
}
