public class HDI {
   static int B = 0;
   int[] append;
   static int substring = 2;
   int[] toString;

   HDI(REI var1) {
      int var2 = var1.B(1723054621);
      this.append = new int[var2];
      this.toString = new int[var2];

      for(int var3 = 0; var3 < var2; ++var3) {
         int var4 = var1.I();
         this.append[var3] = var4;
         int var5 = var1.C();
         int var6 = var1.C();
         this.toString[var3] = var6 + (var5 << 16);
      }

   }

   void I(YFI var1, int var2, int var3) {
      try {
         int var4 = this.toString[0];
         var1.I(var2, var4 >>> 16, var4 & '\uffff', -1002380279);
         SSI var5 = var1.I(1609800550);
         var5.XI = 0;

         for(int var6 = this.append.length - 1; var6 >= 0; --var6) {
            int var7 = this.append[var6];
            int var8 = this.toString[var6];
            var5.YI[var5.XI * 2050671733] = var8 >> 16;
            var5.v[2050671733 * var5.XI] = var8 & '\uffff';
            byte var9 = NA.I.C;
            if (var7 == 0) {
               var9 = NA.D.C;
            } else if (2 == var7) {
               var9 = NA.Z.C;
            }

            var5.MI[var5.XI * 2050671733] = var9;
            var5.XI += -1013322787;
         }

      } catch (RuntimeException var10) {
         throw DQ.I(var10, "df.a(" + ')');
      }
   }

   public static EC I(REI var0, short var1) {
      try {
         int var2 = var0.Y(1235052657);
         HZ var3 = XII.Z((byte)44)[var0.I()];
         IZ var4 = Q.Z(126968516)[var0.I()];
         int var5 = var0.J(1556136554);
         int var6 = var0.J(1903752417);
         return new EC(var2, var3, var4, var5, var6);
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "df.a(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)76);
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var3.o * 457937409;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "df.qn(" + ')');
      }
   }

   static final void I(byte var0) {
      try {
         for(QN var1 = (QN)XEI.rZ.I((byte)3); var1 != null; var1 = (QN)XEI.rZ.I((byte)3)) {
            ZC.I(var1, -1638035740);
         }

         byte var5 = 0;
         byte var2 = 3;
         int var3;
         if (XEI.uI * 1596783995 == 0) {
            for(var3 = var5; var3 <= var2; ++var3) {
               XEI.F(var3);
            }

            XEI.C();
         } else {
            XEI.I();

            for(var3 = var5; var3 <= var2; ++var3) {
               XEI.B();
               XEI.D(var3);
               XEI.F(var3);
            }

            XEI.Z();
            XEI.C();
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "df.ii(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         String var2 = (String)var0.S[(var0.A -= 969361751) * -203050393];
         var0.J -= -783761378;
         int var3 = var0.H[681479919 * var0.J];
         int var4 = var0.H[681479919 * var0.J + 1];
         var0.S[(var0.A += 969361751) * -203050393 - 1] = var2.substring(var3, var4);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "df.aas(" + ')');
      }
   }
}
