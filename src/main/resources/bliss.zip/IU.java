public class IU {
   KJ Z;
   KJ I;
   JQ append = new JQ(64);
   JQ C = new JQ(60);
   int B;
   protected static DY D;
   public static X[] F;
   static int J;

   public void I(int var1) {
      try {
         JQ var2 = this.append;
         synchronized(this.append) {
            this.append.Z();
         }

         var2 = this.C;
         synchronized(this.C) {
            this.C.Z();
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "qc.i(" + ')');
      }
   }

   public GU I(int var1, int var2) {
      try {
         JQ var4 = this.append;
         GU var3;
         synchronized(this.append) {
            var3 = (GU)this.append.I((long)var1);
         }

         if (var3 != null) {
            return var3;
         } else {
            KJ var5 = this.Z;
            byte[] var10;
            synchronized(this.Z) {
               var10 = this.Z.I(II.m.Z(var1, -880627246), II.m.I(var1, -2138953670), (byte)-76);
            }

            var3 = new GU();
            var3.C = this;
            var3.I = var1 * 1757755963;
            if (var10 != null) {
               var3.I(new REI(var10), (byte)-38);
            }

            JQ var11 = this.append;
            synchronized(this.append) {
               this.append.I(var3, (long)var1);
            }

            return var3;
         }
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "qc.a(" + ')');
      }
   }

   public void Z(int var1) {
      try {
         JQ var2 = this.append;
         synchronized(this.append) {
            this.append.I();
         }

         var2 = this.C;
         synchronized(this.C) {
            this.C.I();
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "qc.b(" + ')');
      }
   }

   public void Z(int var1, int var2) {
      try {
         JQ var3 = this.append;
         synchronized(this.append) {
            this.append.I(var1, -465863614);
         }

         var3 = this.C;
         synchronized(this.C) {
            this.C.I(var1, -1017728103);
         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "qc.p(" + ')');
      }
   }

   public void C(int var1, int var2) {
      try {
         this.B = var1 * -1451688935;
         JQ var3 = this.C;
         synchronized(this.C) {
            this.C.I();
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "qc.f(" + ')');
      }
   }

   public IU(ZV var1, XW var2, KJ var3, KJ var4) {
      this.Z = var3;
      this.I = var4;
      int var5 = this.Z.Z(1921321046) - 1;
      II.m.I((short)3745);
      this.Z.F(var5, -1103317672);
   }

   static final void I(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         EC.I(var3, var4, var0, (byte)-85);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "qc.ly(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, int var3) {
      try {
         var0.r = var2.H[(var2.J -= -391880689) * 681479919] == 1;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "qc.cr(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.Q.Z(-369768513);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "qc.ajk(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         var0.J -= -783761378;
         int var2 = var0.H[var0.J * 681479919];
         int var3 = var0.H[1 + 681479919 * var0.J];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = GSI.OZ.I(var2, 2021332528).K[var3];
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "qc.acp(" + ')');
      }
   }

   public static CE I(byte var0) {
      try {
         return ZE.I;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "qc.as(" + ')');
      }
   }
}
