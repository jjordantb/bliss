import jaclib.ping.Ping;

public final class LQ {
   QK Z = new QK();
   int aClass479Array6311;
   int append;
   JX init;
   EY method256 = new EY();
   public static KJ I;

   public QK I(long var1) {
      try {
         QK var3 = (QK)this.init.I(var1);
         if (var3 != null) {
            this.method256.I(var3, (byte)-98);
         }

         return var3;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ot.a(" + ')');
      }
   }

   public LQ(int var1) {
      this.aClass479Array6311 = var1 * -1251678705;
      this.append = var1 * -1442966963;

      int var2;
      for(var2 = 1; var2 + var2 < var1; var2 += var2) {
         ;
      }

      this.init = new JX(var2);
   }

   public void I(int var1) {
      try {
         this.method256.B(-710330872);
         this.init.I((byte)-28);
         this.Z = new QK();
         this.append = -964444701 * this.aClass479Array6311;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ot.b(" + ')');
      }
   }

   public void I(QK var1, long var2) {
      try {
         if (this.append * -78285179 == 0) {
            QK var4 = this.method256.I(-2130705221);
            var4.I(-1460969981);
            var4.C(1224116599);
            if (var4 == this.Z) {
               var4 = this.method256.I(-2124650372);
               var4.I(-1460969981);
               var4.C(-1522621021);
            }
         } else {
            this.append -= -1442966963;
         }

         this.init.I(var1, var2);
         this.method256.I(var1, (byte)-113);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ot.f(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-49);
         var0.H[(var0.J += -391880689) * 681479919 - 1] = XEI.I(var3).C((byte)14);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ot.sr(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.e.Z(-1715403508);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ot.anm(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)9);
         X var4 = IU.F[var2 >> 16];
         GCI.I(var3, var4, var0, (byte)88);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ot.dt(" + ')');
      }
   }

   public static int Z(int var0) {
      try {
         if (IJ.I * 363912581 == 0) {
            ZII.Z.I((JAI)(new KF("jaclib")), (int)1596959683);
            if (ZII.Z.Z(-1994130525).method256(1033369240) != 100) {
               return 1;
            }

            if (!((KF)ZII.Z.Z(-1994130525)).I(-88973782)) {
               RT.K.C(1045646617);
               KF.Z(1815020733);

               try {
                  Ping.init();
               } catch (Throwable var9) {
                  ;
               }
            }

            IJ.I = -28142771;
         }

         int var1;
         int var5;
         if (363912581 * IJ.I == 1) {
            RuntimeException_Sub3.aClass479Array6311 = ZII.C(498211090);
            ZII.R.I((JAI)(new MF(HU.Z)), (int)1886459423);
            ZII.C.I((JAI)(new KF("jaggl")), (int)35492934);
            ZII.A.I((JAI)(new KF("jagdx")), (int)901862397);
            ZII.B.I((JAI)(new KF("sw3d")), (int)894420181);
            ZII.F.I((JAI)(new KF("hw3d")), (int)484486949);
            ZII.J.I((JAI)(new KF("jagtheora")), (int)1559153600);
            ZII.i.I((JAI)(new MF(EFI.B)), (int)63607433);
            ZII.S.I((JAI)(new MF(XX.Z)), (int)1106252958);
            ZII.D.I((JAI)(new MF(QA.T)), (int)-82697463);
            ZII.E.I((JAI)(new MF(I)), (int)-43844989);
            ZII.G.I((JAI)(new MF(DCI.C)), (int)664247222);
            ZII.L.I((JAI)(new MF(IZ.B)), (int)1643462211);
            ZII.K.I((JAI)(new MF(WFI.Z)), (int)1475366772);
            ZII.H.I((JAI)(new MF(AS.F)), (int)2057866589);
            ZII.M.I((JAI)(new MF(UF.r)), (int)1522498653);
            ZII.N.I((JAI)(new MF(JZI.C)), (int)2023502986);
            ZII.O.I((JAI)(new MF(DZI.D)), (int)1517464080);
            ZII.P.I((JAI)(new MF(WS.A)), (int)1685456867);
            ZII.Y.I((JAI)(new MF(EI.B)), (int)1053166996);
            ZII.U.I((JAI)(new MF(QZI.Z)), (int)1037096117);
            ZII.T.I((JAI)(new MF(EA.J)), (int)4556211);
            ZII.Q.I((JAI)(new BJ(CI.B, "huffman")), (int)827266290);
            ZII.I.I((JAI)(new MF(LC.G)), (int)650895714);
            ZII.V.I((JAI)(new MF(HT.Z)), (int)199698192);
            ZII.W.I((JAI)(new MF(BB.G)), (int)70682511);
            ZII.X.I((JAI)(new JF(VJI.J, "details")), (int)-221178534);

            for(var1 = 0; var1 < RuntimeException_Sub3.aClass479Array6311.length; ++var1) {
               if (RuntimeException_Sub3.aClass479Array6311[var1].Z(-1994130525) == null) {
                  throw new RuntimeException();
               }
            }

            var1 = 0;
            ZII[] var2 = RuntimeException_Sub3.aClass479Array6311;

            for(int var3 = 0; var3 < var2.length; ++var3) {
               ZII var4 = var2[var3];
               var5 = var4.I(-1839796424);
               int var6 = var4.Z(-1994130525).method256(1033369240);
               var1 += var5 * var6 / 100;
            }

            IJ.Z = 1385369023 * var1;
            IJ.I = -56285542;
         }

         if (RuntimeException_Sub3.aClass479Array6311 == null) {
            return 100;
         } else {
            var1 = 0;
            int var11 = 0;
            boolean var12 = true;
            ZII[] var13 = RuntimeException_Sub3.aClass479Array6311;

            for(var5 = 0; var5 < var13.length; ++var5) {
               ZII var14 = var13[var5];
               int var7 = var14.I(212846361);
               int var8 = var14.Z(-1994130525).method256(1033369240);
               if (var8 < 100) {
                  var12 = false;
               }

               var1 += var7;
               var11 += var7 * var8 / 100;
            }

            if (var12) {
               if (!((KF)ZII.J.Z(-1994130525)).I(104668639)) {
                  XEI.NC = RT.K.B(-2027084439);
               }

               RuntimeException_Sub3.aClass479Array6311 = null;
            }

            var11 -= -913055169 * IJ.Z;
            var1 -= -913055169 * IJ.Z;
            var5 = var1 > 0 ? 100 * var11 / var1 : 100;
            if (!var12 && var5 > 99) {
               var5 = 99;
            }

            return var5;
         }
      } catch (RuntimeException var10) {
         throw DQ.I(var10, "ot.a(" + ')');
      }
   }

   static final void B(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-46);
         SW.I(var3, var0, 1480483039);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ot.qs(" + ')');
      }
   }
}
