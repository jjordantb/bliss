public class DH extends YG {
   int[] append(int var1) {
      return WJ.A;
   }

   public DH() {
      super(0, true);
   }

   int[] toString(int var1) {
      return WJ.A;
   }

   int[] Z(int var1, int var2) {
      try {
         return WJ.A;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aha.i(" + ')');
      }
   }
}
