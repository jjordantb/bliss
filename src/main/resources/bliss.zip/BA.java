public class BA {
   static int append = 3;
   static int arraycopy = 0;
   static int method3936 = 2;
   public static int toString = 1;

   BA() throws Throwable {
      throw new Error();
   }

   static final void I(OU var0, byte var1) {
      try {
         if (YR.F.method3936(81, -841277867)) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 1;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "lg.ade(" + ')');
      }
   }

   static boolean I(int var0, int var1, int var2, int var3) {
      try {
         AP var4 = XEI.mI.T(-1611682495);
         boolean var5 = true;
         HAI var6 = (HAI)var4.F(var0, var1, var2, 693483522);
         if (var6 != null) {
            var5 &= EX.I(var6, (byte)-60);
         }

         var6 = (HAI)var4.I(var0, var1, var2, XEI.CF, 664102063);
         if (var6 != null) {
            var5 &= EX.I(var6, (byte)-4);
         }

         var6 = (HAI)var4.B(var0, var1, var2, (byte)95);
         if (var6 != null) {
            var5 &= EX.I(var6, (byte)-3);
         }

         return var5;
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "lg.k(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         FX.f = var0.H[(var0.J -= -391880689) * 681479919] * 985311877;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "lg.afn(" + ')');
      }
   }

   public static BY[] I(byte var0) {
      try {
         if (B.WZ == null) {
            BY[] var1 = O.I((DY)IU.D, (short)486);
            BY[] var2 = new BY[var1.length];
            int var3 = 0;
            int var4 = FW.J.Y.Z(-1747444886);

            label81:
            for(int var5 = 0; var5 < var1.length; ++var5) {
               BY var6 = var1[var5];
               if (var6.C * -1087459453 > 0 && -1087459453 * var6.C < 24) {
                  if (var0 == 0) {
                     throw new IllegalStateException();
                  }
               } else if (var6.Z * 28445523 >= 800 && var6.B * 262154323 >= 600) {
                  if (var4 == 2) {
                     if (var6.Z * 28445523 > 800) {
                        continue;
                     }

                     if (var6.B * 262154323 > 600) {
                        if (var0 == 0) {
                           throw new IllegalStateException();
                        }
                        continue;
                     }
                  }

                  if (1 != var4 || var6.Z * 28445523 <= 1024 && var6.B * 262154323 <= 768) {
                     for(int var7 = 0; var7 < var3; ++var7) {
                        BY var8 = var2[var7];
                        if (var6.Z * 28445523 == 28445523 * var8.Z && 262154323 * var8.B == 262154323 * var6.B) {
                           if (-1087459453 * var6.C > -1087459453 * var8.C) {
                              var2[var7] = var6;
                           }
                           continue label81;
                        }
                     }

                     var2[var3] = var6;
                     ++var3;
                  }
               }
            }

            B.WZ = new BY[var3];
            System.arraycopy(var2, 0, B.WZ, 0, var3);
            int[] var10 = new int[B.WZ.length];

            for(int var11 = 0; var11 < B.WZ.length; ++var11) {
               BY var12 = B.WZ[var11];
               var10[var11] = 28445523 * var12.Z * 262154323 * var12.B;
            }

            HSI.I((int[])var10, (Object[])B.WZ, (byte)98);
         }

         return B.WZ;
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "lg.hm(" + ')');
      }
   }

   static final void I(int var0) {
      try {
         EE var1;
         for(var1 = (EE)EE.G.Z(1766612795); var1 != null; var1 = (EE)EE.G.B(49146)) {
            OF.I(var1, false, (byte)8);
         }

         for(var1 = (EE)EE.T.Z(1766612795); var1 != null; var1 = (EE)EE.T.B(49146)) {
            OF.I(var1, true, (byte)8);
         }

      } catch (RuntimeException var2) {
         throw DQ.I(var2, "lg.i(" + ')');
      }
   }

   static void Z(int var0) {
      try {
         JN.C = 0;
         JN.A = 1129029761;
         JN.I = 1835291189;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "lg.f(" + ')');
      }
   }

   public static int I(byte[] var0, int var1, int var2) {
      try {
         return K.I(var0, 0, var1, -1922082533);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "lg.f(" + ')');
      }
   }
}
