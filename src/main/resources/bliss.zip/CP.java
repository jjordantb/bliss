public class CP {
   int I = 2100310889;
   int Z = -192677437;
   int[] C;
   VO B;
   int D;
   public static long F;

   CP() {
      this.B = VO.Z;
      this.D = 544205675;
   }

   void append(REI var1, int var2, int var3) {
      try {
         if (1 == var2) {
            this.Z = var1.C() * 192677437;
         } else if (2 == var2) {
            this.C = new int[var1.I()];

            for(int var4 = 0; var4 < this.C.length; ++var4) {
               this.C[var4] = var1.C();
            }
         } else if (3 == var2) {
            this.I = var1.I() * -2100310889;
         } else if (4 == var2) {
            this.B = (VO)IW.I(DDI.Z(-151911925), var1.I(), (byte)2);
         } else if (5 == var2) {
            this.D = var1.Y(1235052657) * -544205675;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "no.f(" + ')');
      }
   }

   void I(REI var1, byte var2) {
      try {
         while(true) {
            int var3 = var1.I();
            if (var3 == 0) {
               if (var2 < 3) {
                  ;
               }

               return;
            }

            this.append(var1, var3, 1312976368);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "no.a(" + ')');
      }
   }

   public static LEI I(int var0, int var1, int var2, int var3, int var4, byte var5) {
      try {
         NO.J.B = var0 * -760677635;
         NO.J.C = var1 * 167105303;
         NO.J.D = var2 * -1544157451;
         NO.J.F = var3 * -1468199503;
         NO.J.I = 89792661 * var4;
         return NO.J;
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "no.b(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)55);
         var0.H[(var0.J += -391880689) * 681479919 - 1] = 1004185785 * var3.TI;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "no.rr(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         F var3 = XL.Z(var2, 1408826506);
         String var4 = "";
         if (var3 != null && var3.B != null) {
            var4 = var3.B;
         }

         var0.S[(var0.A += 969361751) * -203050393 - 1] = var4;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "no.abo(" + ')');
      }
   }

   public static void I(int var0, int var1) {
      try {
         VK var2 = IV.I(14, (long)var0);
         var2.B(-1882192793);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "no.o(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)36);
         X var4 = IU.F[var2 >> 16];
         III.I(var3, var4, var0, 924787839);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "no.il(" + ')');
      }
   }
}
