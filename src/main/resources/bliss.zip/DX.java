public class DX {
   long I;
   short[] Z;
   short[] C;
   int[] B;

   public DX(long var1, int[] var3, short[] var4, short[] var5) {
      this.I = var1 * 8069314464859468115L;
      this.B = var3;
      this.C = var4;
      this.Z = var5;
   }

   public static boolean I(int var0, byte var1) {
      try {
         return var0 == 0 || var0 == 17 || 6 == var0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "rz.ff(" + ')');
      }
   }
}
