public class KBI {
   int I;
   String Z;
   int C;
   int B;
   int D;
   public static TJ F;

   public int I(int var1) {
      try {
         return this.C * -356113587;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "cn.b(" + ')');
      }
   }

   public int Z(int var1) {
      try {
         return -1009994485 * this.I;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "cn.f(" + ')');
      }
   }

   public String I(byte var1) {
      try {
         return this.Z;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "cn.a(" + ')');
      }
   }

   public int C(int var1) {
      try {
         return -1542462711 * this.D;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "cn.i(" + ')');
      }
   }

   public int I(short var1) {
      try {
         return -1009911665 * this.B;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "cn.p(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, byte var3) {
      try {
         var0.p = var2.H[(var2.J -= -391880689) * 681479919] * 1830595391;
         var0.SI = var2.H[(var2.J -= -391880689) * 681479919] * 2021607495;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "cn.jd(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.K.I(-134644277);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "cn.ajn(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.g.Z((byte)1);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "cn.akk(" + ')');
      }
   }

   public static void I(KJ var0, FEI var1, int var2) {
      try {
         LY.S = var0;
         EA.I = var1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "cn.a(" + ')');
      }
   }

   static int I(EL var0, LZI var1, int var2) {
      try {
         String var3 = DQ.I((EL)var0, (byte)66);
         return var1.I((String)var3, (GAI[])FX.s, (int)1319235613);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "cn.by(" + ')');
      }
   }

   public static void I(HZI var0, int var1, int var2, SSI var3, int var4, byte var5) {
      try {
         OU var6 = UD.Z(-1579984972);
         var6.E = var3;
         var6.V = var4 * -1596022393;
         UEI.I(var0, var1, var2, var6, 536465062);
         var6.E = null;
         var6.V = 1596022393;
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "cn.d(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, int var3) {
      try {
         int var4 = var2.H[(var2.J -= -391880689) * 681479919];
         String var5 = (String)var2.S[(var2.A -= 969361751) * -203050393];
         DZI var6 = WFI.C.I(var4, 2060489134);
         if (!var6.Z.equals(var5)) {
            var0.I(var4, var5, (byte)-32);
         } else {
            var0.I(var4, 1279288503);
         }

      } catch (RuntimeException var7) {
         throw DQ.I(var7, "cn.gm(" + ')');
      }
   }

   static final void I(WE var0, int var1) {
      try {
         var0.J = false;
         if (var0.A != null) {
            var0.A.J = 0;
         }

         for(WE var2 = var0.method2930(); var2 != null; var2 = var0.method2931()) {
            I(var2, -1994707671);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "cn.x(" + ')');
      }
   }

   static final void B(int var0) {
      try {
         if (-1 != XEI.xC * -257444687) {
            int var1 = UC.Z.method3894((byte)15);
            int var2 = UC.Z.method3883((byte)-12);
            PM var3 = (PM)XEI.gC.Z(1766612795);
            if (var3 != null) {
               var1 = var3.method3547((byte)-8);
               var2 = var3.method3560(-876742344);
            }

            if (XEI.SB != null && XEI.gI == JFI.C) {
               XEI.KB = true;
               XEI.LB = 0;
               XEI.EC = 0;
               XEI.NB = -500212323 * GY.Z;
               XEI.DF = JM.J * -1522183559;
            }

            RH.I((OSI)null, -257444687 * XEI.xC, 0, 0, GY.Z * -2110394505, JM.J * -1111710645, 0, 0, var1, var2, (byte)67);
            if (Q.I != null) {
               SEI.Z(var1, var2, -2137349879);
            }
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "cn.lc(" + ')');
      }
   }
}
