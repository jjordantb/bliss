import java.awt.Component;

public class DE {
   public static int[] I;
   public static FEI Z;

   DE() throws Throwable {
      throw new Error();
   }

   public static YO I(Component var0, int var1) {
      try {
         return new IP(var0);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "mf.a(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.J -= -1175642067;
         int var2 = var0.H[var0.J * 681479919];
         int var3 = var0.H[1 + 681479919 * var0.J];
         int var4 = var0.H[2 + 681479919 * var0.J];
         GN.I(7, var2 << 16 | var3, var4, "", 768379136);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "mf.ala(" + ')');
      }
   }
}
