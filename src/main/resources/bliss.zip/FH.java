public class FH extends YG {
   int[] Z(int var1, int var2) {
      try {
         int[] var3 = this.P.I(var1, 1728864266);
         if (this.P.D) {
            int var4 = WJ.J[var1];

            for(int var5 = 0; var5 < WJ.C * -1474554145; ++var5) {
               var3[var5] = this.toString(WJ.A[var5], var4, (byte)-64) % 4096;
            }
         }

         return var3;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ahb.i(" + ')');
      }
   }

   int[] append(int var1) {
      int[] var2 = this.P.I(var1, 521968543);
      if (this.P.D) {
         int var3 = WJ.J[var1];

         for(int var4 = 0; var4 < WJ.C * -1474554145; ++var4) {
            var2[var4] = this.toString(WJ.A[var4], var3, (byte)4) % 4096;
         }
      }

      return var2;
   }

   int toString(int var1, int var2, byte var3) {
      try {
         int var4 = var1 + 57 * var2;
         var4 ^= var4 << 1;
         return 4096 - (1376312589 + (789221 + var4 * var4 * 15731) * var4 & Integer.MAX_VALUE) / 262144;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ahb.ac(" + ')');
      }
   }

   int[] toString(int var1) {
      int[] var2 = this.P.I(var1, 881374072);
      if (this.P.D) {
         int var3 = WJ.J[var1];

         for(int var4 = 0; var4 < WJ.C * -1474554145; ++var4) {
            var2[var4] = this.toString(WJ.A[var4], var3, (byte)-53) % 4096;
         }
      }

      return var2;
   }

   public FH() {
      super(0, true);
   }
}
