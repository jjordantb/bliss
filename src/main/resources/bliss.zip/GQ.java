import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class GQ {
   int add = 0;
   boolean hasNext = false;
   ON[] I = new ON[8192];
   int Z = 0;
   long iterator;
   XBI C = new XBI();
   List next = new LinkedList();
   int B;
   List D = new LinkedList();
   int remove = 0;
   boolean F = false;
   boolean J = false;
   public boolean S = false;
   long A;
   static boolean[] E = new boolean[32];
   static boolean[] G = new boolean[8];

   GQ(int var1, boolean var2) {
      this.add(var1, var2);
   }

   void add(int var1, boolean var2) {
      CQ.A.add(this);
      this.A = (long)var1;
      this.iterator = (long)var1;
      this.F = true;
      this.J = var2;
   }

   public void I() {
      this.F = true;
   }

   public void Z() {
      this.hasNext = true;
   }

   boolean I(GSI var1, long var2) {
      if (this.A != this.iterator) {
         this.Z();
      } else {
         this.next();
      }

      if (var2 - this.A > 750L) {
         this.C();
         return false;
      } else {
         int var4 = (int)(var2 - this.iterator);
         Iterator var5;
         YP var6;
         if (this.F) {
            var5 = this.next.iterator();

            while(var5.hasNext()) {
               var6 = (YP)var5.next();

               for(int var7 = 0; var7 < var6.D.e * 1095253617; ++var7) {
                  var6.I(var1, var2, 1, !this.hasNext, (byte)63);
               }
            }

            this.F = false;
         }

         var5 = this.next.iterator();

         while(var5.hasNext()) {
            var6 = (YP)var5.next();
            var6.I(var1, var2, var4, !this.hasNext, (byte)45);
         }

         this.iterator = var2;
         return true;
      }
   }

   void C() {
      this.S = true;
      Iterator var1 = this.D.iterator();

      while(var1.hasNext()) {
         HM var2 = (HM)var1.next();
         if (var2.J.R * -1955592777 == 1) {
            var2.I(-1460969981);
         }
      }

      for(int var3 = 0; var3 < this.I.length; ++var3) {
         if (this.I[var3] != null) {
            this.I[var3].I();
            this.I[var3] = null;
         }
      }

      this.Z = 0;
      this.next = new LinkedList();
      this.add = 0;
      this.D = new LinkedList();
      this.remove = 0;
   }

   void hasNext(GSI var1, NFI[] var2, boolean var3) {
      for(int var4 = 0; var4 < 32; ++var4) {
         E[var4] = false;
      }

      Iterator var7 = this.next.iterator();

      while(true) {
         label58:
         while(var7.hasNext()) {
            YP var5 = (YP)var7.next();
            if (var2 != null) {
               for(int var6 = 0; var6 < var2.length; ++var6) {
                  if (var5.E == var2[var6] || var5.E == var2[var6].F) {
                     E[var6] = true;
                     var5.I((byte)-40);
                     var5.H = false;
                     continue label58;
                  }
               }
            }

            if (!var3) {
               if (var5.C * -917784967 == 0) {
                  var7.remove();
                  --this.add;
               } else {
                  var5.H = true;
               }
            }
         }

         if (var2 != null) {
            for(int var8 = 0; var8 < var2.length && var8 != 32 && this.add != 32; ++var8) {
               if (!E[var8]) {
                  YP var9 = new YP(var1, var2[var8], this, this.A);
                  this.next.add(var9);
                  ++this.add;
                  E[var8] = true;
               }
            }
         }

         return;
      }
   }

   void iterator(WBI[] var1, boolean var2) {
      for(int var3 = 0; var3 < 8; ++var3) {
         G[var3] = false;
      }

      Iterator var6 = this.D.iterator();

      while(true) {
         label67:
         while(var6.hasNext()) {
            HM var4 = (HM)var6.next();
            if (var1 != null) {
               for(int var5 = 0; var5 < var1.length; ++var5) {
                  if (var4.G == var1[var5] || var4.G == var1[var5].Z) {
                     G[var5] = true;
                     var4.C(-219401060);
                     continue label67;
                  }
               }
            }

            if (!var2) {
               var4.I(-1460969981);
               --this.remove;
               if (var4.Z(-629325116)) {
                  var4.I(-1460969981);
                  CQ.G -= 817588661;
               }
            }
         }

         if (var1 != null) {
            for(int var7 = 0; var7 < var1.length && var7 != 8 && this.remove != 8; ++var7) {
               if (!G[var7]) {
                  HM var8 = null;
                  if (var1[var7].I((byte)3).R * -1955592777 == 1 && CQ.G * -1237648227 < 32) {
                     var8 = new HM(var1[var7], this);
                     CQ.E.I(var8, (long)(var1[var7].C * 617796067));
                     CQ.G += 817588661;
                  }

                  if (var8 == null) {
                     var8 = new HM(var1[var7], this);
                  }

                  this.D.add(var8);
                  ++this.remove;
                  G[var7] = true;
               }
            }
         }

         return;
      }
   }

   public XBI B() {
      this.C.I.I(198538836);

      for(int var1 = 0; var1 < this.I.length; ++var1) {
         if (this.I[var1] != null && this.I[var1].M != null) {
            this.C.I.I((MN)this.I[var1], (byte)-89);
         }
      }

      return this.C;
   }

   public void I(int var1, int var2, int var3, int var4, int var5) {
      this.B = var1;
   }

   void I(AP var1, GSI var2) {
      this.C.I.I(-1313547025);
      Iterator var3 = this.next.iterator();

      while(var3.hasNext()) {
         YP var4 = (YP)var3.next();
         var4.I(var1, var2, this.iterator);
      }

   }

   public XBI D() {
      return this.C;
   }

   void next() {
      this.hasNext = false;
   }

   public void I(GSI var1, long var2, NFI[] var4, WBI[] var5, boolean var6) {
      if (!this.S) {
         this.hasNext(var1, var4, var6);
         this.iterator(var5, var6);
         this.A = var2;
      }

   }

   public static GQ I(int var0, boolean var1) {
      if (CQ.J * -1264407527 != CQ.F * 274948937) {
         GQ var2 = CQ.D[CQ.F * 274948937];
         CQ.F = (CQ.F * 274948937 + 1 & NBI.I[CQ.I * 1197525581]) * 172162809;
         var2.add(var0, var1);
         return var2;
      } else {
         return new GQ(var0, var1);
      }
   }

   public void I(long var1) {
      this.A = var1;
   }
}
