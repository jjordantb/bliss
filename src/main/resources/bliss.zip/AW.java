public class AW extends LV {
   public static int method5611 = 1;
   public static int toString = 0;

   public int method5612(int var1, int var2) {
      try {
         if (this.I.I((byte)-56) == ZV.D) {
            if (var1 == 0) {
               if (this.I.O.I(1268692572) == 1) {
                  return 2;
               }

               if (this.I.P.C(2092806883) == 1) {
                  return 2;
               }

               if (this.I.f.C(1056672135) > 0) {
                  return 2;
               }
            }

            return 1;
         } else {
            return 3;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aeq.f(" + ')');
      }
   }

   public void I(int var1) {
      try {
         if (this.I.I((byte)-100) != ZV.D) {
            this.C = 1886334997;
         }

         if (this.C * -1598873795 != 0 && 1 != this.C * -1598873795) {
            this.C = this.method5611(-2130948136) * 1886334997;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aeq.s(" + ')');
      }
   }

   int method5615() {
      return 1;
   }

   void method5614(int var1, int var2) {
      try {
         this.C = 1886334997 * var1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aeq.p(" + ')');
      }
   }

   public AW(int var1, MM var2) {
      super(var1, var2);
   }

   void method5610(int var1) {
      this.C = 1886334997 * var1;
   }

   public int Z(int var1) {
      try {
         return this.C * -1598873795;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aeq.y(" + ')');
      }
   }

   public AW(MM var1) {
      super(var1);
   }

   public int method5616(int var1) {
      if (this.I.I((byte)-125) == ZV.D) {
         if (var1 == 0) {
            if (this.I.O.I(252992424) == 1) {
               return 2;
            }

            if (this.I.P.C(1884202670) == 1) {
               return 2;
            }

            if (this.I.f.C(-1401768386) > 0) {
               return 2;
            }
         }

         return 1;
      } else {
         return 3;
      }
   }

   int method5611(int var1) {
      return 1;
   }

   public boolean Z(byte var1) {
      try {
         return this.I.I((byte)-64) == ZV.D;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aeq.z(" + ')');
      }
   }
}
