public abstract class JG extends AE {
   int J;

   abstract int method3054(ZG var1);

   abstract void method3055();

   abstract int method3056(ZG var1);

   abstract void method3057();

   JG() throws Throwable {
      throw new Error();
   }

   abstract void method3058();

   abstract int method3059(ZG var1);

   abstract void method3060();
}
