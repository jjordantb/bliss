import java.io.File;
import javax.swing.filechooser.FileFilter;

public class ASI extends FileFilter {
   DF append;
   DF isDirectory;

   public boolean accept(File var1) {
      try {
         if (this.isDirectory.Z(564359284) && var1.isDirectory()) {
            return true;
         } else {
            return !this.isDirectory.Z(842824305);
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aeo.accept(" + ')');
      }
   }

   public String getDescription() {
      return null;
   }

   ASI(DF var1, DF var2) {
      this.append = var1;
      this.isDirectory = var2;
   }
}
