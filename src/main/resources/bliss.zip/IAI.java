public interface IAI {
   boolean method237(PM var1, WSI[] var2, int var3, YO var4);

   boolean method238(PM var1, WSI[] var2, int var3, YO var4);

   boolean method239(PM var1, WSI[] var2, int var3, YO var4, int var5);
}
