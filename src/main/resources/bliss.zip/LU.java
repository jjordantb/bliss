import jaggl.OpenGL;

public abstract class LU {
   int f;
   int glBufferDataARBa;
   static int glBufferDataARBub = 34963;
   static int glBufferSubDataARBub = 34962;
   int I;
   MJI Z;
   boolean glGenBuffersARB;
   boolean method478 = false;
   static int[] C = new int[1];

   LU(MJI var1, int var2, jaclib.memory.I var3, int var4, boolean var5) {
      this.Z = var1;
      this.glBufferDataARBa = var2;
      this.f = var4;
      this.glGenBuffersARB = var5;
      OpenGL.glGenBuffersARB(1, C, 0);
      this.I = C[0];
      this.method478();
      OpenGL.glBufferDataARBa(var2, this.f, var3.f(), this.glGenBuffersARB ? '裠' : '裤');
      this.Z.d += this.f;
   }

   abstract void method478();

   void I(byte[] var1, int var2) {
      this.method478();
      if (var2 > this.f) {
         OpenGL.glBufferDataARBub(this.glBufferDataARBa, var2, var1, 0, this.glGenBuffersARB ? '裠' : '裤');
         this.Z.d += var2 - this.f;
         this.f = var2;
      } else {
         OpenGL.glBufferSubDataARBub(this.glBufferDataARBa, 0, var2, var1, 0);
      }

   }

   LU(MJI var1, int var2, byte[] var3, int var4, boolean var5) {
      this.Z = var1;
      this.glBufferDataARBa = var2;
      this.f = var4;
      this.glGenBuffersARB = var5;
      OpenGL.glGenBuffersARB(1, C, 0);
      this.I = C[0];
      this.method478();
      OpenGL.glBufferDataARBub(var2, this.f, var3, 0, this.glGenBuffersARB ? '裠' : '裤');
      this.Z.d += this.f;
   }

   abstract void method480();
}
