public class fa extends IBI implements SAI, TAI {
   boolean aBoolean8978 = false;
   long nativeid;

   public void ma(boolean var1) {
      this.M(this.nativeid, var1);
   }

   fa(ja var1, int[] var2, int var3, int var4, int var5, int var6, boolean var7) {
      this.RA(var1, var2, var3, var4, var5, var6, var7);
   }

   native void F(long var1, int[] var3);

   fa(ja var1, int var2, int var3, int var4, int var5, boolean var6) {
      this.K(var1, var2, var3, var4, var5, var6);
   }

   native void UA(ja var1, int var2, int var3);

   public int p() {
      return this.da(this.nativeid);
   }

   native void EA(ja var1, int[] var2, byte[] var3, byte[] var4, int var5, int var6, int var7, int var8);

   native void ea(long var1, int var3, int var4, int var5, int var6, int var7, int var8);

   public int f() {
      return this.GA(this.nativeid);
   }

   native void M(long var1, boolean var3);

   public void method621(int var1, int var2, int var3, int var4) {
      this.U(this.nativeid, var1, var2, var3, var4);
   }

   native void U(long var1, int var3, int var4, int var5, int var6);

   public void method622(int[] var1) {
      this.F(this.nativeid, var1);
   }

   native void dd(long var1, int var3, int var4, long var5, int var7, int var8);

   void method651(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      this.ha(this.nativeid, var1, var2, var3, var4, var5, var6, var7, var8);
   }

   public int method630() {
      return this.da(this.nativeid);
   }

   native int da(long var1);

   public int method669() {
      return this.GA(this.nativeid);
   }

   native int WA(long var1);

   public void b() {
   }

   public int method625() {
      return this.GA(this.nativeid);
   }

   public void method677(int[] var1) {
      this.F(this.nativeid, var1);
   }

   native int ba(long var1);

   void method676(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10) {
      this.e(this.nativeid, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10);
   }

   public int a() {
      return this.da(this.nativeid);
   }

   public void method675(int var1, int var2, int var3, int var4, int var5, int var6) {
      this.ea(this.nativeid, var1, var2, var3, var4, var5, var6);
   }

   public TAI method647() {
      return this.aBoolean8978 ? this : null;
   }

   public void method632(int var1, int var2, int var3) {
      this.j(this.nativeid, var1, var2, var3);
   }

   native void j(long var1, int var3, int var4, int var5);

   public void method665(int var1, int var2, int var3, int var4, int var5, int var6) {
      this.ea(this.nativeid, var1, var2, var3, var4, var5, var6);
   }

   native void Y(long var1, int var3, int var4, int var5, int var6, int var7);

   public void method654(int var1, int var2, QJI var3, int var4, int var5) {
      this.o(this.nativeid, var1, var2, ((wa)var3).nativeid, var4, var5);
   }

   native void o(long var1, int var3, int var4, long var5, int var7, int var8);

   public void method643(int var1, int var2, int var3, int var4, int var5) {
      this.Y(this.nativeid, var1, var2, var3, var4, var5);
   }

   native void aa(long var1, int var3, int var4, int var5, int var6, int var7, int var8, int var9);

   public void method662(int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      this.aa(this.nativeid, var1, var2, var3, var4, var5, var6, var7);
   }

   public void method674(int var1, int var2, int var3, int var4, int var5) {
      this.Y(this.nativeid, var1, var2, var3, var4, var5);
   }

   void method642(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10) {
      this.e(this.nativeid, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10);
   }

   native void ha(long var1, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10);

   void method644(float var1, float var2, float var3, float var4, float var5, float var6, int var7, QJI var8, int var9, int var10) {
      this.FA(this.nativeid, var1, var2, var3, var4, var5, var6, var7, ((wa)var8).nativeid, var9, var10, this.aBoolean8978);
   }

   native void FA(long var1, float var3, float var4, float var5, float var6, float var7, float var8, int var9, long var10, int var12, int var13, boolean var14);

   public void method631(int var1, int var2, int var3, int var4, int var5) {
      this.Y(this.nativeid, var1, var2, var3, var4, var5);
   }

   public void method628(int var1, int var2, int var3) {
      this.j(this.nativeid, var1, var2, var3);
   }

   public TAI method646() {
      return this.aBoolean8978 ? this : null;
   }

   public int method271() {
      return this.WA(this.nativeid);
   }

   public int method658() {
      return this.da(this.nativeid);
   }

   public void method649(int var1, int var2, int var3, int var4, int var5) {
      this.Y(this.nativeid, var1, var2, var3, var4, var5);
   }

   void method635(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      this.ha(this.nativeid, var1, var2, var3, var4, var5, var6, var7, var8);
   }

   public void method648(int var1, int var2, int var3, int var4, int var5) {
      this.Y(this.nativeid, var1, var2, var3, var4, var5);
   }

   public void method650(int var1, int var2, QJI var3, int var4, int var5) {
      this.o(this.nativeid, var1, var2, ((wa)var3).nativeid, var4, var5);
   }

   void method672(float var1, float var2, float var3, float var4, float var5, float var6, int var7, QJI var8, int var9, int var10) {
      this.FA(this.nativeid, var1, var2, var3, var4, var5, var6, var7, ((wa)var8).nativeid, var9, var10, this.aBoolean8978);
   }

   void method652(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      this.ha(this.nativeid, var1, var2, var3, var4, var5, var6, var7, var8);
   }

   fa(ja var1, int[] var2, byte[] var3, byte[] var4, int var5, int var6, int var7, int var8) {
      this.EA(var1, var2, var3, var4, var5, var6, var7, var8);
   }

   public int i() {
      return this.da(this.nativeid);
   }

   public int k() {
      return this.GA(this.nativeid);
   }

   public void d() {
   }

   public void method624(int var1, int var2, int var3, int var4, int var5, int var6) {
      this.ea(this.nativeid, var1, var2, var3, var4, var5, var6);
   }

   public void x() {
   }

   public TAI method627() {
      return this.aBoolean8978 ? this : null;
   }

   public void method655(int var1, int var2, int var3, int var4) {
      this.U(this.nativeid, var1, var2, var3, var4);
   }

   native void dc(long var1, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10);

   fa(ja var1, int var2, int var3, boolean var4) {
      this.aBoolean8978 = var4;
      this.UA(var1, var2, var3);
   }

   public void u() {
   }

   public void method640(int[] var1) {
      this.F(this.nativeid, var1);
   }

   native void dn(long var1, int var3, int var4, int var5, int var6, int var7, int var8, int var9);

   native int GA(long var1);

   public void method656(int[] var1) {
      this.F(this.nativeid, var1);
   }

   public void method660(int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      this.aa(this.nativeid, var1, var2, var3, var4, var5, var6, var7);
   }

   public void method661(int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      this.aa(this.nativeid, var1, var2, var3, var4, var5, var6, var7);
   }

   void method629(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10) {
      this.e(this.nativeid, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10);
   }

   void method663(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10) {
      this.e(this.nativeid, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10);
   }

   void method657(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10) {
      this.e(this.nativeid, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10);
   }

   public int method623() {
      return this.da(this.nativeid);
   }

   void method664(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10) {
      this.e(this.nativeid, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10);
   }

   void method666(float var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8, int var9, int var10) {
      this.e(this.nativeid, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10);
   }

   native void cr(long var1, int var3, int var4, int var5, int var6);

   public int method667() {
      return this.GA(this.nativeid);
   }

   public int method668() {
      return this.GA(this.nativeid);
   }

   native void RA(ja var1, int[] var2, int var3, int var4, int var5, int var6, boolean var7);

   void method670(float var1, float var2, float var3, float var4, float var5, float var6, int var7, QJI var8, int var9, int var10) {
      this.FA(this.nativeid, var1, var2, var3, var4, var5, var6, var7, ((wa)var8).nativeid, var9, var10, this.aBoolean8978);
   }

   void method671(float var1, float var2, float var3, float var4, float var5, float var6, int var7, QJI var8, int var9, int var10) {
      this.FA(this.nativeid, var1, var2, var3, var4, var5, var6, var7, ((wa)var8).nativeid, var9, var10, this.aBoolean8978);
   }

   native void e(long var1, float var3, float var4, float var5, float var6, float var7, float var8, int var9, int var10, int var11, int var12);

   public void z(boolean var1) {
      this.M(this.nativeid, var1);
   }

   native void cn(ja var1, int var2, int var3);

   native void ch(ja var1, int var2, int var3);

   native void ct(ja var1, int var2, int var3);

   native void cc(ja var1, int[] var2, int var3, int var4, int var5, int var6, boolean var7);

   native void ca(ja var1, int[] var2, byte[] var3, byte[] var4, int var5, int var6, int var7, int var8);

   native void ci(ja var1, int var2, int var3, int var4, int var5, boolean var6);

   native void ce(long var1, int var3, int var4, int var5, int var6);

   native void cb(long var1, int var3, int var4, int var5, int var6);

   public int method626() {
      return this.ba(this.nativeid);
   }

   native int cu(long var1);

   native int cp(long var1);

   native int cq(long var1);

   native int cf(long var1);

   native int dh(long var1);

   native void dg(long var1, int var3, int var4, int var5);

   native void method_do(long var1, int var3, int var4, int var5, int var6, int var7, int var8, int var9);

   native void dq(long var1, int var3, int var4, int var5, int var6, int var7);

   native void ds(long var1, int var3, int var4, long var5, int var7, int var8);

   native void dp(long var1, int var3, int var4, long var5, int var7, int var8);

   public int method272() {
      return this.WA(this.nativeid);
   }

   native void dx(long var1, int var3, int var4, long var5, int var7, int var8);

   native void K(ja var1, int var2, int var3, int var4, int var5, boolean var6);

   native void dk(long var1, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10);

   native void db(long var1, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10);

   native void dl(long var1, int var3, int var4, int var5);

   public int method653() {
      return this.ba(this.nativeid);
   }

   native void dm(long var1, float var3, float var4, float var5, float var6, float var7, float var8, int var9, long var10, int var12, int var13, boolean var14);
}
