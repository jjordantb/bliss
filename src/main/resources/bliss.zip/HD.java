import jagdx.IDirect3DDevice;
import jagdx.IDirect3DSurface;
import jagdx.IDirect3DTexture;
import jagdx.IUnknown;

public class HD extends GD implements BEI {
   public int method88() {
      return super.method76();
   }

   public TAI method117(int var1) {
      return new XB(this, var1);
   }

   public void method83(int var1, int var2, int var3, int var4, int[] var5, int var6) {
      long var7 = IDirect3DTexture.GetSurfaceLevel(this.Z, 0);
      long var9 = IDirect3DDevice.CreateRenderTarget(this.D.FZ, var3, var4, 21, 0, 0, true);
      if (jagdx.S.f(IDirect3DDevice.StretchRect(this.D.FZ, var7, var1, var2, var3, var4, var9, 0, 0, var3, var4, 1))) {
         IDirect3DSurface.Download(var9, 0, 0, var3, var4, var3 * 4, 16, this.D.J);
         this.D.F.clear();
         this.D.F.asIntBuffer().get(var5);
      }

      IUnknown.Release(var7);
      IUnknown.Release(var9);
   }

   public int method92() {
      return super.method92();
   }

   public int method76() {
      return super.method76();
   }

   public void method129(EB var1) {
      super.method122(var1);
   }

   public float method78(float var1) {
      return super.method78(var1);
   }

   public boolean method79() {
      return super.method79();
   }

   public TAI method121(int var1) {
      return new XB(this, var1);
   }

   public void method81(int var1, int var2, int var3, int var4, int[] var5, int var6, int var7) {
      super.method81(var1, var2, var3, var4, var5, var6, var7);
   }

   public int method86() {
      return super.method92();
   }

   public void method101(int var1, int var2, int var3, int var4, int[] var5, int var6, int var7) {
      super.method81(var1, var2, var3, var4, var5, var6, var7);
   }

   public void method128() {
      super.method128();
   }

   public void method122(EB var1) {
      super.method122(var1);
   }

   public void b() {
      super.b();
   }

   public void method82(int var1, int var2, int var3, int var4, byte[] var5, YCI var6, int var7, int var8) {
      super.method82(var1, var2, var3, var4, var5, var6, var7, var8);
   }

   public void method107(int var1, int var2, int var3, int var4, int[] var5, int var6) {
      long var7 = IDirect3DTexture.GetSurfaceLevel(this.Z, 0);
      long var9 = IDirect3DDevice.CreateRenderTarget(this.D.FZ, var3, var4, 21, 0, 0, true);
      if (jagdx.S.f(IDirect3DDevice.StretchRect(this.D.FZ, var7, var1, var2, var3, var4, var9, 0, 0, var3, var4, 1))) {
         IDirect3DSurface.Download(var9, 0, 0, var3, var4, var3 * 4, 16, this.D.J);
         this.D.F.clear();
         this.D.F.asIntBuffer().get(var5);
      }

      IUnknown.Release(var7);
      IUnknown.Release(var9);
   }

   public void x() {
      super.b();
   }

   public void method106(boolean var1, boolean var2) {
      super.method80(var1, var2);
   }

   public int method75() {
      return super.method76();
   }

   public float method77(float var1) {
      return super.method77(var1);
   }

   public void method123() {
      super.method128();
   }

   public float method89(float var1) {
      return super.method77(var1);
   }

   public float method90(float var1) {
      return super.method77(var1);
   }

   public TAI method118(int var1) {
      return new XB(this, var1);
   }

   public void d() {
      super.b();
   }

   public float method109(float var1) {
      return super.method78(var1);
   }

   public float method94(float var1) {
      return super.method78(var1);
   }

   public float method95(float var1) {
      return super.method78(var1);
   }

   public void method96(boolean var1, boolean var2) {
      super.method80(var1, var2);
   }

   public void method97(boolean var1, boolean var2) {
      super.method80(var1, var2);
   }

   public void method98(boolean var1, boolean var2) {
      super.method80(var1, var2);
   }

   public boolean Z() {
      return super.Z();
   }

   public void method99(boolean var1, boolean var2) {
      super.method80(var1, var2);
   }

   public void method80(boolean var1, boolean var2) {
      super.method80(var1, var2);
   }

   public void method102(int var1, int var2, int var3, int var4, int[] var5, int var6, int var7) {
      super.method81(var1, var2, var3, var4, var5, var6, var7);
   }

   public void method125() {
      super.method128();
   }

   public void method104(int var1, int var2, int var3, int var4, byte[] var5, YCI var6, int var7, int var8) {
      super.method82(var1, var2, var3, var4, var5, var6, var7, var8);
   }

   public TAI method119(int var1) {
      return new XB(this, var1);
   }

   public void method93(int var1, int var2, int var3, int var4, int[] var5, int var6) {
      long var7 = IDirect3DTexture.GetSurfaceLevel(this.Z, 0);
      long var9 = IDirect3DDevice.CreateRenderTarget(this.D.FZ, var3, var4, 21, 0, 0, true);
      if (jagdx.S.f(IDirect3DDevice.StretchRect(this.D.FZ, var7, var1, var2, var3, var4, var9, 0, 0, var3, var4, 1))) {
         IDirect3DSurface.Download(var9, 0, 0, var3, var4, var3 * 4, 16, this.D.J);
         this.D.F.clear();
         this.D.F.asIntBuffer().get(var5);
      }

      IUnknown.Release(var7);
      IUnknown.Release(var9);
   }

   public void u() {
      super.b();
   }

   public boolean method108() {
      return super.Z();
   }

   public boolean method111() {
      return super.Z();
   }

   public int method84() {
      return super.method76();
   }

   public void method126() {
      super.method128();
   }

   public float method91(float var1) {
      return super.method77(var1);
   }

   public void method127(EB var1) {
      super.method122(var1);
   }

   public void method124(EB var1) {
      super.method122(var1);
   }

   public void method87(int var1, int var2, int var3, int var4, byte[] var5, YCI var6, int var7, int var8) {
      super.method82(var1, var2, var3, var4, var5, var6, var7, var8);
   }

   public TAI method120(int var1) {
      return new XB(this, var1);
   }

   public boolean method85() {
      return super.method79();
   }

   public void method100(int var1, int var2, int var3, int var4, byte[] var5, YCI var6, int var7, int var8) {
      super.method82(var1, var2, var3, var4, var5, var6, var7, var8);
   }

   HD(PJI var1, YCI var2, SDI var3, int var4, int var5) {
      super(var1, var2, var3, var4, var5, 1025, 0);
   }

   public boolean method110() {
      return super.method79();
   }

   public float method105(float var1) {
      return super.method78(var1);
   }
}
