public class FC {
   static final boolean I(int var0, int var1) {
      return (var0 & 33) != 0;
   }

   static final boolean Z(int var0, int var1) {
      return (var0 & 52) != 0;
   }

   static final boolean C(int var0, int var1) {
      return (var0 & 544) == 544 | (var0 & 24) != 0;
   }

   static final boolean B(int var0, int var1) {
      return (var0 & 540800) != 0;
   }

   static final boolean D(int var0, int var1) {
      return (var0 & 256) != 0;
   }

   static final boolean F(int var0, int var1) {
      return false;
   }

   static final boolean J(int var0, int var1) {
      return (var0 & '耀') != 0;
   }

   static final boolean S(int var0, int var1) {
      return (var0 & '얀') != 0;
   }

   static final boolean A(int var0, int var1) {
      return (var0 & 2048) != 0;
   }

   static final boolean E(int var0, int var1) {
      return (var0 & 2048) != 0;
   }

   static final boolean G(int var0, int var1) {
      return f(var0, var1) & ((var0 & 8192) != 0 | C(var0, var1) | Y(var0, var1));
   }

   static final boolean H(int var0, int var1) {
      return (var0 & 34) != 0;
   }

   static final boolean K(int var0, int var1) {
      return (var0 & 2048) != 0;
   }

   static final boolean L(int var0, int var1) {
      return (var0 & 458752) != 0 || I(var0, var1) || i(var0, var1);
   }

   static final boolean M(int var0, int var1) {
      return (var0 & 458752) != 0 || H(var0, var1) || i(var0, var1);
   }

   static final boolean N(int var0, int var1) {
      return (var0 & 458752) != 0 || Z(var0, var1) || i(var0, var1);
   }

   static final boolean O(int var0, int var1) {
      boolean var2 = (var1 & 55) != 0 ? G(var0, var1) : U(var0, var1);
      return (var0 & 65536) != 0 | C(var0, var1) | var2;
   }

   static final boolean P(int var0, int var1) {
      return F(var0, var1) || s(var0, var1);
   }

   static final boolean Q(int var0, int var1) {
      return (var0 & 384) != 0;
   }

   static final boolean R(int var0, int var1) {
      return (var0 & 32) != 0;
   }

   static final boolean T(int var0, int var1) {
      return (var0 & 1024) != 0;
   }

   static final boolean U(int var0, int var1) {
      if (!A(var0, var1)) {
         return false;
      } else {
         return (var0 & '退') != 0 | B(var0, var1) | D(var0, var1) ? true : (var1 & 55) == 0 & ((var0 & 8192) != 0 | C(var0, var1) | Y(var0, var1));
      }
   }

   static final boolean V(int var0, int var1) {
      return (var0 & 2048) != 0 | J(var0, var1) || U(var0, var1);
   }

   static final boolean W(int var0, int var1) {
      return (var0 & 16) != 0;
   }

   static final boolean X(int var0, int var1) {
      return (var0 & 2048) != 0;
   }

   static final boolean Y(int var0, int var1) {
      return (var0 & 65536) != 0;
   }

   static final boolean i(int var0, int var1) {
      return (I(var0, var1) | H(var0, var1) | Z(var0, var1)) & K(var0, var1);
   }

   static final boolean z(int var0, int var1) {
      return W(var0, var1) & E(var0, var1);
   }

   static final boolean c(int var0, int var1) {
      return (var0 & 262144) != 0 | D(var0, var1) || U(var0, var1);
   }

   static final boolean b(int var0, int var1) {
      return B(var0, var1) || U(var0, var1);
   }

   static final boolean d(int var0, int var1) {
      return (var0 & 55) != 0;
   }

   static final boolean f(int var0, int var1) {
      return (var0 & 2048) != 0 && (var1 & 55) != 0;
   }

   FC() throws Throwable {
      throw new Error();
   }

   static final boolean j(int var0, int var1) {
      return (var0 & 393216) != 0 | W(var0, var1) || z(var0, var1);
   }

   static final boolean s(int var0, int var1) {
      return F(var0, var1) & X(var0, var1);
   }
}
