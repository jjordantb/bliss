public class HZI implements AAI {
   public static HZI I = new HZI("", 12);
   public static HZI Z = new HZI("", 10);
   public static HZI C = new HZI("", 23);
   public static HZI B = new HZI("", 11);
   public static HZI D = new HZI("", 16);
   public static HZI F = new HZI("", 25);
   public static HZI J = new HZI("", 22);
   public static HZI S = new HZI("", 17);
   public static HZI A = new HZI("", 18);
   public static HZI E = new HZI("", 19);
   public static HZI G = new HZI("", 20);
   public static HZI H = new HZI("", 21);
   public static HZI K = new HZI("", 13);
   public static HZI L = new HZI("", 15);
   public static HZI M = new HZI("", 24);
   public static HZI N = new HZI("", 14);
   public static HZI O = new HZI("", 26);
   public static HZI P = new HZI("", 27);
   static HZI append = new HZI("", 73);
   static HZI toString = new HZI("", 76);
   public int Q;

   HZI(String var1, int var2) {
      this.Q = var2 * 1197369919;
   }

   static void I(int var0) {
      try {
         int var1 = GY.Z * -2110394505;
         int var2 = JM.J * -1111710645;
         if (-639974669 * ADI.S < var1) {
            var1 = -639974669 * ADI.S;
         }

         if (1282634425 * XEI.F < var2) {
            var2 = XEI.F * 1282634425;
         }

         try {
            VD.D.I((Object[])(new Object[]{var1, var2, VB.I((byte)-5), FW.J.Y.Z(-1747444886)}), (short)28321);
         } catch (Throwable var4) {
            ;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ut.ge(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         KY.I(727186143);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ut.agh(" + ')');
      }
   }

   static void Z(int var0) {
      try {
         UB.A.Z();
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "ut.i(" + ')');
      }
   }
}
