public class HM extends AE {
   VB J;
   float S;
   int A;
   int E;
   WBI G;
   int H;
   float K;
   static float[] append = new float[3];
   static YK L;

   void C(int var1) {
      try {
         this.A = 2086576921 * this.G.I;
         this.E = this.G.D * 587912369;
         this.H = this.G.F * -247287593;
         if (this.G.J != null) {
            this.G.J.Z((float)(1776313545 * this.J.K), (float)(-739294135 * this.J.L), (float)(this.J.M * -1849369705), append);
         }

         this.S = append[0];
         this.K = append[2];
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "acf.a(" + ')');
      }
   }

   HM(WBI var1, GQ var2) {
      this.G = var1;
      this.J = this.G.I((byte)3);
      this.C(-1046035099);
   }

   static final void I(HSI var0, X var1, OU var2, byte var3) {
      try {
         var0.vI = var2.H[(var2.J -= -391880689) * 681479919] * 728904583;
         VEI.I(var0, 1196529132);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "acf.dx(" + ')');
      }
   }
}
