public class KW extends LV {
   public static int method5611 = 2;
   public static int toString = 1;
   public static int F = 0;

   public int I(int var1) {
      try {
         return -1598873795 * this.C;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ade.y(" + ')');
      }
   }

   public KW(int var1, MM var2) {
      super(var1, var2);
      UZ.I(-1598873795 * this.C, -1410466853);
   }

   public void Z(int var1) {
      try {
         if (this.I.B(-463714341).C(1268482556) < 245) {
            this.C = 0;
         }

         if (-1598873795 * this.C < 0 || -1598873795 * this.C > 2) {
            this.C = this.method5611(-334062973) * 1886334997;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ade.s(" + ')');
      }
   }

   void method5610(int var1) {
      this.C = var1 * 1886334997;
      UZ.I(-1598873795 * this.C, -1253191065);
   }

   public int method5612(int var1, int var2) {
      try {
         return this.I.B(-2143176849).C(1386061533) < 245 ? 3 : 1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ade.f(" + ')');
      }
   }

   void method5614(int var1, int var2) {
      try {
         this.C = var1 * 1886334997;
         UZ.I(-1598873795 * this.C, -663288448);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ade.p(" + ')');
      }
   }

   public KW(MM var1) {
      super(var1);
      UZ.I(this.C * -1598873795, -1776530085);
   }

   int method5615() {
      return this.I.B(-810795620).C(1995953827) < 245 ? 0 : 2;
   }

   public int method5616(int var1) {
      return this.I.B(616034505).C(1913483259) < 245 ? 3 : 1;
   }

   int method5611(int var1) {
      try {
         return this.I.B(-1188800813).C(1637246770) < 245 ? 0 : 2;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ade.a(" + ')');
      }
   }

   public boolean Z(byte var1) {
      try {
         return this.I.B(-325188584).C(2056702911) >= 245;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ade.z(" + ')');
      }
   }

   public static int C(int var0, int var1) {
      try {
         int var2 = var0 >>> 1;
         var2 |= var2 >>> 1;
         var2 |= var2 >>> 2;
         var2 |= var2 >>> 4;
         var2 |= var2 >>> 8;
         var2 |= var2 >>> 16;
         return var0 & ~var2;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ade.i(" + ')');
      }
   }
}
