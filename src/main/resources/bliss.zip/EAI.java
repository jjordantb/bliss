public interface EAI {
   boolean method262();

   boolean method263(String var1, int var2);

   boolean method264(int var1);

   boolean method265(String var1, int var2);

   boolean method266(String var1);

   boolean method267(String var1);

   boolean method268();

   boolean method269();

   boolean method270(String var1);
}
