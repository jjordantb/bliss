public class AX extends SX {
   void I(BU var1, int var2, byte var3) {
      try {
         RF.I(var1, var2, -646004957);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "aem.l(" + ')');
      }
   }

   public AX() {
      super(true);
   }

   void append(BU var1, int var2) {
      RF.I(var1, var2, -1673739713);
   }
}
