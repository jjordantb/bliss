public class GBI {
   UT F;
   CX YA;
   int append = 0;
   IR ga;
   byte m;
   int I;
   int Z;
   boolean method4728 = false;
   boolean method4781 = false;
   SX method4786;
   int method5082;
   int n = -1646192771;
   boolean[] toString;
   DX C;
   boolean B;
   GJI D;
   boolean J = false;
   int S;
   GQ A;
   byte E;

   public void I(int var1, int var2) {
      try {
         this.method4781 = true;
         this.YA(false, var1, 1, -933534749);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ck.a(" + ')');
      }
   }

   void I(DX var1, int var2) {
      try {
         this.C = var1;
         this.F = null;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ck.b(" + ')');
      }
   }

   int I(int var1) {
      try {
         return -this.Z(-46753485);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ck.p(" + ')');
      }
   }

   final UT I(GSI var1, int var2, boolean var3, boolean var4, byte var5) {
      try {
         KEI var6 = this.YA.C(1686561661 * this.S);
         if (var6.C != null) {
            var6 = var6.I((FAI)(1596783995 * XEI.uI == 0 ? PFI.D : MI.E), (int)1333630702);
         }

         if (var6 == null) {
            this.Z(var1, -475225909);
            this.n = -1646192771;
            return null;
         } else {
            if (!this.method4781 && -72440277 * this.n != var6.Z * 1181652947) {
               this.YA(true, -1, 0, 2114520079);
               this.J = false;
               this.F = null;
            }

            this.F(this.ga, 1121645041);
            if (var4) {
               var4 &= this.B & !this.J & FW.J.m.C(-896655100) != 0;
            }

            if (var3 && !var4) {
               this.n = -722933511 * var6.Z;
               return null;
            } else {
               SF var7 = this.ga.I().I;
               AP var8 = XEI.mI.T(-1611682495);
               if (var4) {
                  var8.I(this.D, this.m, (int)var7.I, (int)var7.Z, this.toString, 528677416);
                  this.J = false;
               }

               YJI var9 = var8.G[this.m];
               YJI var10;
               if (this.method4728) {
                  var10 = var8.K[0];
               } else {
                  var10 = this.m < 3 ? var8.G[1 + this.m] : null;
               }

               UT var11 = null;
               if (this.method4786.I((byte)-82)) {
                  if (var4) {
                     var2 |= 262144;
                  }

                  var11 = var6.I(var1, var2, 11 != this.I * -1598457753 ? -1598457753 * this.I : 10, 11 == -1598457753 * this.I ? 4 + this.Z * 748228569 : 748228569 * this.Z, var9, var10, (int)var7.I, var9.I((int)var7.I, (int)var7.Z, -1408801129), (int)var7.Z, this.method4786, this.C, (byte)18);
                  if (var11 != null) {
                     if (var4) {
                        if (this.toString == null) {
                           this.toString = new boolean[4];
                        }

                        this.D = var11.ga(this.D);
                        var8.Z(this.D, this.m, (int)var7.I, (int)var7.Z, this.toString, -1719073428);
                        this.J = true;
                     }

                     this.append = var11.YA() * -1931353415;
                     var11.n();
                  } else {
                     this.toString = null;
                     this.D = null;
                     this.append = 0;
                  }

                  this.F = null;
               } else if (this.F != null && (this.F.m() & var2) == var2 && -72440277 * this.n == 1181652947 * var6.Z) {
                  var11 = this.F;
               } else {
                  if (this.F != null) {
                     var2 |= this.F.m();
                  }

                  ZY var12 = var6.I(var1, var2, this.I * -1598457753 != 11 ? -1598457753 * this.I : 10, 11 == this.I * -1598457753 ? 748228569 * this.Z + 4 : 748228569 * this.Z, var9, var10, (int)var7.I, var9.I((int)var7.I, (int)var7.Z, -1367024792), (int)var7.Z, var4, this.C, -105046202);
                  if (var12 != null) {
                     this.F = var11 = (UT)var12.I;
                     if (var4) {
                        this.D = (GJI)var12.Z;
                        this.toString = null;
                        var8.Z(this.D, this.m, (int)var7.I, (int)var7.Z, (boolean[])null, -1920595487);
                        this.J = true;
                     }

                     this.append = var11.YA() * -1931353415;
                     var11.n();
                  } else {
                     this.toString = null;
                     this.D = null;
                     this.F = null;
                     this.append = 0;
                  }
               }

               this.n = var6.Z * -722933511;
               return var11;
            }
         }
      } catch (RuntimeException var13) {
         throw DQ.I(var13, "ck.i(" + ')');
      }
   }

   void I(GSI var1, UT var2, LF var3, int var4, int var5, int var6, int var7, boolean var8, int var9) {
      try {
         NFI[] var10 = var2.method4781();
         WBI[] var11 = var2.method4728();
         if ((this.A == null || this.A.S) && (var10 != null || var11 != null)) {
            KEI var12 = this.YA.C(1686561661 * this.S);
            if (var12.C != null) {
               var12 = var12.I((FAI)(XEI.uI * 1596783995 == 0 ? PFI.D : MI.E), (int)1897177328);
            }

            if (var12 != null) {
               this.A = GQ.I(XEI.kB * 443738891, true);
            }
         }

         if (this.A != null) {
            var2.method4786(var3);
            if (var8) {
               this.A.I(var1, (long)(XEI.kB * 443738891), var10, var11, false);
            } else {
               this.A.I((long)(443738891 * XEI.kB));
            }

            this.A.I(this.E, var4, var5, var6, var7);
         }

      } catch (RuntimeException var13) {
         throw DQ.I(var13, "ck.k(" + ')');
      }
   }

   void I(GSI var1, int var2) {
      try {
         this.I(var1, 262144, true, true, (byte)2);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ck.u(" + ')');
      }
   }

   GBI(GSI var1, CX var2, KEI var3, int var4, int var5, int var6, int var7, IR var8, boolean var9, int var10) {
      this.YA = var2;
      this.S = -2096584305 * var3.Z;
      this.I = -1523702953 * var4;
      this.Z = var5 * -1809022871;
      this.ga = var8;
      this.method4781 = -1 != var10;
      this.E = (byte)var6;
      this.m = (byte)var7;
      this.method4728 = var9;
      this.B = var1.method5082() && var3.CI && !this.method4728;
      this.method4786 = new EX(var8, false);
      this.YA(false, var10, 1, 126217673);
   }

   void F(IR var1, int var2) {
      try {
         if (this.method4786.I((byte)-77)) {
            if (this.method4786.Z(XEI.kB * 443738891 - -735091231 * this.method5082, 1976097000)) {
               if (FW.J.m.C(-184271029) == 2) {
                  this.J = false;
               }

               if (this.method4786.D(-1768742219)) {
                  this.method4786.I(-1, (int)-1793536388);
                  this.method4781 = false;
                  this.YA(false, -1, 0, 66091574);
               }
            }
         } else {
            this.YA(false, -1, 0, 2063242000);
         }

         this.method5082 = -803072405 * XEI.kB;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ck.r(" + ')');
      }
   }

   void YA(boolean var1, int var2, int var3, int var4) {
      try {
         int var5 = var2;
         boolean var6 = false;
         if (var2 == -1) {
            KEI var7 = this.YA.C(this.S * 1686561661);
            KEI var8 = var7;
            if (var7.C != null) {
               var7 = var7.I((FAI)(1596783995 * XEI.uI == 0 ? PFI.D : MI.E), (int)1802349433);
            }

            if (var7 == null) {
               return;
            }

            if (var7 == var8) {
               var8 = null;
            }

            if (var7.C(934270378)) {
               if (var1 && this.method4786.I((byte)-5) && var7.I(this.method4786.Z(2076230166), 1402053046)) {
                  return;
               }

               if (1181652947 * var7.Z != -72440277 * this.n) {
                  var6 = var7.II;
               }

               var5 = var7.I((byte)14);
               if (var7.B(-1966445745)) {
                  var3 = 0;
               } else {
                  var3 = 1;
               }
            } else if (var8 != null && var8.C(934270378)) {
               if (var1 && this.method4786.I((byte)-12) && var8.I(this.method4786.Z(1572334487), 1867786247)) {
                  return;
               }

               if (this.n * -72440277 != 1181652947 * var7.Z) {
                  var6 = var8.II;
               }

               var5 = var8.I((byte)14);
               if (var8.B(-1966445745)) {
                  var3 = 0;
               } else {
                  var3 = 1;
               }
            }
         }

         if (var5 == -1) {
            this.method4786.I(-1, false, 79187064);
         } else {
            this.method4786.I(var5, 0, var3, var6, (byte)0);
            this.method5082 = XEI.kB * -803072405;
            this.J = false;
            this.F = null;
         }

      } catch (RuntimeException var9) {
         throw DQ.I(var9, "ck.q(" + ')');
      }
   }

   int Z(int var1) {
      try {
         return -60718199 * this.append;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ck.f(" + ')');
      }
   }

   boolean C(int var1) {
      try {
         return this.B;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ck.d(" + ')');
      }
   }

   void Z(GSI var1, int var2) {
      try {
         if (this.D != null) {
            SF var3 = this.ga.I().I;
            XEI.mI.T(-1611682495).I(this.D, this.m, (int)var3.I, (int)var3.Z, this.toString, 677085165);
            this.toString = null;
            this.D = null;
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ck.x(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.J -= -783761378;
         int var2 = var0.H[var0.J * 681479919];
         int var3 = var0.H[var0.J * 681479919 + 1];
         if (var3 == -1) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = -1;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = GSI.OZ.I(var2, 2082342727).I((char)var3, 166344309);
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ck.acw(" + ')');
      }
   }

   public static void I(HZI var0, int var1, int var2, HAI var3, int var4) {
      try {
         OU var5 = UD.Z(407967339);
         var5.I = var3;
         UEI.I(var0, var1, var2, var5, 536465062);
         var5.I = null;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ck.u(" + ')');
      }
   }

   public static void I(boolean var0, int var1) {
      try {
         if (WA.B == null) {
            GSI.L(-1748236923);
         }

         if (var0) {
            WA.B.I((byte)-102);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ck.b(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         O.I(var3, var0, (byte)0);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ck.qo(" + ')');
      }
   }

   static final void I(OU var0, short var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = JH.R.I(var2).R * 1764050979;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ck.aby(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         if (XEI.LC != null) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = -1801543887 * UII.I;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ck.wx(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, byte var3) {
      try {
         var2.J -= -1175642067;
         int var4 = var2.H[681479919 * var2.J];
         short var5 = (short)var2.H[var2.J * 681479919 + 1];
         short var6 = (short)var2.H[var2.J * 681479919 + 2];
         if (var4 >= 0 && var4 < 5) {
            var0.Z(var4, var5, var6, -162772929);
            VEI.I(var0, -882757286);
            if (var0.a * -1309843523 == -1 && !var1.I) {
               LX.I(var0.V * -440872681, var4, 227307662);
            }
         }

      } catch (RuntimeException var7) {
         throw DQ.I(var7, "ck.gv(" + ')');
      }
   }
}
