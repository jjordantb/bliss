import jagdx.IDirect3DCubeTexture;
import jagdx.IDirect3DDevice;
import java.nio.ByteBuffer;

public class ED extends SD implements ZEI {
   int CreateCubeTexture;

   public void method122(EB var1) {
      super.method122(var1);
   }

   public void method128() {
      this.D.I((SD)this);
   }

   public void b() {
      super.b();
   }

   public void method126() {
      this.D.I((SD)this);
   }

   public void d() {
      super.b();
   }

   public void method125() {
      this.D.I((SD)this);
   }

   ED(PJI var1, int var2, boolean var3, int[][] var4) {
      super(var1, YCI.Z, SDI.C, var3 && var1.SZ, var2 * var2 * 6);
      this.CreateCubeTexture = var2;
      if (this.I) {
         this.Z = IDirect3DDevice.CreateCubeTexture(this.D.FZ, this.CreateCubeTexture, 0, 1024, 21, 1);
      } else {
         this.Z = IDirect3DDevice.CreateCubeTexture(this.D.FZ, this.CreateCubeTexture, 1, 0, 21, 1);
      }

      ByteBuffer var5 = this.D.F;

      for(int var6 = 0; var6 < 6; ++var6) {
         var5.clear();
         var5.asIntBuffer().put(var4[var6]);
         IDirect3DCubeTexture.Upload(this.Z, var6, 0, 0, 0, this.CreateCubeTexture, this.CreateCubeTexture, this.CreateCubeTexture * 4, 0, this.D.J);
      }

   }

   public void x() {
      super.b();
   }

   public void u() {
      super.b();
   }

   public void method123() {
      this.D.I((SD)this);
   }

   public void method127(EB var1) {
      super.method122(var1);
   }

   public void method124(EB var1) {
      super.method122(var1);
   }

   public void method129(EB var1) {
      super.method122(var1);
   }
}
