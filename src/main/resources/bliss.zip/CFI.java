public class CFI extends LDI {
   int append;
   int toString;
   String Z;
   int C;
   int B;

   CFI(REI var1) {
      super(var1);
      this.B = var1.C() * -1972913347;
      this.append = var1.C() * 1250113173;
      this.Z = var1.E(2035314126);
      this.toString = var1.H((byte)53) * -1423918679;
      this.C = var1.C() * 1154354255;
   }

   public void method869() {
      AN.I(1855729883 * EJI.Z, -1180797931 * this.B, -1854610243 * this.append, NQ.I(-1180797931 * this.B, this.append * -1854610243, 1855729883 * EJI.Z, -2129149221), this.C * -745698641, this.toString * 1817377433, this.Z, 1145625350);
   }

   public void method868() {
      AN.I(1855729883 * EJI.Z, -1180797931 * this.B, -1854610243 * this.append, NQ.I(-1180797931 * this.B, this.append * -1854610243, 1855729883 * EJI.Z, -1605294967), this.C * -745698641, this.toString * 1817377433, this.Z, 531512737);
   }

   public void method866(int var1) {
      try {
         AN.I(1855729883 * EJI.Z, -1180797931 * this.B, -1854610243 * this.append, NQ.I(-1180797931 * this.B, this.append * -1854610243, 1855729883 * EJI.Z, -1944886078), this.C * -745698641, this.toString * 1817377433, this.Z, 1123266965);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "yn.f(" + ')');
      }
   }

   static void I(byte var0) {
      try {
         PK var1 = GB.I(MEI.s, XEI.eI.Z, (byte)17);
         var1.J.B(XEI.hI * -2059460167, -1112529192);
         XEI.eI.I(var1, (byte)-106);
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "yn.ns(" + ')');
      }
   }

   public static void Z(int var0, byte var1) {
      try {
         VK var2 = IV.I(16, (long)var0);
         var2.B(-2024208824);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "yn.l(" + ')');
      }
   }

   static void I(int var0, int var1, int var2, int var3, int var4) {
      try {
         VK var5 = IV.I(18, (long)var1 << 32 | (long)var0);
         var5.I((byte)25);
         var5.L = 1274450087 * var2;
         var5.H = var3 * 293101103;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "yn.am(" + ')');
      }
   }
}
