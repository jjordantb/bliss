public abstract class IX {
   IX() throws Throwable {
      throw new Error();
   }

   public static final void I(int var0, int var1, int var2, int var3, int var4, int var5, int var6, byte var7) {
      try {
         if (var0 >= -1424479739 * DT.D && var1 <= 1135094847 * DT.Z && var2 >= 1155384281 * DT.C && var3 <= DT.B * -1062447355) {
            OS.I(var0, var1, var2, var3, var4, var5, var6, (byte)76);
         } else {
            AEI.I(var0, var1, var2, var3, var4, var5, var6, (byte)-89);
         }

      } catch (RuntimeException var9) {
         throw DQ.I(var9, "ru.u(" + ')');
      }
   }
}
