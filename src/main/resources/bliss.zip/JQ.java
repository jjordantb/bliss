public final class JQ {
   JX J;
   EY Z;
   int append;
   int method3437;

   void J(LL var1, int var2) {
      try {
         if (var1 != null) {
            var1.I(-1460969981);
            var1.C(-2141988967);
            this.append += -1044171843 * var1.G;
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "on.b(" + ')');
      }
   }

   public int I(byte var1) {
      try {
         int var2 = 0;

         for(LL var3 = (LL)this.Z.Z(1659179977); var3 != null; var3 = (LL)this.Z.C(1776119940)) {
            if (!var3.method3438(1593047308)) {
               ++var2;
            }
         }

         return var2;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "on.r(" + ')');
      }
   }

   public Object I(long var1) {
      try {
         LL var3 = (LL)this.J.I(var1);
         if (var3 == null) {
            return null;
         } else {
            Object var4 = var3.method3437(-1395408926);
            if (var4 == null) {
               var3.I(-1460969981);
               var3.C(-300474257);
               this.append += var3.G * -1044171843;
               return null;
            } else {
               if (var3.method3438(-1388215910)) {
                  ML var5 = new ML(var4, 1980662847 * var3.G);
                  this.J.I(var5, var3.Z * 7051297995265073167L);
                  this.Z.I(var5, (byte)-4);
                  var5.A = 0L;
                  var3.I(-1460969981);
                  var3.C(1072331765);
               } else {
                  this.Z.I(var3, (byte)-40);
                  var3.A = 0L;
               }

               return var4;
            }
         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "on.a(" + ')');
      }
   }

   public void I(Object var1, long var2, int var4, byte var5) {
      try {
         if (var4 > this.method3437 * 2087531591) {
            throw new IllegalStateException();
         } else {
            this.Z(var2);
            this.append -= -1846372093 * var4;

            while(1177262507 * this.append < 0) {
               LL var6 = (LL)this.Z.I(-2130209329);
               this.J(var6, -1092506029);
            }

            ML var8 = new ML(var1, var4);
            this.J.I(var8, var2);
            this.Z.I(var8, (byte)-108);
            var8.A = 0L;
         }
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "on.i(" + ')');
      }
   }

   public void I(int var1, int var2) {
      try {
         for(LL var3 = (LL)this.Z.Z(-1737359401); var3 != null; var3 = (LL)this.Z.C(1372068776)) {
            if (var3.method3438(504566053)) {
               if (var3.method3437(1618549592) == null) {
                  var3.I(-1460969981);
                  var3.C(932803925);
                  this.append += -1044171843 * var3.G;
               }
            } else if ((var3.A += 1476940603538232441L) * -5533549728640346679L > (long)var1) {
               NL var4 = new NL(var3.method3437(1802409899), var3.G * 1980662847);
               this.J.I(var4, 7051297995265073167L * var3.Z);
               FY.I(var4, var3, -2008394772);
               var3.I(-1460969981);
               var3.C(357875821);
            }
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "on.k(" + ')');
      }
   }

   public void I() {
      try {
         this.Z.B(1649887220);
         this.J.I((byte)-88);
         this.append = 1537477589 * this.method3437;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "on.d(" + ')');
      }
   }

   public int I(int var1) {
      try {
         return this.method3437 * 2087531591;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "on.u(" + ')');
      }
   }

   public JQ(int var1) {
      this(var1, var1);
   }

   public void Z() {
      try {
         for(LL var1 = (LL)this.Z.Z(-1664121892); var1 != null; var1 = (LL)this.Z.C(-1665993458)) {
            if (var1.method3438(2031877244)) {
               var1.I(-1460969981);
               var1.C(784746714);
               this.append += -1044171843 * var1.G;
            }
         }

      } catch (RuntimeException var2) {
         throw DQ.I(var2, "on.q(" + ')');
      }
   }

   public Object Z(int var1) {
      try {
         LL var4;
         for(LL var2 = (LL)this.J.C(2018189704); var2 != null; this.append += -1044171843 * var4.G) {
            Object var3 = var2.method3437(-709026193);
            if (var3 != null) {
               return var3;
            }

            var4 = var2;
            var2 = (LL)this.J.Z((byte)18);
            var4.I(-1460969981);
            var4.C(600406320);
         }

         return null;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "on.n(" + ')');
      }
   }

   public Object C(int var1) {
      try {
         LL var4;
         for(LL var2 = (LL)this.J.Z((byte)37); var2 != null; this.append += -1044171843 * var4.G) {
            Object var3 = var2.method3437(110174403);
            if (var3 != null) {
               return var3;
            }

            var4 = var2;
            var2 = (LL)this.J.Z((byte)35);
            var4.I(-1460969981);
            var4.C(538286919);
         }

         return null;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "on.s(" + ')');
      }
   }

   public int B(int var1) {
      try {
         return this.append * 1177262507;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "on.x(" + ')');
      }
   }

   public void Z(long var1) {
      try {
         LL var3 = (LL)this.J.I(var1);
         this.J(var3, -1811015164);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "on.f(" + ')');
      }
   }

   public void I(Object var1, long var2) {
      try {
         this.I(var1, var2, 1, (byte)-117);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "on.p(" + ')');
      }
   }

   public JQ(int var1, int var2) {
      this.Z = new EY();
      this.method3437 = var1 * -1371130505;
      this.append = -1846372093 * var1;

      int var3;
      for(var3 = 1; var3 + var3 < var1 && var3 < var2; var3 += var3) {
         ;
      }

      this.J = new JX(var3);
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         FW.J.I(FW.J.K, var2, 1144244334);
         XEI.mI.P(458039847);
         JN.I(656179282);
         XEI.w = false;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "on.ahd(" + ')');
      }
   }

   public static BV[] D(int var0) {
      try {
         return new BV[]{BV.F, BV.A, BV.D, BV.H, BV.K, BV.Z, BV.G, BV.J, BV.C, BV.I, BV.E, BV.L, BV.S, BV.B};
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "on.a(" + ')');
      }
   }

   public static int I(int var0, int var1, boolean var2, byte var3) {
      try {
         DN var4 = CS.I(var0, var2, 1780285943);
         if (var4 == null) {
            return 0;
         } else if (var1 == -1) {
            return 0;
         } else {
            int var5 = 0;

            for(int var6 = 0; var6 < var4.G.length; ++var6) {
               if (var1 == var4.E[var6]) {
                  var5 += var4.G[var6];
               }
            }

            return var5;
         }
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "on.b(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         int var2 = var0.X[var0.i * 1883543357];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = ((GEI)var0.E).qI.I(var2, -966489489);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "on.ao(" + ')');
      }
   }
}
