import java.util.Random;

public class EH extends YG {
   static int sqrt = 3;
   static int Q = 1;
   static int R = 2;
   static int T = 2048;
   short[] U = new short[512];
   static int V = 1;
   static int W = 2;
   byte[] X = new byte[512];
   static int Y = 0;
   static int i = 5;
   static int z = 0;
   static int c = 2;
   static int b = 5;
   static int d = 4;
   static int f = 1;
   int j = 0;
   int s = -1678309376;
   int a = 1054806071;
   int e = 1710056533;
   int g = 1239043726;
   int h = -1784051459;
   static int k = 4;
   static int l = 3;

   int[] Z(int var1, int var2) {
      try {
         int[] var3 = this.P.I(var1, 1076087457);
         if (this.P.D) {
            int var4 = -1818338063 * this.e * WJ.J[var1] + 2048;
            int var5 = var4 >> 12;
            int var6 = 1 + var5;

            for(int var7 = 0; var7 < WJ.C * -1474554145; ++var7) {
               OII.E = 1648440697;
               PQ.K = -495419991;
               ZV.E = -586878723;
               OH.W = -1158324685;
               int var8 = 883178403 * this.a * WJ.A[var7] + 2048;
               int var9 = var8 >> 12;
               int var10 = 1 + var9;

               for(int var11 = var5 - 1; var11 <= var6; ++var11) {
                  int var12 = this.X[(var11 >= -1818338063 * this.e ? var11 - this.e * -1818338063 : var11) & 255] & 255;

                  for(int var13 = var9 - 1; var13 <= var10; ++var13) {
                     int var14 = (this.X[(var13 >= this.a * 883178403 ? var13 - this.a * 883178403 : var13) + var12 & 255] & 255) * 2;
                     int var15 = var8 - (this.U[var14++] + (var13 << 12));
                     int var16 = var4 - ((var11 << 12) + this.U[var14]);
                     int var17;
                     switch(this.h * -1013656491) {
                     case 1:
                        var17 = var15 * var15 + var16 * var16 >> 12;
                        break;
                     case 2:
                        var17 = (var16 < 0 ? -var16 : var16) + (var15 < 0 ? -var15 : var15);
                        break;
                     case 3:
                        var15 = var15 < 0 ? -var15 : var15;
                        var16 = var16 < 0 ? -var16 : var16;
                        var17 = var15 > var16 ? var15 : var16;
                        break;
                     case 4:
                        var15 = (int)(Math.sqrt((double)((float)(var15 < 0 ? -var15 : var15) / 4096.0F)) * 4096.0D);
                        var16 = (int)(Math.sqrt((double)((float)(var16 < 0 ? -var16 : var16) / 4096.0F)) * 4096.0D);
                        var17 = var16 + var15;
                        var17 = var17 * var17 >> 12;
                        break;
                     case 5:
                        var15 *= var15;
                        var16 *= var16;
                        var17 = (int)(Math.sqrt(Math.sqrt((double)((float)(var15 + var16) / 1.6777216E7F))) * 4096.0D);
                        break;
                     default:
                        var17 = (int)(Math.sqrt((double)((float)(var16 * var16 + var15 * var15) / 1.6777216E7F)) * 4096.0D);
                     }

                     if (var17 < -1479855355 * OH.W) {
                        OII.E = PQ.K * 335526737;
                        PQ.K = ZV.E * 1817789725;
                        ZV.E = OH.W * 256238607;
                        OH.W = -989158963 * var17;
                     } else if (var17 < -618310741 * ZV.E) {
                        OII.E = PQ.K * 335526737;
                        PQ.K = 1817789725 * ZV.E;
                        ZV.E = -1560604925 * var17;
                     } else if (var17 < -472479385 * PQ.K) {
                        OII.E = PQ.K * 335526737;
                        PQ.K = -1652063657 * var17;
                     } else if (var17 < OII.E * -1065886921) {
                        OII.E = var17 * 499042951;
                     }
                  }
               }

               switch(-94219657 * this.g) {
               case 0:
                  var3[var7] = -1479855355 * OH.W;
                  break;
               case 1:
                  var3[var7] = ZV.E * -618310741;
                  break;
               case 2:
                  var3[var7] = -618310741 * ZV.E - -1479855355 * OH.W;
                  break;
               case 3:
                  var3[var7] = -472479385 * PQ.K;
                  break;
               case 4:
                  var3[var7] = -1065886921 * OII.E;
               }
            }
         }

         return var3;
      } catch (RuntimeException var18) {
         throw DQ.I(var18, "ahf.i(" + ')');
      }
   }

   void B(int var1) {
      try {
         this.X = WJ.I(35399273 * this.j, (byte)47);
         this.append(-804707257);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ahf.x(" + ')');
      }
   }

   void Z() {
      this.X = WJ.I(35399273 * this.j, (byte)50);
      this.append(-975250951);
   }

   void append(int var1) {
      try {
         Random var2 = new Random((long)(this.j * 35399273));
         this.U = new short[512];
         if (this.s * -1261812447 > 0) {
            for(int var3 = 0; var3 < 512; ++var3) {
               this.U[var3] = (short)IG.I(var2, -1261812447 * this.s, (byte)14);
            }
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ahf.ac(" + ')');
      }
   }

   int[] sqrt(int var1) {
      int[] var2 = this.P.I(var1, 538924530);
      if (this.P.D) {
         int var3 = -1818338063 * this.e * WJ.J[var1] + 2048;
         int var4 = var3 >> 12;
         int var5 = 1 + var4;

         for(int var6 = 0; var6 < WJ.C * -1474554145; ++var6) {
            OII.E = 1648440697;
            PQ.K = -495419991;
            ZV.E = -586878723;
            OH.W = -1158324685;
            int var7 = 883178403 * this.a * WJ.A[var6] + 2048;
            int var8 = var7 >> 12;
            int var9 = 1 + var8;

            for(int var10 = var4 - 1; var10 <= var5; ++var10) {
               int var11 = this.X[(var10 >= -1818338063 * this.e ? var10 - this.e * -1818338063 : var10) & 255] & 255;

               for(int var12 = var8 - 1; var12 <= var9; ++var12) {
                  int var13 = (this.X[(var12 >= this.a * 883178403 ? var12 - this.a * 883178403 : var12) + var11 & 255] & 255) * 2;
                  int var14 = var7 - (this.U[var13++] + (var12 << 12));
                  int var15 = var3 - ((var10 << 12) + this.U[var13]);
                  int var16;
                  switch(this.h * -1013656491) {
                  case 1:
                     var16 = var14 * var14 + var15 * var15 >> 12;
                     break;
                  case 2:
                     var16 = (var15 < 0 ? -var15 : var15) + (var14 < 0 ? -var14 : var14);
                     break;
                  case 3:
                     var14 = var14 < 0 ? -var14 : var14;
                     var15 = var15 < 0 ? -var15 : var15;
                     var16 = var14 > var15 ? var14 : var15;
                     break;
                  case 4:
                     var14 = (int)(Math.sqrt((double)((float)(var14 < 0 ? -var14 : var14) / 4096.0F)) * 4096.0D);
                     var15 = (int)(Math.sqrt((double)((float)(var15 < 0 ? -var15 : var15) / 4096.0F)) * 4096.0D);
                     var16 = var15 + var14;
                     var16 = var16 * var16 >> 12;
                     break;
                  case 5:
                     var14 *= var14;
                     var15 *= var15;
                     var16 = (int)(Math.sqrt(Math.sqrt((double)((float)(var14 + var15) / 1.6777216E7F))) * 4096.0D);
                     break;
                  default:
                     var16 = (int)(Math.sqrt((double)((float)(var15 * var15 + var14 * var14) / 1.6777216E7F)) * 4096.0D);
                  }

                  if (var16 < -1479855355 * OH.W) {
                     OII.E = PQ.K * 335526737;
                     PQ.K = ZV.E * 1817789725;
                     ZV.E = OH.W * 256238607;
                     OH.W = -989158963 * var16;
                  } else if (var16 < -618310741 * ZV.E) {
                     OII.E = PQ.K * 335526737;
                     PQ.K = 1817789725 * ZV.E;
                     ZV.E = -1560604925 * var16;
                  } else if (var16 < -472479385 * PQ.K) {
                     OII.E = PQ.K * 335526737;
                     PQ.K = -1652063657 * var16;
                  } else if (var16 < OII.E * -1065886921) {
                     OII.E = var16 * 499042951;
                  }
               }
            }

            switch(-94219657 * this.g) {
            case 0:
               var2[var6] = -1479855355 * OH.W;
               break;
            case 1:
               var2[var6] = ZV.E * -618310741;
               break;
            case 2:
               var2[var6] = -618310741 * ZV.E - -1479855355 * OH.W;
               break;
            case 3:
               var2[var6] = -472479385 * PQ.K;
               break;
            case 4:
               var2[var6] = -1065886921 * OII.E;
            }
         }
      }

      return var2;
   }

   int[] toString(int var1) {
      int[] var2 = this.P.I(var1, 1191732037);
      if (this.P.D) {
         int var3 = -1818338063 * this.e * WJ.J[var1] + 2048;
         int var4 = var3 >> 12;
         int var5 = 1 + var4;

         for(int var6 = 0; var6 < WJ.C * -1474554145; ++var6) {
            OII.E = 1648440697;
            PQ.K = -495419991;
            ZV.E = -586878723;
            OH.W = -1158324685;
            int var7 = 883178403 * this.a * WJ.A[var6] + 2048;
            int var8 = var7 >> 12;
            int var9 = 1 + var8;

            for(int var10 = var4 - 1; var10 <= var5; ++var10) {
               int var11 = this.X[(var10 >= -1818338063 * this.e ? var10 - this.e * -1818338063 : var10) & 255] & 255;

               for(int var12 = var8 - 1; var12 <= var9; ++var12) {
                  int var13 = (this.X[(var12 >= this.a * 883178403 ? var12 - this.a * 883178403 : var12) + var11 & 255] & 255) * 2;
                  int var14 = var7 - (this.U[var13++] + (var12 << 12));
                  int var15 = var3 - ((var10 << 12) + this.U[var13]);
                  int var16;
                  switch(this.h * -1013656491) {
                  case 1:
                     var16 = var14 * var14 + var15 * var15 >> 12;
                     break;
                  case 2:
                     var16 = (var15 < 0 ? -var15 : var15) + (var14 < 0 ? -var14 : var14);
                     break;
                  case 3:
                     var14 = var14 < 0 ? -var14 : var14;
                     var15 = var15 < 0 ? -var15 : var15;
                     var16 = var14 > var15 ? var14 : var15;
                     break;
                  case 4:
                     var14 = (int)(Math.sqrt((double)((float)(var14 < 0 ? -var14 : var14) / 4096.0F)) * 4096.0D);
                     var15 = (int)(Math.sqrt((double)((float)(var15 < 0 ? -var15 : var15) / 4096.0F)) * 4096.0D);
                     var16 = var15 + var14;
                     var16 = var16 * var16 >> 12;
                     break;
                  case 5:
                     var14 *= var14;
                     var15 *= var15;
                     var16 = (int)(Math.sqrt(Math.sqrt((double)((float)(var14 + var15) / 1.6777216E7F))) * 4096.0D);
                     break;
                  default:
                     var16 = (int)(Math.sqrt((double)((float)(var15 * var15 + var14 * var14) / 1.6777216E7F)) * 4096.0D);
                  }

                  if (var16 < -1479855355 * OH.W) {
                     OII.E = PQ.K * 335526737;
                     PQ.K = ZV.E * 1817789725;
                     ZV.E = OH.W * 256238607;
                     OH.W = -989158963 * var16;
                  } else if (var16 < -618310741 * ZV.E) {
                     OII.E = PQ.K * 335526737;
                     PQ.K = 1817789725 * ZV.E;
                     ZV.E = -1560604925 * var16;
                  } else if (var16 < -472479385 * PQ.K) {
                     OII.E = PQ.K * 335526737;
                     PQ.K = -1652063657 * var16;
                  } else if (var16 < OII.E * -1065886921) {
                     OII.E = var16 * 499042951;
                  }
               }
            }

            switch(-94219657 * this.g) {
            case 0:
               var2[var6] = -1479855355 * OH.W;
               break;
            case 1:
               var2[var6] = ZV.E * -618310741;
               break;
            case 2:
               var2[var6] = -618310741 * ZV.E - -1479855355 * OH.W;
               break;
            case 3:
               var2[var6] = -472479385 * PQ.K;
               break;
            case 4:
               var2[var6] = -1065886921 * OII.E;
            }
         }
      }

      return var2;
   }

   void I(int var1, REI var2, byte var3) {
      try {
         switch(var1) {
         case 0:
            this.a = (this.e = var2.I() * 2059998225) * -910111141;
            break;
         case 1:
            this.j = var2.I() * -893138471;
            break;
         case 2:
            this.s = var2.C() * 1389592289;
            break;
         case 3:
            this.g = var2.I() * -1527961785;
            break;
         case 4:
            this.h = var2.I() * -1784051459;
            break;
         case 5:
            this.a = var2.I() * -648032245;
            break;
         case 6:
            this.e = var2.I() * 2059998225;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ahf.r(" + ')');
      }
   }

   void append() {
      this.X = WJ.I(35399273 * this.j, (byte)-59);
      this.append(1419756353);
   }

   public EH() {
      super(0, true);
   }

   void sqrt(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.a = (this.e = var2.I() * 2059998225) * -910111141;
         break;
      case 1:
         this.j = var2.I() * -893138471;
         break;
      case 2:
         this.s = var2.C() * 1389592289;
         break;
      case 3:
         this.g = var2.I() * -1527961785;
         break;
      case 4:
         this.h = var2.I() * -1784051459;
         break;
      case 5:
         this.a = var2.I() * -648032245;
         break;
      case 6:
         this.e = var2.I() * 2059998225;
      }

   }

   void toString(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.a = (this.e = var2.I() * 2059998225) * -910111141;
         break;
      case 1:
         this.j = var2.I() * -893138471;
         break;
      case 2:
         this.s = var2.C() * 1389592289;
         break;
      case 3:
         this.g = var2.I() * -1527961785;
         break;
      case 4:
         this.h = var2.I() * -1784051459;
         break;
      case 5:
         this.a = var2.I() * -648032245;
         break;
      case 6:
         this.e = var2.I() * 2059998225;
      }

   }

   void sqrt() {
      this.X = WJ.I(35399273 * this.j, (byte)-39);
      this.append(-1703391466);
   }
}
