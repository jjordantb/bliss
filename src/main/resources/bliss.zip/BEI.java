public interface BEI extends CEI {
   TAI method117(int var1);

   TAI method118(int var1);

   TAI method119(int var1);

   TAI method120(int var1);

   TAI method121(int var1);
}
