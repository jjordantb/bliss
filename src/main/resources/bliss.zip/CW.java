public class CW extends LV {
   public static int method5611 = 1;
   public static int toString = 0;

   public CW(MM var1) {
      super(var1);
   }

   public CW(int var1, MM var2) {
      super(var1, var2);
   }

   void method5610(int var1) {
      this.C = var1 * 1886334997;
   }

   int method5616(int var1) {
      return 1;
   }

   int method5612(int var1, int var2) {
      return 1;
   }

   void method5614(int var1, int var2) {
      try {
         this.C = var1 * 1886334997;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aef.p(" + ')');
      }
   }

   public int Z(byte var1) {
      try {
         return -1598873795 * this.C;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aef.z(" + ')');
      }
   }

   int method5615() {
      return 1;
   }

   public void C(byte var1) {
      try {
         if (-1598873795 * this.C != 1 && -1598873795 * this.C != 0) {
            this.C = this.method5611(2029882425) * 1886334997;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aef.s(" + ')');
      }
   }

   int method5611(int var1) {
      return 1;
   }
}
