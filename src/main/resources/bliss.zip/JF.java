import java.io.IOException;

public class JF implements JAI {
   String Z;
   KJ append;
   static String[] I;
   static int C;
   public static int B;
   static int D;

   public int method256(int var1) {
      try {
         return this.append.D(this.Z, -2147290732) ? 100 : this.append.C(this.Z, -1986969413);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jc.a(" + ')');
      }
   }

   public HY method260(int var1) {
      try {
         return HY.C;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jc.f(" + ')');
      }
   }

   JF(KJ var1, String var2) {
      this.append = var1;
      this.Z = var2;
   }

   public int method258() {
      return this.append.D(this.Z, -2133628727) ? 100 : this.append.C(this.Z, -162075659);
   }

   public HY method259() {
      return HY.C;
   }

   public HY method257() {
      return HY.C;
   }

   public HY method261() {
      return HY.C;
   }

   static BSI I(int var0, byte var1) {
      try {
         BSI var2 = (BSI)HU.I.I((long)var0);
         if (var2 != null) {
            return var2;
         } else {
            byte[] var3 = HT.Z.I(var0, 0, (byte)12);
            if (var3 != null && var3.length > 1) {
               try {
                  var2 = RC.I((byte[])var3, (byte)16);
               } catch (Exception var5) {
                  throw new RuntimeException(var5.getMessage() + " " + var0);
               }

               HU.I.I(var2, (long)var0);
               return var2;
            } else {
               return null;
            }
         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "jc.f(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         F var3 = XL.Z(var2, -500483592);
         String var4 = "";
         if (var3 != null && var3.D != null) {
            var4 = var3.D;
         }

         var0.S[(var0.A += 969361751) * -203050393 - 1] = var4;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "jc.acz(" + ')');
      }
   }

   public static int I(CharSequence var0, short var1) {
      try {
         return LV.I(var0, 10, true, -1228221916);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jc.i(" + ')');
      }
   }

   static String I(int[] var0, byte var1) {
      try {
         StringBuilder var2 = new StringBuilder();
         int var3 = -232961423 * EA.D;

         for(int var4 = 0; var4 < var0.length; ++var4) {
            UR var5 = OO.I.I(var0[var4], 245040087);
            if (var5.Q * 347977109 == -1) {
               if (var1 != 1) {
                  throw new IllegalStateException();
               }
            } else {
               IBI var6 = (IBI)FX.j.I((long)(347977109 * var5.Q));
               if (var6 == null) {
                  RFI var7 = RFI.I(EC.F, var5.Q * 347977109, 0);
                  if (var7 != null) {
                     var6 = FT.P.method5125(var7, true);
                     FX.j.I(var6, (long)(var5.Q * 347977109));
                  }
               }

               if (var6 != null) {
                  FX.s[var3] = var6;
                  var2.append(" <img=").append(var3).append(">");
                  ++var3;
               }
            }
         }

         return var2.toString();
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "jc.bc(" + ')');
      }
   }

   public static void I(boolean var0, boolean var1, short var2) {
      try {
         if (var0) {
            LT.C -= 1929855733;
            if (LT.C * -1320167075 == 0) {
               LT.Z = null;
            }
         }

         if (var1) {
            LT.I -= -1931699395;
            if (726176789 * LT.I == 0) {
               DE.I = null;
            }
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "jc.f(" + ')');
      }
   }

   public static final void I(boolean var0, byte var1) {
      try {
         VJ[] var2 = XEI.AI;

         for(int var3 = 0; var3 < var2.length; ++var3) {
            VJ var4 = var2[var3];

            try {
               var4.Z(-1494345865);
            } catch (IOException var7) {
               ;
            }

            var4.I((byte)56);
         }

         OL.F(-20644488);
         MF.I(false, -1663847334);
         XEI.mI.B((byte)8);
         XEI.mI.O(-2101576654);
         QW.I(false, 1336561252);
         S.I(2, 207248326);
         AN.B = 184109511;
         AN.D = false;
         KZ.I(-1865838561);
         TS.I(true, -2090545066);
         BB.Z(-1182326447);
         GI.Z(-1799886054);
         QS.I(-1759070114);
         if (var0) {
            HX.I(6, 628188692);
         } else {
            HX.I(19, -244529723);

            try {
               MY.I(DSI.C, "loggedout", (short)24145);
            } catch (Throwable var6) {
               ;
            }
         }

      } catch (RuntimeException var8) {
         throw DQ.I(var8, "jc.gi(" + ')');
      }
   }

   static void I(int var0, int var1) {
      try {
         DN.A = -747654435 * var0;
         DN.J.I();
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jc.s(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = UA.F.n.I((byte)0) >> 3;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jc.uc(" + ')');
      }
   }
}
