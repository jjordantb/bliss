public class AR extends SR implements HAI {
   boolean append = true;
   boolean gc;
   HP i;
   public GBI P;
   static long Q;

   final void method4378() {
      throw new IllegalStateException();
   }

   boolean method4350(GSI var1, int var2, int var3, byte var4) {
      try {
         UT var5 = this.P.I(var1, 131072, false, false, (byte)-17);
         return var5 == null ? false : var5.method4787(var2, var3, this.J(), false, 0);
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "wm.bu(" + ')');
      }
   }

   boolean method4376(short var1) {
      try {
         return this.append;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wm.be(" + ')');
      }
   }

   public HP method4358(GSI var1, byte var2) {
      try {
         return this.i;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "wm.bc(" + ')');
      }
   }

   boolean method4385(GSI var1, int var2, int var3) {
      UT var4 = this.P.I(var1, 131072, false, false, (byte)-18);
      return var4 == null ? false : var4.method4787(var2, var3, this.J(), false, 0);
   }

   public int Z(byte var1) {
      try {
         return this.P.I(2132571778);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wm.bx(" + ')');
      }
   }

   KP method4394(GSI var1, int var2) {
      try {
         UT var3 = this.P.I(var1, 2048, false, true, (byte)42);
         if (var3 == null) {
            return null;
         } else {
            LF var4 = this.J();
            ZJ var5 = this.I();
            KP var6 = BDI.I(this.gc, 1432921779);
            int var7 = (int)var5.I.I >> 9;
            int var8 = (int)var5.I.Z >> 9;
            this.P.I(var1, var3, var4, var7, var7, var8, var8, true, 244174707);
            var3.method4739(var4, this.N[0], 0);
            if (this.P.A != null) {
               XBI var9 = this.P.A.D();
               var1.method5042(var9);
            }

            this.append = var3.i() || this.P.A != null;
            if (this.i == null) {
               this.i = TY.I((int)var5.I.I, (int)var5.I.C, (int)var5.I.Z, var3, 2034122433);
            } else {
               QS.I(this.i, (int)var5.I.I, (int)var5.I.C, (int)var5.I.Z, var3, (byte)83);
            }

            return var6;
         }
      } catch (RuntimeException var10) {
         throw DQ.I(var10, "wm.bo(" + ')');
      }
   }

   public AR(AP var1, GSI var2, CX var3, KEI var4, int var5, int var6, int var7, int var8, int var9, boolean var10, int var11, int var12) {
      super(var1, var7, var8, var9, var5, var6, -228547261 * var4.n);
      this.P = new GBI(var2, var3, var4, RW.R.V * -1976050083, var11, var5, var6, this, var10, var12);
      this.gc = var4.K * 1532834983 != 0 && !var10;
      this.I(1, 397760713);
   }

   public void method40(GSI var1) {
      this.P.Z(var1, -475225909);
   }

   final boolean method4366(int var1) {
      return false;
   }

   final void method4355(GSI var1, IR var2, int var3, int var4, int var5, boolean var6, int var7) {
      try {
         throw new IllegalStateException();
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "wm.bk(" + ')');
      }
   }

   final void method4398(byte var1) {
      try {
         throw new IllegalStateException();
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wm.bq(" + ')');
      }
   }

   public int method32(byte var1) {
      try {
         return 1686561661 * this.P.S;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wm.a(" + ')');
      }
   }

   public int method29(int var1) {
      try {
         return -1598457753 * this.P.I;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wm.f(" + ')');
      }
   }

   public int method30(short var1) {
      try {
         return 748228569 * this.P.Z;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wm.b(" + ')');
      }
   }

   boolean method4372(GSI var1, int var2, int var3) {
      UT var4 = this.P.I(var1, 131072, false, false, (byte)-51);
      return var4 == null ? false : var4.method4787(var2, var3, this.J(), false, 0);
   }

   boolean method4399(byte var1) {
      return false;
   }

   final void method4388(GSI var1, IR var2, int var3, int var4, int var5, boolean var6) {
      throw new IllegalStateException();
   }

   public void I(DX var1, byte var2) {
      try {
         this.P.I(var1, -748656560);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "wm.by(" + ')');
      }
   }

   public void method37(GSI var1, int var2) {
      try {
         this.P.Z(var1, -475225909);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "wm.d(" + ')');
      }
   }

   public int method36() {
      return -1598457753 * this.P.I;
   }

   public int method35() {
      return -1598457753 * this.P.I;
   }

   public int method42() {
      return 748228569 * this.P.Z;
   }

   public int method38() {
      return 748228569 * this.P.Z;
   }

   public void method34() {
   }

   public boolean method41() {
      return this.P.C(16957801);
   }

   public void method28(GSI var1) {
      this.P.I(var1, -1400920433);
   }

   public void method43(GSI var1) {
      this.P.Z(var1, -475225909);
   }

   void method4373(GSI var1) {
      UT var2 = this.P.I(var1, 262144, true, true, (byte)5);
      if (var2 != null) {
         SF var3 = this.I().I;
         int var4 = (int)var3.I >> 9;
         int var5 = (int)var3.Z >> 9;
         this.P.I(var1, var2, this.J(), var4, var4, var5, var5, false, 264840409);
      }

   }

   public int method4361(int var1) {
      try {
         return this.P.Z(-2145027593);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wm.bm(" + ')');
      }
   }

   public int method45() {
      return 1686561661 * this.P.S;
   }

   boolean method4365() {
      return false;
   }

   boolean method4374() {
      return false;
   }

   public HP method4367(GSI var1) {
      return this.i;
   }

   public HP method4368(GSI var1) {
      return this.i;
   }

   public int append() {
      return this.P.I(2084300626);
   }

   public void method33(GSI var1, int var2) {
      try {
         this.P.I(var1, 1192057266);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "wm.k(" + ')');
      }
   }

   public void method44(GSI var1) {
      this.P.Z(var1, -475225909);
   }

   void method4371(GSI var1) {
      UT var2 = this.P.I(var1, 262144, true, true, (byte)-9);
      if (var2 != null) {
         SF var3 = this.I().I;
         int var4 = (int)var3.I >> 9;
         int var5 = (int)var3.Z >> 9;
         this.P.I(var1, var2, this.J(), var4, var4, var5, var5, false, 1404836454);
      }

   }

   public int method4380() {
      return this.P.Z(1657985578);
   }

   final boolean method4387() {
      return false;
   }

   public int method4381() {
      return this.P.Z(-1816306113);
   }

   boolean method4352(GSI var1, int var2, int var3) {
      UT var4 = this.P.I(var1, 131072, false, false, (byte)-102);
      return var4 == null ? false : var4.method4787(var2, var3, this.J(), false, 0);
   }

   final void method4375(GSI var1, IR var2, int var3, int var4, int var5, boolean var6) {
      throw new IllegalStateException();
   }

   public boolean method39(int var1) {
      try {
         return this.P.C(260525653);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "wm.i(" + ')');
      }
   }

   final void method4377() {
      throw new IllegalStateException();
   }

   void method4357(GSI var1, int var2) {
      try {
         UT var3 = this.P.I(var1, 262144, true, true, (byte)-16);
         if (var3 != null) {
            SF var4 = this.I().I;
            int var5 = (int)var4.I >> 9;
            int var6 = (int)var4.Z >> 9;
            this.P.I(var1, var3, this.J(), var5, var5, var6, var6, false, 1937927561);
         }

      } catch (RuntimeException var7) {
         throw DQ.I(var7, "wm.bb(" + ')');
      }
   }

   public int method4379() {
      return this.P.Z(1926384337);
   }

   final boolean method4386() {
      return false;
   }

   boolean method4369() {
      return this.append;
   }

   boolean method4382() {
      return this.append;
   }

   boolean method4349() {
      return this.append;
   }

   boolean method4383() {
      return this.append;
   }

   boolean method4351() {
      return this.append;
   }

   final boolean method4384() {
      return false;
   }

   boolean method4353() {
      return false;
   }

   public void method31(byte var1) {
   }

   KP method4370(GSI var1) {
      UT var2 = this.P.I(var1, 2048, false, true, (byte)-3);
      if (var2 == null) {
         return null;
      } else {
         LF var3 = this.J();
         ZJ var4 = this.I();
         KP var5 = BDI.I(this.gc, 1939994642);
         int var6 = (int)var4.I.I >> 9;
         int var7 = (int)var4.I.Z >> 9;
         this.P.I(var1, var2, var3, var6, var6, var7, var7, true, 1228885360);
         var2.method4739(var3, this.N[0], 0);
         if (this.P.A != null) {
            XBI var8 = this.P.A.D();
            var1.method5042(var8);
         }

         this.append = var2.i() || this.P.A != null;
         if (this.i == null) {
            this.i = TY.I((int)var4.I.I, (int)var4.I.C, (int)var4.I.Z, var2, 1982662132);
         } else {
            QS.I(this.i, (int)var4.I.I, (int)var4.I.C, (int)var4.I.Z, var2, (byte)26);
         }

         return var5;
      }
   }

   public int gc() {
      return this.P.I(2101198661);
   }

   final boolean method4400() {
      return false;
   }

   static final void Z(OU var0, byte var1) {
      try {
         VJ var2 = XW.I((short)512);
         PK var3 = GB.I(MEI.aI, var2.Z, (byte)18);
         var3.J.F(0);
         int var4 = var3.J.A * 385051775;
         var3.J.F(2);
         var3.J.Z(var0.G.I * -2034569943, 16711935);
         var0.G.Z.I(var3.J, var0.G.C, 1820223429);
         var3.J.A(385051775 * var3.J.A - var4, (byte)-61);
         var2.I(var3, (byte)-22);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "wm.adk(" + ')');
      }
   }

   public static void B(byte var0) {
      try {
         HX.I(17, 1188643494);
         BB.Z(-1182326447);
         System.gc();
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "wm.lx(" + ')');
      }
   }

   static final void I(OU var0, short var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         int[] var3 = OSI.Z(var2, 1679514983);
         TW.I((int[])var3, 0, (int[])var0.H, 681479919 * var0.J, 3);
         var0.J += -1175642067;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "wm.akm(" + ')');
      }
   }
}
