public class GY {
   static JQ I = new JQ(32);
   public static int Z;

   GY() throws Throwable {
      throw new Error();
   }

   static String I(String var0, int var1) {
      try {
         if (CZI.Z.startsWith("win")) {
            return var0 + ".dll";
         } else if (CZI.Z.startsWith("linux")) {
            return "lib" + var0 + ".so";
         } else {
            return CZI.Z.startsWith("mac") ? "lib" + var0 + ".dylib" : null;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "t.a(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-48);
         X var4 = IU.F[var2 >> 16];
         VU.I(var3, var4, var0, (byte)106);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "t.ce(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = TQ.R * 235445649;
         var0.H[(var0.J += -391880689) * 681479919 - 1] = 508782749 * TQ.L;
         var0.H[(var0.J += -391880689) * 681479919 - 1] = 1800450029 * TQ.f;
         TQ.R = -1908115170;
         TQ.L = 599892555;
         TQ.f = 930150939;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "t.ahz(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         var0.J -= -783761378;
         int var2 = var0.H[var0.J * 681479919];
         int var3 = var0.H[1 + 681479919 * var0.J];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = (var2 & 1 << var3) != 0 ? 1 : 0;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "t.zh(" + ')');
      }
   }
}
