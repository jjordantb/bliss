public class CJ {
   public static int DISABLE_XTEA_CRASH = 4;
   public static int Z = 1;
   public static int append = 3;
   public static int toString = 0;
   public static int I = 2;
   static HSI C;

   CJ() throws Throwable {
      throw new Error();
   }

   static final byte[] I(byte[] var0, int var1) {
      try {
         REI var2 = new REI(var0);
         int var3 = var2.I();
         int var4 = var2.H((byte)-98);
         if (var4 >= 0 && (-989796335 * KJ.Z == 0 || var4 <= -989796335 * KJ.Z)) {
            if (var3 == 0) {
               byte[] var10 = new byte[var4];
               var2.I((byte[])var10, 0, var4, (int)-953523806);
               return var10;
            } else {
               int var5 = var2.H((byte)-15);
               if (var5 < 0 || -989796335 * KJ.Z != 0 && var5 > KJ.Z * -989796335) {
                  throw new RuntimeException();
               } else {
                  byte[] var6 = new byte[var5];
                  if (1 == var3) {
                     WX.I(var6, var5, var0, var4, 9);
                  } else {
                     ZCI var7 = KJ.I;
                     synchronized(KJ.I) {
                        KJ.I.I(var2, var6, -2006263589);
                     }
                  }

                  return var6;
               }
            }
         } else {
            throw new RuntimeException();
         }
      } catch (Throwable var9) {
         if (Loader.DISABLE_XTEA_CRASH) {
            return new byte[100];
         } else {
            throw DQ.I(var9, "jy.ad(" + ')');
         }
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         var0.J -= -1175642067;
         int var2 = var0.H[681479919 * var0.J];
         int var3 = var0.H[var0.J * 681479919 + 1];
         int var4 = var0.H[var0.J * 681479919 + 2];
         GN.I(8, var2 << 16 | var3, var4, "", 1153707798);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "jy.all(" + ')');
      }
   }

   public static XM I(int var0) {
      try {
         if (GN.N != null && GN.m != null) {
            GN.m.I(GN.N, 1595014600);
            XM var1 = (XM)GN.m.I(1453357547);
            if (var1 == null) {
               return null;
            } else {
               HQ var2 = GN.W.I(-530122905 * var1.E, -113320818);
               return var2 != null && var2.a && var2.I(GN.D, 391184195) ? var1 : ECI.I(-20548648);
            }
         } else {
            return null;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "jy.cn(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         ZE.I(var3, var4, var0, 2047482896);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "jy.fh(" + ')');
      }
   }
}
