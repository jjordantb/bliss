public abstract class LR extends IR {
   int method4354(GE[] var1, int var2) {
      try {
         SF var3 = this.I().I;
         return this.I((int)var3.I >> -1688804109 * this.H.I, (int)var3.Z >> -1688804109 * this.H.I, var1, 2132561832);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ajx.dg(" + ')');
      }
   }

   boolean method4360(int var1) {
      try {
         SF var2 = this.I().I;
         return this.H.d[((int)var2.I >> -1688804109 * this.H.I) - this.H.z * -804213305 + this.H.Q * 583010427][((int)var2.Z >> this.H.I * -1688804109) - this.H.J * 465603579 + this.H.Q * 583010427];
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ajx.dq(" + ')');
      }
   }

   boolean method4364(GSI var1, byte var2) {
      try {
         SF var3 = this.I().I;
         XO var4 = this.H.A(this.K, (int)var3.I >> this.H.I * -1688804109, (int)var3.Z >> -1688804109 * this.H.I, -113950602);
         return var4 != null && var4.Z.T ? this.H.D.Z(this.K, (int)var3.I >> -1688804109 * this.H.I, (int)var3.Z >> this.H.I * -1688804109, var4.Z.method4361(1951240662) + this.method4361(1951240662)) : this.H.D.I(this.K, (int)var3.I >> -1688804109 * this.H.I, (int)var3.Z >> this.H.I * -1688804109);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ajx.dl(" + ')');
      }
   }

   boolean method4391(GSI var1) {
      SF var2 = this.I().I;
      XO var3 = this.H.A(this.K, (int)var2.I >> this.H.I * -1688804109, (int)var2.Z >> -1688804109 * this.H.I, 1285556304);
      return var3 != null && var3.Z.T ? this.H.D.Z(this.K, (int)var2.I >> -1688804109 * this.H.I, (int)var2.Z >> this.H.I * -1688804109, var3.Z.method4361(1951240662) + this.method4361(1951240662)) : this.H.D.I(this.K, (int)var2.I >> -1688804109 * this.H.I, (int)var2.Z >> this.H.I * -1688804109);
   }

   final boolean method4384() {
      return false;
   }

   final void method4355(GSI var1, IR var2, int var3, int var4, int var5, boolean var6, int var7) {
      try {
         throw new IllegalStateException();
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "ajx.bk(" + ')');
      }
   }

   final boolean method4366(int var1) {
      return false;
   }

   final void method4375(GSI var1, IR var2, int var3, int var4, int var5, boolean var6) {
      throw new IllegalStateException();
   }

   final void method4398(byte var1) {
      try {
         throw new IllegalStateException();
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ajx.bq(" + ')');
      }
   }

   final void method4377() {
      throw new IllegalStateException();
   }

   final void method4378() {
      throw new IllegalStateException();
   }

   LR(AP var1, int var2, int var3, int var4, int var5, int var6) {
      super(var1);
      this.K = (byte)var5;
      this.L = (byte)var6;
      this.I(new SF((float)var2, (float)var3, (float)var4));
   }

   final boolean method4400() {
      return false;
   }

   final boolean method4386() {
      return false;
   }

   boolean method4396() {
      SF var1 = this.I().I;
      return this.H.d[((int)var1.I >> -1688804109 * this.H.I) - this.H.z * -804213305 + this.H.Q * 583010427][((int)var1.Z >> this.H.I * -1688804109) - this.H.J * 465603579 + this.H.Q * 583010427];
   }

   int method4390(GE[] var1) {
      SF var2 = this.I().I;
      return this.I((int)var2.I >> -1688804109 * this.H.I, (int)var2.Z >> -1688804109 * this.H.I, var1, 1968893016);
   }

   final boolean method4387() {
      return false;
   }

   boolean method4359(GSI var1) {
      SF var2 = this.I().I;
      XO var3 = this.H.A(this.K, (int)var2.I >> this.H.I * -1688804109, (int)var2.Z >> -1688804109 * this.H.I, -832807192);
      return var3 != null && var3.Z.T ? this.H.D.Z(this.K, (int)var2.I >> -1688804109 * this.H.I, (int)var2.Z >> this.H.I * -1688804109, var3.Z.method4361(1951240662) + this.method4361(1951240662)) : this.H.D.I(this.K, (int)var2.I >> -1688804109 * this.H.I, (int)var2.Z >> this.H.I * -1688804109);
   }

   boolean method4393(GSI var1) {
      SF var2 = this.I().I;
      XO var3 = this.H.A(this.K, (int)var2.I >> this.H.I * -1688804109, (int)var2.Z >> -1688804109 * this.H.I, -1759814831);
      return var3 != null && var3.Z.T ? this.H.D.Z(this.K, (int)var2.I >> -1688804109 * this.H.I, (int)var2.Z >> this.H.I * -1688804109, var3.Z.method4361(1951240662) + this.method4361(1951240662)) : this.H.D.I(this.K, (int)var2.I >> -1688804109 * this.H.I, (int)var2.Z >> this.H.I * -1688804109);
   }

   boolean method4389(GSI var1) {
      SF var2 = this.I().I;
      XO var3 = this.H.A(this.K, (int)var2.I >> this.H.I * -1688804109, (int)var2.Z >> -1688804109 * this.H.I, 1171846903);
      return var3 != null && var3.Z.T ? this.H.D.Z(this.K, (int)var2.I >> -1688804109 * this.H.I, (int)var2.Z >> this.H.I * -1688804109, var3.Z.method4361(1951240662) + this.method4361(1951240662)) : this.H.D.I(this.K, (int)var2.I >> -1688804109 * this.H.I, (int)var2.Z >> this.H.I * -1688804109);
   }

   boolean method4395() {
      SF var1 = this.I().I;
      return this.H.d[((int)var1.I >> -1688804109 * this.H.I) - this.H.z * -804213305 + this.H.Q * 583010427][((int)var1.Z >> this.H.I * -1688804109) - this.H.J * 465603579 + this.H.Q * 583010427];
   }

   final void method4388(GSI var1, IR var2, int var3, int var4, int var5, boolean var6) {
      throw new IllegalStateException();
   }

   boolean method4397() {
      SF var1 = this.I().I;
      return this.H.d[((int)var1.I >> -1688804109 * this.H.I) - this.H.z * -804213305 + this.H.Q * 583010427][((int)var1.Z >> this.H.I * -1688804109) - this.H.J * 465603579 + this.H.Q * 583010427];
   }
}
