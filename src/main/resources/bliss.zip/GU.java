public class GU {
   int I;
   int KA = -48388469;
   int W;
   public int Z = -761293581;
   short[] X;
   short[] append;
   short[] f;
   short[] m;
   IU C;
   int method4755 = -2062770560;
   int method5004 = 0;
   int method5017 = 0;
   int method5037 = 0;
   public boolean B = false;
   public byte D = 0;
   int oa = -1498254464;

   void I(REI var1, byte var2) {
      try {
         while(true) {
            int var3 = var1.I();
            if (var3 == 0) {
               if (var2 == -1) {
                  throw new IllegalStateException();
               }

               return;
            }

            this.KA(var1, var3, 84112235);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "qm.a(" + ')');
      }
   }

   void KA(REI var1, int var2, int var3) {
      try {
         if (1 == var2) {
            this.W = var1.Y(1235052657) * 422607467;
         } else if (var2 == 2) {
            this.Z = var1.Y(1235052657) * 761293581;
         } else if (4 == var2) {
            this.oa = var1.C() * -1420991257;
         } else if (var2 == 5) {
            this.method4755 = var1.C() * -586540739;
         } else if (var2 == 6) {
            this.method5004 = var1.C() * -79411937;
         } else if (7 == var2) {
            this.method5017 = var1.I() * 1905965041;
         } else if (8 == var2) {
            this.method5037 = var1.I() * -241990007;
         } else if (9 == var2) {
            this.D = 3;
            this.KA = -1485189472;
         } else if (10 == var2) {
            this.B = true;
         } else if (var2 == 11) {
            this.D = 1;
         } else if (12 == var2) {
            this.D = 4;
         } else if (var2 == 13) {
            this.D = 5;
         } else if (14 == var2) {
            this.D = 2;
            this.KA = var1.I() * -497453824;
         } else if (var2 == 15) {
            this.D = 3;
            this.KA = var1.C() * 48388469;
         } else if (16 == var2) {
            this.D = 3;
            this.KA = var1.H((byte)52) * 48388469;
         } else {
            int var4;
            int var5;
            if (40 == var2) {
               var4 = var1.I();
               this.X = new short[var4];
               this.append = new short[var4];

               for(var5 = 0; var5 < var4; ++var5) {
                  this.X[var5] = (short)var1.C();
                  this.append[var5] = (short)var1.C();
               }
            } else if (41 == var2) {
               var4 = var1.I();
               this.f = new short[var4];
               this.m = new short[var4];

               for(var5 = 0; var5 < var4; ++var5) {
                  this.f[var5] = (short)var1.C();
                  this.m[var5] = (short)var1.C();
               }
            }
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "qm.f(" + ')');
      }
   }

   public final UT I(GSI var1, int var2, SX var3, byte var4, int var5) {
      try {
         return this.I(var1, var2, false, (YJI)null, (YJI)null, 0, 0, 0, var3, var4, 1256553464);
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "qm.b(" + ')');
      }
   }

   public final UT I(GSI var1, int var2, boolean var3, YJI var4, YJI var5, int var6, int var7, int var8, SX var9, byte var10, int var11) {
      try {
         int var12 = var2;
         var3 &= this.D != 0;
         if (var9 != null) {
            var12 = var2 | var9.B(-1790708337);
         }

         if (var3) {
            var12 |= this.D == 3 ? 7 : 2;
         }

         if (this.method4755 * -64059883 != 128) {
            var12 |= 2;
         }

         if (128 != this.oa * -1869386025 || this.method5004 * -614140193 != 0) {
            var12 |= 5;
         }

         JQ var14 = this.C.C;
         UT var13;
         synchronized(this.C.C) {
            var13 = (UT)this.C.C.I((long)((this.I = 1757755963 * (-559444237 * this.I | var1.KZ * 580915349 << 29)) * -559444237));
         }

         if (var13 == null || var1.method5017(var13.m(), var12) != 0) {
            if (var13 != null) {
               var12 = var1.method5004(var12, var13.m());
            }

            int var20 = var12;
            if (this.X != null) {
               var20 = var12 | 16384;
            }

            if (this.f != null) {
               var20 |= 32768;
            }

            MBI var15 = MBI.I((KJ)this.C.I, this.W * -283549117, (int)0);
            if (var15 == null) {
               return null;
            }

            if (var15.P < 13) {
               var15.I(2);
            }

            var13 = var1.method5037(var15, var20, -258957271 * this.C.B, 64 + -2043193071 * this.method5017, 850 + 1459867577 * this.method5037);
            int var16;
            if (this.X != null) {
               for(var16 = 0; var16 < this.X.length; ++var16) {
                  var13.X(this.X[var16], this.append[var16]);
               }
            }

            if (this.f != null) {
               for(var16 = 0; var16 < this.f.length; ++var16) {
                  var13.W(this.f[var16], this.m[var16]);
               }
            }

            var13.KA(var12);
            JQ var22 = this.C.C;
            synchronized(this.C.C) {
               this.C.C.I(var13, (long)((this.I = (this.I * -559444237 | 580915349 * var1.KZ << 29) * 1757755963) * -559444237));
            }
         }

         UT var21 = var13.method4755(var10, var12, true);
         if (var9 != null) {
            var9.I((UT)var21, 0, (int)-400006457);
         }

         if (-1869386025 * this.oa != 128 || this.method4755 * -64059883 != 128) {
            var21.oa(-1869386025 * this.oa, this.method4755 * -64059883, -1869386025 * this.oa);
         }

         if (-614140193 * this.method5004 != 0) {
            if (this.method5004 * -614140193 == 90) {
               var21.f(4096);
            }

            if (-614140193 * this.method5004 == 180) {
               var21.f(8192);
            }

            if (270 == -614140193 * this.method5004) {
               var21.f(12288);
            }
         }

         if (var3) {
            var21.pa(this.D, 167177949 * this.KA, var4, var5, var6, var7, var8);
         }

         var21.KA(var2);
         return var21;
      } catch (RuntimeException var19) {
         throw DQ.I(var19, "qm.p(" + ')');
      }
   }

   public final boolean I(byte var1) {
      try {
         return this.W * -283549117 == -1 ? true : this.C.I.I(-283549117 * this.W, 0, (int)-676484272);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "qm.i(" + ')');
      }
   }

   static boolean I(int var0, short var1) {
      try {
         if (var0 != 18 && 19 != var0 && 20 != var0 && var0 != 21 && 22 != var0 && 1004 != var0) {
            return 17 == var0;
         } else {
            return true;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "qm.bo(" + ')');
      }
   }

   public static boolean I(char var0, int var1) {
      try {
         if ((var0 <= 0 || var0 >= '\u0080') && (var0 < ' ' || var0 > 'ÿ')) {
            if (var0 != 0) {
               char[] var2 = EV.I;

               for(int var3 = 0; var3 < var2.length; ++var3) {
                  char var4 = var2[var3];
                  if (var4 == var0) {
                     return true;
                  }
               }
            }

            return false;
         } else {
            return true;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "qm.f(" + ')');
      }
   }

   public static final void I(String var0, int var1) {
      try {
         if (EFI.F != null) {
            VJ var2 = XW.I((short)512);
            PK var3 = GB.I(MEI.VI, var2.Z, (byte)6);
            var3.J.F(SBI.I(var0, 1482909411));
            var3.J.I(var0, 2132300359);
            var2.I(var3, (byte)-58);
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "qm.mr(" + ')');
      }
   }

   static final void I(int var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      try {
         if (var2 >= 1 && var3 >= 1 && var2 <= XEI.mI.Z(-1936425983) - 2 && var3 <= XEI.mI.C(-1245034974) - 2) {
            int var9 = var0;
            if (var0 < 3 && XEI.mI.M(511320643).I(var2, var3, 549965572)) {
               var9 = var0 + 1;
            }

            if (XEI.mI.T(-1611682495) != null) {
               XEI.mI.H(-1368274969).I(FT.P, var0, var1, var2, var3, XEI.mI.A(var0), 366084983);
               if (var4 >= 0) {
                  int var10 = FW.J.S.Z(-810781268);
                  FW.J.I(FW.J.S, 1, 650835797);
                  XEI.mI.H(-630573167).I(FT.P, var9, var0, var2, var3, var4, var5, var6, XEI.mI.A(var0), var7, 2073430416);
                  FW.J.I(FW.J.S, var10, 631929348);
               }
            }
         }

      } catch (RuntimeException var11) {
         throw DQ.I(var11, "qm.d(" + ')');
      }
   }

   public static int I(CharSequence var0, int var1, byte var2) {
      try {
         return LV.I(var0, var1, true, -566000595);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "qm.k(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         FW.J.I(FW.J.j, var0.H[(var0.J -= -391880689) * 681479919] != 0 ? 1 : 0, -856880407);
         JN.I(656179282);
         XEI.mI.P(1778418334);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "qm.aip(" + ')');
      }
   }
}
