public abstract class GJ {
   public static AEI I;
   public static int Z;
   public static int C;

   abstract void method2249(int var1);

   abstract PF method2250(int var1);

   abstract byte[] method2251(int var1, byte var2);

   abstract byte[] method2252(int var1);

   abstract int method2253(int var1, int var2);

   abstract PF method2254();

   abstract PF method2255();

   abstract void method2256(int var1, short var2);

   abstract int method2257(int var1);

   abstract byte[] method2258(int var1);

   abstract byte[] method2259(int var1);

   abstract void method2260(int var1);

   abstract int method2261(int var1);

   abstract byte[] method2262(int var1);

   abstract void method2263(int var1);

   abstract PF method2264();

   abstract void method2265(int var1);

   static final void I(OU var0, int var1) {
      try {
         var0.J -= -783761378;
         int var2 = var0.H[var0.J * 681479919];
         int var3 = var0.H[1 + var0.J * 681479919];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var3 * var2;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "kd.yr(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-71);
         X var4 = IU.F[var2 >> 16];
         F.I(var3, var4, var0, 1901866056);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "kd.dn(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         var0.J -= -15720283;
         HZ[] var2 = XII.Z((byte)58);
         IZ[] var3 = Q.Z(1297575712);
         DJ.I(var2[var0.H[681479919 * var0.J]], var3[var0.H[1 + 681479919 * var0.J]], var0.H[2 + var0.J * 681479919], var0.H[3 + 681479919 * var0.J], var0.H[4 + 681479919 * var0.J], var0.H[var0.J * 681479919 + 5], var0.H[var0.J * 681479919 + 6], var0.H[7 + 681479919 * var0.J], var0.H[var0.J * 681479919 + 8], var0.H[9 + 681479919 * var0.J], var0.H[10 + 681479919 * var0.J], -1940539575);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "kd.se(" + ')');
      }
   }

   static void I(int var0, int var1, int var2) {
      try {
         VK var3 = IV.I(13, (long)var0);
         var3.I((byte)67);
         var3.L = var1 * 1274450087;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "kd.aq(" + ')');
      }
   }
}
