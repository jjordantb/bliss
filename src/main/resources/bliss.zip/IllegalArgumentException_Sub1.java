public class IllegalArgumentException_Sub1 extends IllegalArgumentException {
   public IllegalArgumentException_Sub1(VG var1, String var2) {
      super("");
   }
}
