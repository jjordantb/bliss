import jaggl.OpenGL;

public class GV {
   HCI L;
   boolean b = true;
   boolean ba = true;
   HCI glBegin;
   int glEnd = 0;
   int glMultiTexCoord2f = 0;
   FO[] glTexCoord2f = new FO[2];
   int glVertex2i = 1;
   boolean method2868;
   FY method2869 = new FY();
   FO method2870;
   boolean method2871 = true;
   MJI method2872;
   boolean method2873 = true;
   int method552 = 1;
   BL method558;
   boolean method560 = false;
   BL method563;
   HCI I;
   int Z = 0;
   SDI C;

   boolean I(int var1, int var2, int var3, int var4) {
      if (this.glBegin != null && !this.method2869.C((byte)63)) {
         if (this.method552 != var3 || this.glVertex2i != var4) {
            this.method552 = var3;
            this.glVertex2i = var4;

            for(AE var5 = this.method2869.Z(1528300499); var5 != this.method2869.I; var5 = var5.I) {
               ((CN)var5).method2871(this.method552, this.glVertex2i);
            }

            this.b = true;
            this.method2871 = true;
            this.ba = true;
         }

         if (this.b()) {
            this.glEnd = var1;
            this.glMultiTexCoord2f = var2;
            this.method2868 = true;
            this.method2872.B(-this.glEnd, this.glVertex2i + this.glMultiTexCoord2f - this.method2872.I((short)16970).method552());
            this.method2872.Z(this.glBegin, (byte)-31);
            this.method2872.ba(3, 0);
            this.glBegin.C(0);
            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   boolean I() {
      return this.glBegin != null;
   }

   void Z() {
      if (this.method2868) {
         if (this.I != null) {
            this.method2872.I(this.I, (byte)-72);
            this.method2872.Z(this.L, (byte)-36);
            this.L.C(0);
            this.I.I(0, 0, this.method552, this.glVertex2i, 0, 0, true, this.method560);
         }

         this.method2872.B();
         this.method2872.B(0);
         this.method2872.I(1);
         this.method2872.L();
         int var1 = 0;
         int var2 = 1;

         CN var3;
         for(CN var4 = (CN)this.method2869.Z(1607067175); var4 != null; var4 = var3) {
            var3 = (CN)this.method2869.Z((byte)-76);
            int var5 = var4.I();

            for(int var6 = 0; var6 < var5; ++var6) {
               var4.method2872(var6, this.glTexCoord2f[var1], this.method2870);
               if (var3 == null && var6 == var5 - 1) {
                  this.method2872.I(this.L, (byte)40);
                  this.method2872.B(0, 0);
                  OpenGL.glBegin(7);
                  OpenGL.glTexCoord2f(0.0F, (float)this.glVertex2i);
                  OpenGL.glMultiTexCoord2f(33985, 0.0F, 1.0F);
                  OpenGL.glVertex2i(this.glEnd, this.glMultiTexCoord2f);
                  OpenGL.glTexCoord2f(0.0F, 0.0F);
                  OpenGL.glMultiTexCoord2f(33985, 0.0F, 0.0F);
                  OpenGL.glVertex2i(this.glEnd, this.glMultiTexCoord2f + this.glVertex2i);
                  OpenGL.glTexCoord2f((float)this.method552, 0.0F);
                  OpenGL.glMultiTexCoord2f(33985, 1.0F, 0.0F);
                  OpenGL.glVertex2i(this.glEnd + this.method552, this.glMultiTexCoord2f + this.glVertex2i);
                  OpenGL.glTexCoord2f((float)this.method552, (float)this.glVertex2i);
                  OpenGL.glMultiTexCoord2f(33985, 1.0F, 1.0F);
                  OpenGL.glVertex2i(this.glEnd + this.method552, this.glMultiTexCoord2f);
                  OpenGL.glEnd();
               } else {
                  this.L.C(var2);
                  OpenGL.glBegin(7);
                  OpenGL.glTexCoord2f(0.0F, (float)this.glVertex2i);
                  OpenGL.glMultiTexCoord2f(33985, 0.0F, 1.0F);
                  OpenGL.glVertex2i(0, 0);
                  OpenGL.glTexCoord2f(0.0F, 0.0F);
                  OpenGL.glMultiTexCoord2f(33985, 0.0F, 0.0F);
                  OpenGL.glVertex2i(0, this.glVertex2i);
                  OpenGL.glTexCoord2f((float)this.method552, 0.0F);
                  OpenGL.glMultiTexCoord2f(33985, 1.0F, 0.0F);
                  OpenGL.glVertex2i(this.method552, this.glVertex2i);
                  OpenGL.glTexCoord2f((float)this.method552, (float)this.glVertex2i);
                  OpenGL.glMultiTexCoord2f(33985, 1.0F, 1.0F);
                  OpenGL.glVertex2i(this.method552, 0);
                  OpenGL.glEnd();
               }

               var4.method2873(var6);
               var2 = var2 + 1 & 1;
               var1 = var1 + 1 & 1;
            }
         }

         this.method2868 = false;
      }

   }

   GV(MJI var1) {
      this.C = SDI.C;
      this.method2872 = var1;
      if (this.method2872.CI && this.method2872.AI) {
         this.glBegin = this.L = new HCI(this.method2872);
         if (this.method2872.J > 1 && this.method2872.BI && this.method2872.p) {
            this.glBegin = this.I = new HCI(this.method2872);
         }
      }

   }

   boolean I(CN var1) {
      if (this.glBegin != null) {
         if (var1.method2868() || var1.method2869()) {
            this.method2869.Z((AE)var1, (int)1179569939);
            this.L();
            if (this.b()) {
               if (this.method552 != -1 && this.glVertex2i != -1) {
                  var1.method2871(this.method552, this.glVertex2i);
               }

               var1.J = true;
               return true;
            }
         }

         this.Z(var1);
      }

      return false;
   }

   void Z(CN var1) {
      var1.J = false;
      var1.method2870();
      var1.I(-1460969981);
      this.L();
   }

   void C() {
      this.L = null;
      this.I = null;
      this.glBegin = null;
      this.method563 = null;
      this.method2870 = null;
      this.glTexCoord2f = null;
      this.method558 = null;
      if (!this.method2869.C((byte)106)) {
         for(AE var1 = this.method2869.Z(1803490493); var1 != this.method2869.I; var1 = var1.I) {
            ((CN)var1).method2870();
         }
      }

      this.glVertex2i = 1;
      this.method552 = 1;
   }

   void L() {
      int var1 = 0;
      boolean var2 = false;
      SDI var3 = SDI.C;

      for(CN var4 = (CN)this.method2869.Z(1419681613); var4 != null; var4 = (CN)this.method2869.Z((byte)-84)) {
         SDI var5 = var4.Z();
         if (var5.S * 685647847 > var3.S * 685647847) {
            var3 = var5;
         }

         var2 |= var4.C();
         var1 += var4.I();
      }

      if (var3 != this.C) {
         this.C = var3;
         this.b = true;
      }

      int var6 = this.Z > 2 ? 2 : this.Z;
      int var7 = var1 > 2 ? 2 : var1;
      if (var6 != var7) {
         this.b = true;
         this.ba = true;
      }

      if (var2 != this.method560) {
         this.method560 = var2;
         this.method2871 = true;
      }

      this.Z = var1;
   }

   boolean b() {
      if (this.method2871) {
         if (this.method563 != null) {
            this.method563.b();
            this.method563 = null;
         }

         if (this.method2870 != null) {
            this.method2870.I();
            this.method2870 = null;
         }
      }

      if (this.b) {
         if (this.method558 != null) {
            this.method558.b();
            this.method558 = null;
         }

         if (this.glTexCoord2f[0] != null) {
            this.glTexCoord2f[0].I();
            this.glTexCoord2f[0] = null;
         }

         if (this.glTexCoord2f[1] != null) {
            this.glTexCoord2f[1].I();
            this.glTexCoord2f[1] = null;
         }
      }

      if (this.method2871) {
         if (this.I != null) {
            this.method563 = new BL(this.method2872, YCI.F, SDI.D, this.method552, this.glVertex2i, this.method2872.J);
         }

         if (this.method560) {
            this.method2870 = new FO(this.method2872, 34037, YCI.F, SDI.D, this.method552, this.glVertex2i);
         } else if (this.method563 == null) {
            this.method563 = new BL(this.method2872, YCI.F, SDI.D, this.method552, this.glVertex2i);
         }

         this.method2871 = false;
         this.ba = true;
         this.method2873 = true;
      }

      if (this.b) {
         if (this.I != null) {
            this.method558 = new BL(this.method2872, YCI.Z, this.C, this.method552, this.glVertex2i, this.method2872.J);
         }

         this.glTexCoord2f[0] = new FO(this.method2872, 34037, YCI.Z, this.C, this.method552, this.glVertex2i);
         this.glTexCoord2f[1] = this.Z > 1 ? new FO(this.method2872, 34037, YCI.Z, this.C, this.method552, this.glVertex2i) : null;
         this.b = false;
         this.ba = true;
         this.method2873 = true;
      }

      if (this.ba) {
         if (this.I != null) {
            this.method2872.Z(this.L, (byte)-20);
            this.L.method558((XAI)null);
            this.L.method563(0, (TAI)null);
            this.L.method563(1, (TAI)null);
            this.L.method563(0, this.glTexCoord2f[0].I(0));
            this.L.method563(1, this.Z > 1 ? this.glTexCoord2f[1].I(0) : null);
            if (this.method560) {
               this.L.method558(this.method2870.Z(0));
            }

            this.method2872.I(this.L, (byte)-22);
            this.method2872.Z(this.I, (byte)12);
            this.I.method558((XAI)null);
            this.I.method563(0, (TAI)null);
            this.I.method563(0, this.method558);
            this.I.method558(this.method563);
            this.method2872.I(this.I, (byte)18);
         } else {
            this.method2872.Z(this.L, (byte)-69);
            this.L.method558((XAI)null);
            this.L.method563(0, (TAI)null);
            this.L.method563(1, (TAI)null);
            this.L.method563(0, this.glTexCoord2f[0].I(0));
            this.L.method563(1, this.Z > 1 ? this.glTexCoord2f[1].I(0) : null);
            if (this.method560) {
               this.L.method558(this.method2870.Z(0));
            } else {
               this.L.method558(this.method563);
            }

            this.method2872.I(this.L, (byte)1);
         }

         this.ba = false;
         this.method2873 = true;
      }

      if (this.method2873) {
         this.method2872.Z(this.glBegin, (byte)-31);
         this.method2873 = !this.glBegin.method560();
         this.method2872.I(this.glBegin, (byte)15);
      }

      return !this.method2873;
   }
}
