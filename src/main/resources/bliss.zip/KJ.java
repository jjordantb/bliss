public final class KJ {
   static int append = 0;
   public static int arraycopy = 1;
   PF length = null;
   static ZCI I = new ZCI();
   boolean method2250;
   static int method2251 = 0;
   Object[] method2253;
   Object[][] method2256;
   int substring;
   GJ toLowerCase;
   static boolean toString = false;
   static int Z = 0;
   public static int C = 2;
   static int B = 1;

   synchronized boolean append(int var1) {
      try {
         if (this.length == null) {
            this.length = this.toLowerCase.method2250(2102263091);
            if (this.length == null) {
               return false;
            }

            this.method2253 = new Object[-1583970959 * this.length.S];
            this.method2256 = new Object[-1583970959 * this.length.S][];
         }

         return true;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ke.a(" + ')');
      }
   }

   public int I(byte var1) {
      try {
         if (!this.append(14382781)) {
            throw new IllegalStateException("");
         } else {
            return this.length.I * 1600327191;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ke.f(" + ')');
      }
   }

   synchronized boolean arraycopy(int var1, int var2, byte var3) {
      try {
         if (!this.append(24313456)) {
            return false;
         } else if (var1 >= 0 && var2 >= 0 && var1 < this.length.B.length && var2 < this.length.B[var1]) {
            return true;
         } else if (toString) {
            throw new IllegalArgumentException(var1 + " " + var2);
         } else {
            return false;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ke.p(" + ')');
      }
   }

   synchronized void length(int var1, byte var2) {
      try {
         if (this.method2250) {
            this.method2253[var1] = this.toLowerCase.method2251(var1, (byte)-83);
         } else {
            this.method2253[var1] = EC.I(this.toLowerCase.method2251(var1, (byte)-115), false, (short)-5444);
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ke.i(" + ')');
      }
   }

   void method2250(int var1, byte var2) {
      try {
         this.toLowerCase.method2256(var1, (short)-11867);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ke.k(" + ')');
      }
   }

   public synchronized byte[] I(int var1, int var2, int[] var3, int var4) {
      try {
         if (!this.arraycopy(var1, var2, (byte)106)) {
            return null;
         } else {
            byte[] var5 = null;
            if (this.method2256[var1] == null || this.method2256[var1][var2] == null) {
               boolean var6 = this.method2256(var1, var2, var3, (byte)1);
               if (!var6) {
                  this.length(var1, (byte)23);
                  var6 = this.method2256(var1, var2, var3, (byte)1);
                  if (!var6) {
                     return null;
                  }
               }
            }

            if (this.method2256[var1] == null) {
               throw new RuntimeException("");
            } else {
               if (this.method2256[var1][var2] != null) {
                  var5 = TP.I(this.method2256[var1][var2], false, -390800011);
                  if (var5 == null) {
                     throw new RuntimeException("");
                  }
               }

               if (var5 != null) {
                  if (this.substring * -1870742467 == 1) {
                     this.method2256[var1][var2] = null;
                     if (1 == this.length.B[var1]) {
                        this.method2256[var1] = null;
                     }
                  } else if (this.substring * -1870742467 == 2) {
                     this.method2256[var1] = null;
                  }
               }

               return var5;
            }
         }
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "ke.u(" + ')');
      }
   }

   public synchronized boolean I(int var1, int var2, int var3) {
      try {
         if (!this.arraycopy(var1, var2, (byte)52)) {
            return false;
         } else if (this.method2256[var1] != null && this.method2256[var1][var2] != null) {
            return true;
         } else if (this.method2253[var1] != null) {
            return true;
         } else {
            this.length(var1, (byte)102);
            return this.method2253[var1] != null;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ke.x(" + ')');
      }
   }

   public synchronized boolean I(int var1, int var2) {
      try {
         if (!this.toLowerCase(var1, (byte)1)) {
            return false;
         } else if (this.method2253[var1] != null) {
            return true;
         } else {
            this.length(var1, (byte)60);
            return this.method2253[var1] != null;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ke.q(" + ')');
      }
   }

   public synchronized boolean I(int var1) {
      try {
         if (!this.append(1564303970)) {
            return false;
         } else {
            boolean var2 = true;

            for(int var3 = 0; var3 < this.length.D.length; ++var3) {
               int var4 = this.length.D[var3];
               if (this.method2253[var4] == null) {
                  this.length(var4, (byte)10);
                  if (this.method2253[var4] == null) {
                     var2 = false;
                  }
               }
            }

            return var2;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ke.n(" + ')');
      }
   }

   public synchronized int Z(byte var1) {
      try {
         if (!this.append(-561688978)) {
            return 0;
         } else {
            int var2 = 0;
            int var3 = 0;

            int var4;
            for(var4 = 0; var4 < this.method2253.length; ++var4) {
               if (this.length.G[var4] > 0) {
                  var2 += 100;
                  var3 += this.method2253(var4, (byte)1);
               }
            }

            if (var2 == 0) {
               return 100;
            } else {
               var4 = var3 * 100 / var2;
               return var4;
            }
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ke.z(" + ')');
      }
   }

   public synchronized byte[] I(int var1, byte var2) {
      try {
         if (!this.append(-1120870395)) {
            return null;
         } else if (this.length.B.length == 1) {
            return this.I(0, var1, (byte)-42);
         } else if (!this.toLowerCase(var1, (byte)1)) {
            return null;
         } else if (this.length.B[var1] == 1) {
            return this.I(var1, 0, (byte)-48);
         } else {
            throw new RuntimeException();
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ke.y(" + ')');
      }
   }

   public boolean I(String var1, int var2) {
      try {
         if (!this.append(2084387932)) {
            return false;
         } else {
            var1 = var1.toLowerCase();
            int var3 = this.length.J.I(LJ.I((CharSequence)var1, (int)-1973803814), 867865737);
            return var3 >= 0;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ke.j(" + ')');
      }
   }

   public int Z(int var1) {
      try {
         return !this.append(-1854256654) ? -1 : this.length.B.length;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ke.v(" + ')');
      }
   }

   public synchronized void Z(int var1, int var2) {
      try {
         if (this.toLowerCase(var1, (byte)1) && this.method2256 != null) {
            this.method2256[var1] = null;
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ke.g(" + ')');
      }
   }

   public void I(boolean var1, boolean var2, int var3) {
      try {
         if (this.append(843198070)) {
            if (var1) {
               this.length.F = null;
               this.length.J = null;
            }

            if (var2) {
               this.length.E = null;
               this.length.L = null;
            }
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ke.e(" + ')');
      }
   }

   public KJ(GJ var1, boolean var2, int var3) {
      if (var3 >= 0 && var3 <= 2) {
         this.toLowerCase = var1;
         this.method2250 = var2;
         this.substring = -98387179 * var3;
      } else {
         throw new IllegalArgumentException("");
      }
   }

   public int C(int var1, int var2) {
      try {
         if (!this.append(-1669476342)) {
            return -1;
         } else {
            int var3 = this.length.J.I(var1, 1079998267);
            return !this.toLowerCase(var3, (byte)1) ? -1 : var3;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ke.w(" + ')');
      }
   }

   public boolean I(String var1, String var2, byte var3) {
      try {
         if (!this.append(-574952224)) {
            return false;
         } else {
            var1 = var1.toLowerCase();
            var2 = var2.toLowerCase();
            int var4 = this.length.J.I(LJ.I((CharSequence)var1, (int)-1984349791), 728033014);
            if (var4 < 0) {
               return false;
            } else {
               int var5 = this.length.L[var4].I(LJ.I((CharSequence)var2, (int)-2081152646), 2090644563);
               return var5 >= 0;
            }
         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ke.o(" + ')');
      }
   }

   public synchronized byte[] I(String var1, String var2, int var3) {
      try {
         if (!this.append(-1323260380)) {
            return null;
         } else {
            var1 = var1.toLowerCase();
            var2 = var2.toLowerCase();
            int var4 = this.length.J.I(LJ.I((CharSequence)var1, (int)-1961901970), 1404802795);
            if (!this.toLowerCase(var4, (byte)1)) {
               return null;
            } else {
               int var5 = this.length.L[var4].I(LJ.I((CharSequence)var2, (int)-2059879258), 838109915);
               return this.I(var4, var5, (byte)-34);
            }
         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ke.l(" + ')');
      }
   }

   boolean method2251(String var1, String var2, int var3) {
      try {
         if (!this.append(391595632)) {
            return false;
         } else {
            var1 = var1.toLowerCase();
            var2 = var2.toLowerCase();
            int var4 = this.length.J.I(LJ.I((CharSequence)var1, (int)-2027002851), 906979105);
            if (!this.toLowerCase(var4, (byte)1)) {
               return false;
            } else {
               int var5 = this.length.L[var4].I(LJ.I((CharSequence)var2, (int)-2028561031), 2121455333);
               return this.I(var4, var5, -1219568896);
            }
         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ke.ax(" + ')');
      }
   }

   synchronized int method2253(int var1, byte var2) {
      try {
         if (!this.toLowerCase(var1, (byte)1)) {
            return 0;
         } else {
            return this.method2253[var1] != null ? 100 : this.toLowerCase.method2253(var1, 65535);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ke.s(" + ')');
      }
   }

   public void Z(String var1, int var2) {
      try {
         if (this.append(1339347995)) {
            var1 = var1.toLowerCase();
            int var3 = this.length.J.I(LJ.I((CharSequence)var1, (int)-2097971535), 1493933726);
            this.method2250(var3, (byte)98);
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ke.ae(" + ')');
      }
   }

   public int C(String var1, int var2) {
      try {
         if (!this.append(2032881212)) {
            return 0;
         } else {
            var1 = var1.toLowerCase();
            int var3 = this.length.J.I(LJ.I((CharSequence)var1, (int)-2069451291), 96817353);
            return this.method2253(var3, (byte)1);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ke.ao(" + ')');
      }
   }

   synchronized boolean method2256(int var1, int var2, int[] var3, byte var4) {
      try {
         if (!this.toLowerCase(var1, (byte)1)) {
            return false;
         } else if (this.method2253[var1] == null) {
            return false;
         } else {
            int var5 = this.length.G[var1];
            int[] var6 = this.length.H[var1];
            if (this.method2256[var1] == null) {
               this.method2256[var1] = new Object[this.length.B[var1]];
            }

            Object[] var7 = this.method2256[var1];
            boolean var8 = true;

            for(int var9 = 0; var9 < var5; ++var9) {
               int var10;
               if (var6 == null) {
                  var10 = var9;
               } else {
                  var10 = var6[var9];
               }

               if (var7[var10] == null) {
                  var8 = false;
                  break;
               }
            }

            if (var8) {
               return true;
            } else {
               byte[] var24;
               if (var3 == null || var3[0] == 0 && var3[1] == 0 && var3[2] == 0 && var3[3] == 0) {
                  var24 = TP.I(this.method2253[var1], false, -144584373);
               } else {
                  var24 = TP.I(this.method2253[var1], true, -858479492);
                  REI var25 = new REI(var24);
                  var25.Z(var3, 5, var25.S.length, -1429633724);
               }

               byte[] var26;
               try {
                  var26 = CJ.I(var24, 1072675128);
               } catch (RuntimeException var22) {
                  throw DQ.I(var22, (var3 != null) + " " + var1 + " " + var24.length + " " + BA.I(var24, var24.length, -1914018334) + " " + BA.I(var24, var24.length - 2, -1788280058) + " " + this.length.A[var1] + " " + 1600327191 * this.length.I);
               }

               if (this.method2250) {
                  this.method2253[var1] = null;
               }

               int var11;
               if (var5 > 1) {
                  int var12;
                  REI var13;
                  int var15;
                  int var16;
                  int var17;
                  int var18;
                  int var19;
                  if (2 != this.substring * -1870742467) {
                     var11 = var26.length;
                     --var11;
                     var12 = var26[var11] & 255;
                     var11 -= 4 * var12 * var5;
                     var13 = new REI(var26);
                     int[] var14 = new int[var5];
                     var13.A = var11 * 116413311;

                     for(var15 = 0; var15 < var12; ++var15) {
                        var16 = 0;

                        for(var17 = 0; var17 < var5; ++var17) {
                           var16 += var13.H((byte)13);
                           var14[var17] += var16;
                        }
                     }

                     byte[][] var28 = new byte[var5][];

                     for(var16 = 0; var16 < var5; ++var16) {
                        var28[var16] = new byte[var14[var16]];
                        var14[var16] = 0;
                     }

                     var13.A = var11 * 116413311;
                     var16 = 0;

                     for(var17 = 0; var17 < var12; ++var17) {
                        var18 = 0;

                        for(var19 = 0; var19 < var5; ++var19) {
                           var18 += var13.H((byte)-32);
                           System.arraycopy(var26, var16, var28[var19], var14[var19], var18);
                           var14[var19] += var18;
                           var16 += var18;
                        }
                     }

                     for(var17 = 0; var17 < var5; ++var17) {
                        if (var6 == null) {
                           var18 = var17;
                        } else {
                           var18 = var6[var17];
                        }

                        if (-1870742467 * this.substring == 0) {
                           var7[var18] = EC.I(var28[var17], false, (short)-26522);
                        } else {
                           var7[var18] = var28[var17];
                        }
                     }
                  } else {
                     var11 = var26.length;
                     --var11;
                     var12 = var26[var11] & 255;
                     var11 -= var5 * var12 * 4;
                     var13 = new REI(var26);
                     int var27 = 0;
                     var15 = 0;
                     var13.A = 116413311 * var11;

                     for(var16 = 0; var16 < var12; ++var16) {
                        var17 = 0;

                        for(var18 = 0; var18 < var5; ++var18) {
                           var17 += var13.H((byte)-36);
                           if (var6 == null) {
                              var19 = var18;
                           } else {
                              var19 = var6[var18];
                           }

                           if (var19 == var2) {
                              var27 += var17;
                              var15 = var19;
                           }
                        }
                     }

                     if (var27 == 0) {
                        return true;
                     }

                     byte[] var29 = new byte[var27];
                     var27 = 0;
                     var13.A = var11 * 116413311;
                     var17 = 0;

                     for(var18 = 0; var18 < var12; ++var18) {
                        var19 = 0;

                        for(int var20 = 0; var20 < var5; ++var20) {
                           var19 += var13.H((byte)-26);
                           int var21;
                           if (var6 == null) {
                              var21 = var20;
                           } else {
                              var21 = var6[var20];
                           }

                           if (var21 == var2) {
                              System.arraycopy(var26, var17, var29, var27, var19);
                              var27 += var19;
                           }

                           var17 += var19;
                        }
                     }

                     var7[var15] = var29;
                  }
               } else {
                  if (var6 == null) {
                     var11 = 0;
                  } else {
                     var11 = var6[0];
                  }

                  if (this.substring * -1870742467 == 0) {
                     var7[var11] = EC.I(var26, false, (short)-11343);
                  } else {
                     var7[var11] = var26;
                  }
               }

               return true;
            }
         }
      } catch (RuntimeException var23) {
         throw DQ.I(var23, "ke.c(" + ')');
      }
   }

   public synchronized int[] B(int var1, int var2) {
      try {
         if (!this.toLowerCase(var1, (byte)1)) {
            return null;
         } else {
            int[] var3 = this.length.H[var1];
            if (var3 == null) {
               var3 = new int[this.length.G[var1]];

               for(int var4 = 0; var4 < var3.length; var3[var4] = var4++) {
                  ;
               }
            }

            return var3;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ke.t(" + ')');
      }
   }

   synchronized boolean substring(int var1, int var2, int[] var3) {
      if (!this.toLowerCase(var1, (byte)1)) {
         return false;
      } else if (this.method2253[var1] == null) {
         return false;
      } else {
         int var4 = this.length.G[var1];
         int[] var5 = this.length.H[var1];
         if (this.method2256[var1] == null) {
            this.method2256[var1] = new Object[this.length.B[var1]];
         }

         Object[] var6 = this.method2256[var1];
         boolean var7 = true;

         for(int var8 = 0; var8 < var4; ++var8) {
            int var9;
            if (var5 == null) {
               var9 = var8;
            } else {
               var9 = var5[var8];
            }

            if (var6[var9] == null) {
               var7 = false;
               break;
            }
         }

         if (var7) {
            return true;
         } else {
            byte[] var22;
            if (var3 == null || var3[0] == 0 && var3[1] == 0 && var3[2] == 0 && var3[3] == 0) {
               var22 = TP.I(this.method2253[var1], false, 959051680);
            } else {
               var22 = TP.I(this.method2253[var1], true, -1017882504);
               REI var23 = new REI(var22);
               var23.Z(var3, 5, var23.S.length, -2120558016);
            }

            byte[] var24;
            try {
               var24 = CJ.I(var22, -199793511);
            } catch (RuntimeException var21) {
               throw DQ.I(var21, (var3 != null) + " " + var1 + " " + var22.length + " " + BA.I(var22, var22.length, -2111183372) + " " + BA.I(var22, var22.length - 2, -1919903806) + " " + this.length.A[var1] + " " + 1600327191 * this.length.I);
            }

            if (this.method2250) {
               this.method2253[var1] = null;
            }

            int var10;
            if (var4 > 1) {
               int var11;
               REI var12;
               int var14;
               int var15;
               int var16;
               int var17;
               int var18;
               if (2 != this.substring * -1870742467) {
                  var10 = var24.length;
                  --var10;
                  var11 = var24[var10] & 255;
                  var10 -= 4 * var11 * var4;
                  var12 = new REI(var24);
                  int[] var13 = new int[var4];
                  var12.A = var10 * 116413311;

                  for(var14 = 0; var14 < var11; ++var14) {
                     var15 = 0;

                     for(var16 = 0; var16 < var4; ++var16) {
                        var15 += var12.H((byte)-6);
                        var13[var16] += var15;
                     }
                  }

                  byte[][] var26 = new byte[var4][];

                  for(var15 = 0; var15 < var4; ++var15) {
                     var26[var15] = new byte[var13[var15]];
                     var13[var15] = 0;
                  }

                  var12.A = var10 * 116413311;
                  var15 = 0;

                  for(var16 = 0; var16 < var11; ++var16) {
                     var17 = 0;

                     for(var18 = 0; var18 < var4; ++var18) {
                        var17 += var12.H((byte)5);
                        System.arraycopy(var24, var15, var26[var18], var13[var18], var17);
                        var13[var18] += var17;
                        var15 += var17;
                     }
                  }

                  for(var16 = 0; var16 < var4; ++var16) {
                     if (var5 == null) {
                        var17 = var16;
                     } else {
                        var17 = var5[var16];
                     }

                     if (-1870742467 * this.substring == 0) {
                        var6[var17] = EC.I(var26[var16], false, (short)3420);
                     } else {
                        var6[var17] = var26[var16];
                     }
                  }
               } else {
                  var10 = var24.length;
                  --var10;
                  var11 = var24[var10] & 255;
                  var10 -= var4 * var11 * 4;
                  var12 = new REI(var24);
                  int var25 = 0;
                  var14 = 0;
                  var12.A = 116413311 * var10;

                  for(var15 = 0; var15 < var11; ++var15) {
                     var16 = 0;

                     for(var17 = 0; var17 < var4; ++var17) {
                        var16 += var12.H((byte)-22);
                        if (var5 == null) {
                           var18 = var17;
                        } else {
                           var18 = var5[var17];
                        }

                        if (var18 == var2) {
                           var25 += var16;
                           var14 = var18;
                        }
                     }
                  }

                  if (var25 == 0) {
                     return true;
                  }

                  byte[] var27 = new byte[var25];
                  var25 = 0;
                  var12.A = var10 * 116413311;
                  var16 = 0;

                  for(var17 = 0; var17 < var11; ++var17) {
                     var18 = 0;

                     for(int var19 = 0; var19 < var4; ++var19) {
                        var18 += var12.H((byte)49);
                        int var20;
                        if (var5 == null) {
                           var20 = var19;
                        } else {
                           var20 = var5[var19];
                        }

                        if (var20 == var2) {
                           System.arraycopy(var24, var16, var27, var25, var18);
                           var25 += var18;
                        }

                        var16 += var18;
                     }
                  }

                  var6[var14] = var27;
               }
            } else {
               if (var5 == null) {
                  var10 = 0;
               } else {
                  var10 = var5[0];
               }

               if (this.substring * -1870742467 == 0) {
                  var6[var10] = EC.I(var24, false, (short)-45);
               } else {
                  var6[var10] = var24;
               }
            }

            return true;
         }
      }
   }

   synchronized boolean toLowerCase(int var1, byte var2) {
      try {
         if (!this.append(-1888148215)) {
            return false;
         } else if (var1 >= 0 && var1 < this.length.B.length && this.length.B[var1] != 0) {
            return true;
         } else if (toString) {
            throw new IllegalArgumentException(Integer.toString(var1));
         } else {
            return false;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ke.b(" + ')');
      }
   }

   public synchronized boolean D(int var1, int var2) {
      try {
         if (!this.append(-259904989)) {
            return false;
         } else if (1 == this.length.B.length) {
            return this.I(0, var1, (int)-1025716899);
         } else if (!this.toLowerCase(var1, (byte)1)) {
            return false;
         } else if (this.length.B[var1] == 1) {
            return this.I(var1, 0, (int)-2065975004);
         } else {
            throw new RuntimeException();
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ke.r(" + ')');
      }
   }

   public int B(String var1, int var2) {
      try {
         if (!this.append(1289573635)) {
            return -1;
         } else {
            var1 = var1.toLowerCase();
            int var3 = this.length.J.I(LJ.I((CharSequence)var1, (int)-2067562497), 403552753);
            return !this.toLowerCase(var3, (byte)1) ? -1 : var3;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ke.m(" + ')');
      }
   }

   public boolean D(String var1, int var2) {
      try {
         if (!this.append(-492791802)) {
            return false;
         } else {
            var1 = var1.toLowerCase();
            int var3 = this.length.J.I(LJ.I((CharSequence)var1, (int)-2120237955), 187766103);
            return this.I(var3, 1717306833);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ke.ak(" + ')');
      }
   }

   public boolean F(String var1, int var2) {
      try {
         int var3 = this.B("", -1723903675);
         return var3 != -1 ? this.method2251("", var1, -563288883) : this.method2251(var1, "", -859462811);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ke.aa(" + ')');
      }
   }

   synchronized boolean toString(int var1, int var2, int[] var3) {
      if (!this.toLowerCase(var1, (byte)1)) {
         return false;
      } else if (this.method2253[var1] == null) {
         return false;
      } else {
         int var4 = this.length.G[var1];
         int[] var5 = this.length.H[var1];
         if (this.method2256[var1] == null) {
            this.method2256[var1] = new Object[this.length.B[var1]];
         }

         Object[] var6 = this.method2256[var1];
         boolean var7 = true;

         for(int var8 = 0; var8 < var4; ++var8) {
            int var9;
            if (var5 == null) {
               var9 = var8;
            } else {
               var9 = var5[var8];
            }

            if (var6[var9] == null) {
               var7 = false;
               break;
            }
         }

         if (var7) {
            return true;
         } else {
            byte[] var22;
            if (var3 == null || var3[0] == 0 && var3[1] == 0 && var3[2] == 0 && var3[3] == 0) {
               var22 = TP.I(this.method2253[var1], false, 235085962);
            } else {
               var22 = TP.I(this.method2253[var1], true, 1730830793);
               REI var23 = new REI(var22);
               var23.Z(var3, 5, var23.S.length, -458895567);
            }

            byte[] var24;
            try {
               var24 = CJ.I(var22, 2053445966);
            } catch (RuntimeException var21) {
               throw DQ.I(var21, (var3 != null) + " " + var1 + " " + var22.length + " " + BA.I(var22, var22.length, -2054415257) + " " + BA.I(var22, var22.length - 2, -1915676199) + " " + this.length.A[var1] + " " + 1600327191 * this.length.I);
            }

            if (this.method2250) {
               this.method2253[var1] = null;
            }

            int var10;
            if (var4 > 1) {
               int var11;
               REI var12;
               int var14;
               int var15;
               int var16;
               int var17;
               int var18;
               if (2 != this.substring * -1870742467) {
                  var10 = var24.length;
                  --var10;
                  var11 = var24[var10] & 255;
                  var10 -= 4 * var11 * var4;
                  var12 = new REI(var24);
                  int[] var13 = new int[var4];
                  var12.A = var10 * 116413311;

                  for(var14 = 0; var14 < var11; ++var14) {
                     var15 = 0;

                     for(var16 = 0; var16 < var4; ++var16) {
                        var15 += var12.H((byte)-16);
                        var13[var16] += var15;
                     }
                  }

                  byte[][] var26 = new byte[var4][];

                  for(var15 = 0; var15 < var4; ++var15) {
                     var26[var15] = new byte[var13[var15]];
                     var13[var15] = 0;
                  }

                  var12.A = var10 * 116413311;
                  var15 = 0;

                  for(var16 = 0; var16 < var11; ++var16) {
                     var17 = 0;

                     for(var18 = 0; var18 < var4; ++var18) {
                        var17 += var12.H((byte)-61);
                        System.arraycopy(var24, var15, var26[var18], var13[var18], var17);
                        var13[var18] += var17;
                        var15 += var17;
                     }
                  }

                  for(var16 = 0; var16 < var4; ++var16) {
                     if (var5 == null) {
                        var17 = var16;
                     } else {
                        var17 = var5[var16];
                     }

                     if (-1870742467 * this.substring == 0) {
                        var6[var17] = EC.I(var26[var16], false, (short)-1311);
                     } else {
                        var6[var17] = var26[var16];
                     }
                  }
               } else {
                  var10 = var24.length;
                  --var10;
                  var11 = var24[var10] & 255;
                  var10 -= var4 * var11 * 4;
                  var12 = new REI(var24);
                  int var25 = 0;
                  var14 = 0;
                  var12.A = 116413311 * var10;

                  for(var15 = 0; var15 < var11; ++var15) {
                     var16 = 0;

                     for(var17 = 0; var17 < var4; ++var17) {
                        var16 += var12.H((byte)51);
                        if (var5 == null) {
                           var18 = var17;
                        } else {
                           var18 = var5[var17];
                        }

                        if (var18 == var2) {
                           var25 += var16;
                           var14 = var18;
                        }
                     }
                  }

                  if (var25 == 0) {
                     return true;
                  }

                  byte[] var27 = new byte[var25];
                  var25 = 0;
                  var12.A = var10 * 116413311;
                  var16 = 0;

                  for(var17 = 0; var17 < var11; ++var17) {
                     var18 = 0;

                     for(int var19 = 0; var19 < var4; ++var19) {
                        var18 += var12.H((byte)10);
                        int var20;
                        if (var5 == null) {
                           var20 = var19;
                        } else {
                           var20 = var5[var19];
                        }

                        if (var20 == var2) {
                           System.arraycopy(var24, var16, var27, var25, var18);
                           var25 += var18;
                        }

                        var16 += var18;
                     }
                  }

                  var6[var14] = var27;
               }
            } else {
               if (var5 == null) {
                  var10 = 0;
               } else {
                  var10 = var5[0];
               }

               if (this.substring * -1870742467 == 0) {
                  var6[var10] = EC.I(var24, false, (short)7031);
               } else {
                  var6[var10] = var24;
               }
            }

            return true;
         }
      }
   }

   public byte[] I(int var1, int var2, byte var3) {
      try {
         return this.I(var1, var2, (int[])null, -1954204331);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ke.d(" + ')');
      }
   }

   public int F(int var1, int var2) {
      try {
         return !this.toLowerCase(var1, (byte)1) ? 0 : this.length.B[var1];
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ke.h(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, int var3) {
      try {
         String var4 = (String)var2.S[(var2.A -= 969361751) * -203050393];
         if (IN.I(var4, var2, -1820459724) != null) {
            var4 = var4.substring(0, var4.length() - 1);
         }

         var0.nZ = OI.I(var4, var2, -2046058202);
         var0.JZ = true;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ke.nf(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = (int)(CI.I((byte)1) / 86400000L) - 11745;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ke.aka(" + ')');
      }
   }
}
