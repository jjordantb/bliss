public class Exception_Sub3 extends Exception {
   Exception_Sub3(H var1, int var2, int var3) {
   }

   public static X method275(int var0, byte var1) {
      try {
         return IU.F[var0 >> 16];
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aev.b(" + ')');
      }
   }
}
