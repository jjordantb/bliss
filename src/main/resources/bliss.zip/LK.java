public class LK extends YG {
   static boolean Q = true;
   static boolean R = true;
   static boolean T = false;
   boolean U = true;
   boolean V = true;

   int[] append(int var1) {
      int[] var2 = this.P.I(var1, 1012167629);
      if (this.P.D) {
         int[] var3 = this.I(0, this.V ? -289063255 * WJ.F - var1 : var1, -1887337990);
         if (this.U) {
            for(int var4 = 0; var4 < WJ.C * -1474554145; ++var4) {
               var2[var4] = var3[-901777799 * WJ.I - var4];
            }
         } else {
            TW.I((int[])var3, 0, (int[])var2, 0, -1474554145 * WJ.C);
         }
      }

      return var2;
   }

   int[][] toString(int var1) {
      int[][] var2 = this.L.I(var1, (byte)107);
      if (this.L.I) {
         int[][] var3 = this.I(0, this.V ? WJ.F * -289063255 - var1 : var1, (byte)8);
         int[] var4 = var3[0];
         int[] var5 = var3[1];
         int[] var6 = var3[2];
         int[] var7 = var2[0];
         int[] var8 = var2[1];
         int[] var9 = var2[2];
         int var10;
         if (this.U) {
            for(var10 = 0; var10 < -1474554145 * WJ.C; ++var10) {
               var7[var10] = var4[WJ.I * -901777799 - var10];
               var8[var10] = var5[-901777799 * WJ.I - var10];
               var9[var10] = var6[WJ.I * -901777799 - var10];
            }
         } else {
            for(var10 = 0; var10 < WJ.C * -1474554145; ++var10) {
               var7[var10] = var4[var10];
               var8[var10] = var5[var10];
               var9[var10] = var6[var10];
            }
         }
      }

      return var2;
   }

   int[] Z(int var1, int var2) {
      try {
         int[] var3 = this.P.I(var1, 1850560302);
         if (this.P.D) {
            int[] var4 = this.I(0, this.V ? -289063255 * WJ.F - var1 : var1, -1887337990);
            if (this.U) {
               for(int var5 = 0; var5 < WJ.C * -1474554145; ++var5) {
                  var3[var5] = var4[-901777799 * WJ.I - var5];
               }
            } else {
               TW.I((int[])var4, 0, (int[])var3, 0, -1474554145 * WJ.C);
            }
         }

         return var3;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "agw.i(" + ')');
      }
   }

   void I(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.U = var2.I() == 1;
         break;
      case 1:
         this.V = var2.I() == 1;
         break;
      case 2:
         this.N = var2.I() == 1;
      }

   }

   int[] D(int var1) {
      int[] var2 = this.P.I(var1, 293659249);
      if (this.P.D) {
         int[] var3 = this.I(0, this.V ? -289063255 * WJ.F - var1 : var1, -1887337990);
         if (this.U) {
            for(int var4 = 0; var4 < WJ.C * -1474554145; ++var4) {
               var2[var4] = var3[-901777799 * WJ.I - var4];
            }
         } else {
            TW.I((int[])var3, 0, (int[])var2, 0, -1474554145 * WJ.C);
         }
      }

      return var2;
   }

   void I(int var1, REI var2, byte var3) {
      try {
         switch(var1) {
         case 0:
            this.U = var2.I() == 1;
            break;
         case 1:
            this.V = var2.I() == 1;
            break;
         case 2:
            this.N = var2.I() == 1;
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "agw.r(" + ')');
      }
   }

   void Z(int var1, REI var2) {
      switch(var1) {
      case 0:
         this.U = var2.I() == 1;
         break;
      case 1:
         this.V = var2.I() == 1;
         break;
      case 2:
         this.N = var2.I() == 1;
      }

   }

   int[][] I(int var1, byte var2) {
      try {
         int[][] var3 = this.L.I(var1, (byte)91);
         if (this.L.I) {
            int[][] var4 = this.I(0, this.V ? WJ.F * -289063255 - var1 : var1, (byte)8);
            int[] var5 = var4[0];
            int[] var6 = var4[1];
            int[] var7 = var4[2];
            int[] var8 = var3[0];
            int[] var9 = var3[1];
            int[] var10 = var3[2];
            int var11;
            if (this.U) {
               for(var11 = 0; var11 < -1474554145 * WJ.C; ++var11) {
                  var8[var11] = var5[WJ.I * -901777799 - var11];
                  var9[var11] = var6[-901777799 * WJ.I - var11];
                  var10[var11] = var7[WJ.I * -901777799 - var11];
               }
            } else {
               for(var11 = 0; var11 < WJ.C * -1474554145; ++var11) {
                  var8[var11] = var5[var11];
                  var9[var11] = var6[var11];
                  var10[var11] = var7[var11];
               }
            }
         }

         return var3;
      } catch (RuntimeException var12) {
         throw DQ.I(var12, "agw.k(" + ')');
      }
   }

   int[][] F(int var1) {
      int[][] var2 = this.L.I(var1, (byte)112);
      if (this.L.I) {
         int[][] var3 = this.I(0, this.V ? WJ.F * -289063255 - var1 : var1, (byte)8);
         int[] var4 = var3[0];
         int[] var5 = var3[1];
         int[] var6 = var3[2];
         int[] var7 = var2[0];
         int[] var8 = var2[1];
         int[] var9 = var2[2];
         int var10;
         if (this.U) {
            for(var10 = 0; var10 < -1474554145 * WJ.C; ++var10) {
               var7[var10] = var4[WJ.I * -901777799 - var10];
               var8[var10] = var5[-901777799 * WJ.I - var10];
               var9[var10] = var6[WJ.I * -901777799 - var10];
            }
         } else {
            for(var10 = 0; var10 < WJ.C * -1474554145; ++var10) {
               var7[var10] = var4[var10];
               var8[var10] = var5[var10];
               var9[var10] = var6[var10];
            }
         }
      }

      return var2;
   }

   public LK() {
      super(1, false);
   }
}
