import jaggl.OpenGL;

public class FII extends RY {
   SO F;
   static char Z = '\u0001';
   static char glDisable = 0;
   KA glEnable;
   VX glLoadIdentity;
   static float[] glMatrixMode = new float[]{0.0F, 0.0F, 0.0F, 0.0F};

   void method516(int var1, int var2) {
      if ((var1 & 1) == 1) {
         if (this.glLoadIdentity.D) {
            this.I.I((SN)this.glLoadIdentity.J);
            glMatrixMode[0] = 0.0F;
            glMatrixMode[1] = 0.0F;
            glMatrixMode[2] = 0.0F;
            glMatrixMode[3] = (float)(this.I.E % 4000) / 4000.0F;
            OpenGL.glTexGenfv(8194, 9473, glMatrixMode, 0);
         } else {
            int var3 = this.I.E % 4000 * 16 / 4000;
            this.I.I((SN)this.glLoadIdentity.H[var3]);
         }
      } else if (this.glLoadIdentity.D) {
         this.I.I((SN)this.glLoadIdentity.J);
         glMatrixMode[0] = 0.0F;
         glMatrixMode[1] = 0.0F;
         glMatrixMode[2] = 0.0F;
         glMatrixMode[3] = 0.0F;
         OpenGL.glTexGenfv(8194, 9473, glMatrixMode, 0);
      } else {
         this.I.I((SN)this.glLoadIdentity.H[0]);
      }

   }

   boolean method501() {
      return true;
   }

   void method518(boolean var1) {
      this.I.Z(260, 8448);
   }

   FII(MJI var1, VX var2) {
      super(var1);
      this.glLoadIdentity = var2;
      this.F();
      this.F = new SO(this.I, YCI.G, SDI.C, 2, new byte[]{0, -1}, YCI.G);
      this.F.C(false);
   }

   void method503(int var1, int var2) {
      if ((var1 & 1) == 1) {
         if (this.glLoadIdentity.D) {
            this.I.I((SN)this.glLoadIdentity.J);
            glMatrixMode[0] = 0.0F;
            glMatrixMode[1] = 0.0F;
            glMatrixMode[2] = 0.0F;
            glMatrixMode[3] = (float)(this.I.E % 4000) / 4000.0F;
            OpenGL.glTexGenfv(8194, 9473, glMatrixMode, 0);
         } else {
            int var3 = this.I.E % 4000 * 16 / 4000;
            this.I.I((SN)this.glLoadIdentity.H[var3]);
         }
      } else if (this.glLoadIdentity.D) {
         this.I.I((SN)this.glLoadIdentity.J);
         glMatrixMode[0] = 0.0F;
         glMatrixMode[1] = 0.0F;
         glMatrixMode[2] = 0.0F;
         glMatrixMode[3] = 0.0F;
         OpenGL.glTexGenfv(8194, 9473, glMatrixMode, 0);
      } else {
         this.I.I((SN)this.glLoadIdentity.H[0]);
      }

   }

   void method500(SN var1, int var2) {
   }

   void method508(boolean var1) {
      this.I.Z(260, 8448);
   }

   void method506(boolean var1) {
      if (this.I.I > 0) {
         float var2 = -0.5F / (float)this.I.I;
         this.I.C(1);
         glMatrixMode[0] = 0.0F;
         glMatrixMode[1] = 0.0F;
         glMatrixMode[2] = var2;
         glMatrixMode[3] = this.I.t * var2 + 0.25F;
         OpenGL.glPushMatrix();
         OpenGL.glLoadIdentity();
         OpenGL.glTexGenfv(8192, 9474, glMatrixMode, 0);
         OpenGL.glPopMatrix();
         this.I.I(0.5F, (float)this.I.I);
         this.I.I((SN)this.F);
         this.I.C(0);
      }

      this.glEnable.I('\u0000');
      OpenGL.glMatrixMode(5890);
      OpenGL.glPushMatrix();
      OpenGL.glScalef(0.25F, 0.25F, 1.0F);
      OpenGL.glMatrixMode(5888);
   }

   void method507(boolean var1) {
      if (this.I.I > 0) {
         float var2 = -0.5F / (float)this.I.I;
         this.I.C(1);
         glMatrixMode[0] = 0.0F;
         glMatrixMode[1] = 0.0F;
         glMatrixMode[2] = var2;
         glMatrixMode[3] = this.I.t * var2 + 0.25F;
         OpenGL.glPushMatrix();
         OpenGL.glLoadIdentity();
         OpenGL.glTexGenfv(8192, 9474, glMatrixMode, 0);
         OpenGL.glPopMatrix();
         this.I.I(0.5F, (float)this.I.I);
         this.I.I((SN)this.F);
         this.I.C(0);
      }

      this.glEnable.I('\u0000');
      OpenGL.glMatrixMode(5890);
      OpenGL.glPushMatrix();
      OpenGL.glScalef(0.25F, 0.25F, 1.0F);
      OpenGL.glMatrixMode(5888);
   }

   void method511() {
      this.glEnable.I('\u0001');
      if (this.I.I > 0) {
         this.I.C(1);
         this.I.I((SN)null);
         this.I.I(1.0F, 0.0F);
         this.I.C(0);
      }

      this.I.Z(8448, 8448);
      OpenGL.glMatrixMode(5890);
      OpenGL.glPopMatrix();
      OpenGL.glMatrixMode(5888);
   }

   void method509(boolean var1) {
      this.I.Z(260, 8448);
   }

   void method510(boolean var1) {
      this.I.Z(260, 8448);
   }

   void F() {
      this.glEnable = new KA(this.I, 2);
      this.glEnable.I((int)0);
      this.I.C(1);
      this.I.Z(7681, 260);
      this.I.I(0, 34168, 768);
      OpenGL.glTexGeni(8192, 9472, 9216);
      OpenGL.glEnable(3168);
      this.I.C(0);
      OpenGL.glTexEnvf(8960, 34163, 2.0F);
      if (this.glLoadIdentity.D) {
         OpenGL.glTexGeni(8194, 9472, 9217);
         OpenGL.glTexGeni(8195, 9472, 9217);
         OpenGL.glTexGenfv(8195, 9473, new float[]{0.0F, 0.0F, 0.0F, 1.0F}, 0);
         OpenGL.glEnable(3170);
         OpenGL.glEnable(3171);
      }

      this.glEnable.I();
      this.glEnable.I((int)1);
      this.I.C(1);
      this.I.Z(8448, 8448);
      this.I.I(0, 5890, 768);
      OpenGL.glDisable(3168);
      this.I.C(0);
      OpenGL.glTexEnvf(8960, 34163, 1.0F);
      if (this.glLoadIdentity.D) {
         OpenGL.glDisable(3170);
         OpenGL.glDisable(3171);
      }

      this.glEnable.I();
   }

   void method504() {
      this.glEnable.I('\u0001');
      if (this.I.I > 0) {
         this.I.C(1);
         this.I.I((SN)null);
         this.I.I(1.0F, 0.0F);
         this.I.C(0);
      }

      this.I.Z(8448, 8448);
      OpenGL.glMatrixMode(5890);
      OpenGL.glPopMatrix();
      OpenGL.glMatrixMode(5888);
   }

   void method513(int var1, int var2) {
      if ((var1 & 1) == 1) {
         if (this.glLoadIdentity.D) {
            this.I.I((SN)this.glLoadIdentity.J);
            glMatrixMode[0] = 0.0F;
            glMatrixMode[1] = 0.0F;
            glMatrixMode[2] = 0.0F;
            glMatrixMode[3] = (float)(this.I.E % 4000) / 4000.0F;
            OpenGL.glTexGenfv(8194, 9473, glMatrixMode, 0);
         } else {
            int var3 = this.I.E % 4000 * 16 / 4000;
            this.I.I((SN)this.glLoadIdentity.H[var3]);
         }
      } else if (this.glLoadIdentity.D) {
         this.I.I((SN)this.glLoadIdentity.J);
         glMatrixMode[0] = 0.0F;
         glMatrixMode[1] = 0.0F;
         glMatrixMode[2] = 0.0F;
         glMatrixMode[3] = 0.0F;
         OpenGL.glTexGenfv(8194, 9473, glMatrixMode, 0);
      } else {
         this.I.I((SN)this.glLoadIdentity.H[0]);
      }

   }

   void method502(int var1, int var2) {
      if ((var1 & 1) == 1) {
         if (this.glLoadIdentity.D) {
            this.I.I((SN)this.glLoadIdentity.J);
            glMatrixMode[0] = 0.0F;
            glMatrixMode[1] = 0.0F;
            glMatrixMode[2] = 0.0F;
            glMatrixMode[3] = (float)(this.I.E % 4000) / 4000.0F;
            OpenGL.glTexGenfv(8194, 9473, glMatrixMode, 0);
         } else {
            int var3 = this.I.E % 4000 * 16 / 4000;
            this.I.I((SN)this.glLoadIdentity.H[var3]);
         }
      } else if (this.glLoadIdentity.D) {
         this.I.I((SN)this.glLoadIdentity.J);
         glMatrixMode[0] = 0.0F;
         glMatrixMode[1] = 0.0F;
         glMatrixMode[2] = 0.0F;
         glMatrixMode[3] = 0.0F;
         OpenGL.glTexGenfv(8194, 9473, glMatrixMode, 0);
      } else {
         this.I.I((SN)this.glLoadIdentity.H[0]);
      }

   }

   void method512() {
      this.glEnable.I('\u0001');
      if (this.I.I > 0) {
         this.I.C(1);
         this.I.I((SN)null);
         this.I.I(1.0F, 0.0F);
         this.I.C(0);
      }

      this.I.Z(8448, 8448);
      OpenGL.glMatrixMode(5890);
      OpenGL.glPopMatrix();
      OpenGL.glMatrixMode(5888);
   }

   void method505(boolean var1) {
      if (this.I.I > 0) {
         float var2 = -0.5F / (float)this.I.I;
         this.I.C(1);
         glMatrixMode[0] = 0.0F;
         glMatrixMode[1] = 0.0F;
         glMatrixMode[2] = var2;
         glMatrixMode[3] = this.I.t * var2 + 0.25F;
         OpenGL.glPushMatrix();
         OpenGL.glLoadIdentity();
         OpenGL.glTexGenfv(8192, 9474, glMatrixMode, 0);
         OpenGL.glPopMatrix();
         this.I.I(0.5F, (float)this.I.I);
         this.I.I((SN)this.F);
         this.I.C(0);
      }

      this.glEnable.I('\u0000');
      OpenGL.glMatrixMode(5890);
      OpenGL.glPushMatrix();
      OpenGL.glScalef(0.25F, 0.25F, 1.0F);
      OpenGL.glMatrixMode(5888);
   }

   void method517(int var1, int var2) {
      if ((var1 & 1) == 1) {
         if (this.glLoadIdentity.D) {
            this.I.I((SN)this.glLoadIdentity.J);
            glMatrixMode[0] = 0.0F;
            glMatrixMode[1] = 0.0F;
            glMatrixMode[2] = 0.0F;
            glMatrixMode[3] = (float)(this.I.E % 4000) / 4000.0F;
            OpenGL.glTexGenfv(8194, 9473, glMatrixMode, 0);
         } else {
            int var3 = this.I.E % 4000 * 16 / 4000;
            this.I.I((SN)this.glLoadIdentity.H[var3]);
         }
      } else if (this.glLoadIdentity.D) {
         this.I.I((SN)this.glLoadIdentity.J);
         glMatrixMode[0] = 0.0F;
         glMatrixMode[1] = 0.0F;
         glMatrixMode[2] = 0.0F;
         glMatrixMode[3] = 0.0F;
         OpenGL.glTexGenfv(8194, 9473, glMatrixMode, 0);
      } else {
         this.I.I((SN)this.glLoadIdentity.H[0]);
      }

   }

   void method514(SN var1, int var2) {
   }

   void method515(int var1, int var2) {
      if ((var1 & 1) == 1) {
         if (this.glLoadIdentity.D) {
            this.I.I((SN)this.glLoadIdentity.J);
            glMatrixMode[0] = 0.0F;
            glMatrixMode[1] = 0.0F;
            glMatrixMode[2] = 0.0F;
            glMatrixMode[3] = (float)(this.I.E % 4000) / 4000.0F;
            OpenGL.glTexGenfv(8194, 9473, glMatrixMode, 0);
         } else {
            int var3 = this.I.E % 4000 * 16 / 4000;
            this.I.I((SN)this.glLoadIdentity.H[var3]);
         }
      } else if (this.glLoadIdentity.D) {
         this.I.I((SN)this.glLoadIdentity.J);
         glMatrixMode[0] = 0.0F;
         glMatrixMode[1] = 0.0F;
         glMatrixMode[2] = 0.0F;
         glMatrixMode[3] = 0.0F;
         OpenGL.glTexGenfv(8194, 9473, glMatrixMode, 0);
      } else {
         this.I.I((SN)this.glLoadIdentity.H[0]);
      }

   }

   boolean method520() {
      return true;
   }

   void method519(SN var1, int var2) {
   }
}
