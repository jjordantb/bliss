public class KY {
   public int[] I = new int[2];
   static int F = 2;
   static int Z = 4;
   static int append = 1;
   public int[] C = new int[3];
   public int[] B = new int[3];
   static int arraycopy = 8;
   public int[] D = new int[2];
   public short[] J;
   public short[] S;

   KY(SEI var1) {
      this.C[0] = 1343198193 * var1.W;
      this.C[1] = var1.e * 34210967;
      this.C[2] = var1.v * 1313278521;
      this.B[0] = 1585491093 * var1.l;
      this.B[1] = var1.k * -1284247975;
      this.B[2] = var1.h * -1767718263;
      this.I[0] = var1.w * -1282951055;
      this.I[1] = 86274879 * var1.m;
      this.D[0] = var1.n * -1531415419;
      this.D[1] = var1.y * 1578724433;
      if (var1.S != null) {
         this.J = new short[var1.S.length];
         System.arraycopy(var1.S, 0, this.J, 0, this.J.length);
      }

      if (var1.G != null) {
         this.S = new short[var1.G.length];
         System.arraycopy(var1.G, 0, this.S, 0, this.S.length);
      }

   }

   public static final void I(int var0) {
      try {
         if (!XEI.cZ) {
            XEI.YZ += (-24.0F - XEI.YZ) / 2.0F;
            XEI.bZ = true;
            XEI.cZ = true;
         }

      } catch (RuntimeException var2) {
         throw DQ.I(var2, "td.hr(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.X[var0.i * 1883543357];
         FSI.J[var2] = (String)var0.S[(var0.A -= 969361751) * -203050393];
         DA.I(var2, 1525227442);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "td.am(" + ')');
      }
   }
}
