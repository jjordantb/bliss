import jaggl.OpenGL;

public class BN extends CN {
   HCI glBegin;
   static float A = 0.25F;
   static float E = 1.0F;
   static float G = 1.0F;
   static String glEnd = "#extension GL_ARB_texture_rectangle : enable\nuniform vec3 params;\nuniform sampler2DRect sceneTex;\nconst vec3 lumCoef = vec3(0.2126, 0.7152, 0.0722);\nvoid main() {\n    vec4 col = texture2DRect(sceneTex, gl_TexCoord[0].xy);\n    gl_FragColor = col*step(params.x, dot(lumCoef, col.rgb));\n}\n";
   YA glGetUniformLocation;
   static String glLoadIdentity = "uniform vec3 step;\nuniform sampler2D baseTex;\nvoid main() {\n\tvec4 fragCol = texture2D(baseTex, gl_TexCoord[0].xy)*0.091396265;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-1.0*step.xy))*0.088584304;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 1.0*step.xy))*0.088584304;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-2.0*step.xy))*0.08065692;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 2.0*step.xy))*0.08065692;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-3.0*step.xy))*0.068989515;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 3.0*step.xy))*0.068989515;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-4.0*step.xy))*0.055434637;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 4.0*step.xy))*0.055434637;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-5.0*step.xy))*0.04184426;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 5.0*step.xy))*0.04184426;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-6.0*step.xy))*0.029672023;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 6.0*step.xy))*0.029672023;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-7.0*step.xy))*0.019765828;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 7.0*step.xy))*0.019765828;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-8.0*step.xy))*0.012369139;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 8.0*step.xy))*0.012369139;\n\tgl_FragColor = fragCol;\n}\n";
   static int glMatrixMode = 256;
   static String glOrtho = "#extension GL_ARB_texture_rectangle : enable\nuniform vec3 params;\nuniform vec3 dimScale;\nuniform sampler2D bloomTex;\nuniform sampler2DRect sceneTex;\nconst vec3 lumCoef = vec3(0.2126, 0.7152, 0.0722);\nvoid main() {\n\t vec4 bloomCol = texture2D(bloomTex, gl_TexCoord[1].xy);\n\t vec4 sceneCol = texture2DRect(sceneTex, gl_TexCoord[0].xy);\n\t float preLum = 0.99*dot(lumCoef, sceneCol.rgb)+0.01;\n    float postLum = preLum*(1.0+(preLum/params.y))/(preLum+1.0);\n\t gl_FragColor = sceneCol*(postLum/preLum)+bloomCol*params.x;\n}\n";
   HCI glPopAttrib;
   FO glPopMatrix;
   FO glPushAttrib;
   static String glPushMatrix = "uniform vec3 params;\nuniform sampler2D sceneTex;\nconst vec3 lumCoef = vec3(0.2126, 0.7152, 0.0722);\nvoid main() {\n    vec4 col = texture2D(sceneTex, gl_TexCoord[0].xy);\n    gl_FragColor = col*step(params.x, dot(lumCoef, col.rgb));\n}\n";
   YA glTexCoord2f;
   int glUniform1i;
   int glUniform3f;
   int glUseProgram;
   YA glVertex2i;
   int glViewport;
   YA method560;
   FO[] method563;

   boolean method2869() {
      if (this.S.CI && this.S.R && this.S.n) {
         this.glPopAttrib = new HCI(this.S);
         this.glPopMatrix = new FO(this.S, 3553, YCI.Z, SDI.I, 256, 256);
         this.glPopMatrix.I(false, false);
         this.glPushAttrib = new FO(this.S, 3553, YCI.Z, SDI.I, 256, 256);
         this.glPushAttrib.I(false, false);
         this.S.Z(this.glPopAttrib, (byte)112);
         this.glPopAttrib.method563(0, this.glPopMatrix.I(0));
         this.glPopAttrib.method563(1, this.glPushAttrib.I(0));
         this.glPopAttrib.C(0);
         if (!this.glPopAttrib.method560()) {
            this.S.I(this.glPopAttrib, (byte)-107);
            return false;
         } else {
            this.S.I(this.glPopAttrib, (byte)-15);
            this.glGetUniformLocation = YA.I(this.S, new HII[]{HII.I(this.S, 35632, "#extension GL_ARB_texture_rectangle : enable\nuniform vec3 params;\nuniform sampler2DRect sceneTex;\nconst vec3 lumCoef = vec3(0.2126, 0.7152, 0.0722);\nvoid main() {\n    vec4 col = texture2DRect(sceneTex, gl_TexCoord[0].xy);\n    gl_FragColor = col*step(params.x, dot(lumCoef, col.rgb));\n}\n")});
            this.method560 = YA.I(this.S, new HII[]{HII.I(this.S, 35632, "uniform vec3 params;\nuniform sampler2D sceneTex;\nconst vec3 lumCoef = vec3(0.2126, 0.7152, 0.0722);\nvoid main() {\n    vec4 col = texture2D(sceneTex, gl_TexCoord[0].xy);\n    gl_FragColor = col*step(params.x, dot(lumCoef, col.rgb));\n}\n")});
            this.glTexCoord2f = YA.I(this.S, new HII[]{HII.I(this.S, 35632, "#extension GL_ARB_texture_rectangle : enable\nuniform vec3 params;\nuniform vec3 dimScale;\nuniform sampler2D bloomTex;\nuniform sampler2DRect sceneTex;\nconst vec3 lumCoef = vec3(0.2126, 0.7152, 0.0722);\nvoid main() {\n\t vec4 bloomCol = texture2D(bloomTex, gl_TexCoord[1].xy);\n\t vec4 sceneCol = texture2DRect(sceneTex, gl_TexCoord[0].xy);\n\t float preLum = 0.99*dot(lumCoef, sceneCol.rgb)+0.01;\n    float postLum = preLum*(1.0+(preLum/params.y))/(preLum+1.0);\n\t gl_FragColor = sceneCol*(postLum/preLum)+bloomCol*params.x;\n}\n")});
            this.glVertex2i = YA.I(this.S, new HII[]{HII.I(this.S, 35632, "uniform vec3 step;\nuniform sampler2D baseTex;\nvoid main() {\n\tvec4 fragCol = texture2D(baseTex, gl_TexCoord[0].xy)*0.091396265;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-1.0*step.xy))*0.088584304;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 1.0*step.xy))*0.088584304;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-2.0*step.xy))*0.08065692;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 2.0*step.xy))*0.08065692;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-3.0*step.xy))*0.068989515;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 3.0*step.xy))*0.068989515;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-4.0*step.xy))*0.055434637;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 4.0*step.xy))*0.055434637;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-5.0*step.xy))*0.04184426;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 5.0*step.xy))*0.04184426;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-6.0*step.xy))*0.029672023;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 6.0*step.xy))*0.029672023;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-7.0*step.xy))*0.019765828;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 7.0*step.xy))*0.019765828;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-8.0*step.xy))*0.012369139;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 8.0*step.xy))*0.012369139;\n\tgl_FragColor = fragCol;\n}\n")});
            return this.method560 != null && this.glGetUniformLocation != null && this.glTexCoord2f != null && this.glVertex2i != null;
         }
      } else {
         return false;
      }
   }

   SDI glBegin() {
      return SDI.I;
   }

   boolean method2868() {
      return this.glPopAttrib != null;
   }

   boolean method2884() {
      return this.glPopAttrib != null;
   }

   SDI glEnd() {
      return SDI.I;
   }

   void method2870() {
      this.glUseProgram = -1;
      this.glViewport = -1;
      this.glBegin = null;
      this.method563 = null;
      this.glPopAttrib = null;
      this.glPopMatrix = null;
      this.glPushAttrib = null;
      this.glGetUniformLocation = null;
      this.method560 = null;
      this.glTexCoord2f = null;
      this.glVertex2i = null;
   }

   void method2871(int var1, int var2) {
      this.glUniform3f = var1;
      this.glUniform1i = var2;
      int var3 = KW.C(this.glUniform3f, 1918937807);
      int var4 = KW.C(this.glUniform1i, 1314388027);
      if (this.glViewport != var3 || this.glUseProgram != var4) {
         int var5;
         if (this.method563 != null) {
            for(var5 = 0; var5 < this.method563.length; ++var5) {
               this.method563[var5].I();
            }

            this.method563 = null;
         }

         if (var3 <= 256 && var4 <= 256) {
            this.glBegin = null;
         } else {
            var5 = var3;
            int var6 = var4;
            int var7 = 0;

            label59:
            while(true) {
               if (var5 <= 256 && var6 <= 256) {
                  if (this.glBegin == null) {
                     this.glBegin = new HCI(this.S);
                  }

                  this.method563 = new FO[var7];
                  var5 = var3;
                  var6 = var4;
                  var7 = 0;

                  while(true) {
                     if (var5 <= 256 && var6 <= 256) {
                        break label59;
                     }

                     this.method563[var7++] = new FO(this.S, 3553, YCI.Z, SDI.I, var5, var6);
                     if (var5 > 256) {
                        var5 >>= 1;
                     }

                     if (var6 > 256) {
                        var6 >>= 1;
                     }
                  }
               }

               if (var5 > 256) {
                  var5 >>= 1;
               }

               if (var6 > 256) {
                  var6 >>= 1;
               }

               ++var7;
            }
         }

         this.glViewport = var3;
         this.glUseProgram = var4;
      }

   }

   void method2873(int var1) {
      OpenGL.glUseProgram(0);
      this.S.C(1);
      this.S.I((SN)null);
      this.S.C(0);
   }

   SDI Z() {
      return SDI.I;
   }

   void method2883(int var1, int var2) {
      this.glUniform3f = var1;
      this.glUniform1i = var2;
      int var3 = KW.C(this.glUniform3f, 1360936610);
      int var4 = KW.C(this.glUniform1i, 1074782076);
      if (this.glViewport != var3 || this.glUseProgram != var4) {
         int var5;
         if (this.method563 != null) {
            for(var5 = 0; var5 < this.method563.length; ++var5) {
               this.method563[var5].I();
            }

            this.method563 = null;
         }

         if (var3 <= 256 && var4 <= 256) {
            this.glBegin = null;
         } else {
            var5 = var3;
            int var6 = var4;
            int var7 = 0;

            label59:
            while(true) {
               if (var5 <= 256 && var6 <= 256) {
                  if (this.glBegin == null) {
                     this.glBegin = new HCI(this.S);
                  }

                  this.method563 = new FO[var7];
                  var5 = var3;
                  var6 = var4;
                  var7 = 0;

                  while(true) {
                     if (var5 <= 256 && var6 <= 256) {
                        break label59;
                     }

                     this.method563[var7++] = new FO(this.S, 3553, YCI.Z, SDI.I, var5, var6);
                     if (var5 > 256) {
                        var5 >>= 1;
                     }

                     if (var6 > 256) {
                        var6 >>= 1;
                     }
                  }
               }

               if (var5 > 256) {
                  var5 >>= 1;
               }

               if (var6 > 256) {
                  var6 >>= 1;
               }

               ++var7;
            }
         }

         this.glViewport = var3;
         this.glUseProgram = var4;
      }

   }

   void method2878(int var1, FO var2, FO var3) {
      OpenGL.glPushAttrib(2048);
      OpenGL.glMatrixMode(5889);
      OpenGL.glPushMatrix();
      OpenGL.glLoadIdentity();
      OpenGL.glOrtho(0.0D, 1.0D, 0.0D, 1.0D, -1.0D, 1.0D);
      int var4;
      int var5;
      if (this.method563 != null) {
         this.S.Z(this.glBegin, (byte)9);
         var4 = KW.C(this.glUniform3f, 2071757561);
         var5 = KW.C(this.glUniform1i, 1398420241);

         int var6;
         for(var6 = 0; var4 > 256 || var5 > 256; ++var6) {
            OpenGL.glViewport(0, 0, var4, var5);
            this.glBegin.method563(0, this.method563[var6].I(0));
            if (var6 == 0) {
               this.S.I((SN)var2);
               OpenGL.glBegin(7);
               OpenGL.glTexCoord2f(0.0F, 0.0F);
               OpenGL.glVertex2i(0, 0);
               OpenGL.glTexCoord2f((float)this.glUniform3f, 0.0F);
               OpenGL.glVertex2i(1, 0);
               OpenGL.glTexCoord2f((float)this.glUniform3f, (float)this.glUniform1i);
               OpenGL.glVertex2i(1, 1);
               OpenGL.glTexCoord2f(0.0F, (float)this.glUniform1i);
               OpenGL.glVertex2i(0, 1);
               OpenGL.glEnd();
            } else {
               this.S.I((SN)this.method563[var6 - 1]);
               OpenGL.glBegin(7);
               OpenGL.glTexCoord2f(0.0F, 0.0F);
               OpenGL.glVertex2i(0, 0);
               OpenGL.glTexCoord2f(1.0F, 0.0F);
               OpenGL.glVertex2i(1, 0);
               OpenGL.glTexCoord2f(1.0F, 1.0F);
               OpenGL.glVertex2i(1, 1);
               OpenGL.glTexCoord2f(0.0F, 1.0F);
               OpenGL.glVertex2i(0, 1);
               OpenGL.glEnd();
            }

            if (var4 > 256) {
               var4 >>= 1;
            }

            if (var5 > 256) {
               var5 >>= 1;
            }
         }

         this.S.I(this.glBegin, (byte)-59);
         this.S.I((SN)this.method563[var6 - 1]);
         this.S.Z(this.glPopAttrib, (byte)-3);
         this.glPopAttrib.C(0);
         OpenGL.glViewport(0, 0, 256, 256);
         int var7 = this.method560.I;
         OpenGL.glUseProgram(var7);
         OpenGL.glUniform1i(OpenGL.glGetUniformLocation(var7, "sceneTex"), 0);
         OpenGL.glUniform3f(OpenGL.glGetUniformLocation(var7, "params"), G, 0.0F, 0.0F);
         OpenGL.glBegin(7);
         OpenGL.glTexCoord2f(0.0F, 0.0F);
         OpenGL.glVertex2i(0, 0);
         OpenGL.glTexCoord2f(1.0F, 0.0F);
         OpenGL.glVertex2i(1, 0);
         OpenGL.glTexCoord2f(1.0F, 1.0F);
         OpenGL.glVertex2i(1, 1);
         OpenGL.glTexCoord2f(0.0F, 1.0F);
         OpenGL.glVertex2i(0, 1);
         OpenGL.glEnd();
      } else {
         this.S.I((SN)var2);
         this.S.Z(this.glPopAttrib, (byte)-8);
         this.glPopAttrib.C(0);
         OpenGL.glViewport(0, 0, 256, 256);
         var4 = this.glGetUniformLocation.I;
         OpenGL.glUseProgram(var4);
         OpenGL.glUniform1i(OpenGL.glGetUniformLocation(var4, "sceneTex"), 0);
         OpenGL.glUniform3f(OpenGL.glGetUniformLocation(var4, "params"), G, 0.0F, 0.0F);
         OpenGL.glBegin(7);
         OpenGL.glTexCoord2f(0.0F, 0.0F);
         OpenGL.glVertex2i(0, 0);
         OpenGL.glTexCoord2f((float)this.glUniform3f, 0.0F);
         OpenGL.glVertex2i(1, 0);
         OpenGL.glTexCoord2f((float)this.glUniform3f, (float)this.glUniform1i);
         OpenGL.glVertex2i(1, 1);
         OpenGL.glTexCoord2f(0.0F, (float)this.glUniform1i);
         OpenGL.glVertex2i(0, 1);
         OpenGL.glEnd();
      }

      this.glPopAttrib.C(1);
      this.S.I((SN)this.glPopMatrix);
      var4 = this.glVertex2i.I;
      OpenGL.glUseProgram(var4);
      OpenGL.glUniform1i(OpenGL.glGetUniformLocation(var4, "baseTex"), 0);
      OpenGL.glUniform3f(OpenGL.glGetUniformLocation(var4, "step"), 0.00390625F, 0.0F, 0.0F);
      OpenGL.glBegin(7);
      OpenGL.glTexCoord2f(0.0F, 0.0F);
      OpenGL.glVertex2i(0, 0);
      OpenGL.glTexCoord2f(1.0F, 0.0F);
      OpenGL.glVertex2i(1, 0);
      OpenGL.glTexCoord2f(1.0F, 1.0F);
      OpenGL.glVertex2i(1, 1);
      OpenGL.glTexCoord2f(0.0F, 1.0F);
      OpenGL.glVertex2i(0, 1);
      OpenGL.glEnd();
      this.glPopAttrib.C(0);
      this.S.I((SN)this.glPushAttrib);
      OpenGL.glUniform3f(OpenGL.glGetUniformLocation(var4, "step"), 0.0F, 0.00390625F, 0.0F);
      OpenGL.glBegin(7);
      OpenGL.glTexCoord2f(0.0F, 0.0F);
      OpenGL.glVertex2i(0, 0);
      OpenGL.glTexCoord2f(1.0F, 0.0F);
      OpenGL.glVertex2i(1, 0);
      OpenGL.glTexCoord2f(1.0F, 1.0F);
      OpenGL.glVertex2i(1, 1);
      OpenGL.glTexCoord2f(0.0F, 1.0F);
      OpenGL.glVertex2i(0, 1);
      OpenGL.glEnd();
      OpenGL.glPopAttrib();
      OpenGL.glPopMatrix();
      OpenGL.glMatrixMode(5888);
      this.S.I(this.glPopAttrib, (byte)2);
      var5 = this.glTexCoord2f.I;
      OpenGL.glUseProgram(var5);
      OpenGL.glUniform1i(OpenGL.glGetUniformLocation(var5, "sceneTex"), 0);
      OpenGL.glUniform1i(OpenGL.glGetUniformLocation(var5, "bloomTex"), 1);
      OpenGL.glUniform3f(OpenGL.glGetUniformLocation(var5, "params"), A, E, 0.0F);
      this.S.C(1);
      this.S.I((SN)this.glPopMatrix);
      this.S.C(0);
      this.S.I((SN)var2);
   }

   boolean method2882() {
      if (this.S.CI && this.S.R && this.S.n) {
         this.glPopAttrib = new HCI(this.S);
         this.glPopMatrix = new FO(this.S, 3553, YCI.Z, SDI.I, 256, 256);
         this.glPopMatrix.I(false, false);
         this.glPushAttrib = new FO(this.S, 3553, YCI.Z, SDI.I, 256, 256);
         this.glPushAttrib.I(false, false);
         this.S.Z(this.glPopAttrib, (byte)-80);
         this.glPopAttrib.method563(0, this.glPopMatrix.I(0));
         this.glPopAttrib.method563(1, this.glPushAttrib.I(0));
         this.glPopAttrib.C(0);
         if (!this.glPopAttrib.method560()) {
            this.S.I(this.glPopAttrib, (byte)15);
            return false;
         } else {
            this.S.I(this.glPopAttrib, (byte)-37);
            this.glGetUniformLocation = YA.I(this.S, new HII[]{HII.I(this.S, 35632, "#extension GL_ARB_texture_rectangle : enable\nuniform vec3 params;\nuniform sampler2DRect sceneTex;\nconst vec3 lumCoef = vec3(0.2126, 0.7152, 0.0722);\nvoid main() {\n    vec4 col = texture2DRect(sceneTex, gl_TexCoord[0].xy);\n    gl_FragColor = col*step(params.x, dot(lumCoef, col.rgb));\n}\n")});
            this.method560 = YA.I(this.S, new HII[]{HII.I(this.S, 35632, "uniform vec3 params;\nuniform sampler2D sceneTex;\nconst vec3 lumCoef = vec3(0.2126, 0.7152, 0.0722);\nvoid main() {\n    vec4 col = texture2D(sceneTex, gl_TexCoord[0].xy);\n    gl_FragColor = col*step(params.x, dot(lumCoef, col.rgb));\n}\n")});
            this.glTexCoord2f = YA.I(this.S, new HII[]{HII.I(this.S, 35632, "#extension GL_ARB_texture_rectangle : enable\nuniform vec3 params;\nuniform vec3 dimScale;\nuniform sampler2D bloomTex;\nuniform sampler2DRect sceneTex;\nconst vec3 lumCoef = vec3(0.2126, 0.7152, 0.0722);\nvoid main() {\n\t vec4 bloomCol = texture2D(bloomTex, gl_TexCoord[1].xy);\n\t vec4 sceneCol = texture2DRect(sceneTex, gl_TexCoord[0].xy);\n\t float preLum = 0.99*dot(lumCoef, sceneCol.rgb)+0.01;\n    float postLum = preLum*(1.0+(preLum/params.y))/(preLum+1.0);\n\t gl_FragColor = sceneCol*(postLum/preLum)+bloomCol*params.x;\n}\n")});
            this.glVertex2i = YA.I(this.S, new HII[]{HII.I(this.S, 35632, "uniform vec3 step;\nuniform sampler2D baseTex;\nvoid main() {\n\tvec4 fragCol = texture2D(baseTex, gl_TexCoord[0].xy)*0.091396265;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-1.0*step.xy))*0.088584304;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 1.0*step.xy))*0.088584304;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-2.0*step.xy))*0.08065692;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 2.0*step.xy))*0.08065692;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-3.0*step.xy))*0.068989515;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 3.0*step.xy))*0.068989515;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-4.0*step.xy))*0.055434637;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 4.0*step.xy))*0.055434637;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-5.0*step.xy))*0.04184426;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 5.0*step.xy))*0.04184426;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-6.0*step.xy))*0.029672023;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 6.0*step.xy))*0.029672023;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-7.0*step.xy))*0.019765828;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 7.0*step.xy))*0.019765828;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-8.0*step.xy))*0.012369139;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 8.0*step.xy))*0.012369139;\n\tgl_FragColor = fragCol;\n}\n")});
            return this.method560 != null && this.glGetUniformLocation != null && this.glTexCoord2f != null && this.glVertex2i != null;
         }
      } else {
         return false;
      }
   }

   void method2867() {
      this.glUseProgram = -1;
      this.glViewport = -1;
      this.glBegin = null;
      this.method563 = null;
      this.glPopAttrib = null;
      this.glPopMatrix = null;
      this.glPushAttrib = null;
      this.glGetUniformLocation = null;
      this.method560 = null;
      this.glTexCoord2f = null;
      this.glVertex2i = null;
   }

   void method2877(int var1, FO var2, FO var3) {
      OpenGL.glPushAttrib(2048);
      OpenGL.glMatrixMode(5889);
      OpenGL.glPushMatrix();
      OpenGL.glLoadIdentity();
      OpenGL.glOrtho(0.0D, 1.0D, 0.0D, 1.0D, -1.0D, 1.0D);
      int var4;
      int var5;
      if (this.method563 != null) {
         this.S.Z(this.glBegin, (byte)-3);
         var4 = KW.C(this.glUniform3f, 1462499323);
         var5 = KW.C(this.glUniform1i, 1465383629);

         int var6;
         for(var6 = 0; var4 > 256 || var5 > 256; ++var6) {
            OpenGL.glViewport(0, 0, var4, var5);
            this.glBegin.method563(0, this.method563[var6].I(0));
            if (var6 == 0) {
               this.S.I((SN)var2);
               OpenGL.glBegin(7);
               OpenGL.glTexCoord2f(0.0F, 0.0F);
               OpenGL.glVertex2i(0, 0);
               OpenGL.glTexCoord2f((float)this.glUniform3f, 0.0F);
               OpenGL.glVertex2i(1, 0);
               OpenGL.glTexCoord2f((float)this.glUniform3f, (float)this.glUniform1i);
               OpenGL.glVertex2i(1, 1);
               OpenGL.glTexCoord2f(0.0F, (float)this.glUniform1i);
               OpenGL.glVertex2i(0, 1);
               OpenGL.glEnd();
            } else {
               this.S.I((SN)this.method563[var6 - 1]);
               OpenGL.glBegin(7);
               OpenGL.glTexCoord2f(0.0F, 0.0F);
               OpenGL.glVertex2i(0, 0);
               OpenGL.glTexCoord2f(1.0F, 0.0F);
               OpenGL.glVertex2i(1, 0);
               OpenGL.glTexCoord2f(1.0F, 1.0F);
               OpenGL.glVertex2i(1, 1);
               OpenGL.glTexCoord2f(0.0F, 1.0F);
               OpenGL.glVertex2i(0, 1);
               OpenGL.glEnd();
            }

            if (var4 > 256) {
               var4 >>= 1;
            }

            if (var5 > 256) {
               var5 >>= 1;
            }
         }

         this.S.I(this.glBegin, (byte)-15);
         this.S.I((SN)this.method563[var6 - 1]);
         this.S.Z(this.glPopAttrib, (byte)-7);
         this.glPopAttrib.C(0);
         OpenGL.glViewport(0, 0, 256, 256);
         int var7 = this.method560.I;
         OpenGL.glUseProgram(var7);
         OpenGL.glUniform1i(OpenGL.glGetUniformLocation(var7, "sceneTex"), 0);
         OpenGL.glUniform3f(OpenGL.glGetUniformLocation(var7, "params"), G, 0.0F, 0.0F);
         OpenGL.glBegin(7);
         OpenGL.glTexCoord2f(0.0F, 0.0F);
         OpenGL.glVertex2i(0, 0);
         OpenGL.glTexCoord2f(1.0F, 0.0F);
         OpenGL.glVertex2i(1, 0);
         OpenGL.glTexCoord2f(1.0F, 1.0F);
         OpenGL.glVertex2i(1, 1);
         OpenGL.glTexCoord2f(0.0F, 1.0F);
         OpenGL.glVertex2i(0, 1);
         OpenGL.glEnd();
      } else {
         this.S.I((SN)var2);
         this.S.Z(this.glPopAttrib, (byte)-16);
         this.glPopAttrib.C(0);
         OpenGL.glViewport(0, 0, 256, 256);
         var4 = this.glGetUniformLocation.I;
         OpenGL.glUseProgram(var4);
         OpenGL.glUniform1i(OpenGL.glGetUniformLocation(var4, "sceneTex"), 0);
         OpenGL.glUniform3f(OpenGL.glGetUniformLocation(var4, "params"), G, 0.0F, 0.0F);
         OpenGL.glBegin(7);
         OpenGL.glTexCoord2f(0.0F, 0.0F);
         OpenGL.glVertex2i(0, 0);
         OpenGL.glTexCoord2f((float)this.glUniform3f, 0.0F);
         OpenGL.glVertex2i(1, 0);
         OpenGL.glTexCoord2f((float)this.glUniform3f, (float)this.glUniform1i);
         OpenGL.glVertex2i(1, 1);
         OpenGL.glTexCoord2f(0.0F, (float)this.glUniform1i);
         OpenGL.glVertex2i(0, 1);
         OpenGL.glEnd();
      }

      this.glPopAttrib.C(1);
      this.S.I((SN)this.glPopMatrix);
      var4 = this.glVertex2i.I;
      OpenGL.glUseProgram(var4);
      OpenGL.glUniform1i(OpenGL.glGetUniformLocation(var4, "baseTex"), 0);
      OpenGL.glUniform3f(OpenGL.glGetUniformLocation(var4, "step"), 0.00390625F, 0.0F, 0.0F);
      OpenGL.glBegin(7);
      OpenGL.glTexCoord2f(0.0F, 0.0F);
      OpenGL.glVertex2i(0, 0);
      OpenGL.glTexCoord2f(1.0F, 0.0F);
      OpenGL.glVertex2i(1, 0);
      OpenGL.glTexCoord2f(1.0F, 1.0F);
      OpenGL.glVertex2i(1, 1);
      OpenGL.glTexCoord2f(0.0F, 1.0F);
      OpenGL.glVertex2i(0, 1);
      OpenGL.glEnd();
      this.glPopAttrib.C(0);
      this.S.I((SN)this.glPushAttrib);
      OpenGL.glUniform3f(OpenGL.glGetUniformLocation(var4, "step"), 0.0F, 0.00390625F, 0.0F);
      OpenGL.glBegin(7);
      OpenGL.glTexCoord2f(0.0F, 0.0F);
      OpenGL.glVertex2i(0, 0);
      OpenGL.glTexCoord2f(1.0F, 0.0F);
      OpenGL.glVertex2i(1, 0);
      OpenGL.glTexCoord2f(1.0F, 1.0F);
      OpenGL.glVertex2i(1, 1);
      OpenGL.glTexCoord2f(0.0F, 1.0F);
      OpenGL.glVertex2i(0, 1);
      OpenGL.glEnd();
      OpenGL.glPopAttrib();
      OpenGL.glPopMatrix();
      OpenGL.glMatrixMode(5888);
      this.S.I(this.glPopAttrib, (byte)-14);
      var5 = this.glTexCoord2f.I;
      OpenGL.glUseProgram(var5);
      OpenGL.glUniform1i(OpenGL.glGetUniformLocation(var5, "sceneTex"), 0);
      OpenGL.glUniform1i(OpenGL.glGetUniformLocation(var5, "bloomTex"), 1);
      OpenGL.glUniform3f(OpenGL.glGetUniformLocation(var5, "params"), A, E, 0.0F);
      this.S.C(1);
      this.S.I((SN)this.glPopMatrix);
      this.S.C(0);
      this.S.I((SN)var2);
   }

   void method2872(int var1, FO var2, FO var3) {
      OpenGL.glPushAttrib(2048);
      OpenGL.glMatrixMode(5889);
      OpenGL.glPushMatrix();
      OpenGL.glLoadIdentity();
      OpenGL.glOrtho(0.0D, 1.0D, 0.0D, 1.0D, -1.0D, 1.0D);
      int var4;
      int var5;
      if (this.method563 != null) {
         this.S.Z(this.glBegin, (byte)61);
         var4 = KW.C(this.glUniform3f, 1385804775);
         var5 = KW.C(this.glUniform1i, 1199238042);

         int var6;
         for(var6 = 0; var4 > 256 || var5 > 256; ++var6) {
            OpenGL.glViewport(0, 0, var4, var5);
            this.glBegin.method563(0, this.method563[var6].I(0));
            if (var6 == 0) {
               this.S.I((SN)var2);
               OpenGL.glBegin(7);
               OpenGL.glTexCoord2f(0.0F, 0.0F);
               OpenGL.glVertex2i(0, 0);
               OpenGL.glTexCoord2f((float)this.glUniform3f, 0.0F);
               OpenGL.glVertex2i(1, 0);
               OpenGL.glTexCoord2f((float)this.glUniform3f, (float)this.glUniform1i);
               OpenGL.glVertex2i(1, 1);
               OpenGL.glTexCoord2f(0.0F, (float)this.glUniform1i);
               OpenGL.glVertex2i(0, 1);
               OpenGL.glEnd();
            } else {
               this.S.I((SN)this.method563[var6 - 1]);
               OpenGL.glBegin(7);
               OpenGL.glTexCoord2f(0.0F, 0.0F);
               OpenGL.glVertex2i(0, 0);
               OpenGL.glTexCoord2f(1.0F, 0.0F);
               OpenGL.glVertex2i(1, 0);
               OpenGL.glTexCoord2f(1.0F, 1.0F);
               OpenGL.glVertex2i(1, 1);
               OpenGL.glTexCoord2f(0.0F, 1.0F);
               OpenGL.glVertex2i(0, 1);
               OpenGL.glEnd();
            }

            if (var4 > 256) {
               var4 >>= 1;
            }

            if (var5 > 256) {
               var5 >>= 1;
            }
         }

         this.S.I(this.glBegin, (byte)83);
         this.S.I((SN)this.method563[var6 - 1]);
         this.S.Z(this.glPopAttrib, (byte)17);
         this.glPopAttrib.C(0);
         OpenGL.glViewport(0, 0, 256, 256);
         int var7 = this.method560.I;
         OpenGL.glUseProgram(var7);
         OpenGL.glUniform1i(OpenGL.glGetUniformLocation(var7, "sceneTex"), 0);
         OpenGL.glUniform3f(OpenGL.glGetUniformLocation(var7, "params"), G, 0.0F, 0.0F);
         OpenGL.glBegin(7);
         OpenGL.glTexCoord2f(0.0F, 0.0F);
         OpenGL.glVertex2i(0, 0);
         OpenGL.glTexCoord2f(1.0F, 0.0F);
         OpenGL.glVertex2i(1, 0);
         OpenGL.glTexCoord2f(1.0F, 1.0F);
         OpenGL.glVertex2i(1, 1);
         OpenGL.glTexCoord2f(0.0F, 1.0F);
         OpenGL.glVertex2i(0, 1);
         OpenGL.glEnd();
      } else {
         this.S.I((SN)var2);
         this.S.Z(this.glPopAttrib, (byte)-6);
         this.glPopAttrib.C(0);
         OpenGL.glViewport(0, 0, 256, 256);
         var4 = this.glGetUniformLocation.I;
         OpenGL.glUseProgram(var4);
         OpenGL.glUniform1i(OpenGL.glGetUniformLocation(var4, "sceneTex"), 0);
         OpenGL.glUniform3f(OpenGL.glGetUniformLocation(var4, "params"), G, 0.0F, 0.0F);
         OpenGL.glBegin(7);
         OpenGL.glTexCoord2f(0.0F, 0.0F);
         OpenGL.glVertex2i(0, 0);
         OpenGL.glTexCoord2f((float)this.glUniform3f, 0.0F);
         OpenGL.glVertex2i(1, 0);
         OpenGL.glTexCoord2f((float)this.glUniform3f, (float)this.glUniform1i);
         OpenGL.glVertex2i(1, 1);
         OpenGL.glTexCoord2f(0.0F, (float)this.glUniform1i);
         OpenGL.glVertex2i(0, 1);
         OpenGL.glEnd();
      }

      this.glPopAttrib.C(1);
      this.S.I((SN)this.glPopMatrix);
      var4 = this.glVertex2i.I;
      OpenGL.glUseProgram(var4);
      OpenGL.glUniform1i(OpenGL.glGetUniformLocation(var4, "baseTex"), 0);
      OpenGL.glUniform3f(OpenGL.glGetUniformLocation(var4, "step"), 0.00390625F, 0.0F, 0.0F);
      OpenGL.glBegin(7);
      OpenGL.glTexCoord2f(0.0F, 0.0F);
      OpenGL.glVertex2i(0, 0);
      OpenGL.glTexCoord2f(1.0F, 0.0F);
      OpenGL.glVertex2i(1, 0);
      OpenGL.glTexCoord2f(1.0F, 1.0F);
      OpenGL.glVertex2i(1, 1);
      OpenGL.glTexCoord2f(0.0F, 1.0F);
      OpenGL.glVertex2i(0, 1);
      OpenGL.glEnd();
      this.glPopAttrib.C(0);
      this.S.I((SN)this.glPushAttrib);
      OpenGL.glUniform3f(OpenGL.glGetUniformLocation(var4, "step"), 0.0F, 0.00390625F, 0.0F);
      OpenGL.glBegin(7);
      OpenGL.glTexCoord2f(0.0F, 0.0F);
      OpenGL.glVertex2i(0, 0);
      OpenGL.glTexCoord2f(1.0F, 0.0F);
      OpenGL.glVertex2i(1, 0);
      OpenGL.glTexCoord2f(1.0F, 1.0F);
      OpenGL.glVertex2i(1, 1);
      OpenGL.glTexCoord2f(0.0F, 1.0F);
      OpenGL.glVertex2i(0, 1);
      OpenGL.glEnd();
      OpenGL.glPopAttrib();
      OpenGL.glPopMatrix();
      OpenGL.glMatrixMode(5888);
      this.S.I(this.glPopAttrib, (byte)-116);
      var5 = this.glTexCoord2f.I;
      OpenGL.glUseProgram(var5);
      OpenGL.glUniform1i(OpenGL.glGetUniformLocation(var5, "sceneTex"), 0);
      OpenGL.glUniform1i(OpenGL.glGetUniformLocation(var5, "bloomTex"), 1);
      OpenGL.glUniform3f(OpenGL.glGetUniformLocation(var5, "params"), A, E, 0.0F);
      this.S.C(1);
      this.S.I((SN)this.glPopMatrix);
      this.S.C(0);
      this.S.I((SN)var2);
   }

   void method2879(int var1) {
      OpenGL.glUseProgram(0);
      this.S.C(1);
      this.S.I((SN)null);
      this.S.C(0);
   }

   void method2880(int var1) {
      OpenGL.glUseProgram(0);
      this.S.C(1);
      this.S.I((SN)null);
      this.S.C(0);
   }

   boolean method2876() {
      if (this.S.CI && this.S.R && this.S.n) {
         this.glPopAttrib = new HCI(this.S);
         this.glPopMatrix = new FO(this.S, 3553, YCI.Z, SDI.I, 256, 256);
         this.glPopMatrix.I(false, false);
         this.glPushAttrib = new FO(this.S, 3553, YCI.Z, SDI.I, 256, 256);
         this.glPushAttrib.I(false, false);
         this.S.Z(this.glPopAttrib, (byte)8);
         this.glPopAttrib.method563(0, this.glPopMatrix.I(0));
         this.glPopAttrib.method563(1, this.glPushAttrib.I(0));
         this.glPopAttrib.C(0);
         if (!this.glPopAttrib.method560()) {
            this.S.I(this.glPopAttrib, (byte)-42);
            return false;
         } else {
            this.S.I(this.glPopAttrib, (byte)12);
            this.glGetUniformLocation = YA.I(this.S, new HII[]{HII.I(this.S, 35632, "#extension GL_ARB_texture_rectangle : enable\nuniform vec3 params;\nuniform sampler2DRect sceneTex;\nconst vec3 lumCoef = vec3(0.2126, 0.7152, 0.0722);\nvoid main() {\n    vec4 col = texture2DRect(sceneTex, gl_TexCoord[0].xy);\n    gl_FragColor = col*step(params.x, dot(lumCoef, col.rgb));\n}\n")});
            this.method560 = YA.I(this.S, new HII[]{HII.I(this.S, 35632, "uniform vec3 params;\nuniform sampler2D sceneTex;\nconst vec3 lumCoef = vec3(0.2126, 0.7152, 0.0722);\nvoid main() {\n    vec4 col = texture2D(sceneTex, gl_TexCoord[0].xy);\n    gl_FragColor = col*step(params.x, dot(lumCoef, col.rgb));\n}\n")});
            this.glTexCoord2f = YA.I(this.S, new HII[]{HII.I(this.S, 35632, "#extension GL_ARB_texture_rectangle : enable\nuniform vec3 params;\nuniform vec3 dimScale;\nuniform sampler2D bloomTex;\nuniform sampler2DRect sceneTex;\nconst vec3 lumCoef = vec3(0.2126, 0.7152, 0.0722);\nvoid main() {\n\t vec4 bloomCol = texture2D(bloomTex, gl_TexCoord[1].xy);\n\t vec4 sceneCol = texture2DRect(sceneTex, gl_TexCoord[0].xy);\n\t float preLum = 0.99*dot(lumCoef, sceneCol.rgb)+0.01;\n    float postLum = preLum*(1.0+(preLum/params.y))/(preLum+1.0);\n\t gl_FragColor = sceneCol*(postLum/preLum)+bloomCol*params.x;\n}\n")});
            this.glVertex2i = YA.I(this.S, new HII[]{HII.I(this.S, 35632, "uniform vec3 step;\nuniform sampler2D baseTex;\nvoid main() {\n\tvec4 fragCol = texture2D(baseTex, gl_TexCoord[0].xy)*0.091396265;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-1.0*step.xy))*0.088584304;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 1.0*step.xy))*0.088584304;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-2.0*step.xy))*0.08065692;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 2.0*step.xy))*0.08065692;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-3.0*step.xy))*0.068989515;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 3.0*step.xy))*0.068989515;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-4.0*step.xy))*0.055434637;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 4.0*step.xy))*0.055434637;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-5.0*step.xy))*0.04184426;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 5.0*step.xy))*0.04184426;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-6.0*step.xy))*0.029672023;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 6.0*step.xy))*0.029672023;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-7.0*step.xy))*0.019765828;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 7.0*step.xy))*0.019765828;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+(-8.0*step.xy))*0.012369139;\n\tfragCol += texture2D(baseTex, gl_TexCoord[0].xy+( 8.0*step.xy))*0.012369139;\n\tgl_FragColor = fragCol;\n}\n")});
            return this.method560 != null && this.glGetUniformLocation != null && this.glTexCoord2f != null && this.glVertex2i != null;
         }
      } else {
         return false;
      }
   }

   SDI glGetUniformLocation() {
      return SDI.I;
   }

   BN(MJI var1) {
      super(var1);
   }

   void method2885(int var1, int var2) {
      this.glUniform3f = var1;
      this.glUniform1i = var2;
      int var3 = KW.C(this.glUniform3f, 1657798261);
      int var4 = KW.C(this.glUniform1i, 1091426304);
      if (this.glViewport != var3 || this.glUseProgram != var4) {
         int var5;
         if (this.method563 != null) {
            for(var5 = 0; var5 < this.method563.length; ++var5) {
               this.method563[var5].I();
            }

            this.method563 = null;
         }

         if (var3 <= 256 && var4 <= 256) {
            this.glBegin = null;
         } else {
            var5 = var3;
            int var6 = var4;
            int var7 = 0;

            label59:
            while(true) {
               if (var5 <= 256 && var6 <= 256) {
                  if (this.glBegin == null) {
                     this.glBegin = new HCI(this.S);
                  }

                  this.method563 = new FO[var7];
                  var5 = var3;
                  var6 = var4;
                  var7 = 0;

                  while(true) {
                     if (var5 <= 256 && var6 <= 256) {
                        break label59;
                     }

                     this.method563[var7++] = new FO(this.S, 3553, YCI.Z, SDI.I, var5, var6);
                     if (var5 > 256) {
                        var5 >>= 1;
                     }

                     if (var6 > 256) {
                        var6 >>= 1;
                     }
                  }
               }

               if (var5 > 256) {
                  var5 >>= 1;
               }

               if (var6 > 256) {
                  var6 >>= 1;
               }

               ++var7;
            }
         }

         this.glViewport = var3;
         this.glUseProgram = var4;
      }

   }

   boolean D() {
      return this.S.CI && this.S.R && this.S.n;
   }
}
