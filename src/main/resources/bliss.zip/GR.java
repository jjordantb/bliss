public abstract class GR extends IR {
   protected short O;
   protected short P;
   public static CS Q;

   final boolean method4384() {
      return false;
   }

   int method4354(GE[] var1, int var2) {
      try {
         SF var3 = this.I().I;
         return this.I((int)var3.I >> -1688804109 * this.H.I, (int)var3.Z >> -1688804109 * this.H.I, var1, 1820308449);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aji.dg(" + ')');
      }
   }

   final void method4378() {
      throw new IllegalStateException();
   }

   final boolean method4400() {
      return false;
   }

   final boolean method4366(int var1) {
      return false;
   }

   final void method4388(GSI var1, IR var2, int var3, int var4, int var5, boolean var6) {
      throw new IllegalStateException();
   }

   final void method4398(byte var1) {
      try {
         throw new IllegalStateException();
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aji.bq(" + ')');
      }
   }

   final void method4375(GSI var1, IR var2, int var3, int var4, int var5, boolean var6) {
      throw new IllegalStateException();
   }

   int method4390(GE[] var1) {
      SF var2 = this.I().I;
      return this.I((int)var2.I >> -1688804109 * this.H.I, (int)var2.Z >> -1688804109 * this.H.I, var1, 2077103831);
   }

   final void method4377() {
      throw new IllegalStateException();
   }

   GR(AP var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      super(var1);
      this.K = (byte)var5;
      this.L = (byte)var6;
      this.O = (short)var7;
      this.P = (short)var8;
      this.I(new SF((float)var2, (float)var3, (float)var4));
   }

   boolean method4359(GSI var1) {
      SF var2 = this.I().I;
      return this.H.D.Z(this.L, (int)var2.I >> this.H.I * -1688804109, (int)var2.Z >> this.H.I * -1688804109, this.method4361(1951240662));
   }

   final void method4355(GSI var1, IR var2, int var3, int var4, int var5, boolean var6, int var7) {
      try {
         throw new IllegalStateException();
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "aji.bk(" + ')');
      }
   }

   final boolean method4386() {
      return false;
   }

   final boolean method4387() {
      return false;
   }

   boolean method4364(GSI var1, byte var2) {
      try {
         SF var3 = this.I().I;
         return this.H.D.Z(this.L, (int)var3.I >> this.H.I * -1688804109, (int)var3.Z >> this.H.I * -1688804109, this.method4361(1951240662));
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "aji.dl(" + ')');
      }
   }

   boolean method4391(GSI var1) {
      SF var2 = this.I().I;
      return this.H.D.Z(this.L, (int)var2.I >> this.H.I * -1688804109, (int)var2.Z >> this.H.I * -1688804109, this.method4361(1951240662));
   }

   boolean method4397() {
      SF var1 = this.I().I;
      return this.H.d[583010427 * this.H.Q + (((int)var1.I >> -1688804109 * this.H.I) - -804213305 * this.H.z)][((int)var1.Z >> -1688804109 * this.H.I) - this.H.J * 465603579 + 583010427 * this.H.Q];
   }

   boolean method4393(GSI var1) {
      SF var2 = this.I().I;
      return this.H.D.Z(this.L, (int)var2.I >> this.H.I * -1688804109, (int)var2.Z >> this.H.I * -1688804109, this.method4361(1951240662));
   }

   boolean method4389(GSI var1) {
      SF var2 = this.I().I;
      return this.H.D.Z(this.L, (int)var2.I >> this.H.I * -1688804109, (int)var2.Z >> this.H.I * -1688804109, this.method4361(1951240662));
   }

   boolean method4395() {
      SF var1 = this.I().I;
      return this.H.d[583010427 * this.H.Q + (((int)var1.I >> -1688804109 * this.H.I) - -804213305 * this.H.z)][((int)var1.Z >> -1688804109 * this.H.I) - this.H.J * 465603579 + 583010427 * this.H.Q];
   }

   boolean method4396() {
      SF var1 = this.I().I;
      return this.H.d[583010427 * this.H.Q + (((int)var1.I >> -1688804109 * this.H.I) - -804213305 * this.H.z)][((int)var1.Z >> -1688804109 * this.H.I) - this.H.J * 465603579 + 583010427 * this.H.Q];
   }

   boolean method4360(int var1) {
      try {
         SF var2 = this.I().I;
         return this.H.d[583010427 * this.H.Q + (((int)var2.I >> -1688804109 * this.H.I) - -804213305 * this.H.z)][((int)var2.Z >> -1688804109 * this.H.I) - this.H.J * 465603579 + 583010427 * this.H.Q];
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aji.dq(" + ')');
      }
   }
}
