import jagdx.IDirect3DDevice;
import jagdx.IUnknown;

public class DD implements YAI {
   int CreateDepthStencilSurface;
   SDI Release;
   int I;
   PJI Z;
   long C;

   public int f() {
      return this.CreateDepthStencilSurface;
   }

   public int a() {
      return this.I;
   }

   public long method144() {
      return this.C;
   }

   public void b() {
      if (this.C != 0L) {
         IUnknown.Release(this.C);
         this.C = 0L;
      }

      this.Z.I((QAI)this);
   }

   public void method141() {
      if (this.C != 0L) {
         this.Z.Z(this.C);
         this.C = 0L;
      }

   }

   public void x() {
      if (this.C != 0L) {
         IUnknown.Release(this.C);
         this.C = 0L;
      }

      this.Z.I((QAI)this);
   }

   public void method142() {
      if (this.C != 0L) {
         this.Z.Z(this.C);
         this.C = 0L;
      }

   }

   public int i() {
      return this.I;
   }

   public int k() {
      return this.CreateDepthStencilSurface;
   }

   DD(PJI var1, SDI var2, int var3, int var4) {
      this.Z = var1;
      this.I = var3;
      this.CreateDepthStencilSurface = var4;
      this.Release = var2;
      this.C = IDirect3DDevice.CreateDepthStencilSurface(this.Z.FZ, var3, var4, PJI.I(this.Release), 0, 0, false);
      this.Z.Z(this);
   }

   public void d() {
      if (this.C != 0L) {
         IUnknown.Release(this.C);
         this.C = 0L;
      }

      this.Z.I((QAI)this);
   }

   public long method147() {
      return this.C;
   }

   public long method145() {
      return this.C;
   }

   public int p() {
      return this.I;
   }

   public void method146() {
      if (this.C != 0L) {
         this.Z.Z(this.C);
         this.C = 0L;
      }

   }

   public void method143() {
      if (this.C != 0L) {
         this.Z.Z(this.C);
         this.C = 0L;
      }

   }

   public void u() {
      if (this.C != 0L) {
         IUnknown.Release(this.C);
         this.C = 0L;
      }

      this.Z.I((QAI)this);
   }

   public void method148() {
      if (this.C != 0L) {
         this.Z.Z(this.C);
         this.C = 0L;
      }

   }
}
