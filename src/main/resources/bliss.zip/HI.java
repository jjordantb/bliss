public class HI extends GI {
   void I(int var1, int var2, int var3, int var4, int var5) {
      try {
         int var6 = this.D.method271();
         int var7 = ((QI)this.C).O * 851871347 * DDI.I(1139144319) / 10 % var6;
         this.D.Z(var7 + (var1 - var6), var2, var6 + var3 - var7, var4);
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "afw.c(" + ')');
      }
   }

   void I(int var1, int var2, int var3, int var4) {
      int var5 = this.D.method271();
      int var6 = ((QI)this.C).O * 851871347 * DDI.I(1139144319) / 10 % var5;
      this.D.Z(var6 + (var1 - var5), var2, var5 + var3 - var6, var4);
   }

   void append(int var1, int var2, int var3, int var4) {
      int var5 = this.D.method271();
      int var6 = ((QI)this.C).O * 851871347 * DDI.I(1139144319) / 10 % var5;
      this.D.Z(var6 + (var1 - var5), var2, var5 + var3 - var6, var4);
   }

   HI(KJ var1, KJ var2, QI var3) {
      super(var1, var2, var3);
   }
}
