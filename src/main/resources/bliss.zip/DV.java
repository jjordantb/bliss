public class DV {
   static KU I;

   DV() throws Throwable {
      throw new Error();
   }

   static final void I(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var0.R.J;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "re.xf(" + ')');
      }
   }
}
