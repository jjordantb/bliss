import java.io.FileOutputStream;

public class ADI {
   public int I;
   public int Z;
   public int C;
   int LOBBY_ENABLED;
   public int B;
   public int D;
   static FileOutputStream F;
   public int J;
   protected static int S;

   public ADI(int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      this.Z = 614121861 * var1;
      this.I = -885436027 * var2;
      this.C = var3 * 399458545;
      this.LOBBY_ENABLED = var4 * -2122084815;
      this.B = 1507836083 * var5;
      this.D = var6 * -1927451111;
      this.J = -875460563 * var7;
   }

   public boolean I(ADI var1, byte var2) {
      try {
         return var1.Z * -1212608691 == -1212608691 * this.Z && 1996750669 * var1.I == this.I * 1996750669 && this.C * -1475891183 == -1475891183 * var1.C && this.LOBBY_ENABLED * -1761932591 == var1.LOBBY_ENABLED * -1761932591 && this.B * -28774789 == -28774789 * var1.B && 484707881 * this.D == 484707881 * var1.D && var1.J * -1637742683 == this.J * -1637742683;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "dd.a(" + ')');
      }
   }

   public ADI() {
   }

   static boolean I(byte var0) {
      try {
         boolean var1;
         try {
            ZCI var2 = new ZCI();
            byte[] var3 = var2.I((byte[])TF.Z, (short)23578);
            MF.I(var3, -161656424);
            var1 = true;
         } catch (Exception var4) {
            return false;
         }

         return var1;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "dd.p(" + ')');
      }
   }

   static void I(int var0, int var1) {
      try {
         if (Loader.LOBBY_ENABLED && 136 != TQ.Z * -122629167) {
            if (Loader.LOBBY_ENABLED && 264 == TQ.Z * -122629167) {
               TQ.B = var0 * -1653306319;
            }
         } else {
            TQ.P = var0 * -1674285757;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "dd.j(" + ')');
      }
   }

   static final void I(OU var0, short var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = XEI.kC[var2];
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "dd.tr(" + ')');
      }
   }
}
