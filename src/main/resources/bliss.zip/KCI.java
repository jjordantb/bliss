public abstract class KCI extends ECI {
   NJI C;

   boolean method136() {
      this.C.E();
      return true;
   }

   boolean method134() {
      this.C.E();
      return true;
   }

   KCI(NJI var1) {
      this.C = var1;
   }

   void I() {
      if (this == this.C.I((short)-23826)) {
         this.C.F();
      }

   }
}
