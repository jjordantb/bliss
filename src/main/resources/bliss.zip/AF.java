public final class AF {
   static int append;
   float I;
   static int cos;
   static AF[] sin = new AF[0];
   float Z;
   float C;
   float B;

   static {
      new AF();
   }

   public String toString() {
      return this.Z + "," + this.I + "," + this.C + "," + this.B;
   }

   public static AF I() {
      AF[] var0 = sin;
      synchronized(sin) {
         AF var1;
         if (cos == 0) {
            var1 = new AF();
            return var1;
         } else {
            sin[--cos].cos();
            var1 = sin[cos];
            return var1;
         }
      }
   }

   static AF I(float var0, float var1, float var2, float var3) {
      AF[] var4 = sin;
      synchronized(sin) {
         AF var5;
         if (cos == 0) {
            var5 = new AF(var0, var1, var2, var3);
            return var5;
         } else {
            sin[--cos].append(var0, var1, var2, var3);
            var5 = sin[cos];
            return var5;
         }
      }
   }

   public AF() {
      this.cos();
   }

   AF(float var1, float var2, float var3, float var4) {
      this.append(var1, var2, var3, var4);
   }

   AF(AF var1) {
      this.I(var1);
   }

   void append(float var1, float var2, float var3, float var4) {
      this.Z = var1;
      this.I = var2;
      this.C = var3;
      this.B = var4;
   }

   public void I(AF var1) {
      this.Z = var1.Z;
      this.I = var1.I;
      this.C = var1.C;
      this.B = var1.B;
   }

   public void Z(float var1, float var2, float var3, float var4) {
      float var5 = (float)Math.sin((double)(var4 * 0.5F));
      float var6 = (float)Math.cos((double)(var4 * 0.5F));
      this.Z = var1 * var5;
      this.I = var2 * var5;
      this.C = var3 * var5;
      this.B = var6;
   }

   final void Z() {
      this.Z = -this.Z;
      this.I = -this.I;
      this.C = -this.C;
   }

   static final AF Z(AF var0) {
      AF var1 = sin(var0);
      var1.Z();
      return var1;
   }

   public final void C(AF var1) {
      this.append(var1.B * this.Z + var1.Z * this.B + var1.I * this.C - var1.C * this.I, var1.B * this.I - var1.Z * this.C + var1.I * this.B + var1.C * this.Z, var1.B * this.C + var1.Z * this.I - var1.I * this.Z + var1.C * this.B, var1.B * this.B - var1.Z * this.Z - var1.I * this.I - var1.C * this.C);
   }

   public static void I(int var0) {
      append = var0;
      sin = new AF[var0];
      cos = 0;
   }

   static final AF I(AF var0, AF var1) {
      AF var2 = sin(var0);
      var2.C(var1);
      return var2;
   }

   public void C() {
      AF[] var1 = sin;
      synchronized(sin) {
         if (cos < append - 1) {
            sin[cos++] = this;
         }

      }
   }

   final void cos() {
      this.C = 0.0F;
      this.I = 0.0F;
      this.Z = 0.0F;
      this.B = 1.0F;
   }

   static AF sin(AF var0) {
      AF[] var1 = sin;
      synchronized(sin) {
         AF var2;
         if (cos == 0) {
            var2 = new AF(var0);
            return var2;
         } else {
            sin[--cos].I(var0);
            var2 = sin[cos];
            return var2;
         }
      }
   }

   public void I(float var1, float var2, float var3) {
      this.Z(0.0F, 1.0F, 0.0F, var1);
      AF var4 = I();
      var4.Z(1.0F, 0.0F, 0.0F, var2);
      this.C(var4);
      var4.Z(0.0F, 0.0F, 1.0F, var3);
      this.C(var4);
      var4.C();
   }
}
