import jaggl.OpenGL;

public class KX {
   int Z;
   int glLoadIdentity;
   int I;
   CSI glMatrixMode;
   byte[] C;
   MJI glScalef;
   int glTranslatef;
   int B;
   EO[][] D;

   void I() {
      this.D = new EO[this.glLoadIdentity][this.glTranslatef];

      for(int var1 = 0; var1 < this.glTranslatef; ++var1) {
         for(int var2 = 0; var2 < this.glLoadIdentity; ++var2) {
            this.D[var2][var1] = new EO(this.glScalef, this, this.glMatrixMode, var2, var1, this.B, var2 * 128 + 1, var1 * 128 + 1);
         }
      }

   }

   void I(int var1, int var2, int var3, boolean[][] var4, boolean var5) {
      this.glScalef.Z(false);
      this.glScalef.D(false);
      this.glScalef.F(-2);
      this.glScalef.I(1);
      this.glScalef.B(1);
      float var6 = 1.0F / (float)(this.glScalef.G * 128);
      int var7;
      int var8;
      int var9;
      int var10;
      int var11;
      int var12;
      int var13;
      if (var5) {
         for(var7 = 0; var7 < this.glTranslatef; ++var7) {
            var8 = var7 << this.B;
            var9 = var7 + 1 << this.B;

            label128:
            for(var10 = 0; var10 < this.glLoadIdentity; ++var10) {
               var11 = var10 << this.B;
               var12 = var10 + 1 << this.B;

               for(var13 = var11; var13 < var12; ++var13) {
                  if (var13 - var1 >= -var3 && var13 - var1 <= var3) {
                     for(int var14 = var8; var14 < var9; ++var14) {
                        if (var14 - var2 >= -var3 && var14 - var2 <= var3 && var4[var13 - var1 + var3][var14 - var2 + var3]) {
                           OpenGL.glMatrixMode(5890);
                           OpenGL.glLoadIdentity();
                           OpenGL.glScalef(var6, var6, 1.0F);
                           OpenGL.glTranslatef((float)(-var10) / var6, (float)(-var7) / var6, 1.0F);
                           OpenGL.glMatrixMode(5888);
                           this.D[var10][var7].I();
                           continue label128;
                        }
                     }
                  }
               }
            }
         }
      } else {
         for(var7 = 0; var7 < this.glTranslatef; ++var7) {
            var8 = var7 << this.B;
            var9 = var7 + 1 << this.B;

            for(var10 = 0; var10 < this.glLoadIdentity; ++var10) {
               var11 = 0;
               var12 = var10 << this.B;
               var13 = var10 + 1 << this.B;
               TEI var20 = this.glScalef.iI;
               var20.A = 0;

               for(int var15 = var8; var15 < var9; ++var15) {
                  if (var15 - var2 >= -var3 && var15 - var2 <= var3) {
                     int var16 = var15 * this.glMatrixMode.Z * -506105871 + var12;

                     for(int var17 = var12; var17 < var13; ++var17) {
                        if (var17 - var1 >= -var3 && var17 - var1 <= var3 && var4[var17 - var1 + var3][var15 - var2 + var3]) {
                           short[] var18 = this.glMatrixMode.X[var16];
                           if (var18 != null) {
                              int var19;
                              if (this.glScalef.u) {
                                 for(var19 = 0; var19 < var18.length; ++var19) {
                                    var20.Z(var18[var19] & '\uffff', 16711935);
                                    ++var11;
                                 }
                              } else {
                                 for(var19 = 0; var19 < var18.length; ++var19) {
                                    var20.C(var18[var19] & '\uffff', 1368367793);
                                    ++var11;
                                 }
                              }
                           }
                        }

                        ++var16;
                     }
                  }
               }

               if (var11 > 0) {
                  OpenGL.glMatrixMode(5890);
                  OpenGL.glLoadIdentity();
                  OpenGL.glScalef(var6, var6, 1.0F);
                  OpenGL.glTranslatef((float)(-var10) / var6, (float)(-var7) / var6, 1.0F);
                  OpenGL.glMatrixMode(5888);
                  this.D[var10][var7].I(var20.S, var11);
               }
            }
         }
      }

      OpenGL.glMatrixMode(5890);
      OpenGL.glLoadIdentity();
      OpenGL.glMatrixMode(5888);
   }

   void I(GJI var1, int var2, int var3) {
      HJI var4 = (HJI)var1;
      var2 += var4.H + 1;
      var3 += var4.M + 1;
      int var5 = var2 + var3 * this.I;
      int var6 = 0;
      int var7 = var4.L;
      int var8 = var4.K;
      int var9 = this.I - var8;
      int var10 = 0;
      int var11;
      if (var3 <= 0) {
         var11 = 1 - var3;
         var7 -= var11;
         var6 += var11 * var8;
         var5 += var11 * this.I;
         var3 = 1;
      }

      if (var3 + var7 >= this.Z) {
         var11 = var3 + var7 + 1 - this.Z;
         var7 -= var11;
      }

      if (var2 <= 0) {
         var11 = 1 - var2;
         var8 -= var11;
         var6 += var11;
         var5 += var11;
         var10 += var11;
         var9 += var11;
         var2 = 1;
      }

      if (var2 + var8 >= this.I) {
         var11 = var2 + var8 + 1 - this.I;
         var8 -= var11;
         var10 += var11;
         var9 += var11;
      }

      if (var8 > 0 && var7 > 0) {
         glLoadIdentity(this.C, var4.N, var6, var5, var8, var7, var9, var10);
         this.glScalef(var2, var3, var8, var7);
      }

   }

   boolean Z(GJI var1, int var2, int var3) {
      HJI var4 = (HJI)var1;
      var2 += var4.H + 1;
      var3 += var4.M + 1;
      int var5 = var2 + var3 * this.I;
      int var6 = var4.L;
      int var7 = var4.K;
      int var8 = this.I - var7;
      int var9;
      if (var3 <= 0) {
         var9 = 1 - var3;
         var6 -= var9;
         var5 += var9 * this.I;
         var3 = 1;
      }

      if (var3 + var6 >= this.Z) {
         var9 = var3 + var6 + 1 - this.Z;
         var6 -= var9;
      }

      if (var2 <= 0) {
         var9 = 1 - var2;
         var7 -= var9;
         var5 += var9;
         var8 += var9;
         var2 = 1;
      }

      if (var2 + var7 >= this.I) {
         var9 = var2 + var7 + 1 - this.I;
         var7 -= var9;
         var8 += var9;
      }

      if (var7 > 0 && var6 > 0) {
         byte var10 = 8;
         var8 += (var10 - 1) * this.I;
         return glMatrixMode(this.C, var5, var7, var6, var8, var10);
      } else {
         return false;
      }
   }

   KX(MJI var1, CSI var2) {
      this.glScalef = var1;
      this.glMatrixMode = var2;
      this.I = 2 + (this.glMatrixMode.Z * -506105871 * this.glMatrixMode.C * -1212653763 >> this.glScalef.H);
      this.Z = 2 + (this.glMatrixMode.I * -1148794921 * this.glMatrixMode.C * -1212653763 >> this.glScalef.H);
      this.C = new byte[this.I * this.Z];
      this.B = 7 + this.glScalef.H - this.glMatrixMode.B * -2137349879;
      this.glLoadIdentity = this.glMatrixMode.Z * -506105871 >> this.B;
      this.glTranslatef = this.glMatrixMode.I * -1148794921 >> this.B;
   }

   static final void Z(byte[] var0, byte[] var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      int var8 = -(var4 >> 2);
      var4 = -(var4 & 3);

      for(int var9 = -var5; var9 < 0; ++var9) {
         int var10001;
         int var10;
         for(var10 = var8; var10 < 0; ++var10) {
            var10001 = var3++;
            var0[var10001] += var1[var2++];
            var10001 = var3++;
            var0[var10001] += var1[var2++];
            var10001 = var3++;
            var0[var10001] += var1[var2++];
            var10001 = var3++;
            var0[var10001] += var1[var2++];
         }

         for(var10 = var4; var10 < 0; ++var10) {
            var10001 = var3++;
            var0[var10001] += var1[var2++];
         }

         var3 += var6;
         var2 += var7;
      }

   }

   static final void glLoadIdentity(byte[] var0, byte[] var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      int var8 = -(var4 >> 2);
      var4 = -(var4 & 3);

      for(int var9 = -var5; var9 < 0; ++var9) {
         int var10001;
         int var10;
         for(var10 = var8; var10 < 0; ++var10) {
            var10001 = var3++;
            var0[var10001] -= var1[var2++];
            var10001 = var3++;
            var0[var10001] -= var1[var2++];
            var10001 = var3++;
            var0[var10001] -= var1[var2++];
            var10001 = var3++;
            var0[var10001] -= var1[var2++];
         }

         for(var10 = var4; var10 < 0; ++var10) {
            var10001 = var3++;
            var0[var10001] -= var1[var2++];
         }

         var3 += var6;
         var2 += var7;
      }

   }

   static final boolean glMatrixMode(byte[] var0, int var1, int var2, int var3, int var4, int var5) {
      int var6 = var2 % var5;
      int var7;
      if (var6 != 0) {
         var7 = var5 - var6;
      } else {
         var7 = 0;
      }

      int var8 = -((var3 + var5 - 1) / var5);
      int var9 = -((var2 + var5 - 1) / var5);

      for(int var10 = var8; var10 < 0; ++var10) {
         for(int var11 = var9; var11 < 0; ++var11) {
            if (var0[var1] == 0) {
               return true;
            }

            var1 += var5;
         }

         var1 -= var7;
         if (var0[var1 - 1] == 0) {
            return true;
         }

         var1 += var4;
      }

      return false;
   }

   void C(GJI var1, int var2, int var3) {
      HJI var4 = (HJI)var1;
      var2 += var4.H + 1;
      var3 += var4.M + 1;
      int var5 = var2 + var3 * this.I;
      int var6 = 0;
      int var7 = var4.L;
      int var8 = var4.K;
      int var9 = this.I - var8;
      int var10 = 0;
      int var11;
      if (var3 <= 0) {
         var11 = 1 - var3;
         var7 -= var11;
         var6 += var11 * var8;
         var5 += var11 * this.I;
         var3 = 1;
      }

      if (var3 + var7 >= this.Z) {
         var11 = var3 + var7 + 1 - this.Z;
         var7 -= var11;
      }

      if (var2 <= 0) {
         var11 = 1 - var2;
         var8 -= var11;
         var6 += var11;
         var5 += var11;
         var10 += var11;
         var9 += var11;
         var2 = 1;
      }

      if (var2 + var8 >= this.I) {
         var11 = var2 + var8 + 1 - this.I;
         var8 -= var11;
         var10 += var11;
         var9 += var11;
      }

      if (var8 > 0 && var7 > 0) {
         Z(this.C, var4.N, var6, var5, var8, var7, var9, var10);
         this.glScalef(var2, var3, var8, var7);
      }

   }

   void glScalef(int var1, int var2, int var3, int var4) {
      if (this.D != null) {
         int var5 = var1 - 1 >> 7;
         int var6 = var1 - 1 + var3 - 1 >> 7;
         int var7 = var2 - 1 >> 7;
         int var8 = var2 - 1 + var4 - 1 >> 7;

         for(int var9 = var5; var9 <= var6; ++var9) {
            EO[] var10 = this.D[var9];

            for(int var11 = var7; var11 <= var8; ++var11) {
               var10[var11].F = true;
            }
         }
      }

   }
}
