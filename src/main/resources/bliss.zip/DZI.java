public class DZI {
   char LOBBY_ENABLED;
   public int I;
   public String Z;
   public boolean C = true;
   public static KJ B;
   public static KJ D;
   public static BD F;
   protected static OII[] J;

   void I(REI var1, int var2) {
      try {
         while(true) {
            int var3 = var1.I();
            if (var3 == 0) {
               return;
            }

            this.LOBBY_ENABLED(var1, var3, -1263021902);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "um.a(" + ')');
      }
   }

   void LOBBY_ENABLED(REI var1, int var2, int var3) {
      try {
         if (1 == var2) {
            this.LOBBY_ENABLED = IZI.I(var1.S(-12558881), 1872893689);
         } else if (2 == var2) {
            this.I = var1.H((byte)-43) * -954052725;
         } else if (var2 == 4) {
            this.C = false;
         } else if (var2 == 5) {
            this.Z = var1.E(-1509093879);
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "um.f(" + ')');
      }
   }

   public boolean I(int var1) {
      try {
         return this.LOBBY_ENABLED == 's';
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "um.b(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         FW.J.I(FW.J.g, var0.H[(var0.J -= -391880689) * 681479919], -1529967366);
         JN.I(656179282);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "um.aiv(" + ')');
      }
   }

   static void I(String var0, String var1, int var2) {
      try {
         TQ.Z = Loader.LOBBY_ENABLED ? -1058684408 : 471358088;
         TQ.d = Loader.LOBBY_ENABLED ? XEI.TI : XEI.eI;
         AY.I(false, false, var0, var1, -1L);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "um.z(" + ')');
      }
   }
}
