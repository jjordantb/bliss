public class CL extends IL {
   int L;
   static int append = 1;
   static int toString = 3;
   static int M = 2;
   FP N;
   byte[] O;

   byte[] method3469() {
      if (this.G) {
         throw new RuntimeException();
      } else {
         return this.O;
      }
   }

   int method3471() {
      return this.G ? 0 : 100;
   }

   byte[] method3467() {
      if (this.G) {
         throw new RuntimeException();
      } else {
         return this.O;
      }
   }

   byte[] method3466() {
      if (this.G) {
         throw new RuntimeException();
      } else {
         return this.O;
      }
   }

   int method3468(int var1) {
      try {
         return this.G ? 0 : 100;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aks.f(" + ')');
      }
   }

   int method3470() {
      return this.G ? 0 : 100;
   }

   byte[] method3465(short var1) {
      try {
         if (this.G) {
            throw new RuntimeException();
         } else {
            return this.O;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "aks.a(" + ')');
      }
   }

   int method3472() {
      return this.G ? 0 : 100;
   }
}
