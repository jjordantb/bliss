import java.io.File;
import java.io.IOException;

public class CZ implements MAI {
   KJ B;
   UC F;
   IBI J;
   public static int I;

   public boolean method54() {
      return this.B.D(791455531 * this.F.I, -457216440);
   }

   CZ(KJ var1, UC var2) {
      this.B = var1;
      this.F = var2;
   }

   public void method58(boolean var1, byte var2) {
      try {
         if (var1) {
            int var3 = GY.Z * -2110394505 > XEI.BC * 775068819 ? GY.Z * -2110394505 : 775068819 * XEI.BC;
            int var4 = JM.J * -1111710645 > -791746413 * XEI.KC ? JM.J * -1111710645 : XEI.KC * -791746413;
            int var5 = this.J.method271();
            int var6 = this.J.method626();
            int var7 = 0;
            int var8 = var3;
            int var9 = var3 * var6 / var5;
            int var10 = (var4 - var9) / 2;
            if (var9 > var4) {
               var10 = 0;
               var9 = var4;
               var8 = var5 * var4 / var6;
               var7 = (var3 - var8) / 2;
            }

            this.J.I(var7, var10, var8, var9);
         }

      } catch (RuntimeException var11) {
         throw DQ.I(var11, "fl.f(" + ')');
      }
   }

   public boolean method52(int var1) {
      try {
         return this.B.D(791455531 * this.F.I, -457216440);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "fl.b(" + ')');
      }
   }

   public void method55() {
      this.J = NV.I(this.B, this.F.I * 791455531, (byte)-99);
   }

   public void method53(int var1) {
      try {
         this.J = NV.I(this.B, this.F.I * 791455531, (byte)-105);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "fl.a(" + ')');
      }
   }

   public boolean method57() {
      return this.B.D(791455531 * this.F.I, -457216440);
   }

   public void method56(boolean var1) {
      if (var1) {
         int var2 = GY.Z * -2110394505 > XEI.BC * 775068819 ? GY.Z * -2110394505 : 775068819 * XEI.BC;
         int var3 = JM.J * -1111710645 > -791746413 * XEI.KC ? JM.J * -1111710645 : XEI.KC * -791746413;
         int var4 = this.J.method271();
         int var5 = this.J.method626();
         int var6 = 0;
         int var7 = var2;
         int var8 = var2 * var5 / var4;
         int var9 = (var3 - var8) / 2;
         if (var8 > var3) {
            var9 = 0;
            var8 = var3;
            var7 = var4 * var3 / var5;
            var6 = (var2 - var7) / 2;
         }

         this.J.I(var6, var9, var7, var8);
      }

   }

   public boolean method59() {
      return this.B.D(791455531 * this.F.I, -457216440);
   }

   static final void I(HSI var0, X var1, OU var2, int var3) {
      try {
         var0.oI = var2.H[(var2.J -= -391880689) * 681479919] * -1455284437;
         VEI.I(var0, -2049323512);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "fl.gc(" + ')');
      }
   }

   static final void I(HSI var0, OU var1, int var2) {
      try {
         int var3 = var1.H[(var1.J -= -391880689) * 681479919];
         int var4 = var1.H[(var1.J -= -391880689) * 681479919] - 1;
         if (1548853569 * var0.KI != 6) {
            throw new RuntimeException("");
         } else {
            HEI var5 = WZ.q.I(572201537 * var0.f, -1577596397);
            if (var0.VC == null) {
               var0.VC = new FZI(var5, true);
            }

            var0.VC.B = PT.I(1726426173) * 3177550440302969639L;
            if (var4 >= 0 && var4 < var5.F.length) {
               var0.VC.Z[var4] = var3;
               VEI.I(var0, 649700405);
            } else {
               throw new RuntimeException("" + var4);
            }
         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "fl.qt(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = UA.F.xI != null && UA.F.xI.B ? 1 : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "fl.ud(" + ')');
      }
   }

   static byte[] I(File var0, int var1, int var2) {
      try {
         byte[] var3;
         try {
            byte[] var4 = new byte[var1];
            GZI.I(var0, var4, var1, 1833251010);
            var3 = var4;
         } catch (IOException var5) {
            return null;
         }

         return var3;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "fl.f(" + ')');
      }
   }

   static final void I(SSI var0, boolean var1, int var2) {
      try {
         int var3 = NA.B.C;
         int var4 = 0;
         if (-412225079 * var0.II > XEI.kB * 443738891) {
            JI.I(var0, -455530754);
         } else if (var0.AI * 1450943713 >= XEI.kB * 443738891) {
            S.I(var0, -1562807680);
         } else {
            XP.I(var0, var1, 365613015);
            var3 = AP.j * -2143152965;
            var4 = ZX.C * 236175727;
         }

         SF var5 = var0.I().I;
         int var6;
         if ((int)var5.I < 512 || (int)var5.Z < 512 || (int)var5.I >= (XEI.mI.Z(-2045914503) - 1) * 512 || (int)var5.Z >= (XEI.mI.C(2070989013) - 1) * 512) {
            var0.e.I(-1, (int)-1660674133);

            for(var6 = 0; var6 < var0.s.length; ++var6) {
               var0.s[var6].C = -1313669563;
               var0.s[var6].Z.I(-1, (int)-1698848994);
            }

            var0.x = null;
            var0.II = 0;
            var0.AI = 0;
            var3 = NA.B.C;
            var4 = 0;
            var0.I((float)(var0.YI[0] * 512 + var0.S() * 256), var5.C, (float)(512 * var0.v[0] + var0.S() * 256));
            var0.Z(229400295);
         }

         if (UA.F == var0 && ((int)var5.I < 6144 || (int)var5.Z < 6144 || (int)var5.I >= (XEI.mI.Z(-2000317727) - 12) * 512 || (int)var5.Z >= (XEI.mI.C(52673101) - 12) * 512)) {
            var0.e.I(-1, (int)-1994577841);

            for(var6 = 0; var6 < var0.s.length; ++var6) {
               var0.s[var6].C = -1313669563;
               var0.s[var6].Z.I(-1, (int)-2027122238);
            }

            var0.x = null;
            var0.II = 0;
            var0.AI = 0;
            var3 = NA.B.C;
            var4 = 0;
            var0.I((float)(var0.YI[0] * 512 + var0.S() * 256), var5.C, (float)(512 * var0.v[0] + var0.S() * 256));
            var0.Z(1590910009);
         }

         var6 = WS.I(var0, 1199726988);
         U.I(var0, -1145965611);
         DK.I(var0, var3, var4, var6, -830154452);
         ZV.I(var0, var3, 1842586894);
         UY.I((SSI)var0, (byte)27);
         AF var7 = AF.I();
         var7.I(HF.I(var0.n.I((byte)0)), HF.I(var0.NI.I((byte)0)), HF.I(var0.PI.I((byte)0)));
         var0.I(var7);
         var7.C();
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "fl.hn(" + ')');
      }
   }
}
