import jagdx.IDirect3DDevice;
import jagdx.IDirect3DVolumeTexture;
import java.nio.ByteBuffer;

public class AD extends SD implements DEI {
   int CreateVolumeTexture;
   int J;
   int Upload;

   long I() {
      return this.Z;
   }

   AD(PJI var1, YCI var2, int var3, int var4, int var5, boolean var6, byte[] var7) {
      super(var1, var2, SDI.C, false, var3 * var4 * var5);
      this.CreateVolumeTexture = var3;
      this.J = var4;
      this.Upload = var5;
      this.Z = IDirect3DDevice.CreateVolumeTexture(this.D.FZ, var3, var4, var5, 1, 0, PJI.I(var2, this.C), 1);
      ByteBuffer var8 = this.D.F;
      var8.clear();
      var8.put(var7);
      IDirect3DVolumeTexture.Upload(this.Z, 0, 0, 0, 0, this.CreateVolumeTexture, this.J, this.Upload, this.CreateVolumeTexture * var2.I * 845115459, 0, this.D.J);
   }

   public void method126() {
      this.D.I(this);
   }

   public void method127(EB var1) {
      super.method122(var1);
   }

   public void b() {
      super.b();
   }

   public void d() {
      super.b();
   }

   public void u() {
      super.b();
   }

   public void x() {
      super.b();
   }

   public void method125() {
      this.D.I(this);
   }

   public void method128() {
      this.D.I(this);
   }

   public void method123() {
      this.D.I(this);
   }

   long CreateVolumeTexture() {
      return this.Z;
   }

   public void method124(EB var1) {
      super.method122(var1);
   }

   public void method129(EB var1) {
      super.method122(var1);
   }

   public void method122(EB var1) {
      super.method122(var1);
   }

   long J() {
      return this.Z;
   }
}
