public class KT {
   public static int append = 6;
   static WW I;

   KT() throws Throwable {
      throw new Error();
   }

   static final void I(OU var0, byte var1) {
      try {
         var0.S[(var0.A += 969361751) * -203050393 - 1] = var0.Z[var0.X[1883543357 * var0.i]];
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ps.ap(" + ')');
      }
   }

   public static short[] I(short[] var0, byte var1) {
      try {
         if (var0 == null) {
            return null;
         } else {
            short[] var2 = new short[var0.length];
            System.arraycopy(var0, 0, var2, 0, var0.length);
            return var2;
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ps.f(" + ')');
      }
   }

   public static boolean I(int var0, int[] var1, int var2) {
      try {
         if (MX.S[var0]) {
            return true;
         } else {
            IU.F[var0] = TP.I(var0, var1, IU.F[var0], false, (byte)3);
            if (IU.F[var0] == null) {
               return false;
            } else {
               MX.S[var0] = true;
               return true;
            }
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ps.i(" + ')');
      }
   }
}
