import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.util.Iterator;

public class EQ {
   public int[][] I;
   public int Z = 512849763;
   public int[] C = null;
   public int[] B = null;
   int J = 0;
   public int D = -241536037;
   public int F = 928434405;
   public int S = 1216995793;
   LF[] append;
   public int A = 1440097851;
   public int E = 0;
   public int G = 1261244237;
   public int H = -1316025001;
   public int K = -1270333873;
   public int L = -1566713043;
   SQ M;
   public int N = 0;
   public int O = 1511636755;
   public int P = -1034489103;
   public int Q = -537960313;
   public int R = 1236000399;
   public int T = 1402060193;
   public int[] U;
   public int V = 1442268255;
   public int W = 0;
   public int X = 0;
   public int Y = 0;
   public int i = 71356649;
   public int z = -697230329;
   public int c = 549936551;
   public int b = 0;
   public int d = -564296781;
   public int[] f;
   public int j = -1019547381;
   public int s = 0;
   public int a = 0;
   public int e = 1593946535;
   public int g = 0;
   public int h = 0;
   public int k = 1711775317;
   public int l = 0;
   public int m = 0;
   public int n = -1083720273;
   public int[][] o;
   public int p = 853635893;
   public int q = 1201368129;
   public boolean r = true;
   public static LG t;
   static int u;
   public static String v;

   void J(REI var1, int var2, int var3) {
      try {
         if (1 == var2) {
            this.Z = var1.Y(1235052657) * -512849763;
            this.S = var1.Y(1235052657) * -1216995793;
         } else if (2 == var2) {
            this.q = var1.Y(1235052657) * -1201368129;
         } else if (var2 == 3) {
            this.H = var1.Y(1235052657) * 1316025001;
         } else if (4 == var2) {
            this.O = var1.Y(1235052657) * -1511636755;
         } else if (5 == var2) {
            this.P = var1.Y(1235052657) * 1034489103;
         } else if (var2 == 6) {
            this.G = var1.Y(1235052657) * -1261244237;
         } else if (var2 == 7) {
            this.k = var1.Y(1235052657) * -1711775317;
         } else if (var2 == 8) {
            this.e = var1.Y(1235052657) * -1593946535;
         } else if (9 == var2) {
            this.L = var1.Y(1235052657) * 1566713043;
         } else if (26 == var2) {
            this.X = (short)(var1.I() * 4) * 1013056483;
            this.Y = (short)(var1.I() * 4) * -1453025501;
         } else {
            int var4;
            int var5;
            if (var2 == 27) {
               if (this.I == null) {
                  this.I = new int[this.M.Z.Z.length][];
               }

               var4 = var1.I();
               this.I[var4] = new int[6];

               for(var5 = 0; var5 < 6; ++var5) {
                  this.I[var4][var5] = var1.J(2080193946);
               }
            } else if (var2 == 28) {
               var4 = var1.I();
               this.U = new int[var4];

               for(var5 = 0; var5 < var4; ++var5) {
                  this.U[var5] = var1.I();
                  if (this.U[var5] == 255) {
                     this.U[var5] = -1;
                  }
               }
            } else if (var2 == 29) {
               this.s = var1.I() * 115903875;
            } else if (var2 == 30) {
               this.a = var1.C() * 719028937;
            } else if (31 == var2) {
               this.N = var1.I() * -369164975;
            } else if (32 == var2) {
               this.g = var1.C() * 1012239243;
            } else if (33 == var2) {
               this.h = var1.J(1712856653) * 92325015;
            } else if (34 == var2) {
               this.E = var1.I() * 477826083;
            } else if (var2 == 35) {
               this.l = var1.C() * -1803824059;
            } else if (36 == var2) {
               this.m = var1.J(1850319623) * 1175766897;
            } else if (37 == var2) {
               this.n = var1.I() * 1083720273;
            } else if (38 == var2) {
               this.D = var1.Y(1235052657) * 241536037;
            } else if (39 == var2) {
               this.V = var1.Y(1235052657) * -1442268255;
            } else if (var2 == 40) {
               this.d = var1.Y(1235052657) * 564296781;
            } else if (var2 == 41) {
               this.A = var1.Y(1235052657) * -1440097851;
            } else if (42 == var2) {
               this.K = var1.Y(1235052657) * 1270333873;
            } else if (var2 == 43) {
               this.z = var1.Y(1235052657) * 697230329;
            } else if (44 == var2) {
               this.p = var1.Y(1235052657) * -853635893;
            } else if (var2 == 45) {
               this.F = var1.C() * -928434405;
            } else if (46 == var2) {
               this.Q = var1.Y(1235052657) * 537960313;
            } else if (var2 == 47) {
               this.j = var1.Y(1235052657) * 1019547381;
            } else if (48 == var2) {
               this.T = var1.Y(1235052657) * -1402060193;
            } else if (var2 == 49) {
               this.c = var1.Y(1235052657) * -549936551;
            } else if (50 == var2) {
               this.i = var1.Y(1235052657) * -71356649;
            } else if (var2 == 51) {
               this.R = var1.Y(1235052657) * -1236000399;
            } else if (52 == var2) {
               var4 = var1.I();
               this.C = new int[var4];
               this.B = new int[var4];

               for(var5 = 0; var5 < var4; ++var5) {
                  this.C[var5] = var1.Y(1235052657);
                  int var6 = var1.I();
                  this.B[var5] = var6;
                  this.J += var6 * 81529747;
               }
            } else if (var2 == 53) {
               this.r = false;
            } else if (var2 == 54) {
               this.W = (var1.I() << 6) * 989376361;
               this.b = (var1.I() << 6) * -1343302987;
            } else if (55 == var2) {
               if (this.f == null) {
                  this.f = new int[this.M.Z.Z.length];
               }

               var4 = var1.I();
               this.f[var4] = var1.C();
            } else if (var2 == 56) {
               if (this.o == null) {
                  this.o = new int[this.M.Z.Z.length][];
               }

               var4 = var1.I();
               this.o[var4] = new int[3];

               for(var5 = 0; var5 < 3; ++var5) {
                  this.o[var4][var5] = var1.J(1788063911);
               }
            }
         }

      } catch (RuntimeException var7) {
         throw DQ.I(var7, "op.f(" + ')');
      }
   }

   public LF[] I(byte var1) {
      try {
         if (this.append != null) {
            return this.append;
         } else if (this.I == null) {
            return null;
         } else {
            this.append = new LF[this.I.length];

            for(int var2 = 0; var2 < this.I.length; ++var2) {
               int var3 = 0;
               int var4 = 0;
               int var5 = 0;
               int var6 = 0;
               int var7 = 0;
               int var8 = 0;
               if (this.I[var2] != null) {
                  var3 = this.I[var2][0];
                  var4 = this.I[var2][1];
                  var5 = this.I[var2][2];
                  var6 = this.I[var2][3] << 3;
                  var7 = this.I[var2][4] << 3;
                  var8 = this.I[var2][5] << 3;
               }

               if (var3 == 0 && var4 == 0 && var5 == 0 && var6 == 0 && var7 == 0 && var8 == 0) {
                  if (var1 <= 12) {
                     throw new IllegalStateException();
                  }
               } else {
                  LF var9 = this.append[var2] = new LF();
                  if (var8 != 0) {
                     var9.Z(0.0F, 0.0F, 1.0F, HF.I(var8));
                  }

                  if (var6 != 0) {
                     var9.Z(1.0F, 0.0F, 0.0F, HF.I(var6));
                  }

                  if (var7 != 0) {
                     var9.Z(0.0F, 1.0F, 0.0F, HF.I(var7));
                  }

                  var9.C((float)var3, (float)var4, (float)var5);
               }
            }

            return this.append;
         }
      } catch (RuntimeException var10) {
         throw DQ.I(var10, "op.i(" + ')');
      }
   }

   public int I(int var1) {
      try {
         if (this.Z * -809747019 != -1) {
            return this.Z * -809747019;
         } else if (this.C == null) {
            return -1;
         } else {
            int var2 = (int)(Math.random() * (double)(-5125477 * this.J));

            int var3;
            for(var3 = 0; var2 >= this.B[var3]; ++var3) {
               var2 -= this.B[var3];
            }

            return this.C[var3];
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "op.b(" + ')');
      }
   }

   public boolean I(int var1, byte var2) {
      try {
         if (-1 == var1) {
            return false;
         } else if (var1 == -809747019 * this.Z) {
            return true;
         } else {
            if (this.C != null) {
               for(int var3 = 0; var3 < this.C.length; ++var3) {
                  if (var1 == this.C[var3]) {
                     return true;
                  }
               }
            }

            return false;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "op.p(" + ')');
      }
   }

   public int[] Z(int var1) {
      try {
         JX var2 = new JX(16);
         OO.I(-809747019 * this.Z, var2, -518506092);
         int[] var3;
         int var4;
         if (this.C != null) {
            var3 = this.C;

            for(var4 = 0; var4 < var3.length; ++var4) {
               int var5 = var3[var4];
               OO.I(var5, var2, -996745872);
            }
         }

         OO.I(844607405 * this.D, var2, -1466126807);
         OO.I(1061677153 * this.V, var2, -537938152);
         OO.I(-129111857 * this.S, var2, -1080833419);
         OO.I(this.d * -277799803, var2, -1770644447);
         OO.I(315374861 * this.A, var2, -1518977416);
         OO.I(this.K * -1532631215, var2, -674677793);
         OO.I(230243963 * this.G, var2, -1811756409);
         OO.I(491753731 * this.k, var2, -1070117202);
         OO.I(-2054940183 * this.e, var2, -891093089);
         OO.I(-783166629 * this.L, var2, -2016176230);
         OO.I(this.q * 328817727, var2, -1375066780);
         OO.I(this.H * -1238642279, var2, -1493937450);
         OO.I(this.O * -907666203, var2, -1237374124);
         OO.I(124010991 * this.P, var2, -707153443);
         OO.I(this.Q * 371497673, var2, -455707757);
         OO.I(this.j * -279532195, var2, -455027567);
         OO.I(this.T * 1885772191, var2, -507782637);
         OO.I(this.c * 914130409, var2, -997447340);
         OO.I(this.i * 250017959, var2, -1792088224);
         OO.I(this.R * -119373935, var2, -909523000);
         var3 = new int[var2.Z(1901508554)];
         var4 = 0;

         AE var6;
         for(Iterator var8 = var2.iterator(); var8.hasNext(); var3[var4++] = (int)(var6.Z * 7051297995265073167L)) {
            var6 = (AE)var8.next();
         }

         return var3;
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "op.k(" + ')');
      }
   }

   void I(REI var1, int var2) {
      try {
         while(true) {
            int var3 = var1.I();
            if (var3 == 0) {
               if (var2 != 162499609) {
                  throw new IllegalStateException();
               }

               return;
            }

            this.J(var1, var3, -247907698);
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "op.a(" + ')');
      }
   }

   static final void I(OU var0, short var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.A -= 1938723502;
         String var3 = (String)var0.S[var0.A * -203050393];
         String var4 = (String)var0.S[1 + var0.A * -203050393];
         if (var3.length() <= 500 && var4.length() <= 500) {
            ZE.I(var2, var3, var4, 600657777);
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "op.aps(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         GJ.Z = 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "op.abp(" + ')');
      }
   }

   public static LEI I(int var0, int var1, short var2) {
      try {
         NO.B.B = var0 * -760677635;
         NO.B.C = var1 * 167105303;
         NO.B.D = -1544157451;
         NO.B.F = -1468199503;
         return NO.B;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "op.a(" + ')');
      }
   }

   public static int I(int var0, int var1, float var2, int var3) {
      try {
         return JK.I(var0, var1, (int)var2, 1963059640);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "op.x(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         FW.J.I(FW.J.e, 0, -1906997591);
         JN.I(656179282);
         XEI.w = false;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "op.anv(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.S.method5612(var2, 1352882135);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "op.aoc(" + ')');
      }
   }

   static void C(int var0) {
      try {
         if (GDI.I * 256666041 < 102) {
            GDI.I += 879545142;
         }

         int var1;
         if (-917301319 * GDI.F != -1 && 3224865510845692061L * RZ.K < CI.I((byte)1)) {
            for(var1 = GDI.F * -917301319; var1 < GDI.G.length; ++var1) {
               if (GDI.G[var1].startsWith("pause")) {
                  int var2 = 5;

                  try {
                     var2 = Integer.parseInt(GDI.G[var1].substring(6));
                  } catch (Exception var9) {
                     ;
                  }

                  CS.I("Pausing for " + var2 + " seconds...", 270683370);
                  GDI.F = (var1 + 1) * -1428832631;
                  RZ.K = (CI.I((byte)1) + (long)(1000 * var2)) * 6717445677357895093L;
                  return;
               }

               GDI.C = GDI.G[var1];
               NZ.I(false, 1496417723);
            }

            GDI.F = 1428832631;
         }

         if (1170859143 * XEI.HI != 0) {
            GDI.D -= XEI.HI * 1787831191;
            if (GDI.D * -1731316011 >= GDI.B * -2035787443) {
               GDI.D = GDI.B * -1477098343 - 205738621;
            }

            if (-1731316011 * GDI.D < 0) {
               GDI.D = 0;
            }

            XEI.HI = 0;
         }

         for(var1 = 0; var1 < 1351936279 * XEI.tB; ++var1) {
            WSI var12 = XEI.aI[var1];
            int var3 = var12.method218((byte)-29);
            char var4 = var12.method217((byte)-110);
            int var5 = var12.method220((byte)0);
            if (84 == var3) {
               NZ.I(false, 1496417723);
            }

            if (var3 == 80) {
               NZ.I(true, 1496417723);
            } else if (var3 == 66 && (var5 & 4) != 0) {
               if (PR.c != null) {
                  String var13 = "";

                  for(int var14 = GDI.A.length - 1; var14 >= 0; --var14) {
                     if (GDI.A[var14] != null && GDI.A[var14].length() > 0) {
                        var13 = var13 + GDI.A[var14] + '\n';
                     }
                  }

                  PR.c.setContents(new StringSelection(var13), (ClipboardOwner)null);
               }
            } else if (67 == var3 && (var5 & 4) != 0) {
               if (PR.c != null) {
                  try {
                     Transferable var6 = PR.c.getContents((Object)null);
                     if (var6 != null) {
                        String var7 = (String)var6.getTransferData(DataFlavor.stringFlavor);
                        if (var7 != null) {
                           String[] var8 = HR.I(var7, '\n', 1017779885);
                           YCI.I(var8, 399274522);
                        }
                     }
                  } catch (Exception var10) {
                     ;
                  }
               }
            } else if (var3 == 85 && -1182747927 * GDI.Z > 0) {
               GDI.C = GDI.C.substring(0, -1182747927 * GDI.Z - 1) + GDI.C.substring(GDI.Z * -1182747927);
               GDI.Z -= 1914783065;
            } else if (101 == var3 && -1182747927 * GDI.Z < GDI.C.length()) {
               GDI.C = GDI.C.substring(0, -1182747927 * GDI.Z) + GDI.C.substring(1 + GDI.Z * -1182747927);
            } else if (var3 == 96 && GDI.Z * -1182747927 > 0) {
               GDI.Z -= 1914783065;
            } else if (var3 == 97 && -1182747927 * GDI.Z < GDI.C.length()) {
               GDI.Z += 1914783065;
            } else if (102 == var3) {
               GDI.Z = 0;
            } else if (103 == var3) {
               GDI.Z = GDI.C.length() * 1914783065;
            } else if (104 == var3 && -1217082313 * GDI.J < GDI.A.length) {
               GDI.J += -1305958009;
               YCI.I(-214283222);
               GDI.Z = GDI.C.length() * 1914783065;
            } else if (105 == var3 && -1217082313 * GDI.J > 0) {
               GDI.J -= -1305958009;
               YCI.I(1763987987);
               GDI.Z = GDI.C.length() * 1914783065;
            } else if (KEI.I((char)var4, (short)160) || "\\/.:, _-+[]~@".indexOf(var4) != -1) {
               GDI.C = GDI.C.substring(0, -1182747927 * GDI.Z) + XEI.aI[var1].method217((byte)9) + GDI.C.substring(GDI.Z * -1182747927);
               GDI.Z += 1914783065;
            }
         }

         XEI.tB = 0;
         XEI.NI = 0;
         TQ.Z(2005471811);
      } catch (RuntimeException var11) {
         throw DQ.I(var11, "op.u(" + ')');
      }
   }
}
