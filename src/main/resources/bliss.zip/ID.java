public class ID {
   public static int Z = 17;
   public static int append = 4;
   public static int toString = 20;
   public static int I = 1;
   public static int C = 21;
   public static int B = 27;
   public static int D = 28;
   public static int F = 9;
   public static int J = 7;
   public static int S = 15;
   public static int A = 26;
   public static int E = 31;
   public static int G = 12;
   public static int H = 5;
   public static int K = 14;
   public static int L = 22;
   public static int M = 23;
   public static int N = 29;
   public static int O = 32;
   public static int P = 8;
   public static int Q = 16;
   public static int R = 24;
   public static int T = 33;
   public static int U = 6;
   public static int V = 11;
   public static int W = 10;
   public static int X = 18;
   public static int Y = 13;
   public static int i = 25;
   public static int z = 3;
   public static int c = 2;
   public static int b = 30;

   ID() throws Throwable {
      throw new Error();
   }

   static final void I(OU var0, byte var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         SI.I(var3, var4, var0, 1051610527);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "if.np(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)83);
         X var4 = IU.F[var2 >> 16];
         ZP.I(var3, var4, var0, -389689371);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "if.oa(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = EE.V * -863531439 == 4 ? 1 : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "if.agy(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         FW.J.I(FW.J.V, var2, 965049953);
         JN.I(656179282);
         XEI.w = false;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "if.aih(" + ')');
      }
   }

   public static LEI I(int var0, int var1, int var2, int var3, RW var4, int var5, byte var6) {
      try {
         NO.F.B = var0 * -760677635;
         NO.F.C = 167105303 * var1;
         NO.F.D = var2 * -1544157451;
         NO.F.F = -1468199503 * var3;
         NO.F.I = var4;
         NO.F.Z = -2142070477 * var5;
         return NO.F;
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "if.k(" + ')');
      }
   }

   public static void I(int var0) {
      try {
         ZB.I(1437455433);
         FX.G = false;
         QF.I(QFI.I * -1347746885, PN.E * 1089948687, 608683427 * ZZ.H, 1396607435 * UX.I, (byte)2);
         HM.L = null;
         QO.I = null;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "if.s(" + ')');
      }
   }

   static final void Z(OU var0, byte var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var3.t * 684246511;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "if.pd(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, byte var3) {
      try {
         var0.ZZ = var2.H[(var2.J -= -391880689) * 681479919] * -7527659;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "if.jq(" + ')');
      }
   }
}
