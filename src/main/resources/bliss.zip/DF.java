import java.awt.Container;
import java.awt.Frame;
import java.io.File;
import javax.swing.JFileChooser;

public class DF implements Runnable {
   File append = null;
   String getParent;
   boolean getSelectedFile;
   boolean setAcceptAllFileFilterUsed = false;

   public boolean I(int var1) {
      try {
         return this.setAcceptAllFileFilterUsed;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "j.f(" + ')');
      }
   }

   public void run() {
      try {
         Container var1 = QO.I((byte)11);
         Frame var2 = null;
         if (PK.L != null) {
            var2 = PK.L;
         } else {
            while(var1 != null) {
               if (var1 instanceof Frame) {
                  var2 = (Frame)var1;
                  break;
               }

               var1 = var1.getParent();
            }
         }

         if (var2 == null) {
            throw new RuntimeException("");
         } else {
            JFileChooser var3 = new JFileChooser("");
            var3.setDialogTitle(this.getParent);
            var3.setFileFilter(new ASI(this, this));
            var3.setFileSelectionMode(1);
            var3.setAcceptAllFileFilterUsed(false);
            int var4 = var3.showOpenDialog(var2);
            if (var4 == 0) {
               this.append = var3.getSelectedFile();
            }

            this.setAcceptAllFileFilterUsed = true;
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "j.run(" + ')');
      }
   }

   public File I(short var1) {
      try {
         return this.append;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "j.a(" + ')');
      }
   }

   public DF(String var1, boolean var2) {
      this.getParent = var1;
      this.getSelectedFile = var2;
      (new Thread(this)).start();
   }

   boolean Z(int var1) {
      try {
         return this.getSelectedFile;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "j.b(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         ZO.I(var3, var4, var0, (byte)12);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "j.fl(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, byte var3) {
      try {
         var0.mZ = var2.H[(var2.J -= -391880689) * 681479919] * -1122372539;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "j.kb(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         CZ.I(var3, var0, 171697285);
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "j.qa(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         String var2 = (String)var0.S[(var0.A -= 969361751) * -203050393];
         XZI.I(var2, -878846096);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "j.wq(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         var0.S[(var0.A += 969361751) * -203050393 - 1] = var0.D.E[var2].I;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "j.xm(" + ')');
      }
   }

   static boolean I(int var0, int var1) {
      try {
         return 57 == var0 || 58 == var0 || var0 == 1007 || var0 == 25 || 30 == var0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "j.bx(" + ')');
      }
   }

   static final void B(OU var0, int var1) {
      try {
         String var2 = null;
         if (XJ.J != null) {
            var2 = XJ.J.I(-161430345);
         }

         if (var2 == null) {
            var2 = "";
         }

         var0.S[(var0.A += 969361751) * -203050393 - 1] = var2;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "j.afh(" + ')');
      }
   }

   public static String I(byte[] var0, int var1, int var2, int var3) {
      try {
         char[] var4 = new char[var2];
         int var5 = 0;
         int var6 = var1;

         int var9;
         for(int var7 = var1 + var2; var6 < var7; var4[var5++] = (char)var9) {
            int var8 = var0[var6++] & 255;
            if (var8 < 128) {
               if (var8 == 0) {
                  var9 = 65533;
               } else {
                  var9 = var8;
               }
            } else if (var8 < 192) {
               var9 = 65533;
            } else if (var8 < 224) {
               if (var6 < var7 && (var0[var6] & 192) == 128) {
                  var9 = (var8 & 31) << 6 | var0[var6++] & 63;
                  if (var9 < 128) {
                     var9 = 65533;
                  }
               } else {
                  var9 = 65533;
               }
            } else if (var8 < 240) {
               if (1 + var6 < var7 && (var0[var6] & 192) == 128 && 128 == (var0[1 + var6] & 192)) {
                  var9 = (var8 & 15) << 12 | (var0[var6++] & 63) << 6 | var0[var6++] & 63;
                  if (var9 < 2048) {
                     var9 = 65533;
                  }
               } else {
                  var9 = 65533;
               }
            } else if (var8 < 248) {
               if (2 + var6 < var7 && 128 == (var0[var6] & 192) && 128 == (var0[var6 + 1] & 192) && (var0[var6 + 2] & 192) == 128) {
                  var9 = (var8 & 7) << 18 | (var0[var6++] & 63) << 12 | (var0[var6++] & 63) << 6 | var0[var6++] & 63;
                  if (var9 >= 65536 && var9 <= 1114111) {
                     var9 = 65533;
                  } else {
                     var9 = 65533;
                  }
               } else {
                  var9 = 65533;
               }
            } else {
               var9 = 65533;
            }
         }

         return new String(var4, 0, var5);
      } catch (RuntimeException var10) {
         throw DQ.I(var10, "j.a(" + ')');
      }
   }
}
