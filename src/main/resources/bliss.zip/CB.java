public class CB {
   static CB I = new CB(5);
   static CB Z = new CB(1);
   public static CB C = new CB(0);
   public static CB B = new CB(2);
   static CB D = new CB(4);
   static CB F = new CB(3);
   public int J;

   CB(int var1) {
      this.J = var1;
   }
}
