import java.util.BitSet;

public class LG extends AE {
   boolean append;
   boolean equalsIgnoreCase = true;
   public byte J;
   public int S = 0;
   int[] longValue;
   public String A = null;
   public RC[] E;
   public byte G;
   long H;

   static {
      new BitSet(65536);
   }

   public LG(REI var1) {
      this.append(var1, (byte)-94);
   }

   public int[] C(int var1) {
      try {
         if (this.longValue == null) {
            String[] var2 = new String[this.S * 649879491];
            this.longValue = new int[649879491 * this.S];

            for(int var3 = 0; var3 < this.S * 649879491; this.longValue[var3] = var3++) {
               var2[var3] = this.E[var3].I;
            }

            IK.I(var2, this.longValue, 715814355);
         }

         return this.longValue;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "abj.f(" + ')');
      }
   }

   void I(RC var1, int var2) {
      try {
         if (this.E == null || 649879491 * this.S >= this.E.length) {
            this.equalsIgnoreCase(5 + 649879491 * this.S, (byte)26);
         }

         this.E[(this.S += 506595563) * 649879491 - 1] = var1;
         this.longValue = null;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "abj.b(" + ')');
      }
   }

   public int I(String var1, byte var2) {
      try {
         for(int var3 = 0; var3 < 649879491 * this.S; ++var3) {
            if (this.E[var3].I.equalsIgnoreCase(var1)) {
               return var3;
            }
         }

         return -1;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "abj.i(" + ')');
      }
   }

   void append(REI var1, byte var2) {
      try {
         int var3 = var1.I();
         if ((var3 & 1) != 0) {
            this.append = true;
         }

         if ((var3 & 2) != 0) {
            this.equalsIgnoreCase = true;
         }

         this.Z = var1.I((short)1568) * 4191220306876042991L;
         this.H = var1.I((short)25426) * 8816161044679006451L;
         this.A = var1.E(1262859658);
         var1.I();
         this.J = var1.S(-12558881);
         this.G = var1.S(-12558881);
         this.S = var1.C() * 506595563;
         if (this.S * 649879491 > 0) {
            this.E = new RC[649879491 * this.S];

            for(int var4 = 0; var4 < this.S * 649879491; ++var4) {
               RC var5 = new RC();
               if (this.append) {
                  var1.I((short)26032);
               }

               if (this.equalsIgnoreCase) {
                  var5.I = var1.E(254031265);
               }

               var5.C = var1.S(-12558881);
               var5.Z = var1.C() * -62810701;
               this.E[var4] = var5;
            }
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "abj.k(" + ')');
      }
   }

   void equalsIgnoreCase(int var1, byte var2) {
      try {
         if (this.E != null) {
            TW.I((Object[])this.E, 0, (Object[])(this.E = new RC[var1]), 0, this.S * 649879491);
         } else {
            this.E = new RC[var1];
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "abj.a(" + ')');
      }
   }

   void Z(int var1, int var2) {
      try {
         this.S -= 506595563;
         if (this.S * 649879491 == 0) {
            this.E = null;
         } else {
            TW.I((Object[])this.E, 1 + var1, (Object[])this.E, var1, this.S * 649879491 - var1);
         }

         this.longValue = null;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "abj.p(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         E.I(var0, -807637826);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "abj.si(" + ')');
      }
   }

   static final void B(OU var0, int var1) {
      try {
         WK var2 = EN.Z(var0.H[(var0.J -= -391880689) * 681479919]);
         if (var2 != null && var2.K != null) {
            var0.S[(var0.A += 969361751) * -203050393 - 1] = var2.K;
         } else {
            var0.S[(var0.A += 969361751) * -203050393 - 1] = "";
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "abj.adf(" + ')');
      }
   }

   static final void D(OU var0, int var1) {
      try {
         int var2 = var0.X[1883543357 * var0.i];
         Long var3 = (Long)LO.C[var2];
         if (var3 == null) {
            var0.Q[(var0.K += -682569305) * 1685767703 - 1] = -1L;
         } else {
            var0.Q[(var0.K += -682569305) * 1685767703 - 1] = var3.longValue();
         }

      } catch (RuntimeException var4) {
         throw DQ.I(var4, "abj.bs(" + ')');
      }
   }
}
