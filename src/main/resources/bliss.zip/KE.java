public class KE extends AE {
   int J;
   public int S;

   KE(int var1, int var2) {
      this.S = var1 * 388289509;
      this.J = var2 * -1076181017;
   }
}
