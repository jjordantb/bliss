public final class ES implements Comparable {
   long I;
   Object Z;
   long C;
   Object B;
   static int D;

   int Z(ES var1, int var2) {
      try {
         if (-547428082756159857L * this.I < -547428082756159857L * var1.I) {
            return -1;
         } else {
            return -547428082756159857L * this.I > -547428082756159857L * var1.I ? 1 : 0;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "kx.a(" + ')');
      }
   }

   public int compareTo(Object var1) {
      try {
         return this.Z((ES)var1, -1964859807);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "kx.compareTo(" + ')');
      }
   }

   ES(Object var1, Object var2) {
      this.Z = var1;
      this.B = var2;
   }

   public boolean equals(Object var1) {
      try {
         if (var1 instanceof ES) {
            return this.B.equals(((ES)var1).B);
         } else {
            throw new IllegalArgumentException();
         }
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "kx.equals(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, byte var3) {
      try {
         String var4 = (String)var2.S[(var2.A -= 969361751) * -203050393];
         if (IN.I(var4, var2, -209664788) != null) {
            var4 = var4.substring(0, var4.length() - 1);
         }

         var0.Z = OI.I(var4, var2, -2046058202);
         var0.JZ = true;
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "kx.lv(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)52);
         X var4 = IU.F[var2 >> 16];
         W.I(var3, var4, var0, -1603621953);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "kx.km(" + ')');
      }
   }

   public static boolean I(int var0, int var1) {
      try {
         return var0 == 1 || var0 == 3 || var0 == 5;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "kx.b(" + ')');
      }
   }
}
