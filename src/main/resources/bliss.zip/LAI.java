public interface LAI {
   RZ method49(int var1);

   RZ method50();

   RZ method51();
}
