import jaggl.OpenGL;

public class EII extends RY {
   float Z;
   int glBindProgramARB;
   static char glDisable = '\u0001';
   static String glEnable = "!!ARBvp1.0\nOPTION  ARB_position_invariant;\nATTRIB  iPos         = vertex.position;\nATTRIB  iColour      = vertex.color;\nATTRIB  iTexCoord    = vertex.texcoord[0];\nOUTPUT  oColour      = result.color;\nOUTPUT  oTexCoord0   = result.texcoord[0];\nOUTPUT  oTexCoord1   = result.texcoord[1];\nOUTPUT  oFogCoord    = result.fogcoord;\nPARAM   time         = program.local[65];\nPARAM   turbulence   = program.local[64];\nPARAM   lightAmbient = program.local[66]; \nPARAM   pMatrix[4]   = { state.matrix.projection };\nPARAM   mvMatrix[4]  = { state.matrix.modelview };\nPARAM   ivMatrix[4]  = { state.matrix.texture[1] };\nPARAM   texMatrix[4]  = { state.matrix.texture[0] };\nPARAM   fNoise[64]   = { program.local[0..63] };\nTEMP    noise, viewPos, worldPos, texCoord;\nADDRESS noiseAddr;\nDP4   viewPos.x, mvMatrix[0], iPos;\nDP4   viewPos.y, mvMatrix[1], iPos;\nDP4   viewPos.z, mvMatrix[2], iPos;\nDP4   viewPos.w, mvMatrix[3], iPos;\nMOV   oFogCoord.x, viewPos.z;\nDP4   worldPos.x, ivMatrix[0], viewPos;\nDP4   worldPos.y, ivMatrix[1], viewPos;\nDP4   worldPos.z, ivMatrix[2], viewPos;\nDP4   worldPos.w, ivMatrix[3], viewPos;\nADD   noise.x, worldPos.x, worldPos.z;SUB   noise.y, worldPos.z, worldPos.x;MUL   noise, noise, 0.0001220703125;\nFRC   noise, noise;\nMUL   noise, noise, 64;\nARL   noiseAddr.x, noise.x;\nMOV   noise.x, fNoise[noiseAddr.x].x;\nARL   noiseAddr.x, noise.y;\nMOV   noise.y, fNoise[noiseAddr.x].y;\nMUL   noise, noise, turbulence.x;\nDP4   texCoord.x, texMatrix[0], iTexCoord;\nDP4   texCoord.y, texMatrix[1], iTexCoord;\nADD   oTexCoord0.xy, texCoord, noise;\nMOV   oTexCoord0.z, 0;\nMOV   oTexCoord0.w, 1;\nMUL   oTexCoord1.xy, texCoord, 0.125;\nMOV   oTexCoord1.zw, time.xxxw;\nMUL   oColour.xyz, iColour, lightAmbient;\nMOV   oColour.w, iColour.w;\nEND";
   ZU glLoadIdentity;
   float[] glLoadMatrixf;
   static char glMatrixMode = 0;
   KA glProgramLocalParameter4fARB;
   VX glProgramLocalParameter4fvARB;
   static float[] C = new float[4];

   void method508(boolean var1) {
   }

   boolean method501() {
      return true;
   }

   void Z() {
      this.glProgramLocalParameter4fARB = new KA(this.I, 2);
      this.glProgramLocalParameter4fARB.I((int)0);
      this.I.C(1);
      this.I.D(-16777216);
      this.I.Z(260, 7681);
      this.I.C(0, 34166, 770);
      this.I.C(0);
      OpenGL.glBindProgramARB(34336, this.glLoadIdentity.I);
      OpenGL.glEnable(34336);
      this.glProgramLocalParameter4fARB.I();
      this.glProgramLocalParameter4fARB.I((int)1);
      this.I.C(1);
      OpenGL.glMatrixMode(5890);
      OpenGL.glLoadIdentity();
      OpenGL.glMatrixMode(5888);
      this.I.I(0);
      this.I.C(0, 5890, 770);
      this.I.C(0);
      OpenGL.glBindProgramARB(34336, 0);
      OpenGL.glDisable(34336);
      OpenGL.glDisable(34820);
      this.glProgramLocalParameter4fARB.I();
   }

   void method505(boolean var1) {
      if (this.glProgramLocalParameter4fARB != null) {
         this.glProgramLocalParameter4fARB.I('\u0000');
         this.I.C(1);
         OpenGL.glMatrixMode(5890);
         OpenGL.glLoadMatrixf(this.I.P.I, 0);
         OpenGL.glMatrixMode(5888);
         this.I.C(0);
         if (this.glBindProgramARB != this.I.E) {
            int var2 = this.I.E % 5000 * 128 / 5000;

            for(int var3 = 0; var3 < 64; ++var3) {
               OpenGL.glProgramLocalParameter4fvARB(34336, var3, this.glLoadMatrixf, var2);
               var2 += 2;
            }

            if (this.glProgramLocalParameter4fvARB.D) {
               this.Z = (float)(this.I.E % 4000) / 4000.0F;
            } else {
               OpenGL.glProgramLocalParameter4fARB(34336, 65, 0.0F, 0.0F, 0.0F, 1.0F);
            }

            this.glBindProgramARB = this.I.E;
         }
      }

   }

   void method504() {
      if (this.glProgramLocalParameter4fARB != null) {
         this.glProgramLocalParameter4fARB.I('\u0001');
         this.I.C(1);
         this.I.I((SN)null);
         this.I.C(0);
      }

   }

   void method503(int var1, int var2) {
      if (this.glProgramLocalParameter4fARB != null) {
         this.I.C(1);
         int var3;
         if ((var1 & 128) == 0) {
            if ((var2 & 1) == 1) {
               if (!this.glProgramLocalParameter4fvARB.D) {
                  var3 = this.I.E % 4000 * 16 / 4000;
                  this.I.I((SN)this.glProgramLocalParameter4fvARB.H[var3]);
                  OpenGL.glProgramLocalParameter4fARB(34336, 65, 0.0F, 0.0F, 0.0F, 1.0F);
               } else {
                  this.I.I((SN)this.glProgramLocalParameter4fvARB.J);
                  OpenGL.glProgramLocalParameter4fARB(34336, 65, this.Z, 0.0F, 0.0F, 1.0F);
               }
            } else {
               if (this.glProgramLocalParameter4fvARB.D) {
                  this.I.I((SN)this.glProgramLocalParameter4fvARB.J);
               } else {
                  this.I.I((SN)this.glProgramLocalParameter4fvARB.H[0]);
               }

               OpenGL.glProgramLocalParameter4fARB(34336, 65, 0.0F, 0.0F, 0.0F, 1.0F);
            }
         } else {
            this.I.I((SN)null);
         }

         this.I.C(0);
         if ((var1 & 64) == 0) {
            C[0] = this.I.k * this.I.g;
            C[1] = this.I.k * this.I.h;
            C[2] = this.I.k * this.I.TI;
            OpenGL.glProgramLocalParameter4fvARB(34336, 66, C, 0);
         } else {
            OpenGL.glProgramLocalParameter4fARB(34336, 66, 1.0F, 1.0F, 1.0F, 1.0F);
         }

         var3 = var1 & 3;
         if (var3 == 2) {
            OpenGL.glProgramLocalParameter4fARB(34336, 64, 0.05F, 1.0F, 1.0F, 1.0F);
         } else if (var3 == 3) {
            OpenGL.glProgramLocalParameter4fARB(34336, 64, 0.1F, 1.0F, 1.0F, 1.0F);
         } else {
            OpenGL.glProgramLocalParameter4fARB(34336, 64, 0.025F, 1.0F, 1.0F, 1.0F);
         }
      }

   }

   void method518(boolean var1) {
   }

   void method502(int var1, int var2) {
      if (this.glProgramLocalParameter4fARB != null) {
         this.I.C(1);
         int var3;
         if ((var1 & 128) == 0) {
            if ((var2 & 1) == 1) {
               if (!this.glProgramLocalParameter4fvARB.D) {
                  var3 = this.I.E % 4000 * 16 / 4000;
                  this.I.I((SN)this.glProgramLocalParameter4fvARB.H[var3]);
                  OpenGL.glProgramLocalParameter4fARB(34336, 65, 0.0F, 0.0F, 0.0F, 1.0F);
               } else {
                  this.I.I((SN)this.glProgramLocalParameter4fvARB.J);
                  OpenGL.glProgramLocalParameter4fARB(34336, 65, this.Z, 0.0F, 0.0F, 1.0F);
               }
            } else {
               if (this.glProgramLocalParameter4fvARB.D) {
                  this.I.I((SN)this.glProgramLocalParameter4fvARB.J);
               } else {
                  this.I.I((SN)this.glProgramLocalParameter4fvARB.H[0]);
               }

               OpenGL.glProgramLocalParameter4fARB(34336, 65, 0.0F, 0.0F, 0.0F, 1.0F);
            }
         } else {
            this.I.I((SN)null);
         }

         this.I.C(0);
         if ((var1 & 64) == 0) {
            C[0] = this.I.k * this.I.g;
            C[1] = this.I.k * this.I.h;
            C[2] = this.I.k * this.I.TI;
            OpenGL.glProgramLocalParameter4fvARB(34336, 66, C, 0);
         } else {
            OpenGL.glProgramLocalParameter4fARB(34336, 66, 1.0F, 1.0F, 1.0F, 1.0F);
         }

         var3 = var1 & 3;
         if (var3 == 2) {
            OpenGL.glProgramLocalParameter4fARB(34336, 64, 0.05F, 1.0F, 1.0F, 1.0F);
         } else if (var3 == 3) {
            OpenGL.glProgramLocalParameter4fARB(34336, 64, 0.1F, 1.0F, 1.0F, 1.0F);
         } else {
            OpenGL.glProgramLocalParameter4fARB(34336, 64, 0.025F, 1.0F, 1.0F, 1.0F);
         }
      }

   }

   void method500(SN var1, int var2) {
      this.I.I(var1);
      this.I.I(var2);
   }

   void method513(int var1, int var2) {
      if (this.glProgramLocalParameter4fARB != null) {
         this.I.C(1);
         int var3;
         if ((var1 & 128) == 0) {
            if ((var2 & 1) == 1) {
               if (!this.glProgramLocalParameter4fvARB.D) {
                  var3 = this.I.E % 4000 * 16 / 4000;
                  this.I.I((SN)this.glProgramLocalParameter4fvARB.H[var3]);
                  OpenGL.glProgramLocalParameter4fARB(34336, 65, 0.0F, 0.0F, 0.0F, 1.0F);
               } else {
                  this.I.I((SN)this.glProgramLocalParameter4fvARB.J);
                  OpenGL.glProgramLocalParameter4fARB(34336, 65, this.Z, 0.0F, 0.0F, 1.0F);
               }
            } else {
               if (this.glProgramLocalParameter4fvARB.D) {
                  this.I.I((SN)this.glProgramLocalParameter4fvARB.J);
               } else {
                  this.I.I((SN)this.glProgramLocalParameter4fvARB.H[0]);
               }

               OpenGL.glProgramLocalParameter4fARB(34336, 65, 0.0F, 0.0F, 0.0F, 1.0F);
            }
         } else {
            this.I.I((SN)null);
         }

         this.I.C(0);
         if ((var1 & 64) == 0) {
            C[0] = this.I.k * this.I.g;
            C[1] = this.I.k * this.I.h;
            C[2] = this.I.k * this.I.TI;
            OpenGL.glProgramLocalParameter4fvARB(34336, 66, C, 0);
         } else {
            OpenGL.glProgramLocalParameter4fARB(34336, 66, 1.0F, 1.0F, 1.0F, 1.0F);
         }

         var3 = var1 & 3;
         if (var3 == 2) {
            OpenGL.glProgramLocalParameter4fARB(34336, 64, 0.05F, 1.0F, 1.0F, 1.0F);
         } else if (var3 == 3) {
            OpenGL.glProgramLocalParameter4fARB(34336, 64, 0.1F, 1.0F, 1.0F, 1.0F);
         } else {
            OpenGL.glProgramLocalParameter4fARB(34336, 64, 0.025F, 1.0F, 1.0F, 1.0F);
         }
      }

   }

   void method511() {
      if (this.glProgramLocalParameter4fARB != null) {
         this.glProgramLocalParameter4fARB.I('\u0001');
         this.I.C(1);
         this.I.I((SN)null);
         this.I.C(0);
      }

   }

   void method509(boolean var1) {
   }

   void method510(boolean var1) {
   }

   EII(MJI var1, VX var2) {
      super(var1);
      this.glProgramLocalParameter4fvARB = var2;
      if (this.I.D && this.I.II >= 2) {
         this.glLoadIdentity = ZU.I(this.I, 34336, "!!ARBvp1.0\nOPTION  ARB_position_invariant;\nATTRIB  iPos         = vertex.position;\nATTRIB  iColour      = vertex.color;\nATTRIB  iTexCoord    = vertex.texcoord[0];\nOUTPUT  oColour      = result.color;\nOUTPUT  oTexCoord0   = result.texcoord[0];\nOUTPUT  oTexCoord1   = result.texcoord[1];\nOUTPUT  oFogCoord    = result.fogcoord;\nPARAM   time         = program.local[65];\nPARAM   turbulence   = program.local[64];\nPARAM   lightAmbient = program.local[66]; \nPARAM   pMatrix[4]   = { state.matrix.projection };\nPARAM   mvMatrix[4]  = { state.matrix.modelview };\nPARAM   ivMatrix[4]  = { state.matrix.texture[1] };\nPARAM   texMatrix[4]  = { state.matrix.texture[0] };\nPARAM   fNoise[64]   = { program.local[0..63] };\nTEMP    noise, viewPos, worldPos, texCoord;\nADDRESS noiseAddr;\nDP4   viewPos.x, mvMatrix[0], iPos;\nDP4   viewPos.y, mvMatrix[1], iPos;\nDP4   viewPos.z, mvMatrix[2], iPos;\nDP4   viewPos.w, mvMatrix[3], iPos;\nMOV   oFogCoord.x, viewPos.z;\nDP4   worldPos.x, ivMatrix[0], viewPos;\nDP4   worldPos.y, ivMatrix[1], viewPos;\nDP4   worldPos.z, ivMatrix[2], viewPos;\nDP4   worldPos.w, ivMatrix[3], viewPos;\nADD   noise.x, worldPos.x, worldPos.z;SUB   noise.y, worldPos.z, worldPos.x;MUL   noise, noise, 0.0001220703125;\nFRC   noise, noise;\nMUL   noise, noise, 64;\nARL   noiseAddr.x, noise.x;\nMOV   noise.x, fNoise[noiseAddr.x].x;\nARL   noiseAddr.x, noise.y;\nMOV   noise.y, fNoise[noiseAddr.x].y;\nMUL   noise, noise, turbulence.x;\nDP4   texCoord.x, texMatrix[0], iTexCoord;\nDP4   texCoord.y, texMatrix[1], iTexCoord;\nADD   oTexCoord0.xy, texCoord, noise;\nMOV   oTexCoord0.z, 0;\nMOV   oTexCoord0.w, 1;\nMUL   oTexCoord1.xy, texCoord, 0.125;\nMOV   oTexCoord1.zw, time.xxxw;\nMUL   oColour.xyz, iColour, lightAmbient;\nMOV   oColour.w, iColour.w;\nEND");
         if (this.glLoadIdentity != null) {
            int[][] var3 = OT.I(64, 256, 0, 4, 4, 3, 0.4F, false, (byte)25);
            int[][] var4 = OT.I(64, 256, 8, 4, 4, 3, 0.4F, false, (byte)80);
            int var5 = 0;
            this.glLoadMatrixf = new float['耀'];

            for(int var6 = 0; var6 < 256; ++var6) {
               int[] var7 = var3[var6];
               int[] var8 = var4[var6];

               for(int var9 = 0; var9 < 64; ++var9) {
                  this.glLoadMatrixf[var5++] = (float)var7[var9] / 4096.0F;
                  this.glLoadMatrixf[var5++] = (float)var8[var9] / 4096.0F;
               }
            }

            this.Z();
         }
      }

   }

   void method507(boolean var1) {
      if (this.glProgramLocalParameter4fARB != null) {
         this.glProgramLocalParameter4fARB.I('\u0000');
         this.I.C(1);
         OpenGL.glMatrixMode(5890);
         OpenGL.glLoadMatrixf(this.I.P.I, 0);
         OpenGL.glMatrixMode(5888);
         this.I.C(0);
         if (this.glBindProgramARB != this.I.E) {
            int var2 = this.I.E % 5000 * 128 / 5000;

            for(int var3 = 0; var3 < 64; ++var3) {
               OpenGL.glProgramLocalParameter4fvARB(34336, var3, this.glLoadMatrixf, var2);
               var2 += 2;
            }

            if (this.glProgramLocalParameter4fvARB.D) {
               this.Z = (float)(this.I.E % 4000) / 4000.0F;
            } else {
               OpenGL.glProgramLocalParameter4fARB(34336, 65, 0.0F, 0.0F, 0.0F, 1.0F);
            }

            this.glBindProgramARB = this.I.E;
         }
      }

   }

   void method512() {
      if (this.glProgramLocalParameter4fARB != null) {
         this.glProgramLocalParameter4fARB.I('\u0001');
         this.I.C(1);
         this.I.I((SN)null);
         this.I.C(0);
      }

   }

   void method517(int var1, int var2) {
      if (this.glProgramLocalParameter4fARB != null) {
         this.I.C(1);
         int var3;
         if ((var1 & 128) == 0) {
            if ((var2 & 1) == 1) {
               if (!this.glProgramLocalParameter4fvARB.D) {
                  var3 = this.I.E % 4000 * 16 / 4000;
                  this.I.I((SN)this.glProgramLocalParameter4fvARB.H[var3]);
                  OpenGL.glProgramLocalParameter4fARB(34336, 65, 0.0F, 0.0F, 0.0F, 1.0F);
               } else {
                  this.I.I((SN)this.glProgramLocalParameter4fvARB.J);
                  OpenGL.glProgramLocalParameter4fARB(34336, 65, this.Z, 0.0F, 0.0F, 1.0F);
               }
            } else {
               if (this.glProgramLocalParameter4fvARB.D) {
                  this.I.I((SN)this.glProgramLocalParameter4fvARB.J);
               } else {
                  this.I.I((SN)this.glProgramLocalParameter4fvARB.H[0]);
               }

               OpenGL.glProgramLocalParameter4fARB(34336, 65, 0.0F, 0.0F, 0.0F, 1.0F);
            }
         } else {
            this.I.I((SN)null);
         }

         this.I.C(0);
         if ((var1 & 64) == 0) {
            C[0] = this.I.k * this.I.g;
            C[1] = this.I.k * this.I.h;
            C[2] = this.I.k * this.I.TI;
            OpenGL.glProgramLocalParameter4fvARB(34336, 66, C, 0);
         } else {
            OpenGL.glProgramLocalParameter4fARB(34336, 66, 1.0F, 1.0F, 1.0F, 1.0F);
         }

         var3 = var1 & 3;
         if (var3 == 2) {
            OpenGL.glProgramLocalParameter4fARB(34336, 64, 0.05F, 1.0F, 1.0F, 1.0F);
         } else if (var3 == 3) {
            OpenGL.glProgramLocalParameter4fARB(34336, 64, 0.1F, 1.0F, 1.0F, 1.0F);
         } else {
            OpenGL.glProgramLocalParameter4fARB(34336, 64, 0.025F, 1.0F, 1.0F, 1.0F);
         }
      }

   }

   void method515(int var1, int var2) {
      if (this.glProgramLocalParameter4fARB != null) {
         this.I.C(1);
         int var3;
         if ((var1 & 128) == 0) {
            if ((var2 & 1) == 1) {
               if (!this.glProgramLocalParameter4fvARB.D) {
                  var3 = this.I.E % 4000 * 16 / 4000;
                  this.I.I((SN)this.glProgramLocalParameter4fvARB.H[var3]);
                  OpenGL.glProgramLocalParameter4fARB(34336, 65, 0.0F, 0.0F, 0.0F, 1.0F);
               } else {
                  this.I.I((SN)this.glProgramLocalParameter4fvARB.J);
                  OpenGL.glProgramLocalParameter4fARB(34336, 65, this.Z, 0.0F, 0.0F, 1.0F);
               }
            } else {
               if (this.glProgramLocalParameter4fvARB.D) {
                  this.I.I((SN)this.glProgramLocalParameter4fvARB.J);
               } else {
                  this.I.I((SN)this.glProgramLocalParameter4fvARB.H[0]);
               }

               OpenGL.glProgramLocalParameter4fARB(34336, 65, 0.0F, 0.0F, 0.0F, 1.0F);
            }
         } else {
            this.I.I((SN)null);
         }

         this.I.C(0);
         if ((var1 & 64) == 0) {
            C[0] = this.I.k * this.I.g;
            C[1] = this.I.k * this.I.h;
            C[2] = this.I.k * this.I.TI;
            OpenGL.glProgramLocalParameter4fvARB(34336, 66, C, 0);
         } else {
            OpenGL.glProgramLocalParameter4fARB(34336, 66, 1.0F, 1.0F, 1.0F, 1.0F);
         }

         var3 = var1 & 3;
         if (var3 == 2) {
            OpenGL.glProgramLocalParameter4fARB(34336, 64, 0.05F, 1.0F, 1.0F, 1.0F);
         } else if (var3 == 3) {
            OpenGL.glProgramLocalParameter4fARB(34336, 64, 0.1F, 1.0F, 1.0F, 1.0F);
         } else {
            OpenGL.glProgramLocalParameter4fARB(34336, 64, 0.025F, 1.0F, 1.0F, 1.0F);
         }
      }

   }

   void method516(int var1, int var2) {
      if (this.glProgramLocalParameter4fARB != null) {
         this.I.C(1);
         int var3;
         if ((var1 & 128) == 0) {
            if ((var2 & 1) == 1) {
               if (!this.glProgramLocalParameter4fvARB.D) {
                  var3 = this.I.E % 4000 * 16 / 4000;
                  this.I.I((SN)this.glProgramLocalParameter4fvARB.H[var3]);
                  OpenGL.glProgramLocalParameter4fARB(34336, 65, 0.0F, 0.0F, 0.0F, 1.0F);
               } else {
                  this.I.I((SN)this.glProgramLocalParameter4fvARB.J);
                  OpenGL.glProgramLocalParameter4fARB(34336, 65, this.Z, 0.0F, 0.0F, 1.0F);
               }
            } else {
               if (this.glProgramLocalParameter4fvARB.D) {
                  this.I.I((SN)this.glProgramLocalParameter4fvARB.J);
               } else {
                  this.I.I((SN)this.glProgramLocalParameter4fvARB.H[0]);
               }

               OpenGL.glProgramLocalParameter4fARB(34336, 65, 0.0F, 0.0F, 0.0F, 1.0F);
            }
         } else {
            this.I.I((SN)null);
         }

         this.I.C(0);
         if ((var1 & 64) == 0) {
            C[0] = this.I.k * this.I.g;
            C[1] = this.I.k * this.I.h;
            C[2] = this.I.k * this.I.TI;
            OpenGL.glProgramLocalParameter4fvARB(34336, 66, C, 0);
         } else {
            OpenGL.glProgramLocalParameter4fARB(34336, 66, 1.0F, 1.0F, 1.0F, 1.0F);
         }

         var3 = var1 & 3;
         if (var3 == 2) {
            OpenGL.glProgramLocalParameter4fARB(34336, 64, 0.05F, 1.0F, 1.0F, 1.0F);
         } else if (var3 == 3) {
            OpenGL.glProgramLocalParameter4fARB(34336, 64, 0.1F, 1.0F, 1.0F, 1.0F);
         } else {
            OpenGL.glProgramLocalParameter4fARB(34336, 64, 0.025F, 1.0F, 1.0F, 1.0F);
         }
      }

   }

   void method506(boolean var1) {
      if (this.glProgramLocalParameter4fARB != null) {
         this.glProgramLocalParameter4fARB.I('\u0000');
         this.I.C(1);
         OpenGL.glMatrixMode(5890);
         OpenGL.glLoadMatrixf(this.I.P.I, 0);
         OpenGL.glMatrixMode(5888);
         this.I.C(0);
         if (this.glBindProgramARB != this.I.E) {
            int var2 = this.I.E % 5000 * 128 / 5000;

            for(int var3 = 0; var3 < 64; ++var3) {
               OpenGL.glProgramLocalParameter4fvARB(34336, var3, this.glLoadMatrixf, var2);
               var2 += 2;
            }

            if (this.glProgramLocalParameter4fvARB.D) {
               this.Z = (float)(this.I.E % 4000) / 4000.0F;
            } else {
               OpenGL.glProgramLocalParameter4fARB(34336, 65, 0.0F, 0.0F, 0.0F, 1.0F);
            }

            this.glBindProgramARB = this.I.E;
         }
      }

   }

   void method514(SN var1, int var2) {
      this.I.I(var1);
      this.I.I(var2);
   }

   void method519(SN var1, int var2) {
      this.I.I(var1);
      this.I.I(var2);
   }

   boolean method520() {
      return true;
   }
}
