public class HK extends YG {
   public HK() {
      super(1, true);
   }

   int[] Z(int var1, int var2) {
      try {
         int[] var3 = this.P.I(var1, 233651340);
         if (this.P.D) {
            int[][] var4 = this.I(0, var1, (byte)8);
            int[] var5 = var4[0];
            int[] var6 = var4[1];
            int[] var7 = var4[2];

            for(int var8 = 0; var8 < -1474554145 * WJ.C; ++var8) {
               var3[var8] = (var7[var8] + var6[var8] + var5[var8]) / 3;
            }
         }

         return var3;
      } catch (RuntimeException var9) {
         throw DQ.I(var9, "agt.i(" + ')');
      }
   }

   int[] append(int var1) {
      int[] var2 = this.P.I(var1, 1878231521);
      if (this.P.D) {
         int[][] var3 = this.I(0, var1, (byte)8);
         int[] var4 = var3[0];
         int[] var5 = var3[1];
         int[] var6 = var3[2];

         for(int var7 = 0; var7 < -1474554145 * WJ.C; ++var7) {
            var2[var7] = (var6[var7] + var5[var7] + var4[var7]) / 3;
         }
      }

      return var2;
   }

   int[] toString(int var1) {
      int[] var2 = this.P.I(var1, 1745127751);
      if (this.P.D) {
         int[][] var3 = this.I(0, var1, (byte)8);
         int[] var4 = var3[0];
         int[] var5 = var3[1];
         int[] var6 = var3[2];

         for(int var7 = 0; var7 < -1474554145 * WJ.C; ++var7) {
            var2[var7] = (var6[var7] + var5[var7] + var4[var7]) / 3;
         }
      }

      return var2;
   }
}
