public class BB {
   public boolean I = false;
   static JQ Z = new JQ(64);
   static int J = 0;
   public int C = -2036085851;
   public int B = 843301217;
   public int D = -1449508928;
   public int F = -603129954;
   public int S = 1561394240;
   static KJ A;
   public boolean E = false;
   public static KJ G;
   public static byte H;

   void J(REI var1, int var2, int var3, int var4) {
      try {
         if (1 == var2) {
            this.C = var1.C() * 2036085851;
            if (39181267 * this.C == 65535) {
               this.C = -2036085851;
            }
         } else if (var2 == 2) {
            this.S = (var1.C() + 1) * 1635009521;
            this.D = (var1.C() + 1) * 2057726207;
         } else if (3 == var2) {
            var1.S(-12558881);
         } else if (var2 == 4) {
            this.F = var1.I() * -301564977;
         } else if (var2 == 5) {
            this.B = var1.I() * 843301217;
         } else if (var2 == 6) {
            this.I = true;
         } else if (7 == var2) {
            this.E = true;
         }

      } catch (RuntimeException var6) {
         throw DQ.I(var6, "he.p(" + ')');
      }
   }

   void I(REI var1, int var2, byte var3) {
      try {
         while(true) {
            int var4 = var1.I();
            if (var4 == 0) {
               if (var3 != 8) {
                  ;
               }

               return;
            }

            this.J(var1, var4, var2, 1303074058);
         }
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "he.b(" + ')');
      }
   }

   public static int I(int var0, int var1) {
      try {
         var0 = (var0 >>> 1 & 1431655765) + (var0 & 1431655765);
         var0 = (var0 & 858993459) + (var0 >>> 2 & 858993459);
         var0 = var0 + (var0 >>> 4) & 252645135;
         var0 += var0 >>> 8;
         var0 += var0 >>> 16;
         return var0 & 255;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "he.b(" + ')');
      }
   }

   public static XE I(int var0) {
      try {
         return EDI.B;
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "he.g(" + ')');
      }
   }

   public static void I(int var0, int var1, int var2, int var3) {
      try {
         XP var4 = XEI.mI.I(681479919);
         int var5 = var1 + -1760580017 * var4.I;
         int var6 = var2 + 283514611 * var4.Z;
         if (XEI.mI.T(-1611682495) != null && XEI.mI.R(-257896295) != WS.Z && var1 >= 0 && var2 >= 0 && var1 < XEI.mI.Z(-1890552944) && var2 < XEI.mI.C(-1685955624)) {
            long var7 = (long)(var0 << 28 | var6 << 14 | var5);
            BG var9 = (BG)XEI.LI.I(var7);
            if (var9 == null) {
               XEI.mI.T(-1611682495).D(var0, var1, var2, (byte)86);
            } else {
               KE var10 = (KE)var9.S.Z(1766612795);
               if (var10 == null) {
                  XEI.mI.T(-1611682495).D(var0, var1, var2, (byte)28);
               } else {
                  MR var11 = (MR)XEI.mI.T(-1611682495).D(var0, var1, var2, (byte)119);
                  if (var11 == null) {
                     var11 = new MR(XEI.mI.T(-1611682495), var1 << 265, XEI.mI.T(-1611682495).G[var0].I(var1, var2, (byte)-15), var2 << 265, var0, var0);
                  } else {
                     var11.R = 2004197937;
                     var11.U = -474510257;
                     var11.H = XEI.mI.T(-1611682495);
                  }

                  var11.V = 397105967 * var10.S;
                  var11.P = -2063762687 * var10.J;

                  label64:
                  while(true) {
                     KE var12 = (KE)var9.S.B(49146);
                     if (var12 == null) {
                        if (var3 <= -111188266) {
                           throw new IllegalStateException();
                        }
                        break;
                     }

                     if (1768239597 * var12.S != -441234013 * var11.V) {
                        var11.U = 1259142109 * var12.S;
                        var11.Q = -1936319903 * var12.J;

                        while(true) {
                           KE var13 = (KE)var9.S.B(49146);
                           if (var13 == null) {
                              if (var3 <= -111188266) {
                                 return;
                              }
                              break label64;
                           }

                           if (var13.S * 1768239597 != -441234013 * var11.V && var13.S * 1768239597 != var11.U * -909380271) {
                              var11.R = -843548765 * var13.S;
                              var11.T = var13.J * -597974721;
                           }
                        }
                     }

                     if (var3 <= -111188266) {
                        return;
                     }
                  }

                  int var15 = NQ.I(256 + (var1 << 9), 256 + (var2 << 9), var0, -859881334);
                  var11.I((float)(var1 << 265), (float)var15, (float)(var2 << 265));
                  var11.O = 0;
                  var11.K = (byte)var0;
                  var11.L = (byte)var0;
                  if (XEI.mI.M(361928521).I(var1, var2, -1635198415)) {
                     var11.L = (byte)(var11.L + 1);
                  }

                  XEI.mI.T(-1611682495).I(var0, var1, var2, var15, var11, 1648403764);
               }
            }
         }

      } catch (RuntimeException var14) {
         throw DQ.I(var14, "he.jy(" + ')');
      }
   }

   public static final void I(OSI var0, boolean var1, boolean var2, int var3) {
      try {
         int var4 = var0.S * -1617025021;
         int var5 = (int)(7051297995265073167L * var0.Z);
         var0.I(-1460969981);
         if (var1) {
            HFI.I(var4, -2042512871);
         }

         HJ.I(var4, (byte)-97);
         HSI var6 = AZI.I(var5, (byte)18);
         if (var6 != null) {
            VEI.I(var6, 999173);
         }

         QJ.B(-1483926701);
         if (!var2 && XEI.xC * -257444687 != -1) {
            NDI.I(-257444687 * XEI.xC, 1, -80338519);
         }

         AY var7 = new AY(XEI.yC);

         for(OSI var8 = (OSI)var7.I(-2012602178); var8 != null; var8 = (OSI)var7.next()) {
            if (!var8.Z(-629325116)) {
               var8 = (OSI)var7.I(-2012602178);
               if (var8 == null) {
                  if (var3 == -113822480) {
                     ;
                  }
                  break;
               }
            }

            if (var8.J * 27137839 == 3) {
               int var9 = (int)(7051297995265073167L * var8.Z);
               if (var9 >>> 16 == var4) {
                  I(var8, true, var2, -113822480);
               }
            }
         }

      } catch (RuntimeException var10) {
         throw DQ.I(var10, "he.lw(" + ')');
      }
   }

   public static final void I(int var0, int var1, int var2, int var3, int var4, byte var5) {
      try {
         YJI.J = 446226445 * var0;
         KSI.F = var1 * 2019382975;
         GB.H = var2 * 584728181;
         NI.L = -759692387 * var3;
         VW.I = -2064447825 * var4;
         if (VW.I * 1179258959 >= 100) {
            int var6 = -589460992 * YJI.J + 256;
            int var7 = 1647476224 * KSI.F + 256;
            int var8 = NQ.I(var6, var7, EJI.Z * 1855729883, -1477224800) - GB.H * 771695069;
            int var9 = var6 - RR.Q * -1740717447;
            int var10 = var8 - L.B * 1449634147;
            int var11 = var7 - -299812095 * RZ.H;
            int var12 = (int)Math.sqrt((double)(var11 * var11 + var9 * var9));
            XEI.VZ = ((int)(Math.atan2((double)var10, (double)var12) * 2607.5945876176133D) & 16383) * -648269561;
            CZ.I = ((int)(Math.atan2((double)var9, (double)var11) * -2607.5945876176133D) & 16383) * -1587695039;
            TF.C = 0;
            if (-104436553 * XEI.VZ < 1024) {
               XEI.VZ = 1891900416;
            }

            if (XEI.VZ * -104436553 > 3072) {
               XEI.VZ = 1380733952;
            }
         }

         EE.V = 2090692627;
         AV.I = -1001372047;
         B.XZ = 178575833;
      } catch (RuntimeException var13) {
         throw DQ.I(var13, "he.hs(" + ')');
      }
   }

   public static short I(int var0, byte var1) {
      try {
         int var2 = var0 >> 10 & 63;
         int var3 = var0 >> 3 & 112;
         int var4 = var0 & 127;
         var3 = var4 <= 64 ? var3 * var4 >> 7 : var3 * (127 - var4) >> 7;
         int var5 = var3 + var4;
         int var6;
         if (var5 != 0) {
            var6 = (var3 << 8) / var5;
         } else {
            var6 = var3 << 1;
         }

         return (short)(var2 << 10 | var6 >> 4 << 7 | var5);
      } catch (RuntimeException var8) {
         throw DQ.I(var8, "he.i(" + ')');
      }
   }

   public static String I(CharSequence var0, int var1) {
      try {
         return FV.I(var0, (UZI)null, (byte)-6);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "he.p(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         CU var2 = var0.c ? var0.M : var0.L;
         HSI var3 = var2.Z;
         X var4 = var2.I;
         GCI.I(var3, var4, var0, (byte)-37);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "he.dj(" + ')');
      }
   }

   static void Z(int var0) {
      try {
         QW.I(false, 1336561252);
         if (1265667685 * GN.j >= 0 && 1265667685 * GN.j != 0) {
            WR.I(1265667685 * GN.j, false, 622850291);
            GN.j = -485258093;
         }

      } catch (RuntimeException var2) {
         throw DQ.I(var2, "he.cs(" + ')');
      }
   }
}
