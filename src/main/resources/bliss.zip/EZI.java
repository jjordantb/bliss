public class EZI {
   KJ B;
   int Z;
   HL[] append;
   public static FQ I;

   public EZI(ZV var1, XW var2, KJ var3, boolean var4) {
      this.B = var3;
      this.Z = this.B.F(-1006924897 * II.V.y, -1837337583) * 1005943745;
      if (var4) {
         this.append = new HL[this.Z * 589337665];

         for(int var5 = 0; var5 < this.Z * 589337665; ++var5) {
            KJ var7 = this.B;
            byte[] var6;
            synchronized(this.B) {
               var6 = this.B.I(-1006924897 * II.V.y, var5, (byte)-117);
            }

            HL var9 = new HL();
            if (var6 != null) {
               var9.Z(new REI(var6), -2124220647);
            }

            this.append[var5] = var9;
         }
      }

   }

   public HL I(int var1, int var2) {
      try {
         return var1 < 0 ? new HL() : this.append[var1];
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "ur.a(" + ')');
      }
   }

   static PK I(byte var0) {
      try {
         return PK.G * -848307417 == 0 ? new PK() : PK.K[(PK.G -= 265413783) * -848307417];
      } catch (RuntimeException var2) {
         throw DQ.I(var2, "ur.a(" + ')');
      }
   }

   static void I(QEI var0, int var1, int var2) {
      try {
         XP var3 = XEI.mI.I(681479919);
         boolean var4 = var0.C(1) == 1;
         if (var4) {
            C.E[(C.A += 867608709) * -1281683379 - 1] = var1;
         }

         int var5 = var0.C(2);
         PEI var6 = XEI.MC[var1];
         if (var5 == 0) {
            if (var4) {
               var6.FZ = false;
            } else {
               if (-442628795 * XEI.i == var1) {
                  throw new RuntimeException();
               }

               IV var7 = C.S[var1] = new IV();
               var7.B = 1896571807 * ((var6.v[0] + var3.Z * 283514611 >> 6) + (var6.K << 28) + (-1760580017 * var3.I + var6.YI[0] >> 6 << 14));
               if (-1 != var6.EZ * 1208589843) {
                  var7.Z = var6.EZ * 1714576017;
               } else {
                  var7.Z = var6.n.I((byte)0) * 481306955;
               }

               var7.I = var6.u * 1969382475;
               var7.C = var6.qI;
               var7.D = var6.GZ;
               if (var6.BZ * 780357347 > 0) {
                  VJI.I(var6, (byte)-66);
               }

               XEI.MC[var1] = null;
               if (var0.C(1) != 0) {
                  GZI.I(var0, var1, 2107350837);
               }
            }
         } else {
            int var8;
            int var9;
            int var15;
            if (var5 == 1) {
               var15 = var0.C(3);
               var8 = var6.YI[0];
               var9 = var6.v[0];
               if (var15 == 0) {
                  --var8;
                  --var9;
               } else if (var15 == 1) {
                  --var9;
               } else if (2 == var15) {
                  ++var8;
                  --var9;
               } else if (var15 == 3) {
                  --var8;
               } else if (4 == var15) {
                  ++var8;
               } else if (5 == var15) {
                  --var8;
                  ++var9;
               } else if (6 == var15) {
                  ++var9;
               } else if (7 == var15) {
                  ++var8;
                  ++var9;
               }

               if (var4) {
                  var6.JZ = var8 * -586951847;
                  var6.SZ = var9 * -682750645;
                  var6.FZ = true;
               } else {
                  var6.I(var8, var9, C.B[var1], -2105155066);
               }
            } else if (2 == var5) {
               var15 = var0.C(4);
               var8 = var6.YI[0];
               var9 = var6.v[0];
               if (var15 == 0) {
                  var8 -= 2;
                  var9 -= 2;
               } else if (1 == var15) {
                  --var8;
                  var9 -= 2;
               } else if (2 == var15) {
                  var9 -= 2;
               } else if (3 == var15) {
                  ++var8;
                  var9 -= 2;
               } else if (var15 == 4) {
                  var8 += 2;
                  var9 -= 2;
               } else if (5 == var15) {
                  var8 -= 2;
                  --var9;
               } else if (6 == var15) {
                  var8 += 2;
                  --var9;
               } else if (var15 == 7) {
                  var8 -= 2;
               } else if (8 == var15) {
                  var8 += 2;
               } else if (var15 == 9) {
                  var8 -= 2;
                  ++var9;
               } else if (var15 == 10) {
                  var8 += 2;
                  ++var9;
               } else if (11 == var15) {
                  var8 -= 2;
                  var9 += 2;
               } else if (12 == var15) {
                  --var8;
                  var9 += 2;
               } else if (var15 == 13) {
                  var9 += 2;
               } else if (14 == var15) {
                  ++var8;
                  var9 += 2;
               } else if (var15 == 15) {
                  var8 += 2;
                  var9 += 2;
               }

               if (var4) {
                  var6.JZ = var8 * -586951847;
                  var6.SZ = var9 * -682750645;
                  var6.FZ = true;
               } else {
                  var6.I(var8, var9, C.B[var1], -2092850777);
               }
            } else {
               var15 = var0.C(1);
               int var10;
               int var11;
               int var12;
               int var13;
               if (var15 == 0) {
                  var8 = var0.C(12);
                  var9 = var8 >> 10;
                  var10 = var8 >> 5 & 31;
                  if (var10 > 15) {
                     var10 -= 32;
                  }

                  var11 = var8 & 31;
                  if (var11 > 15) {
                     var11 -= 32;
                  }

                  var12 = var6.YI[0] + var10;
                  var13 = var6.v[0] + var11;
                  if (var4) {
                     var6.JZ = -586951847 * var12;
                     var6.SZ = var13 * -682750645;
                     var6.FZ = true;
                  } else {
                     var6.I(var12, var13, C.B[var1], -2123912900);
                  }

                  var6.K = var6.L = (byte)(var6.K + var9 & 3);
                  if (XEI.mI.M(-232228879).I(var12, var13, 1039567132)) {
                     var6.L = (byte)(var6.L + 1);
                  }

                  if (-442628795 * XEI.i == var1 && EJI.Z * 1855729883 != var6.K) {
                     EJI.Z = -85701805 * var6.K;
                  }
               } else {
                  var8 = var0.C(30);
                  var9 = var8 >> 28;
                  var10 = var8 >> 14 & 16383;
                  var11 = var8 & 16383;
                  var12 = (var10 + -1760580017 * var3.I + var6.YI[0] & 16383) - var3.I * -1760580017;
                  var13 = (var11 + var3.Z * 283514611 + var6.v[0] & 16383) - var3.Z * 283514611;
                  if (var4) {
                     var6.JZ = -586951847 * var12;
                     var6.SZ = -682750645 * var13;
                     var6.FZ = true;
                  } else {
                     var6.I(var12, var13, C.B[var1], -2073670245);
                  }

                  var6.K = var6.L = (byte)(var9 + var6.K & 3);
                  if (XEI.mI.M(934483887).I(var12, var13, 624472586)) {
                     var6.L = (byte)(var6.L + 1);
                  }

                  if (var1 == XEI.i * -442628795) {
                     EJI.Z = -85701805 * var6.K;
                  }
               }
            }
         }

      } catch (RuntimeException var14) {
         throw DQ.I(var14, "ur.i(" + ')');
      }
   }
}
