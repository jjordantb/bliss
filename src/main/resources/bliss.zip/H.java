import java.io.File;

public class H {
   static int B = 4;
   R[] I;
   static int F = 256;
   String Z;
   R[] C;
   G[] D;
   static int append = 2;

   void B(byte[] var1, int var2) throws Exception_Sub3 {
      try {
         D var3 = new D(var1);
         int var4 = var3.Z(1157029171);
         if (var4 != 4) {
            throw new Exception_Sub3(this, var4, 4);
         } else {
            this.Z = var3.I(1509343502);
            this.I = new R[var3.Z(725581167)];
            this.C = new R[var3.Z(1366230292)];
            this.D = new G[var3.Z(594275655)];

            int var5;
            for(var5 = 0; var5 < this.I.length; ++var5) {
               this.I[var5] = new R();
               this.I[var5].I((D)var3, (byte)107);
            }

            for(var5 = 0; var5 < this.C.length; ++var5) {
               this.C[var5] = new R();
               this.C[var5].I((D)var3, (byte)107);
            }

            for(var5 = 0; var5 < this.D.length; ++var5) {
               this.D[var5] = new G();
               this.D[var5].I(var3, (byte)-15);
            }

         }
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "el.a(" + ')');
      }
   }

   public H(byte[] var1) throws Exception_Sub3 {
      this.B(var1, 1575472907);
   }

   static final void I(OU var0, int var1) {
      try {
         String var2 = (String)var0.S[(var0.A -= 969361751) * -203050393];
         boolean var3 = RT.K.I(new File(var2), -714101418);
         var0.H[(var0.J += -391880689) * 681479919 - 1] = var3 ? 1 : 0;
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "el.agp(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.i.I(-1741518508);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "el.aks(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         byte var2 = UA.F.K;
         SF var3 = UA.F.I().I;
         XP var4 = XEI.mI.I(681479919);
         int var5 = ((int)var3.I >> 9) + -1760580017 * var4.I;
         int var6 = ((int)var3.Z >> 9) + 283514611 * var4.Z;
         var0.H[(var0.J += -391880689) * 681479919 - 1] = (var5 << 14) + (var2 << 28) + var6;
      } catch (RuntimeException var7) {
         throw DQ.I(var7, "el.tt(" + ')');
      }
   }
}
