public class B {
   static B I = new B(93);
   static B Z = new B(64);
   static B C = new B(9);
   static B B = new B(63);
   static B D = new B(108);
   static B F = new B(119);
   static B J = new B(46);
   static B S = new B(111);
   static B A = new B(45);
   static B E = new B(103);
   public static B G = new B(13);
   static B H = new B(40);
   static B K = new B(116);
   static B L = new B(120);
   static B M = new B(41);
   static B N = new B(78);
   static B O = new B(33);
   static B P = new B(58);
   static B Q = new B(124);
   static B R = new B(24);
   static B T = new B(74);
   static B U = new B(106);
   static B V = new B(99);
   static B W = new B(44);
   public static B X = new B(75);
   static B Y = new B(62);
   static B i = new B(50);
   static B z = new B(71);
   static B c = new B(36);
   static B b = new B(114);
   static B d = new B(29);
   static B f = new B(5);
   static B j = new B(21);
   static B s = new B(2);
   static B a = new B(87);
   static B e = new B(15);
   static B g = new B(53);
   static B h = new B(122);
   static B k = new B(28);
   static B l = new B(91);
   static B m = new B(68);
   static B n = new B(95);
   public static B o = new B(82);
   public static B p = new B(31);
   static B q = new B(79);
   static B r = new B(70);
   static B t = new B(34);
   static B u = new B(37);
   public static B v = new B(1);
   static B w = new B(7);
   static B x = new B(109);
   static B y = new B(84);
   static B II = new B(90);
   static B ZI = new B(72);
   static B CI = new B(8);
   static B BI = new B(101);
   static B DI = new B(20);
   static B FI = new B(54);
   static B JI = new B(11);
   static B SI = new B(55);
   static B AI = new B(17);
   static B EI = new B(49);
   static B GI = new B(10);
   static B HI = new B(67);
   static B KI = new B(102);
   static B LI = new B(43);
   static B MI = new B(60);
   static B NI = new B(83);
   static B OI = new B(73);
   static B PI = new B(0);
   public static B QI = new B(104);
   static B RI = new B(96);
   static B TI = new B(48);
   static B UI = new B(35);
   static B VI = new B(86);
   static B WI = new B(16);
   static B XI = new B(97);
   static B YI = new B(22);
   static B iI = new B(77);
   static B zI = new B(57);
   static B cI = new B(123);
   static B bI = new B(76);
   static B dI = new B(100);
   static B fI = new B(121);
   static B jI = new B(38);
   static B sI = new B(65);
   static B aI = new B(56);
   static B eI = new B(51);
   static B gI = new B(89);
   static B hI = new B(26);
   static B kI = new B(52);
   static B lI = new B(27);
   static B mI = new B(12);
   static B nI = new B(98);
   static B oI = new B(19);
   static B pI = new B(23);
   public static B qI = new B(80);
   static B rI = new B(85);
   static B tI = new B(39);
   static B uI = new B(92);
   static B vI = new B(112);
   static B wI = new B(118);
   static B xI = new B(6);
   static B yI = new B(61);
   static B IZ = new B(115);
   static B ZZ = new B(42);
   static B CZ = new B(94);
   static B BZ = new B(117);
   static B DZ = new B(110);
   static B FZ = new B(107);
   static B JZ = new B(105);
   static B SZ = new B(113);
   static B AZ = new B(30);
   static B EZ = new B(69);
   static B GZ = new B(47);
   static B HZ = new B(18);
   static B KZ = new B(81);
   static B LZ = new B(14);
   static B MZ = new B(3);
   public int NZ;
   static B OZ = new B(88);
   static B PZ = new B(59);
   static B QZ = new B(66);
   public static B RZ = new B(4);
   static B TZ = new B(32);
   static B UZ = new B(25);
   public static int VZ;
   static BY[] WZ;
   public static int XZ;

   B(int var1) {
      this.NZ = var1 * -1700037047;
   }

   static final void I(OU var0, byte var1) {
      try {
         HSI var2 = AZI.I(var0.H[(var0.J -= -391880689) * 681479919], (byte)-124);
         var2.SC = null;
         var2.AC = null;
         VEI.I(var2, -1793194156);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "eb.bj(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         WK.Z(var0.H[(var0.J -= -391880689) * 681479919], -1482618001);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "eb.xy(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         var0.J -= -783761378;
         int var2 = var0.H[681479919 * var0.J];
         int var3 = var0.H[var0.J * 681479919 + 1];
         var0.H[(var0.J += -391880689) * 681479919 - 1] = GSI.OZ.I(var2, 537859491).L[var3];
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "eb.acu(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         if (!FT.P.method5032()) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 3;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.E.method5612(var2, 1352882135);
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "eb.aou(" + ')');
      }
   }

   static final void B(OU var0, int var1) {
      try {
         if (YX.I) {
            BY[] var2 = BA.I((byte)-22);
            var0.H[(var0.J += -391880689) * 681479919 - 1] = var2.length;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "eb.aec(" + ')');
      }
   }

   static final void I(OU var0, short var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = TF.I(1029121048);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "eb.adw(" + ')');
      }
   }
}
