import java.io.IOException;

public class C {
   static int I = 0;
   static int Z = 0;
   static byte[] C = new byte[2048];
   static byte[] B = new byte[2048];
   static REI[] D = new REI[2048];
   static int[] F = new int[2048];
   static int[] J = new int[2048];
   static int append = 1;
   static int out = 2;
   static IV[] S = new IV[2048];
   static int A = 0;
   static int[] E = new int[2048];

   C() throws Throwable {
      throw new Error();
   }

   public static void I(REI var0, byte var1) {
      try {
         byte[] var2 = new byte[24];

         try {
            ZE.P.I(0L);
            ZE.P.I(var2, 430767444);

            int var3;
            for(var3 = 0; var3 < 24 && var2[var3] == 0; ++var3) {
               ;
            }

            if (var3 >= 24) {
               throw new IOException();
            }
         } catch (Exception var5) {
            for(int var4 = 0; var4 < 24; ++var4) {
               var2[var4] = -1;
            }
         }

         var0.I((byte[])var2, 0, 24, (short)-371);
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "ak.r(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-13);
         X var4 = IU.F[var2 >> 16];
         ID.I(var3, var4, var0, (byte)-123);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "ak.jn(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         QQ.I(var0.H[(var0.J -= -391880689) * 681479919], (byte)0);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ak.aef(" + ')');
      }
   }

   static final void I(OU var0, byte var1) {
      try {
         System.out.println(var0.S[(var0.A -= 969361751) * -203050393]);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "ak.afw(" + ')');
      }
   }
}
