public class AS {
   static int Z = 1;
   static int append = 4;
   static int toString = 0;
   static int I = 3;
   static int C = 2;
   static int B = 6;
   static int D = 7;
   public static KJ F;
   public static int J;

   AS() throws Throwable {
      throw new Error();
   }

   static final void I(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         HSI var3 = AZI.I(var2, (byte)-1);
         X var4 = IU.F[var2 >> 16];
         KJ.I(var3, var4, var0, 1204631441);
      } catch (RuntimeException var5) {
         throw DQ.I(var5, "kw.ni(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
      try {
         int var2 = var0.H[(var0.J -= -391880689) * 681479919];
         ZQ var3 = PF.I(var2, (byte)-81);
         if (var3 != null) {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = -877023375 * var3.C;
            var0.S[(var0.A += 969361751) * -203050393 - 1] = var3.A;
            KQ var4 = var3.D(-1575528470);
            var0.H[(var0.J += -391880689) * 681479919 - 1] = var4.Z * 1675394033;
            var0.S[(var0.A += 969361751) * -203050393 - 1] = var4.I;
            var0.H[(var0.J += -391880689) * 681479919 - 1] = var3.I * -945794709;
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 512449113 * var3.E;
            var0.S[(var0.A += 969361751) * -203050393 - 1] = var3.S;
         } else {
            var0.H[(var0.J += -391880689) * 681479919 - 1] = -1;
            var0.S[(var0.A += 969361751) * -203050393 - 1] = "";
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
            var0.S[(var0.A += 969361751) * -203050393 - 1] = "";
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
            var0.H[(var0.J += -391880689) * 681479919 - 1] = 0;
            var0.S[(var0.A += 969361751) * -203050393 - 1] = "";
         }

      } catch (RuntimeException var5) {
         throw DQ.I(var5, "kw.alq(" + ')');
      }
   }

   static final void C(OU var0, int var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.Q.I(-391880689) ? 1 : 0;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "kw.anw(" + ')');
      }
   }

   static final void I(HSI var0, X var1, OU var2, short var3) {
      try {
         var2.J -= -1175642067;
         int var4 = var2.H[var2.J * 681479919];
         short var5 = (short)var2.H[1 + 681479919 * var2.J];
         short var6 = (short)var2.H[2 + 681479919 * var2.J];
         if (var4 >= 0 && var4 < 5) {
            var0.I(var4, var5, var6, -1261920411);
            VEI.I(var0, 1064187264);
            if (var0.a * -1309843523 == -1 && !var1.I) {
               NFI.I(-440872681 * var0.V, var4, (byte)1);
            }
         }

      } catch (RuntimeException var7) {
         throw DQ.I(var7, "kw.gy(" + ')');
      }
   }
}
