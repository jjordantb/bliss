public class AE {
   public AE I;
   public long Z;
   public AE C;
   public static int B;
   static int D;
   static int F;

   public void I(int var1) {
      try {
         if (this.C != null) {
            this.C.I = this.I;
            this.I.C = this.C;
            this.I = null;
            this.C = null;
         }

      } catch (RuntimeException var3) {
         throw DQ.I(var3, "mk.t(" + ')');
      }
   }

   public boolean Z(int var1) {
      try {
         return this.C != null;
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "mk.h(" + ')');
      }
   }

   static final void I(OU var0, int var1) {
      try {
         var0.J -= -783761378;
         TK var2 = AN.L.I(var0.H[681479919 * var0.J], 894186762);
         int var3 = var0.H[681479919 * var0.J + 1];
         int var4 = -1;

         for(int var5 = 0; var5 < -408056823 * var2.M; ++var5) {
            if (var3 == var2.G[var5]) {
               var4 = var2.K[var5];
               break;
            }
         }

         var0.H[(var0.J += -391880689) * 681479919 - 1] = var4;
      } catch (RuntimeException var6) {
         throw DQ.I(var6, "mk.tu(" + ')');
      }
   }

   static final void Z(OU var0, int var1) {
   }

   static final void I(OU var0, byte var1) {
      try {
         var0.H[(var0.J += -391880689) * 681479919 - 1] = FW.J.c.C((byte)23);
      } catch (RuntimeException var3) {
         throw DQ.I(var3, "mk.ajm(" + ')');
      }
   }

   public static BB I(int var0, int var1) {
      try {
         BB var2 = (BB)BB.Z.I((long)var0);
         if (var2 != null) {
            return var2;
         } else {
            byte[] var3 = BB.A.I(0, var0, (byte)-64);
            var2 = new BB();
            if (var3 != null) {
               var2.I(new REI(var3), var0, (byte)-27);
            }

            BB.Z.I(var2, (long)var0);
            return var2;
         }
      } catch (RuntimeException var4) {
         throw DQ.I(var4, "mk.f(" + ')');
      }
   }
}
