package loading;

import java.util.HashMap;


/**
 * Wrapper class for readability
 *
 * @author Parametric
 */
public class Configs extends HashMap<String, String> { }
