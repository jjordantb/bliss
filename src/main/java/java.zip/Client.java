public class Client {

    public static String getUsername() {
        return null;
    }

}
