public interface class311 {
   int method444(int var1);

   class972 method448(int var1);
}
