public interface class311 {
   int method444(int var1);

   class972 method445();

   int method446();

   class972 method447();

   class972 method448(int var1);

   class972 method449();
}
