public interface class331 {
   int method89(int var1);

   int method90();

   int method91();
}
