public interface class331 {
   int method89(int var1);
}
