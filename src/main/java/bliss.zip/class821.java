public interface class821 {
   String method2994(class103 var1, int[] var2, long var3);
}
