public class class318 extends class256 {
   class878 field547;

   public boolean method490() {
      class864 var1 = this.field547.method5918((byte)-26);
      if (var1 != null) {
         class417.method5690(class112.field2126, -1617025021 * this.field8101, -1, this.field547, var1, -391880689);
         return true;
      } else {
         return false;
      }
   }

   public boolean method4487(int var1) {
      try {
         class864 var2 = this.field547.method5918((byte)-81);
         if (var2 != null) {
            class417.method5690(class112.field2126, -1617025021 * this.field8101, -1, this.field547, var2, -391880689);
            return true;
         } else {
            return false;
         }
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ajs.a(" + ')');
      }
   }

   public class318(int var1, int var2, class878 var3) {
      super(var1, var2);
      this.field547 = var3;
   }
}
