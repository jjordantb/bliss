public final class class358 extends class284 {
   static int field1895;
   static int field1896;
   static class358[] field1897 = new class358[0];
   int field1898;
   int field1899;
   int field1900;
   long field1901;
   int field1902;

   public int method6666(int var1) {
      try {
         return this.field1898 * -959647937;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ajn.a(" + ')');
      }
   }

   public int method6667(byte var1) {
      try {
         return this.field1899 * 658623775;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ajn.f(" + ')');
      }
   }

   public int method6680(int var1) {
      try {
         return -660333015 * this.field1900;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ajn.b(" + ')');
      }
   }

   public long method6669(byte var1) {
      try {
         return this.field1901 * 3438655524500841893L;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ajn.i(" + ')');
      }
   }

   public long method6679() {
      return this.field1901 * 3438655524500841893L;
   }

   public void method6670(int var1) {
      try {
         class358[] var2 = field1897;
         synchronized(field1897) {
            if (2017906303 * field1895 < field1896 * 2020209463 - 1) {
               field1897[(field1895 += 1787228543) * 2017906303 - 1] = this;
            }

         }
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "ajn.d(" + ')');
      }
   }

   public int method6668(int var1) {
      try {
         return -1495835541 * this.field1902;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ajn.p(" + ')');
      }
   }

   public int method6673() {
      return this.field1899 * 658623775;
   }

   public int method6677() {
      return this.field1898 * -959647937;
   }

   public int method6674() {
      return this.field1899 * 658623775;
   }

   public int method6682() {
      return -660333015 * this.field1900;
   }

   public int method6685() {
      return -660333015 * this.field1900;
   }

   public int method6671() {
      return this.field1898 * -959647937;
   }

   public long method6672() {
      return this.field1901 * 3438655524500841893L;
   }

   public long method6678() {
      return this.field1901 * 3438655524500841893L;
   }

   public long method6676() {
      return this.field1901 * 3438655524500841893L;
   }

   public int method6684() {
      return -1495835541 * this.field1902;
   }

   public int method6681() {
      return -1495835541 * this.field1902;
   }

   public void method6675() {
      class358[] var1 = field1897;
      synchronized(field1897) {
         if (2017906303 * field1895 < field1896 * 2020209463 - 1) {
            field1897[(field1895 += 1787228543) * 2017906303 - 1] = this;
         }

      }
   }

   public void method6683() {
      class358[] var1 = field1897;
      synchronized(field1897) {
         if (2017906303 * field1895 < field1896 * 2020209463 - 1) {
            field1897[(field1895 += 1787228543) * 2017906303 - 1] = this;
         }

      }
   }
}
