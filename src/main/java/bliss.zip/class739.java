public class class739 {
   static class162 field2999;

   class739() throws Throwable {
      throw new Error();
   }

   static final void method1793(class744 var0, int var1) {
      try {
         var0.field3157[++var0.field3158 - 1] = var0.field3169.field9697;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ox.xl(" + ')');
      }
   }

   static String method1794(long var0, int var2, short var3) {
      try {
         class411.method5593(var0);
         int var4 = class308.field416.get(5);
         int var5 = class308.field416.get(2) + 1;
         int var6 = class308.field416.get(1);
         return Integer.toString(var4 / 10) + var4 % 10 + "/" + var5 / 10 + var5 % 10 + "/" + var6 % 100 / 10 + var6 % 10;
      } catch (RuntimeException var7) {
         throw class158.method3445(var7, "ox.p(" + ')');
      }
   }

   public static void method1795(int var0, int var1, int var2, boolean var3, int var4) {
      try {
         class730.field2779 = 0L;
         int var5 = class660.method5750((byte)-125);
         if (3 == var0 || var5 == 3) {
            var3 = true;
         }

         if (!class593.field1623.method4804()) {
            var3 = true;
         }

         class83.method885(var5, var0, var1, var2, var3, (byte)24);
      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "ox.gl(" + ')');
      }
   }
}
