public interface class334 extends class893 {
   void method2756();

   void method2753();

   void method49();

   void method50();

   void method2754();

   void method51();

   long method52();

   long method53();

   void method54();

   void method2755();

   long method55();

   void method56();
}
