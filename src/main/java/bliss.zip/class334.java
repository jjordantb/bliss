public interface class334 extends class893 {
   void method49();

   long method52();

   void method2755();
}
