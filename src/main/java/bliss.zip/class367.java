public class class367 extends class535 {
   int method2273(int var1, int var2) {
      return 1;
   }

   public class367(int var1, class838 var2) {
      super(var1, var2);
   }

   public void method1563(int var1) {
   }

   int method2277(int var1) {
      return 1;
   }

   void method2275(int var1, int var2) {
      try {
         this.field3708 = var1 * 1886334997;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "aeb.p(" + ')');
      }
   }

   public int method1564(int var1) {
      try {
         return -1598873795 * this.field3708;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "aeb.z(" + ')');
      }
   }

   int method2276() {
      return 0;
   }

   public class367(class838 var1) {
      super(var1);
   }

   void method2271(int var1) {
      this.field3708 = var1 * 1886334997;
   }

   int method2272(int var1) {
      return 0;
   }

   public static class331 method1565(class331[] var0, int var1, byte var2) {
      try {
         class331[] var3 = var0;

         for(int var4 = 0; var4 < var3.length; ++var4) {
            class331 var5 = var3[var4];
            if (var1 == var5.method89(694163818)) {
               return var5;
            }
         }

         return null;
      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "aeb.a(" + ')');
      }
   }
}
