public abstract class class80 extends class568 {
   int field1091;

   abstract void method870();

   abstract int method871(class451 var1);

   class80() throws Throwable {
      throw new Error();
   }
}
