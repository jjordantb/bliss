public abstract class class80 extends class568 {
   int field1091;

   abstract int method869(class451 var1);

   abstract void method870();

   abstract int method871(class451 var1);

   abstract void method872();

   class80() throws Throwable {
      throw new Error();
   }

   abstract void method873();

   abstract int method874(class451 var1);

   abstract void method875();
}
