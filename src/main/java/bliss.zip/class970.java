public class class970 {
   int[] field2988;
   short field2989;
   short[] field2990;
   short field2991;
   int[] field2992;
   short[] field2993;
   short[] field2994;
   short[] field2995;
   short[] field2996;
   byte[] field2997;
   short[] field2998;
}
