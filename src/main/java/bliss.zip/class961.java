public class class961 extends class106 {
   String field3628;
   int field3629;
   class120 field3630;

   void method168(class907 var1, int var2) {
      try {
         this.field3629 = var1.method6420((byte)-78) * 1400658899;
         this.field3628 = var1.method6379(951209118);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "aga.a(" + ')');
      }
   }

   void method172(class907 var1) {
      this.field3629 = var1.method6420((byte)-96) * 1400658899;
      this.field3628 = var1.method6379(-131087516);
   }

   void method170(class420 var1, byte var2) {
      try {
         var1.method5785(this.field3629 * -419842981, this.field3628, (byte)24);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "aga.f(" + ')');
      }
   }

   void method171(class420 var1) {
      var1.method5785(this.field3629 * -419842981, this.field3628, (byte)24);
   }

   class961(class120 var1) {
      this.field3630 = var1;
   }

   void method169(class907 var1) {
      this.field3629 = var1.method6420((byte)-1) * 1400658899;
      this.field3628 = var1.method6379(-184200581);
   }
}
