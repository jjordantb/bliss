public class class67 {
   short field1687;
   byte field1688;
   short field1689;
   short field1690;
   int field1691 = -1;
   short field1692;
   short field1693;
}
