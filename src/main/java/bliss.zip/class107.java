public class class107 extends class345 {
   class214 field1563;

   public class107(class214 var1) {
      this.field1563 = var1;
   }

   static final void method1200(class744 var0, byte var1) {
      try {
         class237 var2 = var0.field3178 ? var0.field3164 : var0.field3163;
         class564 var3 = var2.field8255;
         class131 var4 = var2.field8254;
         class175.method3050(var3, var4, var0, -1468199503);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "aid.jy(" + ')');
      }
   }
}
