public class class590 {
   static class590 field1577 = new class590(8);
   static class590 field1578 = new class590(2);
   public static class590 field1579 = new class590(4);
   public static class590 field1580 = new class590(1);
   static class590 field1581 = new class590(3);
   static class590 field1582 = new class590(6);
   static class590 field1583 = new class590(7);
   static class590 field1584 = new class590(5);
   public int field1585;

   class590(int var1) {
      this.field1585 = var1;
   }

   static final void method1217(class744 var0, int var1) {
      try {
         var0.field3156 -= 2;
         int var2 = var0.field3161[var0.field3156];
         int var3 = var0.field3161[1 + var0.field3156];
         class205 var4 = class848.field8597.method3399(var2, 7133861);
         int var5 = var4.field7622[var3];
         var0.field3161[++var0.field3156 - 1] = var5;
      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "pu.acv(" + ')');
      }
   }

   static final void method1218(class744 var0, int var1) {
      try {
         var0.field3161[++var0.field3156 - 1] = class615.field8903.field9137.method3689(-706712654);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "pu.ajb(" + ')');
      }
   }

   public static void method1219(int var0) {
      try {
         if (class890.field9270.field4347 != -1) {
            class381.method1064(class890.field9270.field4347, class890.field9270.field4343, 955770805);
         }

      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "pu.b(" + ')');
      }
   }

   static void method1220(class564 var0, class564 var1, int var2) {
      try {
         class701 var3 = class637.method5936(class643.field10006, class730.field2692.field7765, (byte)44);
         var3.field3364.method6400(var1.field1005);
         var3.field3364.method6368(var0.field867, (byte)-22);
         var3.field3364.method6364(var1.field867, -855626208);
         var3.field3364.method6362(var0.field879, 16711935);
         var3.field3364.method6400(var1.field879);
         var3.field3364.method6421(var0.field1005, 1472780126);
         class730.field2692.method4380(var3, (byte)-67);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "pu.kq(" + ')');
      }
   }

   static final void method1221(class744 var0, int var1) {
      try {
         var0.field3161[++var0.field3156 - 1] = class615.field8903.field9147.method5180(1496111936) ? 1 : 0;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "pu.ane(" + ')');
      }
   }

   static final void method1222(class564 var0, class131 var1, class744 var2, int var3) {
      try {
         String var4 = (String)var2.field3157[--var2.field3158];
         if (class960.method2212(var4, var2, -393614280) != null) {
            var4 = var4.substring(0, var4.length() - 1);
         }

         var0.field862 = class634.method5872(var4, var2, -2046058202);
         var0.field963 = true;
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "pu.lh(" + ')');
      }
   }

   static String method1223(class564 var0, int var1, byte var2) {
      try {
         if (!class730.method1761(var0).method1743(var1, (byte)-47) && var0.field989 == null) {
            return null;
         } else if (var0.field920 != null && var0.field920.length > var1 && var0.field920[var1] != null && var0.field920[var1].trim().length() != 0) {
            return var0.field920[var1];
         } else {
            return class730.field2828 ? "Hidden-" + var1 : null;
         }
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "pu.bq(" + ')');
      }
   }
}
