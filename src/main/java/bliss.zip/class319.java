public interface class319 {
   void method482();

   boolean method483();

   void method484();

   boolean method485();

   void method486();

   void method487();

   void method488();

   void method489();
}
