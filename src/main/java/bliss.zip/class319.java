public interface class319 {
   void method482();

   void method484();

   boolean method485();
}
