public abstract class class92 implements class524 {
   public class39[] field555;

   class92(class39[] var1) {
      this.field555 = var1;
   }
}
