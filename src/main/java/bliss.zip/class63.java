public class class63 {
   public static int field1647 = 718;
   public static int field1648 = 1;

   class63() throws Throwable {
      throw new Error();
   }

   static final void method1251(class744 var0, int var1) {
      try {
         var0.field3156 -= -783761378;
         if (var0.field3161[1 + var0.field3156 * 681479919] != var0.field3161[var0.field3156 * 681479919]) {
            var0.field3176 += 286750741 * var0.field3174[var0.field3176 * 1883543357];
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ig.o(" + ')');
      }
   }

   static final void method1252(class744 var0, byte var1) {
      try {
         class237 var2 = var0.field3178 ? var0.field3164 : var0.field3163;
         class564 var3 = var2.field8255;
         class131 var4 = var2.field8254;
         class849.method4784(var3, var4, var0, -159729779);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "ig.ix(" + ')');
      }
   }

   public static int method1253(int var0, int var1, int var2) {
      try {
         var1 = var1 * (var0 & 127) >> 7;
         if (var1 < 2) {
            var1 = 2;
         } else if (var1 > 126) {
            var1 = 126;
         }

         return (var0 & 'ﾀ') + var1;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "ig.k(" + ')');
      }
   }
}
