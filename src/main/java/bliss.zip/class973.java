public class class973 {
   int field2611;
   int field2612;
   int[] field2613;
   int[] field2614;

   class973() {
      class29.method3514(16);
      this.field2612 = class29.method3507() != 0 ? class29.method3514(4) + 1 : 1;
      if (class29.method3507() != 0) {
         class29.method3514(8);
      }

      class29.method3514(2);
      if (this.field2612 > 1) {
         this.field2611 = class29.method3514(4);
      }

      this.field2613 = new int[this.field2612];
      this.field2614 = new int[this.field2612];

      for(int var1 = 0; var1 < this.field2612; ++var1) {
         class29.method3514(8);
         this.field2613[var1] = class29.method3514(8);
         this.field2614[var1] = class29.method3514(8);
      }

   }
}
