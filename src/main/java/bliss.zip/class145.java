public class class145 extends class89 {
   Object field1559;

   class145(class195 var1, Object var2, int var3) {
      super(var1, var3);
      this.field1559 = var2;
   }

   boolean method955() {
      return false;
   }

   boolean method953() {
      return false;
   }

   Object method956() {
      return this.field1559;
   }

   Object method954() {
      return this.field1559;
   }

   Object method952() {
      return this.field1559;
   }
}
