public class class79 {
   static class373 field1525 = new class373();

   class79() throws Throwable {
      throw new Error();
   }

   static final void method1156(class564 var0, class131 var1, class744 var2, int var3) {
      try {
         int var4 = var2.field3161[--var2.field3156];
         if (var4 == class564.field991 || class564.field844 == var4 || class564.field931 == var4) {
            var0.field961 = var4;
         }

      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "ts.id(" + ')');
      }
   }

   public static final int method1157(String var0, int var1) {
      try {
         if (var0 == null) {
            return -1;
         } else {
            for(int var2 = 0; var2 < class730.field2923; ++var2) {
               if (var0.equalsIgnoreCase(class730.field2685[var2])) {
                  return var2;
               }
            }

            return -1;
         }
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ts.lg(" + ')');
      }
   }

   static void method1158(class180 var0, int var1, int var2, int var3, boolean var4, long var5) {
      try {
         class389.method1153(var0, var1, var2, var3, var4, var5, 0, -1584646162);
      } catch (RuntimeException var8) {
         throw class158.method3445(var8, "ts.p(" + ')');
      }
   }
}
