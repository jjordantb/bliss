public final class class967 {
   byte[] field2565;
   int field2566 = 16;
   int field2567 = 258;
   int field2568 = 6;
   int[][] field2569;
   int field2570 = 18002;
   int field2571;
   int field2572;
   int field2573;
   int field2574 = 4096;
   int field2575;
   int field2576;
   int field2577;
   byte[][] field2578;
   byte[] field2579;
   int field2580;
   int field2581;
   int field2582;
   int field2583;
   int field2584;
   int field2585;
   int[] field2586;
   int field2587 = 50;
   int[] field2588;
   static int[] field2589;
   int field2590;
   byte[] field2591;
   boolean[] field2592;
   byte[] field2593;
   int[][] field2594;
   int[] field2595;
   byte[] field2596;
   byte[] field2597;
   int[] field2598;
   byte field2599;
   int field2600;
   int[][] field2601;
   boolean[] field2602;
   int field2603;
   public static class180 field2604;

   class967() {
      this.field2566 = 16;
      this.field2567 = 258;
      this.field2568 = 6;
      this.field2587 = 50;
      this.field2570 = 18002;
      this.field2572 = 0;
      this.field2575 = 0;
      this.field2586 = new int[256];
      this.field2588 = new int[257];
      this.field2602 = new boolean[256];
      this.field2592 = new boolean[16];
      this.field2593 = new byte[256];
      this.field2597 = new byte[4096];
      this.field2598 = new int[16];
      this.field2596 = new byte[18002];
      this.field2591 = new byte[18002];
      this.field2578 = new byte[6][258];
      this.field2594 = new int[6][258];
      this.field2569 = new int[6][258];
      this.field2601 = new int[6][258];
      this.field2595 = new int[6];
   }

   public static final void method1749(String var0, int var1) {
      try {
         if (var0 != null) {
            if ((-1054937867 * class730.field2923 < 200 || class730.field2788) && -1054937867 * class730.field2923 < 200) {
               String var2 = class526.method2229(var0, 554575211);
               if (var2 != null) {
                  int var3;
                  String var4;
                  String var5;
                  for(var3 = 0; var3 < class730.field2923 * -1054937867; ++var3) {
                     var4 = class526.method2229(class730.field2685[var3], 460678269);
                     if (var4 != null && var4.equals(var2)) {
                        class727.method1683(4, var0 + class814.field4797.method2927(class321.field1066, -875414210), (byte)-72);
                        return;
                     }

                     if (class730.field2927[var3] != null) {
                        var5 = class526.method2229(class730.field2927[var3], -1697709934);
                        if (var5 != null && var5.equals(var2)) {
                           class727.method1683(4, var0 + class814.field4797.method2927(class321.field1066, -875414210), (byte)-22);
                           return;
                        }
                     }
                  }

                  for(var3 = 0; var3 < -548972447 * class730.field2934; ++var3) {
                     var4 = class526.method2229(class730.field2841[var3], 629913933);
                     if (var4 != null && var4.equals(var2)) {
                        class727.method1683(4, class814.field4803.method2927(class321.field1066, -875414210) + var0 + class814.field4804.method2927(class321.field1066, -875414210), (byte)-89);
                        return;
                     }

                     if (class730.field2937[var3] != null) {
                        var5 = class526.method2229(class730.field2937[var3], -1007795446);
                        if (var5 != null && var5.equals(var2)) {
                           class727.method1683(4, class814.field4803.method2927(class321.field1066, -875414210) + var0 + class814.field4804.method2927(class321.field1066, -875414210), (byte)-109);
                           return;
                        }
                     }
                  }

                  if (class526.method2229(class923.field10295.field3374, -712250197).equals(var2)) {
                     class727.method1683(4, class814.field4793.method2927(class321.field1066, -875414210), (byte)-34);
                  } else {
                     class684 var7 = class423.method5712((short)512);
                     class701 var8 = class637.method5936(class643.field10029, var7.field7765, (byte)14);
                     var8.field3364.method6361(class305.method372(var0, -92805385));
                     var8.field3364.method6366(var0, 2126537806);
                     var7.method4380(var8, (byte)-112);
                  }
               }
            } else {
               class727.method1683(4, class814.field4705.method2927(class321.field1066, -875414210), (byte)-99);
            }
         }

      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "sc.mk(" + ')');
      }
   }

   public static void method1750(int var0, int var1) {
      try {
         if (var0 != class730.field2733 * -1233866115) {
            class730.field2704 = 0;
            if (var0 == 5 || 13 == var0) {
               class871.method5900(760519077);
            }

            if (var0 != 5 && class467.field7301 != null) {
               class467.field7301.method179(-2130986966);
               class467.field7301 = null;
            }

            if (19 == var0) {
               class936.method6276(8 == -1233866115 * class730.field2733 || -1233866115 * class730.field2733 == 2 || 747461259 * class6.field4931.field9533 != class730.field2822 * -257444687, -1608675861);
            }

            if (var0 == 14) {
               class470.method4593(class730.field2822 * -257444687 != class6.field4931.field9522 * 1349088077, -687019075);
            }

            if (var0 != 4 && 6 != var0) {
               if (3 == var0 || var0 == 18 && -1233866115 * class730.field2733 != 16) {
                  class871.method5900(1162411214);
               } else if (var0 == 2) {
                  class917.method6452((byte)0);
               }
            } else {
               class900.method6348((byte)-8);
            }

            if (class399.method3529(var0, -1178041789)) {
               class730.field2697.method5315((byte)75);
               class371.method867(true, 1336561252);
            }

            if (17 == var0 || var0 == 19) {
               class870.method5889(-1734216597);
            }

            boolean var2 = 7 == var0 || class162.method3544(var0, 2038230333) || class669.method4121(var0, 1765230881);
            boolean var3 = 7 == -1233866115 * class730.field2733 || class162.method3544(class730.field2733 * -1233866115, 2005988447) || class669.method4121(-1233866115 * class730.field2733, 1765230881);
            if (var2 != var3) {
               if (var2) {
                  class540.field3920 = class540.field3923 * 1701432991;
                  if (class615.field8903.field9153.method2717(-2145576299) != 0) {
                     class488.method4739(2, class771.field3732, 782166935 * class540.field3923, 0, class615.field8903.field9153.method2717(-2142499578), false, 1118626209);
                     class228.method4589(-656326093);
                  } else {
                     class154.method3492(2, 2140319778);
                  }

                  class794.field541.method230(false, -1153302935);
               } else {
                  class154.method3492(2, 1226990292);
                  class794.field541.method230(true, -1469822226);
               }
            }

            if (class399.method3529(var0, 299941911) || var0 == 5 || 13 == var0) {
               class593.field1623.method5046();
            }

            class730.field2733 = -705702187 * var0;
         }

      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "sc.fd(" + ')');
      }
   }
}
