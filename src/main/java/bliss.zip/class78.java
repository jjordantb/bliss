public class class78 {
   public String field1497;
   public int field1498;
   public byte field1499;
   static int field1500;
   public static int field1501;

   static int method1123(char var0, int var1) {
      try {
         return var0 >= 0 && var0 < class867.field9755.length ? class867.field9755[var0] : -1;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "gq.a(" + ')');
      }
   }

   static final void method1124(class744 var0, int var1) {
      try {
         var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = 443738891 * class730.field2866;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "gq.tx(" + ')');
      }
   }

   static class346 method1125(byte[] var0, byte var1) {
      try {
         return new class346(new class907(var0));
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "gq.p(" + ')');
      }
   }

   static final void method1126(boolean var0, class744 var1, byte var2) {
      try {
         class237 var3 = var1.field3178 ? var1.field3164 : var1.field3163;
         class564 var4 = var3.field8255;
         class131 var5 = var3.field8254;
         if (var0) {
            class277.method6634(var5, var4, -1270501871);
         } else {
            class414.method5597(var5, var4, (byte)-3);
         }

      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "gq.cd(" + ')');
      }
   }

   static final void method1127(class744 var0, int var1) {
      try {
         var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = class237.method4653((byte)30);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "gq.um(" + ')');
      }
   }
}
