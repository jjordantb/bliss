import java.util.HashMap;
import java.util.Map;

public class class814 {
   static class814 field4655 = new class814((String)null, "geschickt werden.", (String)null, (String)null);
   public static class814 field4656 = new class814("There was an error executing the command.", "Es gab einen Fehler beim Ausf�hren des Befehls.", "Une erreur s'est produite lors de l'ex�cution de la commande.", "Houve um erro quando o comando foi executado.");
   static class814 field4657 = new class814("Loading world map - ", "Lade Weltkarte - ", "Chargement de la mappemonde - ", "Carregando mapa-m�ndi - ");
   public static class814 field4658 = new class814("Continue", "Weiter", "Continuer", "Continuar");
   static class814 field4659 = new class814("Loading config - ", "Lade Konfiguration - ", "Chargement des fichiers config - ", "Carregando config - ");
   static class814 field4660 = new class814("Login to a members' server to use this object.", "Du musst auf einer Mitglieder-Welt sein, um diesen Gegenstand zu benutzen.", "Connectez-vous � un serveur d'abonn�s pour utiliser cet objet.", "Acesse um servidor para membros para usar este objeto.");
   static class814 field4661 = new class814("Swap this note at any bank for the equivalent item.", "Dieses Zertifikat kann in einer Bank entsprechend eingetauscht werden.", "�changez ce re�u contre l'objet correspondant dans la banque de votre choix.", "V� a qualquer banco para trocar esta nota pelo objeto equivalente.");
   public static class814 field4662 = new class814("Please wait...", "Bitte warte...", "Veuillez attendre", "Aguarde...");
   public static class814 field4663 = new class814("Profiling...", "Profiling...", "Profilage...", "Profiling...");
   public static class814 field4664 = new class814("Take", "Nehmen", "Prendre", "Pegar");
   static class814 field4665 = new class814((String)null, "der Spieler ist momentan nicht verf�gbar.", (String)null, (String)null);
   static class814 field4666 = new class814("Ok", "Okay", "OK", "Ok");
   static class814 field4667 = new class814("Select", "Ausw�hlen", "S�lectionner", "Selecionar");
   public static class814 field4668 = new class814("Please wait - attempting to reestablish.", "Bitte warte - es wird versucht, die Verbindung wiederherzustellen.", "Veuillez patienter - tentative de r�tablissement.", "Tentando reestabelecer conex�o. Aguarde.");
   static class814 field4669 = new class814("Loaded additional fonts", "Zusatzschriftarten geladen", "Polices secondaires charg�es", "Fontes principais carregadas");
   static class814 field4670 = new class814("You can't report yourself!", "Du kannst dich nicht selbst melden!", "Vous ne pouvez pas vous signaler vous-m�me !", "Voc� n�o pode denunciar a si pr�prio!");
   public static class814 field4671 = new class814("white:", "weiss:", "blanc:", "branco:");
   static class814 field4672 = new class814("You cannot report that person for Staff Impersonation, they are Jagex Staff.", "Diese Person ist ein Jagex-Mitarbeiter!", "Cette personne est un membre du personnel de Jagex, vous ne pouvez pas la signaler pour abus d'identit�.", "Voc� n�o pode denunciar essa pessoa por tentar se passar por membro da equipe Jagex, pois ela faz parte da equipe.");
   static class814 field4673 = new class814("You can spot a Jagex moderator by the gold crown next to their name.", "Jagex-Mitarbeiter haben eine goldene Krone neben ihrem Namen.", "Vous pouvez reconna�tre les mod�rateurs Jagex � la couronne dor�e en regard de leur nom.", "Os moderadores da Jagex s�o identificados por uma coroa dourada pr�xima ao \u007fnome.");
   static class814 field4674 = new class814("You can report that person under a different rule.", "Diese Person kann bez�glich einer anderen Regel gemeldet werden.", "Vous pouvez signaler cette personne pour une autre infraction aux r�gles.", "Voc� n�o pode denunciar essa pessoa de acordo com uma regra diferente.");
   static class814 field4675 = new class814("Unable to add name - system busy.", "Der Name konnte nicht hinzugef�gt werden, das System ist derzeit ausgelastet.", "Impossible d'ajouter un nom - syst�me occup�.", "N�o foi poss�vel adicionar o nome. O sistema est� ocupado.");
   static class814 field4676 = new class814("Unable to send abuse report - system busy.", "Meldung konnte nicht gesendet werden - Systeme �berlastet", "Impossible de signaler un abus - Erreur syst�me", "Sistema ocupado. N�o foi poss�vel enviar sua den�ncia de abuso.");
   static class814 field4677 = new class814("Invalid name", "Unzul�ssiger Name!", "Nom incorrect", "Nome inv�lido");
   static class814 field4678 = new class814("To use this item please login to a members' server.", "Du musst auf einer Mitglieder-Welt sein, um diesen Gegenstand zu benutzen.", "Veuillez vous connecter � un serveur d'abonn�s pour utiliser cet objet.", "Acesse um servidor para membros para usar este objeto.");
   public static class814 field4679 = new class814("Unknown developer command: ", "Unbekannter Befehl: ", "Commande inconnue : ", "Comando desconhecido: ");
   static class814 field4680 = new class814("Nothing interesting happens.", "Nichts Interessantes passiert.", "Il ne se passe rien d'int�ressant.", "Nada de interessante acontece.");
   public static class814 field4681 = new class814("flash3:", "blinken3:", "clignotant3:", "brilho3:");
   static class814 field4682 = new class814("Invalid teleport!", "Unzul�ssiger Teleport!", "T�l�portation non valide !", "Teleporte inv�lido!");
   static class814 field4683 = new class814("This player is on a quick chat world and cannot receive your message.", "Der Spieler kann auf einer Direktchat-Welt keine Nachrichten empfangen.", "Ce joueur est sur un serveur � messagerie rapide et ne peut pas recevoir votre message.", "Este jogador n�o pode receber sua mensagem porque est� em um mundo de papo r�pido.");
   static class814 field4684 = new class814("Unable to add friend - system busy.", "Der Freund konnte nicht hinzugef�gt werden, das System ist derzeit ausgelastet.", "Impossible d'ajouter un ami - syst�me occup�.", "N�o foi poss�vel adicionar o amigo. O sistema est� ocupado.");
   static class814 field4685 = new class814("Unable to add friend - unknown player.", "Spieler konnte nicht hinzugef�gt werden - Spieler unbekannt.", "Impossible d'ajouter l'ami - joueur inconnu.", "N�o foi poss�vel adicionar um amigo - jogador desconhecido.");
   public static class814 field4686 = new class814("flash1:", "blinken1:", "clignotant1:", "flash1:");
   static class814 field4687 = new class814("Unable to add name - unknown player.", "Name konnte nicht hinzugef�gt werden - Spieler unbekannt.", "Impossible d'ajouter le nom - joueur inconnu.", "N�o foi poss�vel adicionar um nome - jogador desconhecido.");
   public static class814 field4688 = new class814(" more options", " weitere Optionen", " autres options", " mais op��es");
   static class814 field4689 = new class814("Unable to delete friend - system busy.", "Der Freund konnte nicht entfernt werden, das System ist derzeit ausgelastet.", "Impossible de supprimer un ami - syst�me occup�.", "N�o foi poss�vel excluir o amigo. O sistema est� ocupado.");
   static class814 field4690 = new class814("Friend", "Freund", "Ami", "Amigo");
   public static class814 field4691 = new class814("shake:", "sch�tteln:", "tremblement:", "tremor:");
   static class814 field4692 = new class814("Unable to send message - player unavailable.", "Deine Nachricht konnte nicht verschickt werden,", "Impossible d'envoyer un message - joueur indisponible.", "N�o foi poss�vel enviar a mensagem. O jogador n�o est� dispon�vel.");
   static class814 field4693 = new class814("#Player", "#Spieler", "#Joueur", "#Jogador");
   static class814 field4694 = new class814("Unable to send message - player not on your friends list.", "Nachricht kann nicht geschickt werden,", "Impossible d'envoyer un message - joueur non inclus dans votre liste d'amis.", "N�o foi poss�vel enviar a mensagem. O jogador n�o est� na sua lista de amigos.");
   static class814 field4695 = new class814((String)null, "Spieler nicht auf deiner Freunde-Liste.", (String)null, (String)null);
   static class814 field4696 = new class814("You appear to be telling someone your password - please don't!", "Willst du jemandem dein Passwort verraten? Das darfst du nicht! Falls das", "Il semble que vous r�v�liez votre mot de passe � quelqu'un - ne faites jamais �a !", "Parece que voc� est� revelando sua senha a algu�m. N�o fa�a isso!");
   static class814 field4697 = new class814("If you are not, please change your password to something more obscure!", "nicht der Fall ist, �ndere dein Passwort zu einem ungew�hnlicheren Begriff!", "Si ce n'est pas le cas, remplacez votre mot de passe par une formule moins �vidente !", "Caso n�o esteja, altere sua senha para algo mais obscuro!");
   static class814 field4698 = new class814("Invalid player name.", "Unzul�ssiger Charaktername!", "Nom de joueur incorrect.", "Nome de jogador inv�lido.");
   static class814 field4699 = new class814("Unable to delete name - system busy.", "Name konnte nicht gel�scht werden - Systemfehler.", "Impossible d'effacer le nom - syst�me occup�.", "N�o foi poss�vel deletar o nome - sistema ocupado.");
   static class814 field4700 = new class814("For that rule you can only report players who have spoken or traded recently.", "Mit dieser Option k�nnen nur Spieler gemeldet werden,", "Cette r�gle n'est invocable que pour les discussions ou �changes r�cents.", "Para essa regra, voc� s� pode denunciar jogadores com quem tenha falado ou negociado recentemente.");
   static class814 field4701 = new class814((String)null, "die k�rzlich gesprochen oder gehandelt haben.", (String)null, (String)null);
   static class814 field4702 = new class814("That player is offline, or has privacy mode enabled.", "Dieser Spieler ist offline oder hat den Privatsph�ren-Modus aktiviert.", "Ce joueur est d�connect� ou en mode priv�.", "O jogador est� offline ou est� com o modo de privacidade ativado.");
   static class814 field4703 = new class814("You cannot send a quick chat message to a player on this world at this time.", "Einem Spieler auf dieser Welt k�nnen derzeit keine Direktchat-Nachrichten", "Impossible d'envoyer un message rapide � un joueur de ce serveur � l'heure actuelle.", "Voc� n�o pode enviar uma mensagem de papo r�pido para um jogador neste mundo neste momento.");
   static class814 field4704 = new class814("You can't reach that.", "Da kommst du nicht hin.", "Vous ne pouvez pas l'atteindre.", "Voc� n�o consegue alcan�ar isso.");
   public static class814 field4705 = new class814("Your friends list is full (200 names maximum)", "Deine Freunde-Liste ist voll, du hast das Maximum von 200 erreicht.", "Votre liste d'amis est pleine (200 noms maximum).", "Sua lista de amigos est� cheia. O limite � 200.");
   static class814 field4706 = new class814("Chat disabled", "Deaktiviert", "Messagerie d�sactiv�e", "Bate-papo desativado");
   static class814 field4707 = new class814("friends_chat", "friends_chat", "friends_chat", "friends_chat");
   public static class814 field4708 = new class814("Fetching Updates - ", "Lade Update - ", "Chargement des MAJ - ", "Carregando atualiza��es - ");
   static class814 field4709 = new class814("You are not allowed to talk in this friends chat channel.", "Du darfst in diesem Freundes-Chatraum nicht reden.", "Vous n'�tes pas autoris� � parler dans ce canal de discussion.", "Voc� pode falar neste bate-papo entre amigos.");
   static class814 field4710 = new class814("Error sending message to friends chat - please try again later!", "Fehler beim Versenden der Nachricht - bitte versuch es sp�ter erneut.", "Erreur lors de l'envoi de ce message – veuillez réessayer ultérieurement !", "Erro ao enviar mensagem para bate-papo entre amigos - favor tentar novamente mais tarde!");
   public static class814 field4711 = new class814("You can't add yourself to your own ignore list.", "Du kannst dich nicht auf deine eigene Ignorieren-Liste setzen!", "Vous ne pouvez pas ajouter votre nom � votre liste noire.", "Voc� n�o pode adicionar a si pr�prio � sua lista de ignorados.");
   static class814 field4712 = new class814("You are not currently in a channel.", "Du befindest dich derzeit nicht in einem Chatraum.", "Vous n'�tes dans aucun canal � l'heure actuelle.", "No momento voc� n�o est� em um canal.");
   static class814 field4713 = new class814("Attempting to join channel...", "Chatraum wird betreten...", "Tentative de connexion au canal...", "Tentando acessar canal...");
   static class814 field4714 = new class814("Sending request to leave channel...", "Chatraum wird verlassen...", "Envoi de la demande de sortie du canal...", "Enviando solicita��o para deixar o canal...");
   static class814 field4715 = new class814("Already attempting to join a channel - please wait...", "Du versuchst bereits, einem Chatraum beizutreten - bitte warte.", "Tentative de connexion au canal d�j� en cours - veuillez patienter...", "J� h� uma tentativa de entrar em um canal. Aguarde...");
   static class814 field4716 = new class814("Leave request already in progress - please wait...", "Du versuchst bereits, einen Chatraum zu verlassen - bitte warte.", "Demande de sortie d�j� effectu�e - veuillez patienter...", "Solicita��o de sa�da j� em andamento. Aguarde...");
   static class814 field4717 = new class814("Invalid channel name entered!", "Ung�ltiger Chatraum-Name angegeben.", "Nom de canal incorrect !", "Nome de canal inv�lido!");
   static class814 field4718 = new class814("Unable to join friends chat at this time - please try again later!", "Freundes-Chatraum kann nicht betreten werden - bitte versuch es sp�ter erneut.", "Vous ne pouvez pas rejoindre ce canal de discussion pour le moment - veuillez r�essayer ult�rieurement !", "N�o foi poss�vel participar do bate-papo entre amigos - favor tentar novamente mais tarde!");
   static class814 field4719 = new class814("Now talking in friends chat channel ", "Freundes-Chatraum: ", "Vous participez actuellement au canal de discussion : ", "Falando no momento no bate-papo entre amigos: ");
   static class814 field4720 = new class814("Now talking in friends chat channel of player: ", "Freundes-Chat dieses Spielers beigetreten: ", "Vous participez actuellement au canal de discussion du joueur : ", "Falando no momento no bate-papo entre amigos do jogador: ");
   static class814 field4721 = new class814("Error joining friends chat channel - please try again later!", "Fehler beim Betreten des Freundes-Chatraums - bitte versuch es sp�ter erneut.", "Erreur lors de la connexion au canal de discussion - veuillez r�essayer ult�rieurement !", "Erro ao participar do bate-papo entre-amigos - favor tentar novamente mais tarde!");
   static class814 field4722 = new class814("You are temporarily blocked from joining channels - please try again later!", "Du darfst derzeit keine Chatr�ume betreten - bitte versuch es sp�ter.", "Vous �tes temporairement exclu des canaux - veuillez r�essayer ult�rieurement.", "Voc� est� temporariamente impedido de entrar em canais. Tente de novo depois!");
   static class814 field4723 = new class814("The channel you tried to join does not exist.", "Der von dir gew�nschte Chatraum existiert nicht.", "Le canal que vous essayez de rejoindre n'existe pas.", "O canal que voc� tentou acessar n�o existe.");
   static class814 field4724 = new class814("You do not have permission to kick users in this channel.", "Du darfst keine Benutzer aus diesem Chatraum rauswerfen.", "Vous n'�tes pas autoris� � expulser des utilisateurs de ce canal.", "Voc� n�o tem permiss�o para expulsar usu�rios neste canal.");
   static class814 field4725 = new class814("You do not have a high enough rank to join this friends chat channel.", "Dein Rang reicht nicht aus, um diesen Freundes-Chatraum zu betreten.", "Votre rang n'est pas assez �lev� pour rejoindre ce canal de discussion.", "Voc� n�o tem uma classifica��o alta o suficiente para participar deste bate-papo entre amigos.");
   static class814 field4726 = new class814("You are temporarily banned from this friends chat channel.", "Du wurdest tempor�r von diesem Freundes-Chatraum gesperrt.", "Vous avez �t� exclu temporairement de ce canal de discussion.", "Voc� foi temporariamente banido deste bate-papo entre amigos.");
   public static class814 field4727 = new class814("Unable to find ", "Spieler kann nicht gefunden werden: ", "Impossible de trouver ", "N�o � poss�vel encontrar ");
   public static class814 field4728 = new class814("Walk here", "Hierhin gehen", "Atteindre", "Caminhar para c�");
   public static class814 field4729 = new class814("Discard", "Ablegen", "Jeter", "Descartar");
   static class814 field4730 = new class814(" was kicked from the channel.", " wurde aus dem Chatraum rausgeworfen.", " a �t� expuls� du canal.", " foi expulso do canal.");
   static class814 field4731 = new class814("You have been kicked from the channel.", "Du wurdest aus dem Chatraum rausgeworfen.", "Vous avez �t� expuls� du canal.", "Voc� foi expulso do canal.");
   public static class814 field4732 = new class814("wave2:", "welle2:", "ondulation2:", "onda2:");
   static class814 field4733 = new class814("You have left the channel.", "Du hast den Chatraum verlassen.", "Vous avez quitt� le canal.", "Voc� saiu do canal.");
   static class814 field4734 = new class814("Your friends chat channel has now been enabled!", "Dein Freundes-Chat ist jetzt eingeschaltet.", "Votre canal de discussion est maintenant activ� !", "O seu bate-papo entre amigos foi ativado!");
   static class814 field4735 = new class814("Join your channel by clicking 'Join Chat' and typing: ", "Klick auf 'Betreten' und gib ein: ", "Pour rejoindre votre canal, cliquez sur � Participer � et entrez : ", "Para entrar no seu canal, clique em \"Acessar bate-papo\" e digite: ");
   static class814 field4736 = new class814("Your friends chat channel has now been disabled!", "Dein Freundes-Chat ist jetzt ausgeschaltet.", "Votre canal de discussion est maintenant d�sactiv� !", "O seu bate-papo entre amigos foi desativado!");
   static class814 field4737 = new class814(" left the channel.", " hat den Chatraum verlassen.", " a quitt� le canal.", " deixou o canal.");
   static class814 field4738 = new class814(" joined the channel.", " hat den Chatraum betreten.", " a rejoint le canal.", " entrou no canal.");
   static class814 field4739 = new class814("That user is not in this channel.", "Dieser Benutzer befindet sich nicht in diesem Chatraum.", "Cet utilisateur n'est pas dans ce canal.", "Esse usu�rio n�o est� no canal.");
   static class814 field4740 = new class814("Your request to kick/ban this user was successful.", "Der Rauswurf/die Sperrung war erfolgreich.", "Votre demande d'exclusion de ce joueur a �t� accept�e.", "Seu pedido para expulsar/suspender este jogador foi bem sucedido.");
   static class814 field4741 = new class814("Your request to refresh this user's temporary ban was successful.", "Die Verl�ngerung der tempor�ren Sperrung dieses Spielers war erfolgreich.", "Le renouvellement d'exclusion temporaire de ce joueur a �t� accept�.", "Seu pedido para reiniciar a suspens�o tempor�ria deste jogador foi bem sucedido.");
   static class814 field4742 = new class814("You have been temporarily muted due to breaking a rule.", "Aufgrund eines Regelversto�es wurdest du vor�bergehend stumm geschaltet.", "La messagerie instantan�e a �t� temporairement bloqu�e suite � une infraction.", "Voc� foi temporariamente vetado por ter violado uma regra.");
   static class814 field4743 = new class814("This mute will remain for a further ", "Diese Stummschaltung gilt f�r weitere ", "Votre acc�s restera bloqu� encore ", "Este veto permanecer� por mais ");
   static class814 field4744 = new class814("Changes will take effect on your friends chat in the next 60 seconds.", "Die �nderungen am Freundes-Chat werden innerhalb von 60 Sekunden �bernommen.", "Les modifications seront apport�s � votre canal de discussion dans les 60 prochaines secondes.", "Mundan�as v�o ocorrer em seu bate-papo entre amigos nos pr�ximos 60 segundos.");
   static class814 field4745 = new class814("You will be un-muted within 24 hours.", "Du wirst innerhalb der n�chsten 24 Stunden wieder sprechen k�nnen.", "Vous aurez � nouveau acc�s � la messagerie instantan�e dans 24 heures.", "O veto ser� retirado dentro de 24 horas.");
   static class814 field4746 = new class814("To prevent further mutes please read the rules.", "Um eine erneute Stummschaltung zu verhindern, lies bitte die Regeln.", "Pour �viter un nouveau blocage, lisez le r�glement.", "Para evitar outros vetos, leia as regras.");
   static class814 field4747 = new class814("You have been permanently muted due to breaking a rule.", "Du wurdest permanent stumm geschaltet, da du gegen eine Regel versto�en hast.", "L'acc�s � la messagerie instantan�e vous a d�finitivement �t� retir� suite � une infraction.", "Voc� foi permanentemente vetado por ter violado uma regra.");
   public static class814 field4748 = new class814("Loading - If stuck at 0% - Restart Client!", "Ladevorgang - bitte warte.", "Chargement en cours. Veuillez patienter.", "Carregando. Aguarde.");
   static class814 field4749 = new class814("You do not have permission to kick this user.", "Du darfst diesen Benutzer nicht rauswerfen.", "Vous n'�tes pas autoris� � expulser cet utilisateur.", "Voc� n�o tem permiss�o para expulsar este usu�rio.");
   public static class814 field4750 = new class814("Connection lost.", "Verbindung abgebrochen.", "Connexion perdue.", "Conex�o perdida.");
   static class814 field4751 = new class814("Thank-you, your abuse report has been received.", "Vielen Dank, deine Meldung ist bei uns eingegangen.", "Merci, nous avons bien re�u votre rapport d'abus.", "Obrigado. Sua den�ncia de abuso foi recebida.");
   public static class814 field4752 = new class814("Loading Cache - ", "Suche nach Updates - ", "V�rification des mises � jour - ", "Verificando atualiza��es - ");
   static class814 field4753 = new class814("You have sent too many abuse reports today! Do not abuse this system!", "Du hast heute schon zu viele Regelverst��e gemeldet! Missbrauch das System nicht!", "Vous avez signalé trop d’abus pour aujourd’hui. N’abusez pas de ce système !", "Voc� j� denunciou abuso muitas vezes hoje. N�o abuse do sistema!");
   static class814 field4754 = new class814((String)null, "indem du dich ins Spiel einloggst.", (String)null, (String)null);
   static class814 field4755 = new class814("Loaded world list data", "Liste der Welten geladen", "Liste des serveurs charg�e", "Dados da lista de mundos carregados");
   public static class814 field4756 = new class814("wave:", "welle:", "ondulation:", "onda:");
   static class814 field4757 = new class814("Loaded sprites", "Sprites geladen.", "Sprites charg�s", "Sprites carregados");
   static class814 field4758 = new class814("Loading wordpack - ", "Lade Wordpack - ", "Chargement du module texte - ", "Carregando pacote de palavras - ");
   static class814 field4759 = new class814("Loaded wordpack", "Wordpack geladen.", "Module texte charg�", "Pacote de palavras carregado");
   static class814 field4760 = new class814("Loading interfaces - ", "Lade Benutzeroberfl�che - ", "Chargement des interfaces - ", "Carregando interfaces - ");
   static class814 field4761 = new class814("Loaded interfaces", "Benutzeroberfl�che geladen.", "Interfaces charg�es", "Interfaces carregadas");
   static class814 field4762 = new class814("Loading interface scripts - ", "Lade Interface-Skripte - ", "Chargement des interfaces - ", "Carregando interfaces - ");
   static class814 field4763 = new class814("Loaded interface scripts", "Interface-Skripte geladen", "Interfaces charg�es", "Interfaces carregadas");
   static class814 field4764 = new class814("Loading additional fonts - ", "Lade Zusatzschriftarten - ", "Chargement de polices secondaires - ", "Carregando fontes principais - ");
   static class814 field4765 = new class814("You are not allowed to join this user's friends chat channel.", "Du darfst den Freundes-Chatraum dieses Benutzers nicht betreten.", "Vous n'�tes pas autoris� � rejoindre le canal de discussion de cet utilisateur.", "Voc� n�o pode participar do bate-papo entre amigos deste usu�rio.");
   public static class814 field4766 = new class814("red:", "rot:", "rouge:", "vermelho:");
   static class814 field4767 = new class814("You are not currently in a friends chat channel.", "Du befindest dich derzeit nicht in einem Freundes-Chatraum.", "Vous ne faites pas partie d'un canal de discussion.", "No momento, voc� n�o est� no bate-papo entre amigos.");
   static class814 field4768 = new class814("Loading world list data", "Lade Liste der Welten", "Chargement de la liste des serveurs", "Carregando dados da lista de mundos");
   static class814 field4769 = new class814("To interact with this please login to a members' server.", "Logg dich auf einer Mitglieder-Welt ein, um damit zu interagieren.", "Veuillez vous connecter � un serveur d'abonn�s pour cette interaction.", "Para interagir, acesse um servidor para membros.");
   static class814 field4770 = new class814("Loaded client variable data", "Client-Variablen geladen", "Variables du client charg�es", "As vari�veis do sistema foram carregadas");
   public static class814 field4771 = new class814("flash2:", "blinken2:", "clignotant2:", "flash2:");
   static class814 field4772 = new class814("Please close the interface you have open before using 'Report Abuse'.", "Bitte schlie� die momentan ge�ffnete Benutzeroberfl�che,", "Fermez l'interface que vous avez ouverte avant d'utiliser le bouton � Signaler un abus �.", "Feche a interface aberta antes de usar o recurso \"Denunciar abuso\".");
   static class814 field4773 = new class814((String)null, "bevor du die Option 'Regelversto� melden' benutzt.", (String)null, (String)null);
   static class814 field4774 = new class814("System update in: ", "System-Update in: ", "Mise � jour syst�me dans : ", "Atualiza��o do sistema em: ");
   public static class814 field4775 = new class814(" has logged in.", " loggt sich ein.", " s'est connect�.", " entrou no jogo.");
   public static class814 field4776 = new class814(" has logged out.", " loggt sich aus.", " s'est d�connect�.", " saiu do jogo.");
   public static class814 field4777 = new class814("Discard", "Ablegen", "Jeter", "Descartar");
   public static class814 field4778 = new class814("cyan:", "blaugr�n:", "cyan:", "cyan:");
   public static class814 field4779 = new class814("Examine", "Untersuchen", "Examiner", "Examinar");
   public static class814 field4780 = new class814("Attack", "Angreifen", "Attaquer", "Atacar");
   public static class814 field4781 = new class814("Choose Option", "W�hl eine Option", "Choisir une option", "Selecionar op��o");
   static class814 field4782 = new class814("You have been removed from this channel.", "Du wurdest aus dem Chatraum entfernt.", "Vous avez �t� supprim� de ce canal.", "Voc� foi retirado desse canal.");
   static class814 field4783 = new class814("Unable to send message - set your display name first by logging into the game.", "Nachricht konnte nicht gesendet werden.  Bitte richte erst deinen Charakternamen ein, ", "Impossible d'envoyer le message - enregistrez un nom de personnage en vous connectant au jeu.", "N�o � poss�vel enviar a mensagem. Defina um nome de personagem antes, fazendo login no jogo.");
   public static class814 field4784 = new class814("Face here", "Hierhin drehen", "Regarder dans cette direction", "Virar para c�");
   public static class814 field4785 = new class814("level: ", "Stufe: ", "niveau ", "n�vel: ");
   public static class814 field4786 = new class814("skill: ", "Fertigkeit: ", "comp�tence ", "habilidade: ");
   public static class814 field4787 = new class814("K", "T", "K", "K");
   static class814 field4788 = new class814("Use", "Benutzen", "Utiliser", "Usar");
   static class814 field4789 = new class814("Close", "Bitte schlie� die momentan ge�ffnete Benutzeroberfl�che,", "Fermez l'interface que vous avez ouverte avant d'utiliser le bouton � Signaler un abus �.", "Feche a interface aberta antes de usar o recurso \"Denunciar abuso\".");
   public static class814 field4790 = new class814(" ", ": ", " ", " ");
   public static class814 field4791 = new class814("M", "M", "M", "M");
   public static class814 field4792 = new class814("M", "M", "M", "M");
   public static class814 field4793 = new class814("You can't add yourself to your own friends list.", "Du kannst dich nicht auf deine eigene Freunde-Liste setzen!", "Vous ne pouvez pas ajouter votre nom � votre liste d'amis.", "Voc� n�o pode adicionar a si pr�prio � sua lista de amigos.");
   public static class814 field4794 = new class814("K", "T", "K", "K");
   static class814 field4795 = new class814("From", "Von:", "De", "De");
   public static class814 field4796 = new class814("Self", "Mich", "Moi", "Eu");
   public static class814 field4797 = new class814(" is already on your friends list.", " steht bereits auf deiner Freunde-Liste!", " est d�j� dans votre liste d'amis.", " j� est� na sua lista de amigos.");
   public static class814 field4798 = new class814("Your ignore list is full. Max of 100 users.", "Deine Ignorieren-Liste ist voll, du kannst nur 100 Spieler darauf eintragen.", "Votre liste noire est pleine (100 noms maximum).", "Sua lista de ignorados est� cheia. O limite � 100 usu�rios.");
   public static class814 field4799 = new class814(" is already on your ignore list.", " steht bereits auf deiner Ignorieren-Liste!", " est d�j� dans votre liste noire.", " j� est� na sua lista de ignorados.");
   static class814 field4800 = new class814("Loading sprites - ", "Lade Sprites - ", "Chargement des sprites - ", "Carregando sprites - ");
   static class814 field4801 = new class814("Loaded world map", "Weltkarte geladen", "Mappemonde charg�e", "Mapa-m�ndi carregado");
   public static class814 field4802 = new class814("rating: ", "Kampfstufe: ", "classement ", "qualifica��o: ");
   public static class814 field4803 = new class814("Please remove ", "Bitte entferne ", "Veuillez commencer par supprimer ", "Remova ");
   public static class814 field4804 = new class814(" from your ignore list first.", " zuerst von deiner Ignorieren-Liste!", " de votre liste noire.", " da sua lista de ignorados primeiro.");
   public static class814 field4805 = new class814("Please remove ", "Bitte entferne ", "Veuillez commencer par supprimer ", "Remova ");
   public static class814 field4806 = new class814(" from your friends list first.", " zuerst von deiner Freunde-Liste!", " de votre liste d'amis.", " da sua lista de amigos primeiro.");
   public static class814 field4807 = new class814("yellow:", "gelb:", "jaune:", "amarelo:");
   public static class814 field4808 = new class814("Cancel", "Abbrechen", "Annuler", "Cancelar");
   public static class814 field4809 = new class814("green:", "gr�n:", "vert:", "verde:");
   static class814 field4810 = new class814("Unable to send message - system busy.", "Deine Nachricht konnte nicht verschickt werden, das System ist derzeit ausgelastet.", "Impossible d'envoyer un message - syst�me occup�.", "N�o foi poss�vel enviar a mensagem. O sistema est� ocupado.");
   public static class814 field4811 = new class814("purple:", "lila:", "violet:", "roxo:");
   public static class814 field4812 = new class814("Loading...", "Lade...", "Chargement en cours...", "Carregando...");
   public static class814 field4813 = new class814("Drop", "Fallen lassen", "Poser", "Largar");
   static class814 field4814 = new class814("Loaded config", "Konfig geladen.", "Fichiers config charg�s", "Config carregada");
   static class814 field4815 = new class814("The channel you tried to join is currently full.", "Der von dir gew�nschte Chatraum ist derzeit �berf�llt.", "Le canal que vous essayez de rejoindre est plein.", "O canal que voc� tentou acessar est� cheio no momento.");
   public static class814 field4816 = new class814("glow1:", "leuchten1:", "brillant1:", "brilho1:");
   public static class814 field4817 = new class814("glow2:", "leuchten2:", "brillant2:", "brilho2:");
   public static class814 field4818 = new class814("glow3:", "leuchten3:", "brillant3:", "brilho3:");
   static class814 field4819 = new class814(" days.", " Tage.", " jours.", " dias.");
   static class814 field4820 = new class814("Please wait until you are logged out of your previous channel.", "Bitte warte, bis du den vorherigen Chatraum verlassen hast.", "Veuillez attendre d'�tre d�connect�(e) de votre canal pr�c�dent.", "Aguarde at� se desconectar do canal anterior.");
   static class814 field4821 = new class814("To go here you must login to a members' server.", "Du musst auf einer Mitglieder-Welt sein, um dort hinzukommen.", "Vous devez vous connecter � un serveur d'abonn�s pour aller � cet endroit.", "Para entrar aqui, acesse um servidor para membros.");
   public static class814 field4822 = new class814("scroll:", "scrollen:", "d�roulement:", "rolagem:");
   public static class814 field4823 = new class814("slide:", "gleiten:", "glissement:", "deslizamento:");
   public static class814 field4824 = new class814("This is the developer console. To close, press the `, � or � keys on your keyboard.", "Das ist die Entwicklerkonsole. Zum Schlie�en, die Tasten `, � or � dr�cken.", "Ceci est la console de d�veloppement. Pour la fermer, appuyez sur les touches `, � ou �.", "Este � o painel de controle do desenvolvedor. Para fechar, pressione `, � ou �.");
   Map field4825 = new HashMap(6);

   class814(String var1, String var2, String var3, String var4) {
      this.field4825.put(class423.field9583, var1);
      this.field4825.put(class423.field9584, var2);
      this.field4825.put(class423.field9585, var3);
      this.field4825.put(class423.field9586, var4);
   }

   public String method2927(class423 var1, int var2) {
      try {
         return (String)this.field4825.get(var1);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "tj.a(" + ')');
      }
   }

   static final void method2928(class744 var0, byte var1) {
      try {
         int var2 = var0.field3161[--var0.field3156];
         var0.field3161[++var0.field3156 - 1] = class488.method4736((char)var2, -946861784) ? 1 : 0;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "tj.aae(" + ')');
      }
   }

   static final void method2929(class744 var0, byte var1) {
      try {
         int var2 = var0.field3161[--var0.field3156];
         var0.field3161[++var0.field3156 - 1] = class615.field8903.field9147.method2273(var2, 1352882135);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "tj.aol(" + ')');
      }
   }

   static final void method2930(class744 var0, short var1) {
      try {
         class615.field8903.method5391(class615.field8903.field9132, var0.field3161[--var0.field3156], 274640540);
         class95.method523(656179282);
         class730.field2657 = true;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "tj.aiq(" + ')');
      }
   }

   static void method2931(int var0) {
      try {
         if (class593.field1623 != null) {
            class730.field2697.method5288((byte)8);
            class410.method5637(1660073823);
            class452.method3868(1532437233);
            class621.method5261((byte)1);
            class730.field2697.method5289(-772209776);
            class115.method1271(2076480784);
            class830.method5375(false, -1663847334);
            class381.method1070(712737937);
            class371.method867(true, 1336561252);
            class250.method4388(1470703335);
            class984.method1876(-90086733);

            int var1;
            for(var1 = 0; var1 < class730.field2652.length; ++var1) {
               class669 var10000 = class730.field2652[var1];
            }

            int var3;
            for(var1 = 0; var1 < 2048; ++var1) {
               class946 var2 = class730.field2786[var1];
               if (var2 != null) {
                  for(var3 = 0; var3 < var2.field4046.length; ++var3) {
                     var2.field4046[var3] = null;
                  }
               }
            }

            for(var1 = 0; var1 < class730.field2753; ++var1) {
               class60 var5 = (class60)class730.field2797[var1].field7515;
               if (var5 != null) {
                  for(var3 = 0; var3 < var5.field4046.length; ++var3) {
                     var5.field4046[var3] = null;
                  }
               }
            }

            class730.field2806.method2941((byte)-70);
            class593.field1623.method4996(500005923);
            class593.field1623 = null;
         }

      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "tj.fp(" + ')');
      }
   }

   public static void method2932(class564 var0, int var1) {
      try {
         if (class730.field2814 == var0.field858) {
            class730.field2882[var0.field1028] = true;
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "tj.ll(" + ')');
      }
   }

   public static void method2933(int var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      try {
         if (var1 >= 0 && var2 >= 0 && var1 < class730.field2697.method5271(-2044392628) - 1 && var2 < class730.field2697.method5272(1696781293) - 1 && class730.field2697.method5317(-1611682495) != null) {
            class265 var8;
            if (var3 == 0) {
               var8 = (class265)class730.field2697.method5317(-1611682495).method2425(var0, var1, var2, 1970836387);
               class265 var9 = (class265)class730.field2697.method5317(-1611682495).method2426(var0, var1, var2, (byte)0);
               if (var8 != null && var4 != 2) {
                  if (var8 instanceof class397) {
                     ((class397)var8).field6490.method348(var6, 334665686);
                  } else {
                     class745.method2596(var0, var3, var1, var2, var8.method4551((byte)-28), var5, var4, var6, -95982907);
                  }
               }

               if (var9 != null) {
                  if (var9 instanceof class397) {
                     ((class397)var9).field6490.method348(var6, -433535088);
                  } else {
                     class745.method2596(var0, var3, var1, var2, var9.method4551((byte)30), var5, var4, var6, -1702879755);
                  }
               }
            } else if (var3 == 1) {
               var8 = (class265)class730.field2697.method5317(-1611682495).method2427(var0, var1, var2, 1080081135);
               if (var8 != null) {
                  if (var8 instanceof class715) {
                     ((class715)var8).field3585.method348(var6, 1175058275);
                  } else {
                     int var11 = var8.method4551((byte)51);
                     if (var4 != 4 && 5 != var4) {
                        if (6 == var4) {
                           class745.method2596(var0, var3, var1, var2, var11, 4 + var5, 4, var6, -219363167);
                        } else if (var4 == 7) {
                           class745.method2596(var0, var3, var1, var2, var11, (2 + var5 & 3) + 4, 4, var6, -353598946);
                        } else if (var4 == 8) {
                           class745.method2596(var0, var3, var1, var2, var11, 4 + var5, 4, var6, -1614214519);
                           class745.method2596(var0, var3, var1, var2, var11, 4 + (2 + var5 & 3), 4, var6, -1199427971);
                        }
                     } else {
                        class745.method2596(var0, var3, var1, var2, var11, var5, 4, var6, 1216421631);
                     }
                  }
               }
            } else if (2 == var3) {
               var8 = (class265)class730.field2697.method5317(-1611682495).method2429(var0, var1, var2, class730.field2942, 898562473);
               if (var8 != null) {
                  if (var4 == 11) {
                     var4 = 10;
                  }

                  if (var8 instanceof class589) {
                     ((class589)var8).field274.method348(var6, 1520781180);
                  } else {
                     class745.method2596(var0, var3, var1, var2, var8.method4551((byte)81), var5, var4, var6, 819048305);
                  }
               }
            } else if (var3 == 3) {
               var8 = (class265)class730.field2697.method5317(-1611682495).method2452(var0, var1, var2, (byte)21);
               if (var8 != null) {
                  if (var8 instanceof class547) {
                     ((class547)var8).field411.method348(var6, 939556837);
                  } else {
                     class745.method2596(var0, var3, var1, var2, var8.method4551((byte)-39), var5, var4, var6, -1265284934);
                  }
               }
            }
         }

      } catch (RuntimeException var10) {
         throw class158.method3445(var10, "tj.kw(" + ')');
      }
   }
}
