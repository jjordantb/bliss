public class class114 {
   static class1 field1721 = new class1(64);
   public static int field1722 = 1;
   public static int field1723 = 2;
   public boolean field1724 = false;
   public int field1725 = 0;
   public short field1726;
   static class180 field1727;
   public short field1728;
   public int[] field1729;
   public int field1730;
   int field1731;
   public int field1732;
   int field1733;
   public int field1734 = -460402411;
   public int[] field1735;
   int field1736 = 551876020;
   public int field1737;
   public int field1738 = -1186467237;
   int field1739 = -82525436;
   int field1740;
   int field1741;
   public boolean field1742 = true;
   public int field1743;
   int field1744 = -1351633244;
   int field1745 = 59539036;
   public int field1746 = -313955239;
   public int field1747;
   public int field1748;
   public int field1749;
   public int field1750;
   public int field1751;
   public int[] field1752;
   public int field1753;
   public int[] field1754;
   public static int field1755 = -1;
   public int field1756 = 894014710;
   public int field1757 = -1054767914;
   public int field1758 = 0;
   public short field1759;
   public boolean field1760 = true;
   public int field1761 = -1971154607;
   public int field1762;
   public int field1763 = 0;
   public int field1764;
   public int field1765 = -2053470659;
   public boolean field1766 = true;
   static int field1767 = 0;
   public boolean field1768 = false;
   public boolean field1769 = true;
   public boolean field1770 = false;
   public int field1771;
   int field1772;
   public int field1773;
   public int field1774;
   public int field1775;
   public int field1776;
   public int field1777;
   int field1778;
   public int field1779 = -891363123;
   public boolean field1780 = true;
   public short field1781;
   public int field1782;
   public boolean field1783 = true;
   public int field1784;
   public int field1785;
   public int field1786;
   public int field1787;
   public int field1788;
   public int field1789;
   public int field1790;
   public int field1791;
   public int field1792;

   void method1292(class907 var1, byte var2) {
      try {
         while(true) {
            int var3 = var1.method6371();
            if (var3 == 0) {
               return;
            }

            this.method1293(var1, var3, (short)3276);
         }
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "hp.b(" + ')');
      }
   }

   void method1293(class907 var1, int var2, short var3) {
      try {
         if (1 == var2) {
            this.field1726 = (short)var1.method6374();
            this.field1759 = (short)var1.method6374();
            this.field1728 = (short)var1.method6374();
            this.field1781 = (short)var1.method6374();
            byte var4 = 3;
            this.field1726 = (short)(this.field1726 << var4);
            this.field1759 = (short)(this.field1759 << var4);
            this.field1728 = (short)(this.field1728 << var4);
            this.field1781 = (short)(this.field1781 << var4);
         } else if (2 == var2) {
            var1.method6371();
         } else if (3 == var2) {
            this.field1730 = var1.method6420((byte)43) * -387057077;
            this.field1764 = var1.method6420((byte)-103) * -1853520269;
         } else if (var2 == 4) {
            this.field1725 = var1.method6371() * -687561841;
            this.field1753 = var1.method6372(-12558881) * -1070610169;
         } else if (5 == var2) {
            this.field1775 = (this.field1737 = (var1.method6374() << 12 << 2) * -1969619697) * -2077217427;
         } else if (6 == var2) {
            this.field1740 = var1.method6420((byte)100) * -1365954181;
            this.field1741 = var1.method6420((byte)-15) * 902519911;
         } else if (7 == var2) {
            this.field1747 = var1.method6374() * 704499925;
            this.field1748 = var1.method6374() * -1653481859;
         } else if (var2 == 8) {
            this.field1749 = var1.method6374() * -517504949;
            this.field1750 = var1.method6374() * -1502909185;
         } else {
            int var5;
            int var7;
            if (9 == var2) {
               var7 = var1.method6371();
               this.field1729 = new int[var7];

               for(var5 = 0; var5 < var7; ++var5) {
                  this.field1729[var5] = var1.method6374();
               }
            } else if (10 == var2) {
               var7 = var1.method6371();
               this.field1735 = new int[var7];

               for(var5 = 0; var5 < var7; ++var5) {
                  this.field1735[var5] = var1.method6374();
               }
            } else if (12 == var2) {
               this.field1756 = var1.method6372(-12558881) * 1700476293;
            } else if (var2 == 13) {
               this.field1757 = var1.method6372(-12558881) * -1620099691;
            } else if (14 == var2) {
               this.field1758 = var1.method6374() * -629947759;
            } else if (15 == var2) {
               this.field1746 = var1.method6374() * 313955239;
            } else if (var2 == 16) {
               this.field1742 = var1.method6371() == 1;
               this.field1761 = var1.method6374() * 1971154607;
               this.field1765 = var1.method6374() * 2053470659;
               this.field1760 = var1.method6371() == 1;
            } else if (var2 == 17) {
               this.field1779 = var1.method6374() * 891363123;
            } else if (18 == var2) {
               this.field1743 = var1.method6420((byte)24) * 661695111;
            } else if (var2 == 19) {
               this.field1763 = var1.method6371() * 709275159;
            } else if (var2 == 20) {
               this.field1744 = var1.method6371() * 587779089;
            } else if (21 == var2) {
               this.field1745 = var1.method6371() * 1460884271;
            } else if (var2 == 22) {
               this.field1734 = var1.method6420((byte)-1) * 460402411;
            } else if (23 == var2) {
               this.field1736 = var1.method6371() * -853474699;
            } else if (24 == var2) {
               this.field1766 = false;
            } else if (25 == var2) {
               var7 = var1.method6371();
               this.field1752 = new int[var7];

               for(var5 = 0; var5 < var7; ++var5) {
                  this.field1752[var5] = var1.method6374();
               }
            } else if (var2 == 26) {
               this.field1783 = false;
            } else if (var2 == 27) {
               this.field1738 = (var1.method6374() << 12 << 2) * 1186467237;
            } else if (var2 == 28) {
               this.field1739 = var1.method6371() * -1461114135;
            } else if (29 == var2) {
               var1.method6367(1655872053);
            } else if (30 == var2) {
               this.field1724 = true;
            } else if (var2 == 31) {
               this.field1775 = (var1.method6374() << 12 << 2) * 1138516579;
               this.field1737 = (var1.method6374() << 12 << 2) * -1969619697;
            } else if (32 == var2) {
               this.field1780 = false;
            } else if (33 == var2) {
               this.field1768 = true;
            } else if (34 == var2) {
               this.field1769 = false;
            }
         }

      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "hp.p(" + ')');
      }
   }

   void method1294(int var1) {
      try {
         if (this.field1756 * -275612851 > -2 || -1831524931 * this.field1757 > -2) {
            this.field1770 = true;
         }

         this.field1771 = 1630521741 * (737478067 * this.field1740 >> 16 & 255);
         this.field1772 = (1522532183 * this.field1741 >> 16 & 255) * -231735957;
         this.field1773 = this.field1772 * 147388659 - this.field1771 * -902341611;
         this.field1774 = 313528669 * (this.field1740 * 737478067 >> 8 & 255);
         this.field1731 = -339699839 * (this.field1741 * 1522532183 >> 8 & 255);
         this.field1776 = this.field1731 * -1096760557 - 1588068271 * this.field1774;
         this.field1777 = (this.field1740 * 737478067 & 255) * -573588505;
         this.field1733 = (1522532183 * this.field1741 & 255) * -1720855383;
         this.field1762 = -844298861 * this.field1733 - 1351662653 * this.field1777;
         this.field1732 = (737478067 * this.field1740 >> 24 & 255) * -1453810947;
         this.field1778 = 1322388433 * (1522532183 * this.field1741 >> 24 & 255);
         this.field1782 = this.field1778 * 1784226905 - 1139279133 * this.field1732;
         if (1558182711 * this.field1743 != 0) {
            this.field1792 = -1525995331 * (1395500273 * this.field1744 * 1940196053 * this.field1748 / 100);
            this.field1751 = -323160919 * (this.field1748 * 1940196053 * -1087319089 * this.field1745 / 100);
            if (-1703669099 * this.field1792 == 0) {
               this.field1792 = -1525995331;
            }

            this.field1785 = 220598105 * (((this.field1743 * 1558182711 >> 16 & 255) - (this.field1773 * -447935375 / 2 + this.field1771 * 1443995973) << 8) / (-1703669099 * this.field1792));
            this.field1786 = 1551625825 * (((1558182711 * this.field1743 >> 8 & 255) - (-1237529867 * this.field1774 + -1154628453 * this.field1776 / 2) << 8) / (this.field1792 * -1703669099));
            this.field1787 = ((1558182711 * this.field1743 & 255) - (this.field1777 * -1297143849 + this.field1762 * -564637277 / 2) << 8) / (this.field1792 * -1703669099) * 1145782203;
            if (this.field1751 * -966201447 == 0) {
               this.field1751 = -323160919;
            }

            this.field1788 = 756703809 * (((1558182711 * this.field1743 >> 24 & 255) - (629527125 * this.field1732 + this.field1782 * 1235129497 / 2) << 8) / (-966201447 * this.field1751));
            this.field1785 += 220598105 * (-1778169623 * this.field1785 > 0 ? -4 : 4);
            this.field1786 += (this.field1786 * 936719777 > 0 ? -4 : 4) * 1551625825;
            this.field1787 += 1145782203 * (this.field1787 * 1137945971 > 0 ? -4 : 4);
            this.field1788 += 756703809 * (this.field1788 * 825667009 > 0 ? -4 : 4);
         }

         if (this.field1734 * 799607235 != -1) {
            this.field1789 = -1215468705 * (this.field1736 * 635387357 * this.field1748 * 1940196053 / 100);
            if (this.field1789 * -1035489121 == 0) {
               this.field1789 = -1215468705;
            }

            this.field1790 = (799607235 * this.field1734 - (this.field1730 * 373784419 + (this.field1764 * -439251269 - 373784419 * this.field1730) / 2)) / (this.field1789 * -1035489121) * -1441694519;
         }

         if (-1628433875 * this.field1738 != -1) {
            this.field1791 = 1204309337 * this.field1739 * 1940196053 * this.field1748 / 100 * -1190650305;
            if (-1648307777 * this.field1791 == 0) {
               this.field1791 = -1190650305;
            }

            this.field1784 = (-1628433875 * this.field1738 - ((-769306129 * this.field1737 - -992661685 * this.field1775) / 2 + -992661685 * this.field1775)) / (-1648307777 * this.field1791) * -1770208597;
         }

      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "hp.i(" + ')');
      }
   }

   static final void method1295(int var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      try {
         if (class730.field2705 * 1596783995 == 3) {
            int var8 = class498.field8102 * 1168366243;
            int[] var9 = class498.field8108;

            int var10;
            for(var10 = 0; var10 < var8; ++var10) {
               class946 var11 = class730.field2786[var9[var10]];
               if (var11 != null) {
                  var11.method2569(var0, var1, var2, var3, var4, var5, var6, (byte)12);
               }
            }

            for(var10 = 0; var10 < -1230451913 * class730.field2684; ++var10) {
               int var14 = class730.field2680[var10];
               class437 var12 = (class437)class730.field2677.method2942((long)var14);
               if (var12 != null) {
                  ((class746)var12.field7515).method2569(var0, var1, var2, var3, var4, var5, var6, (byte)12);
               }
            }
         }

      } catch (RuntimeException var13) {
         throw class158.method3445(var13, "hp.js(" + ')');
      }
   }

   static void method1296(byte var0) {
      try {
         class682.field7698.method2941((byte)-40);
         class682.field7684.method2710(1028697182);
         class682.field7715.method2710(1342386694);
      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "hp.f(" + ')');
      }
   }
}
