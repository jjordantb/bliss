public class class375 {
   int field1174;
   int field1175;
   int field1176;
   int field1177;
}
