public class class767 extends class605 {
   public void method5103(boolean var1) {
      this.field8692.method616(0);
      this.field8692.method555(0, class557.field496);
      this.field8692.method622(0, class557.field496);
      this.field8692.method555(1, class557.field497);
      this.field8692.method622(1, class557.field497);
      this.field8692.method620(class584.field295, class584.field295);
      this.method2240();
   }

   public class767(class325 var1) {
      super(var1);
   }

   public void method5113(boolean var1) {
      this.field8692.method616(0);
      this.field8692.method555(0, class557.field496);
      this.field8692.method622(0, class557.field496);
      this.field8692.method555(1, class557.field497);
      this.field8692.method622(1, class557.field497);
      this.field8692.method620(class584.field295, class584.field295);
      this.method2240();
   }

   void method2240() {
      this.field8692.method617(this.field8689);
      this.field8692.method624().method269(this.field8691);
      this.field8692.method625(class90.field550);
      this.field8692.method651(class427.field7386, this.field8704, this.field8705, this.field8706, this.field8686);
   }

   public void method5105(class344 var1) {
      this.field8692.method559(var1, this.field8692.field674, this.field8692.field777);
   }

   public void method5110(class344 var1) {
      this.field8692.method559(var1, this.field8692.field674, this.field8692.field777);
   }

   public void method5102(int var1) {
      this.field8692.method616(0);
      this.field8692.method620(class584.field295, class584.field300);
      this.field8692.method555(0, class557.field496);
      this.field8692.method622(0, class557.field497);
      this.field8692.method555(1, class557.field497);
      this.field8692.method622(1, class557.field497);
      this.method2240();
   }

   public void method5109() {
      this.method5106(0);
   }

   public void method5111(class344 var1) {
      this.field8692.method559(var1, this.field8692.field674, this.field8692.field777);
   }

   public void method5112(boolean var1) {
      this.field8692.method616(0);
      this.field8692.method555(0, class557.field496);
      this.field8692.method622(0, class557.field496);
      this.field8692.method555(1, class557.field497);
      this.field8692.method622(1, class557.field497);
      this.field8692.method620(class584.field295, class584.field295);
      this.method2240();
   }

   public void method5107(int var1) {
      this.field8692.method616(0);
      this.field8692.method620(class584.field295, class584.field300);
      this.field8692.method555(0, class557.field496);
      this.field8692.method622(0, class557.field497);
      this.field8692.method555(1, class557.field497);
      this.field8692.method622(1, class557.field497);
      this.method2240();
   }

   public void method5114(boolean var1) {
      this.field8692.method616(0);
      this.field8692.method555(0, class557.field496);
      this.field8692.method622(0, class557.field496);
      this.field8692.method555(1, class557.field497);
      this.field8692.method622(1, class557.field497);
      this.field8692.method620(class584.field295, class584.field295);
      this.method2240();
   }

   public void method5106(int var1) {
      this.field8692.method616(0);
      this.field8692.method620(class584.field295, class584.field295);
      this.field8692.method555(0, class557.field496);
      this.field8692.method622(0, class557.field496);
      this.field8692.method555(1, class557.field497);
      this.field8692.method622(1, class557.field497);
      this.method2240();
   }

   public void method5117(int var1) {
      this.field8692.method616(0);
      this.field8692.method620(class584.field295, class584.field295);
      this.field8692.method555(0, class557.field496);
      this.field8692.method622(0, class557.field496);
      this.field8692.method555(1, class557.field497);
      this.field8692.method622(1, class557.field497);
      this.method2240();
   }

   public void method5115(int var1) {
      this.field8692.method616(0);
      this.field8692.method620(class584.field295, class584.field300);
      this.field8692.method555(0, class557.field496);
      this.field8692.method622(0, class557.field497);
      this.field8692.method555(1, class557.field497);
      this.field8692.method622(1, class557.field497);
      this.method2240();
   }

   public void method5116(int var1) {
      this.field8692.method616(0);
      this.field8692.method620(class584.field295, class584.field300);
      this.field8692.method555(0, class557.field496);
      this.field8692.method622(0, class557.field497);
      this.field8692.method555(1, class557.field497);
      this.field8692.method622(1, class557.field497);
      this.method2240();
   }

   public void method5118() {
      this.method5106(0);
   }

   public void method5119(int var1) {
      this.field8692.method616(0);
      this.field8692.method620(class584.field295, class584.field300);
      this.field8692.method555(0, class557.field496);
      this.field8692.method622(0, class557.field497);
      this.field8692.method555(1, class557.field497);
      this.field8692.method622(1, class557.field497);
      this.method2240();
   }

   public void method5120(int var1) {
      this.field8692.method616(0);
      this.field8692.method620(class584.field295, class584.field300);
      this.field8692.method555(0, class557.field496);
      this.field8692.method622(0, class557.field497);
      this.field8692.method555(1, class557.field497);
      this.field8692.method622(1, class557.field497);
      this.method2240();
   }

   public void method5104(int var1) {
      this.field8692.method616(0);
      this.field8692.method620(class584.field295, class584.field300);
      this.field8692.method555(0, class557.field496);
      this.field8692.method622(0, class557.field497);
      this.field8692.method555(1, class557.field497);
      this.field8692.method622(1, class557.field497);
      this.method2240();
   }
}
