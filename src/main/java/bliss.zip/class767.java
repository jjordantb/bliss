public class class767 extends class605 {
   public class767(class325 var1) {
      super(var1);
   }

   public void method5113(boolean var1) {
      super.field8692.method616(0);
      super.field8692.method555(0, class557.field496);
      super.field8692.method622(0, class557.field496);
      super.field8692.method555(1, class557.field497);
      super.field8692.method622(1, class557.field497);
      super.field8692.method620(class584.field295, class584.field295);
      this.method2240();
   }

   void method2240() {
      super.field8692.method617(super.field8689);
      super.field8692.method624().method269(super.field8691);
      super.field8692.method625(class90.field550);
      super.field8692.method651(class427.field7386, super.field8704, super.field8705, super.field8706, super.field8686);
   }

   public void method5105(class344 var1) {
      super.field8692.method559(var1, super.field8692.field674, super.field8692.field777);
   }

   public void method5102(int var1) {
      super.field8692.method616(0);
      super.field8692.method620(class584.field295, class584.field300);
      super.field8692.method555(0, class557.field496);
      super.field8692.method622(0, class557.field497);
      super.field8692.method555(1, class557.field497);
      super.field8692.method622(1, class557.field497);
      this.method2240();
   }

   public void method5109() {
      this.method5106(0);
   }

   public void method5107(int var1) {
      super.field8692.method616(0);
      super.field8692.method620(class584.field295, class584.field300);
      super.field8692.method555(0, class557.field496);
      super.field8692.method622(0, class557.field497);
      super.field8692.method555(1, class557.field497);
      super.field8692.method622(1, class557.field497);
      this.method2240();
   }

   public void method5106(int var1) {
      super.field8692.method616(0);
      super.field8692.method620(class584.field295, class584.field295);
      super.field8692.method555(0, class557.field496);
      super.field8692.method622(0, class557.field496);
      super.field8692.method555(1, class557.field497);
      super.field8692.method622(1, class557.field497);
      this.method2240();
   }
}
