public abstract class class576 implements class54 {
   int field66;
   class180 field67;
   class727 field68;
   class180 field69;
   class827 field70;
   long field71;
   public static class180 field72;

   abstract void method57(boolean var1, int var2, int var3);

   abstract void method58(boolean var1, int var2, int var3);

   public boolean method1539() {
      boolean var1 = true;
      if (!this.field67.method3280(this.field70.field9035 * 955568089, -457216440)) {
         var1 = false;
      }

      if (!this.field69.method3280(955568089 * this.field70.field9035, -457216440)) {
         var1 = false;
      }

      return var1;
   }

   public boolean method1537(int var1) {
      try {
         boolean var2 = true;
         if (!this.field67.method3280(this.field70.field9035 * 955568089, -457216440)) {
            var2 = false;
         }

         if (!this.field69.method3280(955568089 * this.field70.field9035, -457216440)) {
            var2 = false;
         }

         return var2;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "fd.b(" + ')');
      }
   }

   abstract void method59(boolean var1, int var2, int var3, int var4);

   public void method1543(boolean var1, byte var2) {
      try {
         int var3 = this.field70.field9028.method1786(-944287579 * this.field70.field9032, class730.field2775 * 775068819, -2137791831) + this.field70.field9033 * -39975161;
         int var4 = this.field70.field9029.method3090(-1387457793 * this.field70.field9036, -791746413 * class730.field2784, -1715218341) + this.field70.field9031 * 1886882435;
         this.method60(var1, var3, var4, 589039750);
         this.method59(var1, var3, var4, -2096633602);
         String var5 = class302.field3768.method119((short)8868);
         if (class27.method3468((byte)1) - this.field71 * 109366757865047727L > 10000L) {
            var5 = var5 + " (" + class302.field3768.method114(-1233866115).field7500 * -861845079 + ")";
         }

         this.field68.method1681(var5, -944287579 * this.field70.field9032 / 2 + var3, 4 + -1387457793 * this.field70.field9036 / 2 + var4 + this.field70.field9034 * -684094775, this.field70.field9030 * 782326281, -1, -370673990);
      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "fd.f(" + ')');
      }
   }

   abstract void method60(boolean var1, int var2, int var3, int var4);

   public void method1541(boolean var1) {
      int var2 = this.field70.field9028.method1786(-944287579 * this.field70.field9032, class730.field2775 * 775068819, -1925244247) + this.field70.field9033 * -39975161;
      int var3 = this.field70.field9029.method3090(-1387457793 * this.field70.field9036, -791746413 * class730.field2784, -1769429058) + this.field70.field9031 * 1886882435;
      this.method60(var1, var2, var3, -895632654);
      this.method59(var1, var2, var3, -358621562);
      String var4 = class302.field3768.method119((short)24747);
      if (class27.method3468((byte)1) - this.field71 * 109366757865047727L > 10000L) {
         var4 = var4 + " (" + class302.field3768.method114(-1233866115).field7500 * -861845079 + ")";
      }

      this.field68.method1681(var4, -944287579 * this.field70.field9032 / 2 + var2, 4 + -1387457793 * this.field70.field9036 / 2 + var3 + this.field70.field9034 * -684094775, this.field70.field9030 * 782326281, -1, -1547657926);
   }

   public boolean method1542() {
      boolean var1 = true;
      if (!this.field67.method3280(this.field70.field9035 * 955568089, -457216440)) {
         var1 = false;
      }

      if (!this.field69.method3280(955568089 * this.field70.field9035, -457216440)) {
         var1 = false;
      }

      return var1;
   }

   public void method1540() {
      class230 var1 = class213.method3814(this.field69, 955568089 * this.field70.field9035, 325683529);
      this.field68 = class593.field1623.method4936(var1, class922.method6236(this.field67, 955568089 * this.field70.field9035), true);
   }

   public boolean method1544() {
      boolean var1 = true;
      if (!this.field67.method3280(this.field70.field9035 * 955568089, -457216440)) {
         var1 = false;
      }

      if (!this.field69.method3280(955568089 * this.field70.field9035, -457216440)) {
         var1 = false;
      }

      return var1;
   }

   abstract void method61(boolean var1, int var2, int var3);

   abstract void method62(boolean var1, int var2, int var3);

   abstract void method63(boolean var1, int var2, int var3);

   abstract void method64(boolean var1, int var2, int var3);

   class576(class180 var1, class180 var2, class827 var3) {
      this.field67 = var1;
      this.field69 = var2;
      this.field70 = var3;
   }

   public void method1538(int var1) {
      try {
         class230 var2 = class213.method3814(this.field69, 955568089 * this.field70.field9035, 1681337882);
         this.field68 = class593.field1623.method4936(var2, class922.method6236(this.field67, 955568089 * this.field70.field9035), true);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "fd.a(" + ')');
      }
   }

   abstract void method65(boolean var1, int var2, int var3);

   int method66(int var1) {
      try {
         int var2 = class302.field3768.method118(-15916663);
         int var3 = var2 * 100;
         if (-1729871315 * this.field66 == var2 && var2 != 0) {
            int var4 = class302.field3768.method121((byte)7);
            if (var4 > var2) {
               long var5 = 109366757865047727L * this.field71 - class302.field3768.method120(-2093041337);
               if (var5 > 0L) {
                  long var7 = var5 * 10000L / (long)var2 * (long)(var4 - var2);
                  long var9 = (class27.method3468((byte)1) - this.field71 * 109366757865047727L) * 10000L;
                  if (var9 < var7) {
                     var3 = (int)(100L * var9 * (long)(var4 - var2) / var7 + (long)(100 * var2));
                  } else {
                     var3 = 100 * var4;
                  }
               }
            }
         } else {
            this.field66 = 1301503397 * var2;
            this.field71 = class27.method3468((byte)1) * -1063467934392987569L;
         }

         return var3;
      } catch (RuntimeException var11) {
         throw class158.method3445(var11, "fd.q(" + ')');
      }
   }

   static final void method67(class564 var0, class131 var1, class744 var2, int var3) {
      try {
         if (5 == -1215239439 * var0.field869) {
            class912.method6480(var0, var1, var2, (short)-9019);
         }

      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "fd.gi(" + ')');
      }
   }

   static final void method68(class744 var0, int var1) {
      try {
         var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = class615.field8903.field9139.method2805(1673845033) == 1 ? 1 : 0;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "fd.ajr(" + ')');
      }
   }

   static final void method69(class744 var0, byte var1) {
      try {
         var0.field3156 -= -1175642067;
         int var2 = var0.field3161[var0.field3156 * 681479919];
         int var3 = var0.field3161[1 + var0.field3156 * 681479919];
         int var4 = var0.field3161[681479919 * var0.field3156 + 2];
         class740.method1920(2, var2 << 16 | var3, var4, "", -474820428);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "fd.ali(" + ')');
      }
   }

   static final void method70(class744 var0, short var1) {
      try {
         int var2 = var0.field3161[(var0.field3156 -= -391880689) * 681479919];
         var0.field3157[(var0.field3158 += 969361751) * -203050393 - 1] = class848.field8597.method3399(var2, 1350033014).field7619;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "fd.acc(" + ')');
      }
   }

   static final void method71(class564 var0, int var1, int var2, int var3, class744 var4, int var5) {
      try {
         if (var0.field910 == null) {
            if (var2 == 0) {
               return;
            }

            var0.field910 = new byte[11];
            var0.field947 = new byte[11];
            var0.field1001 = new int[11];
         }

         var0.field910[var1] = (byte)var2;
         if (var2 != 0) {
            var0.field945 = true;
         } else {
            var0.field945 = false;

            for(int var6 = 0; var6 < var0.field910.length; ++var6) {
               if (var0.field910[var6] != 0) {
                  var0.field945 = true;
                  break;
               }
            }
         }

         var0.field947[var1] = (byte)var3;
      } catch (RuntimeException var7) {
         throw class158.method3445(var7, "fd.kd(" + ')');
      }
   }
}
