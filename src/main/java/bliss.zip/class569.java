public class class569 {
   public static class764 field24;
   static int field25;
   static class219 field26;

   class569() throws Throwable {
      throw new Error();
   }

   static final void method10(class564 var0, class131 var1, class744 var2, int var3) {
      try {
         var0.field924 = var2.field3161[--var2.field3156] == 1;
         class814.method2932(var0, 242919800);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "kc.et(" + ')');
      }
   }

   static final void method11(class564 var0, class131 var1, class744 var2, int var3) {
      try {
         var2.field3156 -= 2;
         byte var4 = 10;
         int var5 = var2.field3161[var2.field3156];
         int var6 = var2.field3161[1 + var2.field3156];
         class576.method71(var0, var4, var5, var6, var2, -781902989);
      } catch (RuntimeException var7) {
         throw class158.method3445(var7, "kc.ki(" + ')');
      }
   }
}
