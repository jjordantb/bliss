public class class552 {
   long field534;
   short[] field535;
   short[] field536;
   int[] field537;

   public class552(long var1, int[] var3, short[] var4, short[] var5) {
      this.field534 = var1;
      this.field537 = var3;
      this.field536 = var4;
      this.field535 = var5;
   }

   public static boolean method457(int var0, byte var1) {
      try {
         return var0 == 0 || var0 == 17 || 6 == var0;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "rz.ff(" + ')');
      }
   }
}
