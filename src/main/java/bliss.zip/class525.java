import jaclib.memory.Z;

public interface class525 extends class943, class524 {
   boolean method2235(int var1, int var2);

   boolean method2236(int var1, int var2, Z var3);

   void method2755();

   void method2756();

   boolean method2237(int var1, int var2);

   void method2753();

   void method2754();

   boolean method2238(int var1, int var2);

   boolean method2239(int var1, int var2, Z var3);
}
