import jaclib.memory.Z;

public interface class525 extends class943, class524 {
   boolean method2236(int var1, int var2, Z var3);

   void method2755();

   boolean method2237(int var1, int var2);
}
