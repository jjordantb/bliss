public class class761 extends class511 {
   public int field4392;

   public class761(class963 var1) {
      super(var1, false);
   }
}
