public class class112 implements class799 {
   public static class112 field2109 = new class112("", 12);
   public static class112 field2110 = new class112("", 10);
   public static class112 field2111 = new class112("", 23);
   public static class112 field2112 = new class112("", 11);
   public static class112 field2113 = new class112("", 16);
   public static class112 field2114 = new class112("", 25);
   public static class112 field2115 = new class112("", 22);
   public static class112 field2116 = new class112("", 17);
   public static class112 field2117 = new class112("", 18);
   public static class112 field2118 = new class112("", 19);
   public static class112 field2119 = new class112("", 20);
   public static class112 field2120 = new class112("", 21);
   public static class112 field2121 = new class112("", 13);
   public static class112 field2122 = new class112("", 15);
   public static class112 field2123 = new class112("", 24);
   public static class112 field2124 = new class112("", 14);
   public static class112 field2125 = new class112("", 26);
   public static class112 field2126 = new class112("", 27);
   static class112 field2127 = new class112("", 73);
   static class112 field2128 = new class112("", 76);
   public int field2129;

   class112(String var1, int var2) {
      this.field2129 = var2 * 1197369919;
   }

   static void method1443(int var0) {
      try {
         int var1 = class759.field4331 * -2110394505;
         int var2 = class97.field614 * -1111710645;
         if (-639974669 * class919.field10433 < var1) {
            var1 = -639974669 * class919.field10433;
         }

         if (1282634425 * class730.field1812 < var2) {
            var2 = class730.field1812 * 1282634425;
         }

         try {
            class662.field9728.method5802(new Object[]{var1, var2, class660.method5750((byte)-5), class615.field8903.field9132.method2605(-1747444886)}, (short)28321);
         } catch (Throwable var4) {
            ;
         }

      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "ut.ge(" + ')');
      }
   }

   static final void method1444(class744 var0, int var1) {
      try {
         class241.method4705(727186143);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ut.agh(" + ')');
      }
   }

   static void method1445(int var0) {
      try {
         class921.field10285.method2979();
      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "ut.i(" + ')');
      }
   }
}
