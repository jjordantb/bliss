public class class343 extends class710 {
   public int field331;

   public class7 method6197(int var1) {
      try {
         return class7.field4914;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "afr.f(" + ')');
      }
   }

   class343(class971 var1, class49 var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, int var11, int var12, int var13, int var14, int var15, int var16) {
      super(var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15);
      this.field331 = var16 * -1980199237;
   }

   public class7 method6199() {
      return class7.field4914;
   }

   public class7 method6198() {
      return class7.field4914;
   }
}
