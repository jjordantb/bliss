public interface class70 {
   boolean method1040(class284 var1, class742[] var2, int var3, class352 var4, int var5);
}
