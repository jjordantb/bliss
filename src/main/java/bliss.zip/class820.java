import jaclib.memory.heap.NativeHeap;

public class class820 extends class792 {
   NativeHeap field4964;

   void method2995() {
      this.field4964.b();
   }

   class820(int var1) {
      this.field4964 = new NativeHeap(var1);
   }
}
