public class class595 {
   int field1923;
   int field1924;
   int field1925;
}
