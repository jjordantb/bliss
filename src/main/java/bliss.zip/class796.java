public class class796 {
   short[] field482;
   short field483;
   byte field484;
   short[] field485;
   short[] field486;
   short[] field487;
   int[] field488;
   int[] field489;
   short[] field490;
   short[] field491;
   short field492;
}
