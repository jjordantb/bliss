public class class809 implements class925 {
   public int field4584;
   public int field4585;
   public int field4586;
   public int field4587;
   public class971 field4588;
   public class49 field4589;
   public int field4590;
   public int field4591;
   public int field4592;
   public int field4593;
   public boolean field4594;
   static int field4595;

   public class7 method6197(int var1) {
      try {
         return class7.field4911;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "fk.f(" + ')');
      }
   }

   class809(int var1, class971 var2, class49 var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, boolean var11) {
      this.field4593 = var1;
      this.field4588 = var2;
      this.field4589 = var3;
      this.field4585 = var4;
      this.field4587 = var5;
      this.field4591 = var6;
      this.field4592 = var7;
      this.field4584 = var8;
      this.field4586 = var9;
      this.field4590 = var10;
      this.field4594 = var11;
   }

   static final void method2886(class744 var0, int var1) {
      try {
         class237 var2 = var0.field3178 ? var0.field3164 : var0.field3163;
         class564 var3 = var2.field8255;
         class131 var4 = var2.field8254;
         class75.method1118(var3, var4, true, 2, var0, -445613711);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "fk.hv(" + ')');
      }
   }

   static final void method2887(class744 var0, int var1) {
      try {
         class237 var2 = var0.field3178 ? var0.field3164 : var0.field3163;
         class564 var3 = var2.field8255;
         var0.field3161[++var0.field3156 - 1] = class730.method1761(var3).method1742((byte)-44);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "fk.ph(" + ')');
      }
   }

   public static void method2888(byte var0) {
      try {
         class818.field4614.method6566((byte)-14);
         class818.field4611 = 1;
         class818.field4621 = null;
         class818.field4625 = null;
      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "fk.x(" + ')');
      }
   }
}
