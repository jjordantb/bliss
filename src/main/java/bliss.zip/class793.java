public class class793 extends class697 {
   class76 field507;
   int field508 = -2081754389;

   class793(class76 var1) {
   }

   void method3820(class907 var1, int var2) {
      try {
         this.field508 = var1.method6374() * 2081754389;
         var1.method6371();
         if (var1.method6371() != 255) {
            var1.field10376 -= 116413311;
            var1.method6375((short)30041);
         }

      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "agk.a(" + ')');
      }
   }

   void method3821(class139 var1, int var2) {
      try {
         var1.method979(this.field508 * -528950723, -554375757);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "agk.f(" + ')');
      }
   }

   void method3822(class139 var1) {
      var1.method979(this.field508 * -528950723, -464922462);
   }

   void method3824(class139 var1) {
      var1.method979(this.field508 * -528950723, -489380093);
   }

   void method3823(class907 var1) {
      this.field508 = var1.method6374() * 2081754389;
      var1.method6371();
      if (var1.method6371() != 255) {
         var1.field10376 -= 116413311;
         var1.method6375((short)3485);
      }

   }

   void method3819(class907 var1) {
      this.field508 = var1.method6374() * 2081754389;
      var1.method6371();
      if (var1.method6371() != 255) {
         var1.field10376 -= 116413311;
         var1.method6375((short)22737);
      }

   }

   void method3825(class907 var1) {
      this.field508 = var1.method6374() * 2081754389;
      var1.method6371();
      if (var1.method6371() != 255) {
         var1.field10376 -= 116413311;
         var1.method6375((short)21753);
      }

   }

   static final void method435(class744 var0, short var1) {
      try {
         var0.field3168[(var0.field3162 += -682569305) * 1685767703 - 1] = var0.field3152[var0.field3174[1883543357 * var0.field3176]];
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "agk.by(" + ')');
      }
   }
}
