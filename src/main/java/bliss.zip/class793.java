public class class793 extends class697 {
   class76 field507;
   int field508 = -1;

   class793(class76 var1) {
   }

   void method3820(class907 var1, int var2) {
      try {
         this.field508 = var1.method6374();
         var1.method6371();
         if (var1.method6371() != 255) {
            --var1.field10376;
            var1.method6375((short)30041);
         }

      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "agk.a(" + ')');
      }
   }

   void method3821(class139 var1, int var2) {
      try {
         var1.method979(this.field508, -554375757);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "agk.f(" + ')');
      }
   }

   static final void method435(class744 var0, short var1) {
      try {
         var0.field3168[++var0.field3162 - 1] = var0.field3152[var0.field3174[var0.field3176]];
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "agk.by(" + ')');
      }
   }
}
