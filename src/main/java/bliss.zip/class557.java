public class class557 {
   public static class557 field495 = new class557(0);
   public static class557 field496 = new class557(2);
   public static class557 field497 = new class557(3);
   public static class557 field498 = new class557(1);
   public int field499;

   class557(int var1) {
      this.field499 = var1;
   }
}
