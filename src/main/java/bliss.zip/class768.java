public interface class768 {
   Object method2232(byte[] var1, class230 var2, boolean var3);

   Object method2233(byte[] var1, class230 var2, boolean var3, int var4);

   Object method2234(byte[] var1, class230 var2, boolean var3);
}
