public class class589 extends class476 implements class265 {
   boolean field271;
   boolean field272 = true;
   class719 field273;
   public class309 field274;

   public int method4564() {
      return 1686561661 * this.field274.field387;
   }

   public void method4559(class848 var1) {
      this.field274.method358(var1, -475225909);
   }

   boolean method2183(short var1) {
      try {
         return this.field272;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wb.be(" + ')');
      }
   }

   public int method211() {
      return this.field274.method350(2067905019);
   }

   public class719 method2165(class848 var1, byte var2) {
      try {
         return this.field273;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "wb.bc(" + ')');
      }
   }

   public int method2170(byte var1) {
      try {
         return this.field274.method350(2130168413);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wb.bx(" + ')');
      }
   }

   class192 method2201(class848 var1, int var2) {
      try {
         class879 var3 = this.field274.method351(var1, 2048, false, true, (byte)-57);
         if (var3 == null) {
            return null;
         } else {
            class135 var4 = this.method1521();
            class192 var5 = class221.method4033(this.field271, 2063497884);
            this.field274.method352(var1, var3, var4, this.field8299, this.field8297, this.field8296, this.field8298, true, -1012043162);
            var3.method5965(var4, this.field3642[0], 0);
            if (this.field274.field388 != null) {
               class874 var6 = this.field274.field388.method1729();
               var1.method4866(var6);
            }

            this.field272 = var3.method5989() || this.field274.field388 != null;
            class446 var8 = this.method1511();
            if (this.field273 == null) {
               this.field273 = class905.method6344((int)var8.field7637.field5296, (int)var8.field7637.field5300, (int)var8.field7637.field5299, var3, 2102300676);
            } else {
               class364.method1613(this.field273, (int)var8.field7637.field5296, (int)var8.field7637.field5300, (int)var8.field7637.field5299, var3, (byte)75);
            }

            return var5;
         }
      } catch (RuntimeException var7) {
         throw class158.method3445(var7, "wb.bo(" + ')');
      }
   }

   void method2164(class848 var1, int var2) {
      try {
         class879 var3 = this.field274.method351(var1, 262144, true, true, (byte)67);
         if (var3 != null) {
            this.field274.method352(var1, var3, this.method1521(), this.field8299, this.field8297, this.field8296, this.field8298, false, -2006037308);
         }

      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "wb.bb(" + ')');
      }
   }

   public void method212(class552 var1, int var2) {
      try {
         this.field274.method349(var1, -38768975);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "wb.bl(" + ')');
      }
   }

   boolean method2157(class848 var1, int var2, int var3, byte var4) {
      try {
         class879 var5 = this.field274.method351(var1, 131072, false, false, (byte)7);
         return var5 == null ? false : var5.method6097(var2, var3, this.method1521(), false, 0);
      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "wb.bu(" + ')');
      }
   }

   final boolean method2173(int var1) {
      return false;
   }

   public boolean method4558(int var1) {
      try {
         return this.field274.method357(1788044006);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wb.i(" + ')');
      }
   }

   public int method4551(byte var1) {
      try {
         return 1686561661 * this.field274.field387;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wb.a(" + ')');
      }
   }

   public int method4548(int var1) {
      try {
         return -1598457753 * this.field274.field375;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wb.f(" + ')');
      }
   }

   public int method4549(short var1) {
      try {
         return 748228569 * this.field274.field376;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wb.b(" + ')');
      }
   }

   public void method4550(byte var1) {
   }

   public int method2188() {
      return this.field274.method356(-1265114071);
   }

   public void method4552(class848 var1, int var2) {
      try {
         this.field274.method353(var1, -2138385554);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "wb.k(" + ')');
      }
   }

   public void method4556(class848 var1, int var2) {
      try {
         this.field274.method358(var1, -475225909);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "wb.d(" + ')');
      }
   }

   public class719 method2175(class848 var1) {
      return this.field273;
   }

   public int method4555() {
      return -1598457753 * this.field274.field375;
   }

   public int method213() {
      return this.field274.method350(2122295662);
   }

   public int method4561() {
      return 748228569 * this.field274.field376;
   }

   boolean method2206(byte var1) {
      return false;
   }

   public void method4553() {
   }

   public boolean method4560() {
      return this.field274.method357(1659146162);
   }

   boolean method2190() {
      return this.field272;
   }

   public int method4557() {
      return 748228569 * this.field274.field376;
   }

   public void method4563(class848 var1) {
      this.field274.method358(var1, -475225909);
   }

   boolean method2179(class848 var1, int var2, int var3) {
      class879 var4 = this.field274.method351(var1, 131072, false, false, (byte)40);
      return var4 == null ? false : var4.method6097(var2, var3, this.method1521(), false, 0);
   }

   boolean method2160() {
      return false;
   }

   boolean method2172() {
      return false;
   }

   boolean method2181() {
      return false;
   }

   final void method2184() {
      throw new IllegalStateException();
   }

   public int method4554() {
      return -1598457753 * this.field274.field375;
   }

   boolean method2159(class848 var1, int var2, int var3) {
      class879 var4 = this.field274.method351(var1, 131072, false, false, (byte)103);
      return var4 == null ? false : var4.method6097(var2, var3, this.method1521(), false, 0);
   }

   final boolean method2191() {
      return false;
   }

   class192 method2177(class848 var1) {
      class879 var2 = this.field274.method351(var1, 2048, false, true, (byte)16);
      if (var2 == null) {
         return null;
      } else {
         class135 var3 = this.method1521();
         class192 var4 = class221.method4033(this.field271, 1631876582);
         this.field274.method352(var1, var2, var3, this.field8299, this.field8297, this.field8296, this.field8298, true, -1124309983);
         var2.method5965(var3, this.field3642[0], 0);
         if (this.field274.field388 != null) {
            class874 var5 = this.field274.field388.method1729();
            var1.method4866(var5);
         }

         this.field272 = var2.method5989() || this.field274.field388 != null;
         class446 var6 = this.method1511();
         if (this.field273 == null) {
            this.field273 = class905.method6344((int)var6.field7637.field5296, (int)var6.field7637.field5300, (int)var6.field7637.field5299, var2, 2091041559);
         } else {
            class364.method1613(this.field273, (int)var6.field7637.field5296, (int)var6.field7637.field5300, (int)var6.field7637.field5299, var2, (byte)35);
         }

         return var4;
      }
   }

   void method2178(class848 var1) {
      class879 var2 = this.field274.method351(var1, 262144, true, true, (byte)-6);
      if (var2 != null) {
         this.field274.method352(var1, var2, this.method1521(), this.field8299, this.field8297, this.field8296, this.field8298, false, 1373727999);
      }

   }

   void method2180(class848 var1) {
      class879 var2 = this.field274.method351(var1, 262144, true, true, (byte)-61);
      if (var2 != null) {
         this.field274.method352(var1, var2, this.method1521(), this.field8299, this.field8297, this.field8296, this.field8298, false, 1730822364);
      }

   }

   final boolean method2194() {
      return false;
   }

   public void method4562(class848 var1) {
      this.field274.method358(var1, -475225909);
   }

   boolean method2189() {
      return this.field272;
   }

   boolean method2192(class848 var1, int var2, int var3) {
      class879 var4 = this.field274.method351(var1, 131072, false, false, (byte)28);
      return var4 == null ? false : var4.method6097(var2, var3, this.method1521(), false, 0);
   }

   public class719 method2174(class848 var1) {
      return this.field273;
   }

   final void method2182(class848 var1, class963 var2, int var3, int var4, int var5, boolean var6) {
      throw new IllegalStateException();
   }

   final void method2195(class848 var1, class963 var2, int var3, int var4, int var5, boolean var6) {
      throw new IllegalStateException();
   }

   final boolean method2207() {
      return false;
   }

   public class589(class545 var1, class848 var2, class240 var3, class50 var4, int var5, int var6, int var7, int var8, int var9, boolean var10, int var11, int var12, int var13, int var14, int var15, int var16, int var17) {
      super(var1, var5, var6, var7, var8, var9, var11, var12, var13, var14, 512737201 * var4.field2241 == 1, class147.method1144(var15, var16, -1836023814));
      this.field274 = new class309(var2, var3, var4, var15, var16, this.field3639, var6, this, var10, var17);
      this.field271 = 1532834983 * var4.field2214 != 0 && !var10;
      this.method2169(1, 823536706);
   }

   public int method2186() {
      return this.field274.method356(-462285436);
   }

   public void method4547(class848 var1) {
      this.field274.method353(var1, 700008268);
   }

   boolean method2176() {
      return this.field272;
   }

   boolean method2156() {
      return this.field272;
   }

   final void method2162(class848 var1, class963 var2, int var3, int var4, int var5, boolean var6, int var7) {
      try {
         throw new IllegalStateException();
      } catch (RuntimeException var9) {
         throw class158.method3445(var9, "wb.bk(" + ')');
      }
   }

   final void method2205(byte var1) {
      try {
         throw new IllegalStateException();
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wb.bq(" + ')');
      }
   }

   boolean method2158() {
      return this.field272;
   }

   final void method2185() {
      throw new IllegalStateException();
   }

   public int method2187() {
      return this.field274.method356(674885315);
   }

   final boolean method2193() {
      return false;
   }

   public int method2168(int var1) {
      try {
         return this.field274.method356(677575417);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wb.bm(" + ')');
      }
   }

   static final void method214(class744 var0, int var1) {
      try {
         int var2 = var0.field3161[(var0.field3156 -= -391880689) * 681479919];
         class564 var3 = class449.method3756(var2, (byte)-18);
         class131 var4 = class382.field1410[var2 >> 16];
         class309.method365(var3, var4, var0, (byte)0);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "wb.gw(" + ')');
      }
   }

   static final void method215(class744 var0, byte var1) {
      try {
         if (class396.field6515 != null && -316347407 * class721.field3635 < class198.field7051 * 367592105) {
            var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = class396.field6515[(class721.field3635 += 1578804497) * -316347407 - 1] & '\uffff';
         } else {
            var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = -1;
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wb.ads(" + ')');
      }
   }

   public static void method216(int var0, int var1) {
      try {
         class682 var2 = class370.method881(5, (long)var0);
         var2.method4336(-1791340902);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wb.x(" + ')');
      }
   }
}
