public class class357 extends class345 {
   String field1697;
   int field1698;
   int field1699;
   int field1700;
   long field1701;
   int field1702;
   int field1703;
   boolean field1704;
   boolean field1705;
   long field1706;
   String field1707;
   boolean field1708;
   String field1709;

   class357(String var1, String var2, int var3, int var4, int var5, long var6, int var8, int var9, boolean var10, boolean var11, long var12, boolean var14) {
      this.field1697 = var2;
      this.field1707 = var1;
      this.field1699 = 1854492667 * var3;
      this.field1702 = var4 * 233648799;
      this.field1700 = var5 * 1821305099;
      this.field1701 = -4396451777151645697L * var6;
      this.field1698 = var8 * 622278169;
      this.field1703 = 643860849 * var9;
      this.field1704 = var10;
      this.field1705 = var11;
      this.field1706 = var12 * -5795929892862797165L;
      this.field1708 = var14;
   }
}
