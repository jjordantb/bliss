public abstract class class721 {
   public static class916 field3634;
   public static int field3635;
   public static int field3636;

   abstract class695 method2136(int var1);

   abstract byte[] method2137(int var1, byte var2);

   abstract int method2139(int var1, int var2);

   abstract void method2142(int var1, short var2);

   static final void method2152(class744 var0, int var1) {
      try {
         var0.field3156 -= 2;
         int var2 = var0.field3161[var0.field3156];
         int var3 = var0.field3161[1 + var0.field3156];
         var0.field3161[++var0.field3156 - 1] = var3 * var2;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "kd.yr(" + ')');
      }
   }

   static final void method2153(class744 var0, byte var1) {
      try {
         int var2 = var0.field3161[--var0.field3156];
         class564 var3 = class449.method3756(var2, (byte)-71);
         class131 var4 = class382.field1410[var2 >> 16];
         class506.method2602(var3, var4, var0, 1901866056);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "kd.dn(" + ')');
      }
   }

   static final void method2154(class744 var0, int var1) {
      try {
         var0.field3156 -= 11;
         class971[] var2 = class812.method2915((byte)58);
         class49[] var3 = class147.method1146(1297575712);
         class141.method1093(var2[var0.field3161[var0.field3156]], var3[var0.field3161[1 + var0.field3156]], var0.field3161[2 + var0.field3156], var0.field3161[3 + var0.field3156], var0.field3161[4 + var0.field3156], var0.field3161[var0.field3156 + 5], var0.field3161[var0.field3156 + 6], var0.field3161[7 + var0.field3156], var0.field3161[var0.field3156 + 8], var0.field3161[9 + var0.field3156], var0.field3161[10 + var0.field3156], -1940539575);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "kd.se(" + ')');
      }
   }

   static void method2155(int var0, int var1, int var2) {
      try {
         class682 var3 = class370.method881(13, (long)var0);
         var3.method4340((byte)67);
         var3.field7687 = var1;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "kd.aq(" + ')');
      }
   }
}
