import java.util.ArrayList;

public final class class384 {
   static ArrayList field1422 = new ArrayList();
   static int field1423 = 200000;
   static int field1424 = 0;
   static int field1425 = 0;
   public static class1 field1426 = new class1(4);
   static boolean field1427 = false;
   static String field1428 = null;
   static int[] field1429 = new int[3];
   static int field1430 = 0;
   static int field1431 = 2000000;

   class384() throws Throwable {
      throw new Error();
   }

   static final void method1081(class744 var0, byte var1) {
      try {
         int var2 = var0.field3161[--var0.field3156];
         var0.field3161[++var0.field3156 - 1] = class730.field2809[var2];
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "qb.tc(" + ')');
      }
   }

   static final void method1082(class564 var0, class131 var1, class744 var2, byte var3) {
      try {
         var0.field936 = var2.field3161[--var2.field3156] == 1;
         class814.method2932(var0, 37472514);
         if (-1 == var0.field879 && !var1.field1101) {
            class823.method5364(var0.field867, 473698218);
         }

      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "qb.ga(" + ')');
      }
   }

   static final void method1083(class744 var0, int var1) {
      try {
         var0.field3161[++var0.field3156 - 1] = class615.field8903.field9133.method5729(1452563063) ? 1 : 0;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "qb.aod(" + ')');
      }
   }
}
