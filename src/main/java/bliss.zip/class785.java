public class class785 {
   char field3821;
   public int field3822;
   public String field3823;
   public boolean field3824 = true;
   public static class180 field3825;
   public static class180 field3826;
   public static class500 field3827;
   protected static class645[] field3828;

   void method2378(class907 var1, int var2) {
      try {
         while(true) {
            int var3 = var1.method6371();
            if (var3 == 0) {
               return;
            }

            this.method2379(var1, var3, -1263021902);
         }
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "um.a(" + ')');
      }
   }

   void method2379(class907 var1, int var2, int var3) {
      try {
         if (1 == var2) {
            this.field3821 = class954.method2092(var1.method6372(-12558881), 1872893689);
         } else if (2 == var2) {
            this.field3822 = var1.method6420((byte)-43);
         } else if (var2 == 4) {
            this.field3824 = false;
         } else if (var2 == 5) {
            this.field3823 = var1.method6379(-1509093879);
         }

      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "um.f(" + ')');
      }
   }

   public boolean method2380(int var1) {
      try {
         return this.field3821 == 's';
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "um.b(" + ')');
      }
   }

   static final void method2381(class744 var0, int var1) {
      try {
         class615.field8903.method5391(class615.field8903.field9143, var0.field3161[--var0.field3156], -1529967366);
         class95.method523(656179282);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "um.aiv(" + ')');
      }
   }

   static void method2382(String var0, String var1, int var2) {
      try {
         class881.field10140 = (Loader.field6962 ? -1058684408 : 471358088) * -122629167;
         class881.field10177 = Loader.field6962 ? class730.field2674 : class730.field2692;
         class521.method2751(false, false, var0, var1, -1L);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "um.z(" + ')');
      }
   }
}
