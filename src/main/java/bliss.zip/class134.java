import java.awt.Component;

public class class134 {
   public static int[] field1398;
   public static class478 field1399;

   class134() throws Throwable {
      throw new Error();
   }

   public static class352 method1035(Component var0, int var1) {
      try {
         return new class956(var0);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "mf.a(" + ')');
      }
   }

   static final void method1036(class744 var0, int var1) {
      try {
         var0.field3156 -= 3;
         int var2 = var0.field3161[var0.field3156];
         int var3 = var0.field3161[1 + var0.field3156];
         int var4 = var0.field3161[2 + var0.field3156];
         class740.method1920(7, var2 << 16 | var3, var4, "", 768379136);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "mf.ala(" + ')');
      }
   }
}
