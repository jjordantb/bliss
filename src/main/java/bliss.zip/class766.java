public class class766 extends class304 {
   int field4356;
   int field4357;
   int field4358;
   int field4359;
   class45 field4360;

   public void method2383(int var1) {
      try {
         this.field4360 = class671.method4237(this.field4358, this.field4359, 0, this.field4357, false, this.field4356, 1770406300);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "yc.f(" + ')');
      }
   }

   void method2384(int var1) {
      try {
         if (this.field4360 != null) {
            class385.method1180(this.field4360, (short)11811);
            this.field4360 = null;
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "yc.b(" + ')');
      }
   }

   class766(class907 var1) {
      super(var1);
      this.field4358 = var1.method6374();
      this.field4357 = var1.method6371();
      this.field4356 = var1.method6371();
      this.field4359 = var1.method6371();
   }

   static final void method2758(class744 var0, int var1) {
      try {
         class237 var2 = var0.field3178 ? var0.field3164 : var0.field3163;
         class564 var3 = var2.field8255;
         var0.field3161[++var0.field3156 - 1] = var3.field915;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "yc.pj(" + ')');
      }
   }

   static void method2759(byte var0) {
      try {
         class956.field3608[44] = 71;
         class956.field3608[45] = 26;
         class956.field3608[46] = 72;
         class956.field3608[47] = 73;
         class956.field3608[59] = 57;
         class956.field3608[61] = 27;
         class956.field3608[91] = 42;
         class956.field3608[92] = 74;
         class956.field3608[93] = 43;
         class956.field3608[192] = 28;
         class956.field3608[222] = 58;
         class956.field3608[520] = 59;
      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "yc.t(" + ')');
      }
   }

   static final void method2760(class744 var0, int var1) {
      try {
         int var2 = var0.field3161[--var0.field3156];
         class564 var3 = class449.method3756(var2, (byte)-74);
         var0.field3161[++var0.field3156 - 1] = var3.field1022;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "yc.rp(" + ')');
      }
   }
}
