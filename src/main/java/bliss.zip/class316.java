public abstract class class316 {
   abstract void method478(int var1, int var2, int var3, int var4, float var5, float var6, float var7, float var8, float[] var9, int var10);

   abstract void method479(int var1, int var2, int var3, int var4, float var5, float var6, float var7, float var8, float[] var9, int var10);

   abstract void method480(int var1, int var2, int var3, int var4, float var5, float var6, float var7, float var8, float[] var9, int var10);
}
