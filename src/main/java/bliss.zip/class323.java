public final class class323 {
   static long field628;
   static long field629;
   static class564[] field630;
   static String field631;

   class323() throws Throwable {
      throw new Error();
   }

   static final void method539(class744 var0, byte var1) {
      try {
         class237 var2 = var0.field3178 ? var0.field3164 : var0.field3163;
         class564 var3 = var2.field8255;
         class131 var4 = var2.field8254;
         class161.method3549(var3, var4, var0, -1057885619);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "dj.on(" + ')');
      }
   }

   static final void method540(class744 var0, int var1) {
      try {
         var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = var0.field3169.field9692 * -2079715533;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "dj.xz(" + ')');
      }
   }

   public static void method541(int var0, int var1) {
      try {
         class740.field3207 = -2138103821;
         class740.field3204 = var0 * 1998014133;
         class10.field6652 = -189172599;
         class622.field9010 = -338630500;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "dj.cg(" + ')');
      }
   }
}
