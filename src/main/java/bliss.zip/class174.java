public class class174 extends class959 {
   int field5076;
   static int field5077 = 1;
   static int field5078 = 3;
   static int field5079 = 2;
   class675 field5080;
   byte[] field5081;

   int method2036(int var1) {
      try {
         return super.field3464 ? 0 : 100;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "aks.f(" + ')');
      }
   }

   byte[] method2033(short var1) {
      try {
         if (super.field3464) {
            throw new RuntimeException();
         } else {
            return this.field5081;
         }
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "aks.a(" + ')');
      }
   }
}
