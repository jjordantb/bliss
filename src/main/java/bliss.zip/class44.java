public class class44 {
   public static int field5121 = 1;
   public static int field5122 = 131072;
   public static int field5123 = 131072;
   public static int field5124 = 32;
   public static int field5125 = 64;
   public static int field5126 = 262144;
   public static int field5127 = 512;
   public static int field5128 = 2;
   public static int field5129 = 4096;
   public static int field5130 = 16;
   public static int field5131 = 65536;
   public static int field5132 = 512;
   public static int field5133 = 2048;
   public static int field5134 = 16384;
   public static int field5135 = 128;
   public static int field5136 = 1024;
   public static int field5137 = 2097152;
   public static int field5138 = 4194304;
   public static int field5139 = 1048576;
   public static int field5140 = 1048576;
   public static int field5141 = 8;
   public static int field5142 = 65536;
   public static int field5143 = 524288;
   public static int field5144 = 32768;
   public static int field5145 = 128;
   public static int field5146 = 4;
   public static int field5147 = 16;
   public static int field5148 = 32;
   public static int field5149 = 4;
   public static int field5150 = 1;
   public static int field5151 = 2097152;
   public static int field5152 = 2;
   public static int field5153 = 16384;
   public static int field5154 = 1024;
   public static int field5155 = 256;
   public static int field5156 = 33554432;
   public static int field5157 = 8;
   public static int field5158 = 4096;
   public static int field5159 = 8192;
   public static int field5160 = 32768;
   public static int field5161 = 8388608;
   public static int field5162 = 8388608;
   public static int field5163 = 262144;
   public static int field5164 = 8192;
   public static int field5165 = 256;
   public static int field5166 = 4194304;
   public static int field5167 = 524288;
   public static int field5168 = 2048;
   public static int field5169 = 16777216;
   public static int field5170 = 64;

   class44() throws Throwable {
      throw new Error();
   }

   public static synchronized void method3082(byte[] var0, int var1) {
      try {
         if (100 == var0.length && class18.field6929 < 1000) {
            class18.field6931[++class18.field6929 - 1] = var0;
         } else if (5000 == var0.length && class18.field6927 < 250) {
            class18.field6926[++class18.field6927 - 1] = var0;
         } else if (30000 == var0.length && class18.field6928 < 50) {
            class18.field6932[++class18.field6928 - 1] = var0;
         } else if (class681.field7538 != null) {
            for(int var2 = 0; var2 < class128.field2348.length; ++var2) {
               if (var0.length == class128.field2348[var2] && class18.field6930[var2] < class681.field7538[var2].length) {
                  class681.field7538[var2][class18.field6930[var2]++] = var0;
                  break;
               }
            }
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "im.f(" + ')');
      }
   }

   static final void method3083(class744 var0, int var1) {
      try {
         int var2 = var0.field3161[--var0.field3156];
         var0.field3161[++var0.field3156 - 1] = var2 & 16383;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "im.te(" + ')');
      }
   }

   public static int method3084(byte var0) {
      try {
         return class198.field7038;
      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "im.k(" + ')');
      }
   }
}
