public class class722 extends class568 {
   public int field3631;
   public static long field3632;

   public class722(int var1) {
      this.field3631 = var1;
   }

   static final void method2132(class744 var0, byte var1) {
      try {
         int var2 = var0.field3161[--var0.field3156];
         class564 var3 = class449.method3756(var2, (byte)29);
         class131 var4 = class382.field1410[var2 >> 16];
         class172.method3030(var3, var4, var0, -364145193);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "abt.nt(" + ')');
      }
   }
}
