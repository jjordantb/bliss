public class class175 {
   static int field4987 = 16;
   class428 field4988;
   int[] field4989 = null;
   protected class545 field4990;
   static int field4991 = 1;
   public int field4992 = 0;
   public boolean field4993 = false;
   int[] field4994;
   public boolean field4995 = false;
   public boolean field4996 = false;
   public int field4997;
   protected int field4998;
   protected int field4999;
   public boolean field5000;
   static int field5001 = 512;
   public byte[][][] field5002;
   protected boolean field5003;
   static int field5004 = 64;
   static int[][] field5005 = new int[][]{{6, 6}, {6, 6}, {6, 5, 5}, {5, 6, 5}, {5, 5, 6}, {6, 5, 5}, {5, 0, 4, 1}, {7, 7, 1, 2}, {7, 1, 2, 7}, {8, 9, 4, 0, 8, 9}, {0, 8, 9, 8, 9, 4}, {11, 0, 10, 11, 4, 2}, {6, 6}, {7, 7, 1, 2}, {7, 7, 1, 2}};
   protected class153 field5006;
   byte[][][] field5007;
   protected byte[][][] field5008;
   static int[][] field5009 = new int[][]{{0, 2}, {0, 2}, {0, 0, 2}, {2, 0, 0}, {0, 2, 0}, {0, 0, 2}, {0, 5, 1, 4}, {0, 4, 4, 4}, {4, 4, 4, 0}, {6, 6, 6, 2, 2, 2}, {2, 2, 2, 6, 6, 6}, {0, 11, 6, 6, 6, 4}, {0, 2}, {0, 4, 4, 4}, {0, 4, 4, 4}};
   int[] field5010;
   int[] field5011;
   int[] field5012;
   int[] field5013;
   static int field5014 = 0;
   static int field5015 = 1;
   static int field5016 = 2;
   static int field5017 = 3;
   int[] field5018 = new int[13];
   static int field5019 = 2;
   static int[][] field5020 = new int[][]{{0, 2, 4, 6}, {6, 0, 2, 3, 5, 3}, {6, 0, 2, 4}, {2, 5, 6, 1}, {0, 2, 6}, {6, 0, 2}, {5, 6, 0, 1, 2, 4}, {7, 7, 1, 2, 4, 6}, {2, 4, 4, 7}, {6, 6, 4, 0, 1, 1, 3, 3}, {0, 2, 2, 6, 6, 4}, {0, 2, 2, 3, 7, 0, 4, 3}, {0, 2, 4, 6}};
   static int field5021 = 8;
   class509 field5022;
   static int field5023 = 32;
   public int[][][] field5024;
   static int field5025 = 128;
   static int field5026 = 256;
   static int[] field5027 = new int[]{0, 4, 3, 3, 1, 1, 3, 5, 1, 5, 3, 6, 4};
   static int field5028 = 4;
   static int[] field5029 = new int[]{0, 1, 2, 2, 1, 1, 2, 3, 1, 3, 3, 4, 2, 0, 4};
   static int[] field5030 = new int[]{4, 2, 1, 1, 2, 2, 3, 1, 3, 3, 3, 2, 0};
   static int[] field5031 = new int[]{0, 2, 2, 2, 1, 1, 3, 3, 1, 3, 3, 4, 4};
   static int[] field5032 = new int[]{4, 2, 1, 1, 2, 2, 3, 1, 3, 3, 3, 2, 0};
   static int[][] field5033 = new int[][]{{0, 1, 2, 3}, {1, -1, -1, 0}, {-1, 2, -1, 0}, {-1, 0, -1, 2}, {0, 1, -1, 2}, {1, 2, -1, 0}, {-1, 4, -1, 1}, {-1, 3, 4, -1}, {-1, 0, 2, -1}, {-1, -1, 2, 0}, {0, 2, 5, 3}, {0, -1, 6, -1}, {0, 1, 2, 3}};
   static int[] field5034 = new int[]{0, 256, 512, 512, 512, 256, 0, 0, 128, 256, 128, 384, 256};
   static int[] field5035 = new int[]{0, 0, 0, 256, 512, 512, 512, 256, 256, 384, 128, 128, 256};
   static boolean[][] field5036 = new boolean[][]{{true, true, true, true, true, true, true, true, true, true, true, true, true}, {true, true, true, false, false, false, true, true, false, false, false, false, true}, {true, false, false, false, false, true, true, true, false, false, false, false, false}, {false, false, true, true, true, true, false, false, false, false, false, false, false}, {true, true, true, true, true, true, false, false, false, false, false, false, false}, {true, true, true, false, false, true, true, true, false, false, false, false, false}, {true, true, false, false, false, true, true, true, false, false, false, false, true}, {true, true, false, false, false, false, false, true, false, false, false, false, false}, {false, true, true, true, true, true, true, true, false, false, false, false, false}, {true, false, false, false, true, true, true, true, true, true, false, false, false}, {true, true, true, true, true, false, false, false, true, true, false, false, false}, {true, true, true, false, false, false, false, false, false, false, true, true, false}, new boolean[13], {true, true, true, true, true, true, true, true, true, true, true, true, true}, new boolean[13]};
   static boolean[][] field5037 = new boolean[][]{new boolean[13], {false, false, true, true, true, true, true, false, false, false, false, false, true}, {true, true, true, true, true, true, false, false, false, false, false, false, false}, {true, true, true, false, false, true, true, true, false, false, false, false, false}, {true, false, false, false, false, true, true, true, false, false, false, false, false}, {false, false, true, true, true, true, false, false, false, false, false, false, false}, {false, true, true, true, true, true, false, false, false, false, false, false, true}, {false, true, true, true, true, true, true, true, false, false, false, false, true}, {true, true, false, false, false, false, false, true, false, false, false, false, false}, {true, true, true, true, true, false, false, false, true, true, false, false, false}, {true, false, false, false, true, true, true, true, true, true, false, false, false}, {true, false, true, true, true, true, true, true, false, false, true, true, false}, {true, true, true, true, true, true, true, true, true, true, true, true, true}, new boolean[13], {true, true, true, true, true, true, true, true, true, true, true, true, true}};
   static int field5038 = 0;
   byte[][][] field5039;
   int[] field5040;
   byte[][][] field5041;
   static int[][] field5042 = new int[][]{{0, 1, 2, 3}, {1, 2, 3, 0}, {1, 2, -1, 0}, {2, 0, -1, 1}, {0, 1, -1, 2}, {1, 2, -1, 0}, {-1, 4, -1, 1}, {-1, 1, 3, -1}, {-1, 0, 2, -1}, {3, 5, 2, 0}, {0, 2, 5, 3}, {0, 2, 3, 5}, {0, 1, 2, 3}};
   static int[][] field5043 = new int[][]{{0, 2, 4, 6}, {6, 0, 2, 4}, {6, 0, 2}, {2, 6, 0}, {0, 2, 6}, {6, 0, 2}, {5, 6, 0, 1, 2, 4}, {7, 2, 4, 4}, {2, 4, 4, 7}, {6, 6, 4, 0, 2, 2}, {0, 2, 2, 6, 6, 4}, {0, 2, 2, 4, 6, 6}, {0, 2, 4, 6}};
   static int[][] field5044 = new int[][]{{2, 4, 6, 0}, {0, 2, 4, 6}, {0, 2, 4}, {4, 0, 2}, {2, 4, 0}, {0, 2, 4}, {6, 0, 1, 2, 4, 5}, {0, 4, 7, 6}, {4, 7, 6, 0}, {0, 8, 6, 2, 9, 4}, {2, 9, 4, 0, 8, 6}, {2, 11, 4, 6, 10, 0}, {2, 4, 6, 0}};
   static int[][] field5045 = new int[][]{{12, 12, 12, 12}, {12, 12, 12, 12}, {5, 5, 5}, {5, 5, 5}, {5, 5, 5}, {5, 5, 5}, {12, 12, 12, 12, 12, 12}, {1, 1, 1, 7}, {1, 1, 7, 1}, {8, 9, 9, 8, 8, 9}, {8, 8, 9, 8, 9, 9}, {10, 10, 11, 11, 11, 10}, {12, 12, 12, 12}};
   static boolean[][] field5046 = new boolean[][]{new boolean[4], {false, true, true, false}, {true, false, true, false}, {true, false, true, false}, {false, false, true, false}, {false, false, true, false}, {true, false, true, false}, {true, false, false, true}, {true, false, false, true}, {true, true, false, false}, new boolean[4], {false, true, false, true}, new boolean[4]};
   boolean field5047;
   boolean field5048;
   static int[][] field5049 = new int[][]{{2, 4, 6, 0}, {0, 2, 3, 5, 6, 4}, {0, 1, 4, 5}, {4, 6, 0, 2}, {2, 4, 0}, {0, 2, 4}, {6, 0, 1, 2, 4, 5}, {0, 1, 2, 4, 6, 7}, {4, 7, 6, 0}, {0, 8, 6, 1, 9, 2, 9, 4}, {2, 9, 4, 0, 8, 6}, {2, 11, 3, 7, 10, 10, 6, 6}, {2, 4, 6, 0}};
   static int[][] field5050 = new int[][]{{12, 12, 12, 12}, {12, 12, 12, 12, 12, 5}, {5, 5, 1, 1}, {5, 1, 1, 5}, {5, 5, 5}, {5, 5, 5}, {12, 12, 12, 12, 12, 12}, {1, 12, 12, 12, 12, 12}, {1, 1, 7, 1}, {8, 9, 9, 8, 8, 3, 1, 9}, {8, 8, 9, 8, 9, 9}, {10, 10, 11, 11, 11, 7, 3, 7}, {12, 12, 12, 12}};
   int[] field5051 = new int[6];
   int[] field5052 = new int[13];
   int[] field5053 = new int[13];
   int[] field5054 = new int[13];
   int[] field5055 = new int[13];
   int field5056 = 0;
   int[] field5057 = new int[13];
   int field5058;
   int field5059;
   int field5060 = 0;
   static int[][] field5061 = new int[][]{{2, 4}, {2, 4}, {5, 2, 4}, {4, 5, 2}, {2, 4, 5}, {5, 2, 4}, {1, 6, 2, 5}, {1, 6, 7, 1}, {6, 7, 1, 1}, {0, 8, 9, 8, 9, 4}, {8, 9, 4, 0, 8, 9}, {2, 10, 0, 10, 11, 11}, {2, 4}, {1, 6, 7, 1}, {1, 6, 7, 1}};
   static int[] field5062 = new int[]{2, 1, 1, 1, 2, 2, 2, 1, 3, 3, 3, 2, 0, 4, 0};
   int field5063;
   int field5064;
   boolean field5065;
   static boolean[][] field5066 = new boolean[][]{new boolean[4], new boolean[4], {false, false, true, false}, {false, false, true, false}, {false, false, true, false}, {false, false, true, false}, {true, false, true, false}, {true, false, false, true}, {true, false, false, true}, new boolean[4], new boolean[4], new boolean[4], new boolean[4]};
   boolean field5067;
   public boolean field5068 = false;
   byte[][][] field5069;
   int field5070;
   int[] field5071;
   int field5072;
   int[] field5073;
   int field5074;
   static int field5075;

   public final void method3031(int var1, int[][] var2, int var3) {
      try {
         int[][] var4 = this.field5024[var1];

         for(int var5 = 0; var5 < this.field4998 * -954368823 + 1; ++var5) {
            for(int var6 = 0; var6 < 1 + this.field4999 * 181474463; ++var6) {
               var4[var5][var6] += var2[var5][var6];
            }
         }

      } catch (RuntimeException var7) {
         throw class158.method3445(var7, "kb.u(" + ')');
      }
   }

   public void method3032(int var1) {
      try {
         this.field5003 = true;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "kb.a(" + ')');
      }
   }

   public final void method3033(int var1, int var2, int var3, int var4, byte var5) {
      try {
         for(int var6 = 0; var6 < this.field4997 * 1551623871; ++var6) {
            this.method3034(var6, var1, var2, var3, var4, -994484260);
         }

      } catch (RuntimeException var7) {
         throw class158.method3445(var7, "kb.b(" + ')');
      }
   }

   public final void method3034(int var1, int var2, int var3, int var4, int var5, int var6) {
      try {
         int var7;
         for(var7 = var3; var7 < var5 + var3; ++var7) {
            for(int var8 = var2; var8 < var4 + var2; ++var8) {
               if (var8 >= 0 && var8 < this.field4998 * -954368823 && var7 >= 0 && var7 < this.field4999 * 181474463) {
                  this.field5024[var1][var8][var7] = var1 > 0 ? this.field5024[var1 - 1][var8][var7] - 960 : 0;
               }
            }
         }

         if (var2 > 0 && var2 < this.field4998 * -954368823) {
            for(var7 = 1 + var3; var7 < var3 + var5; ++var7) {
               if (var7 >= 0 && var7 < 181474463 * this.field4999) {
                  this.field5024[var1][var2][var7] = this.field5024[var1][var2 - 1][var7];
               }
            }
         }

         if (var3 > 0 && var3 < 181474463 * this.field4999) {
            for(var7 = 1 + var2; var7 < var4 + var2; ++var7) {
               if (var7 >= 0 && var7 < -954368823 * this.field4998) {
                  this.field5024[var1][var7][var3] = this.field5024[var1][var7][var3 - 1];
               }
            }
         }

         if (var2 >= 0 && var3 >= 0 && var2 < this.field4998 * -954368823 && var3 < this.field4999 * 181474463) {
            if (var1 == 0) {
               if (var2 > 0 && this.field5024[var1][var2 - 1][var3] != 0) {
                  this.field5024[var1][var2][var3] = this.field5024[var1][var2 - 1][var3];
               } else if (var3 > 0 && this.field5024[var1][var2][var3 - 1] != 0) {
                  this.field5024[var1][var2][var3] = this.field5024[var1][var2][var3 - 1];
               } else if (var2 > 0 && var3 > 0 && this.field5024[var1][var2 - 1][var3 - 1] != 0) {
                  this.field5024[var1][var2][var3] = this.field5024[var1][var2 - 1][var3 - 1];
               }
            } else if (var2 > 0 && this.field5024[var1][var2 - 1][var3] != this.field5024[var1 - 1][var2 - 1][var3]) {
               this.field5024[var1][var2][var3] = this.field5024[var1][var2 - 1][var3];
            } else if (var3 > 0 && this.field5024[var1][var2][var3 - 1] != this.field5024[var1 - 1][var2][var3 - 1]) {
               this.field5024[var1][var2][var3] = this.field5024[var1][var2][var3 - 1];
            } else if (var2 > 0 && var3 > 0 && this.field5024[var1][var2 - 1][var3 - 1] != this.field5024[var1 - 1][var2 - 1][var3 - 1]) {
               this.field5024[var1][var2][var3] = this.field5024[var1][var2 - 1][var3 - 1];
            }
         }

      } catch (RuntimeException var9) {
         throw class158.method3445(var9, "kb.p(" + ')');
      }
   }

   public final void method3035(class907 var1, int var2, int var3, int var4, int var5, class262[] var6, int var7) {
      try {
         int var8;
         int var10;
         int var11;
         int var12;
         if (!this.field5000) {
            for(var8 = 0; var8 < 4; ++var8) {
               class262 var9 = var6[var8];

               for(var10 = 0; var10 < 64; ++var10) {
                  for(var11 = 0; var11 < 64; ++var11) {
                     var12 = var2 + var10;
                     int var13 = var11 + var3;
                     if (var12 >= 0 && var12 < -954368823 * this.field4998 && var13 >= 0 && var13 < this.field4999 * 181474463) {
                        var9.method4530(var12, var13, -1001372278);
                     }
                  }
               }
            }
         }

         var8 = var2 + var4;
         int var15 = var5 + var3;

         for(var10 = 0; var10 < this.field4997 * 1551623871; ++var10) {
            for(var11 = 0; var11 < 64; ++var11) {
               for(var12 = 0; var12 < 64; ++var12) {
                  this.method3048(var1, var10, var11 + var2, var3 + var12, 0, 0, var11 + var8, var15 + var12, 0, false, -2042161970);
               }
            }
         }

      } catch (RuntimeException var14) {
         throw class158.method3445(var14, "kb.i(" + ')');
      }
   }

   public final void method3036(class907 var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, class262[] var9, int var10) {
      try {
         int var11 = (var6 & 7) * 8;
         int var12 = 8 * (var7 & 7);
         int var14;
         int var17;
         if (!this.field5000) {
            class262 var13 = var9[var2];

            for(var14 = 0; var14 < 8; ++var14) {
               for(int var15 = 0; var15 < 8; ++var15) {
                  int var16 = var3 + class596.method1456(var14 & 7, var15 & 7, var8, -1280307862);
                  var17 = var4 + class905.method6345(var14 & 7, var15 & 7, var8, (byte)-111);
                  if (var16 > 0 && var16 < this.field4998 * -954368823 - 1 && var17 > 0 && var17 < 181474463 * this.field4999 - 1) {
                     var13.method4530(var16, var17, -1032370407);
                  }
               }
            }
         }

         int var29 = (var6 & -8) << 3;
         var14 = (var7 & -8) << 3;
         byte var30 = 0;
         byte var31 = 0;
         if (1 == var8) {
            var31 = 1;
         } else if (2 == var8) {
            var30 = 1;
            var31 = 1;
         } else if (var8 == 3) {
            var30 = 1;
         }

         for(var17 = 0; var17 < 1551623871 * this.field4997; ++var17) {
            for(int var18 = 0; var18 < 64; ++var18) {
               for(int var19 = 0; var19 < 64; ++var19) {
                  if (var17 == var5 && var18 >= var11 && var18 <= var11 + 8 && var19 >= var12 && var19 <= var12 + 8) {
                     int var20;
                     int var21;
                     if (var18 != 8 + var11 && 8 + var12 != var19) {
                        var20 = var3 + class596.method1456(var18 & 7, var19 & 7, var8, -1280307862);
                        var21 = var4 + class905.method6345(var18 & 7, var19 & 7, var8, (byte)-33);
                        this.method3048(var1, var2, var20, var21, var30, var31, var18 + var29, var19 + var14, var8, false, -2042161970);
                     } else {
                        if (var8 == 0) {
                           var20 = var3 + (var18 - var11);
                           var21 = var4 + (var19 - var12);
                        } else if (1 == var8) {
                           var20 = var3 + (var19 - var12);
                           var21 = var4 + 8 - (var18 - var11);
                        } else if (2 == var8) {
                           var20 = var3 + 8 - (var18 - var11);
                           var21 = 8 + var4 - (var19 - var12);
                        } else {
                           var20 = 8 + var3 - (var19 - var12);
                           var21 = var4 + (var18 - var11);
                        }

                        this.method3048(var1, var2, var20, var21, 0, 0, var29 + var18, var19 + var14, 0, true, -2042161970);
                     }

                     if (63 == var18 || 63 == var19) {
                        byte var22 = 1;
                        if (var18 == 63 && var19 == 63) {
                           var22 = 3;
                        }

                        for(int var23 = 0; var23 < var22; ++var23) {
                           int var24 = var18;
                           int var25 = var19;
                           if (var23 == 0) {
                              var24 = var18 == 63 ? 64 : var18;
                              var25 = 63 == var19 ? 64 : var19;
                           } else if (1 == var23) {
                              var24 = 64;
                           } else if (2 == var23) {
                              var25 = 64;
                           }

                           int var26;
                           int var27;
                           if (var8 == 0) {
                              var26 = var3 + (var24 - var11);
                              var27 = var4 + (var25 - var12);
                           } else if (var8 == 1) {
                              var26 = var25 - var12 + var3;
                              var27 = 8 + var4 - (var24 - var11);
                           } else if (2 == var8) {
                              var26 = var3 + 8 - (var24 - var11);
                              var27 = var4 + 8 - (var25 - var12);
                           } else {
                              var26 = var3 + 8 - (var25 - var12);
                              var27 = var4 + (var24 - var11);
                           }

                           if (var26 >= 0 && var26 < this.field4998 * -954368823 && var27 >= 0 && var27 < 181474463 * this.field4999) {
                              this.field5024[var2][var26][var27] = this.field5024[var2][var20 + var30][var21 + var31];
                           }
                        }
                     }
                  } else {
                     this.method3048(var1, 0, -1, -1, 0, 0, 0, 0, 0, false, -2042161970);
                  }
               }
            }
         }

      } catch (RuntimeException var28) {
         throw class158.method3445(var28, "kb.k(" + ')');
      }
   }

   public void method3037(int var1) {
      try {
         this.field5040 = null;
         this.field5010 = null;
         this.field5011 = null;
         this.field5012 = null;
         this.field5013 = null;
         this.field5003 = false;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "kb.f(" + ')');
      }
   }

   public void method3038(class848 var1, int[][][] var2, class262[] var3, byte var4) {
      try {
         int var5;
         int var6;
         int var7;
         if (!this.field5000) {
            for(var5 = 0; var5 < 4; ++var5) {
               for(var6 = 0; var6 < this.field4998 * -954368823; ++var6) {
                  for(var7 = 0; var7 < this.field4999 * 181474463; ++var7) {
                     if ((this.field5006.field5406[var5][var6][var7] & 1) != 0) {
                        int var8 = var5;
                        if ((this.field5006.field5406[1][var6][var7] & 2) != 0) {
                           var8 = var5 - 1;
                        }

                        if (var8 >= 0) {
                           var3[var8].method4519(var6, var7, (byte)4);
                        }
                     }
                  }
               }
            }
         }

         for(var5 = 0; var5 < 1551623871 * this.field4997; ++var5) {
            var6 = 0;
            var7 = 0;
            if (!this.field5000) {
               if (this.field4993) {
                  var7 |= 8;
               }

               if (this.field5068) {
                  var6 |= 2;
               }

               if (917702315 * this.field4992 != 0) {
                  var6 |= 1;
                  var7 |= 16;
               }
            }

            if (this.field5068) {
               var7 |= 7;
            }

            if (!this.field4996) {
               var7 |= 32;
            }

            int[][] var10 = var2 != null && var5 < var2.length ? var2[var5] : this.field5024[var5];
            this.field4990.method2450(var5, var1.method4864(this.field4998 * -954368823, 181474463 * this.field4999, this.field5024[var5], var10, 512, var6, var7), (byte)32);
         }

      } catch (RuntimeException var9) {
         throw class158.method3445(var9, "kb.x(" + ')');
      }
   }

   public final void method3039(class848 var1, class454 var2, class454 var3, byte var4) {
      try {
         int[][] var5 = new int[this.field4998 * -954368823][181474463 * this.field4999];
         if (this.field5040 == null || this.field5040.length != 181474463 * this.field4999) {
            this.field5040 = new int[181474463 * this.field4999];
            this.field5010 = new int[this.field4999 * 181474463];
            this.field5011 = new int[181474463 * this.field4999];
            this.field5012 = new int[this.field4999 * 181474463];
            this.field5013 = new int[181474463 * this.field4999];
         }

         int var6;
         for(var6 = 0; var6 < 1551623871 * this.field4997; ++var6) {
            int var7;
            for(var7 = 0; var7 < this.field4999 * 181474463; ++var7) {
               this.field5040[var7] = 0;
               this.field5010[var7] = 0;
               this.field5011[var7] = 0;
               this.field5012[var7] = 0;
               this.field5013[var7] = 0;
            }

            for(var7 = -5; var7 < this.field4998 * -954368823; ++var7) {
               int var8;
               int var9;
               int var10;
               int var17;
               for(var8 = 0; var8 < this.field4999 * 181474463; ++var8) {
                  var9 = 5 + var7;
                  if (var9 < this.field4998 * -954368823) {
                     var10 = this.field5041[var6][var9][var8] & 255;
                     if (var10 > 0) {
                        class758 var11 = this.field4988.method4151(var10 - 1, (byte)-1);
                        this.field5040[var8] += var11.field4338 * 838046775;
                        this.field5010[var8] += -620399085 * var11.field4335;
                        this.field5011[var8] += 656695887 * var11.field4340;
                        this.field5012[var8] += var11.field4341 * -813159285;
                        ++this.field5013[var8];
                     }
                  }

                  var10 = var7 - 5;
                  if (var10 >= 0) {
                     var17 = this.field5041[var6][var10][var8] & 255;
                     if (var17 > 0) {
                        class758 var12 = this.field4988.method4151(var17 - 1, (byte)-1);
                        this.field5040[var8] -= var12.field4338 * 838046775;
                        this.field5010[var8] -= -620399085 * var12.field4335;
                        this.field5011[var8] -= var12.field4340 * 656695887;
                        this.field5012[var8] -= var12.field4341 * -813159285;
                        --this.field5013[var8];
                     }
                  }
               }

               if (var7 >= 0) {
                  var8 = 0;
                  var9 = 0;
                  var10 = 0;
                  var17 = 0;
                  int var18 = 0;

                  for(int var13 = -5; var13 < 181474463 * this.field4999; ++var13) {
                     int var14 = 5 + var13;
                     if (var14 < 181474463 * this.field4999) {
                        var8 += this.field5040[var14];
                        var9 += this.field5010[var14];
                        var10 += this.field5011[var14];
                        var17 += this.field5012[var14];
                        var18 += this.field5013[var14];
                     }

                     int var15 = var13 - 5;
                     if (var15 >= 0) {
                        var8 -= this.field5040[var15];
                        var9 -= this.field5010[var15];
                        var10 -= this.field5011[var15];
                        var17 -= this.field5012[var15];
                        var18 -= this.field5013[var15];
                     }

                     if (var13 >= 0 && var17 > 0 && var18 > 0) {
                        var5[var7][var13] = class916.method6457(256 * var8 / var17, var9 / var18, var10 / var18, -1708993857);
                     }
                  }
               }
            }

            if (this.field4995) {
               this.method3041(var1, this.field4990.field3862[var6], var6, var5, var6 == 0 ? var2 : null, var6 == 0 ? var3 : null, (byte)114);
            } else {
               this.method3040(var1, this.field4990.field3862[var6], var6, var5, var6 == 0 ? var2 : null, var6 == 0 ? var3 : null, (byte)-8);
            }

            this.field5041[var6] = null;
            this.field5007[var6] = null;
            this.field5069[var6] = null;
            this.field5039[var6] = null;
         }

         if (!this.field5000) {
            if (917702315 * this.field4992 != 0) {
               this.field4990.method2418((byte)-114);
            }

            if (this.field5068) {
               this.field4990.method2443((byte)-116);
            }
         }

         for(var6 = 0; var6 < 1551623871 * this.field4997; ++var6) {
            this.field4990.field3862[var6].method3898();
         }

      } catch (RuntimeException var16) {
         throw class158.method3445(var16, "kb.r(" + ')');
      }
   }

   void method3040(class848 var1, class454 var2, int var3, int[][] var4, class454 var5, class454 var6, byte var7) {
      try {
         for(int var8 = 0; var8 < -954368823 * this.field4998; ++var8) {
            for(int var9 = 0; var9 < this.field4999 * 181474463; ++var9) {
               byte var10 = this.field5069[var3][var8][var9];
               byte var11 = this.field5039[var3][var8][var9];
               int var12 = this.field5007[var3][var8][var9] & 255;
               int var13 = this.field5041[var3][var8][var9] & 255;
               class593 var14 = var12 != 0 ? this.field5022.method2527(var12 - 1, -165601895) : null;
               class758 var15 = var13 != 0 ? this.field4988.method4151(var13 - 1, (byte)-1) : null;
               if (var10 == 0 && var14 == null) {
                  var10 = 12;
               }

               class593 var16 = var14;
               if (var14 != null && var14.field1608 * -45966925 == -1 && -1 == var14.field1611 * 1728947183) {
                  var16 = var14;
                  var14 = null;
               }

               if (var14 == null && var15 == null) {
                  if (var7 == 0) {
                     throw new IllegalStateException();
                  }
               } else {
                  this.field5072 = 989325699 * field5029[var10];
                  this.field5070 = field5062[var10] * -786924081;
                  int var17 = (var14 != null ? 1500080431 * this.field5070 : 0) + (var15 != null ? -299537109 * this.field5072 : 0);
                  int var18 = 0;
                  this.field5059 = 0;
                  this.field5074 = (var14 != null ? 324071475 * var14.field1609 : -1) * -365069805;
                  int var19 = var15 != null ? var15.field4334 * 2012295231 : -1;
                  int[] var20 = new int[var17];
                  int[] var21 = new int[var17];
                  int[] var22 = new int[var17];
                  int[] var23 = new int[var17];
                  int[] var24 = new int[var17];
                  int[] var25 = new int[var17];
                  int[] var26 = var14 != null && 1728947183 * var14.field1611 != -1 ? new int[var17] : null;
                  int var27;
                  if (var14 != null) {
                     for(var27 = 0; var27 < 1500080431 * this.field5070; ++var27) {
                        var20[var18] = field5009[var10][this.field5059 * -875169383];
                        var21[var18] = field5061[var10][this.field5059 * -875169383];
                        var22[var18] = field5005[var10][this.field5059 * -875169383];
                        var24[var18] = this.field5074 * 1659854875;
                        var25[var18] = -1551409901 * var14.field1612;
                        var23[var18] = -45966925 * var14.field1608;
                        if (var26 != null) {
                           var26[var18] = var14.field1611 * 1728947183;
                        }

                        ++var18;
                        this.field5059 += -1319613783;
                     }

                     if (!this.field5000 && var3 == 0) {
                        this.field4990.method2413(var8, var9, 1987637503 * var14.field1616, 1104862312 * var14.field1618, 2077360047 * var14.field1606, var14.field1619 * -986621081, var14.field1620 * 171987805, -589660893 * var14.field1621, (byte)26);
                     }
                  } else {
                     this.field5059 += 640026119 * this.field5070;
                  }

                  if (var15 != null) {
                     for(var27 = 0; var27 < this.field5072 * -299537109; ++var27) {
                        var20[var18] = field5009[var10][this.field5059 * -875169383];
                        var21[var18] = field5061[var10][this.field5059 * -875169383];
                        var22[var18] = field5005[var10][this.field5059 * -875169383];
                        var24[var18] = var19;
                        var25[var18] = -1106852061 * var15.field4337;
                        var23[var18] = var4[var8][var9];
                        if (var26 != null) {
                           var26[var18] = var23[var18];
                        }

                        ++var18;
                        this.field5059 += -1319613783;
                     }
                  }

                  var27 = field5034.length;
                  int[] var28 = new int[var27];
                  int[] var29 = new int[var27];
                  int[] var30 = var6 != null ? new int[var27] : null;
                  int[] var31 = var6 == null && var5 == null ? null : new int[var27];

                  int var32;
                  int var33;
                  int var34;
                  int var35;
                  for(var32 = 0; var32 < var27; ++var32) {
                     var33 = field5034[var32];
                     var34 = field5035[var32];
                     if (var11 == 0) {
                        var28[var32] = var33;
                        var29[var32] = var34;
                     } else if (var11 == 1) {
                        var28[var32] = var34;
                        var29[var32] = 512 - var33;
                     } else if (var11 == 2) {
                        var28[var32] = 512 - var33;
                        var29[var32] = 512 - var34;
                     } else if (3 == var11) {
                        var28[var32] = 512 - var34;
                        var29[var32] = var33;
                     }

                     int var36;
                     if (var30 != null && field5036[var10][var32]) {
                        var35 = (var8 << 9) + var28[var32];
                        var36 = (var9 << 9) + var29[var32];
                        var30[var32] = var6.method3887(var35, var36, -1630287818) - var2.method3887(var35, var36, -1985119630);
                     }

                     if (var31 != null) {
                        if (var6 != null && !field5036[var10][var32]) {
                           var35 = var28[var32] + (var8 << 9);
                           var36 = (var9 << 9) + var29[var32];
                           var31[var32] = var2.method3887(var35, var36, -2021974678) - var6.method3887(var35, var36, -1548103444);
                        } else if (var5 != null && !field5037[var10][var32]) {
                           var35 = var28[var32] + (var8 << 9);
                           var36 = var29[var32] + (var9 << 9);
                           var31[var32] = var5.method3887(var35, var36, -1771548697) - var2.method3887(var35, var36, -1288158581);
                        }
                     }
                  }

                  var32 = var2.method3888(var8, var9, (byte)-95);
                  var33 = var2.method3888(1 + var8, var9, (byte)-111);
                  var34 = var2.method3888(1 + var8, var9 + 1, (byte)-31);
                  var35 = var2.method3888(var8, 1 + var9, (byte)-5);
                  boolean var39 = this.field5006.method3386(var8, var9, 471001785);
                  if (var39 && var3 > 1 || !var39 && var3 > 0) {
                     boolean var37 = true;
                     if (var15 != null && !var15.field4336) {
                        var37 = false;
                     } else if (var13 == 0 && var10 != 0) {
                        var37 = false;
                     } else if (var12 > 0 && var16 != null && !var16.field1614) {
                        var37 = false;
                     }

                     if (var37 && var33 == var32 && var32 == var34 && var35 == var32) {
                        this.field5008[var3][var8][var9] = (byte)(this.field5008[var3][var8][var9] | 4);
                     }
                  }

                  class919 var40 = new class919();
                  if (this.field5000) {
                     var40.field10426 = this.field4990.method2409(var8, var9, (byte)76) * 614121861;
                     var40.field10425 = this.field4990.method2408(var8, var9, (byte)47) * -885436027;
                     var40.field10427 = this.field4990.method2410(var8, var9, (byte)-105) * 399458545;
                     var40.field10429 = this.field4990.method2411(var8, var9, (byte)90) * 1507836083;
                     var40.field10430 = this.field4990.method2454(var8, var9, -374977085) * -1927451111;
                     var40.field10432 = this.field4990.method2412(var8, var9, -1965414520) * -875460563;
                  }

                  var2.method3883(var8, var9, var28, var30, var29, var31, var20, var21, var22, var23, var26, var24, var25, var40, false);
                  this.field4990.method2407(var3, var8, var9, -239048224);
               }
            }
         }

      } catch (RuntimeException var38) {
         throw class158.method3445(var38, "kb.q(" + ')');
      }
   }

   void method3041(class848 var1, class454 var2, int var3, int[][] var4, class454 var5, class454 var6, byte var7) {
      try {
         byte[][] var8 = this.field5069[var3];
         byte[][] var9 = this.field5039[var3];
         byte[][] var10 = this.field5041[var3];
         byte[][] var11 = this.field5007[var3];
         boolean[] var12 = new boolean[4];

         for(int var13 = 0; var13 < -954368823 * this.field4998; ++var13) {
            int var14 = var13 < this.field4998 * -954368823 - 1 ? 1 + var13 : var13;

            for(int var15 = 0; var15 < this.field4999 * 181474463; ++var15) {
               int var16 = var15 < 181474463 * this.field4999 - 1 ? var15 + 1 : var15;
               this.field5058 = var8[var13][var15] * 1375153633;
               this.field5059 = -1319613783 * var9[var13][var15];
               int var17 = var11[var13][var15] & 255;
               int var18 = var10[var13][var15] & 255;
               if (var17 == 0 && var18 == 0) {
                  if (var7 <= -1) {
                     return;
                  }
               } else {
                  class593 var19 = var17 != 0 ? this.field5022.method2527(var17 - 1, -165601895) : null;
                  class758 var20 = var18 != 0 ? this.field4988.method4151(var18 - 1, (byte)-1) : null;
                  if (-1377184223 * this.field5058 == 0 && var19 == null) {
                     this.field5058 = -678025588;
                  }

                  this.field5065 = false;
                  this.field5047 = false;
                  var12[3] = false;
                  var12[2] = false;
                  var12[1] = false;
                  var12[0] = false;
                  class593 var24 = var19;
                  if (var19 != null) {
                     if (var19.field1608 * -45966925 == -1 && var19.field1611 * 1728947183 == -1) {
                        var24 = var19;
                        var19 = null;
                     } else if (var20 != null && -1377184223 * this.field5058 != 0) {
                        this.field5047 = var19.field1615;
                     }
                  }

                  this.field5059 = this.method3042(var18, var13, var15, var14, var16, var2, var10, -1666801922) * -1319613783;

                  int var25;
                  for(var25 = 0; var25 < 13; ++var25) {
                     this.field5018[var25] = -1;
                     this.field5057[var25] = 1;
                  }

                  this.method3043(var1, var19, var20, var13, var15, var8, var9, var11, var12, (short)803);
                  this.field5067 = !this.field5047 && !var12[0] && !var12[2] && !var12[1] && !var12[3];
                  this.method3044(var19, var20, (byte)4);
                  var25 = -299537109 * this.field5072 + 1500080431 * this.field5070;
                  if (var25 <= 0) {
                     this.field4990.method2407(var3, var13, var15, 1960447518);
                  } else {
                     if (var12[0]) {
                        ++var25;
                     }

                     if (var12[2]) {
                        ++var25;
                     }

                     if (var12[1]) {
                        ++var25;
                     }

                     if (var12[3]) {
                        ++var25;
                     }

                     this.field5060 = 0;
                     this.field5056 = 0;
                     int var26 = 3 * var25;
                     int[] var27 = this.field5048 ? new int[var26] : null;
                     int[] var28 = new int[var26];
                     int[] var29 = new int[var26];
                     int[] var30 = new int[var26];
                     int[] var31 = new int[var26];
                     int[] var32 = new int[var26];
                     int[] var33 = var6 != null ? new int[var26] : null;
                     int[] var34 = var6 == null && var5 == null ? null : new int[var26];
                     this.method3045(var1, var3, var13, var15, var19, var12, var27, var28, var29, var30, var31, var32, var33, var34, var2, var6, var5, (byte)-84);
                     int var35 = var10[var13][var16] & 255;
                     int var36 = var10[var14][var16] & 255;
                     int var37 = var10[var14][var15] & 255;
                     this.method3046(var1, var3, var13, var15, var14, var16, var20, var18, var35, var36, var37, var12, var27, var28, var29, var30, var31, var32, var33, var34, var4, var2, var6, var5, (short)9391);
                     this.method3049(var2, var20, var24, var3, var13, var15, var14, var16, var18, var17, 1222931725);
                     class919 var38 = new class919();
                     if (this.field5000) {
                        var38.field10426 = this.field4990.method2409(var13, var15, (byte)60) * 614121861;
                        var38.field10425 = this.field4990.method2408(var13, var15, (byte)89) * -885436027;
                        var38.field10427 = this.field4990.method2410(var13, var15, (byte)-43) * 399458545;
                        var38.field10429 = this.field4990.method2411(var13, var15, (byte)2) * 1507836083;
                        var38.field10430 = this.field4990.method2454(var13, var15, -37055227) * -1927451111;
                        var38.field10432 = this.field4990.method2412(var13, var15, -1965414520) * -875460563;
                     }

                     var2.method3882(var13, var15, var28, var33, var29, var34, var30, var27, var31, var32, var38, this.field5065);
                     this.field4990.method2407(var3, var13, var15, 200248008);
                  }
               }
            }
         }

      } catch (RuntimeException var39) {
         throw class158.method3445(var39, "kb.n(" + ')');
      }
   }

   int method3042(int var1, int var2, int var3, int var4, int var5, class454 var6, byte[][] var7, int var8) {
      try {
         if ((this.field5058 * -1377184223 == 0 || 12 == this.field5058 * -1377184223) && var2 > 0 && var3 > 0 && var2 < this.field4998 * -954368823 && var3 < this.field4999 * 181474463) {
            byte var9 = 0;
            byte var10 = 0;
            byte var11 = 0;
            byte var12 = 0;
            int var16 = var9 + (var1 == var7[var2 - 1][var3 - 1] ? 1 : -1);
            int var17 = var10 + (var7[var4][var3 - 1] == var1 ? 1 : -1);
            int var18 = var11 + (var1 == var7[var4][var5] ? 1 : -1);
            int var19 = var12 + (var1 == var7[var2 - 1][var5] ? 1 : -1);
            if (var7[var2][var3 - 1] == var1) {
               ++var16;
               ++var17;
            } else {
               --var16;
               --var17;
            }

            if (var1 == var7[var4][var3]) {
               ++var17;
               ++var18;
            } else {
               --var17;
               --var18;
            }

            if (var1 == var7[var2][var5]) {
               ++var18;
               ++var19;
            } else {
               --var18;
               --var19;
            }

            if (var7[var2 - 1][var3] == var1) {
               ++var19;
               ++var16;
            } else {
               --var19;
               --var16;
            }

            int var13 = var16 - var18;
            if (var13 < 0) {
               var13 = -var13;
            }

            int var14 = var17 - var19;
            if (var14 < 0) {
               var14 = -var14;
            }

            if (var13 == var14) {
               var13 = var6.method3888(var2, var3, (byte)-74) - var6.method3888(var4, var5, (byte)-114);
               if (var13 < 0) {
                  var13 = -var13;
               }

               var14 = var6.method3888(var4, var3, (byte)-76) - var6.method3888(var2, var5, (byte)-82);
               if (var14 < 0) {
                  var14 = -var14;
               }
            }

            return var13 < var14 ? 1 : 0;
         } else {
            return -875169383 * this.field5059;
         }
      } catch (RuntimeException var15) {
         throw class158.method3445(var15, "kb.s(" + ')');
      }
   }

   void method3043(class848 var1, class593 var2, class758 var3, int var4, int var5, byte[][] var6, byte[][] var7, byte[][] var8, boolean[] var9, short var10) {
      try {
         boolean[] var11 = var2 != null && var2.field1615 ? field5046[-1377184223 * this.field5058] : field5066[this.field5058 * -1377184223];
         this.method3047(var1, var2, var3, var4, var5, -954368823 * this.field4998, 181474463 * this.field4999, var8, var6, var7, var9, -2064335777);
         this.field5048 = var2 != null && -45966925 * var2.field1608 != 1728947183 * var2.field1611;
         if (!this.field5048) {
            for(int var12 = 0; var12 < 8; ++var12) {
               if (this.field5018[var12] >= 0 && this.field5053[var12] != this.field5052[var12]) {
                  this.field5048 = true;
                  break;
               }
            }
         }

         byte var13;
         if (!var11[1 + this.field5059 * -875169383 & 3]) {
            var13 = 1;
            var9[var13] |= (this.field5057[2] & this.field5057[4]) == 0;
         }

         if (!var11[3 + this.field5059 * -875169383 & 3]) {
            var13 = 3;
            var9[var13] |= (this.field5057[6] & this.field5057[0]) == 0;
         }

         if (!var11[0 + -875169383 * this.field5059 & 3]) {
            var13 = 0;
            var9[var13] |= (this.field5057[0] & this.field5057[2]) == 0;
         }

         if (!var11[this.field5059 * -875169383 + 2 & 3]) {
            var13 = 2;
            var9[var13] |= (this.field5057[4] & this.field5057[6]) == 0;
         }

         if (!this.field5047 && (this.field5058 * -1377184223 == 0 || -1377184223 * this.field5058 == 12)) {
            if (var9[0] && !var9[1] && !var9[2] && var9[3]) {
               var9[3] = false;
               var9[0] = false;
               this.field5058 = 1375153633 * (this.field5058 * -1377184223 == 0 ? 13 : 14);
               this.field5059 = 0;
            } else if (var9[0] && var9[1] && !var9[2] && !var9[3]) {
               var9[1] = false;
               var9[0] = false;
               this.field5058 = 1375153633 * (-1377184223 * this.field5058 == 0 ? 13 : 14);
               this.field5059 = 336125947;
            } else if (!var9[0] && var9[1] && var9[2] && !var9[3]) {
               var9[2] = false;
               var9[1] = false;
               this.field5058 = (this.field5058 * -1377184223 == 0 ? 13 : 14) * 1375153633;
               this.field5059 = 1655739730;
            } else if (!var9[0] && !var9[1] && var9[2] && var9[3]) {
               var9[3] = false;
               var9[2] = false;
               this.field5058 = (-1377184223 * this.field5058 == 0 ? 13 : 14) * 1375153633;
               this.field5059 = -1319613783;
            }
         }

      } catch (RuntimeException var14) {
         throw class158.method3445(var14, "kb.z(" + ')');
      }
   }

   void method3044(class593 var1, class758 var2, byte var3) {
      try {
         if (this.field5067) {
            this.field5071 = field5009[-1377184223 * this.field5058];
            this.field4994 = field5061[-1377184223 * this.field5058];
            this.field5073 = field5005[this.field5058 * -1377184223];
            this.field5070 = (var1 != null ? field5062[this.field5058 * -1377184223] : 0) * -786924081;
            this.field5072 = 989325699 * (var2 != null ? field5029[this.field5058 * -1377184223] : 0);
         } else if (this.field5047) {
            this.field5071 = field5020[this.field5058 * -1377184223];
            this.field4994 = field5049[-1377184223 * this.field5058];
            this.field5073 = field5050[this.field5058 * -1377184223];
            this.field5070 = -786924081 * (var1 != null ? field5032[this.field5058 * -1377184223] : 0);
            this.field5072 = (var2 != null ? field5027[-1377184223 * this.field5058] : 0) * 989325699;
            this.field4989 = field5033[this.field5058 * -1377184223];
         } else {
            this.field5071 = field5043[this.field5058 * -1377184223];
            this.field4994 = field5044[this.field5058 * -1377184223];
            this.field5073 = field5045[-1377184223 * this.field5058];
            this.field5070 = -786924081 * (var1 != null ? field5030[-1377184223 * this.field5058] : 0);
            this.field5072 = 989325699 * (var2 != null ? field5031[this.field5058 * -1377184223] : 0);
            this.field4989 = field5042[-1377184223 * this.field5058];
         }

      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "kb.y(" + ')');
      }
   }

   void method3045(class848 var1, int var2, int var3, int var4, class593 var5, boolean[] var6, int[] var7, int[] var8, int[] var9, int[] var10, int[] var11, int[] var12, int[] var13, int[] var14, class454 var15, class454 var16, class454 var17, byte var18) {
      try {
         this.field5064 = -1010428415;
         this.field5074 = 365069805;
         this.field5063 = 1240828160;
         if (var5 != null) {
            this.field5064 = var5.field1608 * 269878349;
            this.field5074 = -610197047 * var5.field1609;
            this.field5063 = var5.field1612 * -1360069077;
            int var19 = class26.method3483(var1, var5, (byte)16);

            for(int var20 = 0; var20 < this.field5070 * 1500080431; ++var20) {
               boolean var21 = false;
               byte var22;
               if (var6[0 - this.field5059 * -875169383 & 3] && this.field4989[0] == -740850409 * this.field5060) {
                  this.field5051[0] = this.field5071[this.field5060 * -740850409];
                  this.field5051[1] = 1;
                  this.field5051[2] = this.field5073[this.field5060 * -740850409];
                  this.field5051[3] = 1;
                  this.field5051[4] = this.field4994[-740850409 * this.field5060];
                  this.field5051[5] = this.field5073[-740850409 * this.field5060];
                  var22 = 6;
               } else if (var6[2 - -875169383 * this.field5059 & 3] && -740850409 * this.field5060 == this.field4989[2]) {
                  this.field5051[0] = this.field5071[this.field5060 * -740850409];
                  this.field5051[1] = 5;
                  this.field5051[2] = this.field5073[this.field5060 * -740850409];
                  this.field5051[3] = 5;
                  this.field5051[4] = this.field4994[this.field5060 * -740850409];
                  this.field5051[5] = this.field5073[this.field5060 * -740850409];
                  var22 = 6;
               } else if (var6[1 - -875169383 * this.field5059 & 3] && this.field4989[1] == this.field5060 * -740850409) {
                  this.field5051[0] = this.field5071[this.field5060 * -740850409];
                  this.field5051[1] = 3;
                  this.field5051[2] = this.field5073[this.field5060 * -740850409];
                  this.field5051[3] = 3;
                  this.field5051[4] = this.field4994[-740850409 * this.field5060];
                  this.field5051[5] = this.field5073[-740850409 * this.field5060];
                  var22 = 6;
               } else if (var6[3 - this.field5059 * -875169383 & 3] && -740850409 * this.field5060 == this.field4989[3]) {
                  this.field5051[0] = this.field5071[this.field5060 * -740850409];
                  this.field5051[1] = 7;
                  this.field5051[2] = this.field5073[-740850409 * this.field5060];
                  this.field5051[3] = 7;
                  this.field5051[4] = this.field4994[this.field5060 * -740850409];
                  this.field5051[5] = this.field5073[-740850409 * this.field5060];
                  var22 = 6;
               } else {
                  this.field5051[0] = this.field5071[-740850409 * this.field5060];
                  this.field5051[1] = this.field4994[-740850409 * this.field5060];
                  this.field5051[2] = this.field5073[-740850409 * this.field5060];
                  var22 = 3;
               }

               for(int var23 = 0; var23 < var22; ++var23) {
                  int var24 = this.field5051[var23];
                  int var25 = var24 - -1750338766 * this.field5059 & 7;
                  int var26 = field5034[var24];
                  int var27 = field5035[var24];
                  int var28;
                  int var29;
                  if (1 == this.field5059 * -875169383) {
                     var28 = var27;
                     var29 = 512 - var26;
                  } else if (this.field5059 * -875169383 == 2) {
                     var28 = 512 - var26;
                     var29 = 512 - var27;
                  } else if (3 == this.field5059 * -875169383) {
                     var28 = 512 - var27;
                     var29 = var26;
                  } else {
                     var28 = var26;
                     var29 = var27;
                  }

                  var8[-1679056507 * this.field5056] = var28;
                  var9[-1679056507 * this.field5056] = var29;
                  int var30;
                  int var31;
                  if (var13 != null && field5036[this.field5058 * -1377184223][var24]) {
                     var30 = (var3 << 9) + var28;
                     var31 = (var4 << 9) + var29;
                     var13[this.field5056 * -1679056507] = var16.method3887(var30, var31, -2146471706) - var15.method3887(var30, var31, -1684141409);
                  }

                  if (var14 != null) {
                     if (var16 != null && !field5036[this.field5058 * -1377184223][var24]) {
                        var30 = (var3 << 9) + var28;
                        var31 = (var4 << 9) + var29;
                        var14[-1679056507 * this.field5056] = var15.method3887(var30, var31, -1369260401) - var16.method3887(var30, var31, -1894367139);
                     } else if (var17 != null && !field5037[-1377184223 * this.field5058][var24]) {
                        var30 = (var3 << 9) + var28;
                        var31 = var29 + (var4 << 9);
                        var14[-1679056507 * this.field5056] = var17.method3887(var30, var31, -1817561670) - var15.method3887(var30, var31, -1384792854);
                     }
                  }

                  if (var24 < 8 && this.field5018[var25] > 2109091647 * var5.field1607) {
                     if (var7 != null) {
                        var7[this.field5056 * -1679056507] = this.field5053[var25];
                     }

                     var12[-1679056507 * this.field5056] = this.field5055[var25];
                     var11[-1679056507 * this.field5056] = this.field5054[var25];
                     var10[this.field5056 * -1679056507] = this.field5052[var25];
                  } else {
                     if (var7 != null) {
                        var7[this.field5056 * -1679056507] = var19;
                     }

                     var11[this.field5056 * -1679056507] = 324071475 * var5.field1609;
                     var12[-1679056507 * this.field5056] = -1551409901 * var5.field1612;
                     var10[this.field5056 * -1679056507] = 1373771263 * this.field5064;
                  }

                  this.field5056 += 107294541;
               }

               this.field5060 += 844235431;
            }

            if (!this.field5000 && var2 == 0) {
               this.field4990.method2413(var3, var4, 1987637503 * var5.field1616, 1104862312 * var5.field1618, var5.field1606 * 2077360047, -986621081 * var5.field1619, 171987805 * var5.field1620, -589660893 * var5.field1621, (byte)-43);
            }

            if (this.field5058 * -1377184223 != 12 && -45966925 * var5.field1608 != -1 && var5.field1613) {
               this.field5065 = true;
            }
         } else if (this.field5067) {
            this.field5060 += 844235431 * field5062[this.field5058 * -1377184223];
         } else if (this.field5047) {
            this.field5060 += 844235431 * field5032[this.field5058 * -1377184223];
         } else {
            this.field5060 += 844235431 * field5030[this.field5058 * -1377184223];
         }

      } catch (RuntimeException var32) {
         throw class158.method3445(var32, "kb.t(" + ')');
      }
   }

   void method3046(class848 var1, int var2, int var3, int var4, int var5, int var6, class758 var7, int var8, int var9, int var10, int var11, boolean[] var12, int[] var13, int[] var14, int[] var15, int[] var16, int[] var17, int[] var18, int[] var19, int[] var20, int[][] var21, class454 var22, class454 var23, class454 var24, short var25) {
      try {
         if (var7 != null) {
            if (var9 == 0) {
               var9 = var8;
            }

            if (var10 == 0) {
               var10 = var8;
            }

            if (var11 == 0) {
               var11 = var8;
            }

            class758 var26 = this.field4988.method4151(var8 - 1, (byte)-1);
            class758 var27 = this.field4988.method4151(var9 - 1, (byte)-1);
            class758 var28 = this.field4988.method4151(var10 - 1, (byte)-1);
            class758 var29 = this.field4988.method4151(var11 - 1, (byte)-1);

            for(int var30 = 0; var30 < this.field5072 * -299537109; ++var30) {
               boolean var31 = false;
               byte var32;
               if (var12[0 - -875169383 * this.field5059 & 3] && -740850409 * this.field5060 == this.field4989[0]) {
                  this.field5051[0] = this.field5071[-740850409 * this.field5060];
                  this.field5051[1] = 1;
                  this.field5051[2] = this.field5073[-740850409 * this.field5060];
                  this.field5051[3] = 1;
                  this.field5051[4] = this.field4994[this.field5060 * -740850409];
                  this.field5051[5] = this.field5073[-740850409 * this.field5060];
                  var32 = 6;
               } else if (var12[2 - this.field5059 * -875169383 & 3] && -740850409 * this.field5060 == this.field4989[2]) {
                  this.field5051[0] = this.field5071[-740850409 * this.field5060];
                  this.field5051[1] = 5;
                  this.field5051[2] = this.field5073[this.field5060 * -740850409];
                  this.field5051[3] = 5;
                  this.field5051[4] = this.field4994[this.field5060 * -740850409];
                  this.field5051[5] = this.field5073[this.field5060 * -740850409];
                  var32 = 6;
               } else if (var12[1 - -875169383 * this.field5059 & 3] && -740850409 * this.field5060 == this.field4989[1]) {
                  this.field5051[0] = this.field5071[-740850409 * this.field5060];
                  this.field5051[1] = 3;
                  this.field5051[2] = this.field5073[-740850409 * this.field5060];
                  this.field5051[3] = 3;
                  this.field5051[4] = this.field4994[this.field5060 * -740850409];
                  this.field5051[5] = this.field5073[this.field5060 * -740850409];
                  var32 = 6;
               } else if (var12[3 - this.field5059 * -875169383 & 3] && this.field4989[3] == this.field5060 * -740850409) {
                  this.field5051[0] = this.field5071[this.field5060 * -740850409];
                  this.field5051[1] = 7;
                  this.field5051[2] = this.field5073[this.field5060 * -740850409];
                  this.field5051[3] = 7;
                  this.field5051[4] = this.field4994[this.field5060 * -740850409];
                  this.field5051[5] = this.field5073[-740850409 * this.field5060];
                  var32 = 6;
               } else {
                  this.field5051[0] = this.field5071[-740850409 * this.field5060];
                  this.field5051[1] = this.field4994[this.field5060 * -740850409];
                  this.field5051[2] = this.field5073[-740850409 * this.field5060];
                  var32 = 3;
               }

               for(int var33 = 0; var33 < var32; ++var33) {
                  int var34 = this.field5051[var33];
                  int var35 = var34 - this.field5059 * -1750338766 & 7;
                  int var36 = field5034[var34];
                  int var37 = field5035[var34];
                  int var38;
                  int var39;
                  if (-875169383 * this.field5059 == 1) {
                     var38 = var37;
                     var39 = 512 - var36;
                  } else if (2 == this.field5059 * -875169383) {
                     var38 = 512 - var36;
                     var39 = 512 - var37;
                  } else if (3 == this.field5059 * -875169383) {
                     var38 = 512 - var37;
                     var39 = var36;
                  } else {
                     var38 = var36;
                     var39 = var37;
                  }

                  var14[this.field5056 * -1679056507] = var38;
                  var15[-1679056507 * this.field5056] = var39;
                  int var40;
                  int var41;
                  if (var19 != null && field5036[this.field5058 * -1377184223][var34]) {
                     var40 = (var3 << 9) + var38;
                     var41 = (var4 << 9) + var39;
                     var19[this.field5056 * -1679056507] = var23.method3887(var40, var41, -1800590512) - var22.method3887(var40, var41, -1832971430);
                  }

                  if (var20 != null) {
                     if (var23 != null && !field5036[this.field5058 * -1377184223][var34]) {
                        var40 = (var3 << 9) + var38;
                        var41 = (var4 << 9) + var39;
                        var20[-1679056507 * this.field5056] = var22.method3887(var40, var41, -1905933409) - var23.method3887(var40, var41, -2129052823);
                     } else if (var24 != null && !field5037[-1377184223 * this.field5058][var34]) {
                        var40 = var38 + (var3 << 9);
                        var41 = var39 + (var4 << 9);
                        var20[this.field5056 * -1679056507] = var24.method3887(var40, var41, -1961049561) - var22.method3887(var40, var41, -1669884522);
                     }
                  }

                  if (var34 < 8 && this.field5018[var35] >= 0) {
                     if (var13 != null) {
                        var13[-1679056507 * this.field5056] = this.field5053[var35];
                     }

                     var18[this.field5056 * -1679056507] = this.field5055[var35];
                     var17[-1679056507 * this.field5056] = this.field5054[var35];
                     var16[this.field5056 * -1679056507] = this.field5052[var35];
                  } else {
                     if (this.field5047 && field5036[this.field5058 * -1377184223][var34]) {
                        var17[-1679056507 * this.field5056] = 1659854875 * this.field5074;
                        var18[this.field5056 * -1679056507] = -2108878663 * this.field5063;
                        var16[this.field5056 * -1679056507] = this.field5064 * 1373771263;
                     } else if (var38 == 0 && var39 == 0) {
                        var16[this.field5056 * -1679056507] = var21[var3][var4];
                        var17[-1679056507 * this.field5056] = var26.field4334 * 2012295231;
                        var18[-1679056507 * this.field5056] = var26.field4337 * -1106852061;
                     } else if (var38 == 0 && var39 == 512) {
                        var16[this.field5056 * -1679056507] = var21[var3][var6];
                        var17[this.field5056 * -1679056507] = 2012295231 * var27.field4334;
                        var18[this.field5056 * -1679056507] = -1106852061 * var27.field4337;
                     } else if (var38 == 512 && 512 == var39) {
                        var16[this.field5056 * -1679056507] = var21[var5][var6];
                        var17[this.field5056 * -1679056507] = var28.field4334 * 2012295231;
                        var18[-1679056507 * this.field5056] = var28.field4337 * -1106852061;
                     } else if (512 == var38 && var39 == 0) {
                        var16[-1679056507 * this.field5056] = var21[var5][var4];
                        var17[-1679056507 * this.field5056] = 2012295231 * var29.field4334;
                        var18[this.field5056 * -1679056507] = var29.field4337 * -1106852061;
                     } else {
                        if (var38 < 256) {
                           if (var39 < 256) {
                              var17[-1679056507 * this.field5056] = var26.field4334 * 2012295231;
                              var18[-1679056507 * this.field5056] = var26.field4337 * -1106852061;
                           } else {
                              var17[this.field5056 * -1679056507] = 2012295231 * var27.field4334;
                              var18[this.field5056 * -1679056507] = var27.field4337 * -1106852061;
                           }
                        } else if (var39 < 256) {
                           var17[this.field5056 * -1679056507] = var29.field4334 * 2012295231;
                           var18[-1679056507 * this.field5056] = var29.field4337 * -1106852061;
                        } else {
                           var17[this.field5056 * -1679056507] = var28.field4334 * 2012295231;
                           var18[-1679056507 * this.field5056] = var28.field4337 * -1106852061;
                        }

                        var40 = class930.method6270(var21[var3][var4], var21[var5][var4], var38 << 7 >> 9, -1452826652);
                        var41 = class930.method6270(var21[var3][var6], var21[var5][var6], var38 << 7 >> 9, -1452826652);
                        var16[-1679056507 * this.field5056] = class930.method6270(var40, var41, var39 << 7 >> 9, -1452826652);
                     }

                     if (var13 != null) {
                        var13[-1679056507 * this.field5056] = var16[-1679056507 * this.field5056];
                     }
                  }

                  this.field5056 += 107294541;
               }

               this.field5060 += 844235431;
            }

            if (-1377184223 * this.field5058 != 0 && var7.field4339) {
               this.field5065 = true;
            }
         }

      } catch (RuntimeException var42) {
         throw class158.method3445(var42, "kb.h(" + ')');
      }
   }

   final void method3047(class848 var1, class593 var2, class758 var3, int var4, int var5, int var6, int var7, byte[][] var8, byte[][] var9, byte[][] var10, boolean[] var11, int var12) {
      try {
         boolean[] var13 = var2 != null && var2.field1615 ? field5046[-1377184223 * this.field5058] : field5066[-1377184223 * this.field5058];
         int var14;
         class593 var15;
         byte var16;
         int var17;
         int var18;
         if (var5 > 0) {
            if (var4 > 0) {
               var14 = var8[var4 - 1][var5 - 1] & 255;
               if (var14 > 0) {
                  var15 = this.field5022.method2527(var14 - 1, -165601895);
                  if (-1 != -45966925 * var15.field1608 && var15.field1615) {
                     var16 = var9[var4 - 1][var5 - 1];
                     var17 = 2 * var10[var4 - 1][var5 - 1] + 4 & 7;
                     var18 = class26.method3483(var1, var15, (byte)16);
                     if (field5036[var16][var17]) {
                        this.field5052[0] = var15.field1608 * -45966925;
                        this.field5053[0] = var18;
                        this.field5054[0] = var15.field1609 * 324071475;
                        this.field5055[0] = -1551409901 * var15.field1612;
                        this.field5018[0] = 2109091647 * var15.field1607;
                        this.field5057[0] = 256;
                     }
                  }
               }
            }

            if (var4 < var6 - 1) {
               var14 = var8[1 + var4][var5 - 1] & 255;
               if (var14 > 0) {
                  var15 = this.field5022.method2527(var14 - 1, -165601895);
                  if (-1 != var15.field1608 * -45966925 && var15.field1615) {
                     var16 = var9[1 + var4][var5 - 1];
                     var17 = 6 + var10[var4 + 1][var5 - 1] * 2 & 7;
                     var18 = class26.method3483(var1, var15, (byte)16);
                     if (field5036[var16][var17]) {
                        this.field5052[2] = var15.field1608 * -45966925;
                        this.field5053[2] = var18;
                        this.field5054[2] = var15.field1609 * 324071475;
                        this.field5055[2] = var15.field1612 * -1551409901;
                        this.field5018[2] = var15.field1607 * 2109091647;
                        this.field5057[2] = 512;
                     }
                  }
               }
            }
         }

         if (var5 < var7 - 1) {
            if (var4 > 0) {
               var14 = var8[var4 - 1][var5 + 1] & 255;
               if (var14 > 0) {
                  var15 = this.field5022.method2527(var14 - 1, -165601895);
                  if (var15.field1608 * -45966925 != -1 && var15.field1615) {
                     var16 = var9[var4 - 1][var5 + 1];
                     var17 = 2 + var10[var4 - 1][1 + var5] * 2 & 7;
                     var18 = class26.method3483(var1, var15, (byte)16);
                     if (field5036[var16][var17]) {
                        this.field5052[6] = -45966925 * var15.field1608;
                        this.field5053[6] = var18;
                        this.field5054[6] = var15.field1609 * 324071475;
                        this.field5055[6] = -1551409901 * var15.field1612;
                        this.field5018[6] = 2109091647 * var15.field1607;
                        this.field5057[6] = 64;
                     }
                  }
               }
            }

            if (var4 < var6 - 1) {
               var14 = var8[var4 + 1][var5 + 1] & 255;
               if (var14 > 0) {
                  var15 = this.field5022.method2527(var14 - 1, -165601895);
                  if (var15.field1608 * -45966925 != -1 && var15.field1615) {
                     var16 = var9[1 + var4][var5 + 1];
                     var17 = 0 + var10[1 + var4][var5 + 1] * 2 & 7;
                     var18 = class26.method3483(var1, var15, (byte)16);
                     if (field5036[var16][var17]) {
                        this.field5052[4] = -45966925 * var15.field1608;
                        this.field5053[4] = var18;
                        this.field5054[4] = 324071475 * var15.field1609;
                        this.field5055[4] = var15.field1612 * -1551409901;
                        this.field5018[4] = 2109091647 * var15.field1607;
                        this.field5057[4] = 128;
                     }
                  }
               }
            }
         }

         int var19;
         int var20;
         int var21;
         byte var24;
         if (var5 > 0) {
            var14 = var8[var4][var5 - 1] & 255;
            if (var14 > 0) {
               var15 = this.field5022.method2527(var14 - 1, -165601895);
               if (-1 != var15.field1608 * -45966925) {
                  var16 = var9[var4][var5 - 1];
                  var24 = var10[var4][var5 - 1];
                  if (var15.field1615) {
                     var18 = 2;
                     var19 = 4 + var24 * 2;
                     var20 = class26.method3483(var1, var15, (byte)16);

                     for(var21 = 0; var21 < 3; ++var21) {
                        var19 &= 7;
                        var18 &= 7;
                        if (field5036[var16][var19] && this.field5018[var18] <= 2109091647 * var15.field1607) {
                           this.field5052[var18] = -45966925 * var15.field1608;
                           this.field5053[var18] = var20;
                           this.field5054[var18] = var15.field1609 * 324071475;
                           this.field5055[var18] = -1551409901 * var15.field1612;
                           if (this.field5018[var18] == var15.field1607 * 2109091647) {
                              this.field5057[var18] |= 32;
                           } else {
                              this.field5057[var18] = 32;
                           }

                           this.field5018[var18] = 2109091647 * var15.field1607;
                        }

                        ++var19;
                        --var18;
                     }

                     if (!var13[this.field5059 * -875169383 + 0 & 3]) {
                        var11[0] = field5046[var16][var24 + 2 & 3];
                     }
                  } else if (!var13[this.field5059 * -875169383 + 0 & 3]) {
                     var11[0] = field5066[var16][2 + var24 & 3];
                  }
               }
            }
         }

         if (var5 < var7 - 1) {
            var14 = var8[var4][var5 + 1] & 255;
            if (var14 > 0) {
               var15 = this.field5022.method2527(var14 - 1, -165601895);
               if (var15.field1608 * -45966925 != -1) {
                  var16 = var9[var4][1 + var5];
                  var24 = var10[var4][1 + var5];
                  if (var15.field1615) {
                     var18 = 4;
                     var19 = 2 * var24 + 2;
                     var20 = class26.method3483(var1, var15, (byte)16);

                     for(var21 = 0; var21 < 3; ++var21) {
                        var19 &= 7;
                        var18 &= 7;
                        if (field5036[var16][var19] && this.field5018[var18] <= 2109091647 * var15.field1607) {
                           this.field5052[var18] = var15.field1608 * -45966925;
                           this.field5053[var18] = var20;
                           this.field5054[var18] = var15.field1609 * 324071475;
                           this.field5055[var18] = var15.field1612 * -1551409901;
                           if (2109091647 * var15.field1607 == this.field5018[var18]) {
                              this.field5057[var18] |= 16;
                           } else {
                              this.field5057[var18] = 16;
                           }

                           this.field5018[var18] = var15.field1607 * 2109091647;
                        }

                        --var19;
                        ++var18;
                     }

                     if (!var13[-875169383 * this.field5059 + 2 & 3]) {
                        var11[2] = field5046[var16][0 + var24 & 3];
                     }
                  } else if (!var13[2 + this.field5059 * -875169383 & 3]) {
                     var11[2] = field5066[var16][0 + var24 & 3];
                  }
               }
            }
         }

         if (var4 > 0) {
            var14 = var8[var4 - 1][var5] & 255;
            if (var14 > 0) {
               var15 = this.field5022.method2527(var14 - 1, -165601895);
               if (-1 != -45966925 * var15.field1608) {
                  var16 = var9[var4 - 1][var5];
                  var24 = var10[var4 - 1][var5];
                  if (var15.field1615) {
                     var18 = 6;
                     var19 = 2 * var24 + 4;
                     var20 = class26.method3483(var1, var15, (byte)16);

                     for(var21 = 0; var21 < 3; ++var21) {
                        var19 &= 7;
                        var18 &= 7;
                        if (field5036[var16][var19] && this.field5018[var18] <= 2109091647 * var15.field1607) {
                           this.field5052[var18] = var15.field1608 * -45966925;
                           this.field5053[var18] = var20;
                           this.field5054[var18] = 324071475 * var15.field1609;
                           this.field5055[var18] = var15.field1612 * -1551409901;
                           if (this.field5018[var18] == var15.field1607 * 2109091647) {
                              this.field5057[var18] |= 8;
                           } else {
                              this.field5057[var18] = 8;
                           }

                           this.field5018[var18] = var15.field1607 * 2109091647;
                        }

                        --var19;
                        ++var18;
                     }

                     if (!var13[-875169383 * this.field5059 + 3 & 3]) {
                        var11[3] = field5046[var16][var24 + 1 & 3];
                     }
                  } else if (!var13[this.field5059 * -875169383 + 3 & 3]) {
                     var11[3] = field5066[var16][1 + var24 & 3];
                  }
               }
            }
         }

         if (var4 < var6 - 1) {
            var14 = var8[1 + var4][var5] & 255;
            if (var14 > 0) {
               var15 = this.field5022.method2527(var14 - 1, -165601895);
               if (-1 != var15.field1608 * -45966925) {
                  var16 = var9[var4 + 1][var5];
                  var24 = var10[var4 + 1][var5];
                  if (var15.field1615) {
                     var18 = 4;
                     var19 = 6 + 2 * var24;
                     var20 = class26.method3483(var1, var15, (byte)16);

                     for(var21 = 0; var21 < 3; ++var21) {
                        var19 &= 7;
                        var18 &= 7;
                        if (field5036[var16][var19] && this.field5018[var18] <= var15.field1607 * 2109091647) {
                           this.field5052[var18] = -45966925 * var15.field1608;
                           this.field5053[var18] = var20;
                           this.field5054[var18] = 324071475 * var15.field1609;
                           this.field5055[var18] = var15.field1612 * -1551409901;
                           if (this.field5018[var18] == var15.field1607 * 2109091647) {
                              this.field5057[var18] |= 4;
                           } else {
                              this.field5057[var18] = 4;
                           }

                           this.field5018[var18] = 2109091647 * var15.field1607;
                        }

                        ++var19;
                        --var18;
                     }

                     if (!var13[-875169383 * this.field5059 + 1 & 3]) {
                        var11[1] = field5046[var16][var24 + 3 & 3];
                     }
                  } else if (!var13[1 + this.field5059 * -875169383 & 3]) {
                     var11[1] = field5066[var16][3 + var24 & 3];
                  }
               }
            }
         }

         if (var2 != null && var2.field1615) {
            var14 = class26.method3483(var1, var2, (byte)16);

            for(int var23 = 0; var23 < 8; ++var23) {
               int var25 = var23 - -1750338766 * this.field5059 & 7;
               if (field5036[-1377184223 * this.field5058][var23] && this.field5018[var25] <= var2.field1607 * 2109091647) {
                  this.field5052[var25] = -45966925 * var2.field1608;
                  this.field5053[var25] = var14;
                  this.field5054[var25] = 324071475 * var2.field1609;
                  this.field5055[var25] = var2.field1612 * -1551409901;
                  if (2109091647 * var2.field1607 == this.field5018[var25]) {
                     this.field5057[var25] |= 2;
                  } else {
                     this.field5057[var25] = 2;
                  }

                  this.field5018[var25] = var2.field1607 * 2109091647;
               }
            }
         }

      } catch (RuntimeException var22) {
         throw class158.method3445(var22, "kb.g(" + ')');
      }
   }

   final void method3048(class907 var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, boolean var10, int var11) {
      try {
         if (var9 == 1) {
            var6 = 1;
         } else if (2 == var9) {
            var5 = 1;
            var6 = 1;
         } else if (3 == var9) {
            var5 = 1;
         }

         int var12;
         if (var3 >= 0 && var3 < -954368823 * this.field4998 && var4 >= 0 && var4 < 181474463 * this.field4999) {
            if (!this.field5000 && !var10) {
               this.field5006.field5406[var2][var3][var4] = 0;
            }

            while(true) {
               var12 = var1.method6371();
               if (var12 == 0) {
                  if (this.field5000) {
                     this.field5024[0][var3 + var5][var4 + var6] = 0;
                  } else if (var2 == 0) {
                     this.field5024[0][var5 + var3][var6 + var4] = -class235.method4642(var7 + 932731, var8 + 556238, (byte)-40) * 8 << 2;
                  } else {
                     this.field5024[var2][var5 + var3][var4 + var6] = this.field5024[var2 - 1][var5 + var3][var4 + var6] - 960;
                  }
                  break;
               }

               if (1 == var12) {
                  int var13 = var1.method6371();
                  if (!this.field5000) {
                     if (var13 == 1) {
                        var13 = 0;
                     }

                     if (var2 == 0) {
                        this.field5024[0][var5 + var3][var6 + var4] = -var13 * 8 << 2;
                     } else {
                        this.field5024[var2][var5 + var3][var6 + var4] = this.field5024[var2 - 1][var5 + var3][var6 + var4] - (var13 * 8 << 2);
                     }
                  } else {
                     this.field5024[0][var5 + var3][var4 + var6] = 8 * var13 << 2;
                  }
                  break;
               }

               if (var12 <= 49) {
                  if (var10) {
                     var1.method6371();
                  } else {
                     this.field5007[var2][var3][var4] = var1.method6372(-12558881);
                     this.field5069[var2][var3][var4] = (byte)((var12 - 2) / 4);
                     this.field5039[var2][var3][var4] = (byte)(var12 - 2 + var9 & 3);
                  }
               } else if (var12 <= 81) {
                  if (!this.field5000 && !var10) {
                     this.field5006.field5406[var2][var3][var4] = (byte)(var12 - 49);
                  }
               } else if (!var10) {
                  this.field5041[var2][var3][var4] = (byte)(var12 - 81);
               }
            }
         } else {
            while(true) {
               var12 = var1.method6371();
               if (var12 == 0) {
                  break;
               }

               if (var12 == 1) {
                  var1.method6371();
                  break;
               }

               if (var12 <= 49) {
                  var1.method6371();
               }
            }
         }

      } catch (RuntimeException var14) {
         throw class158.method3445(var14, "kb.d(" + ')');
      }
   }

   void method3049(class454 var1, class758 var2, class593 var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, int var11) {
      try {
         int var12 = var1.method3888(var5, var6, (byte)-41);
         int var13 = var1.method3888(var7, var6, (byte)-89);
         int var14 = var1.method3888(var7, var8, (byte)-120);
         int var15 = var1.method3888(var5, var8, (byte)-113);
         boolean var16 = this.field5006.method3386(var5, var6, 1693212331);
         if (var16 && var4 > 1 || !var16 && var4 > 0) {
            boolean var17 = true;
            if (var2 != null && !var2.field4336) {
               var17 = false;
            } else if (var9 == 0 && -1377184223 * this.field5058 != 0) {
               var17 = false;
            } else if (var10 > 0 && var3 != null && !var3.field1614) {
               var17 = false;
            }

            if (var17 && var13 == var12 && var12 == var14 && var12 == var15) {
               this.field5008[var4][var5][var6] = (byte)(this.field5008[var4][var5][var6] | 4);
            }
         }

      } catch (RuntimeException var18) {
         throw class158.method3445(var18, "kb.v(" + ')');
      }
   }

   class175(class545 var1, int var2, int var3, int var4, boolean var5, class509 var6, class428 var7, class153 var8) {
      this.field4990 = var1;
      this.field4997 = 142248255 * var2;
      this.field4998 = var3 * 325279097;
      this.field4999 = var4 * 2072446815;
      this.field5000 = var5;
      this.field5022 = var6;
      this.field4988 = var7;
      this.field5006 = var8;
      this.field5041 = new byte[this.field4997 * 1551623871][this.field4998 * -954368823][181474463 * this.field4999];
      this.field5007 = new byte[1551623871 * this.field4997][-954368823 * this.field4998][181474463 * this.field4999];
      this.field5069 = new byte[1551623871 * this.field4997][-954368823 * this.field4998][this.field4999 * 181474463];
      this.field5039 = new byte[this.field4997 * 1551623871][-954368823 * this.field4998][181474463 * this.field4999];
      this.field5024 = new int[this.field4997 * 1551623871][this.field4998 * -954368823 + 1][181474463 * this.field4999 + 1];
      this.field5008 = new byte[1551623871 * this.field4997][1 + -954368823 * this.field4998][181474463 * this.field4999 + 1];
   }

   static final void method3050(class564 var0, class131 var1, class744 var2, int var3) {
      try {
         var0.field955 = (String)var2.field3157[(var2.field3158 -= 969361751) * -203050393];
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "kb.jh(" + ')');
      }
   }

   public static void method3051(class769 var0, int var1) {
      try {
         class508.field3965 = var0;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "kb.a(" + ')');
      }
   }

   static final void method3052(int var0, int var1, int var2, int var3, int var4, int var5, byte var6) {
      try {
         int var7 = 1168366243 * class498.field8102;
         int[] var8 = class498.field8108;
         class730.field2887 = 0;
         int var9;
         if (class730.field2705 * 1596783995 == 0) {
            var9 = class949.field3322.length;
         } else {
            var9 = var7 + class730.field2684 * -1230451913;
         }

         int var10;
         Object var13;
         int var19;
         int var20;
         int var21;
         int var22;
         int var93;
         int var95;
         int var102;
         int var107;
         int var109;
         for(var10 = 0; var10 < var9; ++var10) {
            class401 var11 = null;
            if (1596783995 * class730.field2705 == 0) {
               class283 var12 = class949.field3322[var10];
               if (!var12.field10613) {
                  continue;
               }

               var13 = var12.method6636(-198688273);
               if (((class746)var13).field4030 * -1706825291 != -1953789277 * class730.field2758) {
                  if (var6 == 0) {
                     return;
                  }
                  continue;
               }

               if (var12.field10610 * 1762367763 >= 0) {
                  var11 = ((class60)var13).field1637;
                  if (var11.field9924 != null) {
                     var11 = var11.method6110(class827.field9037, 1805717140);
                     if (var11 == null) {
                        if (var6 == 0) {
                           return;
                        }
                        continue;
                     }
                  }
               }
            } else {
               if (var10 < var7) {
                  var13 = class730.field2786[var8[var10]];
               } else {
                  var13 = (class746)((class437)class730.field2677.method2942((long)class730.field2680[var10 - var7])).field7515;
                  var11 = ((class60)var13).field1637;
                  if (var11.field9924 != null) {
                     var11 = var11.method6110(class827.field9037, 1690174676);
                     if (var11 == null) {
                        if (var6 == 0) {
                           throw new IllegalStateException();
                        }
                        continue;
                     }
                  }
               }

               if (((class746)var13).field4035 * 648883167 < 0 || -1706825291 * ((class746)var13).field4030 != -1953789277 * class730.field2758 && ((class746)var13).field3639 != class923.field10295.field3639) {
                  continue;
               }
            }

            class213.method3815((class963)var13, ((class746)var13).method2170((byte)-83), -1841539170);
            if (class730.field2873[0] >= 0.0F) {
               if (((class746)var13).method2557((byte)-114)) {
                  class625 var92 = ((class746)var13).method2565(-593782084);
                  if (var92 != null && -559111197 * class730.field2887 < 547709851 * class730.field2625) {
                     class730.field2891[class730.field2887 * -559111197] = class271.field10557.method4605(var92.method5820((byte)1), -1350600471) / 2;
                     class730.field2889[-559111197 * class730.field2887] = (int)class730.field2873[0];
                     class730.field2890[class730.field2887 * -559111197] = (int)class730.field2873[1];
                     class730.field2638[-559111197 * class730.field2887] = var92;
                     class730.field2887 += -392578613;
                  }
               }

               var93 = (int)(class730.field2873[1] + (float)var1);
               class48[] var17;
               class922[] var18;
               class48 var105;
               if (!((class746)var13).field4087 && -1472450313 * ((class746)var13).field4080 > 443738891 * class730.field2866) {
                  boolean var14 = true;
                  byte var15 = 1;
                  if (var11 == null) {
                     class946 var16 = class730.field2786[var8[var10]];
                     var95 = ((class746)var13).method2554(379142264).field3996 * 2108452425;
                     if (var16.field3382) {
                        var15 = 2;
                     }
                  } else {
                     var95 = -1362808149 * var11.field9903;
                     if (-1 == var95) {
                        var95 = ((class746)var13).method2554(-1076416255).field3996 * 2108452425;
                     }
                  }

                  class48[] var98 = class120.field2291;
                  if (var95 != -1) {
                     var17 = (class48[])class730.field2761.method2974((long)var95);
                     if (var17 == null) {
                        var18 = class922.method6248(class562.field827, var95, 0);
                        if (var18 != null) {
                           var17 = new class48[var18.length];

                           for(var19 = 0; var19 < var18.length; ++var19) {
                              var17[var19] = class593.field1623.method4982(var18[var19], true);
                           }

                           class730.field2761.method2984(var17, (long)var95);
                        }
                     }

                     if (var17 != null && var17.length >= 2) {
                        var98 = var17;
                     }
                  }

                  if (var15 >= var98.length) {
                     var15 = 1;
                  }

                  class48 var103 = var98[0];
                  var105 = var98[var15];
                  var93 -= Math.max(class271.field10557.field8230 * 1110385787, var103.method3108());
                  var19 = (int)(class730.field2873[0] + (float)var0 - (float)(var103.method3106() >> 1));
                  var20 = var103.method3106() * ((class746)var13).field4027 * -766383861 / 255;
                  var21 = var103.method3108();
                  if (-766383861 * ((class746)var13).field4027 > 0 && var20 < 2) {
                     var20 = 2;
                  }

                  var103.method3128(var19, var93);
                  class593.field1623.method4829(var19, var93, var19 + var20, var93 + var21);
                  var105.method3128(var19, var93);
                  class593.field1623.method4986(var0, var1, var2 + var0, var3 + var1);
               } else {
                  var93 -= Math.max(1110385787 * class271.field10557.field8230, class120.field2291[0].method3108());
               }

               var93 -= 2;
               if (!((class746)var13).field4087) {
                  class48 var97;
                  class48 var99;
                  if (-424347101 * ((class746)var13).field4050 > 443738891 * class730.field2866) {
                     var97 = class916.field10419[((class746)var13).field4083 ? 2 : 0];
                     var99 = class916.field10419[((class746)var13).field4083 ? 3 : 1];
                     boolean var100 = true;
                     if (var13 instanceof class60) {
                        var102 = var11.field9920 * -1088584623;
                        if (-1 == var102) {
                           var102 = ((class746)var13).method2554(1682687181).field4012 * -2139195165;
                        }
                     } else {
                        var102 = ((class746)var13).method2554(-387842167).field4012 * -2139195165;
                     }

                     if (-1 != var102) {
                        var17 = (class48[])class730.field2880.method2974((long)var102);
                        if (var17 == null) {
                           var18 = class922.method6248(class562.field827, var102, 0);
                           if (var18 != null) {
                              var17 = new class48[var18.length];

                              for(var19 = 0; var19 < var18.length; ++var19) {
                                 var17[var19] = class593.field1623.method4982(var18[var19], true);
                              }

                              class730.field2880.method2984(var17, (long)var102);
                           }
                        }

                        if (var17 != null && var17.length == 4) {
                           var97 = var17[((class746)var13).field4083 ? 2 : 0];
                           var99 = var17[((class746)var13).field4083 ? 3 : 1];
                        }
                     }

                     var109 = ((class746)var13).field4050 * -424347101 - class730.field2866 * 443738891;
                     if (var109 <= -1547810795 * ((class746)var13).field4052) {
                        var107 = var97.method3106();
                     } else {
                        var109 -= -1547810795 * ((class746)var13).field4052;
                        var19 = ((class746)var13).field4060 * 293281353 == 0 ? 0 : (((class746)var13).field4051 * 878490761 - var109) / (((class746)var13).field4060 * 293281353) * 293281353 * ((class746)var13).field4060;
                        var107 = var97.method3106() * var19 / (((class746)var13).field4051 * 878490761);
                     }

                     var19 = var97.method3108();
                     var93 -= var19;
                     var20 = (int)(class730.field2873[0] + (float)var0 - (float)(var97.method3106() >> 1));
                     var97.method3128(var20, var93);
                     class593.field1623.method4829(var20, var93, var107 + var20, var19 + var93);
                     var99.method3128(var20, var93);
                     class593.field1623.method4986(var0, var1, var2 + var0, var3 + var1);
                     var93 -= 2;
                  }

                  if (var11 == null) {
                     class946 var101 = (class946)var13;
                     if (-1 != var101.field3381 * -1126079563) {
                        var99 = class18.field6933[var101.field3381 * -1126079563];
                        var93 -= var99.method3108();
                        var99.method3128((int)((float)var0 + class730.field2873[0] - 12.0F), var93);
                        var93 -= 2;
                     }

                     if (-1 != var101.field3380 * -2031128911) {
                        var99 = class535.field3709[-2031128911 * var101.field3380];
                        var93 -= var99.method3108();
                        var99.method3128((int)(class730.field2873[0] + (float)var0 - 12.0F), var93);
                        var93 -= 2;
                     }
                  } else if (-986687803 * var11.field9921 >= 0 && -986687803 * var11.field9921 < class535.field3709.length) {
                     var97 = class535.field3709[var11.field9921 * -986687803];
                     var93 -= var97.method3108();
                     var97.method3128((int)((float)var0 + class730.field2873[0] - (float)(var97.method3106() >> 1)), var93);
                     var93 -= 2;
                  }
               }

               int var10000;
               class921[] var104;
               class921 var111;
               if (var13 instanceof class946) {
                  if (var10 >= 0) {
                     var95 = 0;
                     var104 = class730.field2851;

                     for(var102 = 0; var102 < var104.length; ++var102) {
                        var111 = var104[var102];
                        if (var111 != null && 10 == var111.field10287 * 958933333 && var8[var10] == -841622081 * var111.field10277) {
                           var105 = class634.field9790[var111.field10279 * -92466201];
                           if (var105.method3108() > var95) {
                              var95 = var105.method3108();
                           }

                           var105.method3128((int)(class730.field2873[0] + (float)var0 - 12.0F), var93 - var105.method3108());
                        }
                     }

                     if (var95 > 0) {
                        var10000 = var93 - (2 + var95);
                     }
                  }
               } else {
                  var95 = 0;
                  var104 = class730.field2851;

                  for(var102 = 0; var102 < var104.length; ++var102) {
                     var111 = var104[var102];
                     if (var111 != null && var111.field10287 * 958933333 == 1 && var111.field10277 * -841622081 == class730.field2680[var10 - var7]) {
                        var105 = class634.field9790[-92466201 * var111.field10279];
                        if (var105.method3108() > var95) {
                           var95 = var105.method3108();
                        }

                        boolean var114;
                        if (var111.field10286 * -519856529 == 0) {
                           var114 = true;
                        } else {
                           var20 = class854.method5151((byte)6) * 1000 / (-519856529 * var111.field10286) / 2;
                           var114 = 443738891 * class730.field2866 % (2 * var20) < var20;
                        }

                        if (var114) {
                           var105.method3128((int)((float)var0 + class730.field2873[0] - 12.0F), var93 - var105.method3108());
                        }
                     }
                  }

                  if (var95 > 0) {
                     var10000 = var93 - (var95 + 2);
                  }
               }

               for(var95 = 0; var95 < class6.field4931.field9523 * -942466371; ++var95) {
                  int var106 = ((class746)var13).field4044[var95];
                  var102 = ((class746)var13).field4066[var95];
                  class399 var112 = null;
                  var107 = 0;
                  if (var102 >= 0) {
                     if (var106 <= class730.field2866 * 443738891) {
                        if (var6 == 0) {
                           throw new IllegalStateException();
                        }
                        continue;
                     }

                     var112 = class339.field157.method1211(((class746)var13).field4066[var95], -1682094753);
                     var107 = -169339039 * var112.field6567;
                  } else if (var106 < 0) {
                     if (var6 == 0) {
                        return;
                     }
                     continue;
                  }

                  var19 = ((class746)var13).field4091[var95];
                  class399 var115 = null;
                  if (var19 >= 0) {
                     var115 = class339.field157.method1211(var19, -1682094753);
                  }

                  if (var106 - var107 > 443738891 * class730.field2866) {
                     if (var6 == 0) {
                        throw new IllegalStateException();
                     }
                  } else {
                     var21 = ((class746)var13).field4045[var95];
                     if (var21 >= 0) {
                        ((class746)var13).field4027 = 1207474851 * var21;
                        ((class746)var13).field4080 = class730.field2866 * -1044781683 + -362436300;
                        ((class746)var13).field4045[var95] = -1;
                     }

                     if (var112 == null) {
                        ((class746)var13).field4044[var95] = -1;
                     } else {
                        var22 = ((class746)var13).method2170((byte)64) / 2;
                        class213.method3815((class963)var13, var22, -1043067647);
                        if (class730.field2873[0] > -1.0F) {
                           class730.field2873[0] += (float)class6.field4931.field9524[var95];
                           class730.field2873[1] += (float)class6.field4931.field9525[var95];
                           Object var23 = null;
                           Object var24 = null;
                           Object var25 = null;
                           Object var26 = null;
                           int var27 = 0;
                           int var28 = 0;
                           int var29 = 0;
                           int var30 = 0;
                           int var31 = 0;
                           int var32 = 0;
                           int var33 = 0;
                           int var34 = 0;
                           class48 var35 = null;
                           class48 var36 = null;
                           class48 var37 = null;
                           class48 var38 = null;
                           int var39 = 0;
                           int var40 = 0;
                           int var41 = 0;
                           int var42 = 0;
                           int var43 = 0;
                           int var44 = 0;
                           int var45 = 0;
                           int var46 = 0;
                           int var47 = 0;
                           class48 var48 = var112.method3522(class593.field1623, (short)-23793);
                           if (var48 != null) {
                              var27 = var48.method3106();
                              int var49 = var48.method3108();
                              if (var49 > var47) {
                                 var47 = var49;
                              }

                              var48.method3105(class730.field2959);
                              var31 = class730.field2959[0];
                           }

                           class48 var117 = var112.method3526(class593.field1623, 406396727);
                           if (var117 != null) {
                              var28 = var117.method3106();
                              int var50 = var117.method3108();
                              if (var50 > var47) {
                                 var47 = var50;
                              }

                              var117.method3105(class730.field2959);
                              var32 = class730.field2959[0];
                           }

                           class48 var118 = var112.method3523(class593.field1623, (byte)26);
                           if (var118 != null) {
                              var29 = var118.method3106();
                              int var51 = var118.method3108();
                              if (var51 > var47) {
                                 var47 = var51;
                              }

                              var118.method3105(class730.field2959);
                              var33 = class730.field2959[0];
                           }

                           class48 var119 = var112.method3524(class593.field1623, (byte)0);
                           int var52;
                           if (var119 != null) {
                              var30 = var119.method3106();
                              var52 = var119.method3108();
                              if (var52 > var47) {
                                 var47 = var52;
                              }

                              var119.method3105(class730.field2959);
                              var34 = class730.field2959[0];
                           }

                           if (var115 != null) {
                              var35 = var115.method3522(class593.field1623, (short)4674);
                              if (var35 != null) {
                                 var39 = var35.method3106();
                                 var52 = var35.method3108();
                                 if (var52 > var47) {
                                    var47 = var52;
                                 }

                                 var35.method3105(class730.field2959);
                                 var43 = class730.field2959[0];
                              }

                              var36 = var115.method3526(class593.field1623, 1200116626);
                              if (var36 != null) {
                                 var40 = var36.method3106();
                                 var52 = var36.method3108();
                                 if (var52 > var47) {
                                    var47 = var52;
                                 }

                                 var36.method3105(class730.field2959);
                                 var44 = class730.field2959[0];
                              }

                              var37 = var115.method3523(class593.field1623, (byte)83);
                              if (var37 != null) {
                                 var41 = var37.method3106();
                                 var52 = var37.method3108();
                                 if (var52 > var47) {
                                    var47 = var52;
                                 }

                                 var37.method3105(class730.field2959);
                                 var45 = class730.field2959[0];
                              }

                              var38 = var115.method3524(class593.field1623, (byte)0);
                              if (var38 != null) {
                                 var42 = var38.method3106();
                                 var52 = var38.method3108();
                                 if (var52 > var47) {
                                    var47 = var52;
                                 }

                                 var38.method3105(class730.field2959);
                                 var46 = class730.field2959[0];
                              }
                           }

                           class727 var120 = class202.field7587;
                           class727 var53 = class202.field7587;
                           class230 var54 = class295.field10474;
                           class230 var55 = class295.field10474;
                           int var56 = -160359777 * var112.field6577;
                           class727 var57;
                           class230 var58;
                           if (var56 >= 0) {
                              var57 = (class727)class785.field3827.method1857(class730.field2681, var56, true, true, -2063324548);
                              var58 = class785.field3827.method1853(class730.field2681, var56, -665127508);
                              if (var57 != null && var58 != null) {
                                 var120 = var57;
                                 var54 = var58;
                              }
                           }

                           if (var115 != null) {
                              var56 = var115.field6577 * -160359777;
                              if (var56 >= 0) {
                                 var57 = (class727)class785.field3827.method1857(class730.field2681, var56, true, true, -2063324548);
                                 var58 = class785.field3827.method1853(class730.field2681, var56, -1834913337);
                                 if (var57 != null && var58 != null) {
                                    var53 = var57;
                                    var55 = var58;
                                 }
                              }
                           }

                           var57 = null;
                           String var121 = null;
                           boolean var59 = false;
                           int var60 = 0;
                           String var61 = var112.method3521(((class746)var13).field4043[var95], -794452403);
                           int var62 = var54.method4605(var61, 1512962528);
                           if (var115 != null) {
                              var121 = var115.method3521(((class746)var13).field4047[var95], -794452403);
                              var60 = var55.method4605(var121, -1394241866);
                           }

                           int var63 = 0;
                           int var64 = 0;
                           if (var28 > 0) {
                              var63 = 1 + var62 / var28;
                           }

                           if (var115 != null && var40 > 0) {
                              var64 = var60 / var40 + 1;
                           }

                           int var65 = 0;
                           int var66 = var65;
                           if (var27 > 0) {
                              var65 += var27;
                           }

                           var65 += 2;
                           int var67 = var65;
                           if (var29 > 0) {
                              var65 += var29;
                           }

                           int var68 = var65;
                           int var69 = var65;
                           int var70;
                           if (var28 > 0) {
                              var70 = var28 * var63;
                              var65 += var70;
                              var69 += (var70 - var62) / 2;
                           } else {
                              var65 += var62;
                           }

                           var70 = var65;
                           if (var30 > 0) {
                              var65 += var30;
                           }

                           int var71 = 0;
                           int var72 = 0;
                           int var73 = 0;
                           int var74 = 0;
                           int var75 = 0;
                           int var76;
                           if (var115 != null) {
                              var65 += 2;
                              var71 = var65;
                              if (var39 > 0) {
                                 var65 += var39;
                              }

                              var65 += 2;
                              var72 = var65;
                              if (var41 > 0) {
                                 var65 += var41;
                              }

                              var73 = var65;
                              var75 = var65;
                              if (var40 > 0) {
                                 var76 = var40 * var64;
                                 var65 += var76;
                                 var75 += (var76 - var60) / 2;
                              } else {
                                 var65 += var60;
                              }

                              var74 = var65;
                              if (var42 > 0) {
                                 var65 += var42;
                              }
                           }

                           var76 = ((class746)var13).field4044[var95] - class730.field2866 * 443738891;
                           int var77 = var112.field6572 * 584392085 - var112.field6572 * 584392085 * var76 / (-169339039 * var112.field6567);
                           int var78 = -(var112.field6565 * 639965299) + var76 * 639965299 * var112.field6565 / (var112.field6567 * -169339039);
                           int var79 = (int)((float)var77 + (class730.field2873[0] + (float)var0 - (float)(var65 >> 1)));
                           int var80 = (int)((float)var1 + class730.field2873[1] - 12.0F + (float)var78);
                           int var81 = var80;
                           int var82 = var80 + var47;
                           int var83 = -176522889 * var112.field6575 + var80 + 15;
                           int var84 = var83 - var54.field8230 * 1110385787;
                           int var85 = var83 + var54.field8225 * -1883958527;
                           if (var84 < var80) {
                              var81 = var84;
                           }

                           if (var85 > var82) {
                              var82 = var85;
                           }

                           int var86 = 0;
                           int var87;
                           int var88;
                           if (var115 != null) {
                              var86 = var115.field6575 * -176522889 + var80 + 15;
                              var87 = var86 - var55.field8230 * 1110385787;
                              var88 = var86 + -1883958527 * var55.field8225;
                              if (var87 < var81) {
                                 ;
                              }

                              if (var88 > var82) {
                                 ;
                              }
                           }

                           var87 = 255;
                           if (var112.field6574 * 1445195441 >= 0) {
                              var87 = (var76 << 8) / (-169339039 * var112.field6567 - 1445195441 * var112.field6574);
                           }

                           if (var87 >= 0 && var87 < 255) {
                              var88 = var87 << 24;
                              int var89 = var88 | 16777215;
                              if (var48 != null) {
                                 var48.method3114(var66 + var79 - var31, var80, 0, var89, 1);
                              }

                              if (var118 != null) {
                                 var118.method3114(var67 + var79 - var33, var80, 0, var89, 1);
                              }

                              int var90;
                              if (var117 != null) {
                                 for(var90 = 0; var90 < var63; ++var90) {
                                    var117.method3114(var68 + var79 - var32 + var28 * var90, var80, 0, var89, 1);
                                 }
                              }

                              if (var119 != null) {
                                 var119.method3114(var70 + var79 - var34, var80, 0, var89, 1);
                              }

                              var120.method1678(var61, var69 + var79, var83, 1473512559 * var112.field6566 | var88, 0, -60400188);
                              if (var115 != null) {
                                 if (var35 != null) {
                                    var35.method3114(var79 + var71 - var43, var80, 0, var89, 1);
                                 }

                                 if (var37 != null) {
                                    var37.method3114(var79 + var72 - var45, var80, 0, var89, 1);
                                 }

                                 if (var36 != null) {
                                    for(var90 = 0; var90 < var64; ++var90) {
                                       var36.method3114(var90 * var40 + (var73 + var79 - var44), var80, 0, var89, 1);
                                    }
                                 }

                                 if (var38 != null) {
                                    var38.method3114(var79 + var74 - var46, var80, 0, var89, 1);
                                 }

                                 var53.method1678(var121, var79 + var75, var86, var115.field6566 * 1473512559 | var88, 0, -540018673);
                              }
                           } else {
                              if (var48 != null) {
                                 var48.method3128(var79 + var66 - var31, var80);
                              }

                              if (var118 != null) {
                                 var118.method3128(var67 + var79 - var33, var80);
                              }

                              if (var117 != null) {
                                 for(var88 = 0; var88 < var63; ++var88) {
                                    var117.method3128(var28 * var88 + (var79 + var68 - var32), var80);
                                 }
                              }

                              if (var119 != null) {
                                 var119.method3128(var70 + var79 - var34, var80);
                              }

                              var120.method1678(var61, var69 + var79, var83, var112.field6566 * 1473512559 | -16777216, 0, -45982797);
                              if (var115 != null) {
                                 if (var35 != null) {
                                    var35.method3128(var71 + var79 - var43, var80);
                                 }

                                 if (var37 != null) {
                                    var37.method3128(var79 + var72 - var45, var80);
                                 }

                                 if (var36 != null) {
                                    for(var88 = 0; var88 < var64; ++var88) {
                                       var36.method3128(var73 + var79 - var44 + var88 * var40, var80);
                                    }
                                 }

                                 if (var38 != null) {
                                    var38.method3128(var74 + var79 - var46, var80);
                                 }

                                 var53.method1678(var121, var75 + var79, var86, var115.field6566 * 1473512559 | -16777216, 0, -751332562);
                              }
                           }
                        }
                     }
                  }
               }
            }
         }

         int var94;
         for(var10 = 0; var10 < 1306491689 * class730.field2640; ++var10) {
            var94 = class730.field2833[var10];
            if (var94 < 2048) {
               var13 = class730.field2786[var94];
            } else {
               var13 = (class746)((class437)class730.field2677.method2942((long)(var94 - 2048))).field7515;
            }

            var93 = class730.field2760[var10];
            Object var110;
            if (var93 < 2048) {
               var110 = class730.field2786[var93];
            } else {
               var110 = (class746)((class437)class730.field2677.method2942((long)(var93 - 2048))).field7515;
            }

            class27.method3469((class746)var13, (class746)var110, (((class746)var13).field4033 -= 512067143) * -152681609, var0, var1, var2, var3, var4, var5, 1553464017);
         }

         var10 = 1110385787 * class271.field10557.field8230 + -1883958527 * class271.field10557.field8225 + 2;

         for(var94 = 0; var94 < class730.field2887 * -559111197; ++var94) {
            int var96 = class730.field2889[var94];
            var93 = class730.field2890[var94];
            var95 = class730.field2891[var94];
            boolean var108 = true;

            while(var108) {
               var108 = false;

               for(var102 = 0; var102 < var94; ++var102) {
                  if (2 + var93 > class730.field2890[var102] - var10 && var93 - var10 < class730.field2890[var102] + 2 && var96 - var95 < class730.field2891[var102] + class730.field2889[var102] && var96 + var95 > class730.field2889[var102] - class730.field2891[var102] && class730.field2890[var102] - var10 < var93) {
                     var93 = class730.field2890[var102] - var10;
                     var108 = true;
                  }
               }
            }

            class730.field2890[var94] = var93;
            String var113 = class730.field2638[var94].method5820((byte)1);
            if (class730.field2824 * 1805045055 == 0) {
               var109 = 16776960;
               var107 = class730.field2638[var94].method5819(642226389);
               if (var107 < 6) {
                  var109 = class730.field2893[var107];
               }

               if (var107 == 6) {
                  var109 = class730.field2758 * -1953789277 % 20 < 10 ? 16711680 : 16776960;
               }

               if (var107 == 7) {
                  var109 = -1953789277 * class730.field2758 % 20 < 10 ? 255 : '\uffff';
               }

               if (8 == var107) {
                  var109 = -1953789277 * class730.field2758 % 20 < 10 ? '뀀' : 8454016;
               }

               if (var107 == 9) {
                  var19 = 150 - class730.field2638[var94].method5821(-1720960633) * 150 / class730.field2638[var94].method5822((short)-1217);
                  if (var19 < 50) {
                     var109 = var19 * 1280 + 16711680;
                  } else if (var19 < 100) {
                     var109 = 16776960 - 327680 * (var19 - 50);
                  } else if (var19 < 150) {
                     var109 = (var19 - 100) * 5 + '\uff00';
                  }
               }

               if (10 == var107) {
                  var19 = 150 - class730.field2638[var94].method5821(-1972553140) * 150 / class730.field2638[var94].method5822((short)-25631);
                  if (var19 < 50) {
                     var109 = 5 * var19 + 16711680;
                  } else if (var19 < 100) {
                     var109 = 16711935 - (var19 - 50) * 327680;
                  } else if (var19 < 150) {
                     var109 = 255 + 327680 * (var19 - 100) - (var19 - 100) * 5;
                  }
               }

               if (var107 == 11) {
                  var19 = 150 - class730.field2638[var94].method5821(-1730083195) * 150 / class730.field2638[var94].method5822((short)-3693);
                  if (var19 < 50) {
                     var109 = 16777215 - 327685 * var19;
                  } else if (var19 < 100) {
                     var109 = 327685 * (var19 - 50) + '\uff00';
                  } else if (var19 < 150) {
                     var109 = 16777215 - 327680 * (var19 - 100);
                  }
               }

               var19 = var109 | -16777216;
               var20 = class730.field2638[var94].method5818(833746281);
               if (var20 == 0) {
                  class501.field3182.method1681(var113, var0 + var96, var93 + var1, var19, -16777216, 1321352583);
               }

               if (1 == var20) {
                  class501.field3182.method1665(var113, var0 + var96, var93 + var1, var19, -16777216, -1953789277 * class730.field2758, -239335762);
               }

               if (2 == var20) {
                  class501.field3182.method1666(var113, var96 + var0, var93 + var1, var19, -16777216, class730.field2758 * -1953789277, (byte)-50);
               }

               if (var20 == 3) {
                  var21 = 150 - class730.field2638[var94].method5821(-2037980380) * 150 / class730.field2638[var94].method5822((short)107);
                  class501.field3182.method1667(var113, var96 + var0, var93 + var1, var19, -16777216, class730.field2758 * -1953789277, var21, (byte)120);
               }

               if (var20 == 4) {
                  var21 = 150 - class730.field2638[var94].method5821(-1700086542) * 150 / class730.field2638[var94].method5822((short)-15372);
                  var22 = var21 * (class271.field10557.method4605(var113, 2139584778) + 100) / 150;
                  class593.field1623.method4829(var96 + var0 - 50, var1, var0 + var96 + 50, var1 + var3);
                  class501.field3182.method1678(var113, 50 + var96 + var0 - var22, var1 + var93, var19, -16777216, 766607406);
                  class593.field1623.method4986(var0, var1, var0 + var2, var3 + var1);
               }

               if (var20 == 5) {
                  var21 = 150 - class730.field2638[var94].method5821(-2069698200) * 150 / class730.field2638[var94].method5822((short)-28873);
                  var22 = 0;
                  if (var21 < 25) {
                     var22 = var21 - 25;
                  } else if (var21 > 125) {
                     var22 = var21 - 125;
                  }

                  int var116 = class271.field10557.field8230 * 1110385787 + -1883958527 * class271.field10557.field8225;
                  class593.field1623.method4829(var0, var1 + var93 - var116 - 1, var2 + var0, var93 + var1 + 5);
                  class501.field3182.method1681(var113, var0 + var96, var22 + var1 + var93, var19, -16777216, -773482636);
                  class593.field1623.method4986(var0, var1, var2 + var0, var1 + var3);
               }
            } else {
               class501.field3182.method1681(var113, var96 + var0, var1 + var93, -256, -16777216, 1698336532);
            }
         }

      } catch (RuntimeException var91) {
         throw class158.method3445(var91, "kb.jm(" + ')');
      }
   }

   public static int method3053(int var0, int var1, int var2, short var3) {
      try {
         var2 &= 3;
         if (var2 == 0) {
            return var1;
         } else if (var2 == 1) {
            return 4095 - var0;
         } else {
            return var2 == 2 ? 4095 - var1 : var0;
         }
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "kb.p(" + ')');
      }
   }
}
