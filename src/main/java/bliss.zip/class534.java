public class class534 extends class381 {
   static boolean field3722;

   class534() throws Throwable {
      throw new Error();
   }

   static void method2290(int var0) {
      try {
         class342.field286 = (-445162670 + class271.field10557.field8230 * 1924902313 + class271.field10557.field8225 * 1924902313) * 1194411673;
         class342.field290 = (524676266 + class378.field1158.field8230 * -1885145515 + class378.field1158.field8225 * -1885145515) * 376067837;
         class342.field287 = new String[500];

         for(int var1 = 0; var1 < class342.field287.length; ++var1) {
            class342.field287[var1] = "";
         }

         class213.method3810(class814.field4824.method2927(class321.field1066, -875414210), 1099175264);
      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "adx.b(" + ')');
      }
   }

   static final void method2291(class744 var0, int var1) {
      try {
         var0.field3161[++var0.field3156 - 1] = class384.field1425;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "adx.amp(" + ')');
      }
   }

   static final void method2292(class744 var0, short var1) {
      try {
         class237 var2 = var0.field3178 ? var0.field3164 : var0.field3163;
         class564 var3 = var2.field8255;
         class131 var4 = var2.field8254;
         class713.method2076(var3, var4, var0, (byte)36);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "adx.dk(" + ')');
      }
   }

   static final void method2293(class564 var0, class131 var1, class744 var2, int var3) {
      try {
         var0.field909 = 3;
         var0.field876 = -1;
         if (var0.field879 == -1 && !var1.field1101) {
            class535.method2284(var0.field867, 1454915163);
         }

      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "adx.hq(" + ')');
      }
   }
}
