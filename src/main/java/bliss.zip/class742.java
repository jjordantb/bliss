public interface class742 {
   int field3136 = 0;
   int field3137 = 4;
   int field3138 = 2;
   int field3139 = 3;
   int field3140 = 1;
   int field3141 = 2;
   int field3142 = 1;

   long method1863(int var1);

   char method1864(byte var1);

   int method1865(byte var1);

   char method1866();

   int method1867(byte var1);

   int method1868();

   int method1869();

   char method1870();

   int method1871();

   int method1872();

   long method1873();

   int method1874(int var1);
}
