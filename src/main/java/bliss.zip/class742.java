public interface class742 {
   long method1863(int var1);

   char method1864(byte var1);

   int method1865(byte var1);

   int method1867(byte var1);

   int method1874(int var1);
}
