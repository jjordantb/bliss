import java.io.IOException;

public abstract class class341 {
   class514 field301 = new class514();
   static int field302 = 512;
   static int field303 = 20;
   public volatile int field304 = 0;
   class514 field305 = new class514();
   class907 field306 = new class907(10);
   class514 field307 = new class514();
   static int field308 = 50;
   int field309;
   long field310;
   class514 field311 = new class514();
   byte field312 = 0;
   class907 field313 = new class907(6);
   public volatile int field314 = 0;
   static int field315 = 3;
   class448 field316;
   public static long field317;

   abstract void method224();

   class448 method225(int var1, int var2, byte var3, boolean var4, int var5) {
      try {
         long var6 = ((long)var1 << 32) + (long)var2;
         class448 var8 = new class448();
         var8.field209 = 1476940603538232441L * var6;
         var8.field7100 = var3;
         var8.field3466 = var4;
         if (var4) {
            if (this.method235(2080324549) >= 50) {
               throw new RuntimeException();
            }

            this.field305.method2704(var8, (byte)-14);
         } else {
            if (this.method228(144457290) >= 20) {
               throw new RuntimeException();
            }

            this.field307.method2704(var8, (byte)-22);
         }

         return var8;
      } catch (RuntimeException var10) {
         throw class158.method3445(var10, "ki.a(" + ')');
      }
   }

   public abstract void method226();

   boolean method227(byte var1) {
      try {
         return this.method235(1959855858) >= 50;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ki.b(" + ')');
      }
   }

   int method228(int var1) {
      try {
         return this.field307.method2708((short)-13891) + this.field301.method2708((short)-16314);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ki.p(" + ')');
      }
   }

   public abstract void method229(Object var1, boolean var2);

   public abstract void method230(boolean var1, int var2);

   public abstract void method231(Object var1, boolean var2, int var3);

   public abstract void method232(byte var1);

   public abstract void method233(byte var1);

   boolean method234(byte var1) {
      try {
         return this.method228(-938507058) >= 20;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ki.f(" + ')');
      }
   }

   public int method235(int var1) {
      try {
         return this.field305.method2708((short)-18478) + this.field311.method2708((short)-10486);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ki.i(" + ')');
      }
   }

   public abstract boolean method236();

   abstract void method237();

   public abstract boolean method238(int var1);

   public abstract void method239(Object var1, boolean var2);

   public abstract void method240(short var1);

   public abstract void method241(boolean var1);

   public abstract void method242();

   public abstract void method243();

   public abstract void method244();

   public abstract void method245();

   abstract void method246(int var1);

   public abstract void method247();

   public abstract void method248();

   static final void method249(class513 var0, int var1, int var2) {
      try {
         class498.field8112 = 0;
         class397.method3478(var0, (byte)-53);
         class810.method2896(var0, -2052480320);
         if (var0.field10376 * 385051775 != var1) {
            throw new RuntimeException(385051775 * var0.field10376 + " " + var1);
         }
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "ki.f(" + ')');
      }
   }

   static final void method250(class564 var0, class131 var1, class744 var2, int var3) {
      try {
         var0.field906 = var2.field3161[(var2.field3156 -= -391880689) * 681479919] == 1;
         class814.method2932(var0, -270865215);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "ki.fm(" + ')');
      }
   }

   static final void method251(class744 var0, byte var1) {
      try {
         int var2 = var0.field3161[(var0.field3156 -= -391880689) * 681479919];
         class564 var3 = class449.method3756(var2, (byte)36);
         class131 var4 = class382.field1410[var2 >> 16];
         class384.method1082(var3, var4, var0, (byte)16);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "ki.gz(" + ')');
      }
   }

   public static void method252(int var0) {
      try {
         if (class540.field3925 != null) {
            class540.field3925.method2626(720263824);
         }

         if (class95.field607 != null) {
            class95.field607.method2626(-1003086851);
         }

      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "ki.d(" + ')');
      }
   }

   public static int method253(class357 var0, byte var1) {
      try {
         if (class602.field8645) {
            return 6;
         } else if (var0 == null) {
            return 0;
         } else {
            int var2 = 946432351 * var0.field1702;
            if (class140.method1049(var2, 1867074090)) {
               return 1;
            } else if (class745.method2593(var2, (short)300)) {
               return 2;
            } else if (class769.method2260(var2, (byte)55)) {
               return 3;
            } else if (class717.method2030(var2, -1710245740)) {
               return 4;
            } else if (class954.method2091(var2, (byte)120)) {
               return 7;
            } else {
               return 16 == var2 ? 8 : 5;
            }
         }
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ki.ap(" + ')');
      }
   }

   static final void method254(class744 var0, int var1) {
      try {
         class392 var2 = class35.method3337(1470671507);
         if (var2 == null) {
            var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = -1;
            var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = -1;
         } else {
            var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = -530122905 * var2.field5396;
            int var3 = -1740053407 * var2.field5393 << 28 | 2122110429 * var2.field5395 + class491.field7820 << 14 | class491.field7813 + -372920341 * var2.field5398;
            var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = var3;
         }

      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "ki.adz(" + ')');
      }
   }

   public static String method255(int var0, int var1) {
      try {
         return "<img=" + var0 + ">";
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ki.a(" + ')');
      }
   }

   static final void method256(class744 var0, int var1) {
      try {
         class237.method4657(class770.method2302(1476588124), var0, (byte)0);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ki.uh(" + ')');
      }
   }

   static final boolean method257(class684 var0, int var1) {
      try {
         boolean var2;
         try {
            var2 = class55.method1561(var0, -1028317786);
         } catch (IOException var7) {
            if (18 == -1233866115 * class730.field2733) {
               var0.method4375(1607816785);
               return false;
            }

            class307.method387(-196070211);
            return true;
         } catch (Exception var8) {
            class389 var4 = class730.field2697.method5270(681479919);
            String var5 = (var0.field7770 != null ? 2075990793 * var0.field7770.field4450 : -1) + class822.field9050 + (var0.field7780 != null ? 2075990793 * var0.field7780.field4450 : -1) + class822.field9050 + (var0.field7783 != null ? 2075990793 * var0.field7783.field4450 : -1) + " " + var0.field7771 * -866602563 + class822.field9050 + (-1760580017 * var4.field1521 + class923.field10295.field4085[0]) + class822.field9050 + (283514611 * var4.field1522 + class923.field10295.field4055[0]) + " ";

            for(int var6 = 0; var6 < -866602563 * var0.field7771 && var6 < 50; ++var6) {
               var5 = var5 + var0.field7768.field10375[var6] + class822.field9050;
            }

            class764.method2747(var5, var8, (short)-6614);
            class82.method920(false, (byte)71);
            return true;
         }

         return var2;
      } catch (RuntimeException var9) {
         throw class158.method3445(var9, "ki.jc(" + ')');
      }
   }

   public static void method258(byte var0) {
      try {
         class881.method6171(-1349846936);
         class978.field3128.method3590(2074664377);
         class978.field3124.method3590(2003457775);
         if (class978.field3123 * -2116412357 > 0) {
            class978.field3123 -= -1604952845;
         }

         class701 var1;
         if (class730.field2744 && class978.field3123 * -2116412357 <= 0) {
            class978.field3123 = -2034285828;
            class730.field2744 = false;
            var1 = class637.method5936(class643.field10033, class730.field2692.field7765, (byte)50);
            var1.field3364.method6419((int)class730.field2738 >> 3);
            var1.field3364.method6421((int)class730.field2931 >> 3, 1908840395);
            class730.field2692.method4380(var1, (byte)-20);
         }

         if (class978.field3125 != class619.field8869) {
            class978.field3125 = class619.field8869;
            var1 = class637.method5936(class643.field10000, class730.field2692.field7765, (byte)90);
            var1.field3364.method6361(class619.field8869 ? 1 : 0);
            class730.field2692.method4380(var1, (byte)-44);
         }

         if (!class730.field2647) {
            var1 = class637.method5936(class643.field9940, class730.field2692.field7765, (byte)9);
            var1.field3364.method6361(0);
            int var2 = 385051775 * var1.field3364.field10376;
            class907 var3 = class615.field8903.method5393(-49990428);
            var1.field3364.method6425(var3.field10375, 0, 385051775 * var3.field10376, (short)-16962);
            var1.field3364.method6426(var1.field3364.field10376 * 385051775 - var2, (byte)-113);
            class730.field2692.method4380(var1, (byte)-84);
            class730.field2647 = true;
         }

      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "ki.d(" + ')');
      }
   }

   static void method259(class848 var0, int var1, int var2, int var3, int var4, int var5, int var6) {
      try {
         if ((class51.field2309 == null || class936.field10314 == null || class103.field206 == null) && class562.field827.method3280(class420.field9723 * 1049272911, -457216440) && class562.field827.method3280(class861.field9025 * -745532315, -457216440) && class562.field827.method3280(-684155443 * class553.field519, -457216440)) {
            class922 var7 = class922.method6242(class562.field827, -745532315 * class861.field9025, 0);
            class936.field10314 = var0.method4982(var7, true);
            var7.method6247();
            class407.field9260 = var0.method4982(var7, true);
            class51.field2309 = var0.method4982(class922.method6242(class562.field827, 1049272911 * class420.field9723, 0), true);
            class922 var8 = class922.method6242(class562.field827, class553.field519 * -684155443, 0);
            class103.field206 = var0.method4982(var8, true);
            var8.method6247();
            class593.field1622 = var0.method4982(var8, true);
         }

         if (class51.field2309 != null && class936.field10314 != null && class103.field206 != null) {
            int var11 = (var3 - class103.field206.method3106() * 2) / class51.field2309.method3106();

            int var12;
            for(var12 = 0; var12 < var11; ++var12) {
               class51.field2309.method3128(var1 + class103.field206.method3106() + var12 * class51.field2309.method3106(), var2 + var4 - class51.field2309.method3108());
            }

            var12 = (var4 - var5 - class103.field206.method3108()) / class936.field10314.method3108();

            for(int var9 = 0; var9 < var12; ++var9) {
               class936.field10314.method3128(var1, var5 + var2 + var9 * class936.field10314.method3108());
               class407.field9260.method3128(var3 + var1 - class407.field9260.method3106(), var5 + var2 + var9 * class936.field10314.method3108());
            }

            class103.field206.method3128(var1, var4 + var2 - class103.field206.method3108());
            class593.field1622.method3128(var3 + var1 - class103.field206.method3106(), var2 + var4 - class103.field206.method3108());
         }

      } catch (RuntimeException var10) {
         throw class158.method3445(var10, "ki.am(" + ')');
      }
   }

   static final void method260(class744 var0, byte var1) {
      try {
         var0.field3156 -= -783761378;
         int var2 = var0.field3161[var0.field3156 * 681479919];
         int var3 = var0.field3161[1 + var0.field3156 * 681479919];
         class514 var4 = class491.method4400(var2 >> 14 & 16383, var2 & 16383);
         boolean var5 = false;

         for(class327 var6 = (class327)var4.method2706(1544902477); var6 != null; var6 = (class327)var4.method2707(1578702645)) {
            if (-947282109 * var6.field16 == var3) {
               var5 = true;
               break;
            }
         }

         if (var5) {
            var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = 1;
         } else {
            var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = 0;
         }

      } catch (RuntimeException var7) {
         throw class158.method3445(var7, "ki.ael(" + ')');
      }
   }

   static final void method261(class744 var0, int var1) {
      try {
         int var2 = var0.field3161[(var0.field3156 -= -391880689) * 681479919];
         int var3 = class615.field8903.field9153.method2717(-2143149199);
         if (var2 != var3 && class540.field3923 * 782166935 == class540.field3920 * -1256171511) {
            if (!class552.method457(class730.field2733 * -1233866115, (byte)33)) {
               if (var3 == 0) {
                  class58.method1581(class771.field3732, -1256171511 * class540.field3920, 0, var2, false, -2072200222);
                  class228.method4589(791572932);
                  class540.field3921 = false;
               } else if (var2 == 0) {
                  class809.method2888((byte)-3);
                  class540.field3921 = false;
               } else {
                  class917.method6448(var2, -1911723714);
               }
            }

            class615.field8903.method5391(class615.field8903.field9153, var2, -1422708524);
            class95.method523(656179282);
            class730.field2647 = false;
         }

      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "ki.ajq(" + ')');
      }
   }

   public static boolean method262(char var0, int var1) {
      try {
         if (var0 >= ' ' && var0 <= '~') {
            return true;
         } else if (var0 >= ' ' && var0 <= 'ÿ') {
            return true;
         } else {
            return var0 == '€' || 'Œ' == var0 || var0 == '—' || var0 == 'œ' || var0 == 'Ÿ';
         }
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ki.v(" + ')');
      }
   }

   static void method263(int var0) {
      try {
         for(class357 var1 = (class357)class602.field8647.method901(1766612795); var1 != null; var1 = (class357)class602.field8647.method906(49146)) {
            if (class140.method1049(946432351 * var1.field1702, 1804726647)) {
               class56.method1550(var1, (byte)5);
            }
         }

      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "ki.w(" + ')');
      }
   }
}
