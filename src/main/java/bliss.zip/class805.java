public class class805 {
   int field4399;
   int field4400;
   int field4401;
   short field4402;
   byte field4403;
   short field4404;
   short field4405;
   short field4406;
   int field4407;
   int field4408 = 0;
   short field4409;
}
