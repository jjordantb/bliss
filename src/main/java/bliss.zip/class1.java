public final class class1 {
   class6 field4949;
   class514 field4950;
   int field4951;
   int field4952;

   void method2972(class142 var1, int var2) {
      try {
         if (var1 != null) {
            var1.method545(-1460969981);
            var1.method156(-2141988967);
            this.field4951 += var1.field1421 * 1177262507;
         }

      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "on.b(" + ')');
      }
   }

   public int method2973(byte var1) {
      try {
         int var2 = 0;

         for(class142 var3 = (class142)this.field4950.method2706(1659179977); var3 != null; var3 = (class142)this.field4950.method2707(1776119940)) {
            if (!var3.method1076(1593047308)) {
               ++var2;
            }
         }

         return var2;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "on.r(" + ')');
      }
   }

   public Object method2974(long var1) {
      try {
         class142 var3 = (class142)this.field4949.method2942(var1);
         if (var3 == null) {
            return null;
         } else {
            Object var4 = var3.method1075(-1395408926);
            if (var4 == null) {
               var3.method545(-1460969981);
               var3.method156(-300474257);
               this.field4951 += var3.field1421 * 1177262507;
               return null;
            } else {
               if (var3.method1076(-1388215910)) {
                  class840 var5 = new class840(var4, var3.field1421 * 1177262507);
                  this.field4949.method2947(var5, var3.field641);
                  this.field4950.method2704(var5, (byte)-4);
                  var5.field209 = 0L;
                  var3.method545(-1460969981);
                  var3.method156(1072331765);
               } else {
                  this.field4950.method2704(var3, (byte)-40);
                  var3.field209 = 0L;
               }

               return var4;
            }
         }
      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "on.a(" + ')');
      }
   }

   public void method2975(Object var1, long var2, int var4, byte var5) {
      try {
         if (var4 > this.field4952) {
            throw new IllegalStateException();
         } else {
            this.method2983(var2);
            this.field4951 -= var4;

            while(this.field4951 < 0) {
               class142 var6 = (class142)this.field4950.method2705(-2130209329);
               this.method2972(var6, -1092506029);
            }

            class840 var8 = new class840(var1, var4);
            this.field4949.method2947(var8, var2);
            this.field4950.method2704(var8, (byte)-108);
            var8.field209 = 0L;
         }
      } catch (RuntimeException var7) {
         throw class158.method3445(var7, "on.i(" + ')');
      }
   }

   public void method2976(int var1, int var2) {
      try {
         for(class142 var3 = (class142)this.field4950.method2706(-1737359401); var3 != null; var3 = (class142)this.field4950.method2707(1372068776)) {
            if (var3.method1076(504566053)) {
               if (var3.method1075(1618549592) == null) {
                  var3.method545(-1460969981);
                  var3.method156(932803925);
                  this.field4951 += var3.field1421 * 1177262507;
               }
            } else if (++var3.field209 > (long)var1) {
               class681 var4 = new class681(var3.method1075(1802409899), var3.field1421 * 1177262507);
               this.field4949.method2947(var4, var3.field641);
               class599.method1287(var4, var3, -2008394772);
               var3.method545(-1460969981);
               var3.method156(357875821);
            }
         }

      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "on.k(" + ')');
      }
   }

   public void method2977() {
      try {
         this.field4950.method2710(1649887220);
         this.field4949.method2941((byte)-88);
         this.field4951 = this.field4952;
      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "on.d(" + ')');
      }
   }

   public int method2978(int var1) {
      try {
         return this.field4952;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "on.u(" + ')');
      }
   }

   public class1(int var1) {
      this(var1, var1);
   }

   public void method2979() {
      try {
         for(class142 var1 = (class142)this.field4950.method2706(-1664121892); var1 != null; var1 = (class142)this.field4950.method2707(-1665993458)) {
            if (var1.method1076(2031877244)) {
               var1.method545(-1460969981);
               var1.method156(784746714);
               this.field4951 += var1.field1421 * 1177262507;
            }
         }

      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "on.q(" + ')');
      }
   }

   public Object method2980(int var1) {
      try {
         class142 var4;
         for(class142 var2 = (class142)this.field4949.method2946(2018189704); var2 != null; this.field4951 += var4.field1421 * 1177262507) {
            Object var3 = var2.method1075(-709026193);
            if (var3 != null) {
               return var3;
            }

            var4 = var2;
            var2 = (class142)this.field4949.method2945((byte)18);
            var4.method545(-1460969981);
            var4.method156(600406320);
         }

         return null;
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "on.n(" + ')');
      }
   }

   public Object method2981(int var1) {
      try {
         class142 var4;
         for(class142 var2 = (class142)this.field4949.method2945((byte)37); var2 != null; this.field4951 += var4.field1421 * 1177262507) {
            Object var3 = var2.method1075(110174403);
            if (var3 != null) {
               return var3;
            }

            var4 = var2;
            var2 = (class142)this.field4949.method2945((byte)35);
            var4.method545(-1460969981);
            var4.method156(538286919);
         }

         return null;
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "on.s(" + ')');
      }
   }

   public int method2982(int var1) {
      try {
         return this.field4951;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "on.x(" + ')');
      }
   }

   public void method2983(long var1) {
      try {
         class142 var3 = (class142)this.field4949.method2942(var1);
         this.method2972(var3, -1811015164);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "on.f(" + ')');
      }
   }

   public void method2984(Object var1, long var2) {
      try {
         this.method2975(var1, var2, 1, (byte)-117);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "on.p(" + ')');
      }
   }

   public class1(int var1, int var2) {
      this.field4950 = new class514();
      this.field4952 = var1;
      this.field4951 = var1;

      int var3;
      for(var3 = 1; var3 + var3 < var1 && var3 < var2; var3 += var3) {
         ;
      }

      this.field4949 = new class6(var3);
   }

   static final void method2985(class744 var0, int var1) {
      try {
         int var2 = var0.field3161[--var0.field3156];
         class615.field8903.method5391(class615.field8903.field9118, var2, 1144244334);
         class730.field2697.method5309(458039847);
         class95.method523(656179282);
         class730.field2647 = false;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "on.ahd(" + ')');
      }
   }

   public static class162[] method2986(int var0) {
      try {
         return new class162[]{class162.field6593, class162.field6596, class162.field6592, class162.field6599, class162.field6600, class162.field6589, class162.field6598, class162.field6594, class162.field6590, class162.field6588, class162.field6597, class162.field6601, class162.field6595, class162.field6591};
      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "on.a(" + ')');
      }
   }

   public static int method2987(int var0, int var1, boolean var2, byte var3) {
      try {
         class163 var4 = class213.method3812(var0, var2, 1780285943);
         if (var4 == null) {
            return 0;
         } else if (var1 == -1) {
            return 0;
         } else {
            int var5 = 0;

            for(int var6 = 0; var6 < var4.field6620.length; ++var6) {
               if (var1 == var4.field6619[var6]) {
                  var5 += var4.field6620[var6];
               }
            }

            return var5;
         }
      } catch (RuntimeException var7) {
         throw class158.method3445(var7, "on.b(" + ')');
      }
   }

   static final void method2988(class744 var0, int var1) {
      try {
         int var2 = var0.field3174[var0.field3176];
         var0.field3161[++var0.field3156 - 1] = ((class60)var0.field3159).field1634.method4032(var2, -966489489);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "on.ao(" + ')');
      }
   }
}
