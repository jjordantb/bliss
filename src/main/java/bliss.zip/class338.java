public class class338 extends class934 {
   class338(String var1, boolean var2) {
      super(var1);
   }

   class338(String var1) {
      this(var1, false);
   }
}
