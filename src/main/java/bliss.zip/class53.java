public final class class53 {
   public static boolean field2311 = true;

   class53() throws Throwable {
      throw new Error();
   }
}
