public class class542 extends class568 {
   int field3943;
   int field3944;
   int field3945;
   int field3946;
   int field3947;
   int field3948;
   int field3949;
   int field3950;
   int field3951;

   boolean method2470(int var1, int var2, int var3, int var4) {
      try {
         return this.field3950 * -206354885 == var1 && var2 >= this.field3945 * -731405573 && var2 <= 480895455 * this.field3946 && var3 >= -1728316981 * this.field3948 && var3 <= -176293349 * this.field3944;
      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "aca.f(" + ')');
      }
   }

   boolean method2471(int var1, int var2, int var3) {
      try {
         return var1 >= this.field3945 * -731405573 && var1 <= 480895455 * this.field3946 && var2 >= -1728316981 * this.field3948 && var2 <= -176293349 * this.field3944;
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "aca.a(" + ')');
      }
   }

   boolean method2472(int var1, int var2, byte var3) {
      try {
         return var1 >= this.field3943 * 1528024175 && var1 <= this.field3947 * 37578241 && var2 >= 50981941 * this.field3949 && var2 <= this.field3951 * 1374138429;
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "aca.b(" + ')');
      }
   }

   void method2473(int var1, int var2, int[] var3, int var4) {
      try {
         var3[0] = -206354885 * this.field3950;
         var3[1] = -731405573 * this.field3945 - 1528024175 * this.field3943 + var1;
         var3[2] = var2 + (this.field3948 * -1728316981 - 50981941 * this.field3949);
      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "aca.p(" + ')');
      }
   }

   class542(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9) {
      this.field3950 = 301572851 * var1;
      this.field3945 = var2 * 868816947;
      this.field3948 = -1243061277 * var3;
      this.field3946 = var4 * 992156191;
      this.field3944 = 878333971 * var5;
      this.field3943 = var6 * -134278513;
      this.field3949 = 1339754013 * var7;
      this.field3947 = var8 * 1785108993;
      this.field3951 = var9 * 734947093;
   }

   void method2474(int var1, int var2, int[] var3, int var4) {
      try {
         var3[0] = 0;
         var3[1] = this.field3943 * 1528024175 - this.field3945 * -731405573 + var1;
         var3[2] = 50981941 * this.field3949 - -1728316981 * this.field3948 + var2;
      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "aca.i(" + ')');
      }
   }
}
