public class class532 {
   public static int field3702 = 4;

   class532() throws Throwable {
      throw new Error();
   }

   static final void method2270(class744 var0, int var1) {
      try {
         var0.field3161[++var0.field3156 - 1] = class615.field8903.field9130.method5267(-2013953489) == 2 ? 1 : 0;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "qf.ajw(" + ')');
      }
   }
}
