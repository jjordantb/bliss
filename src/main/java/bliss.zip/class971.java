public class class971 {
   static class971 field2984 = new class971();
   static class971 field2985 = new class971();
   static class971 field2986 = new class971();
   static int field2987;

   public int method1786(int var1, int var2, int var3) {
      try {
         int var4 = class759.field4331 > var2 ? -2110394505 * class759.field4331 * -2010408377 : var2;
         if (field2986 == this) {
            return 0;
         } else if (field2984 == this) {
            return var4 - var1;
         } else {
            return field2985 == this ? (var4 - var1) / 2 : 0;
         }
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "fq.f(" + ')');
      }
   }

   static final void method1787(class744 var0, int var1) {
      try {
         int var2 = var0.field3161[--var0.field3156];
         class506 var3 = class395.method3397(var2, -1927807761);
         String var4 = "";
         if (var3 != null && var3.field4126 != null) {
            var4 = var3.field4126;
         }

         var0.field3157[++var0.field3158 - 1] = var4;
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "fq.acs(" + ')');
      }
   }

   static final void method1788(class744 var0, byte var1) {
      try {
         int var2 = var0.field3161[--var0.field3156];
         class327 var3 = class491.method4415(var2 >> 14 & 16383, var2 & 16383);
         if (var3 == null) {
            var0.field3161[++var0.field3156 - 1] = -1;
         } else {
            var0.field3161[++var0.field3156 - 1] = var3.field16;
         }

      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "fq.adh(" + ')');
      }
   }

   public static void method1789(String var0, boolean var1, class848 var2, class727 var3, class230 var4, byte var5) {
      try {
         boolean var6 = !class534.field3722 || class461.method3994(-2107815446);
         if (var6) {
            int var7;
            int var8;
            int var10;
            int var11;
            if (class534.field3722 && var6) {
               var4 = class228.field8221;
               var3 = var2.method4936(var4, class228.field8214, true);
               var7 = var4.method4600(var0, 250, (class653[])null, -2064618715);
               var8 = var4.method4601(var0, 250, var4.field8228, (class653[])null, -804719139);
               int var15 = class968.field2552.field10269;
               var10 = 4 + var15;
               var7 += 2 * var10;
               var8 += var10 * 2;
               if (var7 < class228.field8217) {
                  var7 = class228.field8217;
               }

               if (var8 < class228.field8220) {
                  var8 = class228.field8220;
               }

               var11 = class228.field8216.method1786(var7, class730.field2775, -1808907629) + class228.field8215;
               int var12 = class228.field8222.method3090(var8, class730.field2784, -750031668) + class228.field8218;
               var2.method4982(class5.field4945, false).method3145(var11 + class417.field9582.field10269, class417.field9582.field10273 + var12, var7 - class417.field9582.field10269 * 2, var8 - 2 * class417.field9582.field10273, 1, 0, 0);
               var2.method4982(class417.field9582, true).method3128(var11, var12);
               class417.field9582.method6247();
               var2.method4982(class417.field9582, true).method3128(var7 + var11 - var15, var12);
               class417.field9582.method6235();
               var2.method4982(class417.field9582, true).method3128(var7 + var11 - var15, var12 + var8 - var15);
               class417.field9582.method6247();
               var2.method4982(class417.field9582, true).method3128(var11, var8 + var12 - var15);
               class417.field9582.method6235();
               var2.method4982(class968.field2552, true).method3119(var11, var12 + class417.field9582.field10273, var15, var8 - 2 * class417.field9582.field10273);
               class968.field2552.method6244();
               var2.method4982(class968.field2552, true).method3119(class417.field9582.field10269 + var11, var12, var7 - 2 * class417.field9582.field10269, var15);
               class968.field2552.method6244();
               var2.method4982(class968.field2552, true).method3119(var11 + var7 - var15, var12 + class417.field9582.field10273, var15, var8 - 2 * class417.field9582.field10273);
               class968.field2552.method6244();
               var2.method4982(class968.field2552, true).method3119(var11 + class417.field9582.field10269, var12 + var8 - var15, var7 - 2 * class417.field9582.field10269, var15);
               class968.field2552.method6244();
               var3.method1663(var0, var10 + var11, var12 + var10, var7 - var10 * 2, var8 - 2 * var10, class245.field8540 | -16777216, -1, 1, 1, 0, (class48[])null, (int[])null, (class23)null, 0, 0, -45995166);
               class431.method4254(var11, var12, var7, var8, (byte)2);
            } else {
               var7 = var4.method4600(var0, 250, (class653[])null, -570698918);
               var8 = var4.method4603(var0, 250, (class653[])null, 1328812176) * 13;
               byte var9 = 4;
               var10 = 6 + var9;
               var11 = 6 + var9;
               var2.method4984(var10 - var9, var11 - var9, var9 + var7 + var9, var8 + var9 + var9, -16777216, 0);
               var2.method4838(var10 - var9, var11 - var9, var9 + var7 + var9, var8 + var9 + var9, -1, 0);
               var3.method1663(var0, var10, var11, var7, var8, -1, -1, 1, 1, 0, (class48[])null, (int[])null, (class23)null, 0, 0, -45995166);
               class431.method4254(var10 - var9, var11 - var9, var9 + var7 + var9, var8 + var9 + var9, (byte)2);
            }

            if (var1) {
               try {
                  var2.method4796((byte)18);
               } catch (class937 var13) {
                  ;
               }
            }
         }

      } catch (RuntimeException var14) {
         throw class158.method3445(var14, "fq.b(" + ')');
      }
   }

   static final void method1790(int var0, int var1, int var2, int var3, int var4) {
      try {
         class176.method3171(var0, var1, var2, 0, var3, false, 2074024195);
      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "fq.jb(" + ')');
      }
   }

   static final void method1791(class744 var0, byte var1) {
      try {
         int var2 = var0.field3161[--var0.field3156];
         class564 var3 = class449.method3756(var2, (byte)74);
         class131 var4 = class382.field1410[var2 >> 16];
         class341.method250(var3, var4, var0, 2008837273);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "fq.ff(" + ')');
      }
   }

   static final void method1792(class744 var0, int var1) {
      try {
         class706.method1935((byte)32);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "fq.ahw(" + ')');
      }
   }
}
