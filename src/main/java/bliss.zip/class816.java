public abstract class class816 extends class621 {
   abstract class891 method2898();
}
