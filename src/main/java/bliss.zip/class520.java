public class class520 extends class535 {
   public static int field4386 = 1;
   public static int field4387 = 0;

   public int method2273(int var1, int var2) {
      try {
         if (super.field3704.method5392((byte)-56) == class469.field7324) {
            if (var1 == 0) {
               if (super.field3704.field9122.method2653(1268692572) == 1) {
                  return 2;
               }

               if (super.field3704.field9123.method5845(2092806883) == 1) {
                  return 2;
               }

               if (super.field3704.field9138.method2263(1056672135) > 0) {
                  return 2;
               }
            }

            return 1;
         } else {
            return 3;
         }
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "aeq.f(" + ')');
      }
   }

   public void method2804(int var1) {
      try {
         if (super.field3704.method5392((byte)-100) != class469.field7324) {
            super.field3708 = 1;
         }

         if (super.field3708 != 0 && 1 != super.field3708) {
            super.field3708 = this.method2272(-2130948136);
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "aeq.s(" + ')');
      }
   }

   void method2275(int var1, int var2) {
      try {
         super.field3708 = var1;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "aeq.p(" + ')');
      }
   }

   public class520(int var1, class838 var2) {
      super(var1, var2);
   }

   public int method2805(int var1) {
      try {
         return super.field3708;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "aeq.y(" + ')');
      }
   }

   public class520(class838 var1) {
      super(var1);
   }

   int method2272(int var1) {
      return 1;
   }

   public boolean method2806(byte var1) {
      try {
         return super.field3704.method5392((byte)-64) == class469.field7324;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "aeq.z(" + ')');
      }
   }
}
