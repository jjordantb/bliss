public class class520 extends class535 {
   public static int field4386 = 1;
   public static int field4387 = 0;

   public int method2273(int var1, int var2) {
      try {
         if (this.field3704.method5392((byte)-56) == class469.field7324) {
            if (var1 == 0) {
               if (this.field3704.field9122.method2653(1268692572) == 1) {
                  return 2;
               }

               if (this.field3704.field9123.method5845(2092806883) == 1) {
                  return 2;
               }

               if (this.field3704.field9138.method2263(1056672135) > 0) {
                  return 2;
               }
            }

            return 1;
         } else {
            return 3;
         }
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "aeq.f(" + ')');
      }
   }

   public void method2804(int var1) {
      try {
         if (this.field3704.method5392((byte)-100) != class469.field7324) {
            this.field3708 = 1886334997;
         }

         if (this.field3708 * -1598873795 != 0 && 1 != this.field3708 * -1598873795) {
            this.field3708 = this.method2272(-2130948136) * 1886334997;
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "aeq.s(" + ')');
      }
   }

   int method2276() {
      return 1;
   }

   void method2275(int var1, int var2) {
      try {
         this.field3708 = 1886334997 * var1;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "aeq.p(" + ')');
      }
   }

   public class520(int var1, class838 var2) {
      super(var1, var2);
   }

   void method2271(int var1) {
      this.field3708 = 1886334997 * var1;
   }

   public int method2805(int var1) {
      try {
         return this.field3708 * -1598873795;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "aeq.y(" + ')');
      }
   }

   public class520(class838 var1) {
      super(var1);
   }

   public int method2277(int var1) {
      if (this.field3704.method5392((byte)-125) == class469.field7324) {
         if (var1 == 0) {
            if (this.field3704.field9122.method2653(252992424) == 1) {
               return 2;
            }

            if (this.field3704.field9123.method5845(1884202670) == 1) {
               return 2;
            }

            if (this.field3704.field9138.method2263(-1401768386) > 0) {
               return 2;
            }
         }

         return 1;
      } else {
         return 3;
      }
   }

   int method2272(int var1) {
      return 1;
   }

   public boolean method2806(byte var1) {
      try {
         return this.field3704.method5392((byte)-64) == class469.field7324;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "aeq.z(" + ')');
      }
   }
}
