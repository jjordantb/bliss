public interface class524 {
   void method2753();

   void method2754();

   void method2755();

   void method2756();
}
