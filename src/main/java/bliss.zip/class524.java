public interface class524 {
   void method2755();
}
