public class class42 {
   void method3069() {
   }

   class42() throws Throwable {
      throw new Error();
   }
}
