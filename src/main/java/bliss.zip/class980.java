public class class980 implements class925 {
   public int field3183;
   public int field3184;
   public int field3185;
   public int field3186;
   public int field3187;
   public int field3188;
   public class49 field3189;
   public class971 field3190;
   public String field3191;
   public int field3192;
   public int field3193;
   public int field3194;
   public int field3195;
   public static class428 field3196;

   public class7 method6197(int var1) {
      try {
         return class7.field4907;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "gc.f(" + ')');
      }
   }

   class980(String var1, class971 var2, class49 var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, int var11, int var12, int var13) {
      this.field3191 = var1;
      this.field3190 = var2;
      this.field3189 = var3;
      this.field3186 = var4;
      this.field3187 = var5;
      this.field3188 = var6;
      this.field3183 = var7;
      this.field3192 = var8;
      this.field3184 = var9;
      this.field3185 = var10;
      this.field3193 = var11;
      this.field3194 = var12;
      this.field3195 = var13;
   }

   public static class114 method1912(int var0, int var1) {
      try {
         class114 var2 = (class114)class114.field1721.method2974((long)var0);
         if (var2 != null) {
            return var2;
         } else {
            byte[] var3 = class114.field1727.method3285(0, var0, (byte)-125);
            var2 = new class114();
            if (var3 != null) {
               var2.method1292(new class907(var3), (byte)20);
            }

            var2.method1294(-721593745);
            class114.field1721.method2984(var2, (long)var0);
            return var2;
         }
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "gc.f(" + ')');
      }
   }

   static boolean method1913(int var0) {
      try {
         return class447.method4319(class422.field9604.field2971, -1572506836);
      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "gc.a(" + ')');
      }
   }

   static final void method1914(class744 var0, byte var1) {
      try {
         var0.field3168[++var0.field3162 - 1] = var0.field3177.field175[var0.field3176];
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "gc.bf(" + ')');
      }
   }

   static boolean method1915(int var0, int var1) {
      try {
         return var0 == 18 || var0 == 16;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "gc.fg(" + ')');
      }
   }

   static final void method1916(class744 var0, int var1) {
      try {
         class237 var2 = var0.field3178 ? var0.field3164 : var0.field3163;
         class564 var3 = var2.field8255;
         class131 var4 = var2.field8254;
         class153.method3389(var3, var4, var0, 2046664396);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "gc.gt(" + ')');
      }
   }

   public static final void method1917(int var0) {
      try {
         if (!class730.field2742) {
            class730.field2741 += (-12.0F - class730.field2741) / 2.0F;
            class730.field2744 = true;
            class730.field2742 = true;
         }

      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "gc.hq(" + ')');
      }
   }

   static final void method1918(class744 var0, int var1) {
      try {
         class547.method379((byte)-5);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "gc.aet(" + ')');
      }
   }
}
