public class class117 {
   public static int field1842 = 6;
   public static int field1843 = 26;
   public static int field1844 = 1;
   public static int field1845 = 14;
   public static int field1846 = 24;
   public static int field1847 = 8;
   public static int field1848 = 9;
   public static int field1849 = 22;
   public static int field1850 = 16;
   public static int field1851 = 10;
   public static int field1852 = 15;
   public static int field1853 = 2;
   public static int field1854 = 3;
   public static int field1855 = 4;
   public static int field1856 = 25;
   public static int field1857 = 27;
   public static int field1858 = 23;
   public static int field1859 = 21;
   public static int field1860 = 29;
   public static int field1861 = 7;
   public static int field1862 = 13;
   public static int field1863 = 17;
   public static int field1864 = 5;
   public static int field1865 = 11;
   public static int field1866 = 28;
   public static int field1867 = 20;
   public static class640 field1868;

   class117() throws Throwable {
      throw new Error();
   }

   static void method1342(class202 var0, int var1, short var2) {
      try {
         Object[] var3 = var0.field7583;
         int var4 = ((Integer)var3[0]).intValue();
         class346 var5 = class82.method915(var4, (byte)1);
         if (var5 != null) {
            class744 var6 = class909.method6439(974537460);
            var6.field3165 = new int[var5.field177 * -1516159487];
            int var7 = 0;
            var6.field3151 = new String[var5.field178 * 1787035509];
            int var8 = 0;
            var6.field3152 = new long[1679522843 * var5.field179];
            int var9 = 0;

            for(int var10 = 1; var10 < var3.length; ++var10) {
               if (var3[var10] instanceof Integer) {
                  int var11 = ((Integer)var3[var10]).intValue();
                  if (-2147483647 == var11) {
                     var11 = var0.field7579 * 1893415363;
                  }

                  if (var11 == -2147483646) {
                     var11 = -54723935 * var0.field7580;
                  }

                  if (var11 == -2147483645) {
                     var11 = var0.field7578 != null ? -440872681 * var0.field7578.field867 : -1;
                  }

                  if (-2147483644 == var11) {
                     var11 = 426539335 * var0.field7581;
                  }

                  if (-2147483643 == var11) {
                     var11 = var0.field7578 != null ? -1309843523 * var0.field7578.field879 : -1;
                  }

                  if (-2147483642 == var11) {
                     var11 = var0.field7582 != null ? -440872681 * var0.field7582.field867 : -1;
                  }

                  if (var11 == -2147483641) {
                     var11 = var0.field7582 != null ? var0.field7582.field879 * -1309843523 : -1;
                  }

                  if (-2147483640 == var11) {
                     var11 = -1652898593 * var0.field7585;
                  }

                  if (-2147483639 == var11) {
                     var11 = var0.field7584 * -2080757995;
                  }

                  var6.field3165[var7++] = var11;
               } else if (var3[var10] instanceof String) {
                  String var15 = (String)var3[var10];
                  if (var15.equals("event_opbase")) {
                     var15 = var0.field7576;
                  }

                  var6.field3151[var8++] = var15;
               } else if (var3[var10] instanceof Long) {
                  long var12 = ((Long)var3[var10]).longValue();
                  var6.field3152[var9++] = var12;
               }
            }

            var6.field3171 = var0.field7577 * -323690565;
            class978.method1842(var5, var1, var6, 546888884);
         }

      } catch (RuntimeException var14) {
         throw class158.method3445(var14, "io.k(" + ')');
      }
   }

   static final void method1343(class744 var0, int var1) {
      try {
         class237 var2 = var0.field3178 ? var0.field3164 : var0.field3163;
         class564 var3 = var2.field8255;
         class131 var4 = var2.field8254;
         class564 var5 = class317.method471(var4, var3, -1926129754);
         var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = var5 == null ? -1 : var5.field867 * -440872681;
      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "io.oq(" + ')');
      }
   }

   public static void method1344(int var0) {
      try {
         try {
            int var1;
            if (1 == 617004265 * class818.field4611) {
               var1 = class818.field4614.method6560((byte)-56);
               if (var1 > 0 && class818.field4614.method6592(747355627)) {
                  var1 -= class573.field105 * -1503744809;
                  if (var1 < 0) {
                     var1 = 0;
                  }

                  class818.field4614.method6568(var1, 2100644467);
                  return;
               }

               class818.field4614.method6566((byte)-38);
               class818.field4614.method6564((byte)81);
               if (class818.field4621 != null) {
                  class818.field4611 = 1770763954;
               } else {
                  class818.field4611 = 0;
               }

               class775.field3700 = null;
               class654.field9350 = null;
            }

            if (3 == class818.field4611 * 617004265) {
               var1 = class818.field4614.method6560((byte)-5);
               if (var1 < class818.field4616 * 643426275 && class818.field4614.method6592(1822181710)) {
                  var1 += 604206485 * class916.field10417;
                  if (var1 > 643426275 * class818.field4616) {
                     var1 = 643426275 * class818.field4616;
                  }

                  class818.field4614.method6568(var1, 1707423851);
               } else {
                  class916.field10417 = 0;
                  class818.field4611 = 0;
               }
            }
         } catch (Exception var2) {
            var2.printStackTrace();
            class818.field4614.method6566((byte)3);
            class182.method3307(-1137434141);
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "io.y(" + ')');
      }
   }
}
