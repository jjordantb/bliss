public class class506 {
   public int field4120;
   public int field4121 = class574.method129(-2067769090) * -740789311;
   public int field4122;
   public String field4123;
   public String field4124;
   public String field4125;
   public String field4126;
   public int field4127;
   public int field4128;
   public String field4129;

   void method2599(int var1, int var2, String var3, String var4, String var5, String var6, int var7, String var8, short var9) {
      try {
         this.field4121 = class574.method129(-2067769090) * -740789311;
         this.field4120 = -1698852737 * class730.field2866;
         this.field4122 = var1 * 392659741;
         this.field4127 = var2 * 849125275;
         this.field4123 = var3;
         this.field4125 = var4;
         this.field4126 = var5;
         this.field4124 = var6;
         this.field4128 = var7 * 1644525439;
         this.field4129 = var8;
      } catch (RuntimeException var11) {
         throw class158.method3445(var11, "ed.a(" + ')');
      }
   }

   class506(int var1, int var2, String var3, String var4, String var5, String var6, int var7, String var8) {
      this.field4120 = class730.field2866 * -1698852737;
      this.field4122 = var1 * 392659741;
      this.field4127 = 849125275 * var2;
      this.field4123 = var3;
      this.field4125 = var4;
      this.field4126 = var5;
      this.field4124 = var6;
      this.field4128 = var7 * 1644525439;
      this.field4129 = var8;
   }

   static final void method2600(class744 var0, byte var1) {
      try {
         if (class53.field2311 && class296.field10468 != null) {
            class739.method1795(class615.field8903.field9109.method6159((byte)92), -1, -1, false, 2006169742);
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ed.aej(" + ')');
      }
   }

   static final void method2601(class744 var0, byte var1) {
      try {
         var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = 1243777389 * class881.field10138;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ed.ahj(" + ')');
      }
   }

   static final void method2602(class564 var0, class131 var1, class744 var2, int var3) {
      try {
         var0.field898 = var2.field3161[(var2.field3156 -= -391880689) * 681479919] * -1041514725;
         class814.method2932(var0, -1371264268);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "ed.db(" + ')');
      }
   }
}
