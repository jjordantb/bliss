public class class146 extends class717 {
   short field1549;
   int field1550 = (int)(class27.method3468((byte)1) / 1000L);
   String field1551;

   class146(String var1, int var2) {
      this.field1551 = var1;
      this.field1549 = (short)var2;
   }

   public static void method1183(int var0, byte var1) {
      try {
         class682 var2 = class370.method881(17, (long)var0);
         var2.method4336(-1772707008);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "aan.ak(" + ')');
      }
   }
}
