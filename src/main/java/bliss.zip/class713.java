public class class713 extends class568 {
   class660 field3534;
   float field3535;
   int field3536;
   int field3537;
   class396 field3538;
   int field3539;
   float field3540;
   static float[] field3541 = new float[3];
   static class357 field3542;

   void method2075(int var1) {
      try {
         this.field3536 = 2086576921 * this.field3538.field6508;
         this.field3537 = this.field3538.field6512 * 587912369;
         this.field3539 = this.field3538.field6513 * -247287593;
         if (this.field3538.field6514 != null) {
            this.field3538.field6514.method294((float)(1776313545 * this.field3534.field9643), (float)(-739294135 * this.field3534.field9644), (float)(this.field3534.field9645 * -1849369705), field3541);
         }

         this.field3535 = field3541[0];
         this.field3540 = field3541[2];
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "acf.a(" + ')');
      }
   }

   class713(class396 var1, class726 var2) {
      this.field3538 = var1;
      this.field3534 = this.field3538.method3493((byte)3);
      this.method2075(-1046035099);
   }

   static final void method2076(class564 var0, class131 var1, class744 var2, byte var3) {
      try {
         var0.field948 = var2.field3161[(var2.field3156 -= -391880689) * 681479919] * 728904583;
         class814.method2932(var0, 1196529132);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "acf.dx(" + ')');
      }
   }
}
