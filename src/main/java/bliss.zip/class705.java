public class class705 extends class568 {
   int field3292;
   int field3293;
   class656 field3294;
   int field3295;
   int field3296;
   int field3297;
   int field3298;
   int field3299;
   int field3300;
   int field3301;
   int field3302;
   int field3303;
   class154 field3304;
   int field3305;
   int field3306;
   class683 field3307;
   static int field3308 = 1048576;
   int field3309;
   class436 field3310;
   int field3311;
   int field3312;
   int field3313;

   void method1940(byte var1) {
      try {
         this.field3307 = null;
         this.field3294 = null;
         this.field3304 = null;
         this.field3310 = null;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "aaq.a(" + ')');
      }
   }

   static final void method1941(class744 var0, byte var1) {
      try {
         class503.method2581(var0, -807637826);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "aaq.so(" + ')');
      }
   }
}
