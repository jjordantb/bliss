public class class556 {
   static int field502 = 3;
   public static int field503;

   class556() throws Throwable {
      throw new Error();
   }

   static boolean method431(int var0) {
      try {
         return class904.field10355 != null;
      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "ud.b(" + ')');
      }
   }

   static final void method432(class744 var0, int var1) {
      try {
         class237 var2 = var0.field3178 ? var0.field3164 : var0.field3163;
         class564 var3 = var2.field8255;
         class131 var4 = var2.field8254;
         class309.method365(var3, var4, var0, (byte)0);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "ud.gj(" + ')');
      }
   }
}
