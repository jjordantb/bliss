public interface class332 extends class659 {
}
