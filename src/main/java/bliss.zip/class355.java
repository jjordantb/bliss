public class class355 extends class347 {
   int field2021 = -406574937;
   int field2022 = 0;
   int field2023 = 0;
   int field2024 = -1186609124;

   void method1410(int var1, class907 var2) {
      switch(var1) {
      case 0:
         this.field2021 = var2.method6374() * -1944832501;
         break;
      case 1:
         this.field2024 = var2.method6374() * -1347820645;
         break;
      case 2:
         this.field2023 = var2.method6374() * 1715409727;
         break;
      case 3:
         this.field2022 = var2.method6374() * 580600575;
      }

   }

   int[] method1411(int var1) {
      int[] var2 = this.field270.method3546(var1, 1699675039);
      if (this.field270.field6612) {
         for(int var3 = 0; var3 < class322.field831 * -1474554145; ++var3) {
            int var4 = 544890047 * this.field2023 + (class322.field838[var3] << 12) / (this.field2021 * -1758059101);
            int var5 = (class322.field836[var1] << 12) / (-1758059101 * this.field2021) + this.field2022 * -824460033;
            int var6 = var4;
            int var7 = var5;
            int var8 = var4;
            int var9 = var5;
            int var10 = var4 * var4 >> 12;
            int var11 = var5 * var5 >> 12;

            int var12;
            for(var12 = 0; var11 + var10 < 16384 && var12 < this.field2024 * 1781451411; ++var12) {
               var9 = (var8 * var9 >> 12) * 2 + var7;
               var8 = var10 - var11 + var6;
               var10 = var8 * var8 >> 12;
               var11 = var9 * var9 >> 12;
            }

            var2[var3] = var12 < this.field2024 * 1781451411 - 1 ? (var12 << 12) / (this.field2024 * 1781451411) : 0;
         }
      }

      return var2;
   }

   void method209(int var1, class907 var2, byte var3) {
      try {
         switch(var1) {
         case 0:
            this.field2021 = var2.method6374() * -1944832501;
            break;
         case 1:
            this.field2024 = var2.method6374() * -1347820645;
            break;
         case 2:
            this.field2023 = var2.method6374() * 1715409727;
            break;
         case 3:
            this.field2022 = var2.method6374() * 580600575;
         }

      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "aht.r(" + ')');
      }
   }

   public class355() {
      super(0, true);
   }

   int[] method1412(int var1) {
      int[] var2 = this.field270.method3546(var1, 1437756438);
      if (this.field270.field6612) {
         for(int var3 = 0; var3 < class322.field831 * -1474554145; ++var3) {
            int var4 = 544890047 * this.field2023 + (class322.field838[var3] << 12) / (this.field2021 * -1758059101);
            int var5 = (class322.field836[var1] << 12) / (-1758059101 * this.field2021) + this.field2022 * -824460033;
            int var6 = var4;
            int var7 = var5;
            int var8 = var4;
            int var9 = var5;
            int var10 = var4 * var4 >> 12;
            int var11 = var5 * var5 >> 12;

            int var12;
            for(var12 = 0; var11 + var10 < 16384 && var12 < this.field2024 * 1781451411; ++var12) {
               var9 = (var8 * var9 >> 12) * 2 + var7;
               var8 = var10 - var11 + var6;
               var10 = var8 * var8 >> 12;
               var11 = var9 * var9 >> 12;
            }

            var2[var3] = var12 < this.field2024 * 1781451411 - 1 ? (var12 << 12) / (this.field2024 * 1781451411) : 0;
         }
      }

      return var2;
   }

   int[] method203(int var1, int var2) {
      try {
         int[] var3 = this.field270.method3546(var1, 1793310792);
         if (this.field270.field6612) {
            for(int var4 = 0; var4 < class322.field831 * -1474554145; ++var4) {
               int var5 = 544890047 * this.field2023 + (class322.field838[var4] << 12) / (this.field2021 * -1758059101);
               int var6 = (class322.field836[var1] << 12) / (-1758059101 * this.field2021) + this.field2022 * -824460033;
               int var7 = var5;
               int var8 = var6;
               int var9 = var5;
               int var10 = var6;
               int var11 = var5 * var5 >> 12;
               int var12 = var6 * var6 >> 12;

               int var13;
               for(var13 = 0; var12 + var11 < 16384 && var13 < this.field2024 * 1781451411; ++var13) {
                  var10 = (var9 * var10 >> 12) * 2 + var8;
                  var9 = var11 - var12 + var7;
                  var11 = var9 * var9 >> 12;
                  var12 = var10 * var10 >> 12;
               }

               var3[var4] = var13 < this.field2024 * 1781451411 - 1 ? (var13 << 12) / (this.field2024 * 1781451411) : 0;
            }
         }

         return var3;
      } catch (RuntimeException var14) {
         throw class158.method3445(var14, "aht.i(" + ')');
      }
   }

   void method1413(int var1, class907 var2) {
      switch(var1) {
      case 0:
         this.field2021 = var2.method6374() * -1944832501;
         break;
      case 1:
         this.field2024 = var2.method6374() * -1347820645;
         break;
      case 2:
         this.field2023 = var2.method6374() * 1715409727;
         break;
      case 3:
         this.field2022 = var2.method6374() * 580600575;
      }

   }

   public static boolean method1414(int var0, int var1) {
      try {
         return var0 != 1 && 7 != var0;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "aht.a(" + ')');
      }
   }
}
