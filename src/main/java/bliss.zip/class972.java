public class class972 {
   public static class972 field2960 = new class972();
   public static class972 field2961 = new class972();
   public static class972 field2962 = new class972();
   public static class972 field2963 = new class972();
   public static class180 field2964;
   public static class240 field2965;

   static final void method1772(class744 var0, byte var1) {
      try {
         class237 var2 = var0.field3178 ? var0.field3164 : var0.field3163;
         class564 var3 = var2.field8255;
         class131 var4 = var2.field8254;
         class640.method6190(var3, var4, var0, (short)-9329);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "tc.jk(" + ')');
      }
   }

   public static void method1773(int var0, int var1, int var2, int var3, int var4) {
      try {
         class381.field1416 = var0;
         class381.field1413 = var2;
         class381.field1414 = var1;
         class381.field1415 = var3;
      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "tc.f(" + ')');
      }
   }

   static final void method1774(class744 var0, int var1) {
      try {
         int var2 = var0.field3161[--var0.field3156];
         class564 var3 = class449.method3756(var2, (byte)-30);
         class131 var4 = class382.field1410[var2 >> 16];
         class221.method4036(var3, var4, var0, (short)255);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "tc.ew(" + ')');
      }
   }

   static void method1775(class848 var0, int var1) {
      try {
         if (!class602.field8663) {
            class738.method1797(var0, -1625873215);
         } else {
            class974.method1784(var0, -618250178);
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "tc.aj(" + ')');
      }
   }

   static final int method1776(int var0, int var1, int var2, int var3) {
      try {
         return var0 < var1 ? var1 : (var0 > var2 ? var2 : var0);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "tc.p(" + ')');
      }
   }

   static void method1777(class848 var0, byte var1) {
      try {
         if (class602.field8645) {
            method1775(var0, -2009290337);
         } else {
            class255.method4499(var0, 1272900210);
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "tc.l(" + ')');
      }
   }

   static void method1778(int var0, int var1, int var2, int var3) {
      try {
         if (1008 == var0) {
            class574.method131(class112.field2110, var1, var2, 67564061);
         } else if (var0 == 1009) {
            class574.method131(class112.field2112, var1, var2, -679680198);
         } else if (var0 == 1010) {
            class574.method131(class112.field2109, var1, var2, -1335757742);
         } else if (1011 == var0) {
            class574.method131(class112.field2121, var1, var2, -1097682484);
         } else if (var0 == 1012) {
            class574.method131(class112.field2124, var1, var2, -1428410660);
         }

      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "tc.cm(" + ')');
      }
   }
}
