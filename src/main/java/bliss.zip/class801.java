public interface class801 extends class659 {
   int method2845();

   float method2846(float var1);

   float method2847(float var1);

   boolean method2848();

   void method2849(boolean var1, boolean var2);

   void method2850(int var1, int var2, int var3, int var4, int[] var5, int var6, int var7);

   void method2851(int var1, int var2, int var3, int var4, byte[] var5, class264 var6, int var7, int var8);

   void method2852(int var1, int var2, int var3, int var4, int[] var5, int var6);

   int method2861();

   boolean method2872();
}
