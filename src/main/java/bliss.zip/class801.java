public interface class801 extends class659 {
   int method2844();

   int method2845();

   float method2846(float var1);

   float method2847(float var1);

   boolean method2848();

   void method2849(boolean var1, boolean var2);

   void method2850(int var1, int var2, int var3, int var4, int[] var5, int var6, int var7);

   void method2851(int var1, int var2, int var3, int var4, byte[] var5, class264 var6, int var7, int var8);

   void method2852(int var1, int var2, int var3, int var4, int[] var5, int var6);

   int method2853();

   boolean method2854();

   int method2855();

   void method2856(int var1, int var2, int var3, int var4, byte[] var5, class264 var6, int var7, int var8);

   int method2857();

   float method2858(float var1);

   float method2859(float var1);

   float method2860(float var1);

   int method2861();

   void method2862(int var1, int var2, int var3, int var4, int[] var5, int var6);

   float method2863(float var1);

   float method2864(float var1);

   void method2865(boolean var1, boolean var2);

   void method2866(boolean var1, boolean var2);

   void method2867(boolean var1, boolean var2);

   void method2868(boolean var1, boolean var2);

   void method2869(int var1, int var2, int var3, int var4, byte[] var5, class264 var6, int var7, int var8);

   void method2870(int var1, int var2, int var3, int var4, int[] var5, int var6, int var7);

   void method2871(int var1, int var2, int var3, int var4, int[] var5, int var6, int var7);

   boolean method2872();

   void method2873(int var1, int var2, int var3, int var4, byte[] var5, class264 var6, int var7, int var8);

   float method2874(float var1);

   void method2875(boolean var1, boolean var2);

   void method2876(int var1, int var2, int var3, int var4, int[] var5, int var6);

   boolean method2877();

   float method2878(float var1);

   boolean method2879();

   boolean method2880();
}
