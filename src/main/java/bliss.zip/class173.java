public class class173 extends class576 {
   class48 field4971;

   public void method1538(int var1) {
      try {
         super.method1538(567803385);
         this.field4971 = class611.method5156(super.field67, ((class665)super.field70).field9595, (byte)-76);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "zs.a(" + ')');
      }
   }

   void method59(boolean var1, int var2, int var3, int var4) {
      try {
         int var5 = this.method66(1618885491) * super.field70.field9032 / 10000;
         int[] var6 = new int[4];
         class593.field1623.method4830(var6);
         class593.field1623.method4986(var2, var3 + 2, var2 + var5, super.field70.field9036 + var3);
         this.field4971.method3119(var2, 2 + var3, super.field70.field9032, super.field70.field9036);
         class593.field1623.method4986(var6[0], var6[1], var6[2], var6[3]);
      } catch (RuntimeException var7) {
         throw class158.method3445(var7, "zs.r(" + ')');
      }
   }

   class173(class180 var1, class180 var2, class665 var3) {
      super(var1, var2, var3);
   }

   public boolean method1537(int var1) {
      try {
         return !super.method1537(-1288443228) ? false : super.field67.method3280(((class665)super.field70).field9595, -457216440);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "zs.b(" + ')');
      }
   }

   void method60(boolean var1, int var2, int var3, int var4) {
      try {
         class593.field1623.method4838(var2 - 2, var3, super.field70.field9032 + 4, 2 + super.field70.field9036, ((class665)super.field70).field9596, 0);
         class593.field1623.method4838(var2 - 1, var3 + 1, super.field70.field9032 + 2, super.field70.field9036, 0, 0);
      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "zs.x(" + ')');
      }
   }
}
