public class class173 extends class576 {
   class48 field4971;

   void method62(boolean var1, int var2, int var3) {
      int var4 = this.method66(-1625124707) * -944287579 * this.field70.field9032 / 10000;
      int[] var5 = new int[4];
      class593.field1623.method4830(var5);
      class593.field1623.method4986(var2, var3 + 2, var2 + var4, this.field70.field9036 * -1387457793 + var3);
      this.field4971.method3119(var2, 2 + var3, this.field70.field9032 * -944287579, -1387457793 * this.field70.field9036);
      class593.field1623.method4986(var5[0], var5[1], var5[2], var5[3]);
   }

   public void method1538(int var1) {
      try {
         super.method1538(567803385);
         this.field4971 = class611.method5156(this.field67, ((class665)this.field70).field9595 * -1056757525, (byte)-76);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "zs.a(" + ')');
      }
   }

   void method59(boolean var1, int var2, int var3, int var4) {
      try {
         int var5 = this.method66(1618885491) * -944287579 * this.field70.field9032 / 10000;
         int[] var6 = new int[4];
         class593.field1623.method4830(var6);
         class593.field1623.method4986(var2, var3 + 2, var2 + var5, this.field70.field9036 * -1387457793 + var3);
         this.field4971.method3119(var2, 2 + var3, this.field70.field9032 * -944287579, -1387457793 * this.field70.field9036);
         class593.field1623.method4986(var6[0], var6[1], var6[2], var6[3]);
      } catch (RuntimeException var7) {
         throw class158.method3445(var7, "zs.r(" + ')');
      }
   }

   class173(class180 var1, class180 var2, class665 var3) {
      super(var1, var2, var3);
   }

   public boolean method1537(int var1) {
      try {
         return !super.method1537(-1288443228) ? false : this.field67.method3280(-1056757525 * ((class665)this.field70).field9595, -457216440);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "zs.b(" + ')');
      }
   }

   void method57(boolean var1, int var2, int var3) {
      class593.field1623.method4838(var2 - 2, var3, this.field70.field9032 * -944287579 + 4, 2 + this.field70.field9036 * -1387457793, ((class665)this.field70).field9596 * 1514768717, 0);
      class593.field1623.method4838(var2 - 1, var3 + 1, this.field70.field9032 * -944287579 + 2, -1387457793 * this.field70.field9036, 0, 0);
   }

   public boolean method1542() {
      return !super.method1537(-2146778663) ? false : this.field67.method3280(-1056757525 * ((class665)this.field70).field9595, -457216440);
   }

   public boolean method1539() {
      return !super.method1537(1006079243) ? false : this.field67.method3280(-1056757525 * ((class665)this.field70).field9595, -457216440);
   }

   void method60(boolean var1, int var2, int var3, int var4) {
      try {
         class593.field1623.method4838(var2 - 2, var3, this.field70.field9032 * -944287579 + 4, 2 + this.field70.field9036 * -1387457793, ((class665)this.field70).field9596 * 1514768717, 0);
         class593.field1623.method4838(var2 - 1, var3 + 1, this.field70.field9032 * -944287579 + 2, -1387457793 * this.field70.field9036, 0, 0);
      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "zs.x(" + ')');
      }
   }

   void method61(boolean var1, int var2, int var3) {
      int var4 = this.method66(1173142113) * -944287579 * this.field70.field9032 / 10000;
      int[] var5 = new int[4];
      class593.field1623.method4830(var5);
      class593.field1623.method4986(var2, var3 + 2, var2 + var4, this.field70.field9036 * -1387457793 + var3);
      this.field4971.method3119(var2, 2 + var3, this.field70.field9032 * -944287579, -1387457793 * this.field70.field9036);
      class593.field1623.method4986(var5[0], var5[1], var5[2], var5[3]);
   }

   public boolean method1544() {
      return !super.method1537(1700813633) ? false : this.field67.method3280(-1056757525 * ((class665)this.field70).field9595, -457216440);
   }

   void method63(boolean var1, int var2, int var3) {
      int var4 = this.method66(1200646093) * -944287579 * this.field70.field9032 / 10000;
      int[] var5 = new int[4];
      class593.field1623.method4830(var5);
      class593.field1623.method4986(var2, var3 + 2, var2 + var4, this.field70.field9036 * -1387457793 + var3);
      this.field4971.method3119(var2, 2 + var3, this.field70.field9032 * -944287579, -1387457793 * this.field70.field9036);
      class593.field1623.method4986(var5[0], var5[1], var5[2], var5[3]);
   }

   void method64(boolean var1, int var2, int var3) {
      int var4 = this.method66(1506402112) * -944287579 * this.field70.field9032 / 10000;
      int[] var5 = new int[4];
      class593.field1623.method4830(var5);
      class593.field1623.method4986(var2, var3 + 2, var2 + var4, this.field70.field9036 * -1387457793 + var3);
      this.field4971.method3119(var2, 2 + var3, this.field70.field9032 * -944287579, -1387457793 * this.field70.field9036);
      class593.field1623.method4986(var5[0], var5[1], var5[2], var5[3]);
   }

   void method58(boolean var1, int var2, int var3) {
      class593.field1623.method4838(var2 - 2, var3, this.field70.field9032 * -944287579 + 4, 2 + this.field70.field9036 * -1387457793, ((class665)this.field70).field9596 * 1514768717, 0);
      class593.field1623.method4838(var2 - 1, var3 + 1, this.field70.field9032 * -944287579 + 2, -1387457793 * this.field70.field9036, 0, 0);
   }

   public void method1540() {
      super.method1538(-1809113492);
      this.field4971 = class611.method5156(this.field67, ((class665)this.field70).field9595 * -1056757525, (byte)-90);
   }

   void method65(boolean var1, int var2, int var3) {
      class593.field1623.method4838(var2 - 2, var3, this.field70.field9032 * -944287579 + 4, 2 + this.field70.field9036 * -1387457793, ((class665)this.field70).field9596 * 1514768717, 0);
      class593.field1623.method4838(var2 - 1, var3 + 1, this.field70.field9032 * -944287579 + 2, -1387457793 * this.field70.field9036, 0, 0);
   }
}
