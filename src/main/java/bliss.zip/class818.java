public class class818 {
   static int field4611 = 0;
   static class180 field4612;
   static class180 field4613;
   static class272 field4614;
   static class752 field4615;
   static int field4616;
   static int field4617 = 1;
   static int field4618 = 2;
   static int field4619 = 3;
   static int field4620 = 0;
   static class180 field4621;
   static int field4622;
   static int field4623;
   static class180 field4624;
   static class272 field4625;

   class818() throws Throwable {
      throw new Error();
   }

   public static String method2900(long var0, int var2, int var3) {
      try {
         class411.method5593(var0);
         int var4 = class308.field416.get(5);
         int var5 = class308.field416.get(2);
         int var6 = class308.field416.get(1);
         return 3 == var2 ? class739.method1794(var0, var2, (short)-6140) : Integer.toString(var4 / 10) + var4 % 10 + "-" + class308.field417[var2][var5] + "-" + var6;
      } catch (RuntimeException var7) {
         throw class158.method3445(var7, "de.a(" + ')');
      }
   }

   static byte method2901(int var0, int var1, byte var2) {
      try {
         if (class15.field6903.field6921 != var0) {
            return 0;
         } else {
            return (byte)((var1 & 1) == 0 ? 1 : 2);
         }
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "de.by(" + ')');
      }
   }

   static final void method2902(class564 var0, class131 var1, class744 var2, int var3) {
      try {
         var0.field960 = var2.field3161[--var2.field3156];
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "de.jm(" + ')');
      }
   }

   public static final void method2903(class963 var0, int var1, byte var2) {
      try {
         class133.method996(var0, var1, true, 229741614);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "de.jj(" + ')');
      }
   }

   static final void method2904(class564 var0, class131 var1, class744 var2, int var3) {
      try {
         var2.field3156 -= 4;
         var0.field1003 = var2.field3161[var2.field3156];
         var0.field932 = var2.field3161[1 + var2.field3156];
         var0.field933 = var2.field3161[2 + var2.field3156];
         var0.field922 = var2.field3161[var2.field3156 + 3];
         class814.method2932(var0, -540239013);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "de.ex(" + ')');
      }
   }
}
