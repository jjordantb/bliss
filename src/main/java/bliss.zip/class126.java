public class class126 extends class347 {
   int[] method1551(int var1) {
      return class322.field838;
   }

   public class126() {
      super(0, true);
   }

   int[] method1552(int var1) {
      return class322.field838;
   }

   int[] method203(int var1, int var2) {
      try {
         return class322.field838;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "aha.i(" + ')');
      }
   }
}
