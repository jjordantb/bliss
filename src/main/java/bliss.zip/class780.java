public interface class780 extends class524 {
   int method2343();

   int method2344();

   int method2345();

   int method2346();

   int method2347();
}
