public interface class780 extends class524 {
   int method2343();

   int method2344();
}
