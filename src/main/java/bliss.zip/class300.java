public class class300 {
   int field3934;
   boolean field3935;
   int field3936;
   int field3937;
   short field3938;
   short field3939;
   short field3940;
   int field3941;
   int field3942;

   class300(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, boolean var10, boolean var11, int var12) {
      this.field3937 = var1;
      this.field3941 = var2;
      this.field3936 = var3;
      this.field3934 = var4;
      this.field3938 = (short)var5;
      this.field3939 = (short)var6;
      this.field3940 = (short)var7;
      this.field3935 = var11;
      this.field3942 = var12;
   }
}
