public class class771 extends class14 {
   public static class180 field3732;

   boolean method3598() {
      return this.method2299((short)10438) != null || this.field6690 * 8383148474145196457L < class27.method3468((byte)1) - 2000L;
   }

   boolean method3583(int var1) {
      try {
         return this.method2299((short)10071) != null || this.field6690 * 8383148474145196457L < class27.method3468((byte)1) - 2000L;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "adi.u(" + ')');
      }
   }

   class284 method2299(short var1) {
      try {
         return (class284)class730.field2808.method901(1766612795);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "adi.az(" + ')');
      }
   }

   class701 method3597(byte var1) {
      try {
         return class637.method5936(class643.field9932, class730.field2692.field7765, (byte)89);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "adi.x(" + ')');
      }
   }

   void method3581(class907 var1, class284 var2, byte var3) {
   }

   boolean method3588() {
      return this.method2299((short)-18072) != null || this.field6690 * 8383148474145196457L < class27.method3468((byte)1) - 2000L;
   }

   void method3585() {
      class284 var1 = this.method2299((short)7682);
      if (var1 != null) {
         int var2 = this.method3579(var1, 32767, (byte)48);
         int var3 = var1.method6680(-1340824693);
         if (var3 < 0) {
            var3 = 0;
         } else if (var3 > 65535) {
            var3 = 65535;
         }

         int var4 = var1.method6667((byte)-58);
         if (var4 < 0) {
            var4 = 0;
         } else if (var4 > 65535) {
            var4 = 65535;
         }

         byte var5 = 0;
         if (var1.method6666(-1372966703) == 2) {
            var5 = 1;
         }

         class701 var6 = class637.method5936(class643.field9945, class730.field2692.field7765, (byte)77);
         var6.field3364.method6364(var4 | var3 << 16, -1426845039);
         var6.field3364.method6419(var2 | var5 << 15);
         class730.field2692.method4380(var6, (byte)-38);
      }

   }

   void method3577() {
      class284 var1 = this.method2299((short)14253);
      if (var1 != null) {
         int var2 = this.method3579(var1, 32767, (byte)78);
         int var3 = var1.method6680(-964598213);
         if (var3 < 0) {
            var3 = 0;
         } else if (var3 > 65535) {
            var3 = 65535;
         }

         int var4 = var1.method6667((byte)26);
         if (var4 < 0) {
            var4 = 0;
         } else if (var4 > 65535) {
            var4 = 65535;
         }

         byte var5 = 0;
         if (var1.method6666(-1372966703) == 2) {
            var5 = 1;
         }

         class701 var6 = class637.method5936(class643.field9945, class730.field2692.field7765, (byte)71);
         var6.field3364.method6364(var4 | var3 << 16, -1629465959);
         var6.field3364.method6419(var2 | var5 << 15);
         class730.field2692.method4380(var6, (byte)-6);
      }

   }

   void method3576(class907 var1, class284 var2) {
   }

   boolean method3587() {
      return this.method2299((short)8384) != null || this.field6690 * 8383148474145196457L < class27.method3468((byte)1) - 2000L;
   }

   void method3582(byte var1) {
      try {
         class284 var2 = this.method2299((short)12232);
         if (var2 != null) {
            int var3 = this.method3579(var2, 32767, (byte)9);
            int var4 = var2.method6680(-1870529488);
            if (var4 < 0) {
               var4 = 0;
            } else if (var4 > 65535) {
               var4 = 65535;
            }

            int var5 = var2.method6667((byte)-26);
            if (var5 < 0) {
               var5 = 0;
            } else if (var5 > 65535) {
               var5 = 65535;
            }

            byte var6 = 0;
            if (var2.method6666(-1372966703) == 2) {
               var6 = 1;
            }

            class701 var7 = class637.method5936(class643.field9945, class730.field2692.field7765, (byte)8);
            var7.field3364.method6364(var5 | var4 << 16, 121434419);
            var7.field3364.method6419(var3 | var6 << 15);
            class730.field2692.method4380(var7, (byte)-44);
         }

      } catch (RuntimeException var8) {
         throw class158.method3445(var8, "adi.d(" + ')');
      }
   }

   int method3593() {
      return 0;
   }

   class701 method3589() {
      return class637.method5936(class643.field9932, class730.field2692.field7765, (byte)126);
   }

   class701 method3595() {
      return class637.method5936(class643.field9932, class730.field2692.field7765, (byte)67);
   }

   int method3599() {
      return 0;
   }

   int method3592() {
      return 0;
   }

   void method3591(class907 var1, class284 var2) {
   }

   void method3594(class907 var1, class284 var2) {
   }

   void method3596(class907 var1, class284 var2) {
   }

   void method3586() {
      class284 var1 = this.method2299((short)-5180);
      if (var1 != null) {
         int var2 = this.method3579(var1, 32767, (byte)103);
         int var3 = var1.method6680(-2028653571);
         if (var3 < 0) {
            var3 = 0;
         } else if (var3 > 65535) {
            var3 = 65535;
         }

         int var4 = var1.method6667((byte)-30);
         if (var4 < 0) {
            var4 = 0;
         } else if (var4 > 65535) {
            var4 = 65535;
         }

         byte var5 = 0;
         if (var1.method6666(-1372966703) == 2) {
            var5 = 1;
         }

         class701 var6 = class637.method5936(class643.field9945, class730.field2692.field7765, (byte)43);
         var6.field3364.method6364(var4 | var3 << 16, -611244662);
         var6.field3364.method6419(var2 | var5 << 15);
         class730.field2692.method4380(var6, (byte)-78);
      }

   }

   int method3580(int var1) {
      return 0;
   }

   public static void method2300(boolean var0, boolean var1, int var2) {
      try {
         if (var0) {
            class543.field3818 += 1929855733;
            class190.method3726(-1915881134);
         }

         if (var1) {
            class543.field3816 += -1931699395;
            class675.method4165((byte)1);
         }

      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "adi.a(" + ')');
      }
   }

   static final void method2301(class744 var0, byte var1) {
      try {
         var0.field3156 -= -783761378;
         class730.field2813 = var0.field3161[var0.field3156 * 681479919] * 443563833;
         class730.field2671 = var0.field3161[1 + var0.field3156 * 681479919] * -802224543;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "adi.afv(" + ')');
      }
   }
}
