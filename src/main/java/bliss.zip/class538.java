public class class538 {
   static class219 field3763;

   class538() throws Throwable {
      throw new Error();
   }

   static final void method2342(class744 var0, int var1) {
      try {
         var0.field3161[++var0.field3156 - 1] = var0.field3169.field9702;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "re.xf(" + ')');
      }
   }
}
