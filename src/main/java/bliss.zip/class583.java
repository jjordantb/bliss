public class class583 extends class568 {
   class319 field318;

   class583(class319 var1) {
      this.field318 = var1;
   }
}
