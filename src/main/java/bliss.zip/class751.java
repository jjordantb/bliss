public final class class751 extends class523 {
   void method2663() {
      this.field4364.method726();
      this.field4364.method594(this.field4365);
      this.field4364.method559(class344.field326, class344.field326, this.field4365);
      this.field4364.method616(0);
      this.field4364.method617(this.field4362);
      this.field4364.method555(0, class557.field496);
      this.field4364.method622(0, class557.field496);
      this.field4364.method555(1, class557.field498);
      this.field4364.method622(1, class557.field498);
      this.field4364.method624().method269(this.field4366);
      this.field4364.method625(class90.field550);
      this.field4364.method642(0, this.field4363);
      this.field4364.method714(this.field4369);
      this.field4364.method657(class427.field7385, this.field4368, 2);
   }

   public void method2762(int var1, int var2) {
      this.field4364.method619(var1);
      this.field4364.method673(var2);
   }

   public void method2767() {
      this.method2663();
   }

   public void method2772() {
      this.field4364.method616(1);
      this.field4364.method617(this.field4361);
      this.field4364.method624().method269(this.field4367);
      this.field4364.method625(class90.field550);
      this.field4364.method620(class584.field300, class584.field295);
      this.field4364.method555(0, class557.field495);
      this.method2663();
      this.field4364.method616(1);
      this.field4364.method618();
   }

   public class751(class325 var1) {
      super(var1);
   }

   public void method2771() {
      this.method2663();
   }

   public void method2765(int var1, int var2) {
      this.field4364.method619(var1);
      this.field4364.method673(var2);
   }

   public void method2766(int var1, int var2) {
      this.field4364.method619(var1);
      this.field4364.method673(var2);
   }

   public void method2768() {
      this.method2663();
   }

   public void method2769() {
      this.field4364.method616(1);
      this.field4364.method617(this.field4361);
      this.field4364.method624().method269(this.field4367);
      this.field4364.method625(class90.field550);
      this.field4364.method620(class584.field300, class584.field295);
      this.field4364.method555(0, class557.field495);
      this.method2663();
      this.field4364.method616(1);
      this.field4364.method618();
   }

   public void method2761() {
      this.method2663();
   }

   public void method2770() {
      this.field4364.method616(1);
      this.field4364.method617(this.field4361);
      this.field4364.method624().method269(this.field4367);
      this.field4364.method625(class90.field550);
      this.field4364.method620(class584.field300, class584.field295);
      this.field4364.method555(0, class557.field495);
      this.method2663();
      this.field4364.method616(1);
      this.field4364.method618();
   }

   public void method2763() {
      this.method2663();
   }

   public void method2773() {
      this.field4364.method616(1);
      this.field4364.method617(this.field4361);
      this.field4364.method624().method269(this.field4367);
      this.field4364.method625(class90.field550);
      this.field4364.method620(class584.field300, class584.field295);
      this.field4364.method555(0, class557.field495);
      this.method2663();
      this.field4364.method616(1);
      this.field4364.method618();
   }

   public void method2764() {
      this.field4364.method616(1);
      this.field4364.method617(this.field4361);
      this.field4364.method624().method269(this.field4367);
      this.field4364.method625(class90.field550);
      this.field4364.method620(class584.field300, class584.field295);
      this.field4364.method555(0, class557.field495);
      this.method2663();
      this.field4364.method616(1);
      this.field4364.method618();
   }

   public void method2774() {
      this.field4364.method616(1);
      this.field4364.method617(this.field4361);
      this.field4364.method624().method269(this.field4367);
      this.field4364.method625(class90.field550);
      this.field4364.method620(class584.field300, class584.field295);
      this.field4364.method555(0, class557.field495);
      this.method2663();
      this.field4364.method616(1);
      this.field4364.method618();
   }
}
