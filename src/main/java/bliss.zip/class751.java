public final class class751 extends class523 {
   void method2663() {
      super.field4364.method726();
      super.field4364.method594(super.field4365);
      super.field4364.method559(class344.field326, class344.field326, super.field4365);
      super.field4364.method616(0);
      super.field4364.method617(super.field4362);
      super.field4364.method555(0, class557.field496);
      super.field4364.method622(0, class557.field496);
      super.field4364.method555(1, class557.field498);
      super.field4364.method622(1, class557.field498);
      super.field4364.method624().method269(super.field4366);
      super.field4364.method625(class90.field550);
      super.field4364.method642(0, super.field4363);
      super.field4364.method714(super.field4369);
      super.field4364.method657(class427.field7385, super.field4368, 2);
   }

   public void method2762(int var1, int var2) {
      super.field4364.method619(var1);
      super.field4364.method673(var2);
   }

   public class751(class325 var1) {
      super(var1);
   }

   public void method2763() {
      this.method2663();
   }

   public void method2764() {
      super.field4364.method616(1);
      super.field4364.method617(super.field4361);
      super.field4364.method624().method269(super.field4367);
      super.field4364.method625(class90.field550);
      super.field4364.method620(class584.field300, class584.field295);
      super.field4364.method555(0, class557.field495);
      this.method2663();
      super.field4364.method616(1);
      super.field4364.method618();
   }
}
