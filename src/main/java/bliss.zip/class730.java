import jaclib.ping.Ping;
import java.awt.Color;
import java.awt.Container;
import java.awt.Frame;
import java.awt.Insets;
import java.awt.Rectangle;
import java.io.IOException;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Random;
import java.util.TimeZone;
import java.util.Vector;

public final class class730 extends class69 {
   static int field2615 = -771751936;
   public static boolean field2616 = false;
   static int field2617 = 256;
   static boolean field2618 = false;
   static ArrayList field2619 = new ArrayList();
   static boolean field2620 = false;
   public static boolean field2621;
   static int[] field2622;
   public static int field2623;
   public static boolean field2624 = false;
   static int field2625;
   public static long field2626 = 0L;
   public static boolean field2627 = false;
   public static boolean field2628 = false;
   static String field2629 = null;
   public static String field2630 = null;
   public static class616 field2631;
   public static boolean field2632 = false;
   public static class564 field2633;
   static boolean field2634 = false;
   static int field2635 = 431443955;
   static String field2636 = null;
   public static String field2637 = null;
   static class625[] field2638;
   static class344 field2639 = new class344();
   static int field2640;
   static class373 field2641;
   public static Object field2642;
   public static boolean field2643 = false;
   static boolean field2644 = true;
   public static int field2645;
   public static int field2646 = 0;
   public static boolean field2647 = true;
   static boolean field2648 = false;
   static boolean field2649 = false;
   public static int field2650 = -1;
   static int[] field2651;
   public static class669[] field2652 = new class669[9];
   public static boolean field2653 = false;
   static boolean field2654 = false;
   static boolean field2655 = true;
   static long field2656 = (long)(Math.random() * 9.999999999E9D) * -2884790245004171741L;
   public static boolean field2657 = false;
   public static int field2658 = 0;
   static int field2659 = 31;
   public static class684[] field2660;
   public static boolean field2661 = false;
   public static int field2662;
   static int field2663 = 0;
   static int field2664 = 128;
   static boolean[] field2665;
   public static class6 field2666;
   static int field2667;
   public static int field2668 = 0;
   public static class742[] field2669 = new class742[79];
   public static Color[] field2670 = new Color[]{new Color(9179409), new Color(3289650), new Color(3289650), new Color(3289650)};
   public static int field2671;
   public static Color[] field2672 = new Color[]{new Color(16777215), new Color(16777215), new Color(16741381), new Color(16741381)};
   static int field2673 = 0;
   public static class684 field2674 = new class684();
   static int field2675 = 0;
   static int field2676 = 13828096;
   public static class6 field2677 = new class6(64);
   static class1 field2678 = new class1(8);
   static String field2679 = null;
   public static int[] field2680 = new int[1024];
   public static class768 field2681 = new class141();
   public static Color[] field2682 = new Color[]{new Color(9179409), new Color(16777215), new Color(16726277), new Color(16726277)};
   static Random field2683;
   public static int field2684 = 0;
   public static String[] field2685;
   public static int[] field2686;
   static int[] field2687 = new int[258];
   static int field2688 = 0;
   static int field2689 = 0;
   static int[] field2690 = new int[1012];
   public static class742[] field2691 = new class742[128];
   public static class684 field2692 = new class684();
   static class564 field2693;
   static int field2694;
   static boolean field2695;
   public static class405 field2696;
   public static class623 field2697;
   public static volatile boolean field2698;
   public static Object field2699;
   static int field2700 = 1375731712;
   public static int field2701;
   public static int field2702;
   public static boolean[] field2703;
   static int field2704 = 0;
   public static int field2705;
   public static boolean field2706;
   static int field2707;
   static int field2708;
   public static int field2709;
   static int field2710 = 5;
   static int field2711 = 1179648;
   public static int field2712;
   public static int field2713;
   static int field2714 = -1828716544;
   static int field2715;
   static int[] field2716;
   public static boolean field2717;
   public static int field2718;
   static int[] field2719;
   public static int[] field2720;
   public static int field2721 = 2048;
   static int field2722;
   static int field2723;
   public static short field2724;
   static int field2725;
   static int field2726;
   static int field2727;
   static int field2728;
   static int field2729;
   static int field2730;
   static int[] field2731;
   public static int[] field2732;
   public static int field2733 = 121508348;
   public static int field2734;
   public static String field2735;
   public static int field2736;
   static int field2737;
   public static float field2738;
   static Calendar field2739;
   static float field2740;
   static float field2741;
   static boolean field2742;
   static boolean field2743;
   public static boolean field2744;
   static int field2745;
   public static int field2746 = 2;
   static int field2747 = 65535;
   public static int[][][] field2748;
   public static int field2749;
   public static int field2750;
   public static int field2751;
   public static int field2752;
   public static int field2753 = 0;
   static String[] field2754;
   public static int field2755;
   static boolean field2756;
   static boolean field2757;
   public static int field2758;
   public static boolean field2759;
   static int[] field2760;
   static class1 field2761 = new class1(4);
   static class616 field2762;
   static long field2763 = 0L;
   static int field2764;
   static int field2765;
   static int field2766;
   static int field2767;
   static int[] field2768;
   static int field2769;
   static int field2770 = 2;
   static int[] field2771;
   static int field2772 = 1;
   static int field2773;
   static int[] field2774;
   public static int field2775;
   static int[] field2776;
   static int field2777;
   static int[] field2778;
   static long field2779;
   static boolean field2780;
   static int field2781;
   static int field2782;
   public static boolean field2783;
   public static int field2784;
   public static String field2785;
   public static class946[] field2786;
   public static boolean field2787 = false;
   public static boolean field2788;
   static int field2789 = 0;
   public static int field2790;
   static int field2791;
   public static boolean field2792;
   public static boolean field2793;
   static boolean field2794;
   public static int field2795 = 0;
   static boolean field2796;
   public static class437[] field2797 = new class437[1024];
   static int field2798;
   static short[] field2799;
   public static class564 field2800;
   static String[] field2801;
   static boolean[] field2802;
   static int field2803;
   static int[] field2804;
   public static class373 field2805;
   public static class6 field2806;
   static int field2807;
   public static class373 field2808 = new class373();
   public static int[] field2809;
   public static int[] field2810;
   public static int[] field2811;
   static int field2812;
   public static int field2813;
   static int field2814;
   static int[] field2815;
   public static int field2816;
   public static boolean field2817;
   static int field2818;
   public static int field2819;
   public static String field2820;
   public static short field2821;
   public static volatile int field2822;
   public static class6 field2823;
   static int field2824;
   public static byte[] field2825 = null;
   public static int field2826;
   public static int field2827;
   static boolean field2828;
   static int[] field2829;
   static int field2830 = 0;
   static boolean field2831;
   static class564 field2832;
   static int[] field2833;
   public static int field2834;
   static int field2835;
   static class564 field2836;
   static boolean field2837;
   static int field2838;
   public static int field2839;
   static int field2840;
   public static String[] field2841;
   static int[] field2842;
   static int field2843;
   static int field2844;
   static boolean field2845;
   static int field2846;
   static boolean field2847;
   static boolean field2848;
   public static boolean field2849 = false;
   static int field2850 = 79;
   public static class921[] field2851 = new class921[8];
   public static int field2852;
   static class135 field2853 = new class135();
   static int field2854 = 9633792;
   static int field2855;
   static int[] field2856;
   static int field2857;
   static int[] field2858;
   static int field2859;
   static int field2860;
   static int field2861;
   static int[] field2862;
   static int field2863;
   public static int field2864;
   static int field2865;
   public static int field2866 = 0;
   static int field2867;
   static int field2868;
   static int field2869 = 0;
   static int field2870;
   public static int field2871 = 1;
   public static int field2872;
   public static float[] field2873;
   static long field2874;
   public static class373 field2875;
   public static int field2876 = 0;
   static class373 field2877;
   static class6 field2878;
   public static int field2879 = 113;
   static class1 field2880 = new class1(4);
   static int[] field2881;
   public static boolean[] field2882;
   static boolean[] field2883;
   static Rectangle[] field2884;
   static int field2885;
   static int[] field2886;
   static int field2887;
   static int field2888;
   static int[] field2889;
   static int[] field2890;
   static int[] field2891;
   static int field2892;
   static int[] field2893;
   static int field2894;
   public static int field2895;
   static int field2896 = 100;
   static long[] field2897;
   static int field2898;
   static boolean field2899;
   static int[] field2900;
   public static String field2901;
   public static class285[] field2902;
   static int field2903;
   static boolean field2904;
   public static short field2905;
   public static int[] field2906;
   static int[] field2907;
   static int[] field2908;
   static String field2909 = null;
   public static short field2910;
   public static short field2911;
   static int field2912;
   public static short field2913;
   public static int field2914;
   public static int field2915;
   public static short field2916;
   public static short field2917;
   static int field2918;
   static int field2919;
   static boolean field2920;
   public static int field2921;
   static int field2922;
   public static int field2923;
   public static int field2924;
   static int field2925 = 4095;
   public static class469 field2926 = null;
   public static String[] field2927;
   public static int[] field2928;
   public static String[] field2929;
   static int field2930 = 32;
   public static float field2931;
   public static boolean[] field2932;
   static class616 field2933;
   public static int field2934;
   static int field2935 = 200;
   public static String[] field2936;
   public static String[] field2937;
   static int field2938;
   public static boolean[] field2939;
   static boolean field2940 = false;
   public static byte field2941;
   public static class832 field2942;
   static int field2943;
   static int field2944 = 5373952;
   static int field2945 = 9568256;
   static int field2946 = 13762560;
   static int field2947 = 301989888;
   static int field2948;
   static int field2949 = -1845493760;
   static class135 field2950 = new class135();
   static int field2951 = 1245184;
   static int field2952 = 5439488;
   public static int field2953 = 0;
   static int field2954;
   static int field2955 = 318767104;
   static int field2956 = 1392508928;
   static int field2957 = 8;
   static int field2958 = -754974720;
   static int[] field2959;

   static {
      field2660 = new class684[]{field2692, field2674};
      field2694 = 0;
      field2695 = false;
      field2696 = new class405();
      field2697 = new class623(false);
      field2698 = false;
      field2699 = new Object();
      field2642 = new Object();
      field2732 = new int[64];
      field2702 = 0;
      field2720 = new int[]{0, 0, 0, 0, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3};
      field2852 = -221729505;
      field2705 = -1334571751;
      field2706 = false;
      field2707 = 733205975;
      field2912 = 0;
      field2709 = 652594363;
      field2718 = -60133325;
      field2662 = 1875737127;
      field2712 = 0;
      field2713 = 0;
      field2701 = 0;
      field2716 = new int[4096];
      field2829 = new int[4096];
      field2731 = new int[50];
      field2719 = new int[50];
      field2900 = new int[]{-1, 8192, 0, -1, 12288, 10240, 14336, -1, 4096, 6144, 2048};
      field2798 = 0;
      field2722 = -57270710;
      field2723 = 0;
      field2807 = -792852734;
      field2725 = 0;
      field2726 = 901405925;
      field2727 = 0;
      field2782 = 0;
      field2860 = -640741266;
      field2730 = 0;
      field2954 = 999313729;
      field2791 = 0;
      field2683 = new Random();
      field2943 = 0;
      field2734 = 0;
      field2736 = 0;
      field2738 = 1044.0F;
      field2931 = 0.0F;
      field2740 = 0.0F;
      field2741 = 0.0F;
      field2742 = false;
      field2743 = false;
      field2744 = true;
      field2745 = 0;
      field2748 = new int[2][][];
      field2749 = -1723181617;
      field2750 = 2694169;
      field2751 = 0;
      field2752 = 0;
      field2839 = 0;
      field2834 = 0;
      field2755 = 0;
      field2756 = false;
      field2757 = false;
      field2758 = 0;
      field2833 = new int[511];
      field2760 = new int[513];
      field2640 = 0;
      field2762 = new class616();
      field2885 = 0;
      field2873 = new float[3];
      field2765 = 0;
      field2766 = 0;
      field2767 = 0;
      field2729 = 0;
      field2769 = 0;
      field2773 = 1225211529;
      field2774 = new int[2];
      field2651 = new int[2];
      field2776 = new int[2];
      field2622 = new int[2];
      field2778 = new int[2];
      field2779 = 0L;
      field2780 = true;
      field2708 = 421892320;
      field2892 = -1413813424;
      field2775 = 1384393775;
      field2784 = -1146614829;
      field2786 = new class946[2048];
      field2623 = -1448461709;
      field2788 = false;
      field2759 = false;
      field2790 = 0;
      field2914 = 0;
      field2792 = false;
      field2793 = false;
      field2794 = false;
      field2621 = false;
      field2796 = true;
      field2783 = false;
      field2799 = new short[]{44, 45, 46, 47, 48, 49, 50, 51};
      field2886 = new int[8];
      field2801 = new String[8];
      field2802 = new boolean[8];
      field2803 = -812630591;
      field2666 = new class6(64);
      field2805 = new class373();
      field2806 = new class6(16);
      field2631 = new class616();
      field2906 = new int[25];
      field2809 = new int[25];
      field2810 = new int[25];
      field2811 = new int[25];
      field2812 = 0;
      field2813 = -443563833;
      field2919 = 280458557;
      field2671 = 802224543;
      field2816 = 766301529;
      field2817 = false;
      field2818 = -1598367905;
      field2888 = -398138063;
      field2820 = null;
      field2735 = null;
      field2822 = -1785861201;
      field2823 = new class6(8);
      field2824 = 0;
      field2633 = null;
      field2826 = 0;
      field2827 = 0;
      field2828 = false;
      field2904 = false;
      field2800 = null;
      field2831 = false;
      field2832 = null;
      field2693 = null;
      field2715 = 0;
      field2835 = 0;
      field2836 = null;
      field2837 = false;
      field2838 = -1246614319;
      field2781 = 429639553;
      field2840 = -1523738763;
      field2948 = 706199093;
      field2920 = false;
      field2843 = 1501079155;
      field2844 = 1873720993;
      field2845 = false;
      field2846 = 0;
      field2847 = false;
      field2848 = false;
      field2915 = -908761385;
      field2856 = new int[32];
      field2764 = 0;
      field2804 = new int[32];
      field2855 = 0;
      field2815 = new int[32];
      field2857 = 0;
      field2858 = new int[32];
      field2859 = 0;
      field2768 = new int[32];
      field2861 = 0;
      field2862 = new int[32];
      field2863 = 0;
      field2864 = 0;
      field2865 = 0;
      field2894 = 0;
      field2867 = 0;
      field2868 = 0;
      field2777 = 0;
      field2870 = 0;
      field2872 = 0;
      field2717 = false;
      field2874 = -5732957771927789473L;
      field2875 = new class373();
      field2641 = new class373();
      field2877 = new class373();
      field2878 = new class6(512);
      field2667 = 0;
      field2814 = 870349622;
      field2882 = new boolean[113];
      field2883 = new boolean[113];
      field2884 = new Rectangle[113];

      for(int var0 = 0; var0 < 113; ++var0) {
         field2884[var0] = new Rectangle();
      }

      field2938 = 0;
      field2881 = new int[4];
      field2887 = 0;
      field2625 = -2022928202;
      field2889 = new int[field2625 * 547709851];
      field2890 = new int[547709851 * field2625];
      field2891 = new int[547709851 * field2625];
      field2638 = new class625[field2625 * 547709851];
      field2893 = new int[]{16776960, 16711680, 65280, 65535, 16711935, 16777215};
      field2819 = 0;
      field2895 = 0;
      field2897 = new long[100];
      field2898 = 0;
      field2899 = false;
      field2785 = null;
      field2901 = null;
      field2902 = new class285[6];
      field2903 = 0;
      field2665 = new boolean[5];
      field2842 = new int[5];
      field2907 = new int[5];
      field2908 = new int[5];
      field2771 = new int[5];
      field2910 = 256;
      field2911 = 205;
      field2905 = 256;
      field2913 = 320;
      field2821 = 1;
      field2724 = 32767;
      field2916 = 1;
      field2917 = 32767;
      field2918 = 0;
      field2728 = 0;
      field2645 = 0;
      field2921 = 0;
      field2922 = 0;
      field2923 = 0;
      field2924 = 0;
      field2685 = new String[200];
      field2927 = new String[200];
      field2928 = new int[200];
      field2929 = new String[200];
      field2686 = new int[200];
      field2703 = new boolean[200];
      field2932 = new boolean[200];
      field2933 = new class616();
      field2934 = 0;
      field2841 = new String[100];
      field2936 = new String[100];
      field2937 = new String[100];
      field2754 = new String[100];
      field2939 = new boolean[100];
      field2739 = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
      field2941 = -6;
      field2942 = new class317();
      field2959 = new int[4];
   }

   public final void method3941() {
      try {
         if (this.method1308(1161676873)) {
            class440[] var1 = class335.method38(2020193893);

            for(int var2 = 0; var2 < var1.length; ++var2) {
               class440 var3 = var1[var2];
               String var4 = class833.field9178.getParameter(var3.field7683);
               if (var4 != null) {
                  switch(Integer.parseInt(var3.field7683)) {
                  case 1:
                     field2646 = Integer.parseInt(var4) * 708949575;
                     break;
                  case 2:
                     field2629 = var4;
                     if (field2629.length() > 100) {
                        field2629 = null;
                     }
                     break;
                  case 3:
                     field2636 = var4;
                     break;
                  case 4:
                     if (class569.field24 == null) {
                        class569.field24 = new class764();
                     }

                     class569.field24.field4347 = Integer.parseInt(var4) * 348739329;
                     break;
                  case 5:
                     class507.field4016 = Integer.parseInt(var4) * -339928991;
                     break;
                  case 6:
                     class419.field9520 = class408.method5469(Integer.parseInt(var4), (byte)-115);
                     if (class419.field9520 != class408.field9221 && class419.field9520 != class408.field9218 && class408.field9219 != class419.field9520 && class419.field9520 != class408.field9220) {
                        class419.field9520 = class408.field9220;
                     }
                     break;
                  case 7:
                     class51.field2310 = var4;
                  case 8:
                  case 14:
                     break;
                  case 9:
                     class221.field7347 = Integer.parseInt(var4) * -2071496301;
                     break;
                  case 10:
                     field2637 = var4;
                     break;
                  case 11:
                     if (var4.equalsIgnoreCase(class822.field9052)) {
                        field2616 = true;
                     } else {
                        field2616 = false;
                     }
                     break;
                  case 12:
                     if (var4.equalsIgnoreCase(class822.field9052)) {
                        field2632 = true;
                     } else {
                        field2632 = false;
                     }
                     break;
                  case 13:
                     class721.field3634 = (class916)class367.method1565(class916.method6460(-1240424446), Integer.parseInt(var4), (byte)2);
                     if (class916.field10410 == class721.field3634) {
                        class721.field3634 = class916.field10418;
                     } else if (!class916.method6456(class721.field3634, 2072733929) && class721.field3634 != class916.field10415) {
                        class721.field3634 = class916.field10415;
                     }
                     break;
                  case 15:
                     field2909 = var4;
                     break;
                  case 16:
                     if (var4.equals(class822.field9052)) {
                        field2661 = true;
                     } else {
                        field2661 = false;
                     }
                     break;
                  case 17:
                     if (var4.equalsIgnoreCase(class822.field9052)) {
                        field2940 = true;
                     } else {
                        field2940 = false;
                     }
                     break;
                  case 18:
                     if (var4.equalsIgnoreCase(class822.field9052)) {
                        field2788 = true;
                     }
                     break;
                  case 19:
                  default:
                     class764.method2747("", new RuntimeException(), (short)-10320);
                     break;
                  case 20:
                     if (class569.field24 == null) {
                        class569.field24 = new class764();
                     }

                     class569.field24.field4343 = var4;
                     break;
                  case 21:
                     class601.field9200 = new class764();
                     class601.field9200.field4347 = Integer.parseInt(var4) * 348739329;
                     break;
                  case 22:
                     if (var4.equalsIgnoreCase(class822.field9052)) {
                        field2620 = true;
                     } else {
                        field2620 = false;
                     }
                     break;
                  case 23:
                     if (var4.equals(class822.field9052)) {
                        field2624 = true;
                     } else {
                        field2624 = false;
                     }
                     break;
                  case 24:
                     field2630 = var4;
                     break;
                  case 25:
                     field2635 = Integer.parseInt(var4) * -431443955;
                     break;
                  case 26:
                     field2926 = class718.method2070(Integer.parseInt(var4), (byte)119);
                     break;
                  case 27:
                     class321.field1066 = class423.method5706(Integer.parseInt(var4), 615406105);
                     break;
                  case 28:
                     field2953 = Integer.parseInt(var4) * 131907935;
                     if (745003679 * field2953 < 0 || 745003679 * field2953 >= field2670.length) {
                        field2953 = 0;
                     }
                     break;
                  case 29:
                     if (var4 != null) {
                        field2825 = class554.method426(class167.method3699(var4, -1122576135), (byte)59);
                        if (field2825.length < 16) {
                           field2825 = null;
                        }
                     }
                     break;
                  case 30:
                     if (var4.equalsIgnoreCase(class822.field9052)) {
                        field2634 = true;
                     } else {
                        field2634 = false;
                     }
                     break;
                  case 31:
                     if (var4.equalsIgnoreCase(class822.field9052)) {
                        field2849 = true;
                     } else {
                        field2849 = false;
                     }
                     break;
                  case 32:
                     field2626 = Long.parseLong(var4) * -4477728998236397853L;
                     break;
                  case 33:
                     class143.field1540 = var4;
                  }
               }
            }

            if (field2909 == null) {
               field2909 = "";
            }

            class716 var6 = new class716(775068819 * field2775, -791746413 * field2784, 351263031 * field2708, field2892 * -510898275, field2926.field7326);
            class5.field4944 = this;
            this.method1301(var6, field2926.field7321, class419.field9520.field9223, 32 + 1286017487 * class419.field9520.field9224, class679.method4268(-369062280), 718, 1, field2634, (byte)23);
         }

      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "client.init(" + ')');
      }
   }

   final void method1313(byte var1) {
      try {
         Frame var2 = new Frame(" ");
         var2.pack();
         var2.dispose();
         class263.field8132 = new class564();
         class791.method398((byte)-66);
         class732.field2980 = new class213();
         class794.field541 = new class81();
         int[] var3 = new int[]{20, 260};
         int[] var4 = new int[]{1000, 100};
         if (var3 != null && var4 != null) {
            class128.field2348 = var3;
            class18.field6930 = new int[var3.length];
            class681.field7538 = new byte[var3.length][][];

            for(int var5 = 0; var5 < class128.field2348.length; ++var5) {
               class681.field7538[var5] = new byte[var4[var5]][];
            }
         } else {
            class128.field2348 = null;
            class18.field6930 = null;
            class681.field7538 = null;
         }

         class32.method3302(100);
         class567.method793(10);
         class725.method1745(100, 906973812);
         class673.method4262(100, 1489616392);
         if (class916.field10415 != class721.field3634) {
            class138.field1171 = new byte[50][];
         }

         class615.field8903 = class455.method3817(815058743);
         if (class615.field8903.field9146.method3999((byte)-54) == 1) {
            class545.field3885 = false;
         }

         if (class916.field10415 == class721.field3634) {
            class601.field9200.field4343 = class833.field9178.getCodeBase().getHost();
         } else if (class916.method6456(class721.field3634, 2144783357)) {
            class601.field9200.field4343 = class833.field9178.getCodeBase().getHost();
            class601.field9200.field4344 = 815680320 + class601.field9200.field4347 * -1670427267;
            class569.field24.field4344 = 815680320 + class569.field24.field4347 * -1670427267;
            class601.field9200.field4345 = -52655920 + class601.field9200.field4347 * 925746937;
            class569.field24.field4345 = class569.field24.field4347 * 925746937 + -52655920;
         } else if (class721.field3634 == class916.field10410) {
            class601.field9200.field4343 = class822.field9051;
            class569.field24.field4343 = class822.field9051;
            class601.field9200.field4344 = 815680320 + class601.field9200.field4347 * -1670427267;
            class569.field24.field4344 = -1670427267 * class569.field24.field4347 + 815680320;
            class601.field9200.field4345 = -52655920 + class601.field9200.field4347 * 925746937;
            class569.field24.field4345 = -52655920 + class569.field24.field4347 * 925746937;
         }

         class601.field9203 = class601.field9200;
         if (field2926 == class469.field7324) {
            field2655 = false;
         }

         class503.field4103 = class50.field2255 = class401.field9918 = class518.field4275 = new short[256];

         try {
            class397.field6496 = class348.method193((byte)72).getToolkit().getSystemClipboard();
         } catch (Exception var6) {
            ;
         }

         class381.field1417 = class134.method1035(class837.field9161, 906112381);
         class912.field10424 = class69.method1335(class837.field9161, true, (short)391);
         if (class916.field10415 != class721.field3634) {
            field2648 = true;
         }

         field1825 = class814.field4748.method2927(class321.field1066, -875414210);
         class625.field9752 = new class794();
         (new Thread(class625.field9752)).start();
      } catch (RuntimeException var7) {
         throw class158.method3445(var7, "client.ak(" + ')');
      }
   }

   final void method1323(byte var1) {
      try {
         if (class615.field8903.field9137.method3689(-497578575) == 2) {
            try {
               this.method1766((byte)0);
            } catch (ThreadDeath var3) {
               throw var3;
            } catch (Throwable var4) {
               class764.method2747(var4.getMessage() + " " + this.method1311((byte)53), var4, (short)-28836);
               field2643 = true;
               class337.method77(0, false, 622850291);
            }
         } else {
            this.method1766((byte)0);
         }

      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "client.ae(" + ')');
      }
   }

   final void method1324(int var1) {
      try {
         if (class615.field8903.field9137.method3689(-1358011800) == 2) {
            try {
               this.method1752((byte)0);
            } catch (ThreadDeath var3) {
               throw var3;
            } catch (Throwable var4) {
               class764.method2747(var4.getMessage() + " " + this.method1311((byte)17), var4, (short)1591);
               field2643 = true;
               class337.method77(0, false, 622850291);
            }
         } else {
            this.method1752((byte)0);
         }

      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "client.ao(" + ')');
      }
   }

   void method1752(byte var1) {
      try {
         if (-1233866115 * field2733 != 10) {
            long var2 = class263.method4516((byte)12) / 1000000L - 2783675710070397783L * field2763;
            field2763 = class263.method4516((byte)-35) / 1000000L * -1871756826282688409L;
            boolean var4 = class874.method5858(1477772934);
            if (var4 && class540.field3921 && class540.field3925 != null) {
               class540.field3925.method2635(-1023851530);
            }

            if (class888.method5532(-1233866115 * field2733, 476312339)) {
               if (0L != field2779 * -7612703297707729209L && class27.method3468((byte)1) > -7612703297707729209L * field2779) {
                  class739.method1795(class660.method5750((byte)-69), -1, -1, false, 243122933);
               } else if (!class593.field1623.method4908() && field1818) {
                  class192.method3742(-444434121);
               }
            }

            int var6;
            if (class296.field10468 == null) {
               Container var5 = class348.method193((byte)74);
               var6 = var5.getSize().width;
               int var7 = var5.getSize().height;
               if (var5 == class701.field3371) {
                  Insets var8 = class701.field3371.getInsets();
                  var6 -= var8.right + var8.left;
                  var7 -= var8.bottom + var8.top;
               }

               if (class919.field10433 * -639974669 != var6 || var7 != 1282634425 * field1812 || field2657) {
                  if (class593.field1623 != null && !class593.field1623.method4804()) {
                     class919.field10433 = var6 * 1325868603;
                     field1812 = var7 * -2115832951;
                  } else {
                     class791.method398((byte)-98);
                  }

                  field2779 = (class27.method3468((byte)1) + 500L) * -1373096961092238601L;
                  field2657 = false;
               }
            }

            if (class53.field2311 && class296.field10468 != null && !class619.field8869 && class888.method5532(-1233866115 * field2733, 476312339)) {
               class739.method1795(class615.field8903.field9109.method6159((byte)34), -1, -1, false, 1694372474);
            }

            boolean var12 = false;
            if (field1811) {
               field1811 = false;
               var12 = true;
            }

            if (var12) {
               class646.method5504((byte)-3);
            }

            if (class593.field1623 != null && class593.field1623.method4908() || class660.method5750((byte)-122) != 1) {
               class881.method6172(-1789306490);
            }

            if (class622.method5340(-1233866115 * field2733, -1448819665)) {
               class309.method361(var12, 430993133);
            } else if (class635.method5923(-1233866115 * field2733, 520913281)) {
               class385.method1181(447944821);
            } else if (class333.method112(field2733 * -1233866115, 279703369)) {
               class385.method1181(447944821);
            } else if (class399.method3529(field2733 * -1233866115, 361133550)) {
               if (field2697.method5269((byte)103) == class529.field3654) {
                  var6 = field2697.method5304(-471108411) / 2;
                  class971.method1789(class814.field4748.method2927(class321.field1066, -875414210) + class822.field9047 + "(" + var6 + "%)", true, class593.field1623, class958.field3479, class378.field1158, (byte)20);
               } else if (field2697.method5269((byte)65) == class529.field3652) {
                  var6 = 50 + field2697.method5312((byte)-20) / 2;
                  class971.method1789(class814.field4748.method2927(class321.field1066, -875414210) + class822.field9047 + "(" + var6 + "%)", true, class593.field1623, class958.field3479, class378.field1158, (byte)38);
               } else {
                  class971.method1789(class814.field4748.method2927(class321.field1066, -875414210), true, class593.field1623, class958.field3479, class378.field1158, (byte)64);
               }
            } else if (-1233866115 * field2733 == 0) {
               class398.method3540(var2);
            } else if (5 == -1233866115 * field2733) {
               class971.method1789(class814.field4750.method2927(class321.field1066, -875414210) + class822.field9047 + class814.field4668.method2927(class321.field1066, -875414210), false, class593.field1623, class958.field3479, class378.field1158, (byte)-78);
            } else if (-1233866115 * field2733 == 13) {
               class971.method1789(class814.field4662.method2927(class321.field1066, -875414210), false, class593.field1623, class958.field3479, class378.field1158, (byte)-34);
            }

            if (field2938 * 2067224717 == 3) {
               for(var6 = 0; var6 < -112139815 * field2667; ++var6) {
                  Rectangle var13 = field2884[var6];
                  if (field2883[var6]) {
                     class593.field1623.method4832(var13.x, var13.y, var13.width, var13.height, -65281, -1154135078);
                  } else {
                     class593.field1623.method4832(var13.x, var13.y, var13.width, var13.height, -16711936, -2005947871);
                  }
               }
            }

            if (class371.method868(-268540899)) {
               class368.method1557(class593.field1623, (byte)127);
            }

            if (!class622.method5340(field2733 * -1233866115, 797947023) && !class399.method3529(-1233866115 * field2733, 1114719498) && -1 != field2822 * -257444687) {
               try {
                  class593.field1623.method4796((byte)-94);
               } catch (class937 var10) {
                  class764.method2747(var10.getMessage() + " " + this.method1311((byte)3), var10, (short)-15479);
                  class337.method77(0, false, 622850291);
               }
            }

            class99.method538(-1025699241);
            var6 = class615.field8903.field9143.method3017((byte)1);
            if (var6 == 0) {
               class764.method2745(15L);
            } else if (var6 == 1) {
               class764.method2745(10L);
            } else if (2 == var6) {
               class764.method2745(5L);
            } else if (3 == var6) {
               class764.method2745(2L);
            }

            if (field2653) {
               class616.method5218(1638092472);
            }

            if (class615.field8903.field9145.method2311((byte)-31) == 1 && 19 == -1233866115 * field2733 && -257444687 * field2822 != -1) {
               class615.field8903.method5391(class615.field8903.field9145, 0, 1020440405);
               class95.method523(656179282);
            }
         }

      } catch (RuntimeException var11) {
         throw class158.method3445(var11, "client.fy(" + ')');
      }
   }

   final void method1315(int var1) {
      try {
         if (field2717) {
            class749.method2525(1472564076);
         }

         class47.method3085(-1772893156);
         if (class593.field1623 != null) {
            class593.field1623.method4996(1233420487);
         }

         if (class53.field2311 && class296.field10468 != null) {
            class386.method1167(class382.field1409, class296.field10468, -784023783);
            class296.field10468 = null;
         }

         field2692.method4374((byte)68);
         field2692.field7775.method935(-2007013994);
         field2674.method4374((byte)31);
         field2674.field7775.method935(-1769039718);
         class317.method472(1722973256);
         class794.field541.method233((byte)-87);
         class732.field2980.method3808(-1838301690);
         if (field2696 != null) {
            field2696.method5474(876164724);
            field2696 = null;
         }

         try {
            Ping.quit();
         } catch (Throwable var4) {
            ;
         }

         class153.method3392(875496962);

         try {
            class408.method5471((byte)-128);
         } catch (Exception var3) {
            ;
         }

         if (field1820) {
            class118.method1462(-849889720);
         }

      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "client.ad(" + ')');
      }
   }

   void method1753(int var1) {
      try {
         boolean var2 = class794.field541.method238(-358267640);
         if (!var2) {
            this.method1770(1084635084);
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "client.ft(" + ')');
      }
   }

   void method1754(int var1, int var2) {
      try {
         class371.field1089 = null;
         class397.field6495 = null;
         field2673 = 0;
         class794.field541.field304 += 686188557;
         class794.field541.field314 = var1 * -1293857183;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "client.fl(" + ')');
      }
   }

   static final void method1755() {
      int var0 = 1168366243 * class498.field8102;
      int[] var1 = class498.field8108;
      int var2 = class615.field8903.field9135.method5225((byte)-15);
      boolean var3 = var2 == 1 && var0 > 200 || var2 == 0 && var0 > 50;

      int var4;
      int var6;
      for(var4 = 0; var4 < var0; ++var4) {
         class946 var5 = field2786[var1[var4]];
         if (!var5.method2000(526198823)) {
            var5.field4035 = 689024993;
         } else if (var5.field3377) {
            var5.field4035 = 689024993;
         } else {
            var5.method4691(449273804);
            if (var5.field8299 >= 0 && var5.field8296 >= 0 && var5.field8297 < field2697.method5271(-1927739596) && var5.field8298 < field2697.method5272(2032357288)) {
               var5.field3386 = var5.field4058 ? var3 : false;
               if (class923.field10295 == var5) {
                  var5.field4035 = -1458458655;
               } else {
                  var6 = 0;
                  if (!var5.field4087) {
                     ++var6;
                  }

                  if (var5.field4080 * -1472450313 > field2866 * 443738891) {
                     var6 += 2;
                  }

                  var6 += 5 - var5.method2550() << 2;
                  if (!var5.field3382 && !var5.field3401) {
                     if (198119493 * field2885 == 0) {
                        var6 += 32;
                     } else {
                        var6 += 128;
                     }

                     var6 += 256;
                  } else {
                     var6 += 512;
                  }

                  var5.field4035 = (1 + var6) * -689024993;
               }
            } else {
               var5.field4035 = 689024993;
            }
         }
      }

      for(var4 = 0; var4 < -1230451913 * field2684; ++var4) {
         class60 var8 = (class60)((class437)field2677.method2942((long)field2680[var4])).field7515;
         if (var8.method1241(819293556) && var8.field1637.method6111(class827.field9037, 922180251)) {
            var8.method4691(449273804);
            if (var8.field8299 >= 0 && var8.field8296 >= 0 && var8.field8297 < field2697.method5271(-1937230343) && var8.field8298 < field2697.method5272(1822473503)) {
               var6 = 0;
               if (!var8.field4087) {
                  ++var6;
               }

               if (-1472450313 * var8.field4080 > 443738891 * field2866) {
                  var6 += 2;
               }

               var6 += 5 - var8.method2550() << 2;
               if (field2885 * 198119493 == 0) {
                  if (var8.field1637.field9909) {
                     var6 += 64;
                  } else {
                     var6 += 128;
                  }
               } else if (198119493 * field2885 == 1) {
                  if (var8.field1637.field9909) {
                     var6 += 32;
                  } else {
                     var6 += 64;
                  }
               }

               if (var8.field1637.field9860) {
                  var6 += 1024;
               } else if (!var8.field1637.field9891) {
                  var6 += 256;
               }

               var8.field4035 = (1 + var6) * -689024993;
            } else {
               var8.field4035 = 689024993;
            }
         } else {
            var8.field4035 = 689024993;
         }
      }

      for(var4 = 0; var4 < field2851.length; ++var4) {
         class921 var9 = field2851[var4];
         if (var9 != null) {
            if (958933333 * var9.field10287 == 1) {
               class437 var10 = (class437)field2677.method2942((long)(var9.field10277 * -841622081));
               if (var10 != null) {
                  class60 var7 = (class60)var10.field7515;
                  if (648883167 * var7.field4035 >= 0) {
                     var7.field4035 += 1921054720;
                  }
               }
            } else if (958933333 * var9.field10287 == 10) {
               class946 var11 = field2786[-841622081 * var9.field10277];
               if (var11 != null && class923.field10295 != var11 && 648883167 * var11.field4035 >= 0) {
                  var11.field4035 += 1921054720;
               }
            }
         }
      }

   }

   static final void method1756(int var0) {
      int var1 = 1168366243 * class498.field8102;
      int[] var2 = class498.field8108;
      int[][] var3 = field2697.method5298((byte)11);
      int[][] var4 = field2697.method5280(-516804479);
      int var5;
      if (field2705 * 1596783995 == 0) {
         var5 = class949.field3322.length;
      } else {
         var5 = field2684 * -1230451913 + var1;
      }

      for(int var6 = 0; var6 < var5; ++var6) {
         Object var8;
         if (1596783995 * field2705 == 0) {
            class283 var7 = class949.field3322[var6];
            if (!var7.field10613) {
               continue;
            }

            var8 = var7.method6636(1762691762);
         } else {
            if (var6 < var1) {
               var8 = field2786[var2[var6]];
            } else {
               var8 = (class746)((class437)field2677.method2942((long)field2680[var6 - var1])).field7515;
            }

            if (var0 != ((class746)var8).field3639 || ((class746)var8).field4035 * 648883167 < 0) {
               continue;
            }
         }

         int var17 = ((class746)var8).method2550();
         class32 var9 = ((class746)var8).method1511().field7637;
         if ((var17 & 1) == 0) {
            if (((int)var9.field5296 & 511) != 0 || ((int)var9.field5299 & 511) != 0) {
               continue;
            }
         } else if (((int)var9.field5296 & 511) != 256 || 256 != ((int)var9.field5299 & 511)) {
            continue;
         }

         int var10;
         int var11;
         if (var17 == 1) {
            var10 = (int)var9.field5296 >> 9;
            var11 = (int)var9.field5299 >> 9;
            if (648883167 * ((class746)var8).field4035 > var3[var10][var11]) {
               var3[var10][var11] = 648883167 * ((class746)var8).field4035;
               var4[var10][var11] = 1;
            } else if (((class746)var8).field4035 * 648883167 == var3[var10][var11]) {
               ++var4[var10][var11];
            }
         } else {
            var10 = 60 + (var17 - 1) * 256;
            var11 = (int)var9.field5296 - var10 >> 9;
            int var12 = (int)var9.field5299 - var10 >> 9;
            int var13 = (int)var9.field5296 + var10 >> 9;
            int var14 = var10 + (int)var9.field5299 >> 9;

            for(int var15 = var11; var15 <= var13; ++var15) {
               for(int var16 = var12; var16 <= var14; ++var16) {
                  if (((class746)var8).field4035 * 648883167 > var3[var15][var16]) {
                     var3[var15][var16] = 648883167 * ((class746)var8).field4035;
                     var4[var15][var16] = 1;
                  } else if (var3[var15][var16] == ((class746)var8).field4035 * 648883167) {
                     ++var4[var15][var16];
                  }
               }
            }
         }
      }

   }

   static final void method1757(int var0) {
      int var1 = class498.field8102 * 1168366243;
      int[] var2 = class498.field8108;
      int[][] var3 = field2697.method5298((byte)11);
      int[][] var4 = field2697.method5280(-516804479);
      int var5;
      if (field2705 * 1596783995 == 0) {
         var5 = class949.field3322.length;
      } else {
         var5 = field2654 ? var1 : -1230451913 * field2684 + var1;
      }

      for(int var6 = 0; var6 < var5; ++var6) {
         Object var8;
         if (field2705 * 1596783995 == 0) {
            class283 var7 = class949.field3322[var6];
            if (!var7.field10613) {
               continue;
            }

            var8 = var7.method6636(2029177891);
         } else {
            if (var6 < var1) {
               var8 = field2786[var2[var6]];
            } else {
               var8 = (class746)((class437)field2677.method2942((long)field2680[var6 - var1])).field7515;
            }

            if (var0 != ((class746)var8).field3639) {
               continue;
            }

            if (648883167 * ((class746)var8).field4035 < 0) {
               ((class746)var8).field4087 = false;
               continue;
            }
         }

         ((class746)var8).field4033 = 0;
         int var17 = ((class746)var8).method2550();
         class32 var9 = ((class746)var8).method1511().field7637;
         if ((var17 & 1) == 0) {
            if (((int)var9.field5296 & 511) != 0 || ((int)var9.field5299 & 511) != 0) {
               ((class746)var8).field4087 = false;
               continue;
            }
         } else if (((int)var9.field5296 & 511) != 256 || 256 != ((int)var9.field5299 & 511)) {
            ((class746)var8).field4087 = false;
            continue;
         }

         if (field2705 * 1596783995 != 0) {
            int var10;
            int var11;
            if (var17 == 1) {
               var10 = (int)var9.field5296 >> 9;
               var11 = (int)var9.field5299 >> 9;
               if (648883167 * ((class746)var8).field4035 != var3[var10][var11]) {
                  ((class746)var8).field4087 = true;
                  continue;
               }

               if (var4[var10][var11] > 1) {
                  --var4[var10][var11];
                  ((class746)var8).field4087 = true;
                  continue;
               }
            } else {
               var10 = (var17 - 1) * 256 + 252;
               var11 = (int)var9.field5296 - var10 >> 9;
               int var12 = (int)var9.field5299 - var10 >> 9;
               int var13 = (int)var9.field5296 + var10 >> 9;
               int var14 = var10 + (int)var9.field5299 >> 9;
               if (!class7.method2940(var3, var4, ((class746)var8).field4035 * 648883167, var11, var12, var13, var14, -1335348035)) {
                  for(int var15 = var11; var15 <= var13; ++var15) {
                     for(int var16 = var12; var16 <= var14; ++var16) {
                        if (var3[var15][var16] == ((class746)var8).field4035 * 648883167) {
                           --var4[var15][var16];
                        }
                     }
                  }

                  ((class746)var8).field4087 = true;
                  continue;
               }
            }
         }

         ((class746)var8).field4087 = false;
         ((class746)var8).method1515(var9.field5296, (float)class679.method4271((int)var9.field5296, (int)var9.field5299, ((class746)var8).field3639, -1247004114), var9.field5299);
         field2697.method5317(-1611682495).method2416((class476)var8, true, (byte)0);
      }

   }

   static final void method1758() {
      field2640 = 0;

      for(int var0 = 0; var0 < -1230451913 * field2684; ++var0) {
         class60 var1 = (class60)((class437)field2677.method2942((long)field2680[var0])).field7515;
         if (var1.field4087 && var1.method2555((byte)1) != -1) {
            int var2 = (var1.method2550() - 1) * 256 + 252;
            class32 var3 = var1.method1511().field7637;
            int var4 = (int)var3.field5296 - var2 >> 9;
            int var5 = (int)var3.field5299 - var2 >> 9;
            class746 var6 = class160.method3567(var1.field3639, var4, var5, (byte)88);
            if (var6 != null) {
               int var7 = var6.field4028 * 1888274983;
               if (var6 instanceof class60) {
                  var7 += 2048;
               }

               if (-152681609 * var6.field4033 == 0 && var6.method2555((byte)1) != -1) {
                  field2833[1306491689 * field2640] = var7;
                  field2760[field2640 * 1306491689] = var7;
                  field2640 += -517123815;
                  var6.field4033 += 512067143;
               }

               field2833[1306491689 * field2640] = var7;
               field2760[1306491689 * field2640] = 1888274983 * var1.field4028 + 2048;
               field2640 += -517123815;
               var6.field4033 += 512067143;
            }
         }
      }

      class804.method2826(field2760, field2833, 0, 1306491689 * field2640 - 1, 1469095364);
   }

   static final void method1759() {
      int var0 = class498.field8102 * 1168366243;
      int[] var1 = class498.field8108;
      int var2;
      if (field2705 * 1596783995 == 0) {
         var2 = class949.field3322.length;
      } else {
         var2 = field2654 ? var0 : var0 + -1230451913 * field2684;
      }

      for(int var3 = 0; var3 < var2; ++var3) {
         Object var5;
         if (1596783995 * field2705 == 0) {
            class283 var4 = class949.field3322[var3];
            if (!var4.field10613) {
               continue;
            }

            var5 = var4.method6636(459581942);
         } else {
            if (var3 < var0) {
               var5 = field2786[var1[var3]];
            } else {
               var5 = (class746)((class437)field2677.method2942((long)field2680[var3 - var0])).field7515;
            }

            if (648883167 * ((class746)var5).field4035 < 0) {
               continue;
            }
         }

         int var7 = ((class746)var5).method2550();
         class32 var6 = ((class746)var5).method1511().field7637;
         if ((var7 & 1) == 0) {
            if (((int)var6.field5296 & 511) == 0 && ((int)var6.field5299 & 511) == 0) {
               continue;
            }
         } else if (((int)var6.field5296 & 511) == 256 && 256 == ((int)var6.field5299 & 511)) {
            continue;
         }

         ((class746)var5).method1515(var6.field5296, (float)class679.method4271((int)var6.field5296, (int)var6.field5299, ((class746)var5).field3639, -1692137069), var6.field5299);
         field2697.method5317(-1611682495).method2416((class476)var5, true, (byte)0);
      }

   }

   public static final void method1760(class131 var0, class564[] var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10) {
      label924:
      for(int var11 = 0; var11 < var1.length; ++var11) {
         class564 var12 = var1[var11];
         if (var12 != null && 1573706803 * var12.field885 == var2) {
            int var13 = 1354508417 * var12.field868 + var7;
            int var14 = -749038817 * var12.field880 + var8;
            int var15;
            int var16;
            int var17;
            int var18;
            if (2 == -1215239439 * var12.field869) {
               var15 = var3;
               var16 = var4;
               var17 = var5;
               var18 = var6;
            } else {
               int var19 = -2093041337 * var12.field881 + var13;
               int var20 = var12.field887 * 457937409 + var14;
               if (-1215239439 * var12.field869 == 9) {
                  ++var19;
                  ++var20;
               }

               var15 = var13 > var3 ? var13 : var3;
               var16 = var14 > var4 ? var14 : var4;
               var17 = var19 < var5 ? var19 : var5;
               var18 = var20 < var6 ? var20 : var6;
            }

            if (-1215239439 * var12.field869 != 0 && !var12.field963 && method1761(var12).field2563 * -1266165749 == 0 && field2693 != var12 && 907611645 * var12.field870 != class564.field990 * 310968271 && 405143323 * class564.field854 != 907611645 * var12.field870 && -451364727 * class564.field994 != 907611645 * var12.field870 && 907611645 * var12.field870 != -1997023283 * class564.field848) {
               if (var15 < var17 && var16 < var18) {
                  class469.method4019(var12, -1954843749);
               }
            } else if (!method1762(var12)) {
               if (field2832 == var12 && class519.method2667(field2832, 1205106518)) {
                  field2920 = true;
                  field2843 = var13 * -1501079155;
                  field2844 = -1873720993 * var14;
               }

               if (var12.field945 || var15 < var17 && var16 < var18) {
                  if (var12.field890 && var9 >= var15 && var10 >= var16 && var9 < var17 && var10 < var18) {
                     for(class202 var37 = (class202)field2875.method901(1766612795); var37 != null; var37 = (class202)field2875.method906(49146)) {
                        if (var37.field7586) {
                           var37.method545(-1460969981);
                           var37.field7578.field1019 = false;
                        }
                     }

                     if (class484.field8532 * 379282043 == 0) {
                        field2832 = null;
                        field2693 = null;
                     }

                     field2846 = 0;
                     class740.field3202 = false;
                     field2848 = false;
                     if (!class602.field8645) {
                        class417.method5691((byte)9);
                     }
                  }

                  boolean var38 = var12.field908 && 5 == -1215239439 * var12.field869 && var12.field948 * -1993792969 == 0 && var12.field1008 * 925824753 < 0 && -1232467723 * var12.field1005 == -1 && -1 == var12.field1014 * -324971993 && !var12.field921 && 840270937 * var12.field1031 == 0;
                  boolean var39 = false;
                  int var24;
                  if (class912.field10424.method5524((byte)-29) >= var15 && class912.field10424.method5513((byte)-71) >= var16 && class912.field10424.method5524((byte)22) < var17 && class912.field10424.method5513((byte)45) < var18) {
                     if (var38) {
                        class118 var21 = var12.method826(class593.field1623, 1065695472);
                        if (var21 != null && var12.field881 * -2093041337 == var21.field2152 * 1633695381 && var21.field2153 * -60174999 == 457937409 * var12.field887) {
                           int var22 = class912.field10424.method5524((byte)110) - var13;
                           int var23 = class912.field10424.method5513((byte)-27) - var14;
                           if (var23 >= 0 && var23 < var21.field2155.length) {
                              var24 = var21.field2155[var23];
                              if (var22 >= var24 && var22 <= var24 + var21.field2154[var23]) {
                                 var39 = true;
                              }
                           }
                        } else {
                           var39 = true;
                        }
                     } else {
                        var39 = true;
                     }
                  }

                  if (!field2817 && var39) {
                     if (var12.field997 * -1200030067 >= 0) {
                        field2919 = var12.field997 * -133568665;
                     } else if (var12.field890) {
                        field2919 = 280458557;
                     }
                  }

                  if (!class602.field8645 && var39 && !var0.field1101) {
                     class949.method1956(var12, var9 - var13, var10 - var14, -1958017189);
                  }

                  boolean var40 = false;
                  if (class912.field10424.method5508(-591622557) && var39) {
                     var40 = true;
                  }

                  boolean var41 = false;
                  class284 var42 = (class284)field2808.method901(1766612795);
                  int var25;
                  int var26;
                  int var27;
                  class118 var43;
                  if (var42 != null && var42.method6666(-1372966703) == 0 && var42.method6667((byte)-35) >= var15 && var42.method6680(-2145889865) >= var16 && var42.method6667((byte)43) < var17 && var42.method6680(-2006325499) < var18) {
                     if (var38) {
                        var43 = var12.method826(class593.field1623, 1959642657);
                        if (var43 != null && -2093041337 * var12.field881 == 1633695381 * var43.field2152 && var43.field2153 * -60174999 == var12.field887 * 457937409) {
                           var25 = var42.method6667((byte)-40) - var13;
                           var26 = var42.method6680(-1117555002) - var14;
                           if (var26 >= 0 && var26 < var43.field2155.length) {
                              var27 = var43.field2155[var26];
                              if (var25 >= var27 && var25 <= var43.field2154[var26] + var27) {
                                 var41 = true;
                              }
                           }
                        } else {
                           var41 = true;
                        }
                     } else {
                        var41 = true;
                     }
                  }

                  if (var12.field910 != null && !class371.method868(-1797996523)) {
                     for(var24 = 0; var24 < var12.field910.length; ++var24) {
                        if (!class381.field1417.method1392(var12.field910[var24], 2064123957)) {
                           if (var12.field1030 != null) {
                              var12.field1030[var24] = 0;
                           }
                        } else if (var12.field1030 == null || 443738891 * field2866 >= var12.field1030[var24]) {
                           byte var44 = var12.field947[var24];
                           if (var44 == 0 || ((var44 & 8) == 0 || !class381.field1417.method1392(86, -229313729) && !class381.field1417.method1392(82, 328550876) && !class381.field1417.method1392(81, 1628571302)) && ((var44 & 2) == 0 || class381.field1417.method1392(86, -1332099546)) && ((var44 & 1) == 0 || class381.field1417.method1392(82, 343135989)) && ((var44 & 4) == 0 || class381.field1417.method1392(81, 883110115))) {
                              if (var24 < 10) {
                                 class740.method1920(var24 + 1, -440872681 * var12.field867, var12.field879 * -1309843523, "", -1542002795);
                              } else if (10 == var24) {
                                 class422.method5724((byte)4);
                                 class725 var46 = method1761(var12);
                                 class900.method6347(var12, var46.method1742((byte)-4), var46.field2557 * -1133219011, 1387537939);
                                 field2820 = class622.method5341(var12, -1213150980);
                                 if (field2820 == null) {
                                    field2820 = "Null";
                                 }

                                 field2735 = var12.field953 + class56.method1545(16777215, -1325844551);
                              }

                              var26 = var12.field1001[var24];
                              if (var12.field1030 == null) {
                                 var12.field1030 = new int[var12.field910.length];
                              }

                              if (var26 != 0) {
                                 var12.field1030[var24] = var26 + 443738891 * field2866;
                              } else {
                                 var12.field1030[var24] = Integer.MAX_VALUE;
                              }
                           }
                        }
                     }
                  }

                  if (var41) {
                     class317.method470(var12, var42.method6667((byte)0) - var13, var42.method6680(-779478067) - var14, 1509566402);
                  }

                  if (field2832 != null && var12 != field2832 && var39 && method1761(var12).method1739(230946951)) {
                     field2836 = var12;
                  }

                  if (field2693 == var12) {
                     field2837 = true;
                     field2838 = 1246614319 * var13;
                     field2781 = var14 * -429639553;
                     field2840 = -1332645491 * field2693.field881;
                     field2948 = -85522485 * field2693.field887;
                  }

                  if (var12.field963 || var12.field870 * 907611645 != 0) {
                     class202 var45;
                     if (var39 && field2663 * 1170859143 != 0 && var12.field954 != null) {
                        var45 = new class202();
                        var45.field7586 = true;
                        var45.field7578 = var12;
                        var45.field7580 = -1937115609 * field2663;
                        var45.field7583 = var12.field954;
                        field2875.method897(var45, 1704998047);
                     }

                     if (field2832 != null) {
                        var41 = false;
                        var40 = false;
                     } else if (class602.field8645 || 907611645 * var12.field870 != 826979979 * class564.field851 && field2846 * -651858367 > 0) {
                        var41 = false;
                        var40 = false;
                        var39 = false;
                     }

                     if (var12.field870 * 907611645 != 0) {
                        int var49;
                        if (-451364727 * class564.field994 == 907611645 * var12.field870 || 907611645 * var12.field870 == class564.field848 * -1997023283) {
                           field2800 = var12;
                           class5 var57 = field2697.method5282((byte)-11).method5665((byte)-85);
                           if (var57.method2955((byte)-111) != null && !class625.field9752.method459(16777472)) {
                              var57.method2955((byte)-126).method2358(class593.field1623, var12.field887 * 457937409, class615.field8903.field9133.method5728(-1741518508), 1359487645);
                           }

                           if (class564.field994 * -451364727 == var12.field870 * 907611645 && !class602.field8645 && var9 >= var15 && var10 >= var16 && var9 < var17 && var10 < var18) {
                              class138.method992(class593.field1623, var9, var10, 132816560);

                              for(class356 var50 = (class356)field2762.method5207(-16777216); var50 != null; var50 = (class356)field2762.method5211(266564001)) {
                                 if (var9 >= -1082644483 * var50.field1793 && var9 < -989655965 * var50.field1798 && var10 >= var50.field1797 * 614770279 && var10 < -252204233 * var50.field1799) {
                                    class417.method5691((byte)112);
                                    class819.method2937(var50.field1794, (byte)-86);
                                 }
                              }
                           }

                           var25 = class498.field8102 * 1168366243;
                           int[] var54 = class498.field8108;

                           for(var27 = 0; var27 < var25; ++var27) {
                              class946 var51 = field2786[var54[var27]];
                              if (var51 != null) {
                                 class625.method5828(class112.field2111, -1, -1, var51, var54[var27], (byte)-7);
                                 var51.method2541(var15, var16, var17, var18, var13 - var12.field891 * 684246511, var14 - var12.field892 * -1424956747, var9, var10, 744800283);
                              }
                           }

                           var27 = 0;

                           while(true) {
                              if (var27 >= -1230451913 * field2684) {
                                 continue label924;
                              }

                              var49 = field2680[var27];
                              class437 var53 = (class437)field2677.method2942((long)var49);
                              if (var53 != null) {
                                 class625.method5828(class112.field2115, -407713023 * ((class60)var53.field7515).field1637.field9862, -1, (class746)var53.field7515, var49, (byte)-73);
                                 ((class746)var53.field7515).method2541(var15, var16, var17, var18, var13 - var12.field891 * 684246511, var14 - var12.field892 * -1424956747, var9, var10, 744800283);
                              }

                              ++var27;
                           }
                        }

                        if (310968271 * class564.field990 == 907611645 * var12.field870) {
                           var43 = var12.method826(class593.field1623, 842748651);
                           if (var43 == null || -64305285 * class95.field595 != 0 && class95.field595 * -64305285 != 3 || class602.field8645 || var9 < var15 || var10 < var16 || var9 >= var17 || var10 >= var18) {
                              continue;
                           }

                           var25 = var9 - var13;
                           var26 = var10 - var14;
                           var27 = var43.field2155[var26];
                           if (var25 < var27 || var25 > var43.field2154[var26] + var27) {
                              continue;
                           }

                           var25 -= var12.field881 * -2093041337 / 2;
                           var26 -= 457937409 * var12.field887 / 2;
                           if (2 == -863531439 * class563.field1083) {
                              var49 = (int)field2931 & 16383;
                           } else {
                              var49 = (int)field2931 + field2782 * 1227356013 & 16383;
                           }

                           int var52 = class703.field3413[var49];
                           int var30 = class703.field3404[var49];
                           if (class563.field1083 * -863531439 != 2) {
                              var52 = (256 + 356727603 * field2730) * var52 >> 8;
                              var30 = (field2730 * 356727603 + 256) * var30 >> 8;
                           }

                           int var31 = var25 * var30 + var26 * var52 >> 14;
                           int var32 = var26 * var30 - var52 * var25 >> 14;
                           int var33;
                           int var34;
                           if (2 == -863531439 * class563.field1083) {
                              var33 = (-2080858977 * field2734 >> 9) + (var31 >> 2);
                              var34 = (field2736 * 1818837461 >> 9) - (var32 >> 2);
                           } else {
                              int var35 = (class923.field10295.method2550() - 1) * 256;
                              class32 var36 = class923.field10295.method1511().field7637;
                              var33 = (var31 >> 2) + ((int)var36.field5296 - var35 >> 9);
                              var34 = ((int)var36.field5299 - var35 >> 9) - (var32 >> 2);
                           }

                           if (field2817 && (-112110875 * class568.field645 & 64) != 0) {
                              class564 var55 = class554.method427(1262526353 * class543.field3820, 392084321 * field2818, -156511736);
                              if (var55 != null) {
                                 class984.method1875(field2820, " " + class822.field9048, 697885143 * class175.field5075, 59, -1232467723 * var12.field1005, 1L, var33, var34, true, false, (long)(-1309843523 * var12.field879 << 32 | var12.field867 * -440872681), true, -1552213884);
                              } else {
                                 class422.method5724((byte)4);
                              }
                              continue;
                           }

                           if (class469.field7320 == field2926) {
                              class984.method1875(class814.field4784.method2927(class321.field1066, -875414210), "", -1, 60, -1, 1L, var33, var34, true, false, 0L, true, -1517476672);
                           }

                           class984.method1875(class776.field3730, "", -1471730241 * field2803, 23, -1, 1L, var33, var34, true, false, 0L, true, -1229159943);
                           continue;
                        }

                        if (var12.field870 * 907611645 == 826979979 * class564.field851) {
                           class147.field1520 = var12;
                           if (var39) {
                              class740.field3202 = true;
                           }

                           if (var41) {
                              var24 = (int)((double)(var42.method6667((byte)-16) - var13 - -2093041337 * var12.field881 / 2) * 2.0D / (double)class491.field7808);
                              var25 = (int)(-((double)(var42.method6680(-890591574) - var14 - 457937409 * var12.field887 / 2) * 2.0D / (double)class491.field7808));
                              var26 = var24 + class896.field9358 * 1196508279 + class491.field7820;
                              var27 = class491.field7813 + var25 + class747.field4148 * 1882038855;
                              class327 var28 = class459.method3965(-360398838);
                              if (var28 == null) {
                                 continue;
                              }

                              int[] var29 = new int[3];
                              var28.method5(var26, var27, var29, -1054516511);
                              if (var29 != null) {
                                 if (class381.field1417.method1392(82, 1232426176) && 1806357379 * field2790 > 0) {
                                    class439.method4280(var29[0], var29[1], var29[2], 1774070906);
                                    continue;
                                 }

                                 field2848 = true;
                                 class569.field25 = var29[0] * -938951349;
                                 class138.field1172 = -1364790753 * var29[1];
                                 class28.field6581 = var29[2] * 1686622783;
                              }

                              field2846 = 640786881;
                              field2847 = false;
                              field2715 = class912.field10424.method5524((byte)32) * -344812543;
                              field2835 = class912.field10424.method5513((byte)45) * -1376922141;
                              continue;
                           }

                           if (var40 && field2846 * -651858367 > 0) {
                              if (1 == field2846 * -651858367 && (-98735103 * field2715 != class912.field10424.method5524((byte)-21) || -938469429 * field2835 != class912.field10424.method5513((byte)40))) {
                                 class916.field10420 = class896.field9358 * -880153251;
                                 class866.field9766 = class747.field4148 * 1849990747;
                                 field2846 = 1281573762;
                              }

                              if (2 == -651858367 * field2846) {
                                 field2847 = true;
                                 class482.method4720(class916.field10420 * 100354019 + (int)((double)(-98735103 * field2715 - class912.field10424.method5524((byte)13)) * 2.0D / (double)class491.field7809), (short)1347);
                                 class718.method2072(-1026644091 * class866.field9766 - (int)((double)(-938469429 * field2835 - class912.field10424.method5513((byte)-70)) * 2.0D / (double)class491.field7809), (byte)44);
                              }
                              continue;
                           }

                           if (-651858367 * field2846 > 0 && !field2847) {
                              if ((field2812 * 2089115297 == 1 || class305.method373(-1803643567)) && -278777595 * class602.field8673 > 2) {
                                 class935.method6308(-98735103 * field2715, field2835 * -938469429, -2029149482);
                              } else if (class935.method6310(2130342678)) {
                                 class935.method6308(field2715 * -98735103, -938469429 * field2835, -2029149482);
                              }
                           }

                           field2846 = 0;
                           continue;
                        }

                        if (class564.field852 * -283863983 == var12.field870 * 907611645) {
                           if (var40) {
                              class295.method6521(class912.field10424.method5524((byte)-30) - var13, class912.field10424.method5513((byte)50) - var14, -2093041337 * var12.field881, 457937409 * var12.field887, -2108838735);
                           }
                           continue;
                        }

                        if (907611645 * var12.field870 == 405143323 * class564.field854) {
                           class804.method2824(var12, var13, var14, -462358504);
                           continue;
                        }
                     }

                     if (!var12.field1020 && var41) {
                        var12.field1020 = true;
                        if (var12.field965 != null) {
                           var45 = new class202();
                           var45.field7586 = true;
                           var45.field7578 = var12;
                           var45.field7579 = (var42.method6667((byte)70) - var13) * 622624491;
                           var45.field7580 = (var42.method6680(-1664921845) - var14) * 335112545;
                           var45.field7583 = var12.field965;
                           field2875.method897(var45, 1397555107);
                        }
                     }

                     if (var12.field1020 && var40 && var12.field988 != null) {
                        var45 = new class202();
                        var45.field7586 = true;
                        var45.field7578 = var12;
                        var45.field7579 = (class912.field10424.method5524((byte)-5) - var13) * 622624491;
                        var45.field7580 = (class912.field10424.method5513((byte)20) - var14) * 335112545;
                        var45.field7583 = var12.field988;
                        field2875.method897(var45, 521504192);
                     }

                     if (var12.field1020 && !var40) {
                        var12.field1020 = false;
                        if (var12.field875 != null) {
                           var45 = new class202();
                           var45.field7586 = true;
                           var45.field7578 = var12;
                           var45.field7579 = (class912.field10424.method5524((byte)-46) - var13) * 622624491;
                           var45.field7580 = (class912.field10424.method5513((byte)-116) - var14) * 335112545;
                           var45.field7583 = var12.field875;
                           field2877.method897(var45, 544676739);
                        }
                     }

                     if (var40 && var12.field968 != null) {
                        var45 = new class202();
                        var45.field7586 = true;
                        var45.field7578 = var12;
                        var45.field7579 = (class912.field10424.method5524((byte)84) - var13) * 622624491;
                        var45.field7580 = (class912.field10424.method5513((byte)88) - var14) * 335112545;
                        var45.field7583 = var12.field968;
                        field2875.method897(var45, 1121649679);
                     }

                     if (!var12.field1019 && var39) {
                        var12.field1019 = true;
                        if (var12.field969 != null) {
                           var45 = new class202();
                           var45.field7586 = true;
                           var45.field7578 = var12;
                           var45.field7579 = (class912.field10424.method5524((byte)77) - var13) * 622624491;
                           var45.field7580 = (class912.field10424.method5513((byte)43) - var14) * 335112545;
                           var45.field7583 = var12.field969;
                           field2875.method897(var45, -424737725);
                        }
                     }

                     if (var12.field1019 && var39 && var12.field970 != null) {
                        var45 = new class202();
                        var45.field7586 = true;
                        var45.field7578 = var12;
                        var45.field7579 = (class912.field10424.method5524((byte)71) - var13) * 622624491;
                        var45.field7580 = (class912.field10424.method5513((byte)-47) - var14) * 335112545;
                        var45.field7583 = var12.field970;
                        field2875.method897(var45, 1191346239);
                     }

                     if (var12.field1019 && !var39) {
                        var12.field1019 = false;
                        if (var12.field847 != null) {
                           var45 = new class202();
                           var45.field7586 = true;
                           var45.field7578 = var12;
                           var45.field7579 = (class912.field10424.method5524((byte)44) - var13) * 622624491;
                           var45.field7580 = (class912.field10424.method5513((byte)29) - var14) * 335112545;
                           var45.field7583 = var12.field847;
                           field2877.method897(var45, 1896898026);
                        }
                     }

                     if (var12.field934 != null) {
                        var45 = new class202();
                        var45.field7578 = var12;
                        var45.field7583 = var12.field934;
                        field2641.method897(var45, 1662348001);
                     }

                     class202 var47;
                     if (var12.field925 != null && 116700579 * field2859 > -1690676599 * var12.field1025) {
                        if (var12.field983 != null && 116700579 * field2859 - -1690676599 * var12.field1025 <= 32) {
                           label788:
                           for(var24 = -1690676599 * var12.field1025; var24 < field2859 * 116700579; ++var24) {
                              var25 = field2858[var24 & 31];

                              for(var26 = 0; var26 < var12.field983.length; ++var26) {
                                 if (var25 == var12.field983[var26]) {
                                    var47 = new class202();
                                    var47.field7578 = var12;
                                    var47.field7583 = var12.field925;
                                    field2875.method897(var47, 1623160189);
                                    break label788;
                                 }
                              }
                           }
                        } else {
                           var45 = new class202();
                           var45.field7578 = var12;
                           var45.field7583 = var12.field925;
                           field2875.method897(var45, 502102502);
                        }

                        var12.field1025 = -1610191925 * field2859;
                     }

                     if (var12.field882 != null && -466597939 * field2861 > -954704559 * var12.field1026) {
                        if (var12.field985 != null && -466597939 * field2861 - var12.field1026 * -954704559 <= 32) {
                           label764:
                           for(var24 = -954704559 * var12.field1026; var24 < field2861 * -466597939; ++var24) {
                              var25 = field2768[var24 & 31];

                              for(var26 = 0; var26 < var12.field985.length; ++var26) {
                                 if (var12.field985[var26] == var25) {
                                    var47 = new class202();
                                    var47.field7578 = var12;
                                    var47.field7583 = var12.field882;
                                    field2875.method897(var47, 1953578472);
                                    break label764;
                                 }
                              }
                           }
                        } else {
                           var45 = new class202();
                           var45.field7578 = var12;
                           var45.field7583 = var12.field882;
                           field2875.method897(var45, 1651648237);
                        }

                        var12.field1026 = field2861 * -1362594883;
                     }

                     if (var12.field902 != null && field2764 * -1667357449 > 942876795 * var12.field1013) {
                        if (var12.field913 != null && field2764 * -1667357449 - var12.field1013 * 942876795 <= 32) {
                           label740:
                           for(var24 = 942876795 * var12.field1013; var24 < field2764 * -1667357449; ++var24) {
                              var25 = field2856[var24 & 31];

                              for(var26 = 0; var26 < var12.field913.length; ++var26) {
                                 if (var25 == var12.field913[var26]) {
                                    var47 = new class202();
                                    var47.field7578 = var12;
                                    var47.field7583 = var12.field902;
                                    field2875.method897(var47, 1394697778);
                                    break label740;
                                 }
                              }
                           }
                        } else {
                           var45 = new class202();
                           var45.field7578 = var12;
                           var45.field7583 = var12.field902;
                           field2875.method897(var45, 2005476208);
                        }

                        var12.field1013 = 1037546165 * field2764;
                     }

                     if (var12.field897 != null && 1610062389 * field2855 > -745327741 * var12.field1023) {
                        if (var12.field979 != null && field2855 * 1610062389 - -745327741 * var12.field1023 <= 32) {
                           label716:
                           for(var24 = var12.field1023 * -745327741; var24 < field2855 * 1610062389; ++var24) {
                              var25 = field2804[var24 & 31];

                              for(var26 = 0; var26 < var12.field979.length; ++var26) {
                                 if (var12.field979[var26] == var25) {
                                    var47 = new class202();
                                    var47.field7578 = var12;
                                    var47.field7583 = var12.field897;
                                    field2875.method897(var47, -117285712);
                                    break label716;
                                 }
                              }
                           }
                        } else {
                           var45 = new class202();
                           var45.field7578 = var12;
                           var45.field7583 = var12.field897;
                           field2875.method897(var45, 1555874647);
                        }

                        var12.field1023 = field2855 * 914240999;
                     }

                     if (var12.field980 != null && -1048955195 * field2857 > -670133479 * var12.field1024) {
                        if (var12.field981 != null && field2857 * -1048955195 - -670133479 * var12.field1024 <= 32) {
                           label692:
                           for(var24 = -670133479 * var12.field1024; var24 < field2857 * -1048955195; ++var24) {
                              var25 = field2815[var24 & 31];

                              for(var26 = 0; var26 < var12.field981.length; ++var26) {
                                 if (var12.field981[var26] == var25) {
                                    var47 = new class202();
                                    var47.field7578 = var12;
                                    var47.field7583 = var12.field980;
                                    field2875.method897(var47, 1221126976);
                                    break label692;
                                 }
                              }
                           }
                        } else {
                           var45 = new class202();
                           var45.field7578 = var12;
                           var45.field7583 = var12.field980;
                           field2875.method897(var45, 1231950426);
                        }

                        var12.field1024 = field2857 * -715849075;
                     }

                     if (var12.field986 != null && -1653538697 * field2863 > 1544416945 * var12.field1027) {
                        if (var12.field914 != null && field2863 * -1653538697 - var12.field1027 * 1544416945 <= 32) {
                           label668:
                           for(var24 = 1544416945 * var12.field1027; var24 < -1653538697 * field2863; ++var24) {
                              var25 = field2862[var24 & 31];

                              for(var26 = 0; var26 < var12.field914.length; ++var26) {
                                 if (var25 == var12.field914[var26]) {
                                    var47 = new class202();
                                    var47.field7578 = var12;
                                    var47.field7583 = var12.field986;
                                    field2875.method897(var47, 337274912);
                                    break label668;
                                 }
                              }
                           }
                        } else {
                           var45 = new class202();
                           var45.field7578 = var12;
                           var45.field7583 = var12.field986;
                           field2875.method897(var45, -118981685);
                        }

                        var12.field1027 = -1196442713 * field2863;
                     }

                     if (538810253 * field2864 > 1916751821 * var12.field940 && var12.field992 != null) {
                        var45 = new class202();
                        var45.field7578 = var12;
                        var45.field7583 = var12.field992;
                        field2875.method897(var45, 873474299);
                     }

                     if (605488971 * field2865 > var12.field940 * 1916751821 && var12.field1010 != null) {
                        var45 = new class202();
                        var45.field7578 = var12;
                        var45.field7583 = var12.field1010;
                        field2875.method897(var45, 1133301081);
                     }

                     if (field2894 * -2049433257 > var12.field940 * 1916751821 && var12.field995 != null) {
                        var45 = new class202();
                        var45.field7578 = var12;
                        var45.field7583 = var12.field995;
                        field2875.method897(var45, 2128380863);
                     }

                     if (field2867 * -570891387 > var12.field940 * 1916751821 && var12.field996 != null) {
                        var45 = new class202();
                        var45.field7578 = var12;
                        var45.field7583 = var12.field996;
                        field2875.method897(var45, 967792354);
                     }

                     if (-707528081 * field2868 > var12.field940 * 1916751821 && var12.field1012 != null) {
                        var45 = new class202();
                        var45.field7578 = var12;
                        var45.field7583 = var12.field1012;
                        field2875.method897(var45, 1183468985);
                     }

                     if (-53597277 * field2777 > var12.field940 * 1916751821 && var12.field999 != null) {
                        var45 = new class202();
                        var45.field7578 = var12;
                        var45.field7583 = var12.field999;
                        field2875.method897(var45, 1170867246);
                     }

                     if (field2870 * -1961929885 > 1916751821 * var12.field940 && var12.field998 != null) {
                        var45 = new class202();
                        var45.field7578 = var12;
                        var45.field7583 = var12.field998;
                        field2875.method897(var45, 1238026704);
                     }

                     var12.field940 = field2915 * -1380945021;
                     if (var12.field993 != null) {
                        for(var24 = 0; var24 < 1351936279 * field2876; ++var24) {
                           class202 var48 = new class202();
                           var48.field7578 = var12;
                           var48.field7585 = field2691[var24].method1865((byte)-58) * 615642911;
                           var48.field7584 = field2691[var24].method1864((byte)-10) * 100528189;
                           var48.field7583 = var12.field993;
                           field2875.method897(var48, 1490051014);
                        }
                     }

                     if (field2756 && var12.field1002 != null) {
                        var45 = new class202();
                        var45.field7578 = var12;
                        var45.field7583 = var12.field1002;
                        field2875.method897(var45, 693108400);
                     }
                  }

                  if (var12.field869 * -1215239439 == 5 && -1 != 925824753 * var12.field1008) {
                     var12.method831(class490.field7866, class527.field3690, 1204090508).method2358(class593.field1623, var12.field887 * 457937409, class615.field8903.field9133.method5728(-1741518508), 961658636);
                  }

                  class469.method4019(var12, -1825904339);
                  if (var12.field869 * -1215239439 == 0) {
                     method1760(var0, var1, var12.field867 * -440872681, var15, var16, var17, var18, var13 - var12.field891 * 684246511, var14 - -1424956747 * var12.field892, var9, var10);
                     if (var12.field1018 != null) {
                        method1760(var0, var12.field1018, -440872681 * var12.field867, var15, var16, var17, var18, var13 - var12.field891 * 684246511, var14 - -1424956747 * var12.field892, var9, var10);
                     }

                     class256 var56 = (class256)field2823.method2942((long)(var12.field867 * -440872681));
                     if (var56 != null) {
                        if (field2926 == class469.field7324 && 27137839 * var56.field8100 == 0 && !class602.field8645 && var39 && !field2828) {
                           class417.method5691((byte)51);
                        }

                        class65.method1260(var56, -1617025021 * var56.field8101, var15, var16, var17, var18, var13, var14, var9, var10, (byte)34);
                     }
                  }
               }
            }
         }
      }

   }

   public static class725 method1761(class564 var0) {
      class725 var1 = (class725)field2878.method2942((long)(-1309843523 * var0.field879) + ((long)(var0.field867 * -440872681) << 32));
      return var1 != null ? var1 : var0.field944;
   }

   static boolean method1762(class564 var0) {
      if (field2828) {
         if (method1761(var0).field2563 * -1266165749 != 0) {
            return false;
         }

         if (-1215239439 * var0.field869 == 0) {
            return false;
         }
      }

      return var0.field886;
   }

   public final void method3958() {
      if (this.method1308(-60994638)) {
         class440[] var1 = class335.method38(-1853688964);

         for(int var2 = 0; var2 < var1.length; ++var2) {
            class440 var3 = var1[var2];
            String var4 = class833.field9178.getParameter(var3.field7683);
            if (var4 != null) {
               switch(Integer.parseInt(var3.field7683)) {
               case 1:
                  field2646 = Integer.parseInt(var4) * 708949575;
                  break;
               case 2:
                  field2629 = var4;
                  if (field2629.length() > 100) {
                     field2629 = null;
                  }
                  break;
               case 3:
                  field2636 = var4;
                  break;
               case 4:
                  if (class569.field24 == null) {
                     class569.field24 = new class764();
                  }

                  class569.field24.field4347 = Integer.parseInt(var4) * 348739329;
                  break;
               case 5:
                  class507.field4016 = Integer.parseInt(var4) * -339928991;
                  break;
               case 6:
                  class419.field9520 = class408.method5469(Integer.parseInt(var4), (byte)-63);
                  if (class419.field9520 != class408.field9221 && class419.field9520 != class408.field9218 && class408.field9219 != class419.field9520 && class419.field9520 != class408.field9220) {
                     class419.field9520 = class408.field9220;
                  }
                  break;
               case 7:
                  class51.field2310 = var4;
               case 8:
               case 14:
                  break;
               case 9:
                  class221.field7347 = Integer.parseInt(var4) * -2071496301;
                  break;
               case 10:
                  field2637 = var4;
                  break;
               case 11:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2616 = true;
                  } else {
                     field2616 = false;
                  }
                  break;
               case 12:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2632 = true;
                  } else {
                     field2632 = false;
                  }
                  break;
               case 13:
                  class721.field3634 = (class916)class367.method1565(class916.method6460(978559132), Integer.parseInt(var4), (byte)2);
                  if (class916.field10410 == class721.field3634) {
                     class721.field3634 = class916.field10418;
                  } else if (!class916.method6456(class721.field3634, 2135116996) && class721.field3634 != class916.field10415) {
                     class721.field3634 = class916.field10415;
                  }
                  break;
               case 15:
                  field2909 = var4;
                  break;
               case 16:
                  if (var4.equals(class822.field9052)) {
                     field2661 = true;
                  } else {
                     field2661 = false;
                  }
                  break;
               case 17:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2940 = true;
                  } else {
                     field2940 = false;
                  }
                  break;
               case 18:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2788 = true;
                  }
                  break;
               case 19:
               default:
                  class764.method2747("", new RuntimeException(), (short)7807);
                  break;
               case 20:
                  if (class569.field24 == null) {
                     class569.field24 = new class764();
                  }

                  class569.field24.field4343 = var4;
                  break;
               case 21:
                  class601.field9200 = new class764();
                  class601.field9200.field4347 = Integer.parseInt(var4) * 348739329;
                  break;
               case 22:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2620 = true;
                  } else {
                     field2620 = false;
                  }
                  break;
               case 23:
                  if (var4.equals(class822.field9052)) {
                     field2624 = true;
                  } else {
                     field2624 = false;
                  }
                  break;
               case 24:
                  field2630 = var4;
                  break;
               case 25:
                  field2635 = Integer.parseInt(var4) * -431443955;
                  break;
               case 26:
                  field2926 = class718.method2070(Integer.parseInt(var4), (byte)91);
                  break;
               case 27:
                  class321.field1066 = class423.method5706(Integer.parseInt(var4), 1796181193);
                  break;
               case 28:
                  field2953 = Integer.parseInt(var4) * 131907935;
                  if (745003679 * field2953 < 0 || 745003679 * field2953 >= field2670.length) {
                     field2953 = 0;
                  }
                  break;
               case 29:
                  if (var4 != null) {
                     field2825 = class554.method426(class167.method3699(var4, -2124619496), (byte)77);
                     if (field2825.length < 16) {
                        field2825 = null;
                     }
                  }
                  break;
               case 30:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2634 = true;
                  } else {
                     field2634 = false;
                  }
                  break;
               case 31:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2849 = true;
                  } else {
                     field2849 = false;
                  }
                  break;
               case 32:
                  field2626 = Long.parseLong(var4) * -4477728998236397853L;
                  break;
               case 33:
                  class143.field1540 = var4;
               }
            }
         }

         if (field2909 == null) {
            field2909 = "";
         }

         class716 var5 = new class716(775068819 * field2775, -791746413 * field2784, 351263031 * field2708, field2892 * -510898275, field2926.field7326);
         class5.field4944 = this;
         this.method1301(var5, field2926.field7321, class419.field9520.field9223, 32 + 1286017487 * class419.field9520.field9224, class679.method4268(-1723932293), 718, 1, field2634, (byte)-31);
      }

   }

   final void method1320() {
      Frame var1 = new Frame(" ");
      var1.pack();
      var1.dispose();
      class263.field8132 = new class564();
      class791.method398((byte)-73);
      class732.field2980 = new class213();
      class794.field541 = new class81();
      int[] var2 = new int[]{20, 260};
      int[] var3 = new int[]{1000, 100};
      if (var2 != null && var3 != null) {
         class128.field2348 = var2;
         class18.field6930 = new int[var2.length];
         class681.field7538 = new byte[var2.length][][];

         for(int var4 = 0; var4 < class128.field2348.length; ++var4) {
            class681.field7538[var4] = new byte[var3[var4]][];
         }
      } else {
         class128.field2348 = null;
         class18.field6930 = null;
         class681.field7538 = null;
      }

      class32.method3302(100);
      class567.method793(10);
      class725.method1745(100, 2088368476);
      class673.method4262(100, -205571101);
      if (class916.field10415 != class721.field3634) {
         class138.field1171 = new byte[50][];
      }

      class615.field8903 = class455.method3817(1281460883);
      if (class615.field8903.field9146.method3999((byte)-114) == 1) {
         class545.field3885 = false;
      }

      if (class916.field10415 == class721.field3634) {
         class601.field9200.field4343 = class833.field9178.getCodeBase().getHost();
      } else if (class916.method6456(class721.field3634, 2144135205)) {
         class601.field9200.field4343 = class833.field9178.getCodeBase().getHost();
         class601.field9200.field4344 = 815680320 + class601.field9200.field4347 * -1670427267;
         class569.field24.field4344 = 815680320 + class569.field24.field4347 * -1670427267;
         class601.field9200.field4345 = -52655920 + class601.field9200.field4347 * 925746937;
         class569.field24.field4345 = class569.field24.field4347 * 925746937 + -52655920;
      } else if (class721.field3634 == class916.field10410) {
         class601.field9200.field4343 = class822.field9051;
         class569.field24.field4343 = class822.field9051;
         class601.field9200.field4344 = 815680320 + class601.field9200.field4347 * -1670427267;
         class569.field24.field4344 = -1670427267 * class569.field24.field4347 + 815680320;
         class601.field9200.field4345 = -52655920 + class601.field9200.field4347 * 925746937;
         class569.field24.field4345 = -52655920 + class569.field24.field4347 * 925746937;
      }

      class601.field9203 = class601.field9200;
      if (field2926 == class469.field7324) {
         field2655 = false;
      }

      class503.field4103 = class50.field2255 = class401.field9918 = class518.field4275 = new short[256];

      try {
         class397.field6496 = class348.method193((byte)114).getToolkit().getSystemClipboard();
      } catch (Exception var5) {
         ;
      }

      class381.field1417 = class134.method1035(class837.field9161, 761707328);
      class912.field10424 = class69.method1335(class837.field9161, true, (short)391);
      if (class916.field10415 != class721.field3634) {
         field2648 = true;
      }

      field1825 = class814.field4748.method2927(class321.field1066, -875414210);
      class625.field9752 = new class794();
      (new Thread(class625.field9752)).start();
   }

   public final void method3963() {
      if (this.method1308(555346996)) {
         class440[] var1 = class335.method38(1031965287);

         for(int var2 = 0; var2 < var1.length; ++var2) {
            class440 var3 = var1[var2];
            String var4 = class833.field9178.getParameter(var3.field7683);
            if (var4 != null) {
               switch(Integer.parseInt(var3.field7683)) {
               case 1:
                  field2646 = Integer.parseInt(var4) * 708949575;
                  break;
               case 2:
                  field2629 = var4;
                  if (field2629.length() > 100) {
                     field2629 = null;
                  }
                  break;
               case 3:
                  field2636 = var4;
                  break;
               case 4:
                  if (class569.field24 == null) {
                     class569.field24 = new class764();
                  }

                  class569.field24.field4347 = Integer.parseInt(var4) * 348739329;
                  break;
               case 5:
                  class507.field4016 = Integer.parseInt(var4) * -339928991;
                  break;
               case 6:
                  class419.field9520 = class408.method5469(Integer.parseInt(var4), (byte)-17);
                  if (class419.field9520 != class408.field9221 && class419.field9520 != class408.field9218 && class408.field9219 != class419.field9520 && class419.field9520 != class408.field9220) {
                     class419.field9520 = class408.field9220;
                  }
                  break;
               case 7:
                  class51.field2310 = var4;
               case 8:
               case 14:
                  break;
               case 9:
                  class221.field7347 = Integer.parseInt(var4) * -2071496301;
                  break;
               case 10:
                  field2637 = var4;
                  break;
               case 11:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2616 = true;
                  } else {
                     field2616 = false;
                  }
                  break;
               case 12:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2632 = true;
                  } else {
                     field2632 = false;
                  }
                  break;
               case 13:
                  class721.field3634 = (class916)class367.method1565(class916.method6460(-1772297471), Integer.parseInt(var4), (byte)2);
                  if (class916.field10410 == class721.field3634) {
                     class721.field3634 = class916.field10418;
                  } else if (!class916.method6456(class721.field3634, 2053185315) && class721.field3634 != class916.field10415) {
                     class721.field3634 = class916.field10415;
                  }
                  break;
               case 15:
                  field2909 = var4;
                  break;
               case 16:
                  if (var4.equals(class822.field9052)) {
                     field2661 = true;
                  } else {
                     field2661 = false;
                  }
                  break;
               case 17:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2940 = true;
                  } else {
                     field2940 = false;
                  }
                  break;
               case 18:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2788 = true;
                  }
                  break;
               case 19:
               default:
                  class764.method2747("", new RuntimeException(), (short)4311);
                  break;
               case 20:
                  if (class569.field24 == null) {
                     class569.field24 = new class764();
                  }

                  class569.field24.field4343 = var4;
                  break;
               case 21:
                  class601.field9200 = new class764();
                  class601.field9200.field4347 = Integer.parseInt(var4) * 348739329;
                  break;
               case 22:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2620 = true;
                  } else {
                     field2620 = false;
                  }
                  break;
               case 23:
                  if (var4.equals(class822.field9052)) {
                     field2624 = true;
                  } else {
                     field2624 = false;
                  }
                  break;
               case 24:
                  field2630 = var4;
                  break;
               case 25:
                  field2635 = Integer.parseInt(var4) * -431443955;
                  break;
               case 26:
                  field2926 = class718.method2070(Integer.parseInt(var4), (byte)23);
                  break;
               case 27:
                  class321.field1066 = class423.method5706(Integer.parseInt(var4), 2129104581);
                  break;
               case 28:
                  field2953 = Integer.parseInt(var4) * 131907935;
                  if (745003679 * field2953 < 0 || 745003679 * field2953 >= field2670.length) {
                     field2953 = 0;
                  }
                  break;
               case 29:
                  if (var4 != null) {
                     field2825 = class554.method426(class167.method3699(var4, -1069347336), (byte)105);
                     if (field2825.length < 16) {
                        field2825 = null;
                     }
                  }
                  break;
               case 30:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2634 = true;
                  } else {
                     field2634 = false;
                  }
                  break;
               case 31:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2849 = true;
                  } else {
                     field2849 = false;
                  }
                  break;
               case 32:
                  field2626 = Long.parseLong(var4) * -4477728998236397853L;
                  break;
               case 33:
                  class143.field1540 = var4;
               }
            }
         }

         if (field2909 == null) {
            field2909 = "";
         }

         class716 var5 = new class716(775068819 * field2775, -791746413 * field2784, 351263031 * field2708, field2892 * -510898275, field2926.field7326);
         class5.field4944 = this;
         this.method1301(var5, field2926.field7321, class419.field9520.field9223, 32 + 1286017487 * class419.field9520.field9224, class679.method4268(-586316395), 718, 1, field2634, (byte)80);
      }

   }

   final void method1318() {
      Frame var1 = new Frame(" ");
      var1.pack();
      var1.dispose();
      class263.field8132 = new class564();
      class791.method398((byte)-49);
      class732.field2980 = new class213();
      class794.field541 = new class81();
      int[] var2 = new int[]{20, 260};
      int[] var3 = new int[]{1000, 100};
      if (var2 != null && var3 != null) {
         class128.field2348 = var2;
         class18.field6930 = new int[var2.length];
         class681.field7538 = new byte[var2.length][][];

         for(int var4 = 0; var4 < class128.field2348.length; ++var4) {
            class681.field7538[var4] = new byte[var3[var4]][];
         }
      } else {
         class128.field2348 = null;
         class18.field6930 = null;
         class681.field7538 = null;
      }

      class32.method3302(100);
      class567.method793(10);
      class725.method1745(100, 230540177);
      class673.method4262(100, 945128656);
      if (class916.field10415 != class721.field3634) {
         class138.field1171 = new byte[50][];
      }

      class615.field8903 = class455.method3817(1110000568);
      if (class615.field8903.field9146.method3999((byte)-45) == 1) {
         class545.field3885 = false;
      }

      if (class916.field10415 == class721.field3634) {
         class601.field9200.field4343 = class833.field9178.getCodeBase().getHost();
      } else if (class916.method6456(class721.field3634, 2086746818)) {
         class601.field9200.field4343 = class833.field9178.getCodeBase().getHost();
         class601.field9200.field4344 = 815680320 + class601.field9200.field4347 * -1670427267;
         class569.field24.field4344 = 815680320 + class569.field24.field4347 * -1670427267;
         class601.field9200.field4345 = -52655920 + class601.field9200.field4347 * 925746937;
         class569.field24.field4345 = class569.field24.field4347 * 925746937 + -52655920;
      } else if (class721.field3634 == class916.field10410) {
         class601.field9200.field4343 = class822.field9051;
         class569.field24.field4343 = class822.field9051;
         class601.field9200.field4344 = 815680320 + class601.field9200.field4347 * -1670427267;
         class569.field24.field4344 = -1670427267 * class569.field24.field4347 + 815680320;
         class601.field9200.field4345 = -52655920 + class601.field9200.field4347 * 925746937;
         class569.field24.field4345 = -52655920 + class569.field24.field4347 * 925746937;
      }

      class601.field9203 = class601.field9200;
      if (field2926 == class469.field7324) {
         field2655 = false;
      }

      class503.field4103 = class50.field2255 = class401.field9918 = class518.field4275 = new short[256];

      try {
         class397.field6496 = class348.method193((byte)22).getToolkit().getSystemClipboard();
      } catch (Exception var5) {
         ;
      }

      class381.field1417 = class134.method1035(class837.field9161, 1701448688);
      class912.field10424 = class69.method1335(class837.field9161, true, (short)391);
      if (class916.field10415 != class721.field3634) {
         field2648 = true;
      }

      field1825 = class814.field4748.method2927(class321.field1066, -875414210);
      class625.field9752 = new class794();
      (new Thread(class625.field9752)).start();
   }

   final void method1325() {
      Frame var1 = new Frame(" ");
      var1.pack();
      var1.dispose();
      class263.field8132 = new class564();
      class791.method398((byte)-84);
      class732.field2980 = new class213();
      class794.field541 = new class81();
      int[] var2 = new int[]{20, 260};
      int[] var3 = new int[]{1000, 100};
      if (var2 != null && var3 != null) {
         class128.field2348 = var2;
         class18.field6930 = new int[var2.length];
         class681.field7538 = new byte[var2.length][][];

         for(int var4 = 0; var4 < class128.field2348.length; ++var4) {
            class681.field7538[var4] = new byte[var3[var4]][];
         }
      } else {
         class128.field2348 = null;
         class18.field6930 = null;
         class681.field7538 = null;
      }

      class32.method3302(100);
      class567.method793(10);
      class725.method1745(100, 643091682);
      class673.method4262(100, 1212945074);
      if (class916.field10415 != class721.field3634) {
         class138.field1171 = new byte[50][];
      }

      class615.field8903 = class455.method3817(719994704);
      if (class615.field8903.field9146.method3999((byte)-48) == 1) {
         class545.field3885 = false;
      }

      if (class916.field10415 == class721.field3634) {
         class601.field9200.field4343 = class833.field9178.getCodeBase().getHost();
      } else if (class916.method6456(class721.field3634, 2088050765)) {
         class601.field9200.field4343 = class833.field9178.getCodeBase().getHost();
         class601.field9200.field4344 = 815680320 + class601.field9200.field4347 * -1670427267;
         class569.field24.field4344 = 815680320 + class569.field24.field4347 * -1670427267;
         class601.field9200.field4345 = -52655920 + class601.field9200.field4347 * 925746937;
         class569.field24.field4345 = class569.field24.field4347 * 925746937 + -52655920;
      } else if (class721.field3634 == class916.field10410) {
         class601.field9200.field4343 = class822.field9051;
         class569.field24.field4343 = class822.field9051;
         class601.field9200.field4344 = 815680320 + class601.field9200.field4347 * -1670427267;
         class569.field24.field4344 = -1670427267 * class569.field24.field4347 + 815680320;
         class601.field9200.field4345 = -52655920 + class601.field9200.field4347 * 925746937;
         class569.field24.field4345 = -52655920 + class569.field24.field4347 * 925746937;
      }

      class601.field9203 = class601.field9200;
      if (field2926 == class469.field7324) {
         field2655 = false;
      }

      class503.field4103 = class50.field2255 = class401.field9918 = class518.field4275 = new short[256];

      try {
         class397.field6496 = class348.method193((byte)106).getToolkit().getSystemClipboard();
      } catch (Exception var5) {
         ;
      }

      class381.field1417 = class134.method1035(class837.field9161, 1054576068);
      class912.field10424 = class69.method1335(class837.field9161, true, (short)391);
      if (class916.field10415 != class721.field3634) {
         field2648 = true;
      }

      field1825 = class814.field4748.method2927(class321.field1066, -875414210);
      class625.field9752 = new class794();
      (new Thread(class625.field9752)).start();
   }

   public String method1763() {
      String var1 = " ";

      try {
         class389 var2 = field2697.method5270(681479919);
         var1 = var1 + var2.field1521 * -1760580017 + class822.field9050 + 283514611 * var2.field1522 + class822.field9050 + field2697.method5271(-2128021636) + class822.field9050 + field2697.method5272(-1076815167) + " ";
         if (class923.field10295 != null) {
            var1 = var1 + 1855729883 * class899.field9552 + class822.field9050 + (-1760580017 * var2.field1521 + class923.field10295.field4085[0]) + class822.field9050 + (class923.field10295.field4055[0] + var2.field1522 * 283514611) + " ";
         } else {
            var1 = var1 + class899.field9552 * 1855729883 + class822.field9050 + class899.field9552 * 1855729883 + class822.field9050 + 1855729883 * class899.field9552 + class822.field9050 + " ";
         }

         var1 = var1 + class615.field8903.field9137.method3689(-682947587) + " " + class615.field8903.field9115.method1098(-723955200) + " " + class660.method5750((byte)-61) + " " + class759.field4331 * -2110394505 + class822.field9050 + class97.field614 * -1111710645 + " ";
         var1 = var1 + class615.field8903.field9126.method6339(-2018199679) + " ";
         var1 = var1 + class615.field8903.field9147.method5182(-90347626) + " ";
         var1 = var1 + class615.field8903.field9138.method2263(-1374891617) + " ";
         var1 = var1 + class615.field8903.field9123.method5845(1903704462) + " ";
         var1 = var1 + class615.field8903.field9117.method5848(-917787431) + " ";
         var1 = var1 + "0 ";
         var1 = var1 + field1827 * 1126040225 + " ";
         var1 = var1 + -1233866115 * field2733 + " ";
         if (class86.field1134 != null) {
            var1 = var1 + class86.field1134.field3064 * 399637415;
         } else {
            var1 = var1 + -1;
         }

         var1 = var1 + " ";
         if (field2636 != null) {
            var1 = var1 + field2636;
         } else {
            var1 = var1 + class822.field9050;
         }

         try {
            if (class615.field8903.field9137.method3689(-1738416059) == 2) {
               Class var3 = ClassLoader.class;
               Field var4 = var3.getDeclaredField("nativeLibraries");
               Class var5 = AccessibleObject.class;
               Method var6 = var5.getDeclaredMethod("setAccessible", Boolean.TYPE);
               var6.invoke(var4, Boolean.TRUE);
               Vector var7 = (Vector)var4.get(class730.class.getClassLoader());

               for(int var8 = 0; var8 < var7.size(); ++var8) {
                  try {
                     Object var9 = var7.elementAt(var8);
                     Field var10 = var9.getClass().getDeclaredField("name");
                     var6.invoke(var10, Boolean.TRUE);

                     try {
                        String var11 = (String)var10.get(var9);
                        if (var11 != null && var11.indexOf("sw3d.dll") != -1) {
                           Field var12 = var9.getClass().getDeclaredField("handle");
                           var6.invoke(var12, Boolean.TRUE);
                           var1 = var1 + " " + Long.toHexString(var12.getLong(var9));
                           var6.invoke(var12, Boolean.FALSE);
                        }
                     } catch (Throwable var13) {
                        ;
                     }

                     var6.invoke(var10, Boolean.FALSE);
                  } catch (Throwable var14) {
                     ;
                  }
               }
            }
         } catch (Throwable var15) {
            ;
         }
      } catch (Throwable var16) {
         ;
      }

      return var1;
   }

   public String method1764() {
      String var1 = " ";

      try {
         class389 var2 = field2697.method5270(681479919);
         var1 = var1 + var2.field1521 * -1760580017 + class822.field9050 + 283514611 * var2.field1522 + class822.field9050 + field2697.method5271(-2102644604) + class822.field9050 + field2697.method5272(-955929187) + " ";
         if (class923.field10295 != null) {
            var1 = var1 + 1855729883 * class899.field9552 + class822.field9050 + (-1760580017 * var2.field1521 + class923.field10295.field4085[0]) + class822.field9050 + (class923.field10295.field4055[0] + var2.field1522 * 283514611) + " ";
         } else {
            var1 = var1 + class899.field9552 * 1855729883 + class822.field9050 + class899.field9552 * 1855729883 + class822.field9050 + 1855729883 * class899.field9552 + class822.field9050 + " ";
         }

         var1 = var1 + class615.field8903.field9137.method3689(-2069894035) + " " + class615.field8903.field9115.method1098(-980707631) + " " + class660.method5750((byte)-68) + " " + class759.field4331 * -2110394505 + class822.field9050 + class97.field614 * -1111710645 + " ";
         var1 = var1 + class615.field8903.field9126.method6339(-1869858699) + " ";
         var1 = var1 + class615.field8903.field9147.method5182(-1501062841) + " ";
         var1 = var1 + class615.field8903.field9138.method2263(1402925605) + " ";
         var1 = var1 + class615.field8903.field9123.method5845(2098109554) + " ";
         var1 = var1 + class615.field8903.field9117.method5848(708887962) + " ";
         var1 = var1 + "0 ";
         var1 = var1 + field1827 * 1126040225 + " ";
         var1 = var1 + -1233866115 * field2733 + " ";
         if (class86.field1134 != null) {
            var1 = var1 + class86.field1134.field3064 * 399637415;
         } else {
            var1 = var1 + -1;
         }

         var1 = var1 + " ";
         if (field2636 != null) {
            var1 = var1 + field2636;
         } else {
            var1 = var1 + class822.field9050;
         }

         try {
            if (class615.field8903.field9137.method3689(-578216379) == 2) {
               Class var3 = ClassLoader.class;
               Field var4 = var3.getDeclaredField("nativeLibraries");
               Class var5 = AccessibleObject.class;
               Method var6 = var5.getDeclaredMethod("setAccessible", Boolean.TYPE);
               var6.invoke(var4, Boolean.TRUE);
               Vector var7 = (Vector)var4.get(class730.class.getClassLoader());

               for(int var8 = 0; var8 < var7.size(); ++var8) {
                  try {
                     Object var9 = var7.elementAt(var8);
                     Field var10 = var9.getClass().getDeclaredField("name");
                     var6.invoke(var10, Boolean.TRUE);

                     try {
                        String var11 = (String)var10.get(var9);
                        if (var11 != null && var11.indexOf("sw3d.dll") != -1) {
                           Field var12 = var9.getClass().getDeclaredField("handle");
                           var6.invoke(var12, Boolean.TRUE);
                           var1 = var1 + " " + Long.toHexString(var12.getLong(var9));
                           var6.invoke(var12, Boolean.FALSE);
                        }
                     } catch (Throwable var13) {
                        ;
                     }

                     var6.invoke(var10, Boolean.FALSE);
                  } catch (Throwable var14) {
                     ;
                  }
               }
            }
         } catch (Throwable var15) {
            ;
         }
      } catch (Throwable var16) {
         ;
      }

      return var1;
   }

   public String method1765() {
      String var1 = " ";

      try {
         class389 var2 = field2697.method5270(681479919);
         var1 = var1 + var2.field1521 * -1760580017 + class822.field9050 + 283514611 * var2.field1522 + class822.field9050 + field2697.method5271(-1917252704) + class822.field9050 + field2697.method5272(-659381111) + " ";
         if (class923.field10295 != null) {
            var1 = var1 + 1855729883 * class899.field9552 + class822.field9050 + (-1760580017 * var2.field1521 + class923.field10295.field4085[0]) + class822.field9050 + (class923.field10295.field4055[0] + var2.field1522 * 283514611) + " ";
         } else {
            var1 = var1 + class899.field9552 * 1855729883 + class822.field9050 + class899.field9552 * 1855729883 + class822.field9050 + 1855729883 * class899.field9552 + class822.field9050 + " ";
         }

         var1 = var1 + class615.field8903.field9137.method3689(-361845304) + " " + class615.field8903.field9115.method1098(-1338991605) + " " + class660.method5750((byte)-87) + " " + class759.field4331 * -2110394505 + class822.field9050 + class97.field614 * -1111710645 + " ";
         var1 = var1 + class615.field8903.field9126.method6339(-1870553527) + " ";
         var1 = var1 + class615.field8903.field9147.method5182(-12224060) + " ";
         var1 = var1 + class615.field8903.field9138.method2263(-149412729) + " ";
         var1 = var1 + class615.field8903.field9123.method5845(1908877980) + " ";
         var1 = var1 + class615.field8903.field9117.method5848(-1923698698) + " ";
         var1 = var1 + "0 ";
         var1 = var1 + field1827 * 1126040225 + " ";
         var1 = var1 + -1233866115 * field2733 + " ";
         if (class86.field1134 != null) {
            var1 = var1 + class86.field1134.field3064 * 399637415;
         } else {
            var1 = var1 + -1;
         }

         var1 = var1 + " ";
         if (field2636 != null) {
            var1 = var1 + field2636;
         } else {
            var1 = var1 + class822.field9050;
         }

         try {
            if (class615.field8903.field9137.method3689(-1704140617) == 2) {
               Class var3 = ClassLoader.class;
               Field var4 = var3.getDeclaredField("nativeLibraries");
               Class var5 = AccessibleObject.class;
               Method var6 = var5.getDeclaredMethod("setAccessible", Boolean.TYPE);
               var6.invoke(var4, Boolean.TRUE);
               Vector var7 = (Vector)var4.get(class730.class.getClassLoader());

               for(int var8 = 0; var8 < var7.size(); ++var8) {
                  try {
                     Object var9 = var7.elementAt(var8);
                     Field var10 = var9.getClass().getDeclaredField("name");
                     var6.invoke(var10, Boolean.TRUE);

                     try {
                        String var11 = (String)var10.get(var9);
                        if (var11 != null && var11.indexOf("sw3d.dll") != -1) {
                           Field var12 = var9.getClass().getDeclaredField("handle");
                           var6.invoke(var12, Boolean.TRUE);
                           var1 = var1 + " " + Long.toHexString(var12.getLong(var9));
                           var6.invoke(var12, Boolean.FALSE);
                        }
                     } catch (Throwable var13) {
                        ;
                     }

                     var6.invoke(var10, Boolean.FALSE);
                  } catch (Throwable var14) {
                     ;
                  }
               }
            }
         } catch (Throwable var15) {
            ;
         }
      } catch (Throwable var16) {
         ;
      }

      return var1;
   }

   void method1766(byte var1) {
      try {
         if (10 != -1233866115 * field2733) {
            if (field2698) {
               Object var2 = field2642;
               synchronized(field2642) {
                  field2642.notify();
               }

               var2 = field2699;
               synchronized(field2699) {
                  try {
                     field2699.wait();
                  } catch (InterruptedException var5) {
                     ;
                  }
               }

               field2698 = false;
            }

            field2866 += -2114713437;
            if (1 == field2866 * 443738891 % 1000) {
               GregorianCalendar var9 = new GregorianCalendar();
               class880.field10188 = (var9.get(11) * 600 + var9.get(12) * 10 + var9.get(13) / 6) * -850559371;
               field2683.setSeed((long)(1401020893 * class880.field10188));
            }

            field2692.method4378((byte)110);
            field2674.method4378((byte)-69);
            this.method1753(-1133219011);
            if (class117.field1868 != null) {
               class117.field1868.method6185(-741953209);
            }

            class321.method859(1528835992);
            class419.method5643(1235750018);
            class381.field1417.method1398(-1098053107);
            class912.field10424.method5516(846408062);
            if (class593.field1623 != null) {
               class593.field1623.method4801((int)class27.method3468((byte)1));
            }

            field2876 = 0;
            field2668 = 0;

            int var3;
            for(class742 var10 = class381.field1417.method1393((byte)-104); var10 != null; var10 = class381.field1417.method1393((byte)-84)) {
               var3 = var10.method1874(-915468471);
               if (var3 != 2 && var3 != 3) {
                  if (var3 == 0 && -1625219821 * field2668 < 79) {
                     field2669[field2668 * -1625219821] = var10;
                     field2668 += -1573964517;
                  }
               } else {
                  char var4 = var10.method1864((byte)-126);
                  if (class20.method3418(1632341597) && (var4 == '`' || var4 == '§' || var4 == '²' || var4 == '↑')) {
                     if (class371.method868(-1504050336)) {
                        class792.method443(-200374470);
                     } else {
                        class509.method2535(-1941589186);
                     }
                  } else if (1351936279 * field2876 < 128) {
                     field2691[field2876 * 1351936279] = var10;
                     field2876 += 1498865319;
                  }
               }
            }

            field2663 = 0;

            for(class284 var11 = class912.field10424.method5509(-1183106665); var11 != null; var11 = class912.field10424.method5509(390773081)) {
               var3 = var11.method6666(-1372966703);
               if (var3 == -1) {
                  class386.method1169(var11, -1457107013);
               } else if (var3 == 6) {
                  field2663 += var11.method6668(2127682803) * 815898935;
                  var11.method6670(1052301405);
               } else if (class827.method5357(var3, 1317289232)) {
                  field2808.method897(var11, 289207550);
                  if (field2808.method910(1828905535) > 10) {
                     class284 var12 = (class284)field2808.method898(2122873457);
                     if (var12 != null) {
                        var12.method6670(880718198);
                     }
                  }
               }
            }

            if (class371.method868(-2065645422)) {
               class507.method2514(2062671792);
            }

            if (class622.method5340(field2733 * -1233866115, 579190405)) {
               class11.method3574(-123142149);
               class147.method1138(1876624858);
            } else if (class399.method3529(-1233866115 * field2733, -922237026)) {
               field2697.method5314(-319147356);
            }

            if (class162.method3544(field2733 * -1233866115, 1989496806) && !class399.method3529(-1233866115 * field2733, -1179252225)) {
               this.method1769(-2054858271);
               class302.method2352(-1664553677);
               class521.method2750((byte)71);
            } else if (class669.method4121(field2733 * -1233866115, 1765230881) && !class399.method3529(-1233866115 * field2733, 275834204)) {
               this.method1769(-1772986224);
               class521.method2750((byte)123);
            } else if (6 == field2733 * -1233866115) {
               class521.method2750((byte)42);
            } else if (class552.method457(field2733 * -1233866115, (byte)9) && !class399.method3529(field2733 * -1233866115, 1200358903)) {
               class574.method133((byte)31);
            } else if (-1233866115 * field2733 == 5 || 13 == -1233866115 * field2733) {
               class521.method2750((byte)15);
               if (-3 != class881.field10143 * -1372893999 && 2 != -1372893999 * class881.field10143 && class881.field10143 * -1372893999 != 15) {
                  if (13 == field2733 * -1233866115) {
                     class881.field10160 = 1522102865 * class881.field10182;
                     class881.field10178 = class881.field10181 * -2096622051;
                     class881.field10166 = class881.field10143 * 1695357761;
                     if (class601.field9197) {
                        class381.method1064(class601.field9196.field4347 * 1606920449, class601.field9196.field4343, 955770805);
                        field2692.method4375(1032485285);
                        class967.method1750(5, 1513920408);
                     } else {
                        class82.method920(class881.field10184, (byte)127);
                     }
                  } else {
                     class82.method920(false, (byte)21);
                  }
               }
            }

            class16.method3679(class593.field1623, -828057261);
            field2808.method898(2109619537);
         }

      } catch (RuntimeException var8) {
         throw class158.method3445(var8, "client.er(" + ')');
      }
   }

   final void method1321() {
      if (field2717) {
         class749.method2525(1390271339);
      }

      class47.method3085(-2139893918);
      if (class593.field1623 != null) {
         class593.field1623.method4996(295313203);
      }

      if (class53.field2311 && class296.field10468 != null) {
         class386.method1167(class382.field1409, class296.field10468, -171748881);
         class296.field10468 = null;
      }

      field2692.method4374((byte)48);
      field2692.field7775.method935(-1556544216);
      field2674.method4374((byte)55);
      field2674.field7775.method935(-921770099);
      class317.method472(1369308377);
      class794.field541.method233((byte)-34);
      class732.field2980.method3808(-854256441);
      if (field2696 != null) {
         field2696.method5474(807433749);
         field2696 = null;
      }

      try {
         Ping.quit();
      } catch (Throwable var3) {
         ;
      }

      class153.method3392(767475885);

      try {
         class408.method5471((byte)-40);
      } catch (Exception var2) {
         ;
      }

      if (field1820) {
         class118.method1462(-849889720);
      }

   }

   public String method1311(byte var1) {
      try {
         String var2 = " ";

         try {
            class389 var3 = field2697.method5270(681479919);
            var2 = var2 + var3.field1521 * -1760580017 + class822.field9050 + 283514611 * var3.field1522 + class822.field9050 + field2697.method5271(-2133877490) + class822.field9050 + field2697.method5272(-932420747) + " ";
            if (class923.field10295 != null) {
               var2 = var2 + 1855729883 * class899.field9552 + class822.field9050 + (-1760580017 * var3.field1521 + class923.field10295.field4085[0]) + class822.field9050 + (class923.field10295.field4055[0] + var3.field1522 * 283514611) + " ";
            } else {
               var2 = var2 + class899.field9552 * 1855729883 + class822.field9050 + class899.field9552 * 1855729883 + class822.field9050 + 1855729883 * class899.field9552 + class822.field9050 + " ";
            }

            var2 = var2 + class615.field8903.field9137.method3689(-719661759) + " " + class615.field8903.field9115.method1098(-1847382084) + " " + class660.method5750((byte)-120) + " " + class759.field4331 * -2110394505 + class822.field9050 + class97.field614 * -1111710645 + " ";
            var2 = var2 + class615.field8903.field9126.method6339(-2046413432) + " ";
            var2 = var2 + class615.field8903.field9147.method5182(-1774221022) + " ";
            var2 = var2 + class615.field8903.field9138.method2263(-2036567589) + " ";
            var2 = var2 + class615.field8903.field9123.method5845(2062127023) + " ";
            var2 = var2 + class615.field8903.field9117.method5848(1830613279) + " ";
            var2 = var2 + "0 ";
            var2 = var2 + field1827 * 1126040225 + " ";
            var2 = var2 + -1233866115 * field2733 + " ";
            if (class86.field1134 != null) {
               var2 = var2 + class86.field1134.field3064 * 399637415;
            } else {
               var2 = var2 + -1;
            }

            var2 = var2 + " ";
            if (field2636 != null) {
               var2 = var2 + field2636;
            } else {
               var2 = var2 + class822.field9050;
            }

            try {
               if (class615.field8903.field9137.method3689(-1809803071) == 2) {
                  Class var4 = ClassLoader.class;
                  Field var5 = var4.getDeclaredField("nativeLibraries");
                  Class var6 = AccessibleObject.class;
                  Method var7 = var6.getDeclaredMethod("setAccessible", Boolean.TYPE);
                  var7.invoke(var5, Boolean.TRUE);
                  Vector var8 = (Vector)var5.get(class730.class.getClassLoader());

                  for(int var9 = 0; var9 < var8.size(); ++var9) {
                     try {
                        Object var10 = var8.elementAt(var9);
                        Field var11 = var10.getClass().getDeclaredField("name");
                        var7.invoke(var11, Boolean.TRUE);

                        try {
                           String var12 = (String)var11.get(var10);
                           if (var12 != null && var12.indexOf("sw3d.dll") != -1) {
                              Field var13 = var10.getClass().getDeclaredField("handle");
                              var7.invoke(var13, Boolean.TRUE);
                              var2 = var2 + " " + Long.toHexString(var13.getLong(var10));
                              var7.invoke(var13, Boolean.FALSE);
                           }
                        } catch (Throwable var14) {
                           ;
                        }

                        var7.invoke(var11, Boolean.FALSE);
                     } catch (Throwable var15) {
                        ;
                     }
                  }
               }
            } catch (Throwable var16) {
               ;
            }
         } catch (Throwable var17) {
            ;
         }

         return var2;
      } catch (RuntimeException var18) {
         throw class158.method3445(var18, "client.j(" + ')');
      }
   }

   final void method1329() {
      if (class615.field8903.field9137.method3689(-638897214) == 2) {
         try {
            this.method1752((byte)0);
         } catch (ThreadDeath var2) {
            throw var2;
         } catch (Throwable var3) {
            class764.method2747(var3.getMessage() + " " + this.method1311((byte)79), var3, (short)-11302);
            field2643 = true;
            class337.method77(0, false, 622850291);
         }
      } else {
         this.method1752((byte)0);
      }

   }

   static final void method1767() {
      int[][] var0 = field2697.method5298((byte)11);
      int var1 = field2697.method5271(-1956838281);
      int var2 = field2697.method5272(-848747876);

      for(int var3 = 0; var3 < var1; ++var3) {
         int[] var4 = var0[var3];

         for(int var5 = 0; var5 < var2; ++var5) {
            var4[var5] = 0;
         }
      }

   }

   final void method1319() {
      Frame var1 = new Frame(" ");
      var1.pack();
      var1.dispose();
      class263.field8132 = new class564();
      class791.method398((byte)-110);
      class732.field2980 = new class213();
      class794.field541 = new class81();
      int[] var2 = new int[]{20, 260};
      int[] var3 = new int[]{1000, 100};
      if (var2 != null && var3 != null) {
         class128.field2348 = var2;
         class18.field6930 = new int[var2.length];
         class681.field7538 = new byte[var2.length][][];

         for(int var4 = 0; var4 < class128.field2348.length; ++var4) {
            class681.field7538[var4] = new byte[var3[var4]][];
         }
      } else {
         class128.field2348 = null;
         class18.field6930 = null;
         class681.field7538 = null;
      }

      class32.method3302(100);
      class567.method793(10);
      class725.method1745(100, -621093418);
      class673.method4262(100, 1820171138);
      if (class916.field10415 != class721.field3634) {
         class138.field1171 = new byte[50][];
      }

      class615.field8903 = class455.method3817(1638033926);
      if (class615.field8903.field9146.method3999((byte)-41) == 1) {
         class545.field3885 = false;
      }

      if (class916.field10415 == class721.field3634) {
         class601.field9200.field4343 = class833.field9178.getCodeBase().getHost();
      } else if (class916.method6456(class721.field3634, 2103536787)) {
         class601.field9200.field4343 = class833.field9178.getCodeBase().getHost();
         class601.field9200.field4344 = 815680320 + class601.field9200.field4347 * -1670427267;
         class569.field24.field4344 = 815680320 + class569.field24.field4347 * -1670427267;
         class601.field9200.field4345 = -52655920 + class601.field9200.field4347 * 925746937;
         class569.field24.field4345 = class569.field24.field4347 * 925746937 + -52655920;
      } else if (class721.field3634 == class916.field10410) {
         class601.field9200.field4343 = class822.field9051;
         class569.field24.field4343 = class822.field9051;
         class601.field9200.field4344 = 815680320 + class601.field9200.field4347 * -1670427267;
         class569.field24.field4344 = -1670427267 * class569.field24.field4347 + 815680320;
         class601.field9200.field4345 = -52655920 + class601.field9200.field4347 * 925746937;
         class569.field24.field4345 = -52655920 + class569.field24.field4347 * 925746937;
      }

      class601.field9203 = class601.field9200;
      if (field2926 == class469.field7324) {
         field2655 = false;
      }

      class503.field4103 = class50.field2255 = class401.field9918 = class518.field4275 = new short[256];

      try {
         class397.field6496 = class348.method193((byte)65).getToolkit().getSystemClipboard();
      } catch (Exception var5) {
         ;
      }

      class381.field1417 = class134.method1035(class837.field9161, 1207669534);
      class912.field10424 = class69.method1335(class837.field9161, true, (short)391);
      if (class916.field10415 != class721.field3634) {
         field2648 = true;
      }

      field1825 = class814.field4748.method2927(class321.field1066, -875414210);
      class625.field9752 = new class794();
      (new Thread(class625.field9752)).start();
   }

   static class564 method1768(class564 var0) {
      class725 var1 = method1761(var0);
      if (var1.method1741(-1363143168)) {
         return class263.field8132;
      } else {
         int var2 = var1.method1738((byte)1);
         if (var2 == 0) {
            return null;
         } else {
            for(int var3 = 0; var3 < var2; ++var3) {
               var0 = class317.method471(class938.method6283(var0.field867 * -440872681, (byte)3), var0, -1949792813);
               if (var0 == null) {
                  return class263.field8132;
               }
            }

            return var0;
         }
      }
   }

   final void method1769(int var1) {
      try {
         int var2;
         if (14 == -1233866115 * field2733 && !class673.method4261((byte)34) || 18 == -1233866115 * field2733 && 42 == class881.field10143 * -1372893999 || 8 == -1233866115 * field2733) {
            if (field2650 >= 0) {
               field2870 = 1991119277 * field2915;
            }

            if (!class602.field8645) {
               class417.method5691((byte)83);
            }

            for(var2 = 0; var2 < 100; ++var2) {
               if (!class341.method257(field2674, 1977605455)) {
                  if (var1 >= -1655691580) {
                     throw new IllegalStateException();
                  }
                  break;
               }
            }
         }

         class533.method2265(-2001896291);
         class741.method1887(-320472795);
         field2943 += 512435497;
         class347.method210(-1, -1, (byte)-29);
         class804.method2824((class564)null, -1, -1, -936647614);
         class625.method5831(-1860145091);
         field2915 += -908761385;

         for(var2 = 0; var2 < field2753 * 1962237353; ++var2) {
            class60 var3 = (class60)field2797[var2].field7515;
            if (var3 != null) {
               byte var4 = var3.field1637.field9906;
               if ((var4 & 1) == 0) {
                  if (var1 >= -1655691580) {
                     return;
                  }
               } else {
                  int var5 = var3.method2550();
                  int var6;
                  if ((var4 & 2) != 0 && 2050671733 * var3.field4084 == 0 && Math.random() * 1000.0D < 10.0D) {
                     var6 = (int)Math.round(Math.random() * 10.0D - 5.0D);
                     int var7 = (int)Math.round(Math.random() * 10.0D - 5.0D);
                     if (var6 != 0 || var7 != 0) {
                        int var8 = var6 + var3.field4085[0];
                        int var9 = var3.field4055[0] + var7;
                        if (var8 < 0) {
                           var8 = 0;
                        } else if (var8 > field2697.method5271(-2117729189) - var5 - 1) {
                           var8 = field2697.method5271(-1866331716) - var5 - 1;
                        }

                        if (var9 < 0) {
                           var9 = 0;
                        } else if (var9 > field2697.method5272(519906067) - var5 - 1) {
                           var9 = field2697.method5272(-1049497824) - var5 - 1;
                        }

                        int var10 = class345.method157(var3.field4085[0], var3.field4055[0], var5, class440.method4335(var8, var9, var5, var5, 0), field2697.method5281(var3.field3639), true, field2731, field2719);
                        if (var10 > 0) {
                           if (var10 > 9) {
                              var10 = 9;
                           }

                           for(int var11 = 0; var11 < var10; ++var11) {
                              var3.field4085[var11] = field2731[var10 - var11 - 1];
                              var3.field4055[var11] = field2719[var10 - var11 - 1];
                              var3.field4074[var11] = class647.field9228.field9230;
                           }

                           var3.field4084 = var10 * -1013322787;
                        }
                     }
                  }

                  class389.method1151(var3, true, 2113441601);
                  var6 = class335.method40(var3, -219055962);
                  class115.method1274(var3, -1234202907);
                  class148.method1132(var3, -2143152965 * class545.field3910, 236175727 * class488.field8423, var6, -1481572185);
                  class469.method4017(var3, -2143152965 * class545.field3910, 1554285314);
                  class871.method5898(var3, (byte)13);
                  class567 var19 = class567.method785();
                  var19.method798(class703.method2002(var3.field4048.method5553((byte)0)), class703.method2002(var3.field4075.method5553((byte)0)), class703.method2002(var3.field4077.method5553((byte)0)));
                  var3.method1520(var19);
                  var19.method795();
               }
            }
         }

         if ((19 == field2733 * -1233866115 || 18 == field2733 * -1233866115 || field2733 * -1233866115 == 14 || field2733 * -1233866115 == 8) && (!class673.method4261((byte)34) || field2733 * -1233866115 == 18 && -1372893999 * class881.field10143 == 42) && !class556.method431(-391880689)) {
            if (class563.field1083 * -863531439 == 3) {
               class276.method6619(-887753775);
            } else {
               class515.method2694((byte)53);
            }

            if (-1740717447 * class103.field205 >> 9 < 14 || -1740717447 * class103.field205 >> 9 >= field2697.method5271(-2005655322) - 14 || class7.field4918 * -299812095 >> 9 < 14 || -299812095 * class7.field4918 >> 9 >= field2697.method5272(-281479847) - 14) {
               field2697.method5292(new class406(class335.field46, (class513)null), -1991819579);
            }
         }

         while(true) {
            class202 var14;
            class564 var15;
            class564 var16;
            do {
               var14 = (class202)field2641.method898(2110977409);
               if (var14 == null) {
                  while(true) {
                     do {
                        var14 = (class202)field2877.method898(2104272776);
                        if (var14 == null) {
                           if (var1 >= -1655691580) {
                              return;
                           }

                           while(true) {
                              do {
                                 var14 = (class202)field2875.method898(2124467113);
                                 if (var14 == null) {
                                    if (field2832 != null) {
                                       class414.method5600(-587743288);
                                    }

                                    if (443738891 * field2866 % 1500 == 0) {
                                       class870.method5889(-1874138850);
                                    }

                                    if (-1233866115 * field2733 == 14 && !class673.method4261((byte)-38) || field2733 * -1233866115 == 18 && 42 == class881.field10143 * -1372893999) {
                                       class932.method6293(99949596);
                                    }

                                    class353.method1383((byte)-37);
                                    if (field2717 && -4876927317316500383L * field2874 < class27.method3468((byte)1) - 60000L) {
                                       class749.method2525(1589950276);
                                    }

                                    for(class146 var17 = (class146)field2933.method5207(-16777216); var17 != null; var17 = (class146)field2933.method5211(-1698881635)) {
                                       if ((long)(-1505693583 * var17.field1550) < class27.method3468((byte)1) / 1000L - 5L) {
                                          if (var17.field1549 > 0) {
                                             class702.method1969(5, 0, "", "", "", var17.field1551 + class814.field4775.method2927(class321.field1066, -875414210), -1638737966);
                                          }

                                          if (var17.field1549 == 0) {
                                             class702.method1969(5, 0, "", "", "", var17.field1551 + class814.field4776.method2927(class321.field1066, -875414210), 750491919);
                                          }

                                          var17.method2028(-250843172);
                                       }
                                    }

                                    if (14 == field2733 * -1233866115 && !class673.method4261((byte)-62) || -1233866115 * field2733 == 18 && -1372893999 * class881.field10143 == 42 || 8 == field2733 * -1233866115) {
                                       if (field2733 * -1233866115 != 18 && field2674.method4377(537308016) == null) {
                                          class82.method920(false, (byte)100);
                                       } else if (field2674 != null) {
                                          field2674.field7774 += 1797987493;
                                          if (field2674.field7774 * 2033675053 > 50) {
                                             class701 var18 = class637.method5936(class643.field9951, field2674.field7765, (byte)52);
                                             field2674.method4380(var18, (byte)-13);
                                          }

                                          try {
                                             field2674.method4376(-1252759839);
                                          } catch (IOException var12) {
                                             if (18 == -1233866115 * field2733) {
                                                field2674.method4374((byte)79);
                                             } else {
                                                class82.method920(false, (byte)120);
                                             }
                                          }
                                       }
                                    }

                                    return;
                                 }

                                 var15 = var14.field7578;
                                 if (-1309843523 * var15.field879 < 0) {
                                    break;
                                 }

                                 var16 = class449.method3756(1573706803 * var15.field885, (byte)71);
                              } while(var16 == null || var16.field1017 == null || -1309843523 * var15.field879 >= var16.field1017.length || var16.field1017[-1309843523 * var15.field879] != var15);

                              class408.method5470(var14, (byte)21);
                           }
                        }

                        var15 = var14.field7578;
                        if (var15.field879 * -1309843523 < 0) {
                           break;
                        }

                        var16 = class449.method3756(1573706803 * var15.field885, (byte)54);
                     } while(var16 == null || var16.field1017 == null || var15.field879 * -1309843523 >= var16.field1017.length || var15 != var16.field1017[var15.field879 * -1309843523]);

                     class408.method5470(var14, (byte)-46);
                  }
               }

               var15 = var14.field7578;
               if (-1309843523 * var15.field879 < 0) {
                  break;
               }

               var16 = class449.method3756(1573706803 * var15.field885, (byte)75);
            } while(var16 == null || var16.field1017 == null || var15.field879 * -1309843523 >= var16.field1017.length || var15 != var16.field1017[-1309843523 * var15.field879]);

            class408.method5470(var14, (byte)-80);
         }
      } catch (RuntimeException var13) {
         throw class158.method3445(var13, "client.gy(" + ')');
      }
   }

   final void method1322() {
      if (field2717) {
         class749.method2525(1480902174);
      }

      class47.method3085(-1837678985);
      if (class593.field1623 != null) {
         class593.field1623.method4996(1124301967);
      }

      if (class53.field2311 && class296.field10468 != null) {
         class386.method1167(class382.field1409, class296.field10468, 1636611445);
         class296.field10468 = null;
      }

      field2692.method4374((byte)50);
      field2692.field7775.method935(-1670676523);
      field2674.method4374((byte)110);
      field2674.field7775.method935(-2132756692);
      class317.method472(1169249273);
      class794.field541.method233((byte)-54);
      class732.field2980.method3808(-776756018);
      if (field2696 != null) {
         field2696.method5474(566548824);
         field2696 = null;
      }

      try {
         Ping.quit();
      } catch (Throwable var3) {
         ;
      }

      class153.method3392(502450411);

      try {
         class408.method5471((byte)-82);
      } catch (Exception var2) {
         ;
      }

      if (field1820) {
         class118.method1462(-849889720);
      }

   }

   final void method1332() {
      if (field2717) {
         class749.method2525(1523652284);
      }

      class47.method3085(190646444);
      if (class593.field1623 != null) {
         class593.field1623.method4996(761781050);
      }

      if (class53.field2311 && class296.field10468 != null) {
         class386.method1167(class382.field1409, class296.field10468, -593229897);
         class296.field10468 = null;
      }

      field2692.method4374((byte)15);
      field2692.field7775.method935(-1072650507);
      field2674.method4374((byte)26);
      field2674.field7775.method935(-1922574767);
      class317.method472(1756987742);
      class794.field541.method233((byte)-25);
      class732.field2980.method3808(-2042019743);
      if (field2696 != null) {
         field2696.method5474(495769489);
         field2696 = null;
      }

      try {
         Ping.quit();
      } catch (Throwable var3) {
         ;
      }

      class153.method3392(808532358);

      try {
         class408.method5471((byte)-20);
      } catch (Exception var2) {
         ;
      }

      if (field1820) {
         class118.method1462(-849889720);
      }

   }

   void method1770(int var1) {
      try {
         if (-1874843963 * class794.field541.field304 > 276316621 * field2675) {
            class601.field9203.method2743(-1472184385);
            field2869 = class794.field541.field304 * 597723658 - -1674112382;
            if (1634815037 * field2869 > 3000) {
               field2869 = 1385487896;
            }

            if (-1874843963 * class794.field541.field304 >= 2 && 2071451041 * class794.field541.field314 == 6) {
               this.method1328("js5connect_outofdate", 1290969486);
               field2733 = 1532912722;
               return;
            }

            if (-1874843963 * class794.field541.field304 >= 1 && 48 == class794.field541.field314 * 2071451041) {
               this.method1328("sessionexpired", -1620528831);
               field2733 = 1532912722;
               return;
            }

            if (-1874843963 * class794.field541.field304 >= 4 && class794.field541.field314 * 2071451041 == -1) {
               this.method1328("js5crc", -147236052);
               field2733 = 1532912722;
               return;
            }

            if (-1874843963 * class794.field541.field304 >= 4 && class622.method5340(-1233866115 * field2733, -1528186124)) {
               if (7 != class794.field541.field314 * 2071451041 && class794.field541.field314 * 2071451041 != 9) {
                  if (2071451041 * class794.field541.field314 > 0) {
                     if (field2679 == null) {
                        this.method1328("js5connect", 1739880113);
                     } else {
                        this.method1328("js5proxy_" + field2679.trim(), 846081998);
                     }
                  } else {
                     this.method1328("js5io", -534127401);
                  }
               } else {
                  this.method1328("js5connect_full", -2072548353);
               }

               field2733 = 1532912722;
               return;
            }
         }

         field2675 = 1790042329 * class794.field541.field304;
         if (1634815037 * field2869 > 0) {
            field2869 -= 2003348245;
         } else {
            try {
               if (field2673 * -333700189 == 0) {
                  class371.field1089 = Loader.field6962 ? class764.method2741(Loader.field6969, 43594) : class601.field9203.method2740(295506052);
                  field2673 += -244111349;
               }

               if (field2673 * -333700189 == 1) {
                  class397.field6495 = class897.method5626(class371.field1089, 125000, -649048480);
                  int var2 = 9 + field2636.length();
                  class907 var3 = new class907(var2 + 2);
                  var3.method6361(class909.field10384.field10394 * -1813470547);
                  var3.method6361(var2);
                  var3.method6364(718, 662709758);
                  if (Loader.field6970 != 0) {
                     var3.method6364(Loader.field6970, -899867170);
                  }

                  var3.method6366(field2636, 2115753617);
                  class397.field6495.method187(var3.field10375, 0, var2 + 2, 2087409715);
                  field2673 += -244111349;
                  class661.field9626 = class27.method3468((byte)1) * 3230976033870405335L;
               }

               int var10;
               if (2 == -333700189 * field2673) {
                  if (class397.field6495.method175(1, (byte)-6)) {
                     byte[] var8 = new byte[1];
                     var10 = class397.field6495.method177(var8, 0, 1, (byte)29);
                     if (var8[0] != 0) {
                        this.method1754(var10, 1537331688);
                        return;
                     }

                     field2673 += -244111349;
                  } else if (class27.method3468((byte)1) - class661.field9626 * 4898534346964759783L > 30000L) {
                     this.method1754(1001, 1729333366);
                     return;
                  }
               }

               if (field2673 * -333700189 == 3) {
                  class403[] var9 = class403.method6145(1922216158);
                  var10 = 4 * var9.length;
                  if (class397.field6495.method175(var10, (byte)-56)) {
                     class907 var4 = new class907(var10);
                     class397.field6495.method177(var4.field10375, 0, var4.field10375.length, (byte)28);

                     for(int var5 = 0; var5 < var9.length; ++var5) {
                        var9[var5].method6144(var4.method6420((byte)30), 1206092602);
                     }

                     boolean var11 = class622.method5340(-1233866115 * field2733, -1798608797) || class162.method3544(-1233866115 * field2733, 1916221113) || class669.method4121(field2733 * -1233866115, 1765230881);
                     class794.field541.method231(class397.field6495, !var11, 2131588995);
                     class371.field1089 = null;
                     class397.field6495 = null;
                     field2673 = 0;
                  }
               }
            } catch (IOException var6) {
               this.method1754(1002, 1042413501);
            }
         }

      } catch (RuntimeException var7) {
         throw class158.method3445(var7, "client.fu(" + ')');
      }
   }

   final void method1334() {
      if (class615.field8903.field9137.method3689(-1278701263) == 2) {
         try {
            this.method1766((byte)0);
         } catch (ThreadDeath var2) {
            throw var2;
         } catch (Throwable var3) {
            class764.method2747(var3.getMessage() + " " + this.method1311((byte)-30), var3, (short)876);
            field2643 = true;
            class337.method77(0, false, 622850291);
         }
      } else {
         this.method1766((byte)0);
      }

   }

   public final void method3959() {
      if (this.method1308(1016289663)) {
         class440[] var1 = class335.method38(-2747182);

         for(int var2 = 0; var2 < var1.length; ++var2) {
            class440 var3 = var1[var2];
            String var4 = class833.field9178.getParameter(var3.field7683);
            if (var4 != null) {
               switch(Integer.parseInt(var3.field7683)) {
               case 1:
                  field2646 = Integer.parseInt(var4) * 708949575;
                  break;
               case 2:
                  field2629 = var4;
                  if (field2629.length() > 100) {
                     field2629 = null;
                  }
                  break;
               case 3:
                  field2636 = var4;
                  break;
               case 4:
                  if (class569.field24 == null) {
                     class569.field24 = new class764();
                  }

                  class569.field24.field4347 = Integer.parseInt(var4) * 348739329;
                  break;
               case 5:
                  class507.field4016 = Integer.parseInt(var4) * -339928991;
                  break;
               case 6:
                  class419.field9520 = class408.method5469(Integer.parseInt(var4), (byte)-72);
                  if (class419.field9520 != class408.field9221 && class419.field9520 != class408.field9218 && class408.field9219 != class419.field9520 && class419.field9520 != class408.field9220) {
                     class419.field9520 = class408.field9220;
                  }
                  break;
               case 7:
                  class51.field2310 = var4;
               case 8:
               case 14:
                  break;
               case 9:
                  class221.field7347 = Integer.parseInt(var4) * -2071496301;
                  break;
               case 10:
                  field2637 = var4;
                  break;
               case 11:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2616 = true;
                  } else {
                     field2616 = false;
                  }
                  break;
               case 12:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2632 = true;
                  } else {
                     field2632 = false;
                  }
                  break;
               case 13:
                  class721.field3634 = (class916)class367.method1565(class916.method6460(-2002441744), Integer.parseInt(var4), (byte)2);
                  if (class916.field10410 == class721.field3634) {
                     class721.field3634 = class916.field10418;
                  } else if (!class916.method6456(class721.field3634, 2131067135) && class721.field3634 != class916.field10415) {
                     class721.field3634 = class916.field10415;
                  }
                  break;
               case 15:
                  field2909 = var4;
                  break;
               case 16:
                  if (var4.equals(class822.field9052)) {
                     field2661 = true;
                  } else {
                     field2661 = false;
                  }
                  break;
               case 17:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2940 = true;
                  } else {
                     field2940 = false;
                  }
                  break;
               case 18:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2788 = true;
                  }
                  break;
               case 19:
               default:
                  class764.method2747("", new RuntimeException(), (short)-3254);
                  break;
               case 20:
                  if (class569.field24 == null) {
                     class569.field24 = new class764();
                  }

                  class569.field24.field4343 = var4;
                  break;
               case 21:
                  class601.field9200 = new class764();
                  class601.field9200.field4347 = Integer.parseInt(var4) * 348739329;
                  break;
               case 22:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2620 = true;
                  } else {
                     field2620 = false;
                  }
                  break;
               case 23:
                  if (var4.equals(class822.field9052)) {
                     field2624 = true;
                  } else {
                     field2624 = false;
                  }
                  break;
               case 24:
                  field2630 = var4;
                  break;
               case 25:
                  field2635 = Integer.parseInt(var4) * -431443955;
                  break;
               case 26:
                  field2926 = class718.method2070(Integer.parseInt(var4), (byte)39);
                  break;
               case 27:
                  class321.field1066 = class423.method5706(Integer.parseInt(var4), 422244563);
                  break;
               case 28:
                  field2953 = Integer.parseInt(var4) * 131907935;
                  if (745003679 * field2953 < 0 || 745003679 * field2953 >= field2670.length) {
                     field2953 = 0;
                  }
                  break;
               case 29:
                  if (var4 != null) {
                     field2825 = class554.method426(class167.method3699(var4, -1670653072), (byte)83);
                     if (field2825.length < 16) {
                        field2825 = null;
                     }
                  }
                  break;
               case 30:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2634 = true;
                  } else {
                     field2634 = false;
                  }
                  break;
               case 31:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2849 = true;
                  } else {
                     field2849 = false;
                  }
                  break;
               case 32:
                  field2626 = Long.parseLong(var4) * -4477728998236397853L;
                  break;
               case 33:
                  class143.field1540 = var4;
               }
            }
         }

         if (field2909 == null) {
            field2909 = "";
         }

         class716 var5 = new class716(775068819 * field2775, -791746413 * field2784, 351263031 * field2708, field2892 * -510898275, field2926.field7326);
         class5.field4944 = this;
         this.method1301(var5, field2926.field7321, class419.field9520.field9223, 32 + 1286017487 * class419.field9520.field9224, class679.method4268(-1477238389), 718, 1, field2634, (byte)80);
      }

   }

   public final void method3960() {
      if (this.method1308(-150089276)) {
         class440[] var1 = class335.method38(1350680601);

         for(int var2 = 0; var2 < var1.length; ++var2) {
            class440 var3 = var1[var2];
            String var4 = class833.field9178.getParameter(var3.field7683);
            if (var4 != null) {
               switch(Integer.parseInt(var3.field7683)) {
               case 1:
                  field2646 = Integer.parseInt(var4) * 708949575;
                  break;
               case 2:
                  field2629 = var4;
                  if (field2629.length() > 100) {
                     field2629 = null;
                  }
                  break;
               case 3:
                  field2636 = var4;
                  break;
               case 4:
                  if (class569.field24 == null) {
                     class569.field24 = new class764();
                  }

                  class569.field24.field4347 = Integer.parseInt(var4) * 348739329;
                  break;
               case 5:
                  class507.field4016 = Integer.parseInt(var4) * -339928991;
                  break;
               case 6:
                  class419.field9520 = class408.method5469(Integer.parseInt(var4), (byte)-52);
                  if (class419.field9520 != class408.field9221 && class419.field9520 != class408.field9218 && class408.field9219 != class419.field9520 && class419.field9520 != class408.field9220) {
                     class419.field9520 = class408.field9220;
                  }
                  break;
               case 7:
                  class51.field2310 = var4;
               case 8:
               case 14:
                  break;
               case 9:
                  class221.field7347 = Integer.parseInt(var4) * -2071496301;
                  break;
               case 10:
                  field2637 = var4;
                  break;
               case 11:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2616 = true;
                  } else {
                     field2616 = false;
                  }
                  break;
               case 12:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2632 = true;
                  } else {
                     field2632 = false;
                  }
                  break;
               case 13:
                  class721.field3634 = (class916)class367.method1565(class916.method6460(-890747284), Integer.parseInt(var4), (byte)2);
                  if (class916.field10410 == class721.field3634) {
                     class721.field3634 = class916.field10418;
                  } else if (!class916.method6456(class721.field3634, 2094353987) && class721.field3634 != class916.field10415) {
                     class721.field3634 = class916.field10415;
                  }
                  break;
               case 15:
                  field2909 = var4;
                  break;
               case 16:
                  if (var4.equals(class822.field9052)) {
                     field2661 = true;
                  } else {
                     field2661 = false;
                  }
                  break;
               case 17:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2940 = true;
                  } else {
                     field2940 = false;
                  }
                  break;
               case 18:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2788 = true;
                  }
                  break;
               case 19:
               default:
                  class764.method2747("", new RuntimeException(), (short)-7537);
                  break;
               case 20:
                  if (class569.field24 == null) {
                     class569.field24 = new class764();
                  }

                  class569.field24.field4343 = var4;
                  break;
               case 21:
                  class601.field9200 = new class764();
                  class601.field9200.field4347 = Integer.parseInt(var4) * 348739329;
                  break;
               case 22:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2620 = true;
                  } else {
                     field2620 = false;
                  }
                  break;
               case 23:
                  if (var4.equals(class822.field9052)) {
                     field2624 = true;
                  } else {
                     field2624 = false;
                  }
                  break;
               case 24:
                  field2630 = var4;
                  break;
               case 25:
                  field2635 = Integer.parseInt(var4) * -431443955;
                  break;
               case 26:
                  field2926 = class718.method2070(Integer.parseInt(var4), (byte)20);
                  break;
               case 27:
                  class321.field1066 = class423.method5706(Integer.parseInt(var4), 1006289259);
                  break;
               case 28:
                  field2953 = Integer.parseInt(var4) * 131907935;
                  if (745003679 * field2953 < 0 || 745003679 * field2953 >= field2670.length) {
                     field2953 = 0;
                  }
                  break;
               case 29:
                  if (var4 != null) {
                     field2825 = class554.method426(class167.method3699(var4, 509279540), (byte)84);
                     if (field2825.length < 16) {
                        field2825 = null;
                     }
                  }
                  break;
               case 30:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2634 = true;
                  } else {
                     field2634 = false;
                  }
                  break;
               case 31:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2849 = true;
                  } else {
                     field2849 = false;
                  }
                  break;
               case 32:
                  field2626 = Long.parseLong(var4) * -4477728998236397853L;
                  break;
               case 33:
                  class143.field1540 = var4;
               }
            }
         }

         if (field2909 == null) {
            field2909 = "";
         }

         class716 var5 = new class716(775068819 * field2775, -791746413 * field2784, 351263031 * field2708, field2892 * -510898275, field2926.field7326);
         class5.field4944 = this;
         this.method1301(var5, field2926.field7321, class419.field9520.field9223, 32 + 1286017487 * class419.field9520.field9224, class679.method4268(1155058529), 718, 1, field2634, (byte)-51);
      }

   }

   public final void method3961() {
      if (this.method1308(2074155450)) {
         class440[] var1 = class335.method38(-913728975);

         for(int var2 = 0; var2 < var1.length; ++var2) {
            class440 var3 = var1[var2];
            String var4 = class833.field9178.getParameter(var3.field7683);
            if (var4 != null) {
               switch(Integer.parseInt(var3.field7683)) {
               case 1:
                  field2646 = Integer.parseInt(var4) * 708949575;
                  break;
               case 2:
                  field2629 = var4;
                  if (field2629.length() > 100) {
                     field2629 = null;
                  }
                  break;
               case 3:
                  field2636 = var4;
                  break;
               case 4:
                  if (class569.field24 == null) {
                     class569.field24 = new class764();
                  }

                  class569.field24.field4347 = Integer.parseInt(var4) * 348739329;
                  break;
               case 5:
                  class507.field4016 = Integer.parseInt(var4) * -339928991;
                  break;
               case 6:
                  class419.field9520 = class408.method5469(Integer.parseInt(var4), (byte)-74);
                  if (class419.field9520 != class408.field9221 && class419.field9520 != class408.field9218 && class408.field9219 != class419.field9520 && class419.field9520 != class408.field9220) {
                     class419.field9520 = class408.field9220;
                  }
                  break;
               case 7:
                  class51.field2310 = var4;
               case 8:
               case 14:
                  break;
               case 9:
                  class221.field7347 = Integer.parseInt(var4) * -2071496301;
                  break;
               case 10:
                  field2637 = var4;
                  break;
               case 11:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2616 = true;
                  } else {
                     field2616 = false;
                  }
                  break;
               case 12:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2632 = true;
                  } else {
                     field2632 = false;
                  }
                  break;
               case 13:
                  class721.field3634 = (class916)class367.method1565(class916.method6460(-292786858), Integer.parseInt(var4), (byte)2);
                  if (class916.field10410 == class721.field3634) {
                     class721.field3634 = class916.field10418;
                  } else if (!class916.method6456(class721.field3634, 2141395178) && class721.field3634 != class916.field10415) {
                     class721.field3634 = class916.field10415;
                  }
                  break;
               case 15:
                  field2909 = var4;
                  break;
               case 16:
                  if (var4.equals(class822.field9052)) {
                     field2661 = true;
                  } else {
                     field2661 = false;
                  }
                  break;
               case 17:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2940 = true;
                  } else {
                     field2940 = false;
                  }
                  break;
               case 18:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2788 = true;
                  }
                  break;
               case 19:
               default:
                  class764.method2747("", new RuntimeException(), (short)868);
                  break;
               case 20:
                  if (class569.field24 == null) {
                     class569.field24 = new class764();
                  }

                  class569.field24.field4343 = var4;
                  break;
               case 21:
                  class601.field9200 = new class764();
                  class601.field9200.field4347 = Integer.parseInt(var4) * 348739329;
                  break;
               case 22:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2620 = true;
                  } else {
                     field2620 = false;
                  }
                  break;
               case 23:
                  if (var4.equals(class822.field9052)) {
                     field2624 = true;
                  } else {
                     field2624 = false;
                  }
                  break;
               case 24:
                  field2630 = var4;
                  break;
               case 25:
                  field2635 = Integer.parseInt(var4) * -431443955;
                  break;
               case 26:
                  field2926 = class718.method2070(Integer.parseInt(var4), (byte)67);
                  break;
               case 27:
                  class321.field1066 = class423.method5706(Integer.parseInt(var4), 2074884925);
                  break;
               case 28:
                  field2953 = Integer.parseInt(var4) * 131907935;
                  if (745003679 * field2953 < 0 || 745003679 * field2953 >= field2670.length) {
                     field2953 = 0;
                  }
                  break;
               case 29:
                  if (var4 != null) {
                     field2825 = class554.method426(class167.method3699(var4, -315411760), (byte)64);
                     if (field2825.length < 16) {
                        field2825 = null;
                     }
                  }
                  break;
               case 30:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2634 = true;
                  } else {
                     field2634 = false;
                  }
                  break;
               case 31:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2849 = true;
                  } else {
                     field2849 = false;
                  }
                  break;
               case 32:
                  field2626 = Long.parseLong(var4) * -4477728998236397853L;
                  break;
               case 33:
                  class143.field1540 = var4;
               }
            }
         }

         if (field2909 == null) {
            field2909 = "";
         }

         class716 var5 = new class716(775068819 * field2775, -791746413 * field2784, 351263031 * field2708, field2892 * -510898275, field2926.field7326);
         class5.field4944 = this;
         this.method1301(var5, field2926.field7321, class419.field9520.field9223, 32 + 1286017487 * class419.field9520.field9224, class679.method4268(-1507101618), 718, 1, field2634, (byte)-75);
      }

   }

   public final void method3957() {
      if (this.method1308(1279242864)) {
         class440[] var1 = class335.method38(2103696164);

         for(int var2 = 0; var2 < var1.length; ++var2) {
            class440 var3 = var1[var2];
            String var4 = class833.field9178.getParameter(var3.field7683);
            if (var4 != null) {
               switch(Integer.parseInt(var3.field7683)) {
               case 1:
                  field2646 = Integer.parseInt(var4) * 708949575;
                  break;
               case 2:
                  field2629 = var4;
                  if (field2629.length() > 100) {
                     field2629 = null;
                  }
                  break;
               case 3:
                  field2636 = var4;
                  break;
               case 4:
                  if (class569.field24 == null) {
                     class569.field24 = new class764();
                  }

                  class569.field24.field4347 = Integer.parseInt(var4) * 348739329;
                  break;
               case 5:
                  class507.field4016 = Integer.parseInt(var4) * -339928991;
                  break;
               case 6:
                  class419.field9520 = class408.method5469(Integer.parseInt(var4), (byte)-119);
                  if (class419.field9520 != class408.field9221 && class419.field9520 != class408.field9218 && class408.field9219 != class419.field9520 && class419.field9520 != class408.field9220) {
                     class419.field9520 = class408.field9220;
                  }
                  break;
               case 7:
                  class51.field2310 = var4;
               case 8:
               case 14:
                  break;
               case 9:
                  class221.field7347 = Integer.parseInt(var4) * -2071496301;
                  break;
               case 10:
                  field2637 = var4;
                  break;
               case 11:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2616 = true;
                  } else {
                     field2616 = false;
                  }
                  break;
               case 12:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2632 = true;
                  } else {
                     field2632 = false;
                  }
                  break;
               case 13:
                  class721.field3634 = (class916)class367.method1565(class916.method6460(1007543512), Integer.parseInt(var4), (byte)2);
                  if (class916.field10410 == class721.field3634) {
                     class721.field3634 = class916.field10418;
                  } else if (!class916.method6456(class721.field3634, 2074117544) && class721.field3634 != class916.field10415) {
                     class721.field3634 = class916.field10415;
                  }
                  break;
               case 15:
                  field2909 = var4;
                  break;
               case 16:
                  if (var4.equals(class822.field9052)) {
                     field2661 = true;
                  } else {
                     field2661 = false;
                  }
                  break;
               case 17:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2940 = true;
                  } else {
                     field2940 = false;
                  }
                  break;
               case 18:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2788 = true;
                  }
                  break;
               case 19:
               default:
                  class764.method2747("", new RuntimeException(), (short)-23039);
                  break;
               case 20:
                  if (class569.field24 == null) {
                     class569.field24 = new class764();
                  }

                  class569.field24.field4343 = var4;
                  break;
               case 21:
                  class601.field9200 = new class764();
                  class601.field9200.field4347 = Integer.parseInt(var4) * 348739329;
                  break;
               case 22:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2620 = true;
                  } else {
                     field2620 = false;
                  }
                  break;
               case 23:
                  if (var4.equals(class822.field9052)) {
                     field2624 = true;
                  } else {
                     field2624 = false;
                  }
                  break;
               case 24:
                  field2630 = var4;
                  break;
               case 25:
                  field2635 = Integer.parseInt(var4) * -431443955;
                  break;
               case 26:
                  field2926 = class718.method2070(Integer.parseInt(var4), (byte)122);
                  break;
               case 27:
                  class321.field1066 = class423.method5706(Integer.parseInt(var4), 556012524);
                  break;
               case 28:
                  field2953 = Integer.parseInt(var4) * 131907935;
                  if (745003679 * field2953 < 0 || 745003679 * field2953 >= field2670.length) {
                     field2953 = 0;
                  }
                  break;
               case 29:
                  if (var4 != null) {
                     field2825 = class554.method426(class167.method3699(var4, -394383445), (byte)114);
                     if (field2825.length < 16) {
                        field2825 = null;
                     }
                  }
                  break;
               case 30:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2634 = true;
                  } else {
                     field2634 = false;
                  }
                  break;
               case 31:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2849 = true;
                  } else {
                     field2849 = false;
                  }
                  break;
               case 32:
                  field2626 = Long.parseLong(var4) * -4477728998236397853L;
                  break;
               case 33:
                  class143.field1540 = var4;
               }
            }
         }

         if (field2909 == null) {
            field2909 = "";
         }

         class716 var5 = new class716(775068819 * field2775, -791746413 * field2784, 351263031 * field2708, field2892 * -510898275, field2926.field7326);
         class5.field4944 = this;
         this.method1301(var5, field2926.field7321, class419.field9520.field9223, 32 + 1286017487 * class419.field9520.field9224, class679.method4268(1164456300), 718, 1, field2634, (byte)22);
      }

   }

   public final void method3964() {
      if (this.method1308(-967809085)) {
         class440[] var1 = class335.method38(103288217);

         for(int var2 = 0; var2 < var1.length; ++var2) {
            class440 var3 = var1[var2];
            String var4 = class833.field9178.getParameter(var3.field7683);
            if (var4 != null) {
               switch(Integer.parseInt(var3.field7683)) {
               case 1:
                  field2646 = Integer.parseInt(var4) * 708949575;
                  break;
               case 2:
                  field2629 = var4;
                  if (field2629.length() > 100) {
                     field2629 = null;
                  }
                  break;
               case 3:
                  field2636 = var4;
                  break;
               case 4:
                  if (class569.field24 == null) {
                     class569.field24 = new class764();
                  }

                  class569.field24.field4347 = Integer.parseInt(var4) * 348739329;
                  break;
               case 5:
                  class507.field4016 = Integer.parseInt(var4) * -339928991;
                  break;
               case 6:
                  class419.field9520 = class408.method5469(Integer.parseInt(var4), (byte)-68);
                  if (class419.field9520 != class408.field9221 && class419.field9520 != class408.field9218 && class408.field9219 != class419.field9520 && class419.field9520 != class408.field9220) {
                     class419.field9520 = class408.field9220;
                  }
                  break;
               case 7:
                  class51.field2310 = var4;
               case 8:
               case 14:
                  break;
               case 9:
                  class221.field7347 = Integer.parseInt(var4) * -2071496301;
                  break;
               case 10:
                  field2637 = var4;
                  break;
               case 11:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2616 = true;
                  } else {
                     field2616 = false;
                  }
                  break;
               case 12:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2632 = true;
                  } else {
                     field2632 = false;
                  }
                  break;
               case 13:
                  class721.field3634 = (class916)class367.method1565(class916.method6460(-1055186700), Integer.parseInt(var4), (byte)2);
                  if (class916.field10410 == class721.field3634) {
                     class721.field3634 = class916.field10418;
                  } else if (!class916.method6456(class721.field3634, 2064566243) && class721.field3634 != class916.field10415) {
                     class721.field3634 = class916.field10415;
                  }
                  break;
               case 15:
                  field2909 = var4;
                  break;
               case 16:
                  if (var4.equals(class822.field9052)) {
                     field2661 = true;
                  } else {
                     field2661 = false;
                  }
                  break;
               case 17:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2940 = true;
                  } else {
                     field2940 = false;
                  }
                  break;
               case 18:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2788 = true;
                  }
                  break;
               case 19:
               default:
                  class764.method2747("", new RuntimeException(), (short)-24314);
                  break;
               case 20:
                  if (class569.field24 == null) {
                     class569.field24 = new class764();
                  }

                  class569.field24.field4343 = var4;
                  break;
               case 21:
                  class601.field9200 = new class764();
                  class601.field9200.field4347 = Integer.parseInt(var4) * 348739329;
                  break;
               case 22:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2620 = true;
                  } else {
                     field2620 = false;
                  }
                  break;
               case 23:
                  if (var4.equals(class822.field9052)) {
                     field2624 = true;
                  } else {
                     field2624 = false;
                  }
                  break;
               case 24:
                  field2630 = var4;
                  break;
               case 25:
                  field2635 = Integer.parseInt(var4) * -431443955;
                  break;
               case 26:
                  field2926 = class718.method2070(Integer.parseInt(var4), (byte)95);
                  break;
               case 27:
                  class321.field1066 = class423.method5706(Integer.parseInt(var4), 1190807224);
                  break;
               case 28:
                  field2953 = Integer.parseInt(var4) * 131907935;
                  if (745003679 * field2953 < 0 || 745003679 * field2953 >= field2670.length) {
                     field2953 = 0;
                  }
                  break;
               case 29:
                  if (var4 != null) {
                     field2825 = class554.method426(class167.method3699(var4, -1400546512), (byte)95);
                     if (field2825.length < 16) {
                        field2825 = null;
                     }
                  }
                  break;
               case 30:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2634 = true;
                  } else {
                     field2634 = false;
                  }
                  break;
               case 31:
                  if (var4.equalsIgnoreCase(class822.field9052)) {
                     field2849 = true;
                  } else {
                     field2849 = false;
                  }
                  break;
               case 32:
                  field2626 = Long.parseLong(var4) * -4477728998236397853L;
                  break;
               case 33:
                  class143.field1540 = var4;
               }
            }
         }

         if (field2909 == null) {
            field2909 = "";
         }

         class716 var5 = new class716(775068819 * field2775, -791746413 * field2784, 351263031 * field2708, field2892 * -510898275, field2926.field7326);
         class5.field4944 = this;
         this.method1301(var5, field2926.field7321, class419.field9520.field9223, 32 + 1286017487 * class419.field9520.field9224, class679.method4268(-418428626), 718, 1, field2634, (byte)29);
      }

   }

   final void method1331() {
      if (class615.field8903.field9137.method3689(-1480003909) == 2) {
         try {
            this.method1766((byte)0);
         } catch (ThreadDeath var2) {
            throw var2;
         } catch (Throwable var3) {
            class764.method2747(var3.getMessage() + " " + this.method1311((byte)-19), var3, (short)-2557);
            field2643 = true;
            class337.method77(0, false, 622850291);
         }
      } else {
         this.method1766((byte)0);
      }

   }

   static final void method1771(class744 var0, int var1) {
      try {
         var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = class495.field8097 * -1537941929;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "client.amm(" + ')');
      }
   }
}
