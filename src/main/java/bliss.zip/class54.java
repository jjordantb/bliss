public interface class54 {
   boolean method1537(int var1);

   void method1538(int var1);

   void method1543(boolean var1, byte var2);
}
