public interface class54 {
   boolean method1537(int var1);

   void method1538(int var1);

   boolean method1539();

   void method1540();

   void method1541(boolean var1);

   boolean method1542();

   void method1543(boolean var1, byte var2);

   boolean method1544();
}
