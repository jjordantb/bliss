public abstract class class959 extends class345 {
   volatile boolean field3464 = true;
   boolean field3465;
   boolean field3466;

   abstract byte[] method2033(short var1);

   abstract int method2036(int var1);
}
