public class class797 extends class770 implements class297 {
   long field474;

   public native void method6550(boolean var1);

   class797(class955 var1) {
   }
}
