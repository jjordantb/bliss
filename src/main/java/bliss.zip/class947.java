public class class947 extends RuntimeException {
   static class180 field3314;
   static class403[] field3315;
}
