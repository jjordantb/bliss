public class class586 {
   static final boolean method301(int var0, int var1) {
      return (var0 & 33) != 0;
   }

   static final boolean method302(int var0, int var1) {
      return (var0 & 52) != 0;
   }

   static final boolean method303(int var0, int var1) {
      return (var0 & 544) == 544 | (var0 & 24) != 0;
   }

   static final boolean method304(int var0, int var1) {
      return (var0 & 540800) != 0;
   }

   static final boolean method305(int var0, int var1) {
      return (var0 & 256) != 0;
   }

   static final boolean method306(int var0, int var1) {
      return false;
   }

   static final boolean method307(int var0, int var1) {
      return (var0 & '耀') != 0;
   }

   static final boolean method308(int var0, int var1) {
      return (var0 & '얀') != 0;
   }

   static final boolean method309(int var0, int var1) {
      return (var0 & 2048) != 0;
   }

   static final boolean method310(int var0, int var1) {
      return (var0 & 2048) != 0;
   }

   static final boolean method311(int var0, int var1) {
      return method332(var0, var1) & ((var0 & 8192) != 0 | method303(var0, var1) | method326(var0, var1));
   }

   static final boolean method312(int var0, int var1) {
      return (var0 & 34) != 0;
   }

   static final boolean method313(int var0, int var1) {
      return (var0 & 2048) != 0;
   }

   static final boolean method314(int var0, int var1) {
      return (var0 & 458752) != 0 || method301(var0, var1) || method327(var0, var1);
   }

   static final boolean method315(int var0, int var1) {
      return (var0 & 458752) != 0 || method312(var0, var1) || method327(var0, var1);
   }

   static final boolean method316(int var0, int var1) {
      return (var0 & 458752) != 0 || method302(var0, var1) || method327(var0, var1);
   }

   static final boolean method317(int var0, int var1) {
      boolean var2 = (var1 & 55) != 0 ? method311(var0, var1) : method322(var0, var1);
      return (var0 & 65536) != 0 | method303(var0, var1) | var2;
   }

   static final boolean method318(int var0, int var1) {
      return method306(var0, var1) || method334(var0, var1);
   }

   static final boolean method319(int var0, int var1) {
      return (var0 & 384) != 0;
   }

   static final boolean method320(int var0, int var1) {
      return (var0 & 32) != 0;
   }

   static final boolean method321(int var0, int var1) {
      return (var0 & 1024) != 0;
   }

   static final boolean method322(int var0, int var1) {
      if (!method309(var0, var1)) {
         return false;
      } else {
         return (var0 & '退') != 0 | method304(var0, var1) | method305(var0, var1) ? true : (var1 & 55) == 0 & ((var0 & 8192) != 0 | method303(var0, var1) | method326(var0, var1));
      }
   }

   static final boolean method323(int var0, int var1) {
      return (var0 & 2048) != 0 | method307(var0, var1) || method322(var0, var1);
   }

   static final boolean method324(int var0, int var1) {
      return (var0 & 16) != 0;
   }

   static final boolean method325(int var0, int var1) {
      return (var0 & 2048) != 0;
   }

   static final boolean method326(int var0, int var1) {
      return (var0 & 65536) != 0;
   }

   static final boolean method327(int var0, int var1) {
      return (method301(var0, var1) | method312(var0, var1) | method302(var0, var1)) & method313(var0, var1);
   }

   static final boolean method328(int var0, int var1) {
      return method324(var0, var1) & method310(var0, var1);
   }

   static final boolean method329(int var0, int var1) {
      return (var0 & 262144) != 0 | method305(var0, var1) || method322(var0, var1);
   }

   static final boolean method330(int var0, int var1) {
      return method304(var0, var1) || method322(var0, var1);
   }

   static final boolean method331(int var0, int var1) {
      return (var0 & 55) != 0;
   }

   static final boolean method332(int var0, int var1) {
      return (var0 & 2048) != 0 && (var1 & 55) != 0;
   }

   class586() throws Throwable {
      throw new Error();
   }

   static final boolean method333(int var0, int var1) {
      return (var0 & 393216) != 0 | method324(var0, var1) || method328(var0, var1);
   }

   static final boolean method334(int var0, int var1) {
      return method306(var0, var1) & method325(var0, var1);
   }
}
