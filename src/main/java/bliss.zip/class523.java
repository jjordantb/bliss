public abstract class class523 {
   public class801 field4361;
   public class801 field4362;
   public class525 field4363;
   protected class325 field4364;
   public class344 field4365 = new class344();
   public class344 field4366 = new class344();
   public class344 field4367 = new class344();
   public int field4368;
   public class92 field4369;

   public abstract void method2762(int var1, int var2);

   public abstract void method2763();

   public abstract void method2764();

   class523(class325 var1) {
      this.field4364 = var1;
   }
}
