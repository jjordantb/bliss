public class class786 {
   short field3796;
   short[] field3797;
   short[] field3798;
   short[] field3799;
   short[] field3800;
   short[] field3801;
   short[] field3802;
   short[] field3803;
   short field3804;
   short[] field3805;
   short[] field3806;
   byte field3807;
   int[] field3808;
   int[] field3809;
}
