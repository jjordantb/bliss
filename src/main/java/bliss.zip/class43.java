public class class43 extends class347 {
   public static class180 field5088;
   public static int field5089 = 1345470509;
   int field5090 = 715315885;
   int field5091;
   int field5092;
   int[] field5093;

   void method3060(int var1, class907 var2) {
      if (var1 == 0) {
         this.field5090 = var2.method6374() * -715315885;
      }

   }

   int method207(short var1) {
      try {
         return -2121898277 * this.field5090;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "agy.q(" + ')');
      }
   }

   void method3061() {
      super.method200(1881168514);
      this.field5093 = null;
   }

   void method200(int var1) {
      try {
         super.method200(1881168514);
         this.field5093 = null;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "agy.f(" + ')');
      }
   }

   boolean method3062(int var1) {
      try {
         if (this.field5093 != null) {
            return true;
         } else if (-2121898277 * this.field5090 >= 0) {
            class922 var2 = field5089 * -1132597157 >= 0 ? class922.method6242(field5088, -1132597157 * field5089, -2121898277 * this.field5090) : class922.method6234(field5088, this.field5090 * -2121898277);
            var2.method6239();
            this.field5093 = var2.method6245();
            this.field5091 = -506570825 * var2.field10269;
            this.field5092 = -274319933 * var2.field10273;
            return true;
         } else {
            return false;
         }
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "agy.ac(" + ')');
      }
   }

   void method209(int var1, class907 var2, byte var3) {
      try {
         if (var1 == 0) {
            this.field5090 = var2.method6374() * -715315885;
         }

      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "agy.r(" + ')');
      }
   }

   int[][] method204(int var1, byte var2) {
      try {
         int[][] var3 = this.field266.method162(var1, (byte)40);
         if (this.field266.field211 && this.method3062(-2021836506)) {
            int[] var4 = var3[0];
            int[] var5 = var3[1];
            int[] var6 = var3[2];
            int var7 = 1274885639 * this.field5091 * (461985445 * class322.field832 != -2125962517 * this.field5092 ? this.field5092 * -2125962517 * var1 / (class322.field832 * 461985445) : var1);
            int var8;
            int var9;
            if (this.field5091 * 1274885639 == -1474554145 * class322.field831) {
               for(var8 = 0; var8 < class322.field831 * -1474554145; ++var8) {
                  var9 = this.field5093[var7++];
                  var6[var8] = (var9 & 255) << 4;
                  var5[var8] = (var9 & '\uff00') >> 4;
                  var4[var8] = (var9 & 16711680) >> 12;
               }
            } else {
               for(var8 = 0; var8 < -1474554145 * class322.field831; ++var8) {
                  var9 = var8 * this.field5091 * 1274885639 / (class322.field831 * -1474554145);
                  int var10 = this.field5093[var9 + var7];
                  var6[var8] = (var10 & 255) << 4;
                  var5[var8] = (var10 & '\uff00') >> 4;
                  var4[var8] = (var10 & 16711680) >> 12;
               }
            }
         }

         return var3;
      } catch (RuntimeException var11) {
         throw class158.method3445(var11, "agy.k(" + ')');
      }
   }

   void method3063(int var1, class907 var2) {
      if (var1 == 0) {
         this.field5090 = var2.method6374() * -715315885;
      }

   }

   public class43() {
      super(0, false);
   }

   int[][] method3064(int var1) {
      int[][] var2 = this.field266.method162(var1, (byte)114);
      if (this.field266.field211 && this.method3062(1831903701)) {
         int[] var3 = var2[0];
         int[] var4 = var2[1];
         int[] var5 = var2[2];
         int var6 = 1274885639 * this.field5091 * (461985445 * class322.field832 != -2125962517 * this.field5092 ? this.field5092 * -2125962517 * var1 / (class322.field832 * 461985445) : var1);
         int var7;
         int var8;
         if (this.field5091 * 1274885639 == -1474554145 * class322.field831) {
            for(var7 = 0; var7 < class322.field831 * -1474554145; ++var7) {
               var8 = this.field5093[var6++];
               var5[var7] = (var8 & 255) << 4;
               var4[var7] = (var8 & '\uff00') >> 4;
               var3[var7] = (var8 & 16711680) >> 12;
            }
         } else {
            for(var7 = 0; var7 < -1474554145 * class322.field831; ++var7) {
               var8 = var7 * this.field5091 * 1274885639 / (class322.field831 * -1474554145);
               int var9 = this.field5093[var8 + var6];
               var5[var7] = (var9 & 255) << 4;
               var4[var7] = (var9 & '\uff00') >> 4;
               var3[var7] = (var9 & 16711680) >> 12;
            }
         }
      }

      return var2;
   }

   int[][] method3065(int var1) {
      int[][] var2 = this.field266.method162(var1, (byte)9);
      if (this.field266.field211 && this.method3062(508632010)) {
         int[] var3 = var2[0];
         int[] var4 = var2[1];
         int[] var5 = var2[2];
         int var6 = 1274885639 * this.field5091 * (461985445 * class322.field832 != -2125962517 * this.field5092 ? this.field5092 * -2125962517 * var1 / (class322.field832 * 461985445) : var1);
         int var7;
         int var8;
         if (this.field5091 * 1274885639 == -1474554145 * class322.field831) {
            for(var7 = 0; var7 < class322.field831 * -1474554145; ++var7) {
               var8 = this.field5093[var6++];
               var5[var7] = (var8 & 255) << 4;
               var4[var7] = (var8 & '\uff00') >> 4;
               var3[var7] = (var8 & 16711680) >> 12;
            }
         } else {
            for(var7 = 0; var7 < -1474554145 * class322.field831; ++var7) {
               var8 = var7 * this.field5091 * 1274885639 / (class322.field831 * -1474554145);
               int var9 = this.field5093[var8 + var6];
               var5[var7] = (var9 & 255) << 4;
               var4[var7] = (var9 & '\uff00') >> 4;
               var3[var7] = (var9 & 16711680) >> 12;
            }
         }
      }

      return var2;
   }

   int method3066() {
      return -2121898277 * this.field5090;
   }

   static final void method3067(class744 var0, int var1) {
      try {
         if (class730.field2901 != null) {
            var0.field3157[(var0.field3158 += 969361751) * -203050393 - 1] = class730.field2901;
         } else {
            var0.field3157[(var0.field3158 += 969361751) * -203050393 - 1] = "";
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "agy.wj(" + ')');
      }
   }
}
