public abstract class class142 extends class345 {
   int field1421;

   abstract Object method1075(int var1);

   abstract boolean method1076(int var1);

   class142(int var1) {
      this.field1421 = -1846372093 * var1;
   }
}
