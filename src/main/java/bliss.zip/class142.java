public abstract class class142 extends class345 {
   int field1421;

   abstract boolean method1074();

   abstract Object method1075(int var1);

   abstract boolean method1076(int var1);

   abstract boolean method1077();

   abstract Object method1078();

   abstract boolean method1079();

   class142(int var1) {
      this.field1421 = 1222339519 * var1;
   }

   abstract Object method1080();
}
