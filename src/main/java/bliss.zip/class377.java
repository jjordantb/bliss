import jaclib.memory.I;

public class class377 extends class763 implements class269 {
   int field1397;

   public int method4542() {
      return this.field1397;
   }

   class377(class13 var1, int var2, I var3) {
      super(var1, var3);
      this.field1397 = var2;
   }

   class377(class13 var1, int var2, byte[] var3, int var4) {
      super(var1, var3, var4);
      this.field1397 = var2;
   }

   public int method4543() {
      return this.field1397;
   }

   public long method4544() {
      return this.field4354.f();
   }

   public int method4539() {
      return 0;
   }

   public int method4537() {
      return 0;
   }

   public void method4536(int var1, byte[] var2, int var3) {
      this.method2752(var2, var3);
      this.field1397 = var1;
   }

   public int method4534() {
      return 0;
   }

   public int method4540() {
      return 0;
   }

   public int method4541() {
      return this.field1397;
   }

   public int method4538() {
      return 0;
   }

   public long method4535() {
      return this.field4354.f();
   }

   public long method4533() {
      return this.field4354.f();
   }

   public void method4545(int var1, byte[] var2, int var3) {
      this.method2752(var2, var3);
      this.field1397 = var1;
   }
}
