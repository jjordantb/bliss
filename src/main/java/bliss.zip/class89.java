public abstract class class89 extends class345 {
   class195 field1135;
   int field1136;

   abstract Object method952();

   abstract boolean method953();

   abstract Object method954();

   abstract boolean method955();

   abstract Object method956();

   class89(class195 var1, int var2) {
      this.field1135 = var1;
      this.field1136 = var2;
   }
}
