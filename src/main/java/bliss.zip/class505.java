public class class505 extends class824 implements class265 {
   boolean field4133;
   class879 field4134;
   class770 field4135;
   int field4136;
   boolean field4137;
   byte field4138;
   class240 field4139;
   boolean field4140;
   class719 field4141;
   boolean field4142;

   public class719 method2165(class848 var1, byte var2) {
      try {
         class32 var3 = this.method1511().field7637;
         if (this.field4141 == null) {
            this.field4141 = class905.method6344((int)var3.field5296, (int)var3.field5300, (int)var3.field5299, this.method2606(var1, 0, (byte)68), 2029931481);
         }

         return this.field4141;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "wo.bc(" + ')');
      }
   }

   boolean method2176() {
      return this.field4134 != null ? this.field4134.method5989() : false;
   }

   public int method2168(int var1) {
      try {
         return this.field4134 != null ? this.field4134.method5976() : 0;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wo.bm(" + ')');
      }
   }

   class879 method2606(class848 var1, int var2, byte var3) {
      try {
         if (this.field4134 != null && var1.method4836(this.field4134.method5948(), var2) == 0) {
            return this.field4134;
         } else {
            class486 var4 = this.method2607(var1, var2, false, -1886813239);
            return var4 != null ? (class879)var4.field8554 : null;
         }
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "wo.by(" + ')');
      }
   }

   class486 method2607(class848 var1, int var2, boolean var3, int var4) {
      try {
         class50 var5 = this.field4139.method4713(2049836463 * this.field4136);
         class454 var6;
         class454 var7;
         if (this.field4137) {
            var6 = this.field3638.field3866[this.field3640];
            var7 = this.field3638.field3864[0];
         } else {
            var6 = this.field3638.field3864[this.field3640];
            if (this.field3640 < 3) {
               var7 = this.field3638.field3864[this.field3640 + 1];
            } else {
               var7 = null;
            }
         }

         class32 var8 = this.method1511().field7637;
         return var5.method1495(var1, var2, class15.field6918.field6921 * -1976050083, this.field4138, var6, var7, (int)var8.field5296, (int)var8.field5300, (int)var8.field5299, var3, (class552)null, -474476261);
      } catch (RuntimeException var9) {
         throw class158.method3445(var9, "wo.bl(" + ')');
      }
   }

   boolean method2158() {
      return this.field4134 != null ? this.field4134.method5989() : false;
   }

   public int method4557() {
      return this.field4138;
   }

   void method2164(class848 var1, int var2) {
   }

   boolean method2157(class848 var1, int var2, int var3, byte var4) {
      try {
         class879 var5 = this.method2606(var1, 131072, (byte)22);
         if (var5 != null) {
            class135 var6 = this.method1521();
            return var5.method6097(var2, var3, var6, false, 0);
         } else {
            return false;
         }
      } catch (RuntimeException var7) {
         throw class158.method3445(var7, "wo.bu(" + ')');
      }
   }

   boolean method2173(int var1) {
      try {
         return this.field4133;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wo.bw(" + ')');
      }
   }

   void method2162(class848 var1, class963 var2, int var3, int var4, int var5, boolean var6, int var7) {
      try {
         if (var2 instanceof class505) {
            class505 var8 = (class505)var2;
            if (this.field4134 != null && var8.field4134 != null) {
               this.field4134.method5994(var8.field4134, var3, var4, var5, var6);
            }
         }

      } catch (RuntimeException var9) {
         throw class158.method3445(var9, "wo.bk(" + ')');
      }
   }

   void method2205(byte var1) {
      try {
         this.field4133 = false;
         if (this.field4134 != null) {
            this.field4134.method5947(this.field4134.method5948() & -65537);
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wo.bq(" + ')');
      }
   }

   boolean method2189() {
      return this.field4134 != null ? this.field4134.method5989() : false;
   }

   public int method4548(int var1) {
      try {
         return class15.field6918.field6921 * -1976050083;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wo.f(" + ')');
      }
   }

   public int method4549(short var1) {
      try {
         return this.field4138;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wo.b(" + ')');
      }
   }

   public void method4550(byte var1) {
      try {
         if (this.field4134 != null) {
            this.field4134.method6093();
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wo.p(" + ')');
      }
   }

   public boolean method4558(int var1) {
      try {
         return this.field4142;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wo.i(" + ')');
      }
   }

   boolean method2190() {
      return this.field4134 != null ? this.field4134.method5989() : false;
   }

   public void method4556(class848 var1, int var2) {
      try {
         Object var3 = null;
         class770 var5;
         if (this.field4135 == null && this.field4142) {
            class486 var4 = this.method2607(var1, 262144, true, -1850458180);
            var5 = (class770)(var4 != null ? var4.field8555 : null);
         } else {
            var5 = this.field4135;
            this.field4135 = null;
         }

         class32 var7 = this.method1511().field7637;
         if (var5 != null) {
            this.field3638.method2441(var5, this.field3640, (int)var7.field5296, (int)var7.field5299, (boolean[])null, 174451452);
         }

      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "wo.d(" + ')');
      }
   }

   public int method4564() {
      return this.field4136 * 2049836463;
   }

   public int method2187() {
      return this.field4134 != null ? this.field4134.method5976() : 0;
   }

   public int method4554() {
      return class15.field6918.field6921 * -1976050083;
   }

   public int method4561() {
      return this.field4138;
   }

   boolean method2191() {
      return this.field4133;
   }

   public void method4553() {
      if (this.field4134 != null) {
         this.field4134.method6093();
      }

   }

   public boolean method4560() {
      return this.field4142;
   }

   public void method4547(class848 var1) {
      Object var2 = null;
      class770 var4;
      if (this.field4135 == null && this.field4142) {
         class486 var3 = this.method2607(var1, 262144, true, -1804274121);
         var4 = (class770)(var3 != null ? var3.field8555 : null);
      } else {
         var4 = this.field4135;
         this.field4135 = null;
      }

      class32 var5 = this.method1511().field7637;
      if (var4 != null) {
         this.field3638.method2449(var4, this.field3640, (int)var5.field5296, (int)var5.field5299, (boolean[])null, -1115505976);
      }

   }

   public void method4562(class848 var1) {
      Object var2 = null;
      class770 var4;
      if (this.field4135 == null && this.field4142) {
         class486 var3 = this.method2607(var1, 262144, true, -2127866030);
         var4 = (class770)(var3 != null ? var3.field8555 : null);
      } else {
         var4 = this.field4135;
         this.field4135 = null;
      }

      class32 var5 = this.method1511().field7637;
      if (var4 != null) {
         this.field3638.method2441(var4, this.field3640, (int)var5.field5296, (int)var5.field5299, (boolean[])null, 1644514804);
      }

   }

   public void method4559(class848 var1) {
      Object var2 = null;
      class770 var4;
      if (this.field4135 == null && this.field4142) {
         class486 var3 = this.method2607(var1, 262144, true, -2044645596);
         var4 = (class770)(var3 != null ? var3.field8555 : null);
      } else {
         var4 = this.field4135;
         this.field4135 = null;
      }

      class32 var5 = this.method1511().field7637;
      if (var4 != null) {
         this.field3638.method2441(var4, this.field3640, (int)var5.field5296, (int)var5.field5299, (boolean[])null, 710992193);
      }

   }

   public class505(class545 var1, class848 var2, class240 var3, class50 var4, int var5, int var6, int var7, int var8, int var9, boolean var10, int var11, boolean var12) {
      super(var1, var7, var8, var9, var5, var6, var4.field2250 * -228547261);
      this.field4139 = var3;
      this.field4136 = 646380829 * var4.field2197;
      this.field4137 = var10;
      this.field4138 = (byte)var11;
      this.field4140 = var4.field2214 * 1532834983 != 0 && !var10;
      this.field4133 = var12;
      this.field4142 = var2.method4916() && var4.field2265 && !this.field4137 && class615.field8903.field9147.method5182(-1930969884) != 0;
      int var13 = 2048;
      if (this.field4133) {
         var13 |= 65536;
      }

      if (var4.field2273) {
         var13 |= 524288;
      }

      class486 var14 = this.method2607(var2, var13, this.field4142, -2037171144);
      if (var14 != null) {
         this.field4134 = (class879)var14.field8554;
         this.field4135 = (class770)var14.field8555;
         if (this.field4133 || var4.field2273) {
            this.field4134 = this.field4134.method6017((byte)0, var13, false);
            if (var4.field2273) {
               class923 var15 = class730.field2697.method5274(-1945230052);
               this.field4134.method5987(1599271859 * var15.field10290, var15.field10291 * 1630923113, -1560648831 * var15.field10292, -57569897 * var15.field10293);
            }
         }
      }

      this.method2169(1, -105360757);
   }

   boolean method2172() {
      if (this.field4134 != null) {
         return !this.field4134.method6036();
      } else {
         return true;
      }
   }

   boolean method2181() {
      if (this.field4134 != null) {
         return !this.field4134.method6036();
      } else {
         return true;
      }
   }

   public class719 method2174(class848 var1) {
      class32 var2 = this.method1511().field7637;
      if (this.field4141 == null) {
         this.field4141 = class905.method6344((int)var2.field5296, (int)var2.field5300, (int)var2.field5299, this.method2606(var1, 0, (byte)71), 1982463178);
      }

      return this.field4141;
   }

   public class719 method2175(class848 var1) {
      class32 var2 = this.method1511().field7637;
      if (this.field4141 == null) {
         this.field4141 = class905.method6344((int)var2.field5296, (int)var2.field5300, (int)var2.field5299, this.method2606(var1, 0, (byte)44), 2033804861);
      }

      return this.field4141;
   }

   public int method4555() {
      return class15.field6918.field6921 * -1976050083;
   }

   void method2178(class848 var1) {
   }

   void method2180(class848 var1) {
   }

   boolean method2179(class848 var1, int var2, int var3) {
      class879 var4 = this.method2606(var1, 131072, (byte)43);
      if (var4 != null) {
         class135 var5 = this.method1521();
         return var4.method6097(var2, var3, var5, false, 0);
      } else {
         return false;
      }
   }

   boolean method2192(class848 var1, int var2, int var3) {
      class879 var4 = this.method2606(var1, 131072, (byte)125);
      if (var4 != null) {
         class135 var5 = this.method1521();
         return var4.method6097(var2, var3, var5, false, 0);
      } else {
         return false;
      }
   }

   boolean method2159(class848 var1, int var2, int var3) {
      class879 var4 = this.method2606(var1, 131072, (byte)126);
      if (var4 != null) {
         class135 var5 = this.method1521();
         return var4.method6097(var2, var3, var5, false, 0);
      } else {
         return false;
      }
   }

   void method2182(class848 var1, class963 var2, int var3, int var4, int var5, boolean var6) {
      if (var2 instanceof class505) {
         class505 var7 = (class505)var2;
         if (this.field4134 != null && var7.field4134 != null) {
            this.field4134.method5994(var7.field4134, var3, var4, var5, var6);
         }
      }

   }

   class192 method2177(class848 var1) {
      if (this.field4134 == null) {
         return null;
      } else {
         class135 var2 = this.method1521();
         class192 var3 = class221.method4033(this.field4140, 1241916364);
         this.field4134.method5965(var2, this.field3642[0], 0);
         return var3;
      }
   }

   void method2184() {
      this.field4133 = false;
      if (this.field4134 != null) {
         this.field4134.method5947(this.field4134.method5948() & -65537);
      }

   }

   void method2185() {
      this.field4133 = false;
      if (this.field4134 != null) {
         this.field4134.method5947(this.field4134.method5948() & -65537);
      }

   }

   public int method2186() {
      return this.field4134 != null ? this.field4134.method5976() : 0;
   }

   public void method4563(class848 var1) {
      Object var2 = null;
      class770 var4;
      if (this.field4135 == null && this.field4142) {
         class486 var3 = this.method2607(var1, 262144, true, -1967364085);
         var4 = (class770)(var3 != null ? var3.field8555 : null);
      } else {
         var4 = this.field4135;
         this.field4135 = null;
      }

      class32 var5 = this.method1511().field7637;
      if (var4 != null) {
         this.field3638.method2441(var4, this.field3640, (int)var5.field5296, (int)var5.field5299, (boolean[])null, 193928700);
      }

   }

   public int method2188() {
      return this.field4134 != null ? this.field4134.method5976() : 0;
   }

   class192 method2201(class848 var1, int var2) {
      try {
         if (this.field4134 == null) {
            return null;
         } else {
            class135 var3 = this.method1521();
            class192 var4 = class221.method4033(this.field4140, 2139686110);
            this.field4134.method5965(var3, this.field3642[0], 0);
            return var4;
         }
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "wo.bo(" + ')');
      }
   }

   public void method4552(class848 var1, int var2) {
      try {
         Object var3 = null;
         class770 var5;
         if (this.field4135 == null && this.field4142) {
            class486 var4 = this.method2607(var1, 262144, true, -2121821591);
            var5 = (class770)(var4 != null ? var4.field8555 : null);
         } else {
            var5 = this.field4135;
            this.field4135 = null;
         }

         class32 var7 = this.method1511().field7637;
         if (var5 != null) {
            this.field3638.method2449(var5, this.field3640, (int)var7.field5296, (int)var7.field5299, (boolean[])null, -412237236);
         }

      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "wo.k(" + ')');
      }
   }

   boolean method2156() {
      return this.field4134 != null ? this.field4134.method5989() : false;
   }

   void method2195(class848 var1, class963 var2, int var3, int var4, int var5, boolean var6) {
      if (var2 instanceof class505) {
         class505 var7 = (class505)var2;
         if (this.field4134 != null && var7.field4134 != null) {
            this.field4134.method5994(var7.field4134, var3, var4, var5, var6);
         }
      }

   }

   public int method4551(byte var1) {
      try {
         return this.field4136 * 2049836463;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wo.a(" + ')');
      }
   }

   boolean method2160() {
      if (this.field4134 != null) {
         return !this.field4134.method6036();
      } else {
         return true;
      }
   }

   boolean method2207() {
      return this.field4133;
   }

   boolean method2193() {
      return this.field4133;
   }

   boolean method2194() {
      return this.field4133;
   }

   boolean method2183(short var1) {
      try {
         return this.field4134 != null ? this.field4134.method5989() : false;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wo.be(" + ')');
      }
   }

   boolean method2206(byte var1) {
      try {
         if (this.field4134 != null) {
            return !this.field4134.method6036();
         } else {
            return true;
         }
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wo.bf(" + ')');
      }
   }

   static final void method2608(class744 var0, int var1) {
      try {
         int var2 = var0.field3174[var0.field3176 * 1883543357];
         int var3 = var0.field3161[(var0.field3156 -= -391880689) * 681479919];
         if (var3 >= 0 && var3 < var0.field3153[var2]) {
            var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = var0.field3155[var2][var3];
         } else {
            throw new RuntimeException();
         }
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "wo.au(" + ')');
      }
   }
}
