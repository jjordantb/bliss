public class class750 {
   boolean field4208;
   boolean field4209;
   class525 field4210;
   class525 field4211;

   boolean method2664() {
      return this.field4208 && !this.field4209;
   }

   class750(boolean var1) {
      this.field4209 = var1;
   }

   void method2665() {
      if (this.field4211 != null) {
         this.field4211.method2755();
      }

      this.field4208 = false;
   }
}
