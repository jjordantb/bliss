import java.io.IOException;

public class class802 extends IOException {
   class802(String var1) {
      super(var1);
   }
}
