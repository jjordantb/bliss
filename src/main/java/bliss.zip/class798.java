public class class798 extends class106 {
   long field504 = 9050845699687573611L;
   String field505 = null;

   void method171(class420 var1) {
      var1.method5782(31082448682122173L * this.field504, this.field505, 0, -783761378);
   }

   class798(class120 var1) {
   }

   void method170(class420 var1, byte var2) {
      try {
         var1.method5782(31082448682122173L * this.field504, this.field505, 0, -783761378);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "afd.f(" + ')');
      }
   }

   void method168(class907 var1, int var2) {
      try {
         if (var1.method6371() != 255) {
            var1.field10376 -= 116413311;
            this.field504 = var1.method6375((short)32060) * -9050845699687573611L;
         }

         this.field505 = var1.method6429(-517364695);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "afd.a(" + ')');
      }
   }

   void method172(class907 var1) {
      if (var1.method6371() != 255) {
         var1.field10376 -= 116413311;
         this.field504 = var1.method6375((short)4817) * -9050845699687573611L;
      }

      this.field505 = var1.method6429(-517364695);
   }

   void method169(class907 var1) {
      if (var1.method6371() != 255) {
         var1.field10376 -= 116413311;
         this.field504 = var1.method6375((short)2363) * -9050845699687573611L;
      }

      this.field505 = var1.method6429(-517364695);
   }

   static final void method433(class744 var0, int var1) {
      try {
         var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = class647.method5488(-333964684).method89(694163818);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "afd.ahc(" + ')');
      }
   }
}
