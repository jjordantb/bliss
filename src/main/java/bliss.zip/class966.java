public class class966 {
   static class170 field2520 = new class170(128);
   public static class180 field2521;
   public static class180 field2522;

   class966() throws Throwable {
      throw new Error();
   }

   public static void method1711(int var0, int var1) {
      try {
         if (8 == class730.field2733) {
            class701 var2 = class637.method5936(class643.field9958, class730.field2674.field7765, (byte)103);
            var2.field3364.method6361(var0);
            class730.field2674.method4380(var2, (byte)-112);
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "qo.k(" + ')');
      }
   }
}
