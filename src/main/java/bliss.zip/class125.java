public class class125 {
   int field2324;
   public int field2325;
   public int field2326;
   public int field2327;

   static final void method1562(class744 var0, int var1) {
      try {
         int var2 = class615.field8903.field9130.method5267(-2013953489);
         class615.field8903.method5391(class615.field8903.field9131, var0.field3161[--var0.field3156] == 1 ? 0 : var2, -1763382439);
         class247.method4722((short)-2481);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "su.aij(" + ')');
      }
   }
}
