public class class974 extends class304 {
   int field2981;
   String field2982;
   static class48[] field2983;

   public void method2383(int var1) {
      try {
         if (577335585 * class730.field2852 != -1) {
            class917.method6450(577335585 * class730.field2852, this.field2982, 607881685 * this.field2981, 2017220990);
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "xx.f(" + ')');
      }
   }

   class974(class907 var1) {
      super(var1);
      this.field2982 = var1.method6379(919568963);
      this.field2981 = var1.method6374() * -602577027;
   }

   public void method2385() {
      if (577335585 * class730.field2852 != -1) {
         class917.method6450(577335585 * class730.field2852, this.field2982, 607881685 * this.field2981, 1486270976);
      }

   }

   public void method2386() {
      if (577335585 * class730.field2852 != -1) {
         class917.method6450(577335585 * class730.field2852, this.field2982, 607881685 * this.field2981, 1478832260);
      }

   }

   public static final void method1783(int var0) {
      try {
         for(int var1 = 0; var1 < 5; ++var1) {
            class730.field2665[var1] = false;
         }

         class730.field2749 = -1723181617;
         class730.field2750 = 2694169;
         class665.field9598 = 0;
         class617.field8843 = 0;
         class563.field1083 = 1355934404;
         class516.field4332 = -1001372047;
         class495.field8099 = 178575833;
      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "xx.hg(" + ')');
      }
   }

   static void method1784(class848 var0, int var1) {
      try {
         int var2 = class622.field9006 * -1347746885;
         int var3 = class281.field10643 * 1089948687;
         int var4 = 608683427 * class809.field4595;
         int var5 = 1396607435 * class873.field9785 - 3;
         byte var6 = 20;
         if (class948.field3290 == null || class909.field10396 == null) {
            class948.field3290 = (class727)class785.field3827.method1857(class730.field2681, class721.field3636 * -2085188617, true, true, -2063324548);
            class909.field10396 = class785.field3827.method1853(class730.field2681, -2085188617 * class721.field3636, -203887938);
            if (class948.field3290 != null && class909.field10396 != null) {
               class979.method1835(2025307040);
               int var16 = var2 + var4 / 2;
               if (var4 + var16 > class759.field4331 * -2110394505) {
                  var16 = class759.field4331 * -2110394505 - var4;
               }

               if (var16 < 0) {
                  var16 = 0;
               }

               class184.method3242(var16, class281.field10643 * 1089948687, (byte)34);
               return;
            }
         }

         class727 var7;
         if (class948.field3290 != null && class909.field10396 != null) {
            var7 = class948.field3290;
         } else {
            var7 = class501.field3182;
         }

         class230 var8 = class600.method5467(-2117423030);
         class888.method5530(var0, class622.field9006 * -1347746885, 1089948687 * class281.field10643, 608683427 * class809.field4595, class873.field9785 * 1396607435, var6, var7, var8, class814.field4781.method2927(class321.field1066, -875414210), 1493499179);
         int var9 = 255 - class602.field8651 * 597392981 - 1868123923 * class602.field8665;
         if (var9 < 0) {
            var9 = 0;
         }

         int var10 = class912.field10424.method5524((byte)-89);
         int var11 = class912.field10424.method5513((byte)17);
         int var12;
         class357 var13;
         int var14;
         class497 var17;
         if (!class602.field8638) {
            var12 = 0;

            for(var13 = (class357)class602.field8647.method901(1766612795); var13 != null; var13 = (class357)class602.field8647.method906(49146)) {
               var14 = 1 + var8.field8230 * 1110385787 + var6 + var3 + (-278777595 * class602.field8673 - 1 - var12) * -411680299 * class602.field8634;
               if (var10 > -1347746885 * class622.field9006 && var10 < 608683427 * class809.field4595 + -1347746885 * class622.field9006 && var11 > var14 - var8.field8230 * 1110385787 - 1 && var11 < var14 + var8.field8225 * -1883958527 && var13.field1704) {
                  var0.method4984(-1347746885 * class622.field9006, var14 - var8.field8230 * 1110385787, 608683427 * class809.field4595, class602.field8634 * -411680299, var9 << 24 | 427035573 * class166.field6895, 1);
               }

               ++var12;
            }
         } else {
            var12 = 0;

            for(var17 = (class497)class602.field8649.method2706(324606134); var17 != null; var17 = (class497)class602.field8649.method2707(2083970273)) {
               var14 = var12 * class602.field8634 * -411680299 + var8.field8230 * 1110385787 + var6 + var3 + 1;
               if (var10 > class622.field9006 * -1347746885 && var10 < class809.field4595 * 608683427 + -1347746885 * class622.field9006 && var11 > var14 - var8.field8230 * 1110385787 - 1 && var11 < var14 + var8.field8225 * -1883958527 && (-628325139 * var17.field8120 > 1 || ((class357)var17.field8121.field4317.field208).field1704)) {
                  var0.method4984(class622.field9006 * -1347746885, var14 - var8.field8230 * 1110385787, class809.field4595 * 608683427, class602.field8634 * -411680299, var9 << 24 | class166.field6895 * 427035573, 1);
               }

               ++var12;
            }

            if (class602.field8639 != null) {
               class888.method5530(var0, 805710735 * class514.field4319, -1370784315 * class936.field10310, 2054409059 * class965.field2535, -1855216229 * class382.field1411, var6, var7, var8, class602.field8639.field8122, -1919103988);
               var12 = 0;

               for(var13 = (class357)class602.field8639.field8121.method2706(473884533); var13 != null; var13 = (class357)class602.field8639.field8121.method2707(1876214432)) {
                  var14 = 1 + class936.field10310 * -1370784315 + var6 + 1110385787 * var8.field8230 + -411680299 * class602.field8634 * var12;
                  if (var10 > 805710735 * class514.field4319 && var10 < class514.field4319 * 805710735 + class965.field2535 * 2054409059 && var11 > var14 - 1110385787 * var8.field8230 - 1 && var11 < var14 + var8.field8225 * -1883958527 && var13.field1704) {
                     var0.method4984(805710735 * class514.field4319, var14 - 1110385787 * var8.field8230, class965.field2535 * 2054409059, class602.field8634 * -411680299, var9 << 24 | class166.field6895 * 427035573, 1);
                  }

                  ++var12;
               }

               class341.method259(var0, 805710735 * class514.field4319, -1370784315 * class936.field10310, 2054409059 * class965.field2535, -1855216229 * class382.field1411, var6, 2145329590);
            }
         }

         class341.method259(var0, -1347746885 * class622.field9006, class281.field10643 * 1089948687, 608683427 * class809.field4595, 1396607435 * class873.field9785, var6, 2136796856);
         if (!class602.field8638) {
            var12 = 0;

            for(var13 = (class357)class602.field8647.method901(1766612795); var13 != null; var13 = (class357)class602.field8647.method906(49146)) {
               var14 = 1110385787 * var8.field8230 + var6 + var3 + 1 + (class602.field8673 * -278777595 - 1 - var12) * class602.field8634 * -411680299;
               class848.method5066(var10, var11, var2, var3, var4, var5, var14, var13, var7, var8, -1067973831 * class958.field3480 | -16777216, 1697857463 * class350.field1644 | -16777216, 549127677);
               ++var12;
            }
         } else {
            var12 = 0;

            for(var17 = (class497)class602.field8649.method2706(-476899641); var17 != null; var17 = (class497)class602.field8649.method2707(81519453)) {
               var14 = -411680299 * class602.field8634 * var12 + 1 + var6 + 1089948687 * class281.field10643 + 1110385787 * var8.field8230;
               if (var17.field8120 * -628325139 == 1) {
                  class848.method5066(var10, var11, class622.field9006 * -1347746885, class281.field10643 * 1089948687, class809.field4595 * 608683427, class873.field9785 * 1396607435, var14, (class357)var17.field8121.field4317.field208, var7, var8, class958.field3480 * -1067973831 | -16777216, class350.field1644 * 1697857463 | -16777216, 579895839);
               } else {
                  class621.method5260(var10, var11, class622.field9006 * -1347746885, 1089948687 * class281.field10643, 608683427 * class809.field4595, 1396607435 * class873.field9785, var14, var17, var7, var8, -1067973831 * class958.field3480 | -16777216, 1697857463 * class350.field1644 | -16777216, (byte)-36);
               }

               ++var12;
            }

            if (class602.field8639 != null) {
               var12 = 0;

               for(var13 = (class357)class602.field8639.field8121.method2706(45096692); var13 != null; var13 = (class357)class602.field8639.field8121.method2707(1092020370)) {
                  var14 = var12 * class602.field8634 * -411680299 + 1 + var8.field8230 * 1110385787 + class936.field10310 * -1370784315 + var6;
                  class848.method5066(var10, var11, 805710735 * class514.field4319, class936.field10310 * -1370784315, 2054409059 * class965.field2535, -1855216229 * class382.field1411, var14, var13, var7, var8, class958.field3480 * -1067973831 | -16777216, class350.field1644 * 1697857463 | -16777216, -316918375);
                  ++var12;
               }
            }
         }

      } catch (RuntimeException var15) {
         throw class158.method3445(var15, "xx.bd(" + ')');
      }
   }

   static final void method1785(class744 var0, byte var1) {
      try {
         class564.method845(var0.field3170, var0, -1596344570);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "xx.aph(" + ')');
      }
   }
}
