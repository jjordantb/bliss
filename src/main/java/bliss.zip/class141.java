final class class141 implements class768 {
   public Object method2233(byte[] var1, class230 var2, boolean var3, int var4) {
      try {
         return class593.field1623.method4936(var2, class922.method6237(var1), var3);
      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "k.a(" + ')');
      }
   }

   public Object method2232(byte[] var1, class230 var2, boolean var3) {
      return class593.field1623.method4936(var2, class922.method6237(var1), var3);
   }

   public Object method2234(byte[] var1, class230 var2, boolean var3) {
      return class593.field1623.method4936(var2, class922.method6237(var1), var3);
   }

   static class398 method1092(class476 var0, byte var1) {
      try {
         class398 var2;
         if (class398.field6584 == null) {
            var2 = new class398();
         } else {
            var2 = class398.field6584;
            class398.field6584 = class398.field6584.field6586;
            var2.field6586 = null;
            class398.field6587 -= -1998519535;
         }

         var2.field6585 = var0;
         return var2;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "k.a(" + ')');
      }
   }

   public static void method1093(class971 var0, class49 var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, int var11) {
      try {
         class228.field8216 = var0;
         class228.field8222 = var1;
         class228.field8215 = var2 * 295365919;
         class228.field8218 = -1224770727 * var3;
         class228.field8217 = var4 * -1586864867;
         class228.field8220 = 1104541761 * var5;
         class370.field1097 = 1351228359 * var6;
         class228.field8219 = 838462141 * var7;
         class348.field221 = var8 * 339871807;
         class417.field9582 = null;
         class968.field2552 = null;
         class5.field4945 = null;
         class245.field8540 = var9 * 1589600979;
         class228.field8213 = var10 * -674457001;
         class461.method3994(-1268692886);
         class534.field3722 = true;
      } catch (RuntimeException var13) {
         throw class158.method3445(var13, "k.a(" + ')');
      }
   }

   static class197 method1094(class907 var0, int var1) {
      try {
         int var2 = var0.method6371();
         int var3 = var0.method6371();
         int var4 = var0.method6371();
         int[] var5 = new int[var4];

         for(int var6 = 0; var6 < var4; ++var6) {
            var5[var6] = var0.method6371();
         }

         return new class197(var2, var3, var5);
      } catch (RuntimeException var7) {
         throw class158.method3445(var7, "k.p(" + ')');
      }
   }

   static final void method1095(class744 var0, int var1) {
      try {
         var0.field3156 -= -1175642067;
         int var2 = var0.field3161[var0.field3156 * 681479919];
         int var3 = var0.field3161[681479919 * var0.field3156 + 1];
         int var4 = var0.field3161[2 + 681479919 * var0.field3156];
         class449.method3756(var2, (byte)83);
         class362.method1505(class382.field1410[var2 >>> 16], var2 & '\uffff', var3, var4, var0.field3178, var0, -782842809);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "k.ba(" + ')');
      }
   }
}
