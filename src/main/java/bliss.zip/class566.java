public class class566 {
   static class566 field623 = new class566();
   public static class566 field624 = new class566();
}
