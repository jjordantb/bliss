public interface class813 extends class780 {
   void method2755();

   void method2756();

   void method2753();

   void method2754();
}
