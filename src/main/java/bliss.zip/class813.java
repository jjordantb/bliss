public interface class813 extends class780 {
   void method2755();
}
