public class class738 implements class832 {
   class156 field3000;
   static int field3001;

   public boolean method5379(class476 var1) {
      return this.field3000 == var1;
   }

   class738(class156 var1) {
      this.field3000 = var1;
   }

   public boolean method5380(class476 var1, int var2) {
      try {
         return this.field3000 == var1;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "mw.a(" + ')');
      }
   }

   public boolean method5381(class476 var1) {
      return this.field3000 == var1;
   }

   static int method1796(class471 var0, class471 var1, int var2, boolean var3, int var4, boolean var5, int var6) {
      try {
         int var7 = class636.method5913(var0, var1, var2, var3, -1657159001);
         if (var7 != 0) {
            return var3 ? -var7 : var7;
         } else if (-1 == var4) {
            return 0;
         } else {
            int var8 = class636.method5913(var0, var1, var4, var5, -552551191);
            return var5 ? -var8 : var8;
         }
      } catch (RuntimeException var9) {
         throw class158.method3445(var9, "mw.r(" + ')');
      }
   }

   static void method1797(class848 var0, int var1) {
      try {
         int var2 = -10660793;
         class352.method1404(var0, -1347746885 * class622.field9006, class281.field10643 * 1089948687, class809.field4595 * 608683427, class873.field9785 * 1396607435, var2, -16777216, (byte)123);
         class501.field3182.method1678(class814.field4781.method2927(class321.field1066, -875414210), -1347746885 * class622.field9006 + 3, 1089948687 * class281.field10643 + 14, var2, -1, 1583712486);
         int var3 = class912.field10424.method5524((byte)-10);
         int var4 = class912.field10424.method5513((byte)38);
         int var5;
         class357 var6;
         int var7;
         if (!class602.field8638) {
            var5 = 0;

            for(var6 = (class357)class602.field8647.method901(1766612795); var6 != null; var6 = (class357)class602.field8647.method906(49146)) {
               var7 = 31 + 1089948687 * class281.field10643 + -411680299 * class602.field8634 * (-278777595 * class602.field8673 - 1 - var5);
               class848.method5066(var3, var4, -1347746885 * class622.field9006, 1089948687 * class281.field10643, 608683427 * class809.field4595, 1396607435 * class873.field9785, var7, var6, class501.field3182, class271.field10557, -1, -256, 247690373);
               ++var5;
            }
         } else {
            var5 = 0;

            for(class497 var9 = (class497)class602.field8649.method2706(198728515); var9 != null; var9 = (class497)class602.field8649.method2707(30142288)) {
               var7 = class281.field10643 * 1089948687 + 31 + var5 * -411680299 * class602.field8634;
               if (1 == var9.field8120 * -628325139) {
                  class848.method5066(var3, var4, -1347746885 * class622.field9006, class281.field10643 * 1089948687, 608683427 * class809.field4595, class873.field9785 * 1396607435, var7, (class357)var9.field8121.field4317.field208, class501.field3182, class271.field10557, -1, -256, 1821923505);
               } else {
                  class621.method5260(var3, var4, class622.field9006 * -1347746885, 1089948687 * class281.field10643, class809.field4595 * 608683427, class873.field9785 * 1396607435, var7, var9, class501.field3182, class271.field10557, -1, -256, (byte)-19);
               }

               ++var5;
            }

            if (class602.field8639 != null) {
               class352.method1404(var0, class514.field4319 * 805710735, -1370784315 * class936.field10310, 2054409059 * class965.field2535, -1855216229 * class382.field1411, var2, -16777216, (byte)111);
               class501.field3182.method1678(class602.field8639.field8122, 805710735 * class514.field4319 + 3, -1370784315 * class936.field10310 + 14, var2, -1, -2064340267);
               var5 = 0;

               for(var6 = (class357)class602.field8639.field8121.method2706(-783790871); var6 != null; var6 = (class357)class602.field8639.field8121.method2707(505275870)) {
                  var7 = var5 * -411680299 * class602.field8634 + class936.field10310 * -1370784315 + 31;
                  class848.method5066(var3, var4, 805710735 * class514.field4319, -1370784315 * class936.field10310, 2054409059 * class965.field2535, class382.field1411 * -1855216229, var7, var6, class501.field3182, class271.field10557, -1, -256, 916241136);
                  ++var5;
               }
            }
         }

      } catch (RuntimeException var8) {
         throw class158.method3445(var8, "mw.ar(" + ')');
      }
   }
}
