public class class748 extends class535 {
   public static int field4130 = 1;
   public static int field4131 = 2;
   public static int field4132 = 0;

   public int method2277(int var1) {
      return 1;
   }

   int method2276() {
      return this.field3704.field9137.method3691(16711680) && class932.method6299(this.field3704.field9137.method3689(-694656664), 1335402682) ? 1 : 0;
   }

   public void method2603(short var1) {
      try {
         if (this.field3708 * -1598873795 < 0 || this.field3708 * -1598873795 > 2) {
            this.field3708 = this.method2272(1979725599) * 1886334997;
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "adj.s(" + ')');
      }
   }

   int method2272(int var1) {
      try {
         return this.field3704.field9137.method3691(16711680) && class932.method6299(this.field3704.field9137.method3689(-745966272), 855449683) ? 1 : 0;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "adj.a(" + ')');
      }
   }

   public boolean method2604(int var1) {
      return true;
   }

   public int method2273(int var1, int var2) {
      return 1;
   }

   public class748(int var1, class838 var2) {
      super(var1, var2);
   }

   void method2275(int var1, int var2) {
      try {
         this.field3708 = 1886334997 * var1;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "adj.p(" + ')');
      }
   }

   public int method2605(int var1) {
      try {
         return -1598873795 * this.field3708;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "adj.y(" + ')');
      }
   }

   void method2271(int var1) {
      this.field3708 = 1886334997 * var1;
   }

   public class748(class838 var1) {
      super(var1);
   }
}
