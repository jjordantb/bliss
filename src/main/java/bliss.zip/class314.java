public class class314 {
   public static byte field501;

   class314() throws Throwable {
      throw new Error();
   }
}
