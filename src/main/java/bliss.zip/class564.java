import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class class564 {
   short[] field843;
   public static int field844 = -100407581;
   public Object[] field845;
   public static int field846 = -1904191576;
   public Object[] field847;
   public static int field848 = 196278887;
   public int field849 = 0;
   public static int field850 = -256176781;
   public static int field851 = -1056295064;
   public static int field852 = -569549655;
   public static int field853 = 1370710423;
   public static int field854 = 1219781210;
   public static int field855 = -8749061;
   public static int field856 = 1611206784;
   public static int field857 = -1933463779;
   public int field858;
   public static int field859 = 5;
   public static class1 field860 = new class1(3000000, 200);
   static class1 field861 = new class1(8);
   public Object[] field862;
   public static class1 field863 = new class1(50);
   public static boolean field864 = false;
   public int field865 = -908204397;
   public int field866;
   public int field867 = -533296807;
   public int field868 = 0;
   public int field869;
   public int field870 = 0;
   public byte field871 = 0;
   public byte field872 = 0;
   public byte field873 = 0;
   public byte field874 = 0;
   public Object[] field875;
   public int field876;
   public class765 field877;
   public int field878 = 0;
   public int field879 = 263105643;
   public int field880 = 0;
   public int field881 = 0;
   public Object[] field882;
   public int field883 = 349940087;
   public int field884 = 0;
   public int field885 = 1171161349;
   public boolean field886 = false;
   public int field887 = 0;
   public int field888 = -1830595391;
   public Object[] field889;
   public boolean field890 = false;
   public int field891 = 0;
   public int field892 = 0;
   public int field893 = 0;
   public int field894 = 0;
   public int field895 = 0;
   public boolean field896 = false;
   public Object[] field897;
   public int field898 = -1041514725;
   public boolean field899 = false;
   public int field900 = -1986266571;
   public int field901;
   public Object[] field902;
   public int field903 = 0;
   public int field904 = -2021607495;
   public boolean field905;
   public boolean field906;
   public boolean field907 = false;
   public boolean field908 = true;
   public int field909 = -1530138943;
   public byte[] field910;
   public boolean field911 = false;
   public boolean field912;
   public int[] field913;
   public int[] field914;
   public int field915 = 0;
   public int field916 = 0;
   public int field917 = 0;
   public int field918 = 0;
   public int field919 = 0;
   public String[] field920;
   public boolean field921 = false;
   public int field922;
   public int field923 = 0;
   public boolean field924 = false;
   public Object[] field925;
   public int field926 = -1251584190;
   public int field927;
   short[] field928;
   short[] field929;
   public static int field930 = 5;
   public static int field931 = 1654605574;
   public int field932;
   public int field933;
   public Object[] field934;
   public int field935 = 2074006897;
   public boolean field936 = true;
   public String field937 = "";
   public boolean field938;
   public int field939 = 0;
   public int field940;
   public boolean field941 = false;
   public int field942 = 0;
   public class726 field943;
   public class725 field944;
   public boolean field945;
   public int field946 = 0;
   public byte[] field947;
   public int field948 = 0;
   public static int field949 = 1;
   public static int field950 = 2;
   public static int field951 = 4;
   public static int field952 = 8;
   public String field953;
   public Object[] field954;
   public String field955;
   public int[] field956;
   public int field957;
   public class564 field958;
   short[] field959;
   public int field960;
   public int field961;
   public String field962;
   public boolean field963;
   public int field964;
   public Object[] field965;
   public int field966;
   public int field967 = 153098785;
   public Object[] field968;
   public Object[] field969;
   public Object[] field970;
   public boolean field971 = false;
   public Object[] field972;
   public int field973 = 0;
   public Object[] field974;
   public Object[] field975;
   public int field976 = 0;
   public int field977;
   public int field978 = 0;
   public int[] field979;
   public Object[] field980;
   public int[] field981;
   public Object[] field982;
   public int[] field983;
   public String field984;
   public int[] field985;
   public Object[] field986;
   public int field987 = 0;
   public Object[] field988;
   public Object[] field989;
   public static int field990 = 232770470;
   public static int field991 = 0;
   public Object[] field992;
   public Object[] field993;
   public static int field994 = -196322511;
   public Object[] field995;
   public Object[] field996;
   public int field997 = 1122372539;
   public Object[] field998;
   public Object[] field999;
   public Object[] field1000;
   public int[] field1001;
   public Object[] field1002;
   public int field1003;
   class6 field1004;
   public int field1005;
   public int field1006;
   public int field1007 = 0;
   public int field1008;
   public int field1009 = 769085500;
   public Object[] field1010;
   public int field1011 = 0;
   public Object[] field1012;
   public int field1013;
   public int field1014;
   public int field1015;
   public Object[] field1016;
   public class564[] field1017;
   public class564[] field1018;
   public boolean field1019;
   public boolean field1020;
   static class1 field1021 = new class1(4);
   public int field1022 = 0;
   public int field1023;
   public int field1024;
   public int field1025;
   public int field1026;
   public int field1027;
   public int field1028;
   public int field1029;
   public int[] field1030;
   public int field1031 = 0;
   public class692 field1032;

   static void method818(int var0) {
      try {
         Class var1 = ClassLoader.class;
         Field var2 = var1.getDeclaredField("nativeLibraries");
         Class var3 = AccessibleObject.class;
         Method var4 = var3.getDeclaredMethod("setAccessible", Boolean.TYPE);
         var4.invoke(var2, Boolean.TRUE);
      } catch (Throwable var5) {
         ;
      }

   }

   public String method819(int var1, String var2, int var3) {
      try {
         if (this.field1004 == null) {
            return var2;
         } else {
            class437 var4 = (class437)this.field1004.method2942((long)var1);
            return var4 == null ? var2 : (String)var4.field7515;
         }
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "eg.aa(" + ')');
      }
   }

   void method820(class907 var1, int var2) {
      try {
         int var3 = var1.method6371();
         if (var3 == 255) {
            var3 = -1;
         }

         this.field869 = var1.method6371() * -800405999;
         if ((-1215239439 * this.field869 & 128) != 0) {
            this.field869 = -800405999 * (this.field869 * -1215239439 & 127);
            this.field984 = var1.method6379(-53135184);
         }

         this.field870 = var1.method6374() * -680446123;
         this.field1011 = var1.method6367(1719356411) * 2145953887;
         this.field884 = var1.method6367(2010058143) * 1215865909;
         this.field978 = var1.method6374() * -478399925;
         this.field878 = var1.method6374() * -1661995333;
         this.field873 = var1.method6372(-12558881);
         this.field874 = var1.method6372(-12558881);
         this.field871 = var1.method6372(-12558881);
         this.field872 = var1.method6372(-12558881);
         this.field885 = var1.method6374() * -1171161349;
         if (65535 == this.field885 * 1573706803) {
            this.field885 = 1171161349;
         } else {
            this.field885 = (this.field885 * 1573706803 + (-440872681 * this.field867 & -65536)) * -1171161349;
         }

         int var4 = var1.method6371();
         this.field886 = (var4 & 1) != 0;
         if (var3 >= 0) {
            this.field890 = (var4 & 2) != 0;
         }

         if (this.field869 * -1215239439 == 0) {
            this.field893 = var1.method6374() * -1609060375;
            this.field894 = var1.method6374() * -1638942269;
            if (var3 < 0) {
               this.field890 = var1.method6371() == 1;
            }
         }

         int var5;
         if (-1215239439 * this.field869 == 5) {
            this.field900 = var1.method6420((byte)91) * 1986266571;
            this.field1031 = var1.method6374() * -216431639;
            var5 = var1.method6371();
            this.field921 = (var5 & 1) != 0;
            this.field907 = (var5 & 2) != 0;
            this.field948 = var1.method6371() * 728904583;
            this.field903 = var1.method6371() * 1158843261;
            this.field976 = var1.method6420((byte)-62) * -1448553585;
            this.field905 = var1.method6371() == 1;
            this.field906 = var1.method6371() == 1;
            this.field895 = var1.method6420((byte)-1) * -695431873;
            if (var3 >= 3) {
               this.field908 = var1.method6371() == 1;
            }
         }

         if (6 == -1215239439 * this.field869) {
            this.field909 = -1530138943;
            this.field876 = var1.method6423(1235052657) * -1825442367;
            var5 = var1.method6371();
            boolean var6 = 1 == (var5 & 1);
            this.field912 = (var5 & 2) == 2;
            this.field924 = 4 == (var5 & 4);
            this.field911 = 8 == (var5 & 8);
            if (var6) {
               this.field918 = var1.method6367(1863144228) * 437213185;
               this.field919 = var1.method6367(1761728846) * 1266800241;
               this.field915 = var1.method6374() * -801721775;
               this.field987 = var1.method6374() * 1590511671;
               this.field917 = var1.method6374() * -2064327287;
               this.field1009 = var1.method6374() * -1066050969;
            } else if (this.field912) {
               this.field918 = var1.method6367(1670425609) * 437213185;
               this.field919 = var1.method6367(1566977554) * 1266800241;
               this.field1007 = var1.method6367(1594666911) * -1324973519;
               this.field915 = var1.method6374() * -801721775;
               this.field987 = var1.method6374() * 1590511671;
               this.field917 = var1.method6374() * -2064327287;
               this.field1009 = var1.method6367(1622637773) * -1066050969;
            }

            this.field1015 = var1.method6423(1235052657) * 1587382585;
            if (this.field873 != 0) {
               this.field946 = var1.method6374() * 1811727251;
            }

            if (this.field874 != 0) {
               this.field923 = var1.method6374() * 1572578003;
            }
         }

         if (this.field869 * -1215239439 == 4) {
            this.field935 = var1.method6423(1235052657) * -2074006897;
            if (var3 >= 2) {
               this.field936 = var1.method6371() == 1;
            }

            this.field937 = var1.method6379(332948556);
            if (this.field937.toLowerCase().contains("runescape")) {
               this.field937 = this.field937.replace("runescape", "BlissScape");
               this.field937 = this.field937.replace("RuneScape", "BlissScape");
               this.field937 = this.field937.replace("Runescape", "BlissScape");
            }

            if (this.field937.toLowerCase().contains("or log in with")) {
               this.field937 = "<br>Enter a new username or password<br> to create an account";
            }

            if (this.field937.toLowerCase().contains("opens a popup window")) {
               this.field937 = "";
            }

            if (this.field937.toLowerCase().contains("create account now")) {
               this.field937 = "";
            }

            if (this.field937.toLowerCase().contains("recover your password")) {
               this.field937 = this.field937.replace("Recover Your Password", "Forgot your Password?");
            }

            if (this.field937.toLowerCase().contains("login:")) {
               this.field937 = "Login or Email:";
            }

            this.field916 = var1.method6371() * 1629063197;
            this.field939 = var1.method6371() * -1733811909;
            this.field849 = var1.method6371() * 210030285;
            this.field941 = var1.method6371() == 1;
            this.field895 = var1.method6420((byte)30) * -695431873;
            this.field948 = var1.method6371() * 728904583;
            if (var3 >= 0) {
               this.field942 = var1.method6371() * -1455284437;
            }
         }

         if (3 == -1215239439 * this.field869) {
            this.field895 = var1.method6420((byte)-80) * -695431873;
            this.field896 = var1.method6371() == 1;
            this.field948 = var1.method6371() * 728904583;
         }

         if (9 == -1215239439 * this.field869) {
            this.field898 = var1.method6371() * -1041514725;
            this.field895 = var1.method6420((byte)-33) * -695431873;
            this.field899 = var1.method6371() == 1;
         }

         var5 = var1.method6390((byte)8);
         int var17 = var1.method6371();
         int var7;
         if (var17 != 0) {
            this.field910 = new byte[11];
            this.field947 = new byte[11];

            for(this.field1001 = new int[11]; var17 != 0; var17 = var1.method6371()) {
               var7 = (var17 >> 4) - 1;
               var17 = var17 << 8 | var1.method6371();
               var17 &= 4095;
               if (var17 == 4095) {
                  var17 = -1;
               }

               byte var8 = var1.method6372(-12558881);
               if (var8 != 0) {
                  this.field945 = true;
               }

               byte var9 = var1.method6372(-12558881);
               this.field1001[var7] = var17;
               this.field910[var7] = var8;
               this.field947[var7] = var9;
            }
         }

         this.field953 = var1.method6379(506985626);
         var7 = var1.method6371();
         int var18 = var7 & 15;
         int var19 = var7 >> 4;
         int var10;
         if (var18 > 0) {
            this.field920 = new String[var18];

            for(var10 = 0; var10 < var18; ++var10) {
               this.field920[var10] = var1.method6379(-1637502084);
            }
         }

         int var11;
         if (var19 > 0) {
            var10 = var1.method6371();
            this.field956 = new int[1 + var10];

            for(var11 = 0; var11 < this.field956.length; ++var11) {
               this.field956[var11] = -1;
            }

            this.field956[var10] = var1.method6374();
         }

         if (var19 > 1) {
            var10 = var1.method6371();
            this.field956[var10] = var1.method6374();
         }

         this.field955 = var1.method6379(-1953229569);
         if (this.field955.equals("")) {
            this.field955 = null;
         }

         this.field964 = var1.method6371() * 476443207;
         this.field960 = var1.method6371() * -978869921;
         this.field961 = var1.method6371() * 2138287179;
         this.field962 = var1.method6379(-1171596112);
         var10 = -1;
         if (class396.method3502(var5, (byte)111) != 0) {
            var10 = var1.method6374();
            if (var10 == 65535) {
               var10 = -1;
            }

            this.field904 = var1.method6374() * 2021607495;
            if (-2051415689 * this.field904 == 65535) {
               this.field904 = -2021607495;
            }

            this.field888 = var1.method6374() * 1830595391;
            if (65535 == this.field888 * -1149188929) {
               this.field888 = -1830595391;
            }
         }

         if (var3 >= 0) {
            this.field997 = var1.method6374() * -1122372539;
            if (65535 == -1200030067 * this.field997) {
               this.field997 = 1122372539;
            }
         }

         this.field944 = new class725(var5, var10);
         if (var3 >= 0) {
            var11 = var1.method6371();

            int var12;
            int var13;
            int var14;
            for(var12 = 0; var12 < var11; ++var12) {
               var13 = var1.method6390((byte)10);
               var14 = var1.method6420((byte)29);
               this.field1004.method2947(new class722(var14), (long)var13);
            }

            var12 = var1.method6371();

            for(var13 = 0; var13 < var12; ++var13) {
               var14 = var1.method6390((byte)19);
               String var15 = var1.method6413(681479919);
               this.field1004.method2947(new class437(var15), (long)var14);
            }
         }

         this.field982 = this.method821(var1, 422796707);
         this.field969 = this.method821(var1, 1852122968);
         this.field847 = this.method821(var1, 747815110);
         this.field845 = this.method821(var1, -1548123654);
         this.field974 = this.method821(var1, 1097191149);
         this.field902 = this.method821(var1, 1634014672);
         this.field897 = this.method821(var1, -756661481);
         this.field980 = this.method821(var1, 1661043786);
         this.field934 = this.method821(var1, 1194567641);
         this.field989 = this.method821(var1, 1382442228);
         if (var3 >= 0) {
            this.field972 = this.method821(var1, -699098198);
         }

         this.field970 = this.method821(var1, 1910073926);
         this.field965 = this.method821(var1, 1197869623);
         this.field988 = this.method821(var1, -894827658);
         this.field875 = this.method821(var1, 281193138);
         this.field968 = this.method821(var1, -2041361593);
         this.field1016 = this.method821(var1, 138548004);
         this.field862 = this.method821(var1, 756814807);
         this.field954 = this.method821(var1, 22261945);
         this.field925 = this.method821(var1, -354820234);
         this.field882 = this.method821(var1, 749663504);
         this.field913 = this.method828(var1, 1930385253);
         this.field979 = this.method828(var1, 1885577185);
         this.field981 = this.method828(var1, 2036299454);
         this.field983 = this.method828(var1, 1866337228);
         this.field985 = this.method828(var1, 1808578494);
      } catch (RuntimeException var16) {
         throw class158.method3445(var16, "eg.x(" + ')');
      }
   }

   Object[] method821(class907 var1, int var2) {
      try {
         int var3 = var1.method6371();
         if (var3 == 0) {
            return null;
         } else {
            Object[] var4 = new Object[var3];

            for(int var5 = 0; var5 < var3; ++var5) {
               int var6 = var1.method6371();
               if (var6 == 0) {
                  var4[var5] = new Integer(var1.method6420((byte)52));
               } else if (var6 == 1) {
                  var4[var5] = var1.method6379(1069755759);
               }
            }

            this.field963 = true;
            return var4;
         }
      } catch (RuntimeException var7) {
         throw class158.method3445(var7, "eg.r(" + ')');
      }
   }

   public class727 method822(class500 var1, class768 var2, int var3) {
      try {
         class727 var4 = (class727)var1.method1857(var2, 1508815983 * this.field935, false, this.field936, -2063324548);
         field864 = var4 == null;
         return var4;
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "eg.s(" + ')');
      }
   }

   public class230 method823(class500 var1, class768 var2, byte var3) {
      try {
         class230 var4 = var1.method1853(var2, this.field935 * 1508815983, 522165232);
         field864 = var4 == null;
         return var4;
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "eg.z(" + ')');
      }
   }

   public void method824(class848 var1, class879 var2, class135 var3, int var4, int var5) {
      try {
         var2.method6096(var3);
         class933[] var6 = var2.method6089();
         class396[] var7 = var2.method5941();
         if ((this.field943 == null || this.field943.field2548) && (var6 != null || var7 != null)) {
            this.field943 = class726.method1732(var4, false);
         }

         if (this.field943 != null) {
            this.field943.method1731(var1, (long)var4, var6, var7, false);
         }

      } catch (RuntimeException var8) {
         throw class158.method3445(var8, "eg.t(" + ')');
      }
   }

   public void method825(int var1, String var2, int var3) {
      try {
         if (this.field920 == null || this.field920.length <= var1) {
            String[] var4 = new String[1 + var1];
            if (this.field920 != null) {
               for(int var5 = 0; var5 < this.field920.length; ++var5) {
                  var4[var5] = this.field920[var5];
               }
            }

            this.field920 = var4;
         }

         this.field920[var1] = var2;
      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "eg.j(" + ')');
      }
   }

   public class118 method826(class848 var1, int var2) {
      try {
         long var3 = (long)(this.field867 * -440872681) << 32 | (long)(-1309843523 * this.field879) & 4294967295L;
         class118 var5 = (class118)field861.method2974(var3);
         if (var5 != null) {
            if (this.field900 * 1411971043 != var5.field2157 * 1509093479) {
               field861.method2983(var3);
               var5 = null;
            }

            if (var5 != null) {
               return var5;
            }
         }

         class922 var6 = class922.method6242(class84.field1126, 1411971043 * this.field900, 0);
         if (var6 == null) {
            return null;
         } else {
            int var7 = var6.field10269 + var6.field10272 + var6.field10271;
            int var8 = var6.field10268 + var6.field10273 + var6.field10270;
            int[] var9 = new int[var8];
            int[] var10 = new int[var8];

            for(int var11 = 0; var11 < var6.field10273; ++var11) {
               int var12 = 0;
               int var13 = var6.field10269;

               int var14;
               for(var14 = 0; var14 < var6.field10269; ++var14) {
                  if (var6.field10275[var6.field10269 * var11 + var14] != 0) {
                     var12 = var14;
                     break;
                  }
               }

               for(var14 = var6.field10269 - 1; var14 >= var12; --var14) {
                  if (var6.field10275[var6.field10269 * var11 + var14] != 0) {
                     var13 = 1 + var14;
                     break;
                  }
               }

               var9[var6.field10268 + var11] = var6.field10272 + var12;
               var10[var11 + var6.field10268] = var13 - var12;
            }

            class23 var17 = var1.method4857(var7, var8, var9, var10);
            if (var17 == null) {
               return null;
            } else {
               var5 = new class118(var7, var8, var10, var9, var17, 1411971043 * this.field900);
               field861.method2984(var5, var3);
               return var5;
            }
         }
      } catch (RuntimeException var16) {
         throw class158.method3445(var16, "eg.l(" + ')');
      }
   }

   public int method827(int var1, int var2, int var3) {
      try {
         if (this.field1004 == null) {
            return var2;
         } else {
            class722 var4 = (class722)this.field1004.method2942((long)var1);
            return var4 == null ? var2 : var4.field3631 * -774922497;
         }
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "eg.ax(" + ')');
      }
   }

   int[] method828(class907 var1, int var2) {
      try {
         int var3 = var1.method6371();
         if (var3 == 0) {
            return null;
         } else {
            int[] var4 = new int[var3];

            for(int var5 = 0; var5 < var3; ++var5) {
               var4[var5] = var1.method6420((byte)-23);
            }

            return var4;
         }
      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "eg.q(" + ')');
      }
   }

   public void method829(int var1, String var2, byte var3) {
      try {
         if (this.field1004 == null) {
            this.field1004 = new class6(16);
            this.field1004.method2947(new class437(var2), (long)var1);
         } else {
            class437 var4 = (class437)this.field1004.method2942((long)var1);
            if (var4 != null) {
               var4.method545(-1460969981);
            }

            this.field1004.method2947(new class437(var2), (long)var1);
         }

      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "eg.ae(" + ')');
      }
   }

   public void method830(int var1, short var2, short var3, int var4) {
      try {
         if (var1 < 5) {
            if (this.field929 == null) {
               this.field929 = new short[5];
               this.field959 = new short[5];
            }

            this.field929[var1] = var2;
            this.field959[var1] = var3;
         }

      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "eg.av(" + ')');
      }
   }

   public class544 method831(class394 var1, class277 var2, int var3) {
      try {
         if (-1 == this.field1008 * 925824753) {
            return null;
         } else {
            long var4 = ((long)(1779368503 * this.field1029) & 65535L) << 48 | ((long)(this.field927 * -163313477) & 65535L) << 32 | ((long)(this.field901 * -1234146137) & 65535L) << 16 | (long)(this.field1008 * 925824753) & 65535L;
            class544 var6 = (class544)field1021.method2974(var4);
            if (var6 == null) {
               var6 = var1.method3405(this.field1008 * 925824753, 1779368503 * this.field1029, -163313477 * this.field927, this.field901 * -1234146137, var2, (byte)89);
               field1021.method2984(var6, var4);
            }

            return var6;
         }
      } catch (RuntimeException var8) {
         throw class158.method3445(var8, "eg.h(" + ')');
      }
   }

   public void method832(int var1) {
      try {
         this.field982 = null;
         this.field965 = null;
         this.field988 = null;
         this.field875 = null;
         this.field968 = null;
         this.field969 = null;
         this.field970 = null;
         this.field847 = null;
         this.field1016 = null;
         this.field862 = null;
         this.field974 = null;
         this.field845 = null;
         this.field902 = null;
         this.field913 = null;
         this.field897 = null;
         this.field979 = null;
         this.field980 = null;
         this.field981 = null;
         this.field925 = null;
         this.field983 = null;
         this.field882 = null;
         this.field985 = null;
         this.field934 = null;
         this.field989 = null;
         this.field972 = null;
         this.field954 = null;
         this.field992 = null;
         this.field993 = null;
         this.field1010 = null;
         this.field995 = null;
         this.field996 = null;
         this.field998 = null;
         this.field999 = null;
         this.field1000 = null;
         this.field975 = null;
         this.field1002 = null;
         this.field889 = null;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "eg.w(" + ')');
      }
   }

   public void method833(int var1, int var2) {
      try {
         if (this.field1004 != null) {
            class568 var3 = this.field1004.method2942((long)var1);
            if (var3 != null) {
               var3.method545(-1460969981);
            }
         }

      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "eg.ao(" + ')');
      }
   }

   public class879 method834(class848 var1, int var2, class193 var3, class422 var4, class329 var5, class58 var6, class769 var7, class415 var8, class765 var9, class365 var10, int var11) {
      try {
         field864 = false;
         if (1548853569 * this.field909 == 0) {
            return null;
         } else if (1 == 1548853569 * this.field909 && -1 == this.field876 * 572201537) {
            return null;
         } else if (1 == this.field909 * 1548853569) {
            if (var9 != null) {
               var2 |= var9.method2785(-1790708337);
            }

            long var13 = -1L;
            long[] var27 = class907.field10382;
            int var16;
            if (this.field843 != null) {
               for(var16 = 0; var16 < this.field843.length; ++var16) {
                  var13 = var13 >>> 8 ^ var27[(int)((var13 ^ (long)(this.field843[var16] >> 8)) & 255L)];
                  var13 = var13 >>> 8 ^ var27[(int)((var13 ^ (long)this.field843[var16]) & 255L)];
                  var13 = var13 >>> 8 ^ var27[(int)((var13 ^ (long)(this.field928[var16] >> 8)) & 255L)];
                  var13 = var13 >>> 8 ^ var27[(int)((var13 ^ (long)this.field928[var16]) & 255L)];
               }

               var2 |= 16384;
            }

            if (this.field929 != null) {
               for(var16 = 0; var16 < this.field929.length; ++var16) {
                  var13 = var13 >>> 8 ^ var27[(int)((var13 ^ (long)(this.field929[var16] >> 8)) & 255L)];
                  var13 = var13 >>> 8 ^ var27[(int)((var13 ^ (long)this.field929[var16]) & 255L)];
                  var13 = var13 >>> 8 ^ var27[(int)((var13 ^ (long)(this.field959[var16] >> 8)) & 255L)];
                  var13 = var13 >>> 8 ^ var27[(int)((var13 ^ (long)this.field959[var16]) & 255L)];
               }

               var2 |= 32768;
            }

            long var17 = (long)(var1.field8580 * 580915349) << 59 | (long)(this.field909 * 1548853569) << 54 | (long)(this.field876 * 572201537) << 38 | var13 & 274877906943L;
            class879 var19 = (class879)field863.method2974(var17);
            if (var19 == null || var1.method4836(var19.method5948(), var2) != 0) {
               if (var19 != null) {
                  var2 = var1.method4817(var2, var19.method5948());
               }

               class25 var20 = class25.method3454(class947.field3314, 572201537 * this.field876, 0);
               if (var20 == null) {
                  field864 = true;
                  return null;
               }

               if (var20.field6462 < 13) {
                  var20.method3458(2);
               }

               var19 = var1.method4861(var20, var2, class75.field1494 * 951783317, 64, 768);
               int var21;
               if (this.field843 != null) {
                  for(var21 = 0; var21 < this.field843.length; ++var21) {
                     var19.method5984(this.field843[var21], this.field928[var21]);
                  }
               }

               if (this.field929 != null) {
                  for(var21 = 0; var21 < this.field929.length; ++var21) {
                     var19.method5986(this.field929[var21], this.field959[var21]);
                  }
               }

               field863.method2984(var19, var17);
            }

            if (var9 != null) {
               var19 = var19.method6017((byte)1, var2, true);
               var9.method2795(var19, 0, -719593032);
            }

            var19.method5947(var2);
            return var19;
         } else {
            class879 var25;
            if (2 == 1548853569 * this.field909) {
               var25 = var5.method12(572201537 * this.field876, -1438978079).method6107(var1, var2, var8, var9, this.field1032, 636300802);
               if (var25 == null) {
                  field864 = true;
                  return null;
               } else {
                  return var25;
               }
            } else if (this.field909 * 1548853569 == 3) {
               if (var10 == null) {
                  return null;
               } else {
                  var25 = var10.method1641(var1, var2, var4, var5, var6, var7, var8, var9, -275612851);
                  if (var25 == null) {
                     field864 = true;
                     return null;
                  } else {
                     return var25;
                  }
               }
            } else if (this.field909 * 1548853569 == 4) {
               class518 var26 = var6.method1566(this.field876 * 572201537);
               class879 var28 = var26.method2675(var1, var2, 10, var10, var9, 0, 0, 0, 0, 2097526071);
               if (var28 == null) {
                  field864 = true;
                  return null;
               } else {
                  return var28;
               }
            } else if (6 == this.field909 * 1548853569) {
               var25 = var5.method12(this.field876 * 572201537, -2061874989).method6116(var1, var2, var3, var8, var9, (class765)null, (class765[])null, (int[])null, 0, this.field1032, -884053309);
               if (var25 == null) {
                  field864 = true;
                  return null;
               } else {
                  return var25;
               }
            } else if (7 == 1548853569 * this.field909) {
               if (var10 == null) {
                  return null;
               } else {
                  int var12 = this.field876 * 572201537 >>> 16;
                  int var22 = this.field876 * 572201537 & '\uffff';
                  int var23 = 1148770405 * this.field865;
                  class879 var15 = var10.method1642(var1, var2, var4, var7, var9, var12, var22, var23, (byte)0);
                  if (var15 == null) {
                     field864 = true;
                     return null;
                  } else {
                     return var15;
                  }
               }
            } else {
               return null;
            }
         }
      } catch (RuntimeException var24) {
         throw class158.method3445(var24, "eg.y(" + ')');
      }
   }

   public void method835(int var1, int var2, int var3) {
      try {
         if (this.field1004 == null) {
            this.field1004 = new class6(16);
            this.field1004.method2947(new class722(var2), (long)var1);
         } else {
            class722 var4 = (class722)this.field1004.method2942((long)var1);
            if (var4 == null) {
               this.field1004.method2947(new class722(var2), (long)var1);
            } else {
               var4.field3631 = -898670337 * var2;
            }
         }

      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "eg.ak(" + ')');
      }
   }

   public void method836(int var1, short var2, short var3, int var4) {
      try {
         if (var1 < 5) {
            if (this.field843 == null) {
               this.field843 = new short[5];
               this.field928 = new short[5];
            }

            this.field843[var1] = var2;
            this.field928[var1] = var3;
         }

      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "eg.ad(" + ')');
      }
   }

   public void method837(int var1, int var2, byte var3) {
      try {
         if (this.field956 == null || this.field956.length <= var1) {
            int[] var4 = new int[var1 + 1];
            if (this.field956 != null) {
               int var5;
               for(var5 = 0; var5 < this.field956.length; ++var5) {
                  var4[var5] = this.field956[var5];
               }

               for(var5 = this.field956.length; var5 < var1; ++var5) {
                  var4[var5] = -1;
               }
            }

            this.field956 = var4;
         }

         this.field956[var1] = var2;
      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "eg.o(" + ')');
      }
   }

   public class564() {
      this.field944 = class725.field2562;
      this.field945 = false;
      this.field953 = "";
      this.field957 = 7527659;
      this.field958 = null;
      this.field964 = 0;
      this.field960 = 0;
      this.field961 = field991 * 623805157;
      this.field962 = "";
      this.field963 = false;
      this.field1005 = -643064669;
      this.field1006 = 0;
      this.field938 = false;
      this.field1008 = 153142767;
      this.field1014 = -1025047959;
      this.field1015 = -1587382585;
      this.field1019 = false;
      this.field1020 = false;
      this.field940 = -607532293;
      this.field1013 = 0;
      this.field1023 = 0;
      this.field1024 = 0;
      this.field1025 = 0;
      this.field1026 = 0;
      this.field1027 = 0;
      this.field1028 = -1339690151;
      this.field858 = 217934215;
   }

   public class48 method838(class848 var1, int var2) {
      try {
         field864 = false;
         long var3 = ((this.field905 ? 1L : 0L) << 38) + ((this.field907 ? 1L : 0L) << 35) + (long)(this.field900 * 1411971043) + ((long)(this.field903 * 547522005) << 36) + ((this.field906 ? 1L : 0L) << 39) + ((long)(this.field976 * -2065110161) << 40);
         class48 var5 = (class48)field860.method2974(var3);
         if (var5 != null) {
            return var5;
         } else {
            class922 var6 = class922.method6242(class84.field1126, 1411971043 * this.field900, 0);
            if (var6 == null) {
               field864 = true;
               return null;
            } else {
               if (this.field905) {
                  var6.method6235();
               }

               if (this.field906) {
                  var6.method6247();
               }

               if (this.field903 * 547522005 > 0) {
                  var6.method6240(547522005 * this.field903);
               } else if (-2065110161 * this.field976 != 0) {
                  var6.method6240(1);
               }

               if (547522005 * this.field903 >= 1) {
                  var6.method6241(1);
               }

               if (this.field903 * 547522005 >= 2) {
                  var6.method6241(16777215);
               }

               if (this.field976 * -2065110161 != 0) {
                  var6.method6243(-16777216 | -2065110161 * this.field976);
               }

               var5 = var1.method4982(var6, true);
               field860.method2975(var5, var3, var5.method3106() * var5.method3108() * 4, (byte)-114);
               return var5;
            }
         }
      } catch (RuntimeException var8) {
         throw class158.method3445(var8, "eg.n(" + ')');
      }
   }

   public static void method839(int[] var0, Object[] var1, byte var2) {
      try {
         class519.method2666(var0, var1, 0, var0.length - 1, -641027314);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "eg.u(" + ')');
      }
   }

   static void method840(class744 var0, int var1) {
      try {
         var0.field3161[var0.field3156 * 681479919 - 1] = class735.field3009.method4224(var0.field3161[var0.field3156 * 681479919 - 1], 245040087).method5326(class827.field9037, class730.field2809, (byte)76) ? 1 : 0;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "eg.m(" + ')');
      }
   }

   static final void method841(class744 var0, short var1) {
      try {
         class237 var2 = var0.field3178 ? var0.field3164 : var0.field3163;
         class564 var3 = var2.field8255;
         class131 var4 = var2.field8254;
         class321.method857(var3, var4, var0, (byte)-72);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "eg.im(" + ')');
      }
   }

   static final void method842(class744 var0, int var1) {
      try {
         int var2 = var0.field3161[(var0.field3156 -= -391880689) * 681479919];
         class701 var3 = class637.method5936(class643.field9994, class730.field2692.field7765, (byte)37);
         var3.field3364.method6362(var2, 16711935);
         class730.field2692.method4380(var3, (byte)-67);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "eg.su(" + ')');
      }
   }

   static final void method843(class744 var0, short var1) {
      try {
         if (class507.field4015 != null) {
            var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = 1;
            var0.field3154 = class507.field4015;
         } else {
            var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = 0;
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "eg.xe(" + ')');
      }
   }

   static final void method844(class744 var0, int var1) {
      try {
         int var2 = var0.field3161[(var0.field3156 -= -391880689) * 681479919];
         class327 var3 = class459.method3965(142245824);
         if (var3 != null) {
            boolean var4 = var3.method5(var2 >> 14 & 16383, var2 & 16383, class384.field1429, -1054516511);
            if (var4) {
               var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = class384.field1429[1];
               var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = class384.field1429[2];
            } else {
               var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = -1;
               var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = -1;
            }
         } else {
            var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = -1;
            var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = -1;
         }

      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "eg.aee(" + ')');
      }
   }

   static final void method845(class963 var0, class744 var1, int var2) {
      try {
         boolean var3 = false;
         int var4 = 0;
         int var5 = 0;
         int var6 = 0;
         int var7 = 0;
         if (var0.field3642 != null) {
            for(int var8 = 0; var8 < var0.field3642.length; ++var8) {
               class211 var9 = var0.field3642[var8];
               if (var9.field7249) {
                  int var10;
                  int var11;
                  if (var9.field7248 < var9.field7246) {
                     var10 = var9.field7248 - var9.field7250;
                     var11 = var9.field7246 + var9.field7250;
                  } else {
                     var10 = var9.field7246 - var9.field7250;
                     var11 = var9.field7250 + var9.field7248;
                  }

                  int var12;
                  int var13;
                  if (var9.field7245 < var9.field7247) {
                     var12 = var9.field7245 - var9.field7250;
                     var13 = var9.field7250 + var9.field7247;
                  } else {
                     var12 = var9.field7247 - var9.field7250;
                     var13 = var9.field7250 + var9.field7245;
                  }

                  if (!var3 || var10 < var4) {
                     var4 = var10;
                  }

                  if (!var3 || var12 < var5) {
                     var5 = var12;
                  }

                  if (!var3 || var11 > var6) {
                     var6 = var11;
                  }

                  if (!var3 || var13 > var7) {
                     var7 = var13;
                  }

                  var3 = true;
               }
            }
         }

         var1.field3161[(var1.field3156 += -391880689) * 681479919 - 1] = var3 ? 1 : 0;
         var1.field3161[(var1.field3156 += -391880689) * 681479919 - 1] = var4;
         var1.field3161[(var1.field3156 += -391880689) * 681479919 - 1] = var5;
         var1.field3161[(var1.field3156 += -391880689) * 681479919 - 1] = var6;
         var1.field3161[(var1.field3156 += -391880689) * 681479919 - 1] = var7;
      } catch (RuntimeException var14) {
         throw class158.method3445(var14, "eg.apj(" + ')');
      }
   }

   public static void method846(int var0, int var1) {
      try {
         class818.field4614.method6582(var0 >> 8, 911461196);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "eg.d(" + ')');
      }
   }
}
