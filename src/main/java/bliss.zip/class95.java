public class class95 {
   public static int field593 = -1;
   static boolean field594 = false;
   static int field595 = 0;
   static int field596 = -1;
   static int[] field597 = new int[1003];
   static int[] field598 = new int[1004];
   static int[] field599 = new int[1005];
   static class373 field600 = new class373();
   public static int field601 = -1;
   static boolean field602 = true;
   static boolean field603 = false;
   static boolean field604 = false;
   static int field605 = 48;
   static int field606 = 0;
   static class752 field607;

   class95() throws Throwable {
      throw new Error();
   }

   public static void method523(int var0) {
      try {
         class439 var1 = null;

         try {
            var1 = class22.method3434("", class730.field2926.field7321, true, -1804643872);
            class907 var2 = class615.field8903.method5393(-804179286);
            var1.method4275(var2.field10375, 0, var2.field10376, -1257925796);
         } catch (Exception var4) {
            ;
         }

         try {
            if (var1 != null) {
               var1.method4276(1091393691);
            }
         } catch (Exception var3) {
            ;
         }

      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "ad.f(" + ')');
      }
   }

   static final void method524(class744 var0, byte var1) {
      try {
         class615.field8903.method5391(class615.field8903.field9123, var0.field3161[--var0.field3156] == 1 ? 1 : 0, -223155318);
         method523(656179282);
         class362.method1508(1660250591);
         class730.field2647 = false;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ad.aim(" + ')');
      }
   }

   static final int method525(class21 var0, int var1) {
      try {
         if (var0 == null) {
            return 12;
         } else {
            switch(var0.field5421) {
            case 3:
               return 20;
            default:
               return 12;
            }
         }
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ad.a(" + ')');
      }
   }

   static final void method526(class744 var0, int var1) {
      try {
         String var2 = (String)var0.field3157[--var0.field3158];
         if (var2.startsWith(class341.method255(0, -278777595)) || var2.startsWith(class341.method255(1, -278777595))) {
            var2 = var2.substring(7);
         }

         var0.field3161[++var0.field3156 - 1] = class942.method6333(var2, -1912416826) ? 1 : 0;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ad.vj(" + ')');
      }
   }
}
