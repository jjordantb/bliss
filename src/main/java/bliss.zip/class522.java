public class class522 extends class765 {
   void method2793(class160 var1, int var2, byte var3) {
      try {
         class59.method1619(var1, var2, -646004957);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "aem.l(" + ')');
      }
   }

   public class522() {
      super(true);
   }

   void method2739(class160 var1, int var2) {
      class59.method1619(var1, var2, -1673739713);
   }
}
