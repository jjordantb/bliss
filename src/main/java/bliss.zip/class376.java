public abstract class class376 {
   class376() throws Throwable {
      throw new Error();
   }

   public static final void method1037(int var0, int var1, int var2, int var3, int var4, int var5, int var6, byte var7) {
      try {
         if (var0 >= class381.field1416 && var1 <= class381.field1413 && var2 >= class381.field1414 && var3 <= class381.field1415) {
            class727.method1688(var0, var1, var2, var3, var4, var5, var6, (byte)76);
         } else {
            class916.method6462(var0, var1, var2, var3, var4, var5, var6, (byte)-89);
         }

      } catch (RuntimeException var9) {
         throw class158.method3445(var9, "ru.u(" + ')');
      }
   }
}
