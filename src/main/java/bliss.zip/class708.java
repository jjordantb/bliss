import jaclib.memory.Z;

public class class708 extends class666 implements class525 {
   byte field3316;

   public boolean method1981(int var1, int var2, long var3) {
      return super.method1977(var1, var2, var3);
   }

   class708(class608 var1, boolean var2) {
      super(var1, 34962, var2);
   }

   int method1943() {
      return this.field3316;
   }

   public boolean method2237(int var1, int var2) {
      this.field3316 = (byte)var2;
      super.method5735(var1);
      return true;
   }

   public boolean method2238(int var1, int var2) {
      this.field3316 = (byte)var2;
      super.method5735(var1);
      return true;
   }

   public void method5738() {
      super.method5738();
   }

   public boolean method1977(int var1, int var2, long var3) {
      return super.method1977(var1, var2, var3);
   }

   public boolean method2239(int var1, int var2, Z var3) {
      this.field3316 = (byte)var2;
      super.method5737(var1, var3);
      return true;
   }

   public void method1983() {
      super.method1983();
   }

   public void method2756() {
      super.method5738();
   }

   public void method2754() {
      super.method5738();
   }

   public void method1980() {
      super.method1983();
   }

   public boolean method2235(int var1, int var2) {
      this.field3316 = (byte)var2;
      super.method5735(var1);
      return true;
   }

   public void method2753() {
      super.method5738();
   }

   public boolean method2236(int var1, int var2, Z var3) {
      this.field3316 = (byte)var2;
      super.method5737(var1, var3);
      return true;
   }

   public int method1974() {
      return super.method1974();
   }

   public int method1979() {
      return super.method1974();
   }

   public boolean method1975(int var1, int var2, long var3) {
      return super.method1977(var1, var2, var3);
   }

   public long method1976(int var1, int var2) {
      return super.method1976(var1, var2);
   }

   public long method1982(int var1, int var2) {
      return super.method1976(var1, var2);
   }

   public int method1978() {
      return super.method1974();
   }
}
