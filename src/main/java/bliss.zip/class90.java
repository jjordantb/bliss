public class class90 {
   static class90 field548 = new class90(5);
   static class90 field549 = new class90(1);
   public static class90 field550 = new class90(0);
   public static class90 field551 = new class90(2);
   static class90 field552 = new class90(4);
   static class90 field553 = new class90(3);
   public int field554;

   class90(int var1) {
      this.field554 = var1;
   }
}
