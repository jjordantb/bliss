public abstract class class760 extends class806 {
   class325 field4385;

   boolean method2484() {
      this.field4385.method591();
      return true;
   }

   boolean method2486() {
      this.field4385.method591();
      return true;
   }

   class760(class325 var1) {
      this.field4385 = var1;
   }

   void method2803() {
      if (this == this.field4385.method4800((short)-23826)) {
         this.field4385.method576();
      }

   }
}
