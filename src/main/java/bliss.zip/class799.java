public interface class799 {
}
