public interface class799 {
   int field500 = 10;
}
