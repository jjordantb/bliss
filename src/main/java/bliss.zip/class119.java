public class class119 {
   public static class119 field2147 = new class119(1);
   public static class119 field2148 = new class119(2);
   public static class119 field2149 = new class119(0);
   static class119 field2150 = new class119(3);
   public int field2151;

   class119(int var1) {
      this.field2151 = var1;
   }
}
