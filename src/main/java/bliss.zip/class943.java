public interface class943 {
   int method1974();

   long method1976(int var1, int var2);

   boolean method1977(int var1, int var2, long var3);

   void method1983();
}
