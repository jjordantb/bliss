public interface class943 {
   int method1974();

   boolean method1975(int var1, int var2, long var3);

   long method1976(int var1, int var2);

   boolean method1977(int var1, int var2, long var3);

   int method1978();

   int method1979();

   void method1980();

   boolean method1981(int var1, int var2, long var3);

   long method1982(int var1, int var2);

   void method1983();
}
