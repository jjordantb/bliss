public class class964 extends class381 {
   static int[] field3633;

   class964() throws Throwable {
      throw new Error();
   }

   static void method2133(int var0, int var1, int var2) {
      try {
         class682 var3 = class370.method881(15, 0L);
         var3.method4340((byte)19);
         var3.field7687 = 1274450087 * var0;
         var3.field7685 = var1 * 293101103;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "adb.ac(" + ')');
      }
   }

   static final void method2134(class564 var0, class131 var1, class744 var2, int var3) {
      try {
         String var4 = (String)var2.field3157[(var2.field3158 -= 969361751) * -203050393];
         if (class960.method2212(var4, var2, -923339363) != null) {
            var4 = var4.substring(0, var4.length() - 1);
         }

         var0.field993 = class634.method5872(var4, var2, -2046058202);
         var0.field963 = true;
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "adb.mn(" + ')');
      }
   }
}
