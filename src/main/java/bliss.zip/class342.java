public class class342 {
   static int field278 = 0;
   static int field279 = 0;
   static int field280 = 350;
   static String field281 = "";
   static int field282 = 0;
   static int field283 = 0;
   static int field284 = -1;
   static int field285 = 0;
   static int field286;
   static String[] field287;
   static boolean field288 = false;
   static String[] field289;
   static int field290;
   static String field291 = "\\/.:, _-+[]~@";
   static String field292 = "Success";
   static String field293 = "Failure";
   static boolean field294;

   class342() throws Throwable {
      throw new Error();
   }

   static String method217(class357 var0, int var1) {
      try {
         if (var0.field1709 != null && var0.field1709.length() != 0) {
            return var0.field1697 != null && var0.field1697.length() > 0 ? var0.field1707 + class814.field4790.method2927(class321.field1066, -875414210) + var0.field1697 + class814.field4790.method2927(class321.field1066, -875414210) + var0.field1709 : var0.field1707 + class814.field4790.method2927(class321.field1066, -875414210) + var0.field1709;
         } else {
            return var0.field1697 != null && var0.field1697.length() > 0 ? var0.field1707 + class814.field4790.method2927(class321.field1066, -875414210) + var0.field1697 : var0.field1707;
         }
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ai.bf(" + ')');
      }
   }

   static final void method218(class744 var0, byte var1) {
      try {
         String var2 = (String)var0.field3157[--var0.field3158];
         class967.method1749(var2, 1986272342);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ai.vh(" + ')');
      }
   }

   static final void method219(class744 var0, int var1) {
      try {
         var0.field3157[++var0.field3158 - 1] = var0.field3154.field1164;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ai.xj(" + ')');
      }
   }

   static class272 method220(class272 var0, int var1) {
      try {
         class272 var2 = var0 == null ? new class272() : new class272(var0);
         var2.method6569(9, 128, 346222187);
         return var2;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ai.f(" + ')');
      }
   }

   public static void method221(int var0) {
      try {
         class564.field860.method2977();
         class564.field863.method2977();
         class564.field861.method2977();
         class564.field1021.method2977();
      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "ai.g(" + ')');
      }
   }

   static final void method222(class744 var0, int var1) {
      try {
         class625 var2 = var0.field3159.method2565(658355638);
         if (var2 == null) {
            var0.field3157[++var0.field3158 - 1] = "";
         } else {
            var0.field3157[++var0.field3158 - 1] = var2.method5820((byte)1);
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ai.aok(" + ')');
      }
   }

   static final void method223(int var0, int[] var1, int var2) {
      try {
         if (class215.method3835(var0, var1, -1347754722)) {
            class564[] var3 = class382.field1410[var0].field1103;

            for(int var4 = 0; var4 < var3.length; ++var4) {
               class564 var5 = var3[var4];
               if (var5 != null && var5.field877 != null) {
                  var5.field877.method2790(-341211018);
               }
            }
         }

      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "ai.lu(" + ')');
      }
   }
}
