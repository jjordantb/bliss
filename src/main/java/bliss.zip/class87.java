public class class87 {
   int field1127;
   int field1128;
   int field1129;
   int field1130;

   class87(class87 var1) {
      this.field1128 = var1.field1128;
      this.field1127 = var1.field1127;
      this.field1129 = var1.field1129;
      this.field1130 = var1.field1130;
   }

   class87() {
   }
}
