public class class8 extends class535 {
   public static int field4966 = 2;
   public static int field4967 = 1;
   public static int field4968 = 0;
   public static int field4969 = 3;
   public static int field4970 = 4;

   public class8(int var1, class838 var2) {
      super(var1, var2);
   }

   int method2272(int var1) {
      try {
         return super.field3704.method5394(866674858).method2266(1731057134) > 1 ? 4 : 2;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "aen.a(" + ')');
      }
   }

   int method2273(int var1, int var2) {
      return 1;
   }

   void method2275(int var1, int var2) {
      try {
         super.field3708 = var1;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "aen.p(" + ')');
      }
   }

   public int method3017(byte var1) {
      try {
         return super.field3708;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "aen.z(" + ')');
      }
   }

   public void method3018(int var1) {
      try {
         if (super.field3708 < 0 && super.field3708 > 4) {
            super.field3708 = this.method2272(1896297259);
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "aen.s(" + ')');
      }
   }

   public class8(class838 var1) {
      super(var1);
   }

   static final void method3019(class744 var0, byte var1) {
      try {
         var0.field3161[++var0.field3156 - 1] = class881.field10180;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "aen.ahx(" + ')');
      }
   }
}
