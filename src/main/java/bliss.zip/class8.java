public class class8 extends class535 {
   public static int field4966 = 2;
   public static int field4967 = 1;
   public static int field4968 = 0;
   public static int field4969 = 3;
   public static int field4970 = 4;

   public class8(int var1, class838 var2) {
      super(var1, var2);
   }

   int method2272(int var1) {
      try {
         return this.field3704.method5394(866674858).method2266(1731057134) > 1 ? 4 : 2;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "aen.a(" + ')');
      }
   }

   int method2276() {
      return this.field3704.method5394(-2103071990).method2266(-711735893) > 1 ? 4 : 2;
   }

   int method2273(int var1, int var2) {
      return 1;
   }

   void method2275(int var1, int var2) {
      try {
         this.field3708 = var1 * 1886334997;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "aen.p(" + ')');
      }
   }

   public int method3017(byte var1) {
      try {
         return -1598873795 * this.field3708;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "aen.z(" + ')');
      }
   }

   public void method3018(int var1) {
      try {
         if (this.field3708 * -1598873795 < 0 && this.field3708 * -1598873795 > 4) {
            this.field3708 = this.method2272(1896297259) * 1886334997;
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "aen.s(" + ')');
      }
   }

   int method2277(int var1) {
      return 1;
   }

   void method2271(int var1) {
      this.field3708 = var1 * 1886334997;
   }

   public class8(class838 var1) {
      super(var1);
   }

   static final void method3019(class744 var0, byte var1) {
      try {
         var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = 1001535723 * class881.field10180;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "aen.ahx(" + ')');
      }
   }
}
