public class class349 extends class568 {
   byte[] field1564;
   int[] field1565;

   class349(int[] var1, byte[] var2) {
      this.field1565 = var1;
      this.field1564 = var2;
   }
}
