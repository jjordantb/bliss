public class class508 extends class568 {
   static class769 field3965;
   public class373 field3966 = new class373();
   static class272 field3967;

   static final void method2498(int var0, int var1, int var2, int var3, byte var4) {
      try {
         if (var0 - var2 >= class381.field1416 && var2 + var0 <= class381.field1413 && var1 - var2 >= class381.field1414 && var1 + var2 <= class381.field1415) {
            class240.method4714(var0, var1, var2, var3, -586727793);
         } else {
            class353.method1381(var0, var1, var2, var3, 179222192);
         }

      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "aad.x(" + ')');
      }
   }

   static final void method2499(class744 var0, int var1) {
      try {
         class237 var2 = var0.field3178 ? var0.field3164 : var0.field3163;
         class564 var3 = var2.field8255;
         class131 var4 = var2.field8254;
         class979.method1837(var3, var4, var0, (byte)-5);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "aad.jo(" + ')');
      }
   }

   static final void method2500(class744 var0, int var1) {
      try {
         int var2 = var0.field3161[--var0.field3156];
         class564 var3 = class449.method3756(var2, (byte)-113);
         class131 var4 = class382.field1410[var2 >> 16];
         class849.method4784(var3, var4, var0, 131231409);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "aad.ij(" + ')');
      }
   }

   static final void method2501(class744 var0, int var1) {
      try {
         int var2 = var0.field3161[--var0.field3156];
         var0.field3157[++var0.field3158 - 1] = Integer.toString(var2);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "aad.ze(" + ')');
      }
   }
}
