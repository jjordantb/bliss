public abstract class class732 extends class963 {
   protected short field2978;
   protected short field2979;
   public static class213 field2980;

   final boolean method2191() {
      return false;
   }

   int method2161(class639[] var1, int var2) {
      try {
         class32 var3 = this.method1511().field7637;
         return this.method2199((int)var3.field5296 >> -1688804109 * this.field3638.field3849, (int)var3.field5299 >> -1688804109 * this.field3638.field3849, var1, 1820308449);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "aji.dg(" + ')');
      }
   }

   final void method2185() {
      throw new IllegalStateException();
   }

   final boolean method2207() {
      return false;
   }

   final boolean method2173(int var1) {
      return false;
   }

   final void method2195(class848 var1, class963 var2, int var3, int var4, int var5, boolean var6) {
      throw new IllegalStateException();
   }

   final void method2205(byte var1) {
      try {
         throw new IllegalStateException();
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "aji.bq(" + ')');
      }
   }

   final void method2182(class848 var1, class963 var2, int var3, int var4, int var5, boolean var6) {
      throw new IllegalStateException();
   }

   int method2197(class639[] var1) {
      class32 var2 = this.method1511().field7637;
      return this.method2199((int)var2.field5296 >> -1688804109 * this.field3638.field3849, (int)var2.field5299 >> -1688804109 * this.field3638.field3849, var1, 2077103831);
   }

   final void method2184() {
      throw new IllegalStateException();
   }

   class732(class545 var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      super(var1);
      this.field3639 = (byte)var5;
      this.field3640 = (byte)var6;
      this.field2978 = (short)var7;
      this.field2979 = (short)var8;
      this.method1514(new class32((float)var2, (float)var3, (float)var4));
   }

   boolean method2166(class848 var1) {
      class32 var2 = this.method1511().field7637;
      return this.field3638.field3857.method1653(this.field3640, (int)var2.field5296 >> this.field3638.field3849 * -1688804109, (int)var2.field5299 >> this.field3638.field3849 * -1688804109, this.method2168(1951240662));
   }

   final void method2162(class848 var1, class963 var2, int var3, int var4, int var5, boolean var6, int var7) {
      try {
         throw new IllegalStateException();
      } catch (RuntimeException var9) {
         throw class158.method3445(var9, "aji.bk(" + ')');
      }
   }

   final boolean method2193() {
      return false;
   }

   final boolean method2194() {
      return false;
   }

   boolean method2171(class848 var1, byte var2) {
      try {
         class32 var3 = this.method1511().field7637;
         return this.field3638.field3857.method1653(this.field3640, (int)var3.field5296 >> this.field3638.field3849 * -1688804109, (int)var3.field5299 >> this.field3638.field3849 * -1688804109, this.method2168(1951240662));
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "aji.dl(" + ')');
      }
   }

   boolean method2198(class848 var1) {
      class32 var2 = this.method1511().field7637;
      return this.field3638.field3857.method1653(this.field3640, (int)var2.field5296 >> this.field3638.field3849 * -1688804109, (int)var2.field5299 >> this.field3638.field3849 * -1688804109, this.method2168(1951240662));
   }

   boolean method2204() {
      class32 var1 = this.method1511().field7637;
      return this.field3638.field3908[583010427 * this.field3638.field3883 + (((int)var1.field5296 >> -1688804109 * this.field3638.field3849) - -804213305 * this.field3638.field3898)][((int)var1.field5299 >> -1688804109 * this.field3638.field3849) - this.field3638.field3858 * 465603579 + 583010427 * this.field3638.field3883];
   }

   boolean method2200(class848 var1) {
      class32 var2 = this.method1511().field7637;
      return this.field3638.field3857.method1653(this.field3640, (int)var2.field5296 >> this.field3638.field3849 * -1688804109, (int)var2.field5299 >> this.field3638.field3849 * -1688804109, this.method2168(1951240662));
   }

   boolean method2196(class848 var1) {
      class32 var2 = this.method1511().field7637;
      return this.field3638.field3857.method1653(this.field3640, (int)var2.field5296 >> this.field3638.field3849 * -1688804109, (int)var2.field5299 >> this.field3638.field3849 * -1688804109, this.method2168(1951240662));
   }

   boolean method2202() {
      class32 var1 = this.method1511().field7637;
      return this.field3638.field3908[583010427 * this.field3638.field3883 + (((int)var1.field5296 >> -1688804109 * this.field3638.field3849) - -804213305 * this.field3638.field3898)][((int)var1.field5299 >> -1688804109 * this.field3638.field3849) - this.field3638.field3858 * 465603579 + 583010427 * this.field3638.field3883];
   }

   boolean method2203() {
      class32 var1 = this.method1511().field7637;
      return this.field3638.field3908[583010427 * this.field3638.field3883 + (((int)var1.field5296 >> -1688804109 * this.field3638.field3849) - -804213305 * this.field3638.field3898)][((int)var1.field5299 >> -1688804109 * this.field3638.field3849) - this.field3638.field3858 * 465603579 + 583010427 * this.field3638.field3883];
   }

   boolean method2167(int var1) {
      try {
         class32 var2 = this.method1511().field7637;
         return this.field3638.field3908[583010427 * this.field3638.field3883 + (((int)var2.field5296 >> -1688804109 * this.field3638.field3849) - -804213305 * this.field3638.field3898)][((int)var2.field5299 >> -1688804109 * this.field3638.field3849) - this.field3638.field3858 * 465603579 + 583010427 * this.field3638.field3883];
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "aji.dq(" + ')');
      }
   }
}
