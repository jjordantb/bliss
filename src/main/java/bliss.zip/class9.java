public abstract class class9 {
   class13 field4965;

   abstract void method2996(class203 var1, int var2);

   abstract boolean method2997();

   abstract void method2999(int var1, int var2);

   abstract void method3000();

   abstract void method3001(boolean var1);

   class9(class13 var1) {
      this.field4965 = var1;
   }

   abstract void method3014(boolean var1);
}
