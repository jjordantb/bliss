public abstract class class9 {
   class13 field4965;

   abstract void method2996(class203 var1, int var2);

   abstract boolean method2997();

   abstract void method2998(int var1, int var2);

   abstract void method2999(int var1, int var2);

   abstract void method3000();

   abstract void method3001(boolean var1);

   class9(class13 var1) {
      this.field4965 = var1;
   }

   abstract void method3002(boolean var1);

   abstract void method3003(boolean var1);

   abstract void method3004(boolean var1);

   abstract void method3005(boolean var1);

   abstract void method3006(boolean var1);

   abstract void method3007();

   abstract void method3008();

   abstract void method3009(int var1, int var2);

   abstract void method3010(class203 var1, int var2);

   abstract void method3011(int var1, int var2);

   abstract void method3012(int var1, int var2);

   abstract void method3013(int var1, int var2);

   abstract void method3014(boolean var1);

   abstract void method3015(class203 var1, int var2);

   abstract boolean method3016();
}
