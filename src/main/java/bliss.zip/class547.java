public class class547 extends class824 implements class265 {
   boolean field408 = true;
   boolean field409;
   class719 field410;
   public class309 field411;
   static long field412;

   final void method2185() {
      throw new IllegalStateException();
   }

   boolean method2157(class848 var1, int var2, int var3, byte var4) {
      try {
         class879 var5 = this.field411.method351(var1, 131072, false, false, (byte)-17);
         return var5 == null ? false : var5.method6097(var2, var3, this.method1521(), false, 0);
      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "wm.bu(" + ')');
      }
   }

   boolean method2183(short var1) {
      try {
         return this.field408;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wm.be(" + ')');
      }
   }

   public class719 method2165(class848 var1, byte var2) {
      try {
         return this.field410;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "wm.bc(" + ')');
      }
   }

   boolean method2192(class848 var1, int var2, int var3) {
      class879 var4 = this.field411.method351(var1, 131072, false, false, (byte)-18);
      return var4 == null ? false : var4.method6097(var2, var3, this.method1521(), false, 0);
   }

   public int method2170(byte var1) {
      try {
         return this.field411.method350(2132571778);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wm.bx(" + ')');
      }
   }

   class192 method2201(class848 var1, int var2) {
      try {
         class879 var3 = this.field411.method351(var1, 2048, false, true, (byte)42);
         if (var3 == null) {
            return null;
         } else {
            class135 var4 = this.method1521();
            class446 var5 = this.method1511();
            class192 var6 = class221.method4033(this.field409, 1432921779);
            int var7 = (int)var5.field7637.field5296 >> 9;
            int var8 = (int)var5.field7637.field5299 >> 9;
            this.field411.method352(var1, var3, var4, var7, var7, var8, var8, true, 244174707);
            var3.method5965(var4, this.field3642[0], 0);
            if (this.field411.field388 != null) {
               class874 var9 = this.field411.field388.method1729();
               var1.method4866(var9);
            }

            this.field408 = var3.method5989() || this.field411.field388 != null;
            if (this.field410 == null) {
               this.field410 = class905.method6344((int)var5.field7637.field5296, (int)var5.field7637.field5300, (int)var5.field7637.field5299, var3, 2034122433);
            } else {
               class364.method1613(this.field410, (int)var5.field7637.field5296, (int)var5.field7637.field5300, (int)var5.field7637.field5299, var3, (byte)83);
            }

            return var6;
         }
      } catch (RuntimeException var10) {
         throw class158.method3445(var10, "wm.bo(" + ')');
      }
   }

   public class547(class545 var1, class848 var2, class240 var3, class50 var4, int var5, int var6, int var7, int var8, int var9, boolean var10, int var11, int var12) {
      super(var1, var7, var8, var9, var5, var6, -228547261 * var4.field2250);
      this.field411 = new class309(var2, var3, var4, class15.field6918.field6921 * -1976050083, var11, var5, var6, this, var10, var12);
      this.field409 = var4.field2214 * 1532834983 != 0 && !var10;
      this.method2169(1, 397760713);
   }

   public void method4559(class848 var1) {
      this.field411.method358(var1, -475225909);
   }

   final boolean method2173(int var1) {
      return false;
   }

   final void method2162(class848 var1, class963 var2, int var3, int var4, int var5, boolean var6, int var7) {
      try {
         throw new IllegalStateException();
      } catch (RuntimeException var9) {
         throw class158.method3445(var9, "wm.bk(" + ')');
      }
   }

   final void method2205(byte var1) {
      try {
         throw new IllegalStateException();
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wm.bq(" + ')');
      }
   }

   public int method4551(byte var1) {
      try {
         return 1686561661 * this.field411.field387;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wm.a(" + ')');
      }
   }

   public int method4548(int var1) {
      try {
         return -1598457753 * this.field411.field375;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wm.f(" + ')');
      }
   }

   public int method4549(short var1) {
      try {
         return 748228569 * this.field411.field376;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wm.b(" + ')');
      }
   }

   boolean method2179(class848 var1, int var2, int var3) {
      class879 var4 = this.field411.method351(var1, 131072, false, false, (byte)-51);
      return var4 == null ? false : var4.method6097(var2, var3, this.method1521(), false, 0);
   }

   boolean method2206(byte var1) {
      return false;
   }

   final void method2195(class848 var1, class963 var2, int var3, int var4, int var5, boolean var6) {
      throw new IllegalStateException();
   }

   public void method375(class552 var1, byte var2) {
      try {
         this.field411.method349(var1, -748656560);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "wm.by(" + ')');
      }
   }

   public void method4556(class848 var1, int var2) {
      try {
         this.field411.method358(var1, -475225909);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "wm.d(" + ')');
      }
   }

   public int method4555() {
      return -1598457753 * this.field411.field375;
   }

   public int method4554() {
      return -1598457753 * this.field411.field375;
   }

   public int method4561() {
      return 748228569 * this.field411.field376;
   }

   public int method4557() {
      return 748228569 * this.field411.field376;
   }

   public void method4553() {
   }

   public boolean method4560() {
      return this.field411.method357(16957801);
   }

   public void method4547(class848 var1) {
      this.field411.method353(var1, -1400920433);
   }

   public void method4562(class848 var1) {
      this.field411.method358(var1, -475225909);
   }

   void method2180(class848 var1) {
      class879 var2 = this.field411.method351(var1, 262144, true, true, (byte)5);
      if (var2 != null) {
         class32 var3 = this.method1511().field7637;
         int var4 = (int)var3.field5296 >> 9;
         int var5 = (int)var3.field5299 >> 9;
         this.field411.method352(var1, var2, this.method1521(), var4, var4, var5, var5, false, 264840409);
      }

   }

   public int method2168(int var1) {
      try {
         return this.field411.method356(-2145027593);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wm.bm(" + ')');
      }
   }

   public int method4564() {
      return 1686561661 * this.field411.field387;
   }

   boolean method2172() {
      return false;
   }

   boolean method2181() {
      return false;
   }

   public class719 method2174(class848 var1) {
      return this.field410;
   }

   public class719 method2175(class848 var1) {
      return this.field410;
   }

   public int method376() {
      return this.field411.method350(2084300626);
   }

   public void method4552(class848 var1, int var2) {
      try {
         this.field411.method353(var1, 1192057266);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "wm.k(" + ')');
      }
   }

   public void method4563(class848 var1) {
      this.field411.method358(var1, -475225909);
   }

   void method2178(class848 var1) {
      class879 var2 = this.field411.method351(var1, 262144, true, true, (byte)-9);
      if (var2 != null) {
         class32 var3 = this.method1511().field7637;
         int var4 = (int)var3.field5296 >> 9;
         int var5 = (int)var3.field5299 >> 9;
         this.field411.method352(var1, var2, this.method1521(), var4, var4, var5, var5, false, 1404836454);
      }

   }

   public int method2187() {
      return this.field411.method356(1657985578);
   }

   final boolean method2194() {
      return false;
   }

   public int method2188() {
      return this.field411.method356(-1816306113);
   }

   boolean method2159(class848 var1, int var2, int var3) {
      class879 var4 = this.field411.method351(var1, 131072, false, false, (byte)-102);
      return var4 == null ? false : var4.method6097(var2, var3, this.method1521(), false, 0);
   }

   final void method2182(class848 var1, class963 var2, int var3, int var4, int var5, boolean var6) {
      throw new IllegalStateException();
   }

   public boolean method4558(int var1) {
      try {
         return this.field411.method357(260525653);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wm.i(" + ')');
      }
   }

   final void method2184() {
      throw new IllegalStateException();
   }

   void method2164(class848 var1, int var2) {
      try {
         class879 var3 = this.field411.method351(var1, 262144, true, true, (byte)-16);
         if (var3 != null) {
            class32 var4 = this.method1511().field7637;
            int var5 = (int)var4.field5296 >> 9;
            int var6 = (int)var4.field5299 >> 9;
            this.field411.method352(var1, var3, this.method1521(), var5, var5, var6, var6, false, 1937927561);
         }

      } catch (RuntimeException var7) {
         throw class158.method3445(var7, "wm.bb(" + ')');
      }
   }

   public int method2186() {
      return this.field411.method356(1926384337);
   }

   final boolean method2193() {
      return false;
   }

   boolean method2176() {
      return this.field408;
   }

   boolean method2189() {
      return this.field408;
   }

   boolean method2156() {
      return this.field408;
   }

   boolean method2190() {
      return this.field408;
   }

   boolean method2158() {
      return this.field408;
   }

   final boolean method2191() {
      return false;
   }

   boolean method2160() {
      return false;
   }

   public void method4550(byte var1) {
   }

   class192 method2177(class848 var1) {
      class879 var2 = this.field411.method351(var1, 2048, false, true, (byte)-3);
      if (var2 == null) {
         return null;
      } else {
         class135 var3 = this.method1521();
         class446 var4 = this.method1511();
         class192 var5 = class221.method4033(this.field409, 1939994642);
         int var6 = (int)var4.field7637.field5296 >> 9;
         int var7 = (int)var4.field7637.field5299 >> 9;
         this.field411.method352(var1, var2, var3, var6, var6, var7, var7, true, 1228885360);
         var2.method5965(var3, this.field3642[0], 0);
         if (this.field411.field388 != null) {
            class874 var8 = this.field411.field388.method1729();
            var1.method4866(var8);
         }

         this.field408 = var2.method5989() || this.field411.field388 != null;
         if (this.field410 == null) {
            this.field410 = class905.method6344((int)var4.field7637.field5296, (int)var4.field7637.field5300, (int)var4.field7637.field5299, var2, 1982662132);
         } else {
            class364.method1613(this.field410, (int)var4.field7637.field5296, (int)var4.field7637.field5300, (int)var4.field7637.field5299, var2, (byte)26);
         }

         return var5;
      }
   }

   public int method377() {
      return this.field411.method350(2101198661);
   }

   final boolean method2207() {
      return false;
   }

   static final void method378(class744 var0, byte var1) {
      try {
         class684 var2 = class423.method5712((short)512);
         class701 var3 = class637.method5936(class643.field10016, var2.field7765, (byte)18);
         var3.field3364.method6361(0);
         int var4 = var3.field3364.field10376 * 385051775;
         var3.field3364.method6361(2);
         var3.field3364.method6362(var0.field3160.field6482 * -2034569943, 16711935);
         var0.field3160.field6483.method6656(var3.field3364, var0.field3160.field6484, 1820223429);
         var3.field3364.method6426(385051775 * var3.field3364.field10376 - var4, (byte)-61);
         var2.method4380(var3, (byte)-22);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "wm.adk(" + ')');
      }
   }

   public static void method379(byte var0) {
      try {
         class967.method1750(17, 1188643494);
         class526.method2231(-1182326447);
         System.gc();
      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "wm.lx(" + ')');
      }
   }

   static final void method380(class744 var0, short var1) {
      try {
         int var2 = var0.field3161[(var0.field3156 -= -391880689) * 681479919];
         int[] var3 = class256.method4490(var2, 1679514983);
         class901.method6355(var3, 0, var0.field3161, 681479919 * var0.field3156, 3);
         var0.field3156 += -1175642067;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "wm.akm(" + ')');
      }
   }
}
