public class class356 extends class717 {
   int field1793;
   class746 field1794;
   static class616 field1795 = new class616();
   static int field1796 = 0;
   int field1797;
   int field1798;
   int field1799;
}
