public class class807 {
   public static class807 field4413 = new class807(116, 6);
   public static class807 field4414 = new class807(21, 6);
   public static class807 field4415 = new class807(2, -2);
   public static class807 field4416 = new class807(3, -1);
   public static class807 field4417 = new class807(4, 19);
   public static class807 field4418 = new class807(5, 4);
   public static class807 field4419 = new class807(6, 1);
   public static class807 field4420 = new class807(7, 4);
   public static class807 field4421 = new class807(8, -1);
   public static class807 field4422 = new class807(9, 6);
   public static class807 field4423 = new class807(36, 29);
   public static class807 field4424 = new class807(11, -2);
   public static class807 field4425 = new class807(12, 1);
   public static class807 field4426 = new class807(13, 2);
   public static class807 field4427 = new class807(14, 23);
   public int field4428;
   public static class807 field4429 = new class807(16, 0);
   public static class807 field4430 = new class807(17, -2);
   public static class807 field4431 = new class807(18, 0);
   public static class807 field4432 = new class807(135, -2);
   public static class807 field4433 = new class807(20, 16);
   public static class807 field4434 = new class807(44, 6);
   public static class807 field4435 = new class807(22, 10);
   public static class807 field4436 = new class807(23, 4);
   public static class807 field4437 = new class807(24, -1);
   public static class807 field4438 = new class807(25, 1);
   public static class807 field4439 = new class807(26, 8);
   public static class807 field4440 = new class807(27, 28);
   public static class807 field4441 = new class807(91, -1);
   public static class807 field4442 = new class807(29, 9);
   public static class807 field4443 = new class807(30, -1);
   public static class807 field4444 = new class807(31, 8);
   public static class807 field4445 = new class807(114, 6);
   public static class807 field4446 = new class807(33, -1);
   public static class807 field4447 = new class807(47, 8);
   public static class807 field4448 = new class807(35, 0);
   public static class807 field4449 = new class807(19, 2);
   public int field4450;
   public static class807 field4451 = new class807(38, 6);
   public static class807 field4452 = new class807(39, 19);
   public static class807 field4453 = new class807(40, 12);
   public static class807 field4454 = new class807(41, 6);
   public static class807 field4455 = new class807(42, -2);
   public static class807 field4456 = new class807(43, -1);
   public static class807 field4457 = new class807(52, 11);
   public static class807 field4458 = new class807(15, 1);
   public static class807 field4459 = new class807(95, 0);
   public static class807 field4460 = new class807(158, 3);
   public static class807 field4461 = new class807(159, 1);
   public static class807 field4462 = new class807(48, 10);
   public static class807 field4463 = new class807(49, -1);
   public static class807 field4464 = new class807(72, -2);
   public static class807 field4465 = new class807(51, 2);
   public static class807 field4466 = new class807(120, 6);
   public static class807 field4467 = new class807(53, 20);
   public static class807 field4468 = new class807(66, 0);
   public static class807 field4469 = new class807(10, -1);
   public static class807 field4470 = new class807(56, 6);
   public static class807 field4471 = new class807(57, 25);
   public static class807 field4472 = new class807(58, 2);
   public static class807 field4473 = new class807(46, 4);
   public static class807 field4474 = new class807(34, -2);
   public static class807 field4475 = new class807(55, -2);
   public static class807 field4476 = new class807(50, 5);
   public static class807 field4477 = new class807(63, 6);
   public static class807 field4478 = new class807(64, -2);
   public static class807 field4479 = new class807(65, 7);
   public static class807 field4480 = new class807(77, -2);
   public static class807 field4481 = new class807(67, 0);
   public static class807 field4482 = new class807(68, 8);
   public static class807 field4483 = new class807(32, -1);
   public static class807 field4484 = new class807(151, 3);
   public static class807 field4485 = new class807(71, 9);
   public static class807 field4486 = new class807(134, -1);
   public static class807 field4487 = new class807(73, 4);
   public static class807 field4488 = new class807(74, 6);
   public static class807 field4489 = new class807(75, 1);
   public static class807 field4490 = new class807(76, 9);
   public static class807 field4491 = new class807(0, -1);
   public static class807 field4492 = new class807(78, 0);
   public static class807 field4493 = new class807(70, 6);
   public static class807 field4494 = new class807(80, 6);
   public static class807 field4495 = new class807(94, 17);
   public static class807 field4496 = new class807(140, 8);
   public static class807 field4497 = new class807(142, -2);
   public static class807 field4498 = new class807(97, -2);
   public static class807 field4499 = new class807(81, 6);
   public static class807 field4500 = new class807(88, -2);
   public static class807 field4501 = new class807(87, 3);
   public static class807 field4502 = new class807(54, 10);
   public static class807 field4503 = new class807(89, 2);
   public static class807 field4504 = new class807(90, 12);
   public static class807 field4505 = new class807(123, 4);
   public static class807 field4506 = new class807(92, 1);
   public static class807 field4507 = new class807(59, 0);
   public static class807 field4508 = new class807(117, -2);
   public static class807 field4509 = new class807(85, -2);
   public static class807 field4510 = new class807(96, -2);
   public static class807 field4511 = new class807(83, -1);
   public static class807 field4512 = new class807(82, 1);
   public static class807 field4513 = new class807(99, 10);
   public static class807 field4514 = new class807(109, 4);
   public static class807 field4515 = new class807(101, 8);
   public static class807 field4516 = new class807(130, -2);
   public static class807 field4517 = new class807(103, 8);
   public static class807 field4518 = new class807(104, -1);
   public static class807 field4519 = new class807(150, 2);
   public static class807 field4520 = new class807(106, -1);
   public static class807 field4521 = new class807(107, -1);
   public static class807 field4522 = new class807(108, 3);
   public static class807 field4523 = new class807(37, 4);
   public static class807 field4524 = new class807(110, 3);
   public static class807 field4525 = new class807(62, -2);
   public static class807 field4526 = new class807(112, 5);
   public static class807 field4527 = new class807(113, 25);
   public static class807 field4528 = new class807(102, 8);
   public static class807 field4529 = new class807(115, 5);
   public static class807 field4530 = new class807(1, -1);
   public static class807 field4531 = new class807(100, 10);
   public static class807 field4532 = new class807(118, -1);
   public static class807 field4533 = new class807(119, -2);
   public static class807 field4534 = new class807(84, 6);
   public static class807 field4535 = new class807(121, 8);
   public static class807 field4536 = new class807(122, 8);
   public static class807 field4537 = new class807(143, 32);
   public static class807 field4538 = new class807(124, 8);
   public static class807 field4539 = new class807(125, 5);
   public static class807 field4540 = new class807(126, -2);
   public static class807 field4541 = new class807(127, 10);
   public static class807 field4542 = new class807(128, -1);
   public static class807 field4543 = new class807(129, 4);
   public static class807 field4544 = new class807(45, 2);
   public static class807 field4545 = new class807(131, 0);
   public static class807 field4546 = new class807(132, -2);
   public static class807 field4547 = new class807(133, -2);
   public static class807 field4548 = new class807(28, 7);
   public static class807 field4549 = new class807(69, 1);
   public static class807 field4550 = new class807(136, -1);
   public static class807 field4551 = new class807(137, 5);
   public static class807 field4552 = new class807(138, -2);
   public static class807 field4553 = new class807(139, -1);
   public static class807 field4554 = new class807(86, 22);
   public static class807 field4555 = new class807(141, 2);
   public static class807 field4556 = new class807(105, -2);
   public static class807 field4557 = new class807(93, 3);
   public static class807 field4558 = new class807(144, -2);
   public static class807 field4559 = new class807(145, 0);
   public static class807 field4560 = new class807(146, 6);
   public static class807 field4561 = new class807(147, 1);
   public static class807 field4562 = new class807(148, -2);
   public static class807 field4563 = new class807(149, 2);
   public static class807 field4564 = new class807(79, 14);
   public static class807 field4565 = new class807(61, -1);
   public static class807 field4566 = new class807(152, 10);
   public static class807 field4567 = new class807(153, 0);
   public static class807 field4568 = new class807(154, 3);
   public static class807 field4569 = new class807(155, 8);
   public static class807 field4570 = new class807(156, 3);
   public static class807 field4571 = new class807(157, 5);
   public static class807 field4572 = new class807(60, 0);
   public static class807 field4573 = new class807(98, 2);
   public static class807 field4574 = new class807(111, 3);

   class807(int var1, int var2) {
      this.field4450 = -477306055 * var1;
      this.field4428 = -1324781857 * var2;
   }

   static final void method2828(class744 var0, int var1) {
      try {
         var0.field3156 -= -783761378;
         int var2 = var0.field3161[681479919 * var0.field3156];
         int var3 = var0.field3161[681479919 * var0.field3156 + 1];
         var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = class776.method2296(var2, var3, false, 1051533242);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "in.tv(" + ')');
      }
   }

   static final void method2829(class744 var0, byte var1) {
      try {
         var0.field3156 -= -783761378;
         int var2 = var0.field3161[681479919 * var0.field3156];
         int var3 = var0.field3161[1 + var0.field3156 * 681479919];
         var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = var3 + var2;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "in.yk(" + ')');
      }
   }

   static final void method2830(class744 var0, byte var1) {
      try {
         class615.field8903.method5391(class615.field8903.field9122, var0.field3161[(var0.field3156 -= -391880689) * 681479919] == 1 ? 1 : 0, -802327901);
         class730.field2697.method5309(549218846);
         class95.method523(656179282);
         class730.field2647 = false;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "in.aii(" + ')');
      }
   }

   static final void method2831(class744 var0, byte var1) {
      try {
         String var2 = (String)var0.field3157[(var0.field3158 -= 969361751) * -203050393];
         int var3 = 0;
         if (class808.method2894(var2, 1423765975)) {
            var3 = class82.method917(var2, (short)6366);
         }

         class701 var4 = class637.method5936(class643.field10011, class730.field2692.field7765, (byte)125);
         var4.field3364.method6364(var3, -1055367891);
         class730.field2692.method4380(var4, (byte)-42);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "in.sz(" + ')');
      }
   }

   static final void method2832(class744 var0, int var1) {
      try {
         class237 var2 = var0.field3178 ? var0.field3164 : var0.field3163;
         class564 var3 = var2.field8255;
         class131 var4 = var2.field8254;
         class384.method1082(var3, var4, var0, (byte)16);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "in.gd(" + ')');
      }
   }
}
