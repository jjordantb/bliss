public interface class951 {
   Object method2017(int[] var1, int var2, int var3, int var4, int var5, boolean var6);

   Object method2018(int[] var1, int var2, int var3, int var4, int var5, boolean var6);

   Object method2019(int[] var1, int var2, int var3, int var4, int var5, boolean var6, int var7);

   Object method2020(int[] var1, int var2, int var3, int var4, int var5, boolean var6);
}
