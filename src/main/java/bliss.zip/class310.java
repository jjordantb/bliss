public class class310 {
   boolean field530;
   class419[] field531;
   public static class180 field532;
   static int field533;

   class310(boolean var1, class419[] var2) {
      this.field530 = var1;
      this.field531 = var2;
   }

   static final void method455(class744 var0, byte var1) {
      try {
         boolean var2 = var0.field3161[(var0.field3156 -= -391880689) * 681479919] == 1;
         class615.field8903.method5391(class615.field8903.field9130, var2 ? 2 : 1, 437258176);
         class615.field8903.method5391(class615.field8903.field9131, var2 ? 2 : 1, -618485822);
         class247.method4722((short)-10564);
         class95.method523(656179282);
         class730.field2647 = false;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "vz.ahh(" + ')');
      }
   }

   public static class7[] method456(int var0) {
      try {
         return new class7[]{class7.field4912, class7.field4908, class7.field4909, class7.field4910, class7.field4911, class7.field4915, class7.field4916, class7.field4907, class7.field4913, class7.field4914};
      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "vz.a(" + ')');
      }
   }
}
