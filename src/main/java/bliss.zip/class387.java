public interface class387 {
   void method1190(int var1, byte[] var2, int var3);

   long method1191();

   int method1197();
}
