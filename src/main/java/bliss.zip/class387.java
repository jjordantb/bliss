public interface class387 {
   void method1189(int var1, byte[] var2, int var3);

   void method1190(int var1, byte[] var2, int var3);

   long method1191();

   int method1192();

   int method1193();

   long method1194();

   long method1195();

   void method1196(int var1, byte[] var2, int var3);

   int method1197();

   void method1198(int var1, byte[] var2, int var3);
}
