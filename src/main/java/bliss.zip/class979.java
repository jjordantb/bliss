public class class979 {
   public static int field3083 = 17;
   public static int field3084 = 4;
   public static int field3085 = 20;
   public static int field3086 = 1;
   public static int field3087 = 21;
   public static int field3088 = 27;
   public static int field3089 = 28;
   public static int field3090 = 9;
   public static int field3091 = 7;
   public static int field3092 = 15;
   public static int field3093 = 26;
   public static int field3094 = 31;
   public static int field3095 = 12;
   public static int field3096 = 5;
   public static int field3097 = 14;
   public static int field3098 = 22;
   public static int field3099 = 23;
   public static int field3100 = 29;
   public static int field3101 = 32;
   public static int field3102 = 8;
   public static int field3103 = 16;
   public static int field3104 = 24;
   public static int field3105 = 33;
   public static int field3106 = 6;
   public static int field3107 = 11;
   public static int field3108 = 10;
   public static int field3109 = 18;
   public static int field3110 = 13;
   public static int field3111 = 25;
   public static int field3112 = 3;
   public static int field3113 = 2;
   public static int field3114 = 30;

   class979() throws Throwable {
      throw new Error();
   }

   static final void method1830(class744 var0, byte var1) {
      try {
         class237 var2 = var0.field3178 ? var0.field3164 : var0.field3163;
         class564 var3 = var2.field8255;
         class131 var4 = var2.field8254;
         class176.method3168(var3, var4, var0, 1051610527);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "if.np(" + ')');
      }
   }

   static final void method1831(class744 var0, int var1) {
      try {
         int var2 = var0.field3161[(var0.field3156 -= -391880689) * 681479919];
         class564 var3 = class449.method3756(var2, (byte)83);
         class131 var4 = class382.field1410[var2 >> 16];
         class472.method4612(var3, var4, var0, -389689371);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "if.oa(" + ')');
      }
   }

   static final void method1832(class744 var0, int var1) {
      try {
         var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = class563.field1083 * -863531439 == 4 ? 1 : 0;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "if.agy(" + ')');
      }
   }

   static final void method1833(class744 var0, int var1) {
      try {
         int var2 = var0.field3161[(var0.field3156 -= -391880689) * 681479919];
         class615.field8903.method5391(class615.field8903.field9129, var2, 965049953);
         class95.method523(656179282);
         class730.field2647 = false;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "if.aih(" + ')');
      }
   }

   public static class312 method1834(int var0, int var1, int var2, int var3, class15 var4, int var5, byte var6) {
      try {
         class673.field7512.field476 = var0 * -760677635;
         class673.field7512.field475 = 167105303 * var1;
         class673.field7512.field477 = var2 * -1544157451;
         class673.field7512.field478 = -1468199503 * var3;
         class673.field7512.field9026 = var4;
         class673.field7512.field9027 = -2142070477 * var5;
         return class673.field7512;
      } catch (RuntimeException var8) {
         throw class158.method3445(var8, "if.k(" + ')');
      }
   }

   public static void method1835(int var0) {
      try {
         class71.method1084(1437455433);
         class602.field8645 = false;
         class431.method4254(class622.field9006 * -1347746885, class281.field10643 * 1089948687, 608683427 * class809.field4595, 1396607435 * class873.field9785, (byte)2);
         class713.field3542 = null;
         class348.field220 = null;
      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "if.s(" + ')');
      }
   }

   static final void method1836(class744 var0, byte var1) {
      try {
         class237 var2 = var0.field3178 ? var0.field3164 : var0.field3163;
         class564 var3 = var2.field8255;
         var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = var3.field891 * 684246511;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "if.pd(" + ')');
      }
   }

   static final void method1837(class564 var0, class131 var1, class744 var2, byte var3) {
      try {
         var0.field957 = var2.field3161[(var2.field3156 -= -391880689) * 681479919] * -7527659;
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "if.jq(" + ')');
      }
   }
}
