public final class class122 {
   static String field2371 = "#";
   static int field2372;
   static class622 field2373;

   class122() throws Throwable {
      throw new Error();
   }

   static final void method1601(class744 var0, int var1) {
      try {
         var0.field3156 -= 2;
         if (var0.field3161[var0.field3156] < var0.field3161[var0.field3156 + 1]) {
            var0.field3176 += var0.field3174[var0.field3176];
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "eu.ax(" + ')');
      }
   }

   static final void method1602(class744 var0, int var1) {
      try {
         class237 var2 = var0.field3178 ? var0.field3164 : var0.field3163;
         class564 var3 = var2.field8255;
         class131 var4 = var2.field8254;
         class370.method877(var3, var4, var0, (byte)-2);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "eu.dq(" + ')');
      }
   }

   static final void method1603(class564 var0, class131 var1, class744 var2, int var3) {
      try {
         String var4 = (String)var2.field3157[--var2.field3158];
         if (class960.method2212(var4, var2, -1678737693) != null) {
            var4 = var4.substring(0, var4.length() - 1);
         }

         var0.field965 = class634.method5872(var4, var2, -2046058202);
         var0.field963 = true;
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "eu.kk(" + ')');
      }
   }

   static final void method1604(class744 var0, int var1) {
      try {
         var0.field3156 -= 2;
         int var2 = var0.field3161[var0.field3156];
         int var3 = var0.field3161[var0.field3156 + 1];
         var0.field3161[++var0.field3156 - 1] = var2 | var3;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "eu.zp(" + ')');
      }
   }

   static final void method1605(class744 var0, byte var1) {
      try {
         int var2 = var0.field3161[--var0.field3156];
         var0.field3161[++var0.field3156 - 1] = class85.field1121.method1566(var2).field4253;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "eu.aao(" + ')');
      }
   }

   static final void method1606(class744 var0, byte var1) {
      try {
         class471 var2 = class5.method2961((byte)21);
         if (var2 != null) {
            var0.field3161[++var0.field3156 - 1] = var2.field8235;
            var0.field3161[++var0.field3156 - 1] = var2.field3476;
            var0.field3157[++var0.field3158 - 1] = var2.field8237;
            class188 var3 = var2.method4615(-1326111472);
            var0.field3161[++var0.field3156 - 1] = var3.field5348;
            var0.field3157[++var0.field3158 - 1] = var3.field5347;
            var0.field3161[++var0.field3156 - 1] = var2.field3472;
            var0.field3161[++var0.field3156 - 1] = var2.field8238;
            var0.field3157[++var0.field3158 - 1] = var2.field8236;
         } else {
            var0.field3161[++var0.field3156 - 1] = -1;
            var0.field3161[++var0.field3156 - 1] = 0;
            var0.field3157[++var0.field3158 - 1] = "";
            var0.field3161[++var0.field3156 - 1] = 0;
            var0.field3157[++var0.field3158 - 1] = "";
            var0.field3161[++var0.field3156 - 1] = 0;
            var0.field3161[++var0.field3156 - 1] = 0;
            var0.field3157[++var0.field3158 - 1] = "";
         }

      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "eu.alb(" + ')');
      }
   }

   static final void method1607(class744 var0, byte var1) {
      try {
         var0.field3161[++var0.field3156 - 1] = var0.field3169.method5776((String)var0.field3157[--var0.field3158], 131072);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "eu.xt(" + ')');
      }
   }

   public static void method1608(int var0, int var1, int var2) {
      try {
         class740.field3206 = var0 - class491.field7820;
         class740.field3201 = var1 - class491.field7813;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "eu.ct(" + ')');
      }
   }

   static final void method1609(class744 var0, int var1) {
      try {
         class237 var2 = var0.field3178 ? var0.field3164 : var0.field3163;
         class564 var3 = var2.field8255;
         class131 var4 = var2.field8254;
         class232.method4660(var3, var4, var0, 852607331);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "eu.gq(" + ')');
      }
   }
}
