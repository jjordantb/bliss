public class class176 {
   public int field5208;
   public int field5209;
   public int field5210;
   public int field5211;
   public int field5212;
   public boolean field5213;
   public int field5214 = 16777215;
   public int field5215;
   public int field5216;
   public int field5217 = 8;
   public int field5218;

   void method3161(class907 var1, byte var2) {
      try {
         while(true) {
            int var3 = var1.method6371();
            if (var3 == 0) {
               if (var2 < 1) {
                  ;
               }

               return;
            }

            this.method3162(var1, var3, (short)6892);
         }
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "fb.a(" + ')');
      }
   }

   void method3162(class907 var1, int var2, short var3) {
      try {
         if (1 == var2) {
            this.field5217 = var1.method6374();
         } else if (2 == var2) {
            this.field5213 = true;
         } else if (3 == var2) {
            this.field5210 = var1.method6367(1536042537);
            this.field5216 = var1.method6367(1731816677);
            this.field5208 = var1.method6367(2113073635);
         } else if (4 == var2) {
            this.field5218 = var1.method6371();
         } else if (5 == var2) {
            this.field5215 = var1.method6423(1235052657);
         } else if (var2 == 6) {
            this.field5214 = var1.method6390((byte)-37);
         } else if (var2 == 7) {
            this.field5212 = var1.method6367(2027099715);
            this.field5211 = var1.method6367(1934566489);
            this.field5209 = var1.method6367(2047169490);
         }

      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "fb.f(" + ')');
      }
   }

   static final void method3163(class744 var0, int var1) {
      try {
         var0.field3156 -= 2;
         int var2 = var0.field3161[var0.field3156];
         int var3 = var0.field3161[1 + var0.field3156];
         var0.field3161[++var0.field3156 - 1] = class859.method5179(var2, var3, true, -880312954);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "fb.tq(" + ')');
      }
   }

   static final void method3164(class744 var0, int var1) {
      try {
         var0.field3156 -= 2;
         int var2 = var0.field3161[var0.field3156];
         int var3 = var0.field3161[1 + var0.field3156];
         class295.method6520(var2, var3 >> 14 & 16383, var3 & 16383, false, 1608871018);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "fb.aen(" + ')');
      }
   }

   static final void method3165(class744 var0, int var1) {
      try {
         class60 var2 = (class60)var0.field3159;
         String var3 = var2.field1633;
         class401 var4 = var2.field1637;
         if (var4.field9924 != null) {
            var4 = var4.method6110(class827.field9037, 1606413785);
            if (var4 == null) {
               var3 = "";
            } else {
               var3 = var4.field9863;
            }
         }

         if (var3 == null) {
            var3 = "";
         }

         var0.field3157[++var0.field3158 - 1] = var3;
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "fb.aoq(" + ')');
      }
   }

   static void method3166(int var0, boolean var1, int var2) {
      try {
         if (var1) {
            class701 var3 = class637.method5936(class643.field9973, class730.field2692.field7765, (byte)105);
            var3.field3364.method6362(var0, 16711935);
            class730.field2692.method4380(var3, (byte)-34);
         } else {
            class574.method131(class112.field2117, var0, -1, -1830852893);
         }

      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "fb.p(" + ')');
      }
   }

   static void method3167(class701 var0, int var1, int var2, int var3, int var4) {
      try {
         var0.field3364.method6408(var1);
         var0.field3364.method6419(var3);
         var0.field3364.method6400(var2);
      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "fb.ka(" + ')');
      }
   }

   static final void method3168(class564 var0, class131 var1, class744 var2, int var3) {
      try {
         String var4 = (String)var2.field3157[--var2.field3158];
         if (class960.method2212(var4, var2, -255285486) != null) {
            var4 = var4.substring(0, var4.length() - 1);
         }

         var0.field1000 = class634.method5872(var4, var2, -2046058202);
         var0.field963 = true;
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "fb.nv(" + ')');
      }
   }

   static int method3169(class60 var0, int var1) {
      try {
         class401 var2 = var0.field1637;
         if (var2.field9924 != null) {
            var2 = var2.method6110(class827.field9037, 1880791850);
            if (var2 == null) {
               return -1;
            }
         }

         int var3 = var2.field9905;
         class507 var4 = var0.method2554(1451181541);
         int var5 = var0.field4041.method2779(1966806311);
         if (var5 != -1 && !var0.field4058) {
            if (var4.field3979 != var5 && var5 != var4.field4007 && var4.field3982 != var5 && var5 != var4.field4004) {
               if (var4.field4013 == var5 || var5 == var4.field3980 || var5 == var4.field3986 || var4.field3985 == var5) {
                  var3 = var2.field9910;
               }
            } else {
               var3 = var2.field9912;
            }
         } else {
            var3 = var2.field9887;
         }

         return var3;
      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "fb.x(" + ')');
      }
   }

   static class200[] method3170(byte var0) {
      try {
         return new class200[]{class200.field7738, class200.field7755, class200.field7721, class200.field7756, class200.field7752, class200.field7727, class200.field7749, class200.field7739, class200.field7748, class200.field7735, class200.field7736, class200.field7743, class200.field7740, class200.field7725, class200.field7754, class200.field7750, class200.field7728, class200.field7744, class200.field7747, class200.field7757, class200.field7724, class200.field7726, class200.field7751, class200.field7741, class200.field7753, class200.field7742, class200.field7729, class200.field7731, class200.field7722, class200.field7737, class200.field7733, class200.field7746, class200.field7734, class200.field7723, class200.field7745, class200.field7730, class200.field7732};
      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "fb.a(" + ')');
      }
   }

   static final void method3171(int var0, int var1, int var2, int var3, int var4, boolean var5, int var6) {
      try {
         if (!var5 && (var1 < 512 || var2 < 512 || var1 > (class730.field2697.method5271(-2030738775) - 2) * 512 || var2 > (class730.field2697.method5272(346597058) - 2) * 512)) {
            float[] var9 = class730.field2873;
            class730.field2873[1] = -1.0F;
            var9[0] = -1.0F;
         } else {
            int var7 = class679.method4271(var1, var2, var0, -1332954611) - var4;
            class730.field2853.method1024(class593.field1623.method4868());
            class730.field2853.method1018((float)var3, 0.0F, 0.0F);
            class593.field1623.method4867(class730.field2853);
            if (var5) {
               class593.field1623.method4890((float)var1, (float)var7, (float)var2, class730.field2873);
            } else {
               class593.field1623.method4889((float)var1, (float)var7, (float)var2, class730.field2873);
            }

            class730.field2853.method1018((float)(-var3), 0.0F, 0.0F);
            class593.field1623.method4867(class730.field2853);
            class730.field2873[0] -= (float)class730.field2918;
            class730.field2873[1] -= (float)class730.field2728;
         }

      } catch (RuntimeException var8) {
         throw class158.method3445(var8, "fb.jk(" + ')');
      }
   }

   static int method3172(byte var0) {
      try {
         int var1;
         if (class615.field8903.field9145.method2311((byte)-102) == 0) {
            for(var1 = 0; var1 < class730.field2876; ++var1) {
               if (class730.field2691[var1].method1864((byte)-58) == 's' || class730.field2691[var1].method1864((byte)-73) == 'S') {
                  class615.field8903.method5391(class615.field8903.field9145, 1, -669556569);
                  class730.field2628 = true;
                  break;
               }
            }
         }

         if (class776.field3728 == class431.field7490) {
            if (class117.field1868 == null) {
               class117.field1868 = new class640(class794.field541, class732.field2980, class449.field7060, class449.field7059);
            }

            if (!class117.field1868.method6182(2031500180)) {
               return 0;
            }

            class397.method3475(0, (String)null, true, (short)256);
            class657.field9549 = !class919.method6485((byte)3);
            class27.field6487 = class381.method1065(class657.field9549 ? class200.field7755 : class200.field7753, false, 1, true, 1414942231);
            class657.field9546 = class381.method1065(class200.field7754, false, 1, true, 1414942231);
            class526.field3666 = class381.method1065(class200.field7734, false, 1, true, 1414942231);
         }

         int var2;
         boolean var9;
         if (class431.field7483 == class776.field3728) {
            var9 = class657.field9546.method3262(380717281);
            var2 = class593.field1624[class200.field7754.method4349(1981547205)].method1957(1121322968);
            var2 += class593.field1624[class657.field9549 ? class200.field7755.method4349(-1014323373) : class200.field7753.method4349(-1736042893)].method1957(1121322968);
            var2 += class593.field1624[class200.field7734.method4349(-202973063)].method1957(1121322968);
            var2 += var9 ? 100 : class657.field9546.method3263((byte)4);
            if (var2 != 400) {
               return var2 / 4;
            }

            class890.field9269 = class27.field6487.method3255((byte)-31);
            class122.field2372 = class657.field9546.method3255((byte)-108);
            class917.method6453(class27.field6487, (byte)13);
            int var3 = class615.field8903.field9144.method1564(-463949651);
            class965.field2534 = new class613(class730.field2926, class321.field1066, class657.field9546);
            class419[] var4 = class965.field2534.method5202(var3, -957350299);
            if (var4.length == 0) {
               var4 = class965.field2534.method5202(0, -2070003816);
            }

            class762 var5 = new class762(class27.field6487, class526.field3666);
            if (var4.length > 0) {
               class657.field9544 = new class940[var4.length];

               for(int var6 = 0; var6 < class657.field9544.length; ++var6) {
                  class657.field9544[var6] = new class791(class965.field2534.method5203(var4[var6].field9519, (byte)89), var4[var6].field9517, var4[var6].field9518, var5);
               }
            }
         }

         if (class431.field7484 == class776.field3728) {
            class785.field3827 = new class500(class27.field6487, class526.field3666, class419.method5641(-1719059338));
         }

         if (class776.field3728 == class431.field7485) {
            var1 = class785.field3827.method1851(2082019062);
            var2 = class785.field3827.method1852(1886749638);
            if (var1 < var2) {
               return 100 * var1 / var2;
            }
         }

         if (class776.field3728 == class431.field7486) {
            if (class657.field9544 != null && class657.field9544.length > 0) {
               if (class657.field9544[0].method6324((byte)54) < 100) {
                  return 0;
               }

               if (class657.field9544.length > 1 && class965.field2534.method5204((byte)-52) && class657.field9544[1].method6324((byte)126) < 100) {
                  return 0;
               }
            }

            class785.field3827.method1856(class730.field2681, (byte)3);
            class867.method5833(class593.field1623, -1001154805);
            class967.method1750(11, -22830656);
         }

         if (class431.field7487 == class776.field3728) {
            class562.field827 = class381.method1065(class200.field7722, false, 1, false, 1414942231);
            class812.field4643 = class381.method1065(class200.field7731, false, 1, false, 1414942231);
            class785.field3825 = class381.method1065(class200.field7733, false, 1, false, 1414942231);
            class429.field7413 = class381.method1065(class200.field7723, false, 1, true, 1414942231);
            class120.field2292 = class381.method1065(class200.field7724, false, 1, true, 1414942231);
            class783.field3963 = class381.method1065(class200.field7751, false, 1, false, 1414942231);
            class948.field3291 = class381.method1065(class200.field7726, true, 1, false, 1414942231);
            class771.field3732 = class381.method1065(class200.field7727, true, 1, false, 1414942231);
            class389.field1524 = class381.method1065(class200.field7745, false, 1, false, 1414942231);
            class576.field72 = class381.method1065(class200.field7730, false, 1, true, 1414942231);
            class27.field6488 = class381.method1065(class200.field7728, false, 1, false, 1414942231);
            class972.field2964 = class381.method1065(class200.field7732, false, 1, false, 1414942231);
            class969.field2496 = class381.method1065(class200.field7743, false, 1, true, 1414942231);
            class967.field2604 = class381.method1065(class200.field7735, false, 1, false, 1414942231);
            class151.field5372 = class381.method1065(class200.field7736, false, 1, false, 1414942231);
            class170.field5104 = class381.method1065(class200.field7725, false, 1, true, 1414942231);
            class310.field532 = class381.method1065(class200.field7738, false, 1, true, 1414942231);
            class49.field5185 = class381.method1065(class200.field7739, false, 1, true, 1414942231);
            class452.field7215 = class381.method1065(class200.field7752, false, 1, true, 1414942231);
            class553.field518 = class381.method1065(class200.field7740, false, 1, true, 1414942231);
            class831.field9108 = class381.method1065(class200.field7742, false, 1, true, 1414942231);
            class754.field4207 = class381.method1065(class200.field7741, false, 1, true, 1414942231);
            class792.field510 = class381.method1065(class200.field7756, true, 1, false, 1414942231);
            class785.field3826 = class381.method1065(class200.field7721, false, 1, true, 1414942231);
            class335.field53 = class381.method1065(class200.field7746, false, 1, true, 1414942231);
            class428.field7416 = class381.method1065(class200.field7747, true, 1, true, 1414942231);
            class808.field4597 = class381.method1065(class200.field7748, false, 1, true, 1414942231);
            class966.field2521 = class381.method1065(class200.field7749, true, 1, true, 1414942231);
            class544.field3795 = class381.method1065(class200.field7737, false, 1, true, 1414942231);
            class966.field2522 = class381.method1065(class200.field7729, true, 1, false, 1414942231);
            class856.field8889 = class381.method1065(class200.field7750, true, 1, false, 1414942231);
            class776.field3729 = class381.method1065(class200.field7744, true, 1, true, 1414942231);
            class16.field6892 = class381.method1065(class200.field7757, true, 2, false, 1414942231);
         }

         if (class776.field3728 == class431.field7488) {
            var1 = 0;

            for(var2 = 0; var2 < class593.field1624.length; ++var2) {
               if (class593.field1624[var2] != null) {
                  var1 += class593.field1624[var2].method1957(1121322968) * class657.field9550[var2] / 100;
               }
            }

            if (var1 != 100) {
               if (class657.field9547 < 0) {
                  class657.field9547 = var1;
               }

               return 100 * (var1 - class657.field9547) / (100 - class657.field9547);
            }

            class543.method2375(class562.field827, 819988020);
            class785.field3827 = new class500(class562.field827, class526.field3666, class419.method5641(-1719059338));
         }

         if (class776.field3728 == class431.field7491) {
            byte[] var10 = class966.field2521.method3264(class590.field1579.field1585, (byte)101);
            if (var10 == null) {
               return 0;
            }

            class153.method3393(var10, -1441857995);
            class184.method3239(-1016382228);
            class967.method1750(7, 907142690);
         }

         if (class431.field7493 == class776.field3728) {
            class606.field8572 = new class839(class856.field8889);
            class677.method4227(class606.field8572, (byte)8);
         }

         if (class431.field7482 == class776.field3728) {
            var1 = class170.method3076(-1857525316);
            if (var1 < 100) {
               return var1;
            }

            class295.method6514(class966.field2521.method3264(class590.field1580.field1585, (byte)90), 745625463);
            class6.field4931 = new class416(class966.field2521);
            class365.field2440 = class6.field4931.field9530;
            class629.field9737 = class6.field4931.field9535;
            if (-1 != class6.field4931.field9536 && -1 != class6.field4931.field9537) {
               class730.field2775 = class6.field4931.field9536;
               class730.field2784 = class6.field4931.field9537;
            }

            class413.field9412 = new class385(class966.field2521);
            class422.field9604 = new class733(class966.field2521);
            class6.field4930 = new class969(class966.field2521);
         }

         if (class431.field7489 == class776.field3728) {
            if (class6.field4931.field9526 != -1 && !class389.field1524.method3260(class6.field4931.field9526, 0, -1803759646)) {
               return 99;
            }

            class962.field3627 = new class849(class428.field7416, class576.field72, class562.field827);
            class452.field7216 = new class851(class730.field2926, class321.field1066, class429.field7413);
            class283.field10614 = new class193(class730.field2926, class321.field1066, class429.field7413, class413.field9412);
            class770.field3733 = new class812(class730.field2926, class321.field1066, class429.field7413, class562.field827);
            class808.field4598 = new class247(class730.field2926, class321.field1066, class310.field532);
            class851.field8731 = new class509(class730.field2926, class321.field1066, class429.field7413);
            class980.field3196 = new class428(class730.field2926, class321.field1066, class429.field7413);
            class339.field157 = new class591(class730.field2926, class321.field1066, class429.field7413, class562.field827);
            class662.field9736 = new class422(class730.field2926, class321.field1066, class429.field7413, class389.field1524);
            class540.field3930 = new class779(class730.field2926, class321.field1066, class429.field7413);
            class229.field8212 = new class754(class730.field2926, class321.field1066, class429.field7413);
            class972.field2965 = new class240(class730.field2926, class321.field1066, true, class170.field5104, class389.field1524);
            class730.field2697.method5287(class972.field2965, -18361497);
            class625.field9752.method458(new class240(class730.field2926, class321.field1066, true, class170.field5104, class389.field1524), 681479919);
            class333.field139 = new class844(class730.field2926, class321.field1066, class429.field7413, class562.field827);
            class981.field3274 = new class945(class730.field2926, class321.field1066, class429.field7413, class562.field827);
            class258.field7913 = new class329(class730.field2926, class321.field1066, true, class49.field5185, class389.field1524);
            class85.field1121 = new class58(class730.field2926, class321.field1066, true, class452.field7216, class452.field7215, class389.field1524);
            class735.field3009 = new class677(class730.field2926, class321.field1066, class429.field7413, true);
            class936.field10313 = new class769(class730.field2926, class321.field1066, class553.field518, class812.field4643, class785.field3825);
            class490.field7866 = new class394(class730.field2926, class321.field1066, class429.field7413);
            class527.field3690 = new class277(class730.field2926, class321.field1066, class429.field7413);
            class635.field9823 = new class382(class730.field2926, class321.field1066, class831.field9108, class389.field1524);
            class58.field2342 = new class339(class730.field2926, class321.field1066, class429.field7413, true);
            class235.field8253 = new class823(class730.field2926, class321.field1066, class429.field7413);
            class671.field7472 = new class942(class730.field2926, class321.field1066, class429.field7413);
            class905.field10369 = new class843(class730.field2926, class321.field1066, class754.field4207);
            class539.field3762 = new class661(class730.field2926, class321.field1066, class429.field7413);
            class619.field8868 = new class368(class730.field2926, class321.field1066, class429.field7413);
            class473.field8291 = new class617(class730.field2926, class321.field1066, class429.field7413);
            class899.field9551 = new class16(class730.field2926, class321.field1066, class429.field7413);
            class669.field7396 = new class337(class730.field2926, class321.field1066, class429.field7413);
            class571.method29(class120.field2292, class389.field1524, class562.field827, class526.field3666, 995134055);
            class23.method3429(class544.field3795, (byte)9);
            class848.field8597 = new class152(class321.field1066, class785.field3826, class335.field53);
            class906.field10363 = new class756(class321.field1066, class785.field3826, class335.field53, new class691());
            class912.method6482(-980237906);
            class827.field9037 = new class646();
            class362.method1508(1884668010);
            class175.method3051(class936.field10313, 638864948);
            class954.method2090(class808.field4597, -1530430191);
            class625.method5826(class389.field1524, class962.field3627, 2043056803);
            class147 var12 = new class147(class27.field6488.method3271("huffman", "", 1988047685));
            class351.method1226(var12, -1778895275);
            class69.field1832 = class881.method6173(-1239681225);
            class86.field1134 = new class734(true);
         }

         if (class431.field7492 == class776.field3728) {
            var1 = class287.method6693(class562.field827, (byte)34) + class785.field3827.method1849(true, -249350940);
            var2 = class529.method2219((short)7611) + class785.field3827.method1852(2124717791);
            if (var1 < var2) {
               return var1 * 100 / var2;
            }
         }

         if (class431.field7494 == class776.field3728) {
            class491.method4397(class792.field510, class851.field8731, class980.field3196, class730.field2697.method5283(-1404290651), class333.field139, class981.field3274, class827.field9037);
         }

         if (class776.field3728 == class431.field7506) {
            class14.field6693 = new int[class671.field7472.field10346];
            class474.field8271 = new boolean[class671.field7472.field10346];
            class978.field3129 = new String[class235.field8253.field9043];

            for(var1 = 0; var1 < class671.field7472.field10346; ++var1) {
               if (class671.field7472.method6332(var1, (byte)-12).field9809 == 0) {
                  class474.field8271[var1] = true;
                  ++class730.field2872;
               }

               class14.field6693[var1] = -1;
            }

            class307.method383(915865311);
            class948.field3291.method3268(false, true, -176172929);
            class771.field3732.method3268(true, true, -158717020);
            class562.field827.method3268(true, true, -1968339968);
            class526.field3666.method3268(true, true, -1788343139);
            class27.field6488.method3268(true, true, -629544722);
            class730.field2653 = true;
         }

         if (class431.field7496 == class776.field3728) {
            if (!class215.method3835(class6.field4931.field9533, (int[])null, -2054647884)) {
               return 0;
            }

            var9 = true;

            for(var2 = 0; var2 < class382.field1410[class6.field4931.field9533].field1103.length; ++var2) {
               class564 var11 = class382.field1410[class6.field4931.field9533].field1103[var2];
               if (var11.field869 == 5 && -1 != var11.field900 && !class562.field827.method3260(var11.field900, 0, -1154476799)) {
                  var9 = false;
               }
            }

            if (!var9) {
               return 0;
            }
         }

         if (class431.field7497 == class776.field3728) {
            class936.method6276(true, -1028404543);
         }

         if (class431.field7498 == class776.field3728) {
            class302.field3768.method122((byte)25);

            try {
               class12.field6680.join();
            } catch (InterruptedException var7) {
               return 0;
            }

            class302.field3768 = null;
            class12.field6680 = null;
            class27.field6487 = null;
            class657.field9546 = null;
            class965.field2534 = null;
            class657.field9544 = null;
            class329.method19(1677071566);
            class730.field2627 = class615.field8903.field9145.method2311((byte)-47) == 1;
            class615.field8903.method5391(class615.field8903.field9145, 1, 807460534);
            if (class730.field2627) {
               class615.field8903.method5391(class615.field8903.field9136, 0, -91524334);
            } else if (class615.field8903.field9136.field6934 && class86.field1134.field3064 < 512 && class86.field1134.field3064 != 0) {
               class615.field8903.method5391(class615.field8903.field9136, 0, -1214226075);
            }

            class95.method523(656179282);
            if (class730.field2627) {
               class337.method77(0, false, 622850291);
            } else {
               class337.method77(class615.field8903.field9136.method3689(-1847672596), false, 622850291);
            }

            class739.method1795(class615.field8903.field9109.method6159((byte)12), -1, -1, false, -107949513);
            class785.field3827.method1856(class730.field2681, (byte)3);
            class867.method5833(class593.field1623, -1188868944);
            class158.method3443(class593.field1623, class562.field827, 498152714);
            class924.method6252(class324.field621, -1481526948);
         }

         return class458.method3828(205846067);
      } catch (RuntimeException var8) {
         throw class158.method3445(var8, "fb.d(" + ')');
      }
   }

   static final int method3173(int var0, int var1) {
      try {
         int var2 = var0 & 63;
         int var3 = var0 >> 6 & 3;
         if (var2 == 18) {
            if (var3 == 0) {
               return 1;
            }

            if (1 == var3) {
               return 2;
            }

            if (2 == var3) {
               return 4;
            }

            if (3 == var3) {
               return 8;
            }
         } else if (var2 == 19 || 21 == var2) {
            if (var3 == 0) {
               return 16;
            }

            if (1 == var3) {
               return 32;
            }

            if (var3 == 2) {
               return 64;
            }

            if (3 == var3) {
               return 128;
            }
         }

         return 0;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "fb.ib(" + ')');
      }
   }
}
