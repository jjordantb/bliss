public class class75 {
   static boolean field1493 = false;
   static int field1494;
   static int field1495;
   static int field1496;

   class75() throws Throwable {
      throw new Error();
   }

   public static void method1117(class180 var0, int var1, int var2, int var3, boolean var4, class272 var5, int var6) {
      try {
         class58.method1581(var0, var1, var2, var3, var4, -2042287938);
         class818.field4625 = var5;
      } catch (RuntimeException var8) {
         throw class158.method3445(var8, "av.b(" + ')');
      }
   }

   static final void method1118(class564 var0, class131 var1, boolean var2, int var3, class744 var4, int var5) {
      try {
         var4.field3156 -= -783761378;
         int var6 = var4.field3161[681479919 * var4.field3156];
         int var7 = var4.field3161[681479919 * var4.field3156 + 1];
         if (-1 == var0.field879 * -1309843523 && !var1.field1101) {
            class284.method6687(-440872681 * var0.field867, 1388671560);
            class466.method4009(-440872681 * var0.field867, 106150101);
            class917.method6455(var0.field867 * -440872681, 2057190103);
         }

         if (-1 == var6) {
            var0.field909 = -1530138943;
            var0.field876 = 1825442367;
            var0.field1005 = -643064669;
         } else {
            var0.field1005 = var6 * 643064669;
            var0.field1006 = -160790887 * var7;
            var0.field938 = var2;
            class518 var8 = class85.field1121.method1566(var6);
            var0.field915 = var8.field4231 * 1147619461;
            var0.field987 = -953332053 * var8.field4232;
            var0.field917 = 1018171305 * var8.field4233;
            var0.field1022 = var8.field4234 * 216639237;
            var0.field973 = var8.field4235 * 2135145581;
            var0.field1009 = var8.field4230 * -1056736627;
            var0.field926 = var3 * -625792095;
            if (-692202853 * var0.field946 > 0) {
               var0.field1009 = var0.field1009 * 237251296 / (var0.field946 * -692202853) * -1066050969;
            } else if (1769572195 * var0.field978 > 0) {
               var0.field1009 = 237251296 * var0.field1009 / (var0.field978 * 1769572195) * -1066050969;
            }
         }

      } catch (RuntimeException var9) {
         throw class158.method3445(var9, "av.hh(" + ')');
      }
   }

   static final void method1119(class744 var0, int var1) {
      try {
         int var2 = var0.field3161[(var0.field3156 -= -391880689) * 681479919];
         class564 var3 = class449.method3756(var2, (byte)-54);
         class131 var4 = class382.field1410[var2 >> 16];
         class394.method3410(var3, var4, var0, -1611318497);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "av.iu(" + ')');
      }
   }

   static final void method1120(class744 var0, int var1) {
      try {
         var0.field3156 -= -783761378;
         int var2 = var0.field3161[var0.field3156 * 681479919];
         int var3 = var0.field3161[1 + 681479919 * var0.field3156];
         var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = class848.field8597.method3399(var2, -1634888229).field7618[var3];
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "av.acy(" + ')');
      }
   }

   static final void method1121(class744 var0, int var1) {
      try {
         if (class182.field5317 * -1111444967 == 2) {
            class182.field5314 = true;
         } else if (-1111444967 * class182.field5317 == 1) {
            class182.field5315 = true;
         } else if (class182.field5317 * -1111444967 == 3) {
            class182.field5316 = true;
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "av.anf(" + ')');
      }
   }

   static void method1122(int var0) {
      try {
         class95.field595 = 0;
         class95.field596 = 955770805;
         class95.field601 = 1129029761;
         class95.field593 = 1835291189;
      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "av.a(" + ')');
      }
   }
}
