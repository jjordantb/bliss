public class class370 {
   int field1092;
   int field1093;
   boolean field1094;
   int field1095;
   boolean field1096;
   static int field1097;

   static final void method876(class744 var0, byte var1) {
      try {
         class980.method1917(-283526771);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "r.agk(" + ')');
      }
   }

   static final void method877(class564 var0, class131 var1, class744 var2, byte var3) {
      try {
         var0.field895 = var2.field3161[--var2.field3156];
         class814.method2932(var0, 230725327);
         if (var0.field879 == -1 && !var1.field1101) {
            class392.method3382(var0.field867, (byte)-11);
         }

      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "r.dg(" + ')');
      }
   }

   static final void method878(class744 var0, short var1) {
      try {
         if (class184.field5231 == null) {
            var0.field3161[++var0.field3156 - 1] = -1;
         } else {
            var0.field3161[++var0.field3156 - 1] = class184.field5231.field6679;
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "r.abm(" + ')');
      }
   }

   static final void method879(class744 var0, int var1) {
      try {
         int var2 = var0.field3161[--var0.field3156];
         class323.method541(var2, -1700743284);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "r.aew(" + ')');
      }
   }

   static final void method880(class564 var0, class131 var1, class744 var2, byte var3) {
      try {
         String var4 = (String)var2.field3157[--var2.field3158];
         if (class960.method2212(var4, var2, -1037591394) != null) {
            var4 = var4.substring(0, var4.length() - 1);
         }

         var0.field972 = class634.method5872(var4, var2, -2046058202);
         var0.field963 = true;
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "r.oj(" + ')');
      }
   }

   static class682 method881(int var0, long var1) {
      try {
         class682 var3 = (class682)class682.field7698.method2942((long)var0 << 56 | var1);
         if (var3 == null) {
            var3 = new class682(var0, var1);
            class682.field7698.method2947(var3, var3.field641);
         }

         return var3;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "r.a(" + ')');
      }
   }
}
