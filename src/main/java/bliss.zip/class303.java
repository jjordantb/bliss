public class class303 {
   class920 field3844;
   boolean field3845;
   class920 field3846;
   boolean field3847;

   class303(boolean var1) {
      this.field3845 = var1;
   }

   boolean method2399() {
      return this.field3847 && !this.field3845;
   }

   void method2400() {
      if (this.field3846 != null) {
         this.field3846.method2755();
      }

      this.field3847 = false;
   }
}
