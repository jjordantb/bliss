public class class787 extends class347 {
   int field3911;
   static int field3912 = 4096;

   public class787() {
      this(4096);
   }

   class787(int var1) {
      super(0, true);
      this.field3911 = -1723691008;
      this.field3911 = 1128895529 * var1;
   }

   int[] method203(int var1, int var2) {
      try {
         int[] var3 = this.field270.method3546(var1, 1924979282);
         if (this.field270.field6612) {
            class901.method6354(var3, 0, -1474554145 * class322.field831, this.field3911 * -945993703);
         }

         return var3;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "ahp.i(" + ')');
      }
   }

   int[] method2458(int var1) {
      int[] var2 = this.field270.method3546(var1, 124151848);
      if (this.field270.field6612) {
         class901.method6354(var2, 0, -1474554145 * class322.field831, this.field3911 * -945993703);
      }

      return var2;
   }

   int[] method2459(int var1) {
      int[] var2 = this.field270.method3546(var1, 1124955877);
      if (this.field270.field6612) {
         class901.method6354(var2, 0, -1474554145 * class322.field831, this.field3911 * -945993703);
      }

      return var2;
   }

   void method2460(int var1, class907 var2) {
      switch(var1) {
      case 0:
         this.field3911 = (var2.method6371() << 12) / 255 * 1128895529;
      default:
      }
   }

   void method2461(int var1, class907 var2) {
      switch(var1) {
      case 0:
         this.field3911 = (var2.method6371() << 12) / 255 * 1128895529;
      default:
      }
   }

   void method209(int var1, class907 var2, byte var3) {
      try {
         switch(var1) {
         case 0:
            this.field3911 = (var2.method6371() << 12) / 255 * 1128895529;
         default:
         }
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "ahp.r(" + ')');
      }
   }
}
