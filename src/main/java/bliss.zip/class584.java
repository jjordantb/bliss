public class class584 {
   public static class584 field295 = new class584(1);
   public int field296;
   public static class584 field297 = new class584(4);
   public static class584 field298 = new class584(2);
   public static class584 field299 = new class584(0);
   public static class584 field300 = new class584(3);

   class584(int var1) {
      this.field296 = var1;
   }
}
