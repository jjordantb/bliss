public class class351 extends class312 {
   public boolean method416(int var1, int var2, int var3, class262 var4) {
      return -1331662251 * this.field476 == var2 && var3 == 1517720743 * this.field475;
   }

   public boolean method414(int var1, int var2, int var3, class262 var4) {
      return -1331662251 * this.field476 == var2 && var3 == 1517720743 * this.field475;
   }

   public boolean method415(int var1, int var2, int var3, class262 var4, int var5) {
      try {
         return -1331662251 * this.field476 == var2 && var3 == 1517720743 * this.field475;
      } catch (RuntimeException var7) {
         throw class158.method3445(var7, "acy.a(" + ')');
      }
   }

   static final void method1225(class744 var0, byte var1) {
      try {
         String var2 = (String)var0.field3157[(var0.field3158 -= 969361751) * -203050393];
         class86.method949(var2, true, (short)5563);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "acy.ww(" + ')');
      }
   }

   public static void method1226(class147 var0, int var1) {
      try {
         class530.field3740 = var0;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "acy.a(" + ')');
      }
   }

   public static class15[] method1227(int var0) {
      try {
         return new class15[]{class15.field6922, class15.field6905, class15.field6911, class15.field6909, class15.field6901, class15.field6906, class15.field6902, class15.field6912, class15.field6899, class15.field6920, class15.field6917, class15.field6914, class15.field6913, class15.field6915, class15.field6916, class15.field6918, class15.field6903, class15.field6908, class15.field6904, class15.field6900, class15.field6907, class15.field6919, class15.field6910};
      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "acy.a(" + ')');
      }
   }
}
