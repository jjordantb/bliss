public class class530 {
   static class147 field3740;
   public static int field3741;

   class530() throws Throwable {
      throw new Error();
   }

   public static final void method2314(int var0) {
      try {
         if (!class730.field2742) {
            class730.field2741 += (12.0F - class730.field2741) / 2.0F;
            class730.field2744 = true;
            class730.field2742 = true;
         }

      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "ei.hf(" + ')');
      }
   }
}
