public class class599 {
   public class568 field1710 = new class568();
   class568 field1711;

   public class568 method1278(int var1) {
      try {
         class568 var2 = this.field1710.field642;
         if (var2 == this.field1710) {
            this.field1711 = null;
            return null;
         } else {
            this.field1711 = var2.field642;
            return var2;
         }
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "sw.d(" + ')');
      }
   }

   public void method1279(class568 var1, int var2) {
      try {
         if (var1.field642 != null) {
            var1.method545(-1460969981);
         }

         var1.field642 = this.field1710;
         var1.field640 = this.field1710.field640;
         var1.field642.field640 = var1;
         var1.field640.field642 = var1;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "sw.b(" + ')');
      }
   }

   public class568 method1280(byte var1) {
      try {
         class568 var2 = this.field1711;
         if (this.field1710 == var2) {
            this.field1711 = null;
            return null;
         } else {
            this.field1711 = var2.field642;
            return var2;
         }
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "sw.x(" + ')');
      }
   }

   public class568 method1281(int var1) {
      try {
         class568 var2 = this.field1710.field640;
         if (var2 == this.field1710) {
            this.field1711 = null;
            return null;
         } else {
            this.field1711 = var2.field640;
            return var2;
         }
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "sw.k(" + ')');
      }
   }

   public void method1282(class568 var1, int var2) {
      try {
         if (var1.field642 != null) {
            var1.method545(-1460969981);
         }

         var1.field642 = this.field1710.field642;
         var1.field640 = this.field1710;
         var1.field642.field640 = var1;
         var1.field640.field642 = var1;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "sw.f(" + ')');
      }
   }

   public class568 method1283(byte var1) {
      try {
         class568 var2 = this.field1711;
         if (var2 == this.field1710) {
            this.field1711 = null;
            return null;
         } else {
            this.field1711 = var2.field640;
            return var2;
         }
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "sw.u(" + ')');
      }
   }

   public boolean method1284(byte var1) {
      try {
         return this.field1710.field640 == this.field1710;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "sw.r(" + ')');
      }
   }

   public class568 method1285(int var1) {
      try {
         class568 var2 = this.field1710.field640;
         if (this.field1710 == var2) {
            return null;
         } else {
            var2.method545(-1460969981);
            return var2;
         }
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "sw.i(" + ')');
      }
   }

   public void method1286(int var1) {
      try {
         while(true) {
            class568 var2 = this.field1710.field640;
            if (this.field1710 == var2) {
               if (var1 < -824427525) {
                  this.field1711 = null;
                  return;
               }

               return;
            }

            var2.method545(-1460969981);
         }
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "sw.a(" + ')');
      }
   }

   public class599() {
      this.field1710.field640 = this.field1710;
      this.field1710.field642 = this.field1710;
   }

   public static void method1287(class345 var0, class345 var1, int var2) {
      try {
         if (var0.field207 != null) {
            var0.method156(-881477192);
         }

         var0.field207 = var1;
         var0.field208 = var1.field208;
         var0.field207.field208 = var0;
         var0.field208.field207 = var0;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "sw.p(" + ')');
      }
   }

   static final void method1288(class744 var0, byte var1) {
      try {
         if (class509.field4024 != null) {
            var0.field3161[++var0.field3156 - 1] = 1;
            var0.field3154 = class509.field4024;
         } else {
            var0.field3161[++var0.field3156 - 1] = 0;
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "sw.xx(" + ')');
      }
   }

   static final void method1289(class744 var0, byte var1) {
      try {
         boolean var2 = true;
         if (class730.field2616) {
            try {
               Object var3 = class662.field9732.method5801(-1654113322);
               if (var3 != null) {
                  var2 = ((Boolean)var3).booleanValue();
               }
            } catch (Throwable var4) {
               ;
            }
         }

         var0.field3161[++var0.field3156 - 1] = var2 ? 1 : 0;
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "sw.ank(" + ')');
      }
   }

   static final void method1290(class744 var0, byte var1) {
      try {
         String var2 = (String)var0.field3157[--var0.field3158];
         class701 var3 = class637.method5936(class643.field9978, class730.field2692.field7765, (byte)19);
         var3.field3364.method6361(var2.length() + 1);
         var3.field3364.method6366(var2, 2140741369);
         class730.field2692.method4380(var3, (byte)-70);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "sw.sf(" + ')');
      }
   }
}
