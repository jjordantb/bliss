public class class781 {
   int field3931;
   int field3932;
   int field3933;
}
