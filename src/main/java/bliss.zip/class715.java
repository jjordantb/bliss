public class class715 extends class732 implements class265 {
   boolean field3582 = true;
   boolean field3583;
   class719 field3584;
   public class309 field3585;

   public void method4553() {
   }

   boolean method2183(short var1) {
      try {
         return this.field3582;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wl.be(" + ')');
      }
   }

   public class719 method2165(class848 var1, byte var2) {
      try {
         return this.field3584;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "wl.bc(" + ')');
      }
   }

   public int method2168(int var1) {
      try {
         return this.field3585.method356(128726833);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wl.bm(" + ')');
      }
   }

   public int method2170(byte var1) {
      try {
         return this.field3585.method350(2145016917);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wl.bx(" + ')');
      }
   }

   public void method2093(class552 var1, byte var2) {
      try {
         this.field3585.method349(var1, -1138005946);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "wl.by(" + ')');
      }
   }

   boolean method2158() {
      return this.field3582;
   }

   void method2164(class848 var1, int var2) {
      try {
         class879 var3 = this.field3585.method351(var1, 262144, false, true, (byte)75);
         if (var3 != null) {
            class135 var4 = this.method1521();
            class446 var5 = this.method1511();
            int var6 = (int)var5.field7637.field5296 >> 9;
            int var7 = (int)var5.field7637.field5299 >> 9;
            this.field3585.method352(var1, var3, var4, var6, var6, var7, var7, false, 1852542070);
         }

      } catch (RuntimeException var8) {
         throw class158.method3445(var8, "wl.bb(" + ')');
      }
   }

   boolean method2157(class848 var1, int var2, int var3, byte var4) {
      try {
         class879 var5 = this.field3585.method351(var1, 131072, false, false, (byte)63);
         return var5 == null ? false : var5.method6097(var2, var3, this.method1521(), false, 0);
      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "wl.bu(" + ')');
      }
   }

   public int method4551(byte var1) {
      try {
         return 1686561661 * this.field3585.field387;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wl.a(" + ')');
      }
   }

   public int method4548(int var1) {
      try {
         return this.field3585.field375 * -1598457753;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wl.f(" + ')');
      }
   }

   public int method4549(short var1) {
      try {
         return 748228569 * this.field3585.field376;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wl.b(" + ')');
      }
   }

   public void method4550(byte var1) {
   }

   public boolean method4558(int var1) {
      try {
         return this.field3585.method357(-1796811837);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "wl.i(" + ')');
      }
   }

   boolean method2172() {
      return false;
   }

   public void method4556(class848 var1, int var2) {
      try {
         this.field3585.method358(var1, -475225909);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "wl.d(" + ')');
      }
   }

   public void method4552(class848 var1, int var2) {
      try {
         this.field3585.method353(var1, 174352681);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "wl.k(" + ')');
      }
   }

   public int method4555() {
      return this.field3585.field375 * -1598457753;
   }

   boolean method2190() {
      return this.field3582;
   }

   public int method4561() {
      return 748228569 * this.field3585.field376;
   }

   public int method4557() {
      return 748228569 * this.field3585.field376;
   }

   boolean method2156() {
      return this.field3582;
   }

   boolean method2206(byte var1) {
      return false;
   }

   class192 method2177(class848 var1) {
      class879 var2 = this.field3585.method351(var1, 2048, false, true, (byte)-76);
      if (var2 == null) {
         return null;
      } else {
         class135 var3 = var1.method5048();
         var3.method1024(this.method1521());
         var3.method1018((float)this.field2978, 0.0F, (float)this.field2979);
         class446 var4 = this.method1511();
         class192 var5 = class221.method4033(this.field3583, 1290253643);
         int var6 = (int)var4.field7637.field5296 >> 9;
         int var7 = (int)var4.field7637.field5299 >> 9;
         this.field3585.method352(var1, var2, var3, var6, var6, var7, var7, true, 1549011469);
         var2.method5965(var3, this.field3642[0], 0);
         if (this.field3585.field388 != null) {
            class874 var8 = this.field3585.field388.method1729();
            var1.method4866(var8);
         }

         this.field3582 = var2.method5989() || this.field3585.field388 != null;
         if (this.field3584 == null) {
            this.field3584 = class905.method6344((int)var4.field7637.field5296, (int)var4.field7637.field5300, (int)var4.field7637.field5299, var2, 1999311873);
         } else {
            class364.method1613(this.field3584, (int)var4.field7637.field5296, (int)var4.field7637.field5300, (int)var4.field7637.field5299, var2, (byte)74);
         }

         return var5;
      }
   }

   public void method4562(class848 var1) {
      this.field3585.method358(var1, -475225909);
   }

   public void method4563(class848 var1) {
      this.field3585.method358(var1, -475225909);
   }

   public void method4559(class848 var1) {
      this.field3585.method358(var1, -475225909);
   }

   boolean method2160() {
      return false;
   }

   boolean method2176() {
      return this.field3582;
   }

   boolean method2181() {
      return false;
   }

   void method2178(class848 var1) {
      class879 var2 = this.field3585.method351(var1, 262144, false, true, (byte)34);
      if (var2 != null) {
         class135 var3 = this.method1521();
         class446 var4 = this.method1511();
         int var5 = (int)var4.field7637.field5296 >> 9;
         int var6 = (int)var4.field7637.field5299 >> 9;
         this.field3585.method352(var1, var2, var3, var5, var5, var6, var6, false, 22822212);
      }

   }

   public int method4554() {
      return this.field3585.field375 * -1598457753;
   }

   public int method2094() {
      return this.field3585.method350(2068020131);
   }

   public int method2095() {
      return this.field3585.method350(2094377016);
   }

   void method2180(class848 var1) {
      class879 var2 = this.field3585.method351(var1, 262144, false, true, (byte)16);
      if (var2 != null) {
         class135 var3 = this.method1521();
         class446 var4 = this.method1511();
         int var5 = (int)var4.field7637.field5296 >> 9;
         int var6 = (int)var4.field7637.field5299 >> 9;
         this.field3585.method352(var1, var2, var3, var5, var5, var6, var6, false, 386620711);
      }

   }

   class192 method2201(class848 var1, int var2) {
      try {
         class879 var3 = this.field3585.method351(var1, 2048, false, true, (byte)-55);
         if (var3 == null) {
            return null;
         } else {
            class135 var4 = var1.method5048();
            var4.method1024(this.method1521());
            var4.method1018((float)this.field2978, 0.0F, (float)this.field2979);
            class446 var5 = this.method1511();
            class192 var6 = class221.method4033(this.field3583, 1881845078);
            int var7 = (int)var5.field7637.field5296 >> 9;
            int var8 = (int)var5.field7637.field5299 >> 9;
            this.field3585.method352(var1, var3, var4, var7, var7, var8, var8, true, -43742513);
            var3.method5965(var4, this.field3642[0], 0);
            if (this.field3585.field388 != null) {
               class874 var9 = this.field3585.field388.method1729();
               var1.method4866(var9);
            }

            this.field3582 = var3.method5989() || this.field3585.field388 != null;
            if (this.field3584 == null) {
               this.field3584 = class905.method6344((int)var5.field7637.field5296, (int)var5.field7637.field5300, (int)var5.field7637.field5299, var3, 2072413227);
            } else {
               class364.method1613(this.field3584, (int)var5.field7637.field5296, (int)var5.field7637.field5300, (int)var5.field7637.field5299, var3, (byte)84);
            }

            return var6;
         }
      } catch (RuntimeException var10) {
         throw class158.method3445(var10, "wl.bo(" + ')');
      }
   }

   public class719 method2175(class848 var1) {
      return this.field3584;
   }

   boolean method2179(class848 var1, int var2, int var3) {
      class879 var4 = this.field3585.method351(var1, 131072, false, false, (byte)4);
      return var4 == null ? false : var4.method6097(var2, var3, this.method1521(), false, 0);
   }

   public void method4547(class848 var1) {
      this.field3585.method353(var1, 2051751369);
   }

   boolean method2159(class848 var1, int var2, int var3) {
      class879 var4 = this.field3585.method351(var1, 131072, false, false, (byte)-39);
      return var4 == null ? false : var4.method6097(var2, var3, this.method1521(), false, 0);
   }

   public int method2186() {
      return this.field3585.method356(1794626017);
   }

   public int method2187() {
      return this.field3585.method356(-1950259661);
   }

   public int method2188() {
      return this.field3585.method356(-398878374);
   }

   public class715(class545 var1, class848 var2, class240 var3, class50 var4, int var5, int var6, int var7, int var8, int var9, boolean var10, int var11, int var12, int var13, int var14, int var15) {
      super(var1, var7, var8, var9, var5, var6, var11, var12);
      this.field3585 = new class309(var2, var3, var4, var13, var14, this.field3639, var6, this, var10, var15);
      this.field3583 = 1532834983 * var4.field2214 != 0 && !var10;
      this.method2169(1, -659392218);
   }

   boolean method2189() {
      return this.field3582;
   }

   public int method4564() {
      return 1686561661 * this.field3585.field387;
   }

   public boolean method4560() {
      return this.field3585.method357(1916662090);
   }

   boolean method2192(class848 var1, int var2, int var3) {
      class879 var4 = this.field3585.method351(var1, 131072, false, false, (byte)-72);
      return var4 == null ? false : var4.method6097(var2, var3, this.method1521(), false, 0);
   }

   public class719 method2174(class848 var1) {
      return this.field3584;
   }

   public static void method2096(long[] var0, Object[] var1, byte var2) {
      try {
         class912.method6481(var0, var1, 0, var0.length - 1, 1394023611);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "wl.r(" + ')');
      }
   }

   public static String[] method2097(String var0, char var1, int var2) {
      try {
         int var3 = class843.method5462(var0, var1, -452041917);
         String[] var4 = new String[1 + var3];
         int var5 = 0;
         int var6 = 0;

         for(int var7 = 0; var7 < var3; ++var7) {
            int var8;
            for(var8 = var6; var0.charAt(var8) != var1; ++var8) {
               ;
            }

            var4[var5++] = var0.substring(var6, var8);
            var6 = 1 + var8;
         }

         var4[var3] = var0.substring(var6);
         return var4;
      } catch (RuntimeException var9) {
         throw class158.method3445(var9, "wl.h(" + ')');
      }
   }

   static final void method2098(class564 var0, class131 var1, class744 var2, byte var3) {
      try {
         var0.method832(333321190);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "wl.kx(" + ')');
      }
   }
}
