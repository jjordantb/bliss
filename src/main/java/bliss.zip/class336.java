public class class336 extends class934 {
   class336(String var1) {
      super(var1);
   }
}
