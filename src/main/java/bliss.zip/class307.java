import java.io.IOException;

public class class307 {
   public static class307 field420 = new class307(9);
   public static class307 field421 = new class307(7);
   public static class307 field422 = new class307(3);
   public static class307 field423 = new class307(2);
   public static class307 field424 = new class307(19);
   public static class307 field425 = new class307(6);
   public static class307 field426 = new class307(5);
   static class48[] field427;
   public static class307 field428 = new class307(6);
   public static class307 field429 = new class307(5);
   public static class307 field430 = new class307(-1);
   public static class307 field431 = new class307(8);
   public static class307 field432 = new class307(-1);
   public static class307 field433 = new class307(16);
   public static class307 field434 = new class307(8);
   public static class307 field435 = new class307(7);

   class307(int var1) {
   }

   static void method383(int var0) {
      try {
         class439 var1 = null;

         try {
            var1 = class22.method3434("2", class730.field2926.field7321, false, -1804643872);
            byte[] var2 = new byte[(int)var1.method4277(-1608358371)];

            int var4;
            for(int var3 = 0; var3 < var2.length; var3 += var4) {
               var4 = var1.method4278(var2, var3, var2.length - var3, (short)1638);
               if (var4 == -1) {
                  throw new IOException();
               }
            }

            class299.method6552(new class907(var2), (byte)3);
         } catch (Exception var6) {
            ;
         }

         try {
            if (var1 != null) {
               var1.method4276(1765313968);
            }
         } catch (Exception var5) {
            ;
         }

      } catch (RuntimeException var7) {
         throw class158.method3445(var7, "ir.r(" + ')');
      }
   }

   static class98[] method384(int var0) {
      try {
         return new class98[]{class98.field608, class98.field609, class98.field611};
      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "ir.a(" + ')');
      }
   }

   static final void method385(byte var0) {
      try {
         class0.method2992(class593.field1623, 556951212);
         if (class899.field9552 != class730.field2773) {
            class247.method4722((short)-2730);
         }

      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "ir.ga(" + ')');
      }
   }

   static class930 method386(class907 var0, int var1) {
      try {
         return new class930(var0.method6367(1929673502), var0.method6367(1591525604), var0.method6367(1980414267), var0.method6367(1697989112), var0.method6367(1558777727), var0.method6367(1996690559), var0.method6367(1912436552), var0.method6367(1880856141), var0.method6390((byte)-28), var0.method6371());
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "ir.r(" + ')');
      }
   }

   static final void method387(int var0) {
      try {
         if (!class669.method4121(class730.field2733, 1765230881) && !class162.method3544(class730.field2733, 1927636725)) {
            class467.field7301 = class730.field2692.method4377(537308016);
            class730.field2692.method4375(865497912);
            class967.method1750(5, 2010723010);
         } else {
            class82.method920(false, (byte)23);
         }

      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "ir.gk(" + ')');
      }
   }

   static void method388(int var0, int var1, int var2, int var3, int var4) {
      try {
         class682 var5 = class370.method881(4, (long)var0);
         var5.method4340((byte)123);
         var5.field7687 = var1;
         var5.field7685 = var2;
         var5.field7686 = var3;
      } catch (RuntimeException var6) {
         throw class158.method3445(var6, "ir.al(" + ')');
      }
   }

   static void method389(class112 var0, int var1, int var2, class744 var3, int var4) {
      try {
         class346 var5 = class22.method3435(var0, var1, var2, -1499442878);
         if (var5 == null) {
            class449.method3758((byte)83);
         } else {
            var3.field3165 = new int[var5.field177];
            var3.field3151 = new Object[var5.field178];
            if (var5.field176 != class112.field2122 && class112.field2116 != var5.field176 && class112.field2113 != var5.field176) {
               if (var5.field176 == class112.field2111) {
                  var3.field3165[0] = var3.field3172;
               }
            } else {
               int var6 = 0;
               int var7 = 0;
               if (class147.field1520 != null) {
                  var6 = class147.field1520.field868;
                  var7 = class147.field1520.field880;
               }

               var3.field3165[0] = class912.field10424.method5524((byte)-93) - var6;
               var3.field3165[1] = class912.field10424.method5513((byte)-71) - var7;
            }

            class978.method1842(var5, 200000, var3, -598583477);
         }

      } catch (RuntimeException var8) {
         throw class158.method3445(var8, "ir.q(" + ')');
      }
   }

   public static boolean method390(int var0) {
      try {
         return class889.field9235 != null;
      } catch (RuntimeException var2) {
         throw class158.method3445(var2, "ir.b(" + ')');
      }
   }
}
