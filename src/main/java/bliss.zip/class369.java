public class class369 {
   short[] field2367;
   short[] field2368;
   short[] field2369;
   byte[] field2370;
}
