public class class51 {
   static class51 field2307 = new class51();
   static class51 field2308 = new class51();
   public static class48 field2309;
   static String field2310;

   static final void method1525(class744 var0, int var1) {
      try {
         class237 var2 = var0.field3178 ? var0.field3164 : var0.field3163;
         class564 var3 = var2.field8255;
         class131 var4 = var2.field8254;
         class122.method1603(var3, var4, var0, -443341169);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "u.kn(" + ')');
      }
   }

   static final void method1526(class744 var0, int var1) {
      try {
         class237 var2 = var0.field3178 ? var0.field3164 : var0.field3163;
         class564 var3 = var2.field8255;
         class131 var4 = var2.field8254;
         class472.method4612(var3, var4, var0, 760062987);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "u.of(" + ')');
      }
   }

   static final void method1527(class744 var0, byte var1) {
      try {
         var0.field3156 -= -783761378;
         int var2 = var0.field3161[681479919 * var0.field3156];
         int var3 = var0.field3161[1 + 681479919 * var0.field3156];
         var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = class1.method2987(var2, var3, false, (byte)12);
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "u.tf(" + ')');
      }
   }

   static final void method1528(class744 var0, byte var1) {
      try {
         int var2 = var0.field3161[(var0.field3156 -= -391880689) * 681479919];
         var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = -804725095 * class730.field2902[var2].field10626;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "u.yh(" + ')');
      }
   }

   static final void method1529(class744 var0, int var1) {
      try {
         var0.field3162 -= -1365138610;
         if (var0.field3168[1685767703 * var0.field3162] != var0.field3168[1 + 1685767703 * var0.field3162]) {
            var0.field3176 += 286750741 * var0.field3174[1883543357 * var0.field3176];
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "u.bc(" + ')');
      }
   }

   public static boolean method1530(int var0, int var1) {
      try {
         return (var0 & -var0) == var0;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "u.k(" + ')');
      }
   }

   static void method1531(class513 var0, int var1) {
      try {
         var0.method6364(class812.field4643.method3255((byte)-114), 233063428);
         var0.method6364(class785.field3825.method3255((byte)-94), 986185599);
         var0.method6364(class429.field7413.method3255((byte)-91), -1745645842);
         var0.method6364(class120.field2292.method3255((byte)-7), -307867882);
         var0.method6364(class783.field3963.method3255((byte)-80), 356103076);
         var0.method6364(class948.field3291.method3255((byte)-111), 513722898);
         var0.method6364(class771.field3732.method3255((byte)-98), -1521253411);
         var0.method6364(class389.field1524.method3255((byte)-35), -1182009494);
         var0.method6364(class562.field827.method3255((byte)-118), -696517500);
         var0.method6364(class576.field72.method3255((byte)-66), -1298892299);
         var0.method6364(class27.field6488.method3255((byte)-94), -1396215756);
         var0.method6364(class972.field2964.method3255((byte)-45), 488399757);
         var0.method6364(class969.field2496.method3255((byte)-108), -976169863);
         var0.method6364(class526.field3666.method3255((byte)-108), 730525491);
         var0.method6364(class967.field2604.method3255((byte)-93), -1013524898);
         var0.method6364(class151.field5372.method3255((byte)-82), -571760236);
         var0.method6364(class170.field5104.method3255((byte)-55), -837295865);
         var0.method6364(class310.field532.method3255((byte)-21), -659161731);
         var0.method6364(class49.field5185.method3255((byte)-73), -243825784);
         var0.method6364(class452.field7215.method3255((byte)-79), -25753487);
         var0.method6364(class553.field518.method3255((byte)-124), -932739856);
         var0.method6364(class831.field9108.method3255((byte)-89), -1017358155);
         var0.method6364(class754.field4207.method3255((byte)-90), 675053726);
         var0.method6364(class792.field510.method3255((byte)-120), -1221329799);
         var0.method6364(class785.field3826.method3255((byte)-98), 539481972);
         var0.method6364(class335.field53.method3255((byte)-40), -783884733);
         var0.method6364(class428.field7416.method3255((byte)-10), 720169439);
         var0.method6364(class808.field4597.method3255((byte)-114), -431907021);
         var0.method6364(class966.field2521.method3255((byte)-12), -1063670881);
         var0.method6364(class544.field3795.method3255((byte)-37), -1033593325);
         var0.method6364(class856.field8889.method3255((byte)-37), -104776264);
         var0.method6364(class776.field3729.method3255((byte)-79), -1698627282);
         var0.method6364(class602.method5090(1705514000), -2046011963);
         var0.method6364(class934.method6313((byte)53), 343602270);
         var0.method6364(class966.field2522.method3255((byte)-68), -1492700633);
         var0.method6364(class16.field6892.method3255((byte)-65), -882969575);
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "u.l(" + ')');
      }
   }

   static final void method1532(class564 var0, byte var1) {
      try {
         if (class564.field846 * -918321179 == var0.field870 * 907611645) {
            if (class923.field10295.field3374 == null) {
               var0.field876 = 0;
               var0.field865 = 0;
            } else {
               var0.field915 = 818038;
               var0.field987 = ((int)(Math.sin((double)(443738891 * class730.field2866) / 40.0D) * 256.0D) & 2047) * 1590511671;
               var0.field909 = 939239877;
               var0.field876 = class730.field2623 * -127794683;
               var0.field865 = class904.method6336(class923.field10295.field3374, (byte)123) * 908204397;
               class765 var2 = class923.field10295.field4041;
               if (var2 != null) {
                  if (var0.field877 == null) {
                     var0.field877 = new class522();
                  }

                  var0.field1015 = var2.method2779(1818062906) * 1587382585;
                  var0.field877.method2796(var2, -947942211);
               } else {
                  var0.field877 = null;
               }
            }
         }

      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "u.la(" + ')');
      }
   }

   static final void method1533(class744 var0, int var1) {
      try {
         var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = class601.field9203.field4347 * 1606920449;
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "u.uj(" + ')');
      }
   }

   static final void method1534(class744 var0, byte var1) {
      try {
         int var2 = var0.field3161[(var0.field3156 -= -391880689) * 681479919];
         class564 var3 = class449.method3756(var2, (byte)-3);
         var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = var3.field909 * 1548853569 == 1 ? 572201537 * var3.field876 : -1;
      } catch (RuntimeException var4) {
         throw class158.method3445(var4, "u.rd(" + ')');
      }
   }

   static final void method1535(class564 var0, class131 var1, class744 var2, byte var3) {
      try {
         int var4 = var2.field3161[(var2.field3156 -= -391880689) * 681479919];
         var0.field899 = var4 == 1;
         class814.method2932(var0, -501234662);
      } catch (RuntimeException var5) {
         throw class158.method3445(var5, "u.fe(" + ')');
      }
   }

   static final void method1536(class744 var0, int var1) {
      try {
         var0.field3161[(var0.field3156 += -391880689) * 681479919 - 1] = var0.field3174[var0.field3176 * 1883543357];
      } catch (RuntimeException var3) {
         throw class158.method3445(var3, "u.e(" + ')');
      }
   }
}
