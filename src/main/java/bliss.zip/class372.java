public class class372 {
   class387 field1119;
}
